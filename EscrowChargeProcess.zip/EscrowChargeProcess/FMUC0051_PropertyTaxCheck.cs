﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;


namespace EscrowChargeProcess
{
    /// <summary>
    /// Summary description for FMUC0051_PropertyTaxCheck
    /// </summary>
    [CodedUITest]
    public class FMUC0051_PropertyTaxCheck : MasterTestClass
    {

        #region BAT
        
        [TestMethod]
        [Description("Property Tax check Screen, create and cancelling the instance")]
        public void FMUC0051_BAT0001()
        {
            try
            {
                Reports.TestDescription = "AF3: Property Tax check Screen, create and cancelling the instance.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion
                
                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD) {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }else{
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Navigate to Property Tax check Screen and Verify for cancelation last instance and create new instance.")]
        public void FMUC0051_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1: Navigate to Property Tax check Screen and Verify for cancelation last instance and create new instance .";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify for Default Values
                Reports.TestStep = "Verify for Default Values.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Support.AreEqual("", FastDriver.PropertyTaxCheck.GABcode.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.GABName.FAGetValue().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.Edit.Selected.ToString());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.BusPhone.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.BusFax.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.CellPhone.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.Pager.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.EmailAddress.FAGetValue().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.EditName.Selected.ToString());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.Name.Text.Trim());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FAGetValue().Trim());
                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion
               
                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                #endregion

                #region Verify for the creation of instance.
                Reports.TestStep = "Verify for the creation of instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Support.AreEqual("6.99", FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FAGetValue().Trim());
                Support.AreEqual("6.99", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FAGetValue().Trim());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Navigate to Property Tax check Screen and Verify for cancelation last instance and create new instance.")]
        public void FMUC0051_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF4: Navigate to Property Tax check Screen and create second instance and canceling.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion
                               
                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                #endregion

                #region Navigate to Property Tax Check screen and clicking on New
                Reports.TestStep = "Navigate to Property Tax Check screen and clicking on New.";
                
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.BottomFrame.New();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();


                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check without Navigate to screen.";

                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify for the creation of instance.
                Reports.TestStep = "Verify for the creation of instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Support.AreEqual("6.99", FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FAGetValue().Trim());
                Support.AreEqual("6.99", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FAGetValue().Trim());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Navigate to Property Tax check Screen and create second instance.")]
        public void FMUC0051_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF5_01: Navigate to Property Tax check Screen and create second instance.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                #endregion

                #region Navigate to Property Tax Check screen and clicking on New
                Reports.TestStep = "Navigate to Property Tax Check screen and clicking on New.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.BottomFrame.New();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();


                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check without Navigate to screen.";

                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify for Two Instance
                Reports.TestStep = "Verify for Two Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.New.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Edit.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Remove.Displayed.ToString());
                Support.AreEqual("3", FastDriver.PropertyTaxSummary.SummaryTable.GetRowCount().ToString());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Navigate to Property Tax check Screen and create Third instance.")]
        public void FMUC0051_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF5_02: Navigate to Property Tax check Screen and create Third instance.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                #endregion

                #region Navigate to Property Tax Check screen and clicking on New
                Reports.TestStep = "Navigate to Property Tax Check screen and clicking on New.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.BottomFrame.New();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();


                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check without Navigate to screen.";

                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click on New and Set an instance of Property tax check without Navigate to screen.
                Reports.TestStep = "Click on New and Set an instance of Property tax check without Navigate to screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify for three Instance
                Reports.TestStep = "Verify for three Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.New.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Edit.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Remove.Displayed.ToString());

                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "3", 1, TableAction.Click);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Navigate to Property Tax check Screen and Reset Third instance.")]
        public void FMUC0051_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF6: Navigate to Property Tax check Screen and Reset Third instance.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                #endregion

                #region Navigate to Property Tax Check screen and clicking on New
                Reports.TestStep = "Navigate to Property Tax Check screen and clicking on New.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.BottomFrame.New();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();


                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check without Navigate to screen.";

                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click on New and Set an instance of Property tax check without Navigate to screen.
                Reports.TestStep = "Click on New and Set an instance of Property tax check without Navigate to screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify for three Instance and edit third instance
                Reports.TestStep = "Verify for three Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.New.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Edit.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Remove.Displayed.ToString());

                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "3", 1, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();
                #endregion

                #region Set an instance of Property tax check without Navigate to screen
                Reports.TestStep = "Set an instance of Property tax check without Navigate to screen.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify that last instance is reset
                Reports.TestStep = "Verify that last instance is reset.";
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                Support.AreEqual("Pro Active Test Name 1", FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "3", 5, TableAction.GetText).Message.Trim());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Navigate to Property Tax Summary Screen and edit the first instance.")]
        public void FMUC0051_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF1: Navigate to Property Tax Summary Screen and edit the first instance.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                #endregion

                #region Navigate to Property Tax Check screen and clicking on New
                Reports.TestStep = "Navigate to Property Tax Check screen and clicking on New.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.BottomFrame.New();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();


                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check without Navigate to screen.";

                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click on New and Set an instance of Property tax check without Navigate to screen.
                Reports.TestStep = "Click on New and Set an instance of Property tax check without Navigate to screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify for three Instance and edit first instance
                Reports.TestStep = "Verify for three Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.New.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Edit.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Remove.Displayed.ToString());

                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();
                #endregion

                #region Set an instance of Property tax check without Navigate to screen
                Reports.TestStep = "Set an instance of Property tax check without Navigate to screen.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("HUDASLNDR1");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
             
                #endregion

                #region Verify that last instance is reset
                Reports.TestStep = "Verify that last instance is reset.";
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1", FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "1", 5, TableAction.GetText).Message.Trim());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("AF2: Navigate to Property Tax Summary Screen and Dele the Third Instance instance.")]
        public void FMUC0051_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF2: Navigate to Property Tax Summary Screen and Delete the Third Instance instance.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");

                #endregion

                #region Enter payment details for PROPERTY_TAX_CHECK.
                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("6.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6.99");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("6.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("6.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-PROPERTY_TAX_CHECK");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                #endregion

                #region Navigate to Property Tax Check screen and clicking on New
                Reports.TestStep = "Navigate to Property Tax Check screen and clicking on New.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.BottomFrame.New();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();


                #endregion

                #region Set Property Tax Check Instance
                Reports.TestStep = "Set an instance of Property tax check without Navigate to screen.";

                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Click on New and Set an instance of Property tax check without Navigate to screen.
                Reports.TestStep = "Click on New and Set an instance of Property tax check without Navigate to screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");

                #endregion

                #region Enter payment details Property Tax.
                Reports.TestStep = "Enter payment details Property Tax.";

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.50");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                    Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2.50");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.Description.FASetText("FMUC0024 - Survey");
                }

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify for three Instance.
                Reports.TestStep = "Verify for three Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.New.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Edit.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Remove.Displayed.ToString());

                #endregion

                #region Delete the 3rd intance
                Reports.TestStep = "Delete the 3rd intance";
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.PropertyTaxSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                Support.AreEqual("3", FastDriver.PropertyTaxSummary.SummaryTable.GetRowCount().ToString());
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        
        #endregion

        #region REGRESSION

        [TestMethod]
        [Description("Create instance and clicking on Check Details, edit Payment Details.")]
        public void FMUC0051_REG0001()
        {
            try
            {
                Reports.TestDescription = "2542_2543_2539_2071_2541_2540_EW11: Create instance and clicking on Check Details, edit Payment Details.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Enter data except GAB CODE for Error warning
                Reports.TestStep = "Enter data except GAB CODE for Error warning.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";
                if (FileType == FormType.CD)
                {
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.Enabled.ToString());
                    Support.AreEqual("Property Taxes", FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAGetValue());
                }
                else
                {
                    FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FASetText("Description_1");
                }
                
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("10.01");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("30.03");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.Enabled.ToString());
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.SendKeys("100" + FAKeys.Tab);
                    Support.AreEqual("", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FAGetValue().Trim());

                }
                else
                {
                    FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.FASetText("20.02");
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FASetText("40.04");
                }

                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_2.FASetText("60.06");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_2.FASetText("80.08");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("70.07");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_2.FASetText("50.05");

                FastDriver.BottomFrame.Done();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxCheck.Thistextfieldconsistsofonlyblanksortabs.Text.Trim().Contains("Business Party required").ToString());

                #endregion

                #region Enter Gab code, reference no and clicking on Done
                Reports.TestStep = "Enter Gab code, reference no and clicking on Done.";
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.PropertyTaxCheck.Reference.FASetText("123456");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Enter the Charges Amount
                Reports.TestStep = "Enter the Charge Amount.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("Addtionalcharge");
                Keyboard.SendKeys(FAKeys.TabAway);

                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("55.01");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("25.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Tax ID and Verify for the check Amount.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.Reference.FASetText("123456");
                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Check Amount :$100.03", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim());
                }
                else {
                    Support.AreEqual("Check Amount :$39.97", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim());
                }

                #endregion

                #region Edit Check Details, Payment Details and verify Pencil image

                Reports.TestStep = "Clicking on Check Details Button.";
                FastDriver.PropertyTaxCheck.CheckDetails.FAClick();

                Reports.TestStep = "Edit description in Inspection/Repair Pest.";

                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();

                FastDriver.CheckDetailsDlg.Description.FASetText("Check Description Edited");

                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Voucher info edited for Inpection/Repair Pest");

                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Reports.TestStep = "Verify for Edited description in Inspection/Repair Pest.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Change Seller Charge Payment method to POC.";


                if (FileType == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItem("No Check");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("RBL");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxCheck.PenciImage.Displayed.ToString());
                #endregion
            }               
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        [Description("Verify the Short Keys")]
        public void FMUC0051_REG0002()
        {
            try
            {
                Reports.TestDescription = "Field_Defination: Verify the Short Keys.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Hot Keys, Create instance.
                Reports.TestStep = "Hot Keys, Create instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                Keyboard.SendKeys("%F");
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Cancel us Shortcut Keys.";

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Delete us Shortcut Keys.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDelete.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();


                #endregion

                #region Hot Keys, Create instance.
                Reports.TestStep = "Hot Keys, Create instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                Keyboard.SendKeys("%F");
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Done us Shortcut Keys.";
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Delete us Shortcut Keys.";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDelete.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "New us Shortcut Keys.";
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Create instance with different value.";
                FastDriver.PropertyTaxCheck.GABcode.FASetText("Hudflinsr1");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Done us Shortcut Keys.";
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify the Short Keys.")]
        public void FMUC0051_REG0003()
        {
            try
            {
                Reports.TestDescription = "Field_Defination: Verify the Short Keys.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Create 2 instances of PROPERTY_TAX_CHECK
                Reports.TestStep = "Create 2 instances of PROPERTY_TAX_CHECK";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("HUDFLINSR1");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify Create and Remove instances using shortcuts
                
                Reports.TestStep = "Select the Create instance from Summary screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 5, TableAction.Click);
                Keyboard.SendKeys("%R");

                Reports.TestStep = "Click on Cancel button.";

                FastDriver.WebDriver.WaitForAlertToExist(20);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Select instance for Edit and pressing ALT+E.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 5, TableAction.Click);
                Keyboard.SendKeys("%E");
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Create instance from Summary screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 5, TableAction.Click);
                Keyboard.SendKeys("%R");
                Support.AreEqual("All information will be removed for this Property Tax.  Continue?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "New us Shortcut Keys.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Create instance with different value.";
                FastDriver.PropertyTaxCheck.FindGABCode("HUDFLINSR1");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify for Two Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.New.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Edit.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Remove.Displayed.ToString());
                Support.AreEqual("3", FastDriver.PropertyTaxSummary.SummaryTable.GetRowCount().ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify name,contact,Business phone and fax on Summary screen")]
        public void FMUC0051_REG0004()
        {
            try
            {
                Reports.TestDescription = "Insp_Rep_Summary_column: Verify name,contact,Business phone and fax on Summary screen.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Create Instance, Enter TAX ID,FIELD DEF for Description ,Buyer Charge, Buyer Credit ,seller Charge and Seller Credit Tex Boxes.
                Reports.TestStep = "Create Instance, Enter TAX ID,FIELD DEF for Description ,Buyer Charge, Buyer Credit ,seller Charge and Seller Credit Tex Boxes.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                Keyboard.SendKeys("%F");
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.Reference.FASetText("12345678");
                if (FileType == FormType.CD)
                {
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.Enabled.ToString());
                    Support.AreEqual("Property Taxes", FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAGetValue());
                }
                else
                {
                    FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FASetText("AlphaNumeric45CharactersAsChargeDescription10212");
                }

                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("12345678910.2345");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("12345678910.2345");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.Enabled.ToString());
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.SendKeys("100" + FAKeys.Tab);
                    Support.AreEqual("", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FAGetValue().Trim());

                }
                else
                {
                    FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.FASetText("12345678910.2345");
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FASetText("12345678910.2345");
                }
                FastDriver.BottomFrame.Done();
                #endregion
                
                #region Verify for the Data Entered
                Reports.TestStep = "Verify for the Data Entered.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAGetValue());
                }
                else
                {
                    Support.AreEqual("AlphaNumeric45CharactersAsChargeDescription10", FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAGetValue());
                }

                Support.AreEqual("12,345,678,910.23", FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FAGetValue());
                Support.AreEqual("12,345,678,910.23", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FAGetValue());

                if (FileType == FormType.CD)
                {
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.Enabled.ToString());
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.SendKeys("100" + FAKeys.Tab);
                    Support.AreEqual("", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FAGetValue().Trim());

                }
                else
                {
                    Support.AreEqual("12,345,678,910.23", FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.FAGetValue());
                    Support.AreEqual("12,345,678,910.23", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FAGetValue());

                }


                #endregion

                Reports.TestStep = "New us Shortcut Keys and create isntance with diferent values.";
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Reports.TestStep = "Create instance with different value.";

                FastDriver.PropertyTaxCheck.FindGABCode("HUDFLINSR1");
                Reports.TestStep = "Verify TAX ID on Summary screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(3, "12345678", 1, TableAction.Click);

                Reports.TestStep = "Select the Create instance from Summary screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 1, TableAction.Click);
                Keyboard.SendKeys("%R");

                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(7, "(616)451-2290", 1, TableAction.Click);


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify Error warning conditions and Static Messages.")]
        public void FMUC0051_REG0005()
        {
            try
            {
                Reports.TestDescription = "Err_War_Conditons_12_6_8_9_11_10_15_13_14: Verify Error warning conditions and Static Messages.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Enter data except GAB CODE for Error warning
                Reports.TestStep = "Enter data except GAB CODE for Error warning.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                Reports.TestStep = "Enter payment details for PROPERTY_TAX_CHECK.";
                if (FileType == FormType.CD)
                {
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.Enabled.ToString());
                    Support.AreEqual("Property Taxes", FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAGetValue());
                }
                else
                {
                    FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FASetText("Description_1" + FAKeys.Tab);
                }


                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("10.01");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("30.03");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.Enabled.ToString());
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.SendKeys("100" + FAKeys.Tab);
                    Support.AreEqual("", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FAGetValue().Trim());

                }
                else
                {
                    FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.FASetText("20.02");
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FASetText("40.04");
                }

                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_2.FASetText("60.06");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_2.FASetText("80.08");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("70.07");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_2.FASetText("50.05");

                FastDriver.BottomFrame.Done();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxCheck.Thistextfieldconsistsofonlyblanksortabs.Text.Trim().Contains("Business Party required").ToString());

                #endregion

                #region Enter Invalid ID CODE to verify the Error Message
                Reports.TestStep = "Enter Invalid ID CODE to verify the Error Message.";
                FastDriver.PropertyTaxCheck.GABcode.FASetText("INVALID_ID");
                FastDriver.PropertyTaxCheck.Find.Click();
                Support.AreEqual("ID Code not found.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.BottomFrame.Cancel();
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on New and cancel de second isntance"
                Reports.TestStep = "Click on New";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Cancel the second instance.";
                FastDriver.PropertyTaxCheck.FindGABCode("HUDFLINSR1");
                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("Addtionalcharge" + FAKeys.Tab);

                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("30.01");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("30.03");
                FastDriver.BottomFrame.Cancel();
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify Error warning conditions and Static Messages.")]
        public void FMUC0051_REG0006()
        {
            try
            {
                Reports.TestDescription = "Err_War_Conditons_12_6_8_9_11_10_15_13_14: Verify Error warning conditions and Static Messages.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Create 2 instances of property tax check
                Reports.TestStep = "Create 2 instances of property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("247");

                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("10.01");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("30.03");

               
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_2.FASetText("60.06");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_2.FASetText("80.08");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("70.07");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_2.FASetText("50.05");
                FastDriver.BottomFrame.Done();

                
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("HUDFLINSR1");
                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("Addtionalcharge"+ FAKeys.Tab);

                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("30.01");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("30.03");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify for Two Instance
                Reports.TestStep = "Verify for Two Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.New.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Edit.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Remove.Displayed.ToString());
                Support.AreEqual("3", FastDriver.PropertyTaxSummary.SummaryTable.GetRowCount().ToString());
                #endregion

                #region Create new instance and cancel it
                Reports.TestStep = "Click on New.";
                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Cancel the Third instance.";
                FastDriver.PropertyTaxCheck.FindGABCode("PROACT01");
                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("Addtionalcharge" + FAKeys.Tab);

                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("40.11");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("50.23");
                FastDriver.BottomFrame.Cancel();
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify instance Edit email and Name
                Reports.TestStep = "Select first instance to edit.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.New.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Edit.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Remove.Displayed.ToString());

                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Flood Insurance 1 for HUD Testing Name 1", 1, TableAction.Click);
                Reports.TestStep = "Verify and Edit the Third instance.";
                FastDriver.PropertyTaxSummary.Edit.FAClick();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Reports.TestStep = "Enter Invalid Email ID.";
                FastDriver.PropertyTaxCheck.FindGABCode("247");

                FastDriver.PropertyTaxCheck.Edit.FASetCheckbox(true);

                FastDriver.PropertyTaxCheck.EmailAddress.FASetText("akjdka@asd@");
                FastDriver.BottomFrame.Done();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Please correct invalid data entered.");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Enter Valid Email ID and Select edit name checkbox.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.Edit.FASetCheckbox(true);
                FastDriver.PropertyTaxCheck.EmailAddress.FASetText("sshailandra@firstam.com");
                FastDriver.PropertyTaxCheck.EditName.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Name field is required when Edit Name checkbox is selected.";
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Name field is required when Edit Name checkbox is selected.");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.Name.FASetText("EditName");
                FastDriver.PropertyTaxCheck.Reference.FASetText("12345");
                #endregion 

                #region Change business Party After Enter Reference Number
                Reports.TestStep = "Change business Party After Enter Reference Number.";
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.Click();
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?",FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify Error warning conditions and Static Messages.")]
        public void FMUC0051_REG0007()
        {
            try
            {
                Reports.TestDescription = "Err_War_Conditons_2_1_7_3_4_5: Verify Error waring conditions and Static Messages.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Create 3 instances of property tax check
                Reports.TestStep = "Create 3 instances of property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("247");

                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("10.01");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("30.03");


                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_2.FASetText("60.06");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_2.FASetText("80.08");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("70.07");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_2.FASetText("50.05");
                FastDriver.BottomFrame.Done();


                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("HUDFLINSR1");
                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("Addtionalcharge" + FAKeys.Tab);

                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("30.01");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("30.03");
                FastDriver.BottomFrame.Done();

                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("HUDFLINSR1");
                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("Addtionalcharge" + FAKeys.Tab);

                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("30.01");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("30.03");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Delete an isntance
                Reports.TestStep = "Delete the instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 5, TableAction.Click);
                FastDriver.PropertyTaxSummary.Remove.FAClick();
                Reports.TestStep = "All information will be removed for this Property Tax. Continue?.";
                Support.AreEqual("All information will be removed for this Property Tax.  Continue?", FastDriver.WebDriver.HandleDialogMessage());
                #endregion

                #region Verify for Two Instance
                Reports.TestStep = "Verify for Two Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.New.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Edit.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxSummary.Remove.Displayed.ToString());
                Support.AreEqual("3", FastDriver.PropertyTaxSummary.SummaryTable.GetRowCount().ToString());
                #endregion

                #region Create New instance and verify Descriptio is enabled/disabled and can/cannot be edited
                Reports.TestStep = "Click on New.";
                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Reports.TestStep = "Create Instance with Description, Buyer and seller charge.";
                FastDriver.PropertyTaxCheck.FindGABCode("247");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.Enabled.ToString());
                    Support.AreEqual("Property Taxes", FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAGetValue());
                }
                else
                {
                    FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FASetText("AlphaNumeric45CharactersAsChargeDescription10212");
                }

                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("10.01");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("30.03");

                if (FileType == FormType.CD)
                {
                    if (!FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.Enabled)
                    {
                        Reports.StatusUpdate("The First Charge Presnet under the section : \"Property Taxes\" has Uneditable Charge description according to the ADM Set up for a file of type = CD", true);
                    }
                    else {
                        Reports.StatusUpdate("There is a chenge in the ADM set up.", false);
                    }

                }
                else
                {
                    FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.Clear();
                    FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.SendKeys(FAKeys.Tab);
                }

                Reports.TestStep = "User tries to delete a charge description that has a charge amount.";
                if (FileType == FormType.CD)
                {
                    Reports.StatusUpdate("The UnEditable charge can not be deleted as it depends on the ADM Setup", true);
                }
                else {
                    Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());
                }
                #endregion
                    
                #region Print All Checks.

                Reports.TestStep = "Print All Checks.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
        
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();


                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);


                Reports.TestStep = "Click on Done in ADS screen.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                #endregion
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify Error warning conditions and Static Messages.")]
        public void FMUC0051_REG0008()
        {
            try
            {
                Reports.TestDescription = "Err_War_Conditons_2_1_7_3_4_5: Verify Error warning conditions and Static Messages.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Create 3 instances of property tax check
                Reports.TestStep = "Create 3 instances of property tax check.";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("247");

                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("10.01");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("30.03");


                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_2.FASetText("60.06");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_2.FASetText("80.08");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("70.07");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_2.FASetText("50.05");
                FastDriver.BottomFrame.Done();


                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("HUDFLINSR1");
                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("Addtionalcharge" + FAKeys.Tab);

                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("30.01");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("30.03");
                FastDriver.BottomFrame.Done();

                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("HUDFLINSR1");
                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("Addtionalcharge" + FAKeys.Tab);

                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("30.01");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("30.03");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Print All Checks.

                Reports.TestStep = "Print All Checks.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();


                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);


                Reports.TestStep = "Click on Done in ADS screen.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                #endregion

                #region Delete an instance
                Reports.TestStep = "Delete the instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();

                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 5, TableAction.Click);
                FastDriver.PropertyTaxSummary.Remove.FAClick();
                Reports.TestStep = "Delete a payee in Home warranty instance.";
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());
                #endregion

                #region Verify for Two Instance
                Reports.TestStep = "Verify for Two Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 1, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();

                #endregion

                Reports.TestStep = "Change the Payee Name after Issuing the check.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.GABcode.FASetText("Some_Value");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                Reports.TestStep = "Change Payee To whom check issued.";
                Support.AreEqual("A check has been issued for this Payee.  The Payee name cannot be changed.", FastDriver.WebDriver.HandleDialogMessage());
               
                Reports.TestStep = "Edit the Charge Enter less than the issued.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("1.00" + FAKeys.Tab);

                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?.";
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Edit the Charge Enter more than the issued.";
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("100.00" + FAKeys.Tab);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Create instance from Summary screen.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 1, TableAction.Click);
                Keyboard.SendKeys("%R");
                Reports.TestStep = "Delete The Payee have Issued Instance.";

                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Select instance for Edit and pressing ALT+E.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 1, TableAction.Click);
                Keyboard.SendKeys("%E");
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Allow Multiple Instances of Property Tax Check.")]
        public void FMUC0051_REG0009()
        {
            try
            {
                Reports.TestDescription = "FM3243 : Allow Multiple Instances of Property Tax Check.";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Create 3 Instances for Property Tax Check
                Reports.TestStep = "Create First Instance for Property Tax Check";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PC1");
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Create Second Instance for Property Tax Check";
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PC2");
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();

                Reports.TestStep = "Create Third Instance for Property Tax Check";
                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PC3");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify created instances
                Reports.TestStep = "Verify For First Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Support.AreEqual("property tax check 1 name 1", FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "1", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify For second Instance.";
                Support.AreEqual("property tax check 2 name 1", FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "2", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify For third Instance.";
                Support.AreEqual("property tax check 3 name 1", FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "3", 5, TableAction.GetText).Message.Trim());

                #endregion

                #region Verify Boundry values
                Reports.TestStep = "Edit First Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "property tax check 1 name 1", 5, TableAction.Click);
                Keyboard.SendKeys("%E");

                Reports.TestStep = "Boundry Value Test.";
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();

                FastDriver.PropertyTaxCheck.GABcode.FASetText("12345678910");

                FastDriver.PropertyTaxCheck.Edit.FASetCheckbox(true);
                FastDriver.PropertyTaxCheck.BusPhone.FASetText("(111)111-111");
                FastDriver.PropertyTaxCheck.BusFax.FASetText("(111)111-111");
                FastDriver.PropertyTaxCheck.CellPhone.FASetText("(111)111-111");
                FastDriver.PropertyTaxCheck.Pager.FASetText("(111)111-111");
                FastDriver.PropertyTaxCheck.EmailAddress.FASetText("aeueuze@email@com");
                FastDriver.PropertyTaxCheck.Reference.FASetText("123456789a123456789a123456789a123456789a123456789aExtra");

                if (FileType == FormType.CD)
                {
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.Enabled.ToString());
                    FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("1111111111000");
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.Enabled.ToString());
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("1111111111000");
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.SendKeys("100.00");
                    Support.AreEqual("0.00", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FAGetValue());
                }
                else
                {
                    FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FASetText("123456789a123456789a123456789a123456789a12345Extra");
                    FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("1111111111000");
                    FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.FASetText("1111111111000");
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("1111111111000");
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FASetText("1111111111000");
                }

                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("123456789a123456789a123456789a123456789a12345Extra" + FAKeys.Tab);
                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("1111111111000");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("1111111111000" + FAKeys.Tab);

                Reports.TestStep = "Validate the data.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Support.AreEqual("1234567891", FastDriver.PropertyTaxCheck.GABcode.FAGetValue());
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxCheck.Edit.IsSelected().ToString());
                Support.AreEqual("(???)???-????", FastDriver.PropertyTaxCheck.BusPhone.FAGetValue());
                Support.AreEqual("(???)???-????", FastDriver.PropertyTaxCheck.BusFax.FAGetValue());
                Support.AreEqual("(???)???-????", FastDriver.PropertyTaxCheck.CellPhone.FAGetValue());
                Support.AreEqual("(???)???-????", FastDriver.PropertyTaxCheck.Pager.FAGetValue());
                Support.AreEqual("?", FastDriver.PropertyTaxCheck.EmailAddress.FAGetValue());
                Support.AreEqual("123456789a123456789a123456789a123456789a123456789a", FastDriver.PropertyTaxCheck.Reference.FAGetValue());

                if (FileType == FormType.CD)
                {
                    Support.AreEqual("Property Taxes", FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAGetValue());
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.Enabled.ToString());
                    Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.Enabled.ToString());
                    FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.SendKeys("100.00");
                    Support.AreEqual("0.00", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FAGetValue());
                }else{
                    Support.AreEqual("123456789a123456789a123456789a123456789a12345", FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAGetValue());
                    Support.AreEqual("?", FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCredit_1.FAGetValue());
                    Support.AreEqual("?", FastDriver.PropertyTaxCheck.PropertyTaxesSellerCredit_1.FAGetValue());
                }

                Support.AreEqual("123456789a123456789a123456789a123456789a12345", FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FAGetValue());
                Support.AreEqual("?", FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FAGetValue());

                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.GiveFocus();
              

                Support.AreEqual("?", FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FAGetValue());

                Reports.TestStep = "Less than ten digits are typed in to a phone field.";
                FastDriver.BottomFrame.Done();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Please correct invalid data entered.");

                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify created instances
                Reports.TestStep = "Verify For First Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Support.AreEqual("property tax check 1 name 1", FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "1", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify For second Instance.";
                Support.AreEqual("property tax check 2 name 1", FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "2", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify For third Instance.";
                Support.AreEqual("property tax check 3 name 1", FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "3", 5, TableAction.GetText).Message.Trim());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("EWC11_EWC13_EWC14")]
        public void FMUC0051_REG0010()
        {
            try
            {
                Reports.TestDescription = "EWC11_EWC13_EWC14";

                #region Login
                _IISLOGIN();
                #endregion

                #region Create File
                Reports.TestStep = "Create file and navigate to the created file";
                FormType FileType = _CreateFile();
                #endregion

                #region Create 3 Instances for Property Tax Check
                Reports.TestStep = "Create First Instance for Property Tax Check";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PC1");
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Create Second Instance for Property Tax Check";
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PC2");
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();

                Reports.TestStep = "Create Third Instance for Property Tax Check";
                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("PC3");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify created instances
                Reports.TestStep = "Click on New and enter charges amount";
                
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.New.FAClick();

                Reports.TestStep = "Enter the Charge Amount.";
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FASetText("Addtionalcharge" + FAKeys.Tab);
                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("50.00");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("20.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "save Changes without Bus Party.";
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Error(s) occured. See Message pane.");

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxCheck.Thistextfieldconsistsofonlyblanksortabs.Text.Trim().Contains("Business Party required").ToString());

                Reports.TestStep = "Enter Invalid Email ID.";
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.PropertyTaxCheck.Edit.FASetCheckbox(true);
                FastDriver.PropertyTaxCheck.EmailAddress.FASetText("akjdka@asd@");
                
                Reports.TestStep = "Less than ten digits are typed in to a phone field.";
                FastDriver.BottomFrame.Done();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Please correct invalid data entered.");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Support.AreEqual(false.ToString(), FastDriver.PropertyTaxCheck.Thistextfieldconsistsofonlyblanksortabs.Text.Trim().Contains("Business Party required").ToString());

                Reports.TestStep = "Verify Tool Tip for Email ID.";
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxCheck.EmailAddress.GetAttribute("title").Contains("Email address is invalid.\r\nValid Examples:\r\n\txyz@abc.com\r\n\txyz@abc.com.uk\r\n\txyz_123@abc.com\r\n\txyz-12.wuv@abc.cnn.edu.uk").ToString());
                
                Reports.TestStep = "Enter Valid Email ID.";
                FastDriver.PropertyTaxCheck.EmailAddress.FASetText("sshailandra@firstam.com");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("10.1");
                FastDriver.BottomFrame.Done();
                
                #endregion

                #region Verify 4th  instance
                Reports.TestStep = "Verify Fouth Instance.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 5, TableAction.Click);
                Keyboard.SendKeys("%E");

                Reports.TestStep = "Enter reference Number.";
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.Reference.FASetText("12345");

                Reports.TestStep = "Change business Party After Enter Reference Number.";
                FastDriver.PropertyTaxCheck.GABcode.FASetText("PC3");
                FastDriver.PropertyTaxCheck.Find.Click();

                Reports.TestStep = "Replace Gab code which has reference number and verify Changing the Business Party will remove.";
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                Support.AreEqual("12345", FastDriver.PropertyTaxCheck.Reference.FAGetValue().Trim());

                FastDriver.PropertyTaxCheck.Reference.FASetText("12345");

                Reports.TestStep = "Change business Party After Enter Reference Number.";
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.Click();

                Reports.TestStep = "Replace Gab code which has reference number and verify Changing the Business Party will remove.";
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify the TAX IPN Number
                Reports.TestStep = "Verify the TAX IPN Number";
                FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Support.AreEqual("12345", FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(5, "Lenders Advantage", 3, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
        
        #region PRIVATE METHODS

        private FormType _CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = _GetCurrentFileFormType();
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.LiabilityAmount = 5000;

            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            #region CreateNewLoan
            var newLoan = new NewLoanParameters()
            {
                Type = "",
                Amount = "",
                GABCode = "247"
            };
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.FillNewLoanForm(newLoan);
            FastDriver.NewLoan.ClickRecapTab();
            FastDriver.NewLoan.WaitForRecapToLoad();
            #endregion

            return customizableFileRequest.formType;
        }

        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private FormType _GetCurrentFileFormType()
        {
            return AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}