﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace EscrowChargeProcess
{

    /// <summary>
    /// Summary description for FMUC0041_HomeownerAssociation
    /// </summary>
    [CodedUITest]
    public class FMUC0046_AssumptionLoan : MasterTestClass
    {

        #region BAT

        [TestMethod]
        [Description("Create Assumption Loan Instances.")]
        public void FMUC0046_BAT0001()
        {
            try
            {
                Reports.TestDescription ="MF1_01: Create Assumption Loan Instances.";

                #region Login 
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File and Verify Values
                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";

                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem());
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetAttribute("value"));
                Support.AreEqual(@"Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetAttribute("value"));
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetAttribute("value"));
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetAttribute("value"));
                Support.AreEqual(@"Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetAttribute("value"));
                Support.AreEqual(@"9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetAttribute("value"));
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetAttribute("value"));
                Support.AreEqual(@"CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem());
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetAttribute("value"));

                #endregion

                #region Create a Assumption Loan Instance
                Reports.TestStep = "Create a Assumption Loan Instance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                Support.AreEqual(true, FastDriver.AssumptionLoanDetails.LenderPolicyLiability.IsDisplayed(), "Verifying Lender Policy Liability field is displayed.");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Validating the data for creating instance.
                Reports.TestStep = "Validating the data for creating instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                Support.AreEqual("$ 300.00", FastDriver.AssumptionLoanDetails.UnPrincBalPane.Text.Trim());
                Support.AreEqual("300.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Trim());
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanDetails.InterestPaidto.FAGetValue().Trim());
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanDetails.NextPaymentDue.FAGetValue().Trim());
                Support.AreEqual(true, FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FAGetValue().Contains("100.50"), "Verifying if amount entered was saved.");
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanDetails.NotedDate.FAGetValue().Trim());
                Support.AreEqual("500.00", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Trim());
                Support.AreEqual("200.00", FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue().Trim());
                Support.AreEqual("Interest only", FastDriver.AssumptionLoanDetails.PaymentType.FAGetSelectedItem().Trim());
                Support.AreEqual("Month", FastDriver.AssumptionLoanDetails.PaymentPer.FAGetSelectedItem().Trim());

                #endregion

                #region Enter Charges in Charges Tab
                Reports.TestStep = "Enter Charges in Charges Tab.";

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FASetText("Changed Description");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.SendKeys("500.00");
                FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesPaymentDetails.SendKeys(FAKeys.Tab);
                #endregion

                #region validate Charges in Charges Tab
                Reports.TestStep = "validate Charges in Charges Tab.";

                Support.AreEqual("Changed Description", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FAGetValue().Trim());
                Support.AreEqual("500.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Trim());
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Click();
                Support.AreEqual("500.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.FAGetValue().Trim());

                #endregion

                #region  Enter Parties and Record Information.
                Reports.TestStep = "Enter Parties and Record Information.";
                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();

                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrusteeBPGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanParties.TrusteeFind.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();
                
                FastDriver.AssumptionLoanParties.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                FastDriver.AssumptionLoanRecording.TrustDeedDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.RecordingDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.Instrument.FASetText("Insrument");
                FastDriver.AssumptionLoanRecording.Book.FASetText("Book");
                FastDriver.AssumptionLoanRecording.Page.FASetText("page");
                
                #endregion

                #region Validate entered Parties and Recording Information.
                Reports.TestStep = "Validate entered Parties and Recording Information.";

                Support.AreEqual("08-22-2012", FastDriver.AssumptionLoanRecording.TrustDeedDate.FAGetValue());
                Support.AreEqual("08-22-2012", FastDriver.AssumptionLoanRecording.RecordingDate.FAGetValue());
                Support.AreEqual("Insrument", FastDriver.AssumptionLoanRecording.Instrument.FAGetValue());
                Support.AreEqual("Book", FastDriver.AssumptionLoanRecording.Book.FAGetValue());
                Support.AreEqual("page", FastDriver.AssumptionLoanRecording.Page.FAGetValue());

                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Create The Second Instance.")]
        public void FMUC0046_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_02: Create The Second Instance.";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File
                Reports.TestStep = "Create a new file.";

                _CreateFile();
                                          
                #endregion

                #region Create a Assumption Loan Instance
                Reports.TestStep = "Create a Assumption Loan Instance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Enter Charges in Charges Tab
                Reports.TestStep = "Enter Charges in Charges Tab.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FASetText("Changed Description");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.SendKeys("500.00");
                FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesPaymentDetails.SendKeys(FAKeys.Tab);
                #endregion
                               
                #region  Enter Parties and Record Information.
                Reports.TestStep = "Enter Parties and Record Information.";
                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();

                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrusteeBPGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanParties.TrusteeFind.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                FastDriver.AssumptionLoanRecording.TrustDeedDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.RecordingDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.Instrument.FASetText("Insrument");
                FastDriver.AssumptionLoanRecording.Book.FASetText("Book");
                FastDriver.AssumptionLoanRecording.Page.FASetText("page");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create a new Assumption Loan Instance
                Reports.TestStep = "Create a new Assumption Loan Instance.";

                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion
                             
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Edit the Created Instances.")]
        public void FMUC0046_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF1: Edit the Created Instances.";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File
                _CreateFile();

                #endregion

                #region Create a Assumption Loan Instance
                Reports.TestStep = "Create a Assumption Loan Instance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Enter Charges in Charges Tab
                Reports.TestStep = "Enter Charges in Charges Tab.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FASetText("Changed Description");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.SendKeys("500.00");
                FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesPaymentDetails.SendKeys(FAKeys.Tab);
                #endregion

                #region  Enter Parties and Record Information.
                Reports.TestStep = "Enter Parties and Record Information.";
                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();

                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrusteeBPGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanParties.TrusteeFind.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                FastDriver.AssumptionLoanRecording.TrustDeedDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.RecordingDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.Instrument.FASetText("Insrument");
                FastDriver.AssumptionLoanRecording.Book.FASetText("Book");
                FastDriver.AssumptionLoanRecording.Page.FASetText("page");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create a new Assumption Loan Instance
                Reports.TestStep = "Create a new Assumption Loan Instance.";

                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region  Verify for summary screen and select the Instance to Edit
                Reports.TestStep = "Verify for summary screen and select the Instance to Edit.";

                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanSummary.New.Displayed.ToString());

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Lease 3 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();

                Reports.TestStep = "Modify the Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsReference.FASetText("8055916");
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("3000.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2013");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2013");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("1500.00W");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2013");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("5000.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("2000.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();
                      
                #endregion

                #region Verify for summary screen and select the Instance to Edit.
                Reports.TestStep = "Verify for summary screen and select the Instance to Edit.";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanSummary.New.Displayed.ToString());

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Lease 3 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();

                Reports.TestStep = "2656_Verify the change.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                Support.AreEqual("$ 3,000.00", FastDriver.AssumptionLoanDetails.UnPrincBalPane.Text.Trim());
                Support.AreEqual("8055916", FastDriver.AssumptionLoanDetails.DetailsReference.FAGetValue().Trim());

                Support.AreEqual("3,000.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Trim());
                Support.AreEqual("06-04-2013", FastDriver.AssumptionLoanDetails.InterestPaidto.FAGetValue().Trim());
                Support.AreEqual("06-04-2013", FastDriver.AssumptionLoanDetails.NextPaymentDue.FAGetValue().Trim());
                Support.AreEqual(true, FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FAGetValue().Contains("1,500.00"), "Verifying if amount entered was saved.");
                Support.AreEqual("06-04-2013", FastDriver.AssumptionLoanDetails.NotedDate.FAGetValue().Trim());
                Support.AreEqual("5,000.00", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Trim());
                Support.AreEqual("2,000.00", FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue().Trim());
                Support.AreEqual("Interest only", FastDriver.AssumptionLoanDetails.PaymentType.FAGetSelectedItem().Trim());
                Support.AreEqual("Month", FastDriver.AssumptionLoanDetails.PaymentPer.FAGetSelectedItem().Trim());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Cancel the Edited Instance.")]
        public void FMUC0046_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF6: Cancel the Edited Instance.";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File
                _CreateFile();

                #endregion

                #region Create a Assumption Loan Instance
                Reports.TestStep = "Create a Assumption Loan Instance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Enter Charges in Charges Tab
                Reports.TestStep = "Enter Charges in Charges Tab.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FASetText("Changed Description");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.SendKeys("500.00");
                FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesPaymentDetails.SendKeys(FAKeys.Tab);
                #endregion

                #region  Enter Parties and Record Information.
                Reports.TestStep = "Enter Parties and Record Information.";
                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();

                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrusteeBPGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanParties.TrusteeFind.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                FastDriver.AssumptionLoanRecording.TrustDeedDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.RecordingDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.Instrument.FASetText("Insrument");
                FastDriver.AssumptionLoanRecording.Book.FASetText("Book");
                FastDriver.AssumptionLoanRecording.Page.FASetText("page");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create a new Assumption Loan Instance
                Reports.TestStep = "Create a new Assumption Loan Instance.";

                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.DetailsReference.FASetText("8055916");

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region  Verify for summary screen and select the Instance to Edit.
                Reports.TestStep = "Verify for summary screen and select the Instance to Edit.";

                FastDriver.AssumptionLoanSummary.WaitForScreenToLoad(element: FastDriver.AssumptionLoanSummary.New);
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Lease 3 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();

                Reports.TestStep = "Cancel Edited Assumption Loan Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Subject To");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Trimester");

                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                             
                #endregion

                #region Verify Cancelled Edited Assumption Loan Instance
                Reports.TestStep = "Verify Cancelled Edited Assumption Loan Instance.";

                Support.AreNotEqual("Subject To", FastDriver.AssumptionLoanDetails.DetailsLoanType.FAGetSelectedItem().Trim());
                Support.AreNotEqual("Trimester", FastDriver.AssumptionLoanDetails.DetailsLoanType.FAGetSelectedItem().Trim());

                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify for summary screen and select the Instance to Edit.
                Reports.TestStep = "Verify for summary screen and select the Instance to Edit.";
                FastDriver.AssumptionLoanSummary.WaitForScreenToLoad(element: FastDriver.AssumptionLoanSummary.New);
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Lease 3 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();

                Reports.TestStep = "Verify the change.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                Support.AreEqual("8055916", FastDriver.AssumptionLoanDetails.DetailsReference.FAGetValue().Trim());

                Support.AreEqual("300.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Trim());
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanDetails.InterestPaidto.FAGetValue().Trim());
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanDetails.NextPaymentDue.FAGetValue().Trim());
                Support.AreEqual(true, FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FAGetValue().Contains("100.50"), "Verifying if amount entered was saved.");
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanDetails.NotedDate.FAGetValue().Trim());
                Support.AreEqual("500.00", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Trim());
                Support.AreEqual("200.00", FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue().Trim());
                Support.AreEqual("Interest only", FastDriver.AssumptionLoanDetails.PaymentType.FAGetSelectedItem().Trim());
                Support.AreEqual("Month", FastDriver.AssumptionLoanDetails.PaymentPer.FAGetSelectedItem().Trim());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Delete the Instance.")]
        public void FMUC0046_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF2: Delete the Instance.";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File
                _CreateFile();

                #endregion

                #region Create a Assumption Loan Instance
                Reports.TestStep = "Create a Assumption Loan Instance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Enter Charges in Charges Tab
                Reports.TestStep = "Enter Charges in Charges Tab.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FASetText("Changed Description");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.SendKeys("500.00");
                FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesPaymentDetails.SendKeys(FAKeys.Tab);
                #endregion

                #region  Enter Parties and Record Information.
                Reports.TestStep = "Enter Parties and Record Information.";
                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();

                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrusteeBPGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanParties.TrusteeFind.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                FastDriver.AssumptionLoanRecording.TrustDeedDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.RecordingDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.Instrument.FASetText("Insrument");
                FastDriver.AssumptionLoanRecording.Book.FASetText("Book");
                FastDriver.AssumptionLoanRecording.Page.FASetText("page");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Create a new Assumption Loan Instance
                Reports.TestStep = "Create a new Assumption Loan Instance.";

                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.DetailsReference.FASetText("8055916");

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region  Delete the Instance.
                Reports.TestStep = "Delete the Instance.";

                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanSummary.New.Displayed.ToString());

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Lease 3 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Remove.FAClick();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Cancel the First Assumption Loan Instances.")]
        public void FMUC0046_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF3: Cancel the First Assumption Loan Instances.";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File and Verify Values
                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";

                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem());
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetAttribute("value"));
                Support.AreEqual(@"Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetAttribute("value"));
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetAttribute("value"));
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetAttribute("value"));
                Support.AreEqual(@"Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetAttribute("value"));
                Support.AreEqual(@"9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetAttribute("value"));
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetAttribute("value"));
                Support.AreEqual(@"CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem());
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetAttribute("value"));

                #endregion

                #region Cancel the Instance
                Reports.TestStep = "Cancel the Instance";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

                #region Verify Cancelation of 1st Instance.
                Reports.TestStep = "Verify Cancelation of 1st Instance.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Support.AreEqual("", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanDetails.InterestPaidto.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanDetails.NextPaymentDue.FAGetValue().Trim());
                Support.AreEqual(true, FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FAGetValue().Contains(""), "Verifying if amount entered was saved.");
                Support.AreEqual("", FastDriver.AssumptionLoanDetails.NotedDate.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue().Trim());
                Support.AreEqual("Principal & Interest", FastDriver.AssumptionLoanDetails.PaymentType.FAGetSelectedItem().Trim());
                Support.AreEqual("Month", FastDriver.AssumptionLoanDetails.PaymentPer.FAGetSelectedItem().Trim());

                #endregion

                #region Create a Assumption Loan Instance
                Reports.TestStep = "Create a Assumption Loan Instance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();
                
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("AF4: Cancel the second instance")]
        public void FMUC0046_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF4: Cancel the second instance";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File
                _CreateFile();

                #endregion
                               
                #region Create a Assumption Loan Instance
                Reports.TestStep = "Create a Assumption Loan Instance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Cancel a Assumption Loan Instance.
                Reports.TestStep = "Cancel a Assumption Loan Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion 

                #region Create a new Assumption Loan Instance
                Reports.TestStep = "Create a new Assumption Loan Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Cancel the third Instance.")]
        public void FMUC0046_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF5: Cancel the third Instance.";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File
                _CreateFile();

                #endregion

                #region Create a Assumption Loan Instance
                Reports.TestStep = "Create a Assumption Loan Instance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion
                
                #region Create a new Assumption Loan Instance
                Reports.TestStep = "Create a new Assumption Loan Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Cancel a Assumption Loan Instance.
                Reports.TestStep = "Cancel a Assumption Loan Instance.";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                FastDriver.AssumptionLoanSummary.New.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify the cancellation of third instance.

                Reports.TestStep = "Verify the cancellation of third instance.";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                Support.AreEqual("3", FastDriver.AssumptionLoanSummary.SummaryTable.GetRowCount().ToString());

                #endregion


                #region Create a new Assumption Loan Instance
                Reports.TestStep = "Create a new Assumption Loan Instance.";
                FastDriver.AssumptionLoanSummary.New.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.BottomFrame.Done();

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Add an Assumption Loan to an Escrow File.")]
        public void FMUC0046_BAT0009()
        {
            string MaturityDate = DateTime.Now.ToDateString();
            try
            {
                Reports.TestDescription = "MF1 :Add an Assumption Loan to an Escrow File.";

                #region Login 
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File and Verify Values
                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";

                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem());
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetAttribute("value"));
                Support.AreEqual(@"Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetAttribute("value"));
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetAttribute("value"));
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetAttribute("value"));
                Support.AreEqual(@"Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetAttribute("value"));
                Support.AreEqual(@"9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetAttribute("value"));
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetAttribute("value"));
                Support.AreEqual(@"CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem());
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetAttribute("value"));

                #endregion

                #region Create a Assumption Loan Instance
                Reports.TestStep = "Create a Assumption Loan Instance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Subject To");

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("101.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("10.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("100.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");
                FastDriver.AssumptionLoanDetails.MaturityDate.FASetText(MaturityDate);

                if (!FastDriver.AssumptionLoanDetails.LateCharge.Selected) {
                    FastDriver.AssumptionLoanDetails.LateCharge.FAClick();
                }

                if (!FastDriver.AssumptionLoanDetails.LateChargeopt1.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateChargeopt1.FAClick();
                }
                FastDriver.AssumptionLoanDetails.LateChargePercentage.FASetText("10.00");

                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText("30");
                if (!FastDriver.AssumptionLoanDetails.LateChargeopt2.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateChargeopt2.FAClick();
                }
                FastDriver.AssumptionLoanDetails.LateChargeAmount.FASetText("500.00");
                #endregion
                                
                #region Enter Charges in Charges Tab
                Reports.TestStep = "Enter Charges in Charges Tab.";

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("Unpaid Principal Balance", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCharge.FAGetValue().Trim());
                Support.AreEqual("101.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Trim());
                Support.AreEqual("101.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.InterestProrationInterestType.FASelectItem("Fixed Rate");
                FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText("5.000000");
                FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FASetText("06-10-2010");
                Support.AreEqual("365", FastDriver.AssumptionLoanCharges.InterestProrationBasedonDays.FAGetSelectedItem().Trim());
                                
                FastDriver.AssumptionLoanCharges.InterestProrationToDate.FASetText("07-10-2011");
                FastDriver.AssumptionLoanCharges.InterestProrationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("Assumption Loan Interest Proration", FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.FAGetValue().Trim());
                Support.AreEqual("1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FAGetValue().Trim());
                Support.AreEqual("1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FASetText("10.00");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("10.00");

                #endregion

                #region Enter Charges in PartiesTab

                Reports.TestStep = "Enter Charges in PartiesTab";
                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                Support.AreEqual("Lease 3 for HUD Testing Name 1, Lease 3 for HUD Testing Name 2", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue());
                Support.AreEqual("Lease 3 for HUD Testing Name 1, Lease 3 for HUD Testing Name 2", FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FAGetValue());

                FastDriver.AssumptionLoanParties.TrusteeBPGABcode.FASetText("TRUSTEE");
                FastDriver.AssumptionLoanParties.TrusteeFind.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                #endregion

                #region Enter Charges in RecordingTab

                Reports.TestStep = "Enter Charges in RecordingTab";
                FastDriver.AssumptionLoanParties.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                FastDriver.AssumptionLoanRecording.TrustDeedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanRecording.RecordingDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanRecording.Instrument.FASetText("Instrument");
                FastDriver.AssumptionLoanRecording.Book.FASetText("Book");
                FastDriver.AssumptionLoanRecording.Page.FASetText("Page");

                FastDriver.BottomFrame.Done();
                #endregion

                #region Validate instance for assumption loan
                Reports.TestStep = "Validate instance for assumption loan.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                Support.AreEqual("Subject To", FastDriver.AssumptionLoanDetails.DetailsLoanType.FAGetSelectedItem().Trim());
                Support.AreEqual("101.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Trim());
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanDetails.InterestPaidto.FAGetValue().Trim());
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanDetails.NextPaymentDue.FAGetValue().Trim());
                Support.AreEqual(true, FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FAGetValue().Contains("100.50"), "Verifying if amount entered was saved.");
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanDetails.NotedDate.FAGetValue().Trim());
                Support.AreEqual("10.00", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Trim());
                Support.AreEqual("100.00", FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue().Trim());
                Support.AreEqual("Interest only", FastDriver.AssumptionLoanDetails.PaymentType.FAGetSelectedItem().Trim());
                Support.AreEqual("Month", FastDriver.AssumptionLoanDetails.PaymentPer.FAGetSelectedItem().Trim());

                Support.AreEqual(MaturityDate, FastDriver.AssumptionLoanDetails.MaturityDate.FAGetValue().Trim());
                Support.AreEqual("30", FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FAGetValue().Trim());

                if (!FastDriver.AssumptionLoanDetails.LateChargeopt2.Selected) {
                    FastDriver.AssumptionLoanDetails.LateChargeopt2.FAClick();
                }

                Support.AreEqual("500.00", FastDriver.AssumptionLoanDetails.LateChargeAmount.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Support.AreEqual("Unpaid Principal Balance", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCharge.FAGetValue().Trim());
                Support.AreEqual("101.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Trim());
                Support.AreEqual("101.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.FAGetValue().Trim());

                Support.AreEqual("Fixed Rate", FastDriver.AssumptionLoanCharges.InterestProrationInterestType.FAGetSelectedItem().Trim());
                Support.AreEqual("5.000000", FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FAGetValue().Trim());
                Support.AreEqual("06-10-2010", FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FAGetValue().Trim());
                Support.AreEqual("365", FastDriver.AssumptionLoanCharges.InterestProrationBasedonDays.FAGetSelectedItem().Trim());
                Support.AreEqual("07-10-2011", FastDriver.AssumptionLoanCharges.InterestProrationToDate.FAGetValue().Trim());
                
                Support.AreEqual("Assumption Loan Interest Proration", FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.FAGetValue().Trim());
                Support.AreEqual("1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FAGetValue().Trim());
                Support.AreEqual("1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FAGetValue().Trim());

                Support.AreEqual("10.00", FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FAGetValue().Trim());
                Support.AreEqual("10.00", FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                Support.AreEqual("Lease 3 for HUD Testing Name 1, Lease 3 for HUD Testing Name 2", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue());
                Support.AreEqual("Lease 3 for HUD Testing Name 1, Lease 3 for HUD Testing Name 2", FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FAGetValue());

                FastDriver.AssumptionLoanParties.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanRecording.TrustDeedDate.FAGetValue().Trim());
                Support.AreEqual("06-04-2012", FastDriver.AssumptionLoanRecording.RecordingDate.FAGetValue().Trim());
                Support.AreEqual("Instrument", FastDriver.AssumptionLoanRecording.Instrument.FAGetValue().Trim());
                Support.AreEqual("Book", FastDriver.AssumptionLoanRecording.Book.FAGetValue().Trim());
                Support.AreEqual("Page", FastDriver.AssumptionLoanRecording.Page.FAGetValue().Trim());

                #endregion



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        
        #endregion

        #region REGRESSION

        [TestMethod]
        [Description("(Covers BRs 2113_2648_2650_2652_2653_2681_2711_2712_2682_2709_2690_2691_2692_2693_2696_2697_2698_FM2655)1:Required Data for Assum. Loan 2:Multiple Assumption Loans 3:Use Assumption Loan 1")]
        public void FMUC0046_REG0001()
        {
            try
            {
                Reports.TestDescription = "BusinessRuleSet1: (Covers BRs 2113_2648_2650_2652_2653_2681_2711_2712_2682_2709_2690_2691_2692_2693_2696_2697_2698_FM2655)1:Required Data for Assum. Loan 2:Multiple Assumption Loans 3:Use Assumption Loan 1";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File and Verify Values
                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";

                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem());
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetAttribute("value"));
                Support.AreEqual(@"Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetAttribute("value"));
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetAttribute("value"));
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetAttribute("value"));
                Support.AreEqual(@"Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetAttribute("value"));
                Support.AreEqual(@"9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetAttribute("value"));
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetAttribute("value"));
                Support.AreEqual(@"CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem());
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetAttribute("value"));

                #endregion

                #region Create Assumption Loan Instance with Business Party
                Reports.TestStep = "Create Assumption Loan Instance with Business Party.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "New us Shortcut Keys.";
                Keyboard.SendKeys("^N");

                Reports.TestStep = "Create a new Assumption Loan Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on New in Assumption Loan Summary Page and Create a new Assumption Loan Instance..
                Reports.TestStep = "Click on New in Assumption Loan Summary Page.";

                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                FastDriver.AssumptionLoanSummary.New.FAClick();

                Reports.TestStep = "Create a new Assumption Loan Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Verify instances creation on AssumptionLoanSummary
                Reports.TestStep = "verify for sequence No of 1st instance.";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanSummary.New.Displayed.ToString());
                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1",FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1,"1",2,TableAction.GetText).Message);

                Reports.TestStep = "verify for sequence No of 2nd instance.";
                Support.AreEqual("Lease 3 for HUD Testing Name 1", FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "2", 2, TableAction.GetText).Message);

                Reports.TestStep = "verify for sequence No of 1st instance.";
                Support.AreEqual("Lease 3 for HUD Testing Name 1", FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.GetText).Message);

                Reports.TestStep = "Delete Assumption loan Instance.";
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Remove.FAClick();
                Support.AreEqual("All information will be removed for this Assumption Loan.  Continue?",FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();

                Reports.TestStep = "Edit the Deleted Sequence.";
                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanSummary.New.Displayed.ToString());
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.Click);
                #endregion

                #region Create a new Assumption Loan Instance.
                FastDriver.AssumptionLoanSummary.Edit.FAClick();
                Reports.TestStep = "Create a new Assumption Loan Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");
                FastDriver.BottomFrame.Done();
                #endregion

                #region verify for sequence No of 3rd instance.
                Reports.TestStep = "verify for sequence No of 3rd instance.";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                Support.AreEqual("Lease 3 for HUD Testing Name 1", FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.GetText).Message);
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Remove.FAClick();
            
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Maintain Same Value for Unpaid Principal Balance Fields")]
        public void FMUC0046_REG0002()
        {
            try
            {
                Reports.TestDescription = "4184: Maintain Same Value for Unpaid Principal Balance Fields";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #endregion

                #region Create File
                _CreateFile();
                #endregion

                #region Enter charge for Refinance and verify for Borrower charges
                Reports.TestStep = "Enter charge for Refinance and verify for Borrower charges.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                              
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Support.AreEqual("", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCharge.FAGetValue());
                Support.AreEqual("300.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue());
                Support.AreEqual("300.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.FAGetValue());

                #endregion

               

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("(Covers Brs 2656_57_59_61_64_65_66_70_4184_1897_4185_2669_2700_01_02_03_04_05_06_2699_2707_08_ERR1_2_3_4_5_7_14)1:Display Entry Recap 2:Update Total Charges 3:Update Total POC 4:Update Check Amount 5:En")]
        public void FMUC0046_REG0003()
        {
            string MaturityDate = DateTime.Now.ToDateString();
            try
            {
                Reports.TestDescription = "BusinessRuleSet2: (Covers Brs 2656_57_59_61_64_65_66_70_4184_1897_4185_2669_2700_01_02_03_04_05_06_2699_2707_08_ERR1_2_3_4_5_7_14)1:Display Entry Recap 2:Update Total Charges 3:Update Total POC 4:Update Check Amount 5:En";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

              
                #endregion

                #region Create File
                Reports.TestStep = "Create a new file.";
                _CreateFile();
                #endregion

                #region Create a new Assumption Loan Instance charges and Parties information.
                Reports.TestStep = "Create a new Assumption Loan Instance charges and Parties information.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("248");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

               
                Reports.TestStep = "Enter Charges in Charges Tab.";

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FASetText("Changed Description");

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.SendKeys("500.00");

                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.Click();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.SendKeys("1000.00");

                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.Click();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.SendKeys("10.00");

                FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.SendKeys("10.00");

                FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.Click();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.SendKeys("100.00");

                FastDriver.BottomFrame.Done();
               
                #endregion

                #region Create a Second Assumption Loan Instance charges and Parties information.
                Reports.TestStep = "Create a Second Assumption Loan Instance charges and Parties information.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.AssumptionLoanDetails.MaturityDate.FASetText(MaturityDate);

                if (!FastDriver.AssumptionLoanDetails.LateCharge.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateCharge.FAClick();
                }

                if (!FastDriver.AssumptionLoanDetails.LateChargeopt1.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateChargeopt1.FAClick();
                }
                FastDriver.AssumptionLoanDetails.LateChargePercentage.FASetText("10.00");

                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText("30");
                if (!FastDriver.AssumptionLoanDetails.LateChargeopt2.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateChargeopt2.FAClick();
                }
                FastDriver.AssumptionLoanDetails.LateChargeAmount.FASetText("500.00");

                Reports.TestStep = "Enter Charges in Charges Tab.";

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("Unpaid Principal Balance", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCharge.FAGetValue().Trim());
                Support.AreEqual("300.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Trim());
                Support.AreEqual("300.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.InterestProrationInterestType.FASelectItem("Fixed Rate");
                FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText("5.000000");
                FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FASetText("06-10-2010");
                Support.AreEqual("365", FastDriver.AssumptionLoanCharges.InterestProrationBasedonDays.FAGetSelectedItem().Trim());

                FastDriver.AssumptionLoanCharges.InterestProrationToDate.FASetText("07-10-2011");
                FastDriver.AssumptionLoanCharges.InterestProrationToDate.SendKeys(FAKeys.Tab);

                Support.AreEqual("Interest Proration", FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.FAGetValue().Trim());
                Support.AreEqual("1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FAGetValue().Trim());
                Support.AreEqual("1,975.00", FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FASetText("10.00");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("10.00");

                Support.AreEqual("$ 300.00", FastDriver.AssumptionLoanCharges.UnPrincBalPane.Text.Trim());
                Support.AreEqual("$ 0.00", FastDriver.AssumptionLoanCharges.TotPocPane.Text.Trim());

                Reports.TestStep = "Enter Charges in PartiesTab";
                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrustMortgagor.Click();
                FastDriver.AssumptionLoanParties.TrustMortgagor.Clear();
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("Trust-Mortgagor");
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FASetText("Original s");
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FASetText("Assignee Beneficiary-Mortgagee");

                FastDriver.BottomFrame.Done();

                FastDriver.AssumptionLoanSummary.WaitForScreenToLoad();

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Lease 3 for HUD Testing Name 1", 2, TableAction.Click);

                FastDriver.AssumptionLoanSummary.Edit.FAClick();

                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.PartiesTab.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrustMortgagorRefresh.FAClick();
                FastDriver.AssumptionLoanParties.Beneficiary_MortgageeRefresh.FAClick();
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_MortgageeRefresh.FAClick();

                Support.AreEqual("SellerName SellerLastName", FastDriver.AssumptionLoanParties.TrustMortgagor.FAGetValue());
                Support.AreEqual("Lease 3 for HUD Testing Name 1, Lease 3 for HUD Testing Name 2", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue());
                Support.AreEqual("Lease 3 for HUD Testing Name 1, Lease 3 for HUD Testing Name 2", FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FAGetValue());

                FastDriver.AssumptionLoanParties.TrusteeBPGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanParties.TrusteeFind.FAClick();

                FastDriver.AssumptionLoanParties.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                FastDriver.AssumptionLoanRecording.TrustDeedDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.RecordingDate.FASetText("08-22-2012");
                FastDriver.AssumptionLoanRecording.Instrument.FASetText("Insrument");
                FastDriver.AssumptionLoanRecording.Book.FASetText("Book");
                FastDriver.AssumptionLoanRecording.Page.FASetText("page");

                FastDriver.BottomFrame.Done();


                #endregion

                #region Click on Find Button to enter business party through GAB
                Reports.TestStep = "Click on Find Button to enter business party through GAB.";
                FastDriver.AssumptionLoanSummary.WaitForScreenToLoad();

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Lease 3 for HUD Testing Name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();
                
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                
                Reports.TestStep = "Set an Homeowner Association id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "HOA1");

                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7,"HOA1",1,TableAction.On);

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                #endregion

                #region Modify the Instance with Unpaid Principal Balance.
                Reports.TestStep = "Modify the Instance with Unpaid Principal Balance.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanSummary>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanSummary.New.Displayed.ToString());

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Homeowner Assn name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();

                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();

                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.SendKeys("400.00" + FAKeys.Tab);
                
                #endregion
                
                #region Print All Checks.

                Reports.TestStep = "Print All Checks.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();


                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);


                Reports.TestStep = "Click on Done in ADS screen.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Assumption Loan Screen and Delete The Payee have Issued Instance

                Reports.TestStep = "Navigate to Assumption Loan Screen.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanSummary>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanSummary.New.Displayed.ToString());

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Homeowner Assn name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();

                Reports.TestStep = "Delete The Payee have Issued Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());
                
                #endregion

                #region Validate Issued cannot be deleted, description cannot be changed while having charge amount and validate less and more charge amount change
                Reports.TestStep = "Click on Find Button to enter business party through GAB.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanSummary>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Homeowner Assn name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Support.AreEqual("A check has been issued for this Payee.  The Payee name cannot be changed.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Delete charge description for entered Charges.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanSummary>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Homeowner Assn name 1", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.SendKeys(FAKeys.Tab);
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();


                Reports.TestStep = "Enter Charge less than issued Amount.";
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.Click();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.SendKeys("5.00" + FAKeys.Tab);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?",  FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Enter Charge More than issued Amount.";
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.SendKeys("15.00" + FAKeys.Tab);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?",  FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                #endregion

                #region Void the First Instance of Loa
                Reports.TestStep = "Void the First Instance of Loan";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Midwest Financial Group", 8, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Void.FAClick();
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Void Reason");
                FastDriver.VoidDlg.ClickOk();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                Reports.TestStep = "Remove the First Instance of Loan";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanSummary>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();

                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "2", 1, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Remove.FAClick();
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("1:User searches for a business party on ID Code and system does not find an exact match 2:User changes Interest Rate, Per Diem, From Date, To Date, Credit Seller, Inclusive, and/or Based On Days. 3")]
        public void FMUC0046_REG0004()
        {
            string MaturityDate = DateTime.Now.ToDateString();
            try
            {
                Reports.TestDescription = "ERR_6_12_13_15_16_17: 1:User searches for a business party on ID Code and system does not find an exact match 2:User changes Interest Rate, Per Diem, From Date, To Date, Credit Seller, Inclusive, and/or Based On Days. 3:";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File and Verify Values
                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Verify fields in Filehomepage for full sanity.";

                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(@"Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem());
                Support.AreEqual(@"5,000.00", FastDriver.FileHomepage.TermsDatesPrice.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyName.FAGetAttribute("value"));
                Support.AreEqual(@"Single Family Residence", FastDriver.FileHomepage.PropertyType.FAGetSelectedItem());
                Support.AreEqual(@"Lot1", FastDriver.FileHomepage.PropertyLotName.FAGetAttribute("value"));
                Support.AreEqual(@"Block1", FastDriver.FileHomepage.PropertyBlock.FAGetAttribute("value"));
                Support.AreEqual(@"Unit1", FastDriver.FileHomepage.PropertyUnit.FAGetAttribute("value"));
                Support.AreEqual(@"Prop1APN1", FastDriver.FileHomepage.PropertyPropTaxAPN1.FAGetAttribute("value"));
                Support.AreEqual(@"9845012345", FastDriver.FileHomepage.PropertyPropTaxAPN2.FAGetAttribute("value"));
                Support.AreEqual(@"J305", FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetAttribute("value"));
                Support.AreEqual(@"JJEJAMQ", FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetAttribute("value"));
                Support.AreEqual(@"ALBANY", FastDriver.FileHomepage.PropertyAddressBookCity.FAGetAttribute("value"));
                Support.AreEqual(@"CA", FastDriver.FileHomepage.PropertyState.FAGetSelectedItem());
                Support.AreEqual(@"ALAMEDA", FastDriver.FileHomepage.PropertyCounty.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer1Firstname", FastDriver.FileHomepage.Buyer1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer1Lastname", FastDriver.FileHomepage.Buyer1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Buyer2Type.FAGetSelectedItem());
                Support.AreEqual(@"Buyer2Firstname", FastDriver.FileHomepage.Buyer2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2SpouseName", FastDriver.FileHomepage.Buyer2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Buyer2Lastname", FastDriver.FileHomepage.Buyer2SpouseLastName.FAGetAttribute("value"));
                Support.AreEqual(@"Individual", FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller1Firstname", FastDriver.FileHomepage.Seller1FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller1Lastname", FastDriver.FileHomepage.Seller1LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Husband/Wife", FastDriver.FileHomepage.Seller2Type.FAGetSelectedItem());
                Support.AreEqual(@"Seller2Firstname", FastDriver.FileHomepage.Seller2FirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2LastName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2SpouseName", FastDriver.FileHomepage.Seller2SpouseFirstName.FAGetAttribute("value"));
                Support.AreEqual(@"Seller2Lastname", FastDriver.FileHomepage.Seller2SpouseLastName.FAGetAttribute("value"));

                #endregion

                #region ID Code Not Found.
                Reports.TestStep = "ID Code Not Found.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("XCHZ");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Support.AreEqual("ID Code not found.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();


                Reports.TestStep = "Enter Charges in Charges Tab.";

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FASetText("Changed Description");

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.SendKeys("500.00");

                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.Click();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.SendKeys("1000.00");

                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.Click();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.SendKeys("10.00");

                FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.Click();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.SendKeys("10.00");

                FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.Click();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.SendKeys("100.00");
                
                #endregion

                #region Save Changes without Bus Party
                Reports.TestStep = "Save Changes without Bus Party.";

                FastDriver.BottomFrame.Done();
                Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Create a new Assumption Loan Instance with all details
                Reports.TestStep = "Create a new Assumption Loan Instance with all details.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                             
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsReference.FASetText("93886444");
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.AssumptionLoanDetails.MaturityDate.FASetText(MaturityDate);

                if (!FastDriver.AssumptionLoanDetails.LateCharge.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateCharge.FAClick();
                }

                if (!FastDriver.AssumptionLoanDetails.LateChargeopt1.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateChargeopt1.FAClick();
                }
                FastDriver.AssumptionLoanDetails.LateChargePercentage.FASetText("10.00");

                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText("30");
                if (!FastDriver.AssumptionLoanDetails.LateChargeopt2.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateChargeopt2.FAClick();
                }
                FastDriver.AssumptionLoanDetails.LateChargeAmount.FASetText("500.00");
                FastDriver.BottomFrame.Done();
                
                #endregion 
                
                #region Click on Find Button to enter business party through GAB
                Reports.TestStep = "Click on Find Button to enter business party through GAB.";
                
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();

                Reports.TestStep = "Set an Homeowner Association id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.IDCode);
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "HOA1");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "HOA1", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Change Business Party have Ref No.";
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                #endregion

                #region Change Prorate Dates and Diem and Verify Dialog Messages
                Reports.TestStep = "Change Prorate Per Diem.";
                
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText("7.000000");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Validate when description is removed.";
                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Enter the proration details and save";

                FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FASetText("09-17-2010");
                FastDriver.AssumptionLoanCharges.InterestProrationToDate.FASetText("07-10-2011");
                FastDriver.BottomFrame.Done();
              
                Reports.TestStep = "Change Prorate From Date.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.InterestProrationFromDate.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationFromDate.SendKeys("09-20-2010"+FAKeys.Tab);
                
                Reports.TestStep = "Formula changed calculate Proration.";
                Support.AreEqual("Interest calculation formula values have changed. \r\nDo you wish to recalculate interest charges?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Change Prorate Based On.";
                FastDriver.AssumptionLoanCharges.InterestProrationBasedonDays.FASelectItemBySendingKeys("366");
                Support.AreEqual("Interest calculation formula values have changed. \r\nDo you wish to recalculate interest charges?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                
                Reports.TestStep = "Change Prorate To date.";
                FastDriver.AssumptionLoanCharges.InterestProrationToDate.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationToDate.SendKeys("07-10-2012" + FAKeys.Tab);
                Support.AreEqual("Interest calculation formula values have changed. \r\nDo you wish to recalculate interest charges?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                //If using FASetCheckbox the dialog shows up and the method still doing some tasks in background and fails due to modal dialog present
                if (!FastDriver.AssumptionLoanCharges.InterestProrationCreditSeller.Selected)
                {
                    FastDriver.AssumptionLoanCharges.InterestProrationCreditSeller.Click();
                }
                else 
                {
                    FastDriver.AssumptionLoanCharges.InterestProrationCreditSeller.Click();
                    FastDriver.AssumptionLoanCharges.InterestProrationCreditSeller.Click();
                }
                Support.AreEqual("Interest calculation formula values have changed. \r\nDo you wish to recalculate interest charges?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "Check Edit Name Check Box.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsEditName.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Name field is required when Edit Name checkbox is selected.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsEditName.FASetCheckbox(false);

                Reports.TestStep = "Check Email Check Box.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsEdit.FASetCheckbox(true);
                FastDriver.AssumptionLoanDetails.DetailsEmailAddress.FASetText("testmail");
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Please correct invalid data entered.", FastDriver.WebDriver.HandleDialogMessage());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("1:User cancels entry of the FIRST new instance using Cancel button on framework before saving a new process instance. 2:User cancels entry of the SECOND new instance using Cancel button on framework before")]
        public void FMUC0046_REG0005()
        {
            string MaturityDate = DateTime.Now.ToDateString();
            try
            {
                Reports.TestDescription = "ERR_8_9_10_11: 1:User cancels entry of the FIRST new instance using Cancel button on framework before saving a new process instance. 2:User cancels entry of the SECOND new instance using Cancel button on framework before";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                #endregion

                #region Create File
                Reports.TestStep = "Create a new file.";
                _CreateFile();
                #endregion
                            
                #region Create a new Assumption Loan Instance with all details
                Reports.TestStep = "Create a new Assumption Loan Instance with all details.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.FindGABCode("HUDLEASE03");
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsReference.FASetText("93886444");
                FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00");
                FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("100.50");
                FastDriver.AssumptionLoanDetails.NotedDate.FASetText("06-04-2012");
                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("500.00");
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("200.00");
                FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Interest only");
                FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");

                FastDriver.AssumptionLoanDetails.MaturityDate.FASetText(MaturityDate);

                if (!FastDriver.AssumptionLoanDetails.LateCharge.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateCharge.FAClick();
                }

                if (!FastDriver.AssumptionLoanDetails.LateChargeopt1.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateChargeopt1.FAClick();
                }
                FastDriver.AssumptionLoanDetails.LateChargePercentage.FASetText("10.00");

                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText("30");
                if (!FastDriver.AssumptionLoanDetails.LateChargeopt2.Selected)
                {
                    FastDriver.AssumptionLoanDetails.LateChargeopt2.FAClick();
                }
                FastDriver.AssumptionLoanDetails.LateChargeAmount.FASetText("500.00");
                FastDriver.BottomFrame.Done();

                #endregion

                #region Cancel The First Instance
                Reports.TestStep = "Navigate to Assumption Loan Screen.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.BottomFrame.Reset();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                Reports.TestStep = "New us Shortcut Keys.";
                FastDriver.BottomFrame.New();

                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Create the second instance

                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                Reports.TestStep = "New us Shortcut Keys.";
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();


                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR2");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.BottomFrame.Done();

                #endregion

                #region Test keyboard shortcuts
                Reports.TestStep = "Enter short cut to create new instance.";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                Keyboard.SendKeys("%N");

                Reports.TestStep = "Cancel us Shortcut Keys.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());
                
                Reports.TestStep = "Enter short cut to create new instance.";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                Keyboard.SendKeys("%N");

                Reports.TestStep = "Create the second Instance.";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR2");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit the Instance us Short Cut.";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();

                Support.AreEqual("Assumption Lender 2 for HUD Test Name 1", FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.GetText).Message.Trim());
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.Click);
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                Keyboard.SendKeys("%E");

                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Remove the Instance us Short Cut.";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "3", 2, TableAction.Click);
                Keyboard.SendKeys("%R");

                Support.AreEqual("All information will be removed for this Assumption Loan.  Continue?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Field Definitions")]
        public void FMUC0046_REG0006()
        {
            string MaturityDate = DateTime.Now.ToDateString();
            try
            {
                Reports.TestDescription = "FD: Field Definitions";
                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                #endregion

                #region Create File
                Reports.TestStep = "Create a new file.";
                _CreateFile();
                #endregion

                #region Verify the Field with lower Boundary Value for details tab.
                Reports.TestStep = "Verify the Field with lower Boundary Value for details tab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.SendKeys("HUDFLINSR" + FAKeys.Tab);
                Support.AreEqual("HUDFLINSR",  FastDriver.AssumptionLoanDetails.DetailsGABcode.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsName.SendKeys("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789", FastDriver.AssumptionLoanDetails.DetailsName.FAGetValue().Trim());
                
                FastDriver.AssumptionLoanDetails.DetailsEdit.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.DetailsBusPhone.SendKeys("123456789" + FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.AssumptionLoanDetails.DetailsBusPhone.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsBusFax.SendKeys("123456789" + FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.AssumptionLoanDetails.DetailsBusFax.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsCellPhone.SendKeys("123456789" + FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.AssumptionLoanDetails.DetailsCellPhone.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsPager.SendKeys("123456789" + FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.AssumptionLoanDetails.DetailsPager.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsEmailAddress.SendKeys("123456789" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanDetails.DetailsEmailAddress.FAGetValue().Trim());

                

                FastDriver.BottomFrame.Cancel();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();

                #endregion
                
                #region Verify the Field with lower Boundary Value for details tab
                Reports.TestStep = "Verify the Field with lower Boundary Value for details tab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
            
                FastDriver.AssumptionLoanDetails.DetailsEditName.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.DetailsNameEdit.SendKeys("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456", FastDriver.AssumptionLoanDetails.DetailsNameEdit.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsReference.SendKeys("0123456789012345678901234567890123456789012345678" + FAKeys.Tab);
                Support.AreEqual("0123456789012345678901234567890123456789012345678", FastDriver.AssumptionLoanDetails.DetailsReference.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FAGetValue().Trim(), "Verifying lower boundry for field.");

                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Trim());
                               
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("99999999999.99");
                FastDriver.AssumptionLoanDetails.PaymentAmount.SendKeys(FAKeys.Tab);
                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("99999999999.99");
                FastDriver.AssumptionLoanDetails.PaymentAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue().Trim());

                Support.AreEqual("Assumption Subject To", FastDriver.AssumptionLoanDetails.DetailsLoanType.Text.Trim());
                Support.AreEqual("Day Month Quarter Semi-Annual Trimester Week Year", FastDriver.AssumptionLoanDetails.PaymentPer.Text.Trim());

                FastDriver.AssumptionLoanDetails.LateCharge.FASetCheckbox(true);
                FastDriver.AssumptionLoanDetails.LateChargeopt1.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.LateChargePercentage.FASetText("9999.0000" + FAKeys.Tab);
                Support.AreEqual("9999.0000", FastDriver.AssumptionLoanDetails.LateChargePercentage.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText("999");
                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.SendKeys(FAKeys.Tab);
                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText("999");
                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.SendKeys(FAKeys.Tab);
                Support.AreEqual("999", FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.LateChargeopt2.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.LateChargeAmount.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanDetails.LateChargeAmount.FAGetValue().Trim());

                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

                #region Verify the Field with Exact Value for details tab
                Reports.TestStep = "Verify the Field with Exact Value for details tab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.SendKeys("HUDFLINSR1" + FAKeys.Tab);
                Support.AreEqual("HUDFLINSR1", FastDriver.AssumptionLoanDetails.DetailsGABcode.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsName.SendKeys("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.AssumptionLoanDetails.DetailsName.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsEdit.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.DetailsBusPhone.SendKeys("1234567899" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.AssumptionLoanDetails.DetailsBusPhone.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsBusFax.SendKeys("1234567899" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.AssumptionLoanDetails.DetailsBusFax.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsCellPhone.SendKeys("1234567899" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.AssumptionLoanDetails.DetailsCellPhone.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsPager.SendKeys("1234567899" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.AssumptionLoanDetails.DetailsPager.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsEmailAddress.SendKeys("test@test.com" + FAKeys.Tab);
                Support.AreEqual("test@test.com", FastDriver.AssumptionLoanDetails.DetailsEmailAddress.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsEditName.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.DetailsNameEdit.SendKeys("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.AssumptionLoanDetails.DetailsNameEdit.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsReference.SendKeys("01234567890123456789012345678901234567890123456789" + FAKeys.Tab);
                Support.AreEqual("01234567890123456789012345678901234567890123456789", FastDriver.AssumptionLoanDetails.DetailsReference.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("12345678912.34" + FAKeys.Tab);
                Support.AreEqual("12,345,678,912.34", FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FAGetValue().Trim(), "Verifying upper boundry for field.");

                FastDriver.AssumptionLoanDetails.LateCharge.FASetCheckbox(true);
                FastDriver.AssumptionLoanDetails.LateChargeopt1.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.LateChargePercentage.FASetText("10000.0000" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanDetails.LateChargePercentage.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText("1000");
                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.SendKeys(FAKeys.Tab);
                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText("1000");
                FastDriver.AssumptionLoanDetails.LateChargeAfterDays.SendKeys(FAKeys.Tab);
                Support.AreEqual("100", FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.LateChargeopt2.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.LateChargeAmount.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanDetails.LateChargeAmount.FAGetValue().Trim());

                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                
                #endregion

                #region Verify the Field with Upper Boundary Value for details tab
                Reports.TestStep = "Verify the Field with Upper Boundary Value for details tab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.SendKeys("HUDFLINSR12" + FAKeys.Tab);
                Support.AreEqual("HUDFLINSR1", FastDriver.AssumptionLoanDetails.DetailsGABcode.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsName.SendKeys("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ12345678901" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.AssumptionLoanDetails.DetailsName.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsEdit.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.DetailsBusPhone.SendKeys("12345678999" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.AssumptionLoanDetails.DetailsBusPhone.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsBusFax.SendKeys("12345678999" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.AssumptionLoanDetails.DetailsBusFax.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsCellPhone.SendKeys("12345678999" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.AssumptionLoanDetails.DetailsCellPhone.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsPager.SendKeys("12345678999" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.AssumptionLoanDetails.DetailsPager.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsEmailAddress.SendKeys("test@test.com" + FAKeys.Tab);
                Support.AreEqual("test@test.com", FastDriver.AssumptionLoanDetails.DetailsEmailAddress.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsEditName.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.DetailsNameEdit.SendKeys("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.AssumptionLoanDetails.DetailsNameEdit.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.DetailsReference.SendKeys("01234567890123456789012345678901234567890123456789" + FAKeys.Tab);
                Support.AreEqual("01234567890123456789012345678901234567890123456789", FastDriver.AssumptionLoanDetails.DetailsReference.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("10000000000000000" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FASetText("10000000000000000" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanDetails.LenderPolicyLiability.FAGetValue().Trim(), "Verifying upper boundry for field.");

                FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("10000000000000000" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("10000000000000000");
                FastDriver.AssumptionLoanDetails.PaymentAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue().Trim());

                FastDriver.AssumptionLoanDetails.LateCharge.FASetCheckbox(true);
                FastDriver.AssumptionLoanDetails.LateChargeopt1.FASetCheckbox(true);

                FastDriver.AssumptionLoanDetails.LateChargePercentage.FASetText("10000000000000000" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanDetails.LateChargePercentage.FAGetValue().Trim());

                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();

                #endregion

                #region Verify the Field with lower Boundary Value for charges tab
                Reports.TestStep = "Verify the Field with lower Boundary Value for charges tab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.SendKeys("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FAGetValue().Trim());
                               
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FASetText("99999999999.99" + FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Trim());

                //SellerCredit not editable
                //FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.SendKeys(FAKeys.Tab);
                //FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.FASetText("99999999999.99" + FAKeys.Tab);
                //Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCredit.FAGetValue().Trim());

                Support.AreEqual("Adjustable Interest Rate Best Prevailing Fixed Rate Interest in Addition Interest Included Variable Interest Rate", FastDriver.AssumptionLoanCharges.InterestProrationInterestType.Text.Trim());

                FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText("99,999,999,999.99" + FAKeys.Tab);

                Support.AreEqual("99,999,999,999.990000", FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FAGetValue().Trim());

                Support.AreEqual("360 365 366", FastDriver.AssumptionLoanCharges.InterestProrationBasedonDays.Text.Trim());

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.SendKeys("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FASetText("99999999999.99" + FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCredit0.FASetText("99999999999.99" + FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCredit0.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCredit0.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("99999999999.99" + FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FAGetValue().Trim());
                
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCredit1.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCredit1.FASetText("99999999999.99" + FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCredit1.FASetText("99999999999.99" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCredit1.FAGetValue().Trim());
                
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                
                #endregion

                #region verify the Field with Exact Value for charges tab
                Reports.TestStep = "Verify the Field with Exact Value for charges tab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.SendKeys("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.SendKeys("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.SendKeys("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.FAGetValue().Trim());
                                                
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

                #region Verify the Field with Upper Boundary Value for charges tab
                Reports.TestStep = "Verify the Field with Upper Boundary Value for charges tab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.SendKeys("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FASetText("10000000000000000" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FASetText("10000000000000000" + FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FASetText("10000000000000000" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Trim());

                //SellerCredit and BuyerCharge are not editable

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.SendKeys("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCredit0.FASetText("10000000000000000" + FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCredit0.FASetText("10000000000000000" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCredit0.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("10000000000000000" + FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("10000000000000000" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FAGetValue().Trim());

                //SellerCredit and BuyerCharge are not editable
                                
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                #endregion

                #region Verify the Field with lower Boundary Value for PartiesTab
                Reports.TestStep = "Verify the Field with lower Boundary Value for PartiesTab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.PartiesTab.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrustMortgagor.Clear();
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG1" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("2354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354AS" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("DFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG123" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("54ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDF" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("G12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG1" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("2354ASDFG12354ASDFG12354ASDFG12354ASDFG1235" + FAKeys.Tab);
                Support.AreEqual("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG1235", FastDriver.AssumptionLoanParties.TrustMortgagor.FAGetValue().Trim());


                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.Clear();
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG1" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("2354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354AS" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("DFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG123" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("54ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDF" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("G12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG1" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("2354ASDFG12354ASDFG12354ASDFG12354ASDFG1235" + FAKeys.Tab);
                Support.AreEqual("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG1235", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue().Trim());

                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.Clear();
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG1" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("2354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354AS" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("DFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG123" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("54ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDF" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("G12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG1" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("2354ASDFG12354ASDFG12354ASDFG12354ASDFG1235" + FAKeys.Tab);
                Support.AreEqual("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG1235", FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FAGetValue().Trim());
                
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify the Field with Exact Boundary Value for PartiesTab
                Reports.TestStep = "Verify the Field with Exact Boundary Value for PartiesTab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.PartiesTab.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrustMortgagor.Clear();
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab); Support.AreEqual("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354", FastDriver.AssumptionLoanParties.TrustMortgagor.FAGetValue().Trim());

                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.Clear();
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab); Support.AreEqual("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue().Trim());

                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.Clear();
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab); Support.AreEqual("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354", FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FAGetValue().Trim());
                
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify the Field with Upper Boundary Value for PartiesTab
                Reports.TestStep = "Verify the Field with Upper Boundary Value for PartiesTab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.PartiesTab.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.TrustMortgagor.Clear();
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.TrustMortgagor.SendKeys("12354ASDFG12354ASDFG123545" + FAKeys.Tab);
                Support.AreEqual("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354", FastDriver.AssumptionLoanParties.TrustMortgagor.FAGetValue().Trim());

                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.Clear();
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG123545" + FAKeys.Tab);
                Support.AreEqual("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue().Trim());

                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.Clear();
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG" + FAKeys.Tab);
                FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.SendKeys("12354ASDFG12354ASDFG123545" + FAKeys.Tab);
                Support.AreEqual("ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354ASDFG12354", FastDriver.AssumptionLoanParties.AssigneeBeneficiary_Mortgagee.FAGetValue().Trim());
                
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify the Field with lower Boundary Value for Recording tab
                Reports.TestStep = "Verify the Field with lower Boundary Value for Recording tab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                FastDriver.AssumptionLoanRecording.Instrument.Clear();
                FastDriver.AssumptionLoanRecording.Instrument.SendKeys("ASDFG12345ASDFG12345ASDFG12345ASDFG12345ASDFG1234" + FAKeys.Tab);
                Support.AreEqual("ASDFG12345ASDFG12345ASDFG12345ASDFG12345ASDFG1234", FastDriver.AssumptionLoanRecording.Instrument.FAGetValue().Trim());

                FastDriver.AssumptionLoanRecording.Book.Clear();
                FastDriver.AssumptionLoanRecording.Book.FASetText("ASDFG12345ASDFG1234" + FAKeys.Tab);
                Support.AreEqual("ASDFG12345ASDFG1234", FastDriver.AssumptionLoanRecording.Book.FAGetValue().Trim());

                FastDriver.AssumptionLoanRecording.Page.Clear();
                FastDriver.AssumptionLoanRecording.Page.FASetText("ASDFG1234" + FAKeys.Tab);
                Support.AreEqual("ASDFG1234", FastDriver.AssumptionLoanRecording.Page.FAGetValue().Trim());
                
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Verify the Field with Exact Boundary Value for Recording tab
                Reports.TestStep = "Verify the Field with Exact Boundary Value for Recording tab.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.RecordingTab.FAClick();
                FastDriver.AssumptionLoanRecording.WaitForScreeToLoan();

                FastDriver.AssumptionLoanRecording.Instrument.Clear();
                FastDriver.AssumptionLoanRecording.Instrument.SendKeys("ASDFG12345ASDFG12345ASDFG12345ASDFG12345ASDFG12345" + FAKeys.Tab);
                Support.AreEqual("ASDFG12345ASDFG12345ASDFG12345ASDFG12345ASDFG12345", FastDriver.AssumptionLoanRecording.Instrument.FAGetValue().Trim());

                FastDriver.AssumptionLoanRecording.Book.Clear();
                FastDriver.AssumptionLoanRecording.Book.FASetText("ASDFG12345ASDFG12345" + FAKeys.Tab);
                Support.AreEqual("ASDFG12345ASDFG12345", FastDriver.AssumptionLoanRecording.Book.FAGetValue().Trim());

                FastDriver.AssumptionLoanRecording.Page.Clear();
                FastDriver.AssumptionLoanRecording.Page.FASetText("ASDFG12345" + FAKeys.Tab);
                Support.AreEqual("ASDFG12345", FastDriver.AssumptionLoanRecording.Page.FAGetValue().Trim());

                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnCancel.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("These 2 Br's are removed")]
        public void FMUC0046_REG0007_PH()
        {
            try
            {
                Reports.TestDescription = "2649_2651_EWC16_3524_3525_3526: These 2 Br's are removed";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("1:User cancels entry of the FIRST new instance using Cancel button on framework before saving a new process instance. 2:User cancels entry of the SECOND new instance using Cancel button on framework before")]
        public void FMUC0046_REG0008()
        {
            try
            {
                Reports.TestDescription = "2657_2659_2661_2113_2666 Updae Total Charges_Update Total POC_Update Check Amount";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                
                #endregion

                #region Create File
                Reports.TestStep = "Create a new file.";
                _CreateFile();
                #endregion

                #region Verify the Error message, Click on Done Button With out entering BUS number
                Reports.TestStep = "Verify the Error message, Click on Done Button With out entering BUS number";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FASetText("Changed Description");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanCharges.ErrorMessageList.Text.Trim().Contains("Business Party required").ToString());

                FastDriver.AssumptionLoanCharges.DetailsTab.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("HUDASLNDR1");

                #endregion

                #region Verify the Total Charges
                Reports.TestStep = "Enter Charges in Charges Tab.";
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription.FASetText("Changed Description");

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FASetText("500.00");

                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FASetText("1000.00");

                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FASetText("10.00");

                FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FASetText("10.00");

                FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.Clear();
                FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.FASetText("100.00");
                FastDriver.AssumptionLoanCharges.InterestProrationPaymentDetails.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify the Total Charges";
                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanCharges.TotChgPane.Text.Contains("900").ToString());

                Reports.TestStep = "Verify the Total POC after changing the Payment Methos to POC";
                FastDriver.AssumptionLoanCharges.InterestProrationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Change the payment details methods to POC.";

                if (_GetCurrentFileFormType() == FormType.CD) { 
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("990.00");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanCharges.TotPocPane.Text.Contains("990").ToString());

                Reports.TestStep = "Verify the Check Amount";
                FastDriver.AssumptionLoanCharges.InterestProrationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Change the payment details methods to POC.";

              
                if (_GetCurrentFileFormType() == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("90.00");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                }
                else {
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("CHK");

                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanCharges.TotPocPane.Text.Contains("90").ToString());

                #endregion

                Reports.TestStep = "Verify the user able to select an Other Entitty Type";
                FastDriver.AssumptionLoanCharges.DetailsTab.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Reports.TestStep = "Select an other Entity Type and search.";

                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.EntityType);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Mortgage Broker");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "AD193335", 1, TableAction.On);

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("4184_1897_2701_2702_2703_2705_2706")]
        public void FMUC0046_REG0009()
        {
            try
            {
                Reports.TestDescription = "4184_1897_2701_2702_2703_2705_2706";

                #region Login
                Reports.TestStep = "Login FAST application.";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }
                #endregion

                #region Create File and Verify Values
                FastDriver.QuickFileEntry.CreateStandardFile();
                #endregion

                #region Verify the Amount in the Borrower Credit field
                Reports.TestStep = "Verify the Amount in the Borrower Credit field when the User entres the Amount in the Loan Details Unpaid Principlae balance for the Transaction Type Refinance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDASLNDR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("300.00" + FAKeys.Tab);

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("300.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify the Amount in the  Loan Details Unpaid Principlae balance field when the User entres the Amount in the Loan Charge Borrower Credit field for the Transaction Type Refinance";

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.SendKeys("400.00" + FAKeys.Tab);

                FastDriver.AssumptionLoanCharges.DetailsTab.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                Support.AreEqual("400.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Trim());

                #endregion

                #region Verify the Amount in the Buyer  Credit and Seller Charge fields when the User entres the Amount in the Loan Details Unpaid Principlae balance for the Transaction Type Non Refinance
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").SwitchToContentFrame();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Sale w/Mortgage");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the Amount in the Buyer  Credit and Seller Charge fields when the User entres the Amount in the Loan Details Unpaid Principlae balance for the Transaction Type Non Refinance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("600.00" + FAKeys.Tab);

                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("600.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Trim());
                Support.AreEqual("600.00", FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Trim());

                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.Click();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.Clear();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.SendKeys("800.00" + FAKeys.Tab);

                FastDriver.AssumptionLoanCharges.DetailsTab.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                Support.AreEqual("800.00", FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue().Trim());
                #endregion

                #region Verify the Calculated Charge amount to the Buyer Credit and Seller Charge fileds if the user not check the Credit  Seller Checkbox
                Reports.TestStep = "Verify the Calculated Charge amount to the Buyer Credit and Seller Charge fileds if the user not check the Credit  Seller Checkbox";
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();


                FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText("10");
                FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FASetText("06-19-2013");
                FastDriver.AssumptionLoanCharges.InterestProrationToDate.FASetText("06-19-2014" + FAKeys.Tab);

                Support.AreEqual("", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FAGetValue().Trim());
                Support.AreEqual("3,650.00", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FAGetValue().Trim());
                Support.AreEqual("3,650.00", FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.FAGetValue().Trim());
                #endregion

                #region Verify the Calculated Charge amount to the Buyer Charge and Seller Credit fileds if the user  checked the Credit Seller Checkbox
                Reports.TestStep = "Verify the Calculated Charge amount to the Buyer Charge and Seller Credit fileds if the user  checked the Credit Seller Checkbox";

                if (!FastDriver.AssumptionLoanCharges.InterestProrationCreditSeller.Selected) {
                    FastDriver.AssumptionLoanCharges.InterestProrationCreditSeller.Click();
                }
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Support.AreEqual("", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FAGetValue().Trim());
                Support.AreEqual("3,650.00", FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FAGetValue().Trim());
                Support.AreEqual("3,650.00", FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.FAGetValue().Trim());
                Support.AreEqual("", FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FAGetValue().Trim());
                #endregion

                Reports.TestStep = "Validate the Seller Information -Names and Relationship values";
                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                Support.AreEqual("Seller1Firstname Seller1Lastname and Seller2Firstname Seller2Lastname and Seller2SpouseName Seller2Lastname", FastDriver.AssumptionLoanParties.TrustMortgagor.FAGetValue());
                
                Reports.TestStep = "Edit Trustor-Mortgagor";
                FastDriver.AssumptionLoanParties.TrustMortgagor.Clear();
                FastDriver.AssumptionLoanParties.TrustMortgagor.FASetText("Test_June");

                Reports.TestStep = "Verify the Seller Information Automatically updated after refresh";
                FastDriver.AssumptionLoanParties.TrustMortgagorRefresh.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();
                Support.AreEqual("Seller1Firstname Seller1Lastname and Seller2Firstname Seller2Lastname and Seller2SpouseName Seller2Lastname", FastDriver.AssumptionLoanParties.TrustMortgagor.FAGetValue());

                Reports.TestStep = "Edit Beneficiary Mortgage and verify and verify the Lender name is effected";
                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1, Assumption Lender 1 for HUD Test Name 2", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue());

                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.Clear();
                FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FASetText("Test_June_Lender");

                FastDriver.AssumptionLoanParties.DetailsTab.FAClick();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();

                Support.AreEqual(false.ToString(), (FastDriver.AssumptionLoanDetails.GABcodeName.Text + FastDriver.AssumptionLoanDetails.GABcodeName1.Text).Contains("Test_June_Lender").ToString());
                
                FastDriver.AssumptionLoanCharges.PartiesTab.FAClick();
                FastDriver.AssumptionLoanParties.WaitForScreeToLoan();

                FastDriver.AssumptionLoanParties.Beneficiary_MortgageeRefresh.FAClick();
                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1, Assumption Lender 1 for HUD Test Name 2", FastDriver.AssumptionLoanParties.Beneficiary_Mortgagee.FAGetValue());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion
        
        #region PRIVATE METHODS

        private FormType _CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = _GetCurrentFileFormType();
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.LiabilityAmount = 5000;

            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            #region CreateNewLoan
            var newLoan = new NewLoanParameters()
            {
                Type = "",
                Amount = "",
                GABCode = "247"
            };
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.FillNewLoanForm(newLoan);
            FastDriver.NewLoan.ClickRecapTab();
            FastDriver.NewLoan.WaitForRecapToLoad();
            #endregion

            return customizableFileRequest.formType;
        }

        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private FormType _GetCurrentFileFormType()
        {
            return AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    }
}
