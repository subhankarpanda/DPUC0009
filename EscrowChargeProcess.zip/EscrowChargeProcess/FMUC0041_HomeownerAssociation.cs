﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpers;


namespace EscrowChargeProcess
{
      /// <summary>
    /// Summary description for FMUC0041_HomeownerAssociation
    /// </summary>
    [CodedUITest]
    public class FMUC0041_HomeownerAssociation : MasterTestClass
    {

        public FMUC0041_HomeownerAssociation() { }

        #region BAT

        [TestMethod]
        [Description("Cancel 1st New Homeowner Association Instance Creation.")]
        public void FMUC0041_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_01: Adding Homeowner Association Instance.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Cancel a newly created homeowner instance.
                
                Reports.TestStep = "Cancel a newly created homeowner instance.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();
             
                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");

                
                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable,"Transfer Fee","3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable,"Transfer Fee","3.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Cancel();

                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

                #region  Verify the fields are  blank after Cancelling the 1st instance.

                Reports.TestStep = "Verify the fields are  blank after Cancelling the 1st instance.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                
                Support.AreEqual("",GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("",GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));


                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Adding Homeowner Association Instance.")]
        public void FMUC0041_BAT0002()
        {
            try
            {

                Reports.TestDescription = "MF1_01: Adding Homeowner Association Instance.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");

              
                FastDriver.BottomFrame.Done();

                #endregion

                #region  Validate a newly added homeowner association instance directly

                Reports.TestStep = "Validate a newly added homeowner association instance directly.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());
                Support.AreEqual("10.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());

                Support.AreEqual("4.00",GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("4.50",GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("2.50", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));

                Support.AreEqual("10.00",FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue());
                Support.AreEqual("07-16-2012",FastDriver.HomeownerAssociation.FromDate.FAGetValue());
                Support.AreEqual("08-17-2012", FastDriver.HomeownerAssociation.ToDate.FAGetValue());

                Support.AreEqual("1.50",GetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));
                Support.AreEqual("2.50", GetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));
                
                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Cancel 2nd New Homeowner Association Instance Creation.")]
        public void FMUC0041_BAT0003()
        {
            try
            {

                Reports.TestDescription = "AF4_00: Cancel 2nd New Homeowner Association Instance Creation.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");


                FastDriver.BottomFrame.Done();

                #endregion

                #region Cancel a newly created homeowner instance.

                Reports.TestStep = "Cancel a newly created homeowner instance.";

                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Cancel();

                FastDriver.WebDriver.HandleDialogMessage();

                #endregion

                #region  Validate a newly added homeowner association instance directly

                Reports.TestStep = "Validate a newly added homeowner association instance directly.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());
                Support.AreEqual("10.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());

                Support.AreEqual("4.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("4.50", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("2.50", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));

                Support.AreEqual("10.00", FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue());
                Support.AreEqual("07-16-2012", FastDriver.HomeownerAssociation.FromDate.FAGetValue());
                Support.AreEqual("08-17-2012", FastDriver.HomeownerAssociation.ToDate.FAGetValue());

                Support.AreEqual("1.50", GetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));
                Support.AreEqual("2.50", GetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));

                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Adding Homeowner Association Instance with clicking new button.")]
        public void FMUC0041_BAT0004()
        {
            try
            {

                Reports.TestDescription = "MF1_02: Adding Homeowner Association Instance with clicking new button.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");


                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on New button to add one more instance.

                Reports.TestStep = "Click on New button to add one more instance.";

                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("12.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "5.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "1.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "3.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("12.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "0.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");
                
                FastDriver.BottomFrame.Done();

                #endregion

                #region Validate a newly added homeowner association instance click on new button.

                Reports.TestStep = "Validate a newly added homeowner association instance click on new button.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2,"Midwest Financial Group",2,TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());
                Support.AreEqual("12.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());

                Support.AreEqual("5.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("1.50", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("3.50", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));

                Support.AreEqual("12.00", FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue());
                Support.AreEqual("07-16-2012", FastDriver.HomeownerAssociation.FromDate.FAGetValue());
                Support.AreEqual("08-17-2012", FastDriver.HomeownerAssociation.ToDate.FAGetValue());

                Support.AreEqual("0.50", GetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));
                Support.AreEqual("2.00", GetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));

                FastDriver.BottomFrame.Done();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Cancel 3rd / Subsequent New Homeowner Association Instance Creation.")]
        public void FMUC0041_BAT0005()
        {
            try
            {

                Reports.TestDescription = "AF5_00: Cancel 3rd / Subsequent New Homeowner Association Instance Creation.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");


                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on New button to add one more instance.

                Reports.TestStep = "Click on New button to add one more instance.";

                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("12.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "5.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "1.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "3.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("12.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "0.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Cancel a newly created homeowner instance.

                Reports.TestStep = "Cancel a newly created homeowner instance.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociationSummary.New.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Cancel();

                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Validate the new button in the screen.
                Reports.TestStep = "Validate the new button in the screen.";
                FastDriver.HomeownerAssociationSummary.SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.New.FAClick();
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Editing Homeowner Association Information.")]
        public void FMUC0041_BAT0006()
        {
            try
            {

                Reports.TestDescription = "AF1_00: Editing Homeowner Association Information.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");


                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on New button to add one more instance.

                Reports.TestStep = "Click on New button to add one more instance.";

                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("12.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "5.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "1.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "3.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("12.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "0.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Edit Homeowner Association Information.
                Reports.TestStep = "Edit Homeowner Association Information.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Validate the edited data
                Reports.TestStep = "Validate the edited data.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                                             
                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());

                Support.AreEqual("3.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("3.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("2.00", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));

              
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        
        [TestMethod]
        [Description("Cancel Changes to Existing Homeowner Association Instance.")]
        public void FMUC0041_BAT0007()
        {
            try
            {

                Reports.TestDescription = "AF6_00: Cancel Changes to Existing Homeowner Association Instance.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");


                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on New button to add one more instance.

                Reports.TestStep = "Click on New button to add one more instance.";

                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("12.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "5.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "1.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "3.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("12.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "0.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Edit Homeowner Association Information.
                Reports.TestStep = "Edit Homeowner Association Information.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Edit the home owner instance and cancel.
                Reports.TestStep = "Edit the home owner instance and cancel.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "6.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "6.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "8.00");

                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                #endregion

                #region Validate the edited data
                Reports.TestStep = "Validate the edited data.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());

                Support.AreEqual("3.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("3.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("2.00", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Deleting a Homeowner Association Instance.")]
        public void FMUC0041_BAT0008()
        {
            try
            {

                Reports.TestDescription = "AF2_00: Deleting a Homeowner Association Instance.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");


                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on New button to add one more instance.

                Reports.TestStep = "Click on New button to add one more instance.";

                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("12.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "5.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "1.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "3.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("12.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "0.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Edit Homeowner Association Information.
                Reports.TestStep = "Edit Homeowner Association Information.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion
                
                #region Delete a Homeowner Association Instance.
                Reports.TestStep = "Delete a Homeowner Association Instance.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Lenders Advantage", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate for 'Available' row.";
                FastDriver.HomeownerAssociationSummary.SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        
        #endregion

        #region REGRESSION

        [TestMethod]
        [Description("Precondition: Validate the Gab code name.")]
        public void FMUC0041_REG0001()
        {
            try
            {
                Reports.TestDescription = "BR_Precondition: Precondition: Validate the Gab code name.";

                #region LOGIN
                _ADMLOGIN();
                #endregion
                               
                #region Enter id code for hoa1 and click on find now.

                Reports.TestStep = "Enter id code for hoa1 and click on find now";

                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").SwitchToContentFrame();

                FastDriver.AddressBookSearch.EntityID.FASetText("HOA1");

                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(1, "Active", 2, TableAction.Click);

                FastDriver.AddressBookSearch.Edit.FAClick();

                #endregion

                #region Enter management company name.
                Reports.TestStep = "Enter management company name.";
                
                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                //If Name2 is not enabled, click version and wait for Name2 to be editable
                if (!FastDriver.BusPartyOrgSetUp.Name2.Enabled) {
                    FastDriver.BusPartyOrgSetUp.Version.FAClick();
                    FastDriver.BusPartyOrgSetUp.Wait.Until(d => {
                        return FastDriver.BusPartyOrgSetUp.Name2.Enabled;
                    });
                }
                FastDriver.BusPartyOrgSetUp.Name2.FASetText("Property Mgmt 1");

                Reports.TestStep = "Get the value of Name of Gab code and add a corporate parent.";
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Bank of America");

                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        
        [TestMethod]
        [Description("1.HOA Required Data 2.One Address Book Entry.")]
        public void FMUC0041_REG0002()
        {
            string Name1;
            string Name2;
            try
            {
                Reports.TestDescription = "BR_FM2112_FM2643: 1.HOA Required Data 2.One Address Book Entry.";

                #region LOGIN
                _ADMLOGIN();
                #endregion

                #region Enter id code for hoa1 and click on find now.

                Reports.TestStep = "Enter id code for hoa1 and click on find now";

                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").SwitchToContentFrame();

                FastDriver.AddressBookSearch.EntityID.FASetText("HOA1");

                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(1, "Active", 2, TableAction.Click);

                FastDriver.AddressBookSearch.Edit.FAClick();

                #endregion

                #region Enter management company name.
                Reports.TestStep = "Enter management company name.";

                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                //If Name2 is not enabled, click version and wait for Name2 to be editable
                if (!FastDriver.BusPartyOrgSetUp.Name2.Enabled)
                {
                    FastDriver.BusPartyOrgSetUp.Version.FAClick();
                    FastDriver.BusPartyOrgSetUp.Wait.Until(d =>
                    {
                        return FastDriver.BusPartyOrgSetUp.Name2.Enabled;
                    });
                }
                FastDriver.BusPartyOrgSetUp.Name2.FASetText("Property Mgmt 1");

                Reports.TestStep = "Get the value of Name of Gab code and add a corporate parent.";
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Bank of America");

                Name1 = FastDriver.BusPartyOrgSetUp.Name1.FAGetValue();
                Name2 = FastDriver.BusPartyOrgSetUp.Name2.FAGetValue();

                FastDriver.BottomFrame.Done();
                #endregion

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Set on Find button in Home Owner Association screen.

                Reports.TestStep = "Set on Find button in Home Owner Association screen.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.Find.FAClick();

                Reports.TestStep = "Set an Homeowner Association id from Global address book.";

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad_0();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("HOA1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();

                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad_0(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(7, "HOA1", 1, TableAction.On);

                FastDriver.DialogBottomFrame.ClickDone();

                #endregion

                #region  Validate the management name after enter GAB id
                Reports.TestStep = "Validate the management name after enter GAB id.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual(FastDriver.HomeownerAssociation.HOA_LenderName.Text.Trim(), Name1.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("1. Enter HOA Dues and Payment Period 2. Display Payment Details 3.Prorate HOA Dues 4.Display Check Details.")]
        public void FMUC0041_REG0003()
        {
            try
            {

                Reports.TestDescription = "BR_FM2376_FM2369_FM2370_FM2371: 1. Enter HOA Dues and Payment Period 2. Display Payment Details 3.Prorate HOA Dues 4.Display Check Details.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType CurrentFormType = _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");
                FastDriver.BottomFrame.Done();
              
                #endregion

                #region  Edit description in Inspection/Repair Pest.

                Reports.TestStep = "Edit description in Inspection/Repair Pest.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.CheckDetails.FAClick();

                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.CheckDetailsDlg.Description.FASetText("Check Description Edited");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Voucher info edited for Inpection/Repair Pest");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                
                #endregion

                #region Click on check management button and Edit description in management company check details.

                Reports.TestStep = "Click on check management button and Edit description in management company check details.";

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.ManagementCompanyCheckDetails.FAClick();
                FastDriver.MgmtCheckDetailDlg.WaitForScreenToLoad();

                FastDriver.MgmtCheckDetailDlg.Description.FASetText("Check Description Edited");
                FastDriver.MgmtCheckDetailDlg.CheckVoucherInfo.FASetText("Edit voucher information");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to homeowner association and change the payment details

                Reports.TestStep = "Navigate to homeowner association and change the payment details,";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$3.99");
                
                if (CurrentFormType == FormType.CD) {

                    FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("REG-HWA");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$3.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$3.99");

                }
                else
                {
                    FastDriver.PaymentDetailsDlg.USEDEFAULT.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.Description.FASetText("REG-HWA");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("POC");

                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validate the pencil image on change payment method.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.imagepencil.Displayed.ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Disable Prorations Entry in Sub Escrow Files.")]
        public void FMUC0041_REG0004()
        {
            try
            {

                Reports.TestDescription = "BR_ES6090: Disable Prorations Entry in Sub Escrow Files.";
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateSubEscrowFile();
                #endregion

                #region Validate that Proration fields are disabled.

                Reports.TestStep = "Validate that Proration fields are disabled.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.CheckDetails.Displayed.ToString());
                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.CreditSeller.Displayed.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.CreditSeller.Enabled.ToString());

                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.DayofClosePaidbySeller.Displayed.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.DayofClosePaidbySeller.Enabled.ToString());

                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationAmount.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.FromDate.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.fromInclusive.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.fromProrate.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.BasedOn.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.Per.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ToDate.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.toInclusive.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.toProrateDate.Enabled.ToString());

                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationDescription.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationBuyerCharge.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationBuyerCredit.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationSellerCharge.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.HomeownerAssociation.ProrationSellerCredit.Enabled.ToString());

                #endregion



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
               
        [TestMethod]
        [Description("Allow Management Company Charges: When company management is blank IN ADM.")]
        public void FMUC0041_REG0005()
        {
            try
            {

                Reports.TestDescription = "BR_FM2372_FM4212_FM2717_1: Allow Management Company Charges: When company management is blank IN ADM.";

                #region LOGIN
                _ADMLOGIN();
                #endregion

                #region Enter id code for hoa1 and click on find now.

                Reports.TestStep = "Enter id code for hoa1 and click on find now";

                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").SwitchToContentFrame();

                FastDriver.AddressBookSearch.EntityID.FASetText("HOA1");

                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(1, "Active", 2, TableAction.Click);

                FastDriver.AddressBookSearch.Edit.FAClick();

                #endregion

                #region Enter management company name.
                Reports.TestStep = "Enter management company blank.";

                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                FastDriver.BusPartyOrgSetUp.Name2.SendKeys(FAKeys.Tab);
                FastDriver.BusPartyOrgSetUp.Name2.FASetText("");

                Reports.TestStep = "Get the value of Name of Gab code and add a corporate parent.";
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Bank of America");
                FastDriver.BottomFrame.Done();

                #endregion



              

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Allow Management Company Charges: Validate that charges are editable and payee name is blank in active disbursement screen.")]
        public void FMUC0041_REG0006()
        {
            string Name1;
            string Name2;
            try
            {
                Reports.TestDescription = "BR_FM2717_2: Allow Management Company Charges: Validate that charges are editable and payee name is blank in active disbursement screen.";

                #region LOGIN
                _ADMLOGIN();
                #endregion

                #region Enter id code for hoa1 and click on find now.

                Reports.TestStep = "Enter id code for hoa1 and click on find now";

                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").SwitchToContentFrame();

                FastDriver.AddressBookSearch.EntityID.FASetText("HOA1");

                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(1, "Active", 2, TableAction.Click);

                FastDriver.AddressBookSearch.Edit.FAClick();

                #endregion

                #region Enter management company name.
                Reports.TestStep = "Enter management company name.";

                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                FastDriver.BusPartyOrgSetUp.Name2.SendKeys(FAKeys.Tab);
                FastDriver.BusPartyOrgSetUp.Name2.FASetText("");
                             
                Reports.TestStep = "Get the value of Name of Gab code and add a corporate parent.";
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Bank of America");

                Name1 = FastDriver.BusPartyOrgSetUp.Name1.FAGetValue();
                Name2 = FastDriver.BusPartyOrgSetUp.Name2.FAGetValue();

                FastDriver.BottomFrame.Done();
                #endregion

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType CurrentFormType = _CreateFile();
                #endregion

                #region Create a home owner association instance and enter management charge

                Reports.TestStep = "Create a home owner association instance and enter management charge.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.FindGABCode("HOA1");
                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.Enabled.ToString());
                FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.FASetText("4.50");

                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.Enabled.ToString());
                FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.FASetText("2.50");

                #endregion

                #region Click on Payment Details button of management company.
                Reports.TestStep = "Click on Payment Details button of management company.";

                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Validate Management name.";

                if (CurrentFormType == FormType.CD) {

                    Support.AreEqual(Name1, FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue());
                }
                else
                {
                    Support.AreEqual(Name1, FastDriver.PaymentDetailsDlg.PayTo.FAGetValue());

                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

               #endregion

                #region Validate that Payee name is blank and status is created
                Reports.TestStep = "Validate that Payee name is blank and status is created.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").SwitchToContentFrame();

                Support.AreEqual(string.Empty, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1,"Created",8,TableAction.GetText).Message.Trim());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Allow Management Company Charges: When company management is not blank.")]
        public void FMUC0041_REG0007()
        {
            try
            {

                Reports.TestDescription = "BR_FM2372_FM2717_3: Allow Management Company Charges: When company management is not blank.";

                #region LOGIN
                _ADMLOGIN();
                #endregion

                #region Enter id code for hoa1 and click on find now.

                Reports.TestStep = "Enter id code for hoa1 and click on find now";

                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").SwitchToContentFrame();

                FastDriver.AddressBookSearch.EntityID.FASetText("HOA1");

                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(1, "Active", 2, TableAction.Click);

                FastDriver.AddressBookSearch.Edit.FAClick();

                #endregion

                #region Enter management company name.
                Reports.TestStep = "Enter management company blank.";

                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                FastDriver.BusPartyOrgSetUp.Name2.SendKeys(FAKeys.Tab);
                FastDriver.BusPartyOrgSetUp.Name2.FASetText("Property Mgmt 1");

                Reports.TestStep = "Get the value of Name of Gab code and add a corporate parent.";
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Bank of America");
                FastDriver.BottomFrame.Done();

                #endregion
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Allow Management Company Charges: Validate that charges are editable and payee name is not blank in active disbursement screen.")]
        public void FMUC0041_REG0008()
        {
            string Name1;
            string Name2;
            try
            {
                Reports.TestDescription = "BR_FM2717_4: Allow Management Company Charges: Validate that charges are editable and payee name is not blank in active disbursement screen.";


                #region LOGIN
                _ADMLOGIN();
                #endregion

                #region Enter id code for hoa1 and click on find now.

                Reports.TestStep = "Enter id code for hoa1 and click on find now";

                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").SwitchToContentFrame();

                FastDriver.AddressBookSearch.EntityID.FASetText("HOA1");

                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(1, "Active", 2, TableAction.Click);

                FastDriver.AddressBookSearch.Edit.FAClick();

                #endregion

                #region Enter management company name.
                Reports.TestStep = "Enter management company blank.";

                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                FastDriver.BusPartyOrgSetUp.Name2.SendKeys(FAKeys.Tab);
                FastDriver.BusPartyOrgSetUp.Name2.FASetText("Property Mgmt 1");

                Name1 = FastDriver.BusPartyOrgSetUp.Name1.FAGetValue();
                Name2 = FastDriver.BusPartyOrgSetUp.Name2.FAGetValue();

                Reports.TestStep = "Get the value of Name of Gab code and add a corporate parent.";
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Bank of America");
                FastDriver.BottomFrame.Done();

                #endregion
               
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType CurrentFormType = _CreateFile();
                #endregion

                #region Create a home owner association instance and enter management charge

                Reports.TestStep = "Create a home owner association instance and enter management charge.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.FindGABCode("HOA1");
                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.Enabled.ToString());
                FastDriver.HomeownerAssociation.ManagementCompanyBuyerCharge.FASetText("4.50");

                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.Enabled.ToString());
                FastDriver.HomeownerAssociation.ManagementCompanySellerCharge.FASetText("2.50");

                #endregion

                #region Click on Payment Details button of management company.
                Reports.TestStep = "Click on Payment Details button of management company.";

                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Validate Management name.";

                Support.AreEqual(Name1, FastDriver.PaymentDetailsDlg.PayTo.FAGetValue());

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Validate that Payee name is of management company and status is Pend
                Reports.TestStep = "Validate that Payee name is of management company and status is Pend";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").SwitchToContentFrame();

                Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, Name2, 1, TableAction.GetText).Message.Trim());

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("BR_FM2374: Display Check Amounts.")]
        public void FMUC0041_REG0009()
        {
            try
            {
                Reports.TestDescription = "BR_FM2374: Display Check Amounts.";


                #region LOGIN
                _ADMLOGIN();
                #endregion

                #region Enter id code for hoa1 and click on find now.

                Reports.TestStep = "Enter id code for hoa1 and click on find now";

                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").SwitchToContentFrame();

                FastDriver.AddressBookSearch.EntityID.FASetText("HOA1");

                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(1, "Active", 2, TableAction.Click);

                FastDriver.AddressBookSearch.Edit.FAClick();

                #endregion

                #region Enter management company name.
                Reports.TestStep = "Enter management company blank.";

                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                FastDriver.BusPartyOrgSetUp.Name2.SendKeys(FAKeys.Tab);
                FastDriver.BusPartyOrgSetUp.Name2.FASetText("Property Mgmt 1");

                Reports.TestStep = "Get the value of Name of Gab code and add a corporate parent.";
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Bank of America");
                FastDriver.BottomFrame.Done();

                #endregion

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType CurrentFormType = _CreateFile();
                #endregion

                #region Create a home owner association instance

                Reports.TestStep = "Create a home owner association instance.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.FindGABCode("HOA2");
               #endregion

                #region Click on Payment Details and Enter charges and make payment method as CHK..
                Reports.TestStep = "Click on Payment Details and Enter charges and make payment method as CHK.";

                FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();


                if (CurrentFormType == FormType.CD)
                {
                   FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$2.50");
                   FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$2.60");
                   FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$2.50");
                   FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$2.60");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.60");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Validate that system displays the total as a check amount for homeowner association.
                Reports.TestStep = "Validate that system displays the total as a check amount for homeowner association.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual("Check Amount: $ 5.10", FastDriver.HomeownerAssociation.ManagementCompanyCheckAmount.Text.Trim());


                #endregion

                #region Click on Payment Details and Enter charges and make payment method as CHK..
                Reports.TestStep = "Click on Payment Details and Enter charges and make payment method as CHK.";

                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();


                if (CurrentFormType == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$2.60");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$2.60");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.60");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Validate that system displays the total as a check amount for homeowner association.
                Reports.TestStep = "Validate that system displays the total as a check amount for homeowner association.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual("Check Amount: $ 5.10", FastDriver.HomeownerAssociation.AssociationChargeCheckAmount.Text.Trim());


                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Delete HOA Instance.")]
        public void FMUC0041_REG0010()
        {
            try
            {
                Reports.TestDescription = "BR_FM2458_ER_2: Delete HOA Instance.";

                #region LOGIN
                _ADMLOGIN();
                #endregion

                #region Enter id code for hoa1 and click on find now.

                Reports.TestStep = "Enter id code for hoa1 and click on find now";

                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").SwitchToContentFrame();

                FastDriver.AddressBookSearch.EntityID.FASetText("HOA1");

                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(1, "Active", 2, TableAction.Click);

                FastDriver.AddressBookSearch.Edit.FAClick();

                #endregion

                #region Enter management company name.
                Reports.TestStep = "Enter management company blank.";

                FastDriver.BusPartyOrgSetUp.SwitchToContentFrame();
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                FastDriver.BusPartyOrgSetUp.Name2.SendKeys(FAKeys.Tab);
                FastDriver.BusPartyOrgSetUp.Name2.FASetText("Property Mgmt 1");

                Reports.TestStep = "Get the value of Name of Gab code and add a corporate parent.";
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItem("Bank of America");
                FastDriver.BottomFrame.Done();

                #endregion

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType CurrentFormType = _CreateFile();
                #endregion

                #region Create a home owner association instance

                Reports.TestStep = "Create a home owner association instance.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.FindGABCode("HOA2");
                #endregion

                #region Click on Payment Details and Enter charges and make payment method as CHK..
                Reports.TestStep = "Click on Payment Details and Enter charges and make payment method as CHK.";

                FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();


                if (CurrentFormType == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$2.60");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$2.60");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.60");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                #endregion

                #region Click on Payment Details and Enter charges and make payment method as CHK..
                Reports.TestStep = "Click on Payment Details and Enter charges and make payment method as CHK.";

                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();


                if (CurrentFormType == FormType.CD)
                {
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$2.60");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$2.50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$2.60");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.60");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on New button to add one more instance.

                Reports.TestStep = "Create a home owner association instance.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("248");

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("12.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "5.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "1.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "3.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("12.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "0.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");


                FastDriver.BottomFrame.Done();

                #endregion

                #region Delete instance Homeowner Association with name Midwest Financial Group.
                Reports.TestStep = "Delete instance Homeowner Association with name Midwest Financial Group.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2,"Midwest Financial Group",2,TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Remove.FAClick();

                Reports.TestStep = "Validate for Delete instance of Home Owner Association message.";
                Support.AreEqual("All information will be removed for this Homeowner Association.  Continue?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.HomeownerAssociationSummary.SwitchToContentFrame();

                Reports.TestStep = "Validate for 'Available' row.";
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Available", 2, TableAction.Click);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("1.User cancels entry of the FIRST new instance.2.User cancels entry of the SECOND instance. 3.User cancels entry of the THIRD or SUBSEQUENT new instance.")]
        public void FMUC0041_REG0011()
        {
            try
            {

                Reports.TestDescription = "BR_FM2458_ER_8_9_10_11: 1.User cancels entry of the FIRST new instance.2.User cancels entry of the SECOND instance. 3.User cancels entry of the THIRD or SUBSEQUENT new instance.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Cancel a newly created homeowner instance.

                Reports.TestStep = "Cancel a newly created homeowner instance.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Click on New button to add one more instance.

                Reports.TestStep = "Add a homeowner association instance directly.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on Homeowner Association in treeview and Validate a newly added homeowner association instance directly.

                Reports.TestStep = "Click on Homeowner Association in treeview and Validate a newly added homeowner association instance directly..";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                
                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());
                Support.AreEqual("10.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());

                Support.AreEqual("4.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("2.00", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("4.50", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));

                Support.AreEqual("10.00", FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue());
                Support.AreEqual("07-16-2012", FastDriver.HomeownerAssociation.FromDate.FAGetValue());
                Support.AreEqual("08-17-2012", FastDriver.HomeownerAssociation.ToDate.FAGetValue());

                Support.AreEqual("1.50", GetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));
                Support.AreEqual("2.00", GetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));

                #endregion

                #region Click on New button to add one more instance and Cancel that instance.

                Reports.TestStep = "Click on New button to add one more instance and Cancel that instance";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.BottomFrame.New();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                #endregion

                #region Validate a newly added homeowner association instance directly.

                Reports.TestStep = "Click on Homeowner Association in treeview and Validate a newly added homeowner association instance directly..";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());
                Support.AreEqual("10.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());

                Support.AreEqual("4.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("2.00", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("4.50", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));

                Support.AreEqual("10.00", FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue());
                Support.AreEqual("07-16-2012", FastDriver.HomeownerAssociation.FromDate.FAGetValue());
                Support.AreEqual("08-17-2012", FastDriver.HomeownerAssociation.ToDate.FAGetValue());

                Support.AreEqual("1.50", GetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));
                Support.AreEqual("2.00", GetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));

                #endregion

                #region Click on New button to add one more instance.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("12.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "5.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "1.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "3.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("12.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "0.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Edit Homeowner Association Information and Validate data
                Reports.TestStep = "Edit Homeowner Association Information and Validate data";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2,"Midwest Financial Group",2,TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();
                Reports.TestStep = "Validate a newly added homeowner association instance click on new button.";

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());
                Support.AreEqual("12.00", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());

                Support.AreEqual("5.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("1.50", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("3.50", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));

                Support.AreEqual("12.00", FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue());
                Support.AreEqual("07-16-2012", FastDriver.HomeownerAssociation.FromDate.FAGetValue());
                Support.AreEqual("08-17-2012", FastDriver.HomeownerAssociation.ToDate.FAGetValue());

                Support.AreEqual("0.50", GetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));
                Support.AreEqual("2.00", GetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues"));

                #endregion

                #region Click on New button to add one more instance and Cancel that instance.

                Reports.TestStep = "Click on New button to add one more instance and Cancel that instance";

                FastDriver.BottomFrame.New();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Validate the new button in the screen
                Reports.TestStep = "Validate the new button in the screen.";
                FastDriver.HomeownerAssociationSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociationSummary.New.Displayed.ToString());

                #endregion

                #region Edit Homeowner Association Information and save

                Reports.TestStep = "Edit Homeowner Association Information and save";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                
                FastDriver.HomeownerAssociation.GABcode.FASetText("248");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "3.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.00");

                FastDriver.BottomFrame.Done();
             
                #endregion

                #region Validate the edited data

                Reports.TestStep = "Validate the edited data";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());

                Support.AreEqual("3.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("3.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("2.00", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));

                #endregion

                #region Edit the home owner instance and cancel

                Reports.TestStep = "Edit the home owner instance and cancel";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "6.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "6.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "8.00");

                FastDriver.BottomFrame.Reset();

                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Validate the edited data

                Reports.TestStep = "Validate the edited data";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Support.AreEqual("MONTH", FastDriver.HomeownerAssociation.PerDiem.FAGetSelectedItem());

                Support.AreEqual("3.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("3.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("2.00", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        
        [TestMethod]
        [Description("1.User searches for a business party on ID Code and system does not find an exact match. 2 User tries to delete a charge description that has a charge amount.")]
        public void FMUC0041_REG0012()
        {
            try
            {
                Reports.TestDescription = "BR_FM2458_ER_6_3_13: 1.User searches for a business party on ID Code and system does not find an exact match. 2 User tries to delete a charge description that has a charge amount.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                FormType CurrentFormType = _CreateFile();
                #endregion

                #region Create an instance with Invalid GAB id

                Reports.TestStep = "Create an instance with Invalid GAB id.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("INVALID_ID");
                FastDriver.HomeownerAssociation.Find.FAClick();
                Support.AreEqual("ID Code not found.", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Enter Charge without GAB id and more than issued check
                Reports.TestStep = "Enter Charge without GAB id and more than issued check.";

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("100");
                FastDriver.BottomFrame.Done();

                Support.AreEqual("Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                #endregion

                #region Add a homeowner association instance
                Reports.TestStep = "Add a homeowner association instance.";
                FastDriver.HomeownerAssociation.FindGABCode("248");
              
                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("12.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "5.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "1.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "3.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("12.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "0.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");
                
                #endregion
                
                #region Remove description when charges are still present
                
                Reports.TestStep = "Remove description when charges are still present.";

                FastDriver.HomeownerAssociation.AssociationChargeDescription.Clear();
                FastDriver.HomeownerAssociation.AssociationChargeDescription.SendKeys(FAKeys.Tab);
                Reports.TestStep = "Delete Charge Description.";

                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                #endregion

                #region Validate that Charge description Retains.
                Reports.TestStep = "Validate that Charge description Retains.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Support.AreEqual("Transfer Fee", FastDriver.HomeownerAssociation.AssociationChargeDescription.FAGetValue().Trim());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("1. User deletes a charge process instance that has issued checks. 2.User tries to decrease or delete a charge amount with payment method of CHK after the payee check is issued.3 User tries to add o")]
        public void FMUC0041_REG0013()
        {
            try
            {

                Reports.TestDescription = "BR_FM2458_ER_1_4_5_7: 1. User deletes a charge process instance that has issued checks. 2.User tries to decrease or delete a charge amount with payment method of CHK after the payee check is issued.3 User tries to add or";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");


                FastDriver.BottomFrame.Done();

                #endregion

                #region Click on New button to add one more instance.

                Reports.TestStep = "Click on New button to add one more instance.";

                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItemBySendingKeys("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("12.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "5.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "1.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "3.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("12.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "0.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.00");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Print All Checks.

                Reports.TestStep = "Print All Checks.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
        
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();

                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();


                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);


                Reports.TestStep = "Click on Done in ADS screen.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                #endregion

                #region Delete a Homeowner Association Instance
                Reports.TestStep = "Delete a Homeowner Association Instance.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Lenders Advantage", 2, TableAction.Click);

                Reports.TestStep = "Delete The Payee have Issued Instance.";
                FastDriver.HomeownerAssociationSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeownerAssociationSummary.SwitchToContentFrame();

                #endregion

                #region Edit Homeowner Association Information.
                Reports.TestStep = "Edit Homeowner Association Information.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);

                FastDriver.HomeownerAssociationSummary.Edit.FAClick();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Reports.TestStep = "Enter Valid gab id.";
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOA1");
                FastDriver.HomeownerAssociation.Find.FAClick();
                Support.AreEqual("A check has been issued for this Payee.  The Payee name cannot be changed.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Enter Charge without GAB id and more than issued check.";
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("100");
                FastDriver.BottomFrame.Done();
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false).Trim());
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Enter a charge less than issued check.";
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("2");
                FastDriver.BottomFrame.Done();
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false).Trim());
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                FastDriver.HomeownerAssociationSummary.SwitchToContentFrame();

                FastDriver.HomeownerAssociationSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual("5.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));
                Support.AreEqual("2.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee"));

                Support.AreEqual("1.50", GetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                Support.AreEqual("3.50", GetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee"));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        
        [TestMethod]
        [Description("1.When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name.2.When the user enters an invalid email address 3.User tries to change a Busi")]
        public void FMUC0041_REG0014()
        {
            try
            {

                Reports.TestDescription = "BR_FM2458_ER_14_15_16: 1.When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name.2.When the user enters an invalid email address 3.User tries to change a Busi";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");

                Reports.TestStep = "Select the edit name check box and save without enter name.";
                FastDriver.HomeownerAssociation.Edit.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.";
                Support.AreEqual("Name field is required when Edit Name checkbox is selected.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Enter name in edit name field.";
                FastDriver.HomeownerAssociation.EditName.FASetText("Editname");

                Reports.TestStep = "Enter invalid email id.";
                FastDriver.HomeownerAssociation.EditCont.FASetCheckbox(true);
                FastDriver.HomeownerAssociation.EmailAddress.FASetText("invalid.com");
                FastDriver.HomeownerAssociation.EmailAddress.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Validate that email id is invalid.";
                Support.AreEqual("?", FastDriver.HomeownerAssociation.EmailAddress.FAGetValue());

                Reports.TestStep = "Enter a valid email id.";
                FastDriver.HomeownerAssociation.EmailAddress.FASetText("abc@regression.com");

                Reports.TestStep = "Create an instance with reference number.";
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.Reference.FASetText("100");

                Reports.TestStep = "Enter Valid gab id.";
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOA1");
                FastDriver.HomeownerAssociation.Find.FAClick();

                Reports.TestStep = "Change Business Party have Ref No.";
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Validate that reference number appears in screen.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual("100", FastDriver.HomeownerAssociation.Reference.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [Description("Field Definitions In Tab Order.")]
        public void FMUC0041_REG0015()
        {
            try
            {

                Reports.TestDescription = "FIELD_DEFINATION: Field Definitions In Tab Order.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Add a homeowner association instance directly.

                Reports.TestStep = "Add a homeowner association instance directly.";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();

                FastDriver.HomeownerAssociation.GABcode.FASetText("247");

                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.HomeownerAssociation.PerDiem.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.AmountDues.FASetText("10.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "4.00");
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "2.00");

                SetBuyerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "4.50");
                SetSellerCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", "2.50");

                FastDriver.HomeownerAssociation.ProrationAmount.FASetText("10.00");
                FastDriver.HomeownerAssociation.FromDate.FASetText("07-16-2012");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2012");

                SetBuyerCharge(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "1.50");
                SetSellerCredit(FastDriver.HomeownerAssociation.HOALienPayoffTable, "Association Dues", "2.50");

                Reports.TestStep = "Select the edit name check box and save without enter name.";
                FastDriver.HomeownerAssociation.Edit.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Enter name in edit name field.";
                FastDriver.HomeownerAssociation.EditName.FASetText("Editname");

                Reports.TestStep = "Enter invalid email id.";
                FastDriver.HomeownerAssociation.EditCont.FASetCheckbox(true);
                FastDriver.HomeownerAssociation.EmailAddress.FASetText("invalid.com");
                FastDriver.HomeownerAssociation.EmailAddress.SendKeys(FAKeys.Tab);

                FastDriver.HomeownerAssociation.EmailAddress.FASetText("abc@regression.com");

                Reports.TestStep = "Create an instance with reference number.";
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.Reference.FASetText("100");

                Reports.TestStep = "Enter Valid gab id.";
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOA1");
                FastDriver.HomeownerAssociation.Find.FAClick();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                #endregion

                #region Verify the Field with lower Boundary Value.
                Reports.TestStep = "Verify the Field with lower Boundary Value.";

                FastDriver.HomeownerAssociation.Name.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789");
                FastDriver.HomeownerAssociation.Name.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789", FastDriver.HomeownerAssociation.Name.FAGetValue());
                FastDriver.HomeownerAssociation.EditCont.FASetCheckbox(true);
                
                FastDriver.HomeownerAssociation.BusPhone.FASetText("123456789");
                FastDriver.HomeownerAssociation.BusPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(???)???-????", FastDriver.HomeownerAssociation.BusPhone.FAGetValue());

                FastDriver.HomeownerAssociation.BusFax.FASetText("123456789");
                FastDriver.HomeownerAssociation.BusFax.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(???)???-????", FastDriver.HomeownerAssociation.BusFax.FAGetValue());

                FastDriver.HomeownerAssociation.CellPhone.FASetText("123456789");
                FastDriver.HomeownerAssociation.CellPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(???)???-????", FastDriver.HomeownerAssociation.CellPhone.FAGetValue());

                FastDriver.HomeownerAssociation.AmountDues.FASetText("-0.99");
                FastDriver.HomeownerAssociation.AmountDues.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"?", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());
                #endregion

                #region Verify the Field with Exact Value.
                Reports.TestStep = "Verify the Field with Exact Value.";
                FastDriver.HomeownerAssociation.Name.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890");
                FastDriver.HomeownerAssociation.Name.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.HomeownerAssociation.Name.FAGetValue());
                FastDriver.HomeownerAssociation.EditCont.FASetCheckbox(true);

                FastDriver.HomeownerAssociation.BusPhone.FASetText("1234567899");
                FastDriver.HomeownerAssociation.BusPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.HomeownerAssociation.BusPhone.FAGetValue());

                FastDriver.HomeownerAssociation.BusFax.FASetText("1234567899");
                FastDriver.HomeownerAssociation.BusFax.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.HomeownerAssociation.BusFax.FAGetValue());

                FastDriver.HomeownerAssociation.CellPhone.FASetText("1234567899");
                FastDriver.HomeownerAssociation.CellPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.HomeownerAssociation.CellPhone.FAGetValue());

                FastDriver.HomeownerAssociation.AmountDues.Click();
                FastDriver.HomeownerAssociation.AmountDues.SendKeys("99999999999.99");
                FastDriver.HomeownerAssociation.AmountDues.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Support.AreEqual(@"99,999,999,999.99", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());

                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                #endregion

                #region Verify the Field with Upper Boundary Value.
                Reports.TestStep = "Verify the Field with Upper Boundary Value.";
                FastDriver.HomeownerAssociation.Name.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890");
                FastDriver.HomeownerAssociation.Name.SendKeys(FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.HomeownerAssociation.Name.FAGetValue());
                FastDriver.HomeownerAssociation.EditCont.FASetCheckbox(true);

                FastDriver.HomeownerAssociation.BusPhone.FASetText("12345678999");
                FastDriver.HomeownerAssociation.BusPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.HomeownerAssociation.BusPhone.FAGetValue());

                FastDriver.HomeownerAssociation.BusFax.FASetText("12345678999");
                FastDriver.HomeownerAssociation.BusFax.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.HomeownerAssociation.BusFax.FAGetValue());

                FastDriver.HomeownerAssociation.CellPhone.FASetText("12345678999");
                FastDriver.HomeownerAssociation.CellPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.HomeownerAssociation.CellPhone.FAGetValue());

                FastDriver.HomeownerAssociation.AmountDues.Click();
                FastDriver.HomeownerAssociation.AmountDues.SendKeys("999999999999.99");
                FastDriver.HomeownerAssociation.AmountDues.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Support.AreEqual(@"?", FastDriver.HomeownerAssociation.AmountDues.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        
        #endregion
        
        #region PRIVATE METHODS

        private FormType _CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = _GetCurrentFileFormType();
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.LiabilityAmount = 5000;

            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
           
            #region CreateNewLoan
            var newLoan = new NewLoanParameters()
            {
                Type = "",
                Amount = "",
                GABCode = "247"
            };
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.FillNewLoanForm(newLoan);
            FastDriver.NewLoan.ClickRecapTab();
            FastDriver.NewLoan.WaitForRecapToLoad();
            #endregion

            return customizableFileRequest.formType;
        }

        private void _CreateSubEscrowFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = _GetCurrentFileFormType();
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.LiabilityAmount = 5000;

            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };

            customizableFileRequest.File.Services = new Service[] 
                    { 
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "SEO"
                        }
                    };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            #region CreateNewLoan
            var newLoan = new NewLoanParameters()
            {
                Type = "",
                Amount = "",
                GABCode = "247"
            };
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.FillNewLoanForm(newLoan);
            FastDriver.NewLoan.ClickRecapTab();
            FastDriver.NewLoan.WaitForRecapToLoad();
            #endregion

        }
      
        public void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }
        
        public void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            try
            {
                FASTLogin.Login(WebSite, Credentials, true);
            }
            catch
            {
                FASTLogin.Login(WebSite, Credentials, true);
            }
        }

        private string GetBuyerCharge(IWebElement TableCharges, string DescriptionRow)
        {
            return TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.GetAttribute, "value").Message;
        }

        private void SetBuyerCharge(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.SetText, BuyerCreditValue);
        }

        private string GetSellerCharge(IWebElement TableCharges, string DescriptionRow)
        {
            return TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.GetAttribute, "value").Message;
        }

        private void SetSellerCharge(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.SetText, BuyerCreditValue);
        }

        private void SetSellerCredit(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 6, TableAction.SetText, BuyerCreditValue);
        }
    
        private string GetSellerCredit(IWebElement TableCharges, string DescriptionRow)
        {
            return TableCharges.PerformTableAction(1, DescriptionRow, 6, TableAction.GetAttribute, "value").Message;
        }
        
        private void SetDescription(IWebElement TableCharges, string DescriptionRow, string NewDescriptionValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 1, TableAction.SetText, NewDescriptionValue);
        }

        public bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private FormType _GetCurrentFileFormType()
        {
            return AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
        }


        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    
    }
}
