﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects;
using FASTWCFHelpers.FastFileService;
using System.IO;
using OpenQA.Selenium;

namespace EscrowChargeProcess
{
    /// <summary>
    /// Summary description for FMUC0047_NewLoan_YieldSpreadPremium
    /// </summary>
    [CodedUITest]
    public class FMUC0047_NewLoan_YieldSpreadPremium : MasterTestClass
    {
        public FMUC0047_NewLoan_YieldSpreadPremium()
        {
        }

        #region BAT
        [TestMethod]
        public void FMUC0047_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_001: Create First New Loan with CD/HUD type.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Remove New Loan Amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("0");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual(@"True", FastDriver.NewLoan.LoanDetailsHUDType_HUD.Selected.ToString());
                }
                else
                {
                    Support.AreEqual(@"False", FastDriver.NewLoan.LoanDetailsHUDType_HUD.Selected.ToString());
                }
                
                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Select Loan Type as RHS.";
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Details Tab.";
                Support.AreEqual("MORTLNDR", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("V100M07", FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue());
                Support.AreEqual("L00100", FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue());
                Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.LoanDetailsSalesRep1.FAGetSelectedItem());
                Support.AreEqual("03-16-2011", FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue());
                Support.AreEqual("08-03-2012", FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue());
                Support.AreEqual("50", FastDriver.NewLoan.LoanDetailsDays.FAGetValue());
                Support.AreEqual("02-08-2013", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue());
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsRefresh.Enabled.ToString());
                Support.AreEqual("FirstAm is not responsible for this.", FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FAGetValue());
                
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_004: Enter details in Loan Charges Tab, Files with HUD Type = CD.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Loan Details Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("MORTLNDR", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("V100M07", FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue());
                Support.AreEqual("L00100", FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue());
                Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.LoanDetailsSalesRep1.FAGetSelectedItem());
                Support.AreEqual("03-16-2011", FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue());
                Support.AreEqual("08-03-2012", FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue());
                Support.AreEqual("50", FastDriver.NewLoan.LoanDetailsDays.FAGetValue());
                Support.AreEqual("02-08-2013", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue());
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsRefresh.Enabled.ToString());
                Support.AreEqual("FirstAm is not responsible for this.", FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FAGetValue());

                Reports.TestStep = "Validate Loan Charges Tab.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesPayCharges.Enabled.ToString());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.Enabled.ToString());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.Enabled.ToString());
                Support.AreEqual("Fixed Rate", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiem.Selected.ToString());
                Support.AreEqual("1.500000", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().Clean());
                Support.AreEqual("08-06-2012", FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue().Clean());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.Selected.ToString());
                Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.Selected.ToString());
                Support.AreEqual("0.0000", FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue().Clean());
                Support.AreEqual("06-27-2013", FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue().Clean());
                Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected.ToString());
                Support.AreEqual("487.50", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("250.00", FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue());
                    Support.AreEqual("250.00", FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesOriginationChargeCharge.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesOriginationChargeZero.Selected.ToString());
                    //Support.AreEqual("250.00", FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetValue().Clean());
                    Support.AreEqual("1.5000", FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetValue().Clean());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FAGetValue().Clean());
                    Support.AreEqual("150.00", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue().Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCharge.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsZero.Selected.ToString());
                    Support.AreEqual("-200.00", FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FAGetValue().Clean());
                    Support.AreEqual("-100.00", FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FAGetValue().Clean());
                    Support.AreEqual("1.7500", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue().Clean());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FAGetValue().Clean());
                    Support.AreEqual("175.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue().Clean());
                    Support.AreEqual("1,500.00", FastDriver.NewLoan.LenderCreditsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("1,800.00", FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("70.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("6", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("30.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentZero.Selected.ToString());
                    Support.AreEqual("-50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue().Clean());
                    Support.AreEqual("101.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FAGetValue().Clean());
                }
                else
                {
                    Support.AreEqual("250.00", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("175.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("100.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("1.750", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue());
                    Support.AreEqual("5", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("70.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("6", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("30.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue().Clean());
                }
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF1_005: Enter details in Mortgage Broker Tab with CD Type = CD/HUD Type = HUD";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);
                    FastDriver.NewLoan.Mortgage_ExpandLenderCredits.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Credit Report", buyerCharge: 1500);
                    FastDriver.NewLoan.Mortgage_ExpandFutureRecFees.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee 1", buyerCharge: 1800);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251, sellerCharge: 151);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Mortgage Broker for a Instance.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("247", FastDriver.NewLoan.MortgageBrokerGABlabel.Text.Clean());
                Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.MortgageSalesRep1.FAGetSelectedItem());
                Support.AreEqual("251.00", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("151.00", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("1,500.00", FastDriver.NewLoan.Mortgage_LenderCreditTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("1,800.00", FastDriver.NewLoan.Mortgage_FutureRecFeesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0004()
        {
            try
            {
                Reports.TestDescription = "MF1_007HUD: Enter details in Note Tab.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);
                    FastDriver.NewLoan.Mortgage_ExpandLenderCredits.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Credit Report", buyerCharge: 1500);
                    FastDriver.NewLoan.Mortgage_ExpandFutureRecFees.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee 1", buyerCharge: 1800);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251, sellerCharge: 151);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Enter the Settlement Date for an instance.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                FastDriver.TermsDatesStatus.DisbursementDate.Click();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Note Tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickNoteTab();
                Support.AreEqual("true", FastDriver.NewLoan.NoteConstructionMortgage.FAGetAttribute("checked").ToString());
                Support.AreEqual("true", FastDriver.NewLoan.NoteBalloonPayment.FAGetAttribute("checked").ToString());
                Support.AreEqual("true", FastDriver.NewLoan.NoteLateChargeof_checkbox.FAGetAttribute("checked").ToString());
                Support.AreEqual("True", FastDriver.NewLoan.NoteLateChargeof_Percentageradio.Selected.ToString());
                Support.AreEqual("5.0000", FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FAGetValue());
                Support.AreEqual("15", FastDriver.NewLoan.NoteLateChargeofDays.FAGetValue());
                Support.AreEqual("08-11-2012", FastDriver.NewLoan.NoteInterestFrom.FAGetValue());
                Support.AreEqual("11-06-2012", FastDriver.NewLoan.NoteFirstPaymentDue.FAGetValue());
                Support.AreEqual("2,500.00", FastDriver.NewLoan.NotePaymentAmount.FAGetValue());
                Support.AreEqual("Quarter", FastDriver.NewLoan.NotePayablePer.FAGetSelectedItem());
                Support.AreEqual("1", FastDriver.NewLoan.NoteLoanTerm.FAGetValue());
   
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0005()
        {
            try
            {
                Reports.TestDescription = "MF1_008HUD: Enter details in Parties Tab.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);
                    FastDriver.NewLoan.Mortgage_ExpandLenderCredits.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Credit Report", buyerCharge: 1500);
                    FastDriver.NewLoan.Mortgage_ExpandFutureRecFees.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee 1", buyerCharge: 1800);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251, sellerCharge: 151);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Settlement Date for an instance.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                FastDriver.TermsDatesStatus.DisbursementDate.Click();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Parties Tab.";
                FastDriver.NewLoan.ClickPartiesTab();
                Support.AreEqual("Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname", FastDriver.NewLoan.PartiesTrustorMortgagor.FAGetValue());
                Support.AreEqual("Mortgage Lender 1 Name 1, Mortgage Lender 1 Name 2", FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FAGetValue());
                Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.PartiesSalesRep1.FAGetSelectedItem());
                Support.AreEqual("L247", FastDriver.NewLoan.PartiesAttention.FAGetSelectedItem());
                Support.AreEqual("Mohanty", FastDriver.NewLoan.PartiesReference.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0006()
        {
            try
            {
                Reports.TestDescription = "MF1_009HUD: Enter details in Related Parties Tab.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);
                    FastDriver.NewLoan.Mortgage_ExpandLenderCredits.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Credit Report", buyerCharge: 1500);
                    FastDriver.NewLoan.Mortgage_ExpandFutureRecFees.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee 1", buyerCharge: 1800);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251, sellerCharge: 151);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Settlement Date for an instance.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                FastDriver.TermsDatesStatus.DisbursementDate.Click();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Navigate to Related Parties Tab and Enter details.";
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Misc- Guarantor/Covenantor");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0007()
        {
            try
            {
                Reports.TestDescription = "MF1_010HUD: Enter details in Record /Mortgage Tab.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");

                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);
                    FastDriver.NewLoan.Mortgage_ExpandLenderCredits.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Credit Report", buyerCharge: 1500);
                    FastDriver.NewLoan.Mortgage_ExpandFutureRecFees.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee 1", buyerCharge: 1800);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251, sellerCharge: 151);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Settlement Date for an instance.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                FastDriver.TermsDatesStatus.DisbursementDate.Click();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Navigate to Related Parties Tab and Enter details.";
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Misc- Guarantor/Covenantor");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRcdgMortageeTab();
                FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                FastDriver.NewLoan.RCDG_MortageBook.FASetText("Mortgages Bible");
                FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");
                Support.AreEqual("True", FastDriver.NewLoan.RCDG_MortageTitleInsuranceMortagagee.FAGetValue().Contains("Coded UI Automation Testing").ToString());

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0008()
        {
            try
            {
                Reports.TestDescription = "MF1_011HUD: View Details in Recap Tab and Escrow File Balance Summary for CD type = CD.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);
                    FastDriver.NewLoan.Mortgage_ExpandLenderCredits.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_LenderCreditTable, "Credit Report", buyerCharge: 1500);
                    FastDriver.NewLoan.Mortgage_ExpandFutureRecFees.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee 1", buyerCharge: 1800);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251, sellerCharge: 151);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Settlement Date for an instance.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                FastDriver.TermsDatesStatus.DisbursementDate.Click();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Navigate to Related Parties Tab and Enter details.";
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Misc- Guarantor/Covenantor");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                FastDriver.NewLoan.WaitForScreenToLoad().ClickRcdgMortageeTab();
                FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                FastDriver.NewLoan.RCDG_MortageBook.FASetText("Mortgages Bible");
                FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");
                Support.AreEqual("True", FastDriver.NewLoan.RCDG_MortageTitleInsuranceMortagagee.FAGetValue().Contains("Coded UI Automation Testing").ToString());

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Recap Tab details for HUD type=HUD.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("-$37.50", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblCA").Text.Clean());
                    Support.AreEqual("-$1,902.00", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblRBL").Text.Clean());
                    Support.AreEqual("$4,460.50", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblFA").Text.Clean());
                }
                else 
                {
                    Support.AreEqual("-$862.50", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblCA").Text.Clean());
                    Support.AreEqual("-$402.00", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblRBL").Text.Clean());
                    Support.AreEqual("$8,735.50", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblFA").Text.Clean());
                }

                

                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0009()
        {
            try
            {
                Reports.TestDescription = "MF1_002: Create First New Loan with HUD type Legacy.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Click on skip button to go to QFE.";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsLoanLiability.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Select HUD Type as Legacy on New Loan screen.";
                Reports.StatusUpdate("The Legacy form type cannot be selected as field is disabled.", true);
                
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Loan Details Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("MORTLNDR", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("Cal Vet", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("V100M07", FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue());
                Support.AreEqual("L00100", FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue());
                Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.LoanDetailsSalesRep1.FAGetSelectedItem());
                Support.AreEqual("03-16-2011", FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue());
                Support.AreEqual("08-03-2012", FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue());
                Support.AreEqual("50", FastDriver.NewLoan.LoanDetailsDays.FAGetValue());
                Support.AreEqual("02-08-2013", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue());
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsRefresh.Enabled.ToString());
                Support.AreEqual("FirstAm is not responsible for this.", FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FAGetValue());
                
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0010()
        {
            try
            {
                Reports.TestDescription = "MF1_003: Enter details in Loan Charges Tab, Files with HUD Type = Legacy.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select HUD Type as Legacy on New Loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Reports.StatusUpdate("The Legacy form type cannot be selected as field is disabled.", true);
                
                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type=Legacy.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Validate Loan Charges Tab for HUD type=Legacy.";
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesPayCharges.Enabled.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.Enabled.ToString());
                    Support.AreEqual("10,000.00", FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.Enabled.ToString());
                    Support.AreEqual("Fixed Rate", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiem.Selected.ToString());
                    Support.AreEqual("1.500000", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().Clean());
                    Support.AreEqual("08-06-2012", FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue().Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.Selected.ToString());
                    Support.AreEqual("0.0000", FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue().Clean());
                    Support.AreEqual("06-27-2013", FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue().Clean());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected.ToString());
                    Support.AreEqual("487.50", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("250.00", FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue());
                    Support.AreEqual("250.00", FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesOriginationChargeCharge.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesOriginationChargeZero.Selected.ToString());
                    //Support.AreEqual("250.00", FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetValue().Clean());
                    Support.AreEqual("1.5000", FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetValue().Clean());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FAGetValue().Clean());
                    Support.AreEqual("150.00", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue().Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCharge.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsZero.Selected.ToString());
                    Support.AreEqual("-200.00", FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FAGetValue().Clean());
                    Support.AreEqual("-100.00", FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FAGetValue().Clean());
                    Support.AreEqual("1.7500", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue().Clean());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FAGetValue().Clean());
                    Support.AreEqual("175.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue().Clean());
                    Support.AreEqual("1,500.00", FastDriver.NewLoan.LenderCreditsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("1,800.00", FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("70.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("6", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("30.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentZero.Selected.ToString());
                    Support.AreEqual("-50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue().Clean());
                    Support.AreEqual("101.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FAGetValue().Clean());
                }
                else
                {
                    Reports.StatusUpdate("Test cannot be executed for CD type files, as its scope is to test HUD type Legacy.", true);
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0011()
        {
            try
            {
                Reports.TestDescription = "MF1_006: Enter details in Mortgage Broker Tab with HUD Type = Legacy.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                  
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                    FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                    FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                    Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                    FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                    
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    
                    Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                    FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                    FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Validate Mortgage Broker for a Instance.";
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                    Support.AreEqualTrim("247", FastDriver.NewLoan.MortgageBrokerGABlabel.Text.Clean());
                    Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.MortgageSalesRep1.FAGetSelectedItem());
                    Support.AreEqual("51.00", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("251.00", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("151.00", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }
                else
                {
                    Reports.StatusUpdate("The scope of this test does not contain any flows for CD type files.", true);
                    FastDriver.WebDriver.Quit();
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }

        [TestMethod]
        public void FMUC0047_BAT0012()
        {
            try
            {
                Reports.TestDescription = "MF1_007Legacy: Enter details in Note Tab.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

               if (!AutoConfig.UseCDFormType)
               {
                   FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                   FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                   FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                   FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                   Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                   FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                   Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                   FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                   FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                   FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                   Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                   FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                   FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                   FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                   FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                   FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                   FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                   FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                   FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                   FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                   Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                   FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                   FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                   FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                   FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                   FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                   FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                   FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                   FastDriver.DialogBottomFrame.ClickDone();
                   FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                   FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                   Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                   FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                   FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                   FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                   FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51);
                   FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);

                   Reports.TestStep = "Navigate to Note Tab and Enter details.";
                   FastDriver.NewLoan.ClickNoteTab();
                   FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                   FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                   FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                   FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                   FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                   FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                   FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                   FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                   FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                   FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                   FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                   Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                   FastDriver.BottomFrame.Done();
                   FastDriver.NewLoan.WaitForScreenToLoad();

                   Reports.TestStep = "Enter the Settlement Date for an instance.";
                   FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                   FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                   FastDriver.TermsDatesStatus.DisbursementDate.Click();
                   FastDriver.BottomFrame.Done();

                   Reports.TestStep = "Validate Note Tab.";
                   FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                   FastDriver.NewLoan.ClickNoteTab();
                   Support.AreEqual("true", FastDriver.NewLoan.NoteConstructionMortgage.FAGetAttribute("checked").ToString());
                   Support.AreEqual("true", FastDriver.NewLoan.NoteBalloonPayment.FAGetAttribute("checked").ToString());
                   Support.AreEqual("true", FastDriver.NewLoan.NoteLateChargeof_checkbox.FAGetAttribute("checked").ToString());
                   Support.AreEqual("True", FastDriver.NewLoan.NoteLateChargeof_Percentageradio.Selected.ToString());
                   Support.AreEqual("5.0000", FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FAGetValue());
                   Support.AreEqual("15", FastDriver.NewLoan.NoteLateChargeofDays.FAGetValue());
                   Support.AreEqual("08-11-2012", FastDriver.NewLoan.NoteInterestFrom.FAGetValue());
                   Support.AreEqual("11-06-2012", FastDriver.NewLoan.NoteFirstPaymentDue.FAGetValue());
                   Support.AreEqual("2,500.00", FastDriver.NewLoan.NotePaymentAmount.FAGetValue());
                   Support.AreEqual("Quarter", FastDriver.NewLoan.NotePayablePer.FAGetSelectedItem());
                   Support.AreEqual("1", FastDriver.NewLoan.NoteLoanTerm.FAGetValue());
                }
                else
                {
                    Reports.StatusUpdate("No flow included in this test for CD type files.", true);
                    FastDriver.WebDriver.Quit();
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0013()
        {
            try
            {
                Reports.TestDescription = "MF1_008Legacy: Enter details in Parties Tab.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                    FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                    FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                    Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                    FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                    FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                    FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                    FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);

                    Reports.TestStep = "Navigate to Note Tab and Enter details.";
                    FastDriver.NewLoan.ClickNoteTab();
                    FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                    FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                    FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                    FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                    FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                    FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                    FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                    FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                    Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForScreenToLoad();

                    Reports.TestStep = "Enter the Settlement Date for an instance.";
                    FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                    FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                    FastDriver.TermsDatesStatus.DisbursementDate.Click();
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    FastDriver.NewLoan.PartiesFindGAB("247");
                    FastDriver.NewLoan.PartiesAttention.FASelectItem(@"L247");
                    FastDriver.NewLoan.PartiesSalesRep1.FASelectItem(@"FATICO, Firstam");
                    FastDriver.NewLoan.PartiesReference.FASetText(@"Mohanty");
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Validate Parties Tab.";
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    Support.AreEqual("Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname", FastDriver.NewLoan.PartiesTrustorMortgagor.FAGetValue());
                    Support.AreEqual("Mortgage Lender 1 Name 1, Mortgage Lender 1 Name 2", FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FAGetValue());
                    Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.PartiesSalesRep1.FAGetSelectedItem());
                    Support.AreEqual("L247", FastDriver.NewLoan.PartiesAttention.FAGetSelectedItem());
                    Support.AreEqual("Mohanty", FastDriver.NewLoan.PartiesReference.FAGetValue());
                }
                else
                {
                    Reports.StatusUpdate("No flow included in this test for CD type files.", true);
                    FastDriver.WebDriver.Quit();
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0014()
        {
            try
            {
                Reports.TestDescription = "MF1_009Legacy: Enter details in Related Parties Tab.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                    FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                    FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                    Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                    FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                    FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                    FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                    FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);

                    Reports.TestStep = "Navigate to Note Tab and Enter details.";
                    FastDriver.NewLoan.ClickNoteTab();
                    FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                    FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                    FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                    FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                    FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                    FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                    FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                    FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                    Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForScreenToLoad();

                    Reports.TestStep = "Enter the Settlement Date for an instance.";
                    FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                    FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                    FastDriver.TermsDatesStatus.DisbursementDate.Click();
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    FastDriver.NewLoan.PartiesFindGAB("247");
                    FastDriver.NewLoan.PartiesAttention.FASelectItem(@"L247");
                    FastDriver.NewLoan.PartiesSalesRep1.FASelectItem(@"FATICO, Firstam");
                    FastDriver.NewLoan.PartiesReference.FASetText(@"Mohanty");
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Validate Parties Tab.";
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    Support.AreEqual("Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname", FastDriver.NewLoan.PartiesTrustorMortgagor.FAGetValue());
                    Support.AreEqual("Mortgage Lender 1 Name 1, Mortgage Lender 1 Name 2", FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FAGetValue());
                    Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.PartiesSalesRep1.FAGetSelectedItem());
                    Support.AreEqual("L247", FastDriver.NewLoan.PartiesAttention.FAGetSelectedItem());
                    Support.AreEqual("Mohanty", FastDriver.NewLoan.PartiesReference.FAGetValue());

                    Reports.TestStep = "Navigate to Related Parties Tab and Enter details.";
                    FastDriver.NewLoan.ClickRelatedPartiesTab();
                    FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                    FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Misc- Guarantor/Covenantor");
                    FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    Reports.StatusUpdate("No flow included in this test for CD type files.", true);
                    FastDriver.WebDriver.Quit();
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0015()
        {
            try
            {
                Reports.TestDescription = "MF1_010Legacy: Enter details in Record /Mortgage Tab.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                    FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                    FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                    Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                    FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                    FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                    FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                    FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);

                    Reports.TestStep = "Navigate to Note Tab and Enter details.";
                    FastDriver.NewLoan.ClickNoteTab();
                    FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                    FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                    FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                    FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                    FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                    FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                    FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                    FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                    Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForScreenToLoad();

                    Reports.TestStep = "Enter the Settlement Date for an instance.";
                    FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                    FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                    FastDriver.TermsDatesStatus.DisbursementDate.Click();
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    FastDriver.NewLoan.PartiesFindGAB("247");
                    FastDriver.NewLoan.PartiesAttention.FASelectItem(@"L247");
                    FastDriver.NewLoan.PartiesSalesRep1.FASelectItem(@"FATICO, Firstam");
                    FastDriver.NewLoan.PartiesReference.FASetText(@"Mohanty");
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Validate Parties Tab.";
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    Support.AreEqual("Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname", FastDriver.NewLoan.PartiesTrustorMortgagor.FAGetValue());
                    Support.AreEqual("Mortgage Lender 1 Name 1, Mortgage Lender 1 Name 2", FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FAGetValue());
                    Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.PartiesSalesRep1.FAGetSelectedItem());
                    Support.AreEqual("L247", FastDriver.NewLoan.PartiesAttention.FAGetSelectedItem());
                    Support.AreEqual("Mohanty", FastDriver.NewLoan.PartiesReference.FAGetValue());

                    Reports.TestStep = "Navigate to Related Parties Tab and Enter details.";
                    FastDriver.NewLoan.ClickRelatedPartiesTab();
                    FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                    FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Misc- Guarantor/Covenantor");
                    FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                    FastDriver.NewLoan.WaitForScreenToLoad().ClickRcdgMortageeTab();
                    FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                    FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                    FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                    FastDriver.NewLoan.RCDG_MortageBook.FASetText("Mortgages Bible");
                    FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");
                    Support.AreEqual("True", FastDriver.NewLoan.RCDG_MortageTitleInsuranceMortagagee.FAGetValue().Contains("Coded UI Automation Testing").ToString());

                    Reports.TestStep = "Click on Done.";
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    Reports.StatusUpdate("No flow included in this test for CD type files.", true);
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0016()
        {
            try
            {
                Reports.TestDescription = "MF1_012Legacy: View Details in Recap Tab and Escrow File Balance Summary for HUD type= Legacy.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                    FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                    FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                    Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                    FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                    FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                    FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                    FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);

                    Reports.TestStep = "Navigate to Note Tab and Enter details.";
                    FastDriver.NewLoan.ClickNoteTab();
                    FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                    FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                    FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                    FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                    FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                    FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                    FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                    FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                    Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForScreenToLoad();

                    Reports.TestStep = "Enter the Settlement Date for an instance.";
                    FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                    FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                    FastDriver.TermsDatesStatus.DisbursementDate.Click();
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    FastDriver.NewLoan.PartiesFindGAB("247");
                    FastDriver.NewLoan.PartiesAttention.FASelectItem(@"L247");
                    FastDriver.NewLoan.PartiesSalesRep1.FASelectItem(@"FATICO, Firstam");
                    FastDriver.NewLoan.PartiesReference.FASetText(@"Mohanty");
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Validate Parties Tab.";
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    Support.AreEqual("Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname", FastDriver.NewLoan.PartiesTrustorMortgagor.FAGetValue());
                    Support.AreEqual("Mortgage Lender 1 Name 1, Mortgage Lender 1 Name 2", FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FAGetValue());
                    Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.PartiesSalesRep1.FAGetSelectedItem());
                    Support.AreEqual("L247", FastDriver.NewLoan.PartiesAttention.FAGetSelectedItem());
                    Support.AreEqual("Mohanty", FastDriver.NewLoan.PartiesReference.FAGetValue());

                    Reports.TestStep = "Navigate to Related Parties Tab and Enter details.";
                    FastDriver.NewLoan.ClickRelatedPartiesTab();
                    FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                    FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Misc- Guarantor/Covenantor");
                    FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                    FastDriver.NewLoan.WaitForScreenToLoad().ClickRcdgMortageeTab();
                    FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                    FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                    FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                    FastDriver.NewLoan.RCDG_MortageBook.FASetText("Mortgages Bible");
                    FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");
                    Support.AreEqual("True", FastDriver.NewLoan.RCDG_MortageTitleInsuranceMortagagee.FAGetValue().Contains("Coded UI Automation Testing").ToString());
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Validate Recap Tab details for HUD type=HUD.";
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                    Support.AreEqual("-$37.50", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblCA").Text.Clean());
                    Support.AreEqual("-$402.00", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblRBL").Text.Clean());
                    Support.AreEqual("$7,811.50", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblFA").Text.Clean());
                }
                else
                {
                    Reports.StatusUpdate("No flow included in this test for CD type files.", true);
                }

                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0017()
        {
            try
            {
                Reports.TestDescription = "MF1_012Legacy: View Details in Recap Tab and Escrow File Balance Summary for HUD type= Legacy.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsEnds.FASetText("02-08-2013");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                    FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                    FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                    Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                    FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                    FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                    FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                    FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251, sellerCharge: 151);

                    Reports.TestStep = "Navigate to Note Tab and Enter details.";
                    FastDriver.NewLoan.ClickNoteTab();
                    FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                    FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                    FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                    FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                    FastDriver.NewLoan.NoteInterestFrom.FASetText("08/11/2012");
                    FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11/06/2012");
                    FastDriver.NewLoan.NotePaymentAmount.FASetText("2500");
                    FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                    FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                    Support.AreEqual("True", FastDriver.NewLoan.NoteLoanterm_Year.Selected.ToString());
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForScreenToLoad();

                    Reports.TestStep = "Enter the Settlement Date for an instance.";
                    FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                    FastDriver.TermsDatesStatus.SettlementDate.FASetText("12-13-2013");
                    FastDriver.TermsDatesStatus.DisbursementDate.Click();
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    FastDriver.NewLoan.PartiesFindGAB("247");
                    FastDriver.NewLoan.PartiesAttention.FASelectItem(@"L247");
                    FastDriver.NewLoan.PartiesSalesRep1.FASelectItem(@"FATICO, Firstam");
                    FastDriver.NewLoan.PartiesReference.FASetText(@"Mohanty");
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Validate Parties Tab.";
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickPartiesTab();
                    Support.AreEqual("Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname", FastDriver.NewLoan.PartiesTrustorMortgagor.FAGetValue());
                    Support.AreEqual("Mortgage Lender 1 Name 1, Mortgage Lender 1 Name 2", FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FAGetValue());
                    Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.PartiesSalesRep1.FAGetSelectedItem());
                    Support.AreEqual("L247", FastDriver.NewLoan.PartiesAttention.FAGetSelectedItem());
                    Support.AreEqual("Mohanty", FastDriver.NewLoan.PartiesReference.FAGetValue());

                    Reports.TestStep = "Navigate to Related Parties Tab and Enter details.";
                    FastDriver.NewLoan.ClickRelatedPartiesTab();
                    FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                    FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Misc- Guarantor/Covenantor");
                    FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                    FastDriver.NewLoan.WaitForScreenToLoad().ClickRcdgMortageeTab();
                    FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                    FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                    FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                    FastDriver.NewLoan.RCDG_MortageBook.FASetText("Mortgages Bible");
                    FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");
                    Support.AreEqual("True", FastDriver.NewLoan.RCDG_MortageTitleInsuranceMortagagee.FAGetValue().Contains("Coded UI Automation Testing").ToString());
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Validate Recap Tab details for HUD type=HUD.";
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                    Support.AreEqual("-$37.50", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblCA").Text.Clean());
                    Support.AreEqual("-$402.00", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblRBL").Text.Clean());
                    Support.AreEqual("$7,811.50", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblFA").Text.Clean());

                    Reports.TestStep = "Validate Loan Amount in Screen for Legacy.";
                    FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                    Support.AreEqual("10,000.00", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean());
                }
                else
                {
                    Reports.StatusUpdate("No flow included in this test for CD type files.", true);
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0018()
        {
            try
            {
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        }

                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LendersAttorney,
                        },
                    }
                };
                #endregion

                Reports.TestDescription = "AF2_001: Create a New Loan from Quick File Entry Us Mortgage Broker Additional Role.";
                Reports.TestStep = "Create a basic order with additional role in Business Source and Associated Business Party.";
                Login(AutoConfig.FASTHomeURL);
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                //FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                //FastDriver.FileHomepage.BusinessPartyAttention.FASelectItem("CNTCTMortLNDR Name 2, CNTCTMortLNDR Name 1");
                //FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                //FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                //FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.BottomFrame.Save();
                //FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("MORTLNDR", FastDriver.NewLoan.MortgageBrokerGABlabel.Text.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0019()
        {
            try
            {
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        }

                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LendersAttorney,
                        },
                    }
                };
                #endregion

                Reports.TestDescription = "AF3_001: Create a New Loan from Quick File Entry Us Lender’s Attorney Additional Role.";
                Reports.TestStep = "Create a basic order with additional role in Business Source and Associated Business Party.";
                Login(AutoConfig.FASTHomeURL);
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                Support.AreEqual("247", FastDriver.NewLoan.RelatedPartiesGABCodeLabel.Text.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0020()
        {
            try
            {
                Reports.TestDescription = "AF4_001: Create a New Loan from Quick File Entry Us New Lender Information.";
                Reports.TestStep = "Create a basic order with additional role in Business Source and Associated Business Party.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0021()
        {
            try
            {
                Reports.TestDescription = "AF5_001: Create a New Loan from Quick File Entry Us First New Loan Amount.";
                Reports.TestStep = "Create a basic order with additional role in Business Source and Associated Business Party.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                Support.AreEqual("5,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0022()
        {
            try
            {
                Reports.TestDescription = "AF6_001: Edit a New Loan.";
                Reports.TestStep = "Create a basic order with additional role in Business Source and Associated Business Party.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Loan Details";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000.00");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Amount after the edit.";
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0022_SetUp()
        {
            try
            {
                Reports.TestDescription = "Setup For BAT22 and Main Flow QC@Closing Tab";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Selecting Region to have Region-level access";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Search for 247 Gab Id code.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.SearchAddressBook("247");
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                if (FastDriver.BusPartyOrgSetUp.QCClosingClient.Selected == false)
                {
                    FastDriver.BusPartyOrgSetUp.QCClosingClient.FASetCheckbox(true);
                    FastDriver.BottomFrame.Done();
                    FastDriver.WebDriver.Quit();
                }
                else
                {
                    Reports.StatusUpdate("QC @ Closing option appears as checked", true);
                    FastDriver.BottomFrame.Done();
                    FastDriver.AddressBookSearch.WaitForScreenToLoad();
                    FastDriver.WebDriver.Quit();
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0023()
        {
            try
            {
                Reports.TestDescription = "AF8_001: Remove a Mortgage Broker or Lender and Retain Charges.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString());
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Remove Mortgage Broker from a New Loan Entry.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("", FastDriver.NewLoan.MortgageBrokerGABlabel.Text.Clean());
                Support.AreEqual("250.00", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("150.00", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0024()
        {
            try
            {
                Reports.TestDescription = "AF9_001: Cancel 1st New “New Loan” Instance Creation.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)5000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)5000.00;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Details After canceling the instance.";
                Support.AreEqual("", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("5,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().Clean());
                Support.AreEqual("5,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue().Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0025()
        {
            try
            {
                Reports.TestDescription = "AF10_001: Cancel 2nd New “New Loan” Instance Creation.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create 2nd New Instance of New Loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Validate Loan Details Tab.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("MORTLNDR", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("V100M07", FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue());
                Support.AreEqual("L00100", FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue());
                Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.LoanDetailsSalesRep1.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsRefresh.Enabled.ToString());
                Support.AreEqual("FirstAm is not responsible for this.", FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FAGetValue());

                Reports.TestStep = "Click on New and Enter details for a New Loan.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("VG100D");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L1001");
                FastDriver.NewLoan.FindGABCode("HUDASLNDR1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Details Tab.";
                Support.AreEqual("HUDASLNDR1", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("1,200.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("1,200.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0026()
        {
            try
            {
                Reports.TestDescription = "AF12_001: Cancel Changes to Exist “New Loan” Instance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("5,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("5,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0027()
        {
            try
            {
                Reports.TestDescription = "AF13_001: Enter Yield Spread Premium Charge and method CHK.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Details Tab.";
                Support.AreEqual("MORTLNDR", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("V100M07", FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue());
                Support.AreEqual("L00100", FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue());
                Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.LoanDetailsSalesRep1.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsRefresh.Enabled.ToString());
                Support.AreEqual("FirstAm is not responsible for this.", FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FAGetValue());

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                Support.AreEqual("true", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAGetAttribute("checked"));
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Validate Loan Charges Tab.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesPayCharges.Enabled.ToString());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.Enabled.ToString());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.Enabled.ToString());
                Support.AreEqual("Fixed Rate", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiem.Selected.ToString());
                Support.AreEqual("1.500000", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().Clean());
                Support.AreEqual("08-06-2012", FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue().Clean());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.Selected.ToString());
                Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.Selected.ToString());
                Support.AreEqual("0.0000", FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue().Clean());
                Support.AreEqual("06-27-2013", FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue().Clean());
                Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected.ToString());
                Support.AreEqual("487.50", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("250.00", FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue());
                    Support.AreEqual("250.00", FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesOriginationChargeCharge.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesOriginationChargeZero.Selected.ToString());
                    //Support.AreEqual("250.00", FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetValue().Clean());
                    Support.AreEqual("1.5000", FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetValue().Clean());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FAGetValue().Clean());
                    Support.AreEqual("150.00", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue().Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCharge.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsZero.Selected.ToString());
                    Support.AreEqual("-200.00", FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FAGetValue().Clean());
                    Support.AreEqual("-100.00", FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FAGetValue().Clean());
                    Support.AreEqual("1.7500", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue().Clean());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FAGetValue().Clean());
                    Support.AreEqual("175.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue().Clean());
                    Support.AreEqual("1,500.00", FastDriver.NewLoan.LenderCreditsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("1,800.00", FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("70.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("6", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("30.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentZero.Selected.ToString());
                    Support.AreEqual("-50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue().Clean());
                    Support.AreEqual("101.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FAGetValue().Clean());
                }
                else
                {
                    Support.AreEqual("250.00", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("175.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("100.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("1.750", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue());
                    Support.AreEqual("5", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("70.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("6", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("30.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue().Clean());
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB("247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsNewLoanDlg.FileCharge.FASetText("50");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("CHK", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FAGetSelectedItem());
                }
                else
                {
                    Support.AreEqual("Check", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FAGetSelectedItem());
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Mortgage Broker CHK amount and YSP in Recap Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("247", FastDriver.NewLoan.MortgageBrokerGABlabel.Text.Clean());
                Support.AreEqual("50.00", FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue());

                Reports.TestStep = "Validate Mortgage Broker CHK amount and YSP in Recap Tab.";
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblTH").Text.Contains("Lenders Advantage").ToString());

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0028()
        {
            try
            {
                Reports.TestDescription = "AF14_001: Change Yield Spread Premium Payment Method to POC.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD type = CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB("247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsNewLoanDlg.FileCharge.FASetText("50");
                FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the System does not add Yield Spread Premium charge to mortgage broker’s check amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("2", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString());

                Reports.TestStep = "Validate Mortgage Broker CHK amount and YSP in Recap Tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("POC", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.ClassName,"HUDCDPOC").Text.Clean());
                }
                else
                {
                    Support.AreEqual("Paid by Others - POC", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.ClassName, "HUDCDPOC").Text.Clean());
                }
                
                Support.AreEqual("$50.00", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblMPOC").Text.Clean());

                Reports.TestStep = "Verify that YSP is not listed in Loan Proceeds";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.Text.Contains("50.00").ToString());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
                
        }

        [TestMethod]
        public void FMUC0047_BAT0029()
        {
            try
            {
                Reports.TestDescription = "AF15_001: Add Second New Loan from Process Screen.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Details Tab.";
                Support.AreEqual("MORTLNDR", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("V100M07", FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue());
                Support.AreEqual("L00100", FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue());
                Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.LoanDetailsSalesRep1.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsRefresh.Enabled.ToString());
                Support.AreEqual("FirstAm is not responsible for this.", FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FAGetValue());

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                Support.AreEqual("true", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAGetAttribute("checked"));
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                Support.AreEqual("true", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAGetAttribute("checked"));
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("101.00");

                    Reports.TestStep = "Enter Charges in GF#6 and 7 in Loan Charge page";
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LenderCreditsTable, "Appraisal Fee", buyerCharge: 1500.00);
                    FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee 1", buyerCharge: 1800.00);
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_PaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                {
                    //
                    FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Validate Loan Charges Tab.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesPayCharges.Enabled.ToString());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.Enabled.ToString());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.Enabled.ToString());
                Support.AreEqual("Fixed Rate", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiem.Selected.ToString());
                Support.AreEqual("1.500000", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().Clean());
                Support.AreEqual("08-06-2012", FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue().Clean());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.Selected.ToString());
                Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.Selected.ToString());
                Support.AreEqual("0.0000", FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue().Clean());
                Support.AreEqual("06-27-2013", FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue().Clean());
                Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.Selected.ToString());
                Support.AreEqual("487.50", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("250.00", FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesOriginationChargeCharge.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesOriginationChargeZero.Selected.ToString());
                    Support.AreEqual("1.5000", FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetValue().Clean());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FAGetValue().Clean());
                    Support.AreEqual("150.00", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue().Clean());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCharge.Selected.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsZero.Selected.ToString());
                    Support.AreEqual("-200.00", FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FAGetValue().Clean());
                    Support.AreEqual("-100.00", FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FAGetValue().Clean());
                    Support.AreEqual("1.7500", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue().Clean());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FAGetValue().Clean());
                    Support.AreEqual("175.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue().Clean());
                    Support.AreEqual("1,500.00", FastDriver.NewLoan.LenderCreditsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("1,800.00", FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("70.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("6", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("30.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentZero.Selected.ToString());
                    Support.AreEqual("-50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue().Clean());
                    Support.AreEqual("101.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FAGetValue().Clean());
                }
                else
                {
                    Support.AreEqual("250.00", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("175.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("100.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("1.750", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue());
                    Support.AreEqual("5", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("70.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("6", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("5.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("30.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue().Clean());
                }

                Reports.TestStep = "Enter details for a New Loan.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("VG100D");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L1001");
                FastDriver.NewLoan.FindGABCode("HUDASLNDR1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate The 2nd Instance Created.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                Support.AreEqual("1,200.00", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.GetText).Message.Clean());
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate The 2nd Instance Created Details";
                Support.AreEqual("Cal Vet", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("1,200.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0030()
        {
            try
            {
                Reports.TestDescription = "AF16_001: Create a New Loan from Quick File Entry Us Lender’s Related Party Additional Role.";
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    }
                };
                #endregion

                Login(AutoConfig.FASTHomeURL);
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                Support.AreEqual("Lender- Originating Branch", FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tRP_NLRP_grdPaye_0_ddlRT").FAGetSelectedItem());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0031()
        {
            try
            {
                Reports.TestDescription = "AF17_EF1_001: Create Related Party.";
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    }
                };
                #endregion

                Login(AutoConfig.FASTHomeURL);
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");

                Reports.TestStep = "Select a new Role in Related Parties Tab.";
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.SelectItemBySendkeys, "Lender- Originating Branch");
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate Related Parties Tab.";
                FastDriver.NewLoan.SwitchToContentFrame();
                Support.AreEqual("Lender- Originating Branch", FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tRP_NLRP_grdPaye_0_ddlRT").FAGetSelectedItem());
                Support.AreEqual("Lender- Funding", FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tRP_NLRP_grdPaye_1_ddlRT").FAGetSelectedItem());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0032()
        {
            try
            {
                Reports.TestDescription = "AF19_AF21_001: Manually Set Account Service product Status for Loan Instance.";
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    }
                };
                #endregion

                Login(AutoConfig.FASTHomeURL);
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Details Tab.";
                Support.AreEqual("247", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                Support.AreEqual("Lender- Originating Branch", FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tRP_NLRP_grdPaye_0_ddlRT").FAGetSelectedItem());


            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0033()
        {
            try
            {
                Reports.TestDescription = "AF20_001: Manually Set Account Service product Status for Loan Instance to a Non-Candidate status.";
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    }
                };
                #endregion

                Login(AutoConfig.FASTHomeURL);
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Details Tab.";
                Support.AreEqual("247", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0034()
        {
            try
            {
                Reports.TestDescription = "AF18_001: Add Third/Subsequent New Loan from Summary.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter values to New Loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("123456");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                
                Reports.TestStep = "Enter values to New Loan screen.";
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100.00");
                FastDriver.NewLoan.FindGABCode("256");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Validate The 3rd Instance Creation.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                Support.AreEqual("100.00", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 3, TableAction.GetText).Message.Clean());
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();

                Reports.TestStep = "Validate Loan Details Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("256", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("Cal Vet", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("100.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("100.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0035()
        {
            try
            {
                Reports.TestDescription = "AF11_001: Cancel 3rd / Subsequent “ New Loan” Instance Creation.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter values to New Loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("123456");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Enter values to New Loan screen.";
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100.00");
                FastDriver.NewLoan.FindGABCode("256");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0036()
        {
            try
            {
                Reports.TestDescription = "AF7_001: Delete a New Loan Instance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Edit Fields in New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter values to New Loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("123456");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItem("L247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Delete Instance from Summary.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                Support.AreEqual("L247", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 4, TableAction.GetText).Message.Clean());
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 4, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                Support.AreEqual("Available", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_BAT0037()
        {
            try
            {
                Reports.TestDescription = "AF17_EF2_001: Create Related Party (Ad Hoc).";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Loan Details Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("MORTLNDR", FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text.Clean());
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("V100M07", FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue());
                Support.AreEqual("L00100", FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue());
                Support.AreEqual("FATICO, Firstam", FastDriver.NewLoan.LoanDetailsSalesRep1.FAGetSelectedItem());
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsRefresh.Enabled.ToString());
                Support.AreEqual("FirstAm is not responsible for this.", FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FAGetValue());
                FastDriver.NewLoan.ClickRelatedPartiesTab();

                Reports.TestStep = "Add a Ad Hoc Contact.";
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Attorney- Primary");
                FastDriver.NewLoan.RelatedPartiesRelatedParty_Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FindContact(IDCode: "247");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                FastDriver.GABEntryRequestDlg.WaitForDialogToLoad();
                FastDriver.GABEntryRequestDlg.BuyerSellerType.FASelectItem("Business Entity");
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem("Lender");
                FastDriver.GABEntryRequestDlg.Name1.FASetText("Barack Obama");
                FastDriver.GABEntryRequestDlg.BusinessPhoneNumber.FASetText("7587857412");
                FastDriver.GABEntryRequestDlg.BusinessPhoneExtension.FASetText("155");
                FastDriver.GABEntryRequestDlg.EmailNumber.FASetText("barack.obama@whitehouse.gov");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText("455 Main St");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText("MIDWAY");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem("TX");
                FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText("96015");
                FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText("HILL");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        #endregion

        #region REGRESSION
        [TestMethod]
        public void FMUC0047_REG0001()
        {
            try
            {
                Reports.TestDescription = "BR_FM1079_ES7235_FM1577_FM1384_FM3579_0001: 1. Create New Loan 1 Entry 2. New Loans on Different File Service Types 3. Use New Loan 1 Charge Setup Template for 1st New Loan 4. Required Data for New loan 5. Default";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Validate New Loan after creating a QFE.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                Support.AreEqual("6,500.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("6,500.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("247", FastDriver.NewLoan.MortgageBrokerGABlabel.Text.Clean());
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                Support.AreEqual("Lender- Originating Branch", FastDriver.NewLoan.RelatedPartyRoletype.FAGetSelectedItem());
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0002()
        {
            try
            {
                Reports.TestDescription = "BR_FM3522_FM1227_FM1088_FM1009_0001: 1. Use New Loan 2+ Charge Template for 2nd+ Instances 2. Number New Loans in Summary 3. Lender for New Loan 4. Select Loan Type.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details for a New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200.00");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("VG100D");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L1001");
                FastDriver.NewLoan.FindGABCode("HUDASLNDR1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Validate an 1st instance Creation.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                Support.AreEqual("6,500.00", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate an instance Creation.";
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                Support.AreEqual("1,200.00", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Select New to create a New Loan.";
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItem("L247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate an instance Creation.";
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 3, TableAction.Click);
                Support.AreEqual("L247", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 4, TableAction.GetText).Message.Clean());
                FastDriver.NewLoanSummary.New.FAClick();

                Reports.TestStep = "Verify the If the user selects the Mortgage Product, then system will auto-filter the Loan Type dropdown list based on the Mortgage Product selected.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("177");
                FastDriver.NewLoan.LoanDetailsMortgageProduct.FASelectItem("50 - i Declare - Regular");
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsLoantype.Text.Contains("Cal Vet").ToString());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Loan Type is populated, and user selects or changes the Mortgage Product, then the system will overwrite the existing Loan Type value with the new Loan Type dropdown list for the newly selected Mortgage Product.";
                
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Lender");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                FastDriver.GABEntryRequestDlg.WaitForDialogToLoad();
                FastDriver.GABEntryRequestDlg.BuyerSellerType.FASelectItem("Business Entity");
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem("Lender");
                FastDriver.GABEntryRequestDlg.Name1.FASetText("Bill Gates");
                FastDriver.GABEntryRequestDlg.BusinessPhoneNumber.FASetText("7587857412");
                FastDriver.GABEntryRequestDlg.BusinessPhoneExtension.FASetText("155");
                FastDriver.GABEntryRequestDlg.EmailNumber.FASetText("bill.gates@microsoft.com");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText("455 Main St");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText("MIDWAY");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem("TX");
                FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText("96015");
                FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText("HILL");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.NewLoan.LoanDetailsMortgageProduct.Enabled.ToString());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_FM3523_0001: 1. Charge Setup Template for Seq. Number of Deleted Instance.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details for a New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200.00");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("VG100D");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L1001");
                FastDriver.NewLoan.FindGABCode("HUDASLNDR1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select a Instance and remove it.";
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select a Deleted New Loan Instance to Edit.";
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000.00");
                FastDriver.NewLoan.FindGABCode("HUDOTHRBR2");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("Regression is on progress.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the New Loan Template is Updated with recently entered information ";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 3, TableAction.Click);
                Support.AreEqual("(710)5458584", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 5, TableAction.GetText).Message.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_FM1385_FM2236_0001: 1. Use Another Entity Type 2. Remove Lender.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details for a New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200.00");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("VG100D");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L1001");
                FastDriver.NewLoan.FindGABCode("HUDASLNDR1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select New to create a New Loan.";
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("200.00");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Mortgage Broker", EntityName: "a*");
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Enter details for Mortgage Broker Tab.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Remove newly created instance.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0005()
        {
            try
            {
                Reports.TestDescription = "REG_0001: (BR_FM1010_FM1510_FM1389_FM1277_FM1390_FM1278_FM1425_FM1279_ES7290_ES7291_ES7292_ES7293_ES7221_FM2240_FM2241_FM4385_FM1014_FM1018_FM1019_FM1225_ES7223_ES7222_FM4342_0001) 1. Loan Amount 2.Copy Loan Amount to Bu";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details for a New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("6750.00");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V0110NL");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("LN00102");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("60");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("Regression is on progress.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");

                Reports.TestStep = "Validate functionality for New Loan.";
                Support.AreEqual("Cal Vet", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("7,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("6,750.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("V0110NL", FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue());
                Support.AreEqual("LN00102", FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue());

                Reports.TestStep = "Validate Updating to Loan Charges Tab Buyer Credit.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                Support.AreEqual("7,000.00", FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());

                Reports.TestStep = "Enter Details for a 2nd New Loan.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500.00");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("450.00");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("VA110W");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("NL1231");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                //Test UAT-INC2933058;
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();
                //FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Enter the Loan Details in 3rd New Loan.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000.00");
                FastDriver.NewLoan.FindGABCode("HUDOTHRBR2");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12/12/2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("Regression is in progress.");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to TDS Screen and Validate Loan Amount and Loan Liability Amt.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("7,000.00", FastDriver.TermsDatesStatus.FirstNewLoan.FAGetValue());
                Support.AreEqual("6,750.00", FastDriver.TermsDatesStatus.FirstNewLoanLiability.FAGetValue());
                Support.AreEqual("500.00", FastDriver.TermsDatesStatus.SecondNewLoan.FAGetValue());
                Support.AreEqual("450.00", FastDriver.TermsDatesStatus.SecondNewLoanLiability.FAGetValue());
                FastDriver.BottomFrame.Done();
                

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0006()
        {
            try
            {
                Reports.TestDescription = "REG_0002: (FM1291_FM1292_FM1294_FM1297_FM1250_ES10937_FM984_FM988_FM985_FM986_FM1392_FM1100_FM1100_FM1101_FM990_FM994_FM996_FM1249_0001) 1. Hazard Ins. Loss Payee Clause 2.Enter Hazard Ins. Loss Payee 3.Edit Hazard Ins.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details for a New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200.00");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("VG100D");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L1001");
                FastDriver.NewLoan.FindGABCode("HUDASLNDR1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Select on a Instance for edit.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("Regression");
                //Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayeebrokenlinkgif.Exists().ToString());

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-15-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("12-26-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercredit.FASetText("50.00");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 4, TableAction.SetText, "50");
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                }
                else 
                {
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 4, TableAction.SetText, "50");
                    FastDriver.NewLoan.CreditChargeIRSPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                }
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("133.00", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FASetText("10.00");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCharge: 50.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 50.00);
                }
                
                Support.AreEqual("50.00", FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }

        [TestMethod]
        public void FMUC0047_REG0007()
        {
            try
            {
                Reports.TestDescription = "FM995_0001: 1.Enter Flat Charge Amount.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details for a New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200.00");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("VG100D");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L1001");
                FastDriver.NewLoan.FindGABCode("HUDASLNDR1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Select on a Instance for edit.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", buyerCharge: 100.00);
                }
                else 
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", buyerCharge: 100.00);
                }
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM998_0001: 1. Change Loan Origination Fee Charge Pmt Method.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details for a New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200.00");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("VG100D");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L1001");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Select on a Instance for edit.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Change the Payment method for origination Charges.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", buyerCharge: 100.00);
                    FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("RBL", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FAGetSelectedItem());
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", buyerCharge: 100.00);
                    FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual("RBL", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem());
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0009()
        {
            try
            {
                Reports.TestDescription = "REG_0003: (FM1393_FM1102_FM997_FM1108_FM1243_FM1167_FM1170_FM1171_FM1254_FM1253_FM1022_FM1172_FM1173_FM1174_FM1175_FM1375_FM1244_0001) 1. Redistribute Charge Amount 2. Loan Discount Points Charge 3.Update Loan Discount P";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Validate AAA charge in Loan Charges Tab and Impounds Description.";
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("Appraisal fee", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("Credit report", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(3, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("Homeowner's insurance", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("Mortgage insurance", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("70.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("30.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue());
                    Support.AreEqual("50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FAGetValue());
                }
                else
                {
                    Support.AreEqual("Appraisal Fee", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("Credit Report", FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(3, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("Homeowner's Insurance", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("Mortgage Insurance", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(3, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("70.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("30.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue());
                    Support.AreEqual("50.00", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FAGetValue());
                }
                

                Reports.TestStep = "Change AAA to Zero.";
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentZero.FAClick();

                Reports.TestStep = "Edit Monthly Charge in Impounds.";
                if (!AutoConfig.UseCDFormType)
                {
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", monthlyCharge: 10);
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 4, TableAction.SetText, "10.00");
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 6, TableAction.Click);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    Support.AreEqual("50.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }
                else
                {
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", monthlyCharge: 10);
                    FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 4, TableAction.SetText, "10.00");
                    FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 6, TableAction.Click);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    Support.AreEqual("50.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for HUD type= Legacy.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251.00, sellerCharge: 151.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251.00, sellerCharge: 151.00);
                }
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0010()
        {
            try
            {
                Reports.TestDescription = "FM1008_FM1380_FM1381_FM4390_FM4391_FM4392_FM4393_FM4394_FM1246_FM2159_FM2161_0001: 1.Mortgage Broker 2. Default Entity Type to Lender 3.Use Another Entity Type 4.Enter Yield Spread Premium Charge 5.Allow Only One Yield S";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for HUD type= Legacy.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251.00, sellerCharge: 151.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251.00, sellerCharge: 151.00);
                }

                Reports.TestStep = "Navigate to Recap Tab and Validate YSP CHK.";
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("Yield Spread Premium(CHK) $51.00", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "YieldSpread").Text.Clean());
                }
                else
                {
                    Support.AreEqual("Broker Fee(Check) $51.00", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "YieldSpread").Text.Clean());
                }
                

                Reports.TestStep = "Select a Entity Type and Click on Find Button.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Lender", EntityName: "b*");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("ID Code", "588", "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select a Entity Type and Click on Find Button.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Energy");
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Delete YSP amount in Mortgage Broker Tab.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText(" ");

                Reports.TestStep = "Validate the payment Methods.";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("CHK", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FAGetSelectedItem());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("CHK").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("POC").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("POC-B").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("POC-L").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("POC-MB").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("POC-S").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("RBL").ToString());
                }
                else
                {
                    Support.AreEqual("Check", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FAGetSelectedItem());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("Check").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("No Check").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("POC").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("POC-L").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("POC-MB").ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.Text.Contains("RBL").ToString());
                }
                

                Reports.TestStep = "Select a method and enter charge.";
                FastDriver.PaymentDetailsNewLoanDlg.FileCharge.FASetText("50");
                FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FASelectItem("POC-MB");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Delete YSP amount in Mortgage Broker Tab.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText(" ");

                Reports.TestStep = "Select a method and enter charge.";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsNewLoanDlg.FileCharge.FASetText("50");
                FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Remove button in Mortgage Broker Tab.";
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0011()
        {
            try
            {
                Reports.TestDescription = "ES7294_ES7236_0001: 1.Restrict Removal of MB has a Pmt method of PMB 2. Restrict Removal of New Loan Lender has a Pmt Method of PBL.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Fee Entry and enter charges.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/ALTA Loan", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner/ALTA Loan", 3, TableAction.Click);
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.FeePaymentDetailsDlg.BuyerCharge.FASetText("20.00");
                    FastDriver.FeePaymentDetailsDlg.PaidbyBuyer.FASetText("8.00");
                    FastDriver.FeePaymentDetailsDlg.BuyerPaidbyLender.FASetText("7.00");
                    FastDriver.FeePaymentDetailsDlg.BuyerPaidbyMortBroker.FASetText("5.00");
                    FastDriver.FeePaymentDetailsDlg.SellerCharge.FASetText("15.00");
                    FastDriver.FeePaymentDetailsDlg.PaidbySeller.FASetText("7.00");
                    FastDriver.FeePaymentDetailsDlg.SellerPaidbyMortBroker.FASetText("8.00");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("8.00");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.00");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Click on Remove button in Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Click on Remove button in Loan Details Tab.";
                FastDriver.NewLoan.LoanDetailsTab.FAClick();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0012()
        {
            try
            {
                Reports.TestDescription = "REG_0004: (FM1215_ES7295_ES7296_FM1219_ES7297_ES7298_FM1222_FM1223_FM1224_FM1216_FM2629_FM1218_FM1220_FM1221_FM1473_FM1474_0001) 1.Note Preparation Details 2.Allow user to view loan information on the Note tab 3.Allow us";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for HUD type= Legacy.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251.00, sellerCharge: 151.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251.00, sellerCharge: 151.00);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08-11-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11-06-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500.00");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter details for New Loan Note Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteInterestRate.FASetText("1.5");
                FastDriver.NewLoan.NoteBaseRate.FASetText("1.5");
                FastDriver.NewLoan.NotePlusMinusRate.FASetText("0.25");
                FastDriver.NewLoan.NoteEquivalentRate.FASetText("0.75");
                FastDriver.NewLoan.NoteMaxChargeRate.FASetText("1.25");
                FastDriver.NewLoan.NoteAlienationClause.FAClick();
                FastDriver.NewLoan.NoteAgreementDate.FASetText("08-03-2012");
                FastDriver.NewLoan.NotePaymentDate_and_Period.FASetText("2nd Monday Of Every Month");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Due Date in Note Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteDueDate.FASetText("06-20-2012");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0013()
        {
            try
            {
                Reports.TestDescription = "FM1281_ES7299_ES7300_ES7301_ES7302_ES7303_ES7304_ES7305_001: 1. Parties Display Broken Link Symbol 2.Buyer Vest for Trustor 3.Edit Trustor Mortgagor 4.Update Trustor from Vest 5.Beneficiary Mortgagee 6.Edit Beneficiary M";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for HUD type= Legacy.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251.00, sellerCharge: 151.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251.00, sellerCharge: 151.00);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08-11-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11-06-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500.00");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                FastDriver.NewLoan.NoteInterestRate.FASetText("1.5");
                FastDriver.NewLoan.NoteBaseRate.FASetText("1.5");
                FastDriver.NewLoan.NotePlusMinusRate.FASetText("0.25");
                FastDriver.NewLoan.NoteEquivalentRate.FASetText("0.75");
                FastDriver.NewLoan.NoteMaxChargeRate.FASetText("1.25");
                FastDriver.NewLoan.NoteAlienationClause.FAClick();
                FastDriver.NewLoan.NoteAgreementDate.FASetText("08-03-2012");
                FastDriver.NewLoan.NotePaymentDate_and_Period.FASetText("2nd Monday Of Every Month");
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteDueDate.FASetText("06-20-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");
                Support.AreEqual("Buyer1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname", FastDriver.NewLoan.PartiesTrustorMortgagor.FAGetValue());
                Support.AreEqual("Mortgage Lender 1 Name 1, Mortgage Lender 1 Name 2", FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FAGetValue());
                FastDriver.NewLoan.PartiesTrustorMortgagor.FASetText("BUYER1Firstname Buyer1Lastname and Buyer2Firstname Buyer2Lastname and Buyer2SpouseName Buyer2Lastname");
                FastDriver.NewLoan.PartiesBeneficiaryMortgagee.Click();
                Support.AreEqual("True", FastDriver.NewLoan.TrustorMortgagerbrokenlink.Exists().ToString());
                FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FASetText("Mortgage LENDER 1 Name 1, Mortgage Lender 1 Name 2 are lenders");
                FastDriver.NewLoan.PartiesTrustorMortgagor.Click();
                Support.AreEqual("True", FastDriver.NewLoan.benificiarybrokenlink.Exists().ToString());
                FastDriver.NewLoan.PartiesTrustorMortgagorRefresh.FAClick();
                FastDriver.NewLoan.PartiesBeneficiaryMortgageeRefresh.FAClick();
                Support.AreEqual("False", FastDriver.NewLoan.TrustorMortgagerbrokenlink.Displayed.ToString());
                Support.AreEqual("False", FastDriver.NewLoan.benificiarybrokenlink.Displayed.ToString());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0014()
        {
            try
            {
                Reports.TestDescription = "ES7306_ES7307_ES7308_ES7309_ES7310_ES7312_ES7313_0001: 1.Related Parties 2.Related Party Role Type 3.Prevent Multiple Lender Related Party Role Types 4.Lenders Attorney 5.Allow Multiple Attorney and or Misc Related Party";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for HUD type= Legacy.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251.00, sellerCharge: 151.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 51.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 251.00, sellerCharge: 151.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251.00, sellerCharge: 151.00);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08-11-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11-06-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500.00");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                FastDriver.NewLoan.NoteInterestRate.FASetText("1.5");
                FastDriver.NewLoan.NoteBaseRate.FASetText("1.5");
                FastDriver.NewLoan.NotePlusMinusRate.FASetText("0.25");
                FastDriver.NewLoan.NoteEquivalentRate.FASetText("0.75");
                FastDriver.NewLoan.NoteMaxChargeRate.FASetText("1.25");
                FastDriver.NewLoan.NoteAlienationClause.FAClick();
                FastDriver.NewLoan.NoteAgreementDate.FASetText("08-03-2012");
                FastDriver.NewLoan.NotePaymentDate_and_Period.FASetText("2nd Monday Of Every Month");
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteDueDate.FASetText("06-20-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Enter a details in Related parties tab.";
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Lender- Originating Branch");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.FAFindElement(ByLocator.Id, "tNL_tRP_NLRP_grdPaye_1_ddlRT").FASelectItemBySendingKeys("L"); 
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.SelectItem, "Attorney- Primary");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "123");

                Reports.TestStep = "Validate in Related Parties Tab.";
                Support.AreEqual("Lender- Originating Branch", FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetSelectedItem).Message.Clean());
                Support.AreEqual("Attorney- Primary", FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.GetSelectedItem).Message.Clean());


                Reports.TestStep = "Select role in related parties tab.";
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Attorney- Primary");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate in Related Parties Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                Support.AreEqual("Lender- Originating Branch", FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetSelectedItem).Message.Clean());
                Support.AreEqual("Attorney- Primary", FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.GetSelectedItem).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0015()
        {
            try
            {
                Reports.TestDescription = "FM2389_ES7314_ES7315_ES7316_ES7317_0001: 1.Enter Record Document Info 2.Title Ins. Mortgagee Clause3.Enter Title Insurance Mortgagee 4.Edit Title Insurance Mortgagee 5.Update Title Insurance Mortgagee.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for HUD type= Legacy.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 251.00, sellerCharge: 151.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 251.00, sellerCharge: 151.00);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08-11-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11-06-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500.00");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                FastDriver.NewLoan.NoteInterestRate.FASetText("1.5");
                FastDriver.NewLoan.NoteBaseRate.FASetText("1.5");
                FastDriver.NewLoan.NotePlusMinusRate.FASetText("0.25");
                FastDriver.NewLoan.NoteEquivalentRate.FASetText("0.75");
                FastDriver.NewLoan.NoteMaxChargeRate.FASetText("1.25");
                FastDriver.NewLoan.NoteAlienationClause.FAClick();
                FastDriver.NewLoan.NoteAgreementDate.FASetText("08-03-2012");
                FastDriver.NewLoan.NotePaymentDate_and_Period.FASetText("2nd Monday Of Every Month");
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteDueDate.FASetText("06-20-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Enter a details in Related parties tab.";
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Lender- Originating Branch");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                Support.AreEqual("Attorney- Primary", FastDriver.NewLoan.RelatedPartiesSummaryTable.FAFindElement(ByLocator.Id, "tNL_tRP_NLRP_grdPaye_1_ddlRT").FAGetSelectedItem());
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "123");

                Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                FastDriver.NewLoan.ClickRcdgMortageeTab();
                FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                FastDriver.NewLoan.RCDG_MortageBook.FASetText("Motgages Bible");
                FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");

                Reports.TestStep = "Edit Title Insurance Mortgagee in RcdgMortgage Tab.";
                FastDriver.NewLoan.RCDG_MortageTitleInsuranceMortagagee.FASetText("who is an obligor under the provisions of Section 12{c} of the Conditions and Stipulations.");
                FastDriver.NewLoan.RCDG_MortageBook.Click();
                Support.AreEqual("True", FastDriver.NewLoan.RCDG_MortageTitleInsuranceMortagageebrokenlink.Exists().ToString());

                Reports.TestStep = "Click refresh of Title Insurance Mortgagee in RcdgMortgage Tab.";
                FastDriver.NewLoan.RCDG_MortageRefresh.FAClick();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0016()
        {
            try
            {
                Reports.TestDescription = "FM5297_0001: 1.Add POC MB Fees to Fund Amount Checkbox.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for HUD type= Legacy.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 51.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08-11-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11-06-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500.00");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                FastDriver.NewLoan.NoteInterestRate.FASetText("1.5");
                FastDriver.NewLoan.NoteBaseRate.FASetText("1.5");
                FastDriver.NewLoan.NotePlusMinusRate.FASetText("0.25");
                FastDriver.NewLoan.NoteEquivalentRate.FASetText("0.75");
                FastDriver.NewLoan.NoteMaxChargeRate.FASetText("1.25");
                FastDriver.NewLoan.NoteAlienationClause.FAClick();
                FastDriver.NewLoan.NoteAgreementDate.FASetText("08-03-2012");
                FastDriver.NewLoan.NotePaymentDate_and_Period.FASetText("2nd Monday Of Every Month");
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteDueDate.FASetText("06-20-2012");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Enter a details in Related parties tab.";
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Lender- Originating Branch");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                Support.AreEqual("Attorney- Primary", FastDriver.NewLoan.RelatedPartiesSummaryTable.FAFindElement(ByLocator.Id, "tNL_tRP_NLRP_grdPaye_1_ddlRT").FAGetSelectedItem()); 
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "123");

                Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                FastDriver.NewLoan.ClickRcdgMortageeTab();
                FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                FastDriver.NewLoan.RCDG_MortageBook.FASetText("Motgages Bible");
                FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");
                FastDriver.NewLoan.RCDG_MortageTitleInsuranceMortagagee.FASetText("who is an obligor under the provisions of Section 12{c} of the Conditions and Stipulations.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry and enter charges.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddPOC_MBFeestoProjectedLoanFunding.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0017()
        {
            try
            {
                Reports.TestDescription = "ES7431_ES7432_ES7433_0001: 1. Noteworld Account Service Candidate 2.Activate Service Product drop down 3.Activate Service Product drop down.";
                Login(AutoConfig.FASTHomeURL);
                Reports.StatusUpdate("The field that is being evaluated in this test cannot be tested as it is disabled. Ending test.", true);
                FastDriver.WebDriver.Quit();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0018()
        {
            try
            {
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter values to New Loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("123456");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Select a Loan Instance from Summary.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                Support.AreEqual("Available", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean());
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();

                Reports.TestStep = "Enter values to New Loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("123456");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0019()
        {
            try
            {
                Reports.TestDescription = "ES7434_0001: 1.Automatically identify Candidate loans in FAST.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate loan type.";
                Support.AreEqual("Cal Vet", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0020()
        {
            try
            {
                Reports.TestDescription = "ES7435_0001: 1.Identify Candidates based on Loan Type.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Seller Carryback");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate loan type.";
                Support.AreEqual("Seller Carryback", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0021()
        {
            try
            {
                Reports.TestDescription = "ES7437_0001: 1.Identify Candidates based on New Loan Charge.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Seller Carryback");

                Reports.TestStep = "Create a loan.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "2nd New Loan to File", buyerCharge: 500.00);
                    Support.AreEqual("500.00", FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    
                }
                else
                {
                    Reports.StatusUpdate("Buyer Charge and Seller Credit fields are disabled for CD type files.", true);
                }
                FastDriver.BottomFrame.Done();
                //FastDriver.NewLoanSummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0022()
        {
            try
            {
                Reports.TestDescription = "ES7438_FM1511_0001: 1.Identify Candidates based on Lender Name 2.Seller Carryback.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Seller Carryback");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100F01");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("NL1235");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Corporate").WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.BuyerSellerType.FASelectItem("Business Entity");
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem("Lender");
                FastDriver.GABEntryRequestDlg.Name1.FASetText("Bill Gates");
                FastDriver.GABEntryRequestDlg.BusinessPhoneNumber.FASetText("7587857412");
                FastDriver.GABEntryRequestDlg.BusinessPhoneExtension.FASetText("155");
                FastDriver.GABEntryRequestDlg.EmailNumber.FASetText("bill.gates@microsoft.com");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText("455 Main St");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText("MIDWAY");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem("TX");
                FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText("96015");
                FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText("HILL");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0023()
        {
            try
            {
                Reports.TestDescription = "ES7439_ES7440_00001: 1. Deselect candidate loan 2. Candidate option Blank.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Seller Carryback");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100F01");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("NL1235");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.FindContact(EntiType: "Corporate").WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                FastDriver.GABEntryRequestDlg.BuyerSellerType.FASelectItem("Business Entity");
                FastDriver.GABEntryRequestDlg.EntityType.FASelectItem("Lender");
                FastDriver.GABEntryRequestDlg.Name1.FASetText("Bill Gates");
                FastDriver.GABEntryRequestDlg.BusinessPhoneNumber.FASetText("7587857412");
                FastDriver.GABEntryRequestDlg.BusinessPhoneExtension.FASetText("155");
                FastDriver.GABEntryRequestDlg.EmailNumber.FASetText("bill.gates@microsoft.com");
                FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText("455 Main St");
                FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText("MIDWAY");
                FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem("TX");
                FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText("96015");
                FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText("HILL");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0024()
        {
            try
            {
                Reports.TestDescription = "REG_0005: ES10965_ES10966_ES10973_ES10968_ES10974_ES10974_ES10975_ES10976_ES10977_ES10978_ES10979_ES10980_ES10985_ES10986_ES10987_ES11512_ES11513_ES11514_ES11620_ES10996 1.Files with HUD Type HUD 2.Select HUD Type 3.Prev";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Click on credit in Loan Charges Tab.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationCredit.FAClick();
                    Support.AreEqual("-250.00", FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue());

                    Reports.TestStep = "Click on Zero in Loan Charges Tab.";
                    FastDriver.NewLoan.LoanChargesInterestCalculationZero.FAClick();
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue());
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0025()
        {
            try
            {
                Reports.TestDescription = "REG_0006: ES10988_ES10989_ES10991_ES10993_ES11515_ES11516_ES11518_ES11520_0001 1.Overwrite calculated Origination Points 2. Enter Origination Points Fixed Dollar Amount 3.Enter both $$ amount and % 4.Edit Origination Poi";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit IRS Origination Points.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FASetText("120.00");
                    FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FASetText("20.00");
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    FastDriver.NewLoan.CreditChargeIRSPoints.FASetText("150.00");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 25.00);
                }
                   
                


            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0026()
        {
            try
            {
                Reports.TestDescription = "ES10967_ES10982_ES10995_ES11522_0001: 1.HUD Type for New Loan 2nd+ Instances 2.Prevent entry of GFE Amounts for New Loan 2nd+ instances 3.Display and not allow to enter $, % , Points for 2+ New Loan 4.Display and not all";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for HUD type = CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit IRS Discount Points.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FASetText("150.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FASetText("25.00");
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                else
                {
                    FastDriver.NewLoan.CreditChargeIRSPoints.FASetText("150.00");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 25.00);
                }
                
                Reports.TestStep = "New us Shortcut Keys.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("255");

                Reports.TestStep = "Validate different radio buttons in New Loan Screen.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationCredit.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationZero.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesOriginationChargeCredit.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesOriginationChargeCharge.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesOriginationChargeZero.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCharge.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsZero.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.Enabled.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.Enabled.ToString());
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0027()
        {
            try
            {
                Reports.TestDescription = "ES10969_ES10970_ES10972_0001: 1.Allow HUD Type change if no Lender exists 2.System removal of GFE Data 3.Change in New Loan Amount.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FASetText("50.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", loanEstimate: 50);
                }

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select CD/HUD on Form Type on New Loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.FormType_CD.FAClick();
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.FormType_HUD.FAClick();
                    FastDriver.NewLoan.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.NewLoan.FormType_HUD.FAClick();
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.FormType_CD.FAClick();
                    FastDriver.NewLoan.WaitForScreenToLoad();
                }
                
                Reports.TestStep = "Validate GFE in Loan Charges Tab.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("", FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue());
                    Support.AreEqual("", FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetValue());
                }
                else
                {
                    Support.AreEqual("", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("", FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean());
                }

                Reports.TestStep = "Enter Loan Origination Charge.";
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCharge: 100.00);
                    
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 100.00);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                
                Reports.TestStep = "Edit Loan Amount in Loan Details Tab.";
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000");               
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Origination fees.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("", FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetValue());
                }
                //else
                //{
                //    Support.AreEqual("", FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                //}
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0028()
        {
            try
            {
                Reports.TestDescription = "ES10990_ES10992_ES10994_ES11517_ES11519_ES11521_0001: 1.Copy Fixed Dollar Amount to Origination Points 2.Enter Flat Charge Amount for Origination Points 3.Delete Origination Points %, $ Amount and Origination Points 4.Co";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FASetText("55.00");
                    FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FASetText("100.00");
                }
                else
                {
                    Reports.StatusUpdate("No flow was included for CD type files.", true);
                }

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate IRS points in Loan Charges Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("55.00", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue());
                    Support.AreEqual("100.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue());
                }
                else
                {
                    Reports.StatusUpdate("No flow was included for CD type files.", true);
                }

                Reports.TestStep = "Enter Amount in IRS Points.";
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FASetText("110.00");
                }
                else
                {
                    Reports.StatusUpdate("No flow was included for CD type files.", true);
                }

                Reports.TestStep = "Validate IRS points in Loan Charges Tab.";
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("50.00", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue());
                    Support.AreEqual("110.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue());
                }
                else
                {
                    Reports.StatusUpdate("No flow was included for CD type files.", true);
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            } 
        }

        [TestMethod]
        public void FMUC0047_REG0029()
        {
            try
            {
                Reports.TestDescription = "ES10971_0001: 1.Removal of GFE Data on deletion of 1st instance of New Loan.";
                Reports.TestStep = "Login to File Side and create a file";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("0");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD/HUD.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete created instance";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate IRS points in Loan Charges Tab.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("0.0000", FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetValue());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FAGetValue());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue());
                    Support.AreEqual("0.0000", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FAGetValue());
                    Support.AreEqual("0.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue());
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0030()
        {
            try
            {
                Reports.TestDescription = "ES11616_ES11617_ES11619_ES11620_ES11622_ES11624_ES11626_ES11627_ES11628_ES11632_0001: 1.Itemize Loan Origination Charges 2.Itemize Origination Charges for FHA, VA and RHS Loans 3.Allow entry of Our Origination charge and";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("300000000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("FHA");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("5000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M08");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("NL1235");
                FastDriver.NewLoan.FindGABCode("255");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Itemized Origination Charges.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Exists().ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Enabled.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.ItemizationOriginationChargesTable.Exists().ToString());
                }
                else
                {
                    Reports.StatusUpdate("No flow included for CD type files.", true);
                }
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForScreenToLoad();
                }

                Reports.TestStep = "Validate Itemized Origination Charges.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Exists().ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Enabled.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.ItemizationOriginationChargesTable.Exists().ToString());
                }
                else
                {
                    Reports.StatusUpdate("No flow included for CD type files.", true);
                }

                Reports.TestStep = "Select FHA as Loan Type in Loan Details Tab.";
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("FHA");

                Reports.TestStep = "Validate Itemized Origination Charges.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Exists().ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Enabled.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.ItemizationOriginationChargesTable.Exists().ToString());
                }
                else
                {
                    Reports.StatusUpdate("No flow included for CD type files.", true);
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0031()
        {
            try
            {
                Reports.TestDescription = "ES11618_ES11629_ES11630_0001: 1.Itemize Origination charges by first property address 2.Change of first property address state 3.Change first property address to a state subject to Itemization.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.Properties[0].PropertyAddress[0].City = "MIDWAY";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "TX";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "HILL";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "96015";
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None,
                            },
                     },
   
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersRealEstateAgent,
                        },
                        Name = "Regression",
                    },
                    //new FileBusinessParty()
                    //{
                    //    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                    //    RoleTypeObjectCD = "ASSOTDPTY",
                    //    AdditionalRole = new AdditionalRoleList()
                    //    {
                    //        eAddtionalRole = AdditionalRoleType.SellersBroker,
                    //    },
                    //},
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Exists().ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Enabled.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.ItemizationOriginationChargesTable.Exists().ToString());
                }
                else
                {
                    Reports.StatusUpdate("No flow included for CD type files.", true);
                }

                Reports.TestStep = "Enter a GAB Code and click on Find Button.";
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.FindGABCode("255");

                Reports.TestStep = "Navigate to property tax info and change a address.";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Santa Ana");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItemBySendingKeys("C");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("ALAMEDA");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("92707");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Itemized Origination Charges.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Exists().ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingPaymentDetails.Enabled.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.ItemizationOriginationChargesTable.Exists().ToString());
                }
                else
                {
                    Reports.StatusUpdate("No flow included for CD type files.", true);
                }
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0032()
        {
            try
            {
                Reports.TestDescription = "ES11632_ES11633_0001: 1.Do not include Our Origination charge in calc of New Loan Chgs 2.Do not include Our Origination charge in calc of Loan Charges.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.Properties[0].PropertyAddress[0].City = "MIDWAY";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "TX";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "HILL";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "96015";
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None,
                            },
                     },
   
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersRealEstateAgent,
                        },
                        Name = "Regression",
                    },
                    //new FileBusinessParty()
                    //{
                    //    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                    //    RoleTypeObjectCD = "ASSOTDPTY",
                    //    AdditionalRole = new AdditionalRoleList()
                    //    {
                    //        eAddtionalRole = AdditionalRoleType.SellersBroker,
                    //    },
                    //},
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("7000");
                FastDriver.NewLoan.FindGABCode("255");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Recap Tab and Validate.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblTH").Text.Contains("Lenders Advantage").ToString());
                Support.AreEqual("True", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblTH").Text.Contains("$7,000.00").ToString());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0033()
        {
            try
            {
                Reports.TestDescription = "ES11634_ES12605_ES13066_0001: 1.Buyer Charge and Buyer Credit for Our Origination Charge 2.Enter Mortgage Insurance Case Number 3.Do not create disbursement for Our Origination charge.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.Properties[0].PropertyAddress[0].City = "MIDWAY";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "TX";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "HILL";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "96015";
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None,
                            },
                     },
   
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersRealEstateAgent,
                        },
                        Name = "Regression",
                    },
                    //new FileBusinessParty()
                    //{
                    //    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                    //    RoleTypeObjectCD = "ASSOTDPTY",
                    //    AdditionalRole = new AdditionalRoleList()
                    //    {
                    //        eAddtionalRole = AdditionalRoleType.SellersBroker,
                    //    },
                    //},
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("7000");
                FastDriver.NewLoan.FindGABCode("255");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Buyer charge in Loan Charges Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCharge: 200);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    FastDriver.NewLoan.OriginationChargesTable.EnterCharges(Row: 1, buyerCharge: 200.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 200);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select a Charge for disbursement.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Issue a Disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 250);
                FastDriver.PrintChecks.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0035()
        {
            try
            {
                Reports.TestDescription = "ES10983_ES10984_ES13100_0001: 1.Change Lender 2.Do not include New Loan Amount in Projected Loan Fund 3.Do not create disbursements for New Loan Amount.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.Properties[0].PropertyAddress[0].City = "MIDWAY";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "TX";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "HILL";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "96015";
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None,
                            },
                     },
   
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.SellersRealEstateAgent,
                        },
                        Name = "Regression",
                    },
                    //new FileBusinessParty()
                    //{
                    //    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDASLNDR1"),
                    //    RoleTypeObjectCD = "ASSOTDPTY",
                    //    AdditionalRole = new AdditionalRoleList()
                    //    {
                    //        eAddtionalRole = AdditionalRoleType.SellersBroker,
                    //    },
                    //},
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create a New Loan with CD type and Loan type as reverse mortgage.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Reverse Mortgage", false);
                FastDriver.NewLoan.LoanDetailsLoantype.FireEvent("onchange");
                

                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.WarningDlg.WaitForScreenToLoad();
                    FastDriver.WarningDlg.No.FAClick();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.NewLoan.WaitForScreenToLoad();
                }
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("7000");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("Q100q");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("N7899");
                FastDriver.NewLoan.FindGABCode("247");

                Reports.TestStep = "Validate a disbursement is not present.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString());

                Reports.TestStep = "Validate the loan amount.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("7,000.00", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Create a New Loan with CD type and Loan type as reverse mortgage.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.ClassName, "cFrameCaptionTR").Text.Contains("Lenders Advantage/ $7,000.00").ToString());
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0036()
        {
            try
            {
                Reports.TestDescription = "REG_0007: (FM1168_ES7318_ES7319_ES7320_ES7321_ES7322_ES7323_ES7324_ES7325_ES7326_ES12623_ES12624_ES7327_ES7328_ES7329_ES7330_ES7331_ES7332_ES7333_ES7334_0001) 1. Display Entry Recap 2.Loan Amount 3.New Loan Charges 4.Tit";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("0");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NotePaymentType.FASelectItem("Principal & Interest");
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08-11-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11-06-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500.00");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                FastDriver.NewLoan.NoteLoanterm_Year.FAClick();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                FastDriver.NewLoan.ClickRcdgMortageeTab();
                FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                FastDriver.NewLoan.RCDG_MortageBook.FASetText("Motgages Bible");
                FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");

                Reports.TestStep = "Navigate to Recap Tab and Validate.";
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblTH").Text.Contains("Lenders Advantage").ToString());
                Support.AreEqual("True", FastDriver.NewLoan.RecapTable.FAFindElement(ByLocator.Id, "lblTH").Text.Contains("$10,000.00").ToString());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0037()
        {
            try
            {
                Reports.TestDescription = "ES10553_ES10535_0001: 1.Automatically Recalculate Calculated Fees 2.Prevent Parameter Changes.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("0");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.IsSelected().ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.IsSelected().ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NotePaymentType.FASelectItem("Principal & Interest");
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08-11-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11-06-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500.00");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                FastDriver.NewLoan.NoteLoanterm_Year.FAClick();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                FastDriver.NewLoan.ClickRcdgMortageeTab();
                FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                FastDriver.NewLoan.RCDG_MortageBook.FASetText("Mortgages Bible");
                FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry and enter charges.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddPOC_MBFeestoProjectedLoanFunding.FASetCheckbox(true);

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.AllFees.FAClick();
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItemBySendingKeys("alta");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 8, TableAction.SetText, "55.00");
                string feeTransfer = FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 12, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tCF_tCS_ucCSFs_grCalcSummary_0_lblTotalCharge").FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Recap Tab and Validate.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("2000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                }
                else
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Issue a Disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, feeTransfer, 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 210);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "validate:1st New Loan Liability Amount is associated with a fee that has been disbursed. Liability Amount Information cannot be modified. Cancel Issued Disbursements before proceed with changes.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("2000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0038()
        {
            try
            {
                Reports.TestDescription = "FM2526_ES7237_ES7238_FM1169_FM1280_0001: 1.Option to Retain Lender Chgs 2.If Lender is deleted or changed delete the Mortgage Product 3.Retain All Information Except Lender Business Party 4.Warn on Calc Weekend Date 4.Wa";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("0");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NotePaymentType.FASelectItem("Principal & Interest");
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08-11-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11-06-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500.00");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                FastDriver.NewLoan.NoteLoanterm_Year.FAClick();

                Reports.TestStep = "Navigate to Parties Tab and Enter details.";
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.PartiesAttention.FASelectItem("L247");
                FastDriver.NewLoan.PartiesSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.PartiesReference.FASetText("Mohanty");

                Reports.TestStep = "Navigate to Recording/Mortgagee Tab and Enter details and then to Recap.";
                FastDriver.NewLoan.ClickRcdgMortageeTab();
                FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("09-12-2012");
                FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("09-13-2012");
                FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("Property1");
                FastDriver.NewLoan.RCDG_MortageBook.FASetText("Motgages Bible");
                FastDriver.NewLoan.RCDG_MortagePage.FASetText("7");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Fee Entry and enter charges.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddPOC_MBFeestoProjectedLoanFunding.FASetCheckbox(true);

                Reports.TestStep = "Select All fees and Click on Calculate";
                FastDriver.FileFees.AllFees.FAClick();
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy.";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItemBySendingKeys("alta");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 8, TableAction.SetText, "55.00");
                string feeTransfer = FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 12, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tCF_tCS_ucCSFs_grCalcSummary_0_lblTotalCharge").FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Recap Tab and Validate.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("2000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                }
                else
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Issue a Disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, feeTransfer, 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Print the checks.";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Click on Remove button in Loan Details Tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate new loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());

                Reports.TestStep = "Validate Loan Charges screen";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                Support.AreEqual("1.500000", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue());
                Support.AreEqual("487.50", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());

                Reports.TestStep = "Enter dates in New Loan Details Screen.";
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.LoanDetailsDays.FASetText("51");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.WeekendWarning.WaitForScreenToLoad();
                FastDriver.WeekendWarning.rdoMonday.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("5000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }

        [TestMethod]
        public void FMUC0047_REG0040()
        {
            try
            {
                Reports.TestDescription = "EWC_1_0001: User deletes a New Loan instance that has issued checks to the New Loan Lender, the Mortgage Broker, or their third party Payees.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("0");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }

                Reports.TestStep = "Issue a Disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0041()
        {
            try
            {
                Reports.TestDescription = "EWC_2_0001: User deletes a charge process instance that does not have issued checks.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create a loan Instance with loan type as seller carry back.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Seller Carryback");

                Reports.TestStep = "Create a loan.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Select a Instance and remove it.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                Support.AreEqual("Available", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0042()
        {
            try
            {
                Reports.TestDescription = "EWC_2_0002: User Cancel the deletes a charge process instance that does not have issued checks.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Create a loan Instance with loan type as seller carry back.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Seller Carryback");

                Reports.TestStep = "Create a loan.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Select a Instance and remove it.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate an instance Creation.";
                Support.AreEqual("Lenders Advantage A Division Of First American Title Ins.", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0043()
        {
            try
            {
                Reports.TestDescription = "EWC_3_0001: User tries to delete a charge description that has a charge amount.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete a Charge description.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.Clear();
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0044()
        {
            try
            {
                Reports.TestDescription = "EWC_4_0001: User tries to decrease or delete a charge amount with payment method of CHK after the payee check is issued.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Issue a Disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the information: A check has been issued for the previously entered charges. The effect of your change may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, this change may result in the File be out-of-balance. Do you wish to make this change?.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.SetText, "45");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge2.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("50.00", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0045()
        {
            try
            {
                Reports.TestDescription = "EWC_4_0002: User tries to decrease or delete a charge amount with payment method of CHK after the payee check is issued.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Issue a Disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the information: A check has been issued for the previously entered charges. The effect of your change may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, this change may result in the File be out-of-balance. Do you wish to make this change?.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.SetText, "45");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge2.Click();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate YSP Charge.";
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("45.00", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0046()
        {
            try
            {
                Reports.TestDescription = "EWC_5_0001: User tries to add or increase a charge amount with payment method of CHK after the payee check is issued.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Issue a Disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the information: A check has been issued for the previously entered charges. The effect of your change may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, this change may result in the File be out-of-balance. Do you wish to make this change?.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.SetText, "55");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge2.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("50.00", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }

        [TestMethod]
        public void FMUC0047_REG0047()
        {
            try
            {
                Reports.TestDescription = "EWC_5_0002: User tries to add or increase a charge amount with payment method of CHK after the payee check is issued.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Issue a Disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the information: A check has been issued for the previously entered charges. The effect of your change may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, this change may result in the File be out-of-balance. Do you wish to make this change?.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.SetText, "55");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge2.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("55.00", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0048()
        {
            try
            {
                Reports.TestDescription = "EWC_6_0001: User searches for a business party on ID Code and system does not find an exact match.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("erghew651");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0049()
        {
            try
            {
                Reports.TestDescription = "EWC_7_0001: The business party is a payee on an issued check and user tries to edit or replace it with another business party.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for CD.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Issue a Disbursement.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate the information: A check has been issued for the previously entered charges. The effect of your change may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, this change may result in the File be out-of-balance. Do you wish to make this change?.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFind.FAClick();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0050()
        {
            try
            {
                Reports.TestDescription = "EWC_8_0001: User cancels entry of the FIRST new instance us Cancel button on framework before save a new process instance.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                
                Reports.TestStep = "Validate: Cancel without save changes?.";
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate new loan screen.";
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());

                Reports.TestStep = "Validate: Cancel without save changes?.";
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate new loan screen.";
                Support.AreEqual("7,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("7,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0051()
        {
            try
            {
                Reports.TestDescription = "EWC_9_0001: User cancels entry of the SECOND new instance us Cancel button on framework before save a new process instance.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Enter details for a new loan.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("DSLNDR0001");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate the loan screen.";
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0052()
        {
            try
            {
                Reports.TestDescription = "EWC_10_0001: User cancels entry of the THIRD or SUBSEQUENT new instance us Cancel button on framework before save a new process instance.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.formType = FormType.CD;
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Enter details for a new loan.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("DSLNDR0001");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Create a 3rd instance of New Loan";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("501");
                FastDriver.NewLoan.FindGABCode("255");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Validate New Loan Summary Screen.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0053()
        {
            try
            {
                Reports.TestDescription = "EWC_11_0001: User cancels entry us Reset button on framework before save changes to an EXIST process instance.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Enter details for a new loan.";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("DSLNDR0001");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30);

                Reports.TestStep = "Edit details of New Loan Instance.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate the loan screen.";
                Support.AreEqual("VA", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("100.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("100.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());

                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate new loan screen.";
                Support.AreEqual("Small Loan", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("500.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("500.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0054()
        {

            try
            {
                Reports.TestDescription = "EWC_12_0001: Rescission Period End date falls on a Saturday.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("255");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("09-04-2012");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("09-06-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("09-19-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("39");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.WeekendWarning.WaitForScreenToLoad();
                Support.AreEqual("Rescission Period End Date falls on a Saturday.", FastDriver.WeekendWarning.RescissionNotice.Text.Clean());
                FastDriver.WeekendWarning.rdoMonday.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForScreenToLoad();

                Support.AreEqual("Small Loan", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("500.00", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("500.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("09-04-2012", FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue());
                Support.AreEqual("09-06-2012", FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue());
                Support.AreEqual("09-19-2012", FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue());
                Support.AreEqual("39", FastDriver.NewLoan.LoanDetailsDays.FAGetValue());
                Support.AreEqual("11-05-2012", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }

        [TestMethod]
        public void FMUC0047_REG0055()
        {
            try
            {
                Reports.TestDescription = "EWC_13_0001: User clicks Remove button to remove a Mortgage Broker or Lender.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for HUD type= HUD.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Remove Mortgage Broker from a New Loan Entry.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Validate in Mortgage Broker Tab.";
                Support.AreEqual("50.00", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("250.00", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("150.00", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0056()
        {
            try
            {
                Reports.TestDescription = "EWC_13_0002: User clicks Remove button to remove a Mortgage Broker or Lender.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details for HUD type= HUD.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00);
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Remove Mortgage Broker from a New Loan Entry.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Validate in Mortgage Broker Tab.";
                Support.AreEqual("", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("", FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0057()
        {
            try
            {
                Reports.TestDescription = "EWC_14_0001: User modifies interest  calculation formula values after original calculation.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                //FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Loan Charge Tab Interest calculation.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("0.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                
                Reports.TestStep = "Validate data in Loan Charges Tab.";
                Support.AreEqual("0.500000", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue());
                Support.AreEqual("487.50", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());

                Reports.TestStep = "Edit Loan Charge Tab Interest calculation.";
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.Click();
                Keyboard.SendKeys("1.0");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate: Interest calculation formula values have changed.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                Support.AreEqual("1.000000", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue());
                Support.AreEqual("325.00", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0058()
        {
            try
            {
                Reports.TestDescription = "EWC_15_40_0001: User modifies Loan Origination Fee calculation formula values after original calculation.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                //FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate: Do you wish to recalculate Loan Origination Fee.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("0.5");
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    Support.AreEqual("0.5000", FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetValue());
                    Support.AreEqual("150.00", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue());
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("2.0");
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    Support.AreEqual("2.0000", FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetValue());
                    Support.AreEqual("200.00", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue());
                }
                else 
                {
                    Reports.StatusUpdate("No flow included for CD type files.", true);
                    FastDriver.WebDriver.Quit();
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0059()
        {
            try
            {
                Reports.TestDescription = "EWC_17_0001: User modifies Loan Discount Points calculation formula values after original calculation.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Loan Charge Tab Interest calculation.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.5");
                    FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                }
                else
                {
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.5");
                    FastDriver.NewLoan.CreditChargeIRSPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                }

                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Validate Discount Percentage in Loan Charges Tab.";
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("1.5000", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue());
                    Support.AreEqual("175.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue());
                }
                else
                {
                    Support.AreEqual("1.500", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue());
                    Support.AreEqual("175.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                }

                Reports.TestStep = "Edit Loan Discount Points in Loan Charges Tab.";
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.0");
                    FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                else
                {
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.0");
                    FastDriver.NewLoan.CreditChargeIRSPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Discount Percentage in Loan Charges Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("1.0000", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue());
                    Support.AreEqual("100.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue());
                }
                else
                {
                    Support.AreEqual("1.000", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue());
                    Support.AreEqual("100.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                }
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0060()
        {
            try
            {
                Reports.TestDescription = "EWC_17_0002: User modifies Loan Discount Points calculation formula values after original calculation.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                }
                else
                {
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Buyer Credit in Loan Charges Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.SetText, "5000");
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Validate Discount Percentage in Loan Charges Tab.";
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("1.7500", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue());
                    Support.AreEqual("175.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue());
                }
                else
                {
                    Support.AreEqual("1.750", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue());
                    Support.AreEqual("175.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                }

                Reports.TestStep = "Edit Loan Amount in Loan Details Tab.";
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate Discount Percentage in Loan Charges Tab.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("1.7500", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue());
                    Support.AreEqual("175.00", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue());
                }
                else
                {
                    Support.AreEqual("1.750", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue());
                    Support.AreEqual("175.00", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                }
                
                Reports.TestStep = "Edit Buyer Credit in Loan Charges Tab.";
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.SetText, "5000");
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Validate Discount Percentage in Loan Charges Tab.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("1.7500", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue());
                    Support.AreEqual("87.50", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue());
                }
                else
                {
                    Support.AreEqual("1.750", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue());
                    Support.AreEqual("87.50", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                }

                Reports.TestStep = "Edit Loan Amount in Loan Details Tab.";
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0061()
        {
            try
            {
                Reports.TestDescription = "EWC_16_18_0001: User modifies loan amount in New Loan charge process after interest charges have been calculated.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Loan Amount in Loan Details Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(false, false, 20);
                FastDriver.WebDriver.HandleDialogMessage(false, false, 20);
                FastDriver.WebDriver.HandleDialogMessage(false, false, 20);
                FastDriver.WebDriver.HandleDialogMessage(false, false, 20);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 20);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Enter a Loan Amount.";
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("5000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0062()
        {
            try
            {
                Reports.TestDescription = "EWC_19_0001: User tries to save a charge process instance without the minimum required data. For New Loan, this is either Lender or Mortgage Broker business party name.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New and Enter details";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate the message: Lender or Mortgage Broker is a required field.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("BusOrgID : Lender or Mortgage Broker Business Party Name is required field.", FastDriver.NewLoan.MessagePaneTop.Text.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0063()
        {
            try
            {
                Reports.TestDescription = "EWC_20_0001: User changes the number of months or monthly amount for a calculated impound charge after initial calculation.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Months in Impounds charges in Loan Charges tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 3, TableAction.SetText, "6");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                else
                {
                    FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 3, TableAction.SetText, "6");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Validate the months and charge for Impound in Loan Charges Tab.";
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("6", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("84.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }
                else
                {
                    Support.AreEqual("6", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("84.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }
                
                Reports.TestStep = "Edit Months in Impounds charges in Loan Charges tab.";
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 3, TableAction.SetText, "7");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                }
                else
                {
                    FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 3, TableAction.SetText, "7");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the months and charge for Impound in Loan Charges Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("7", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("84.00", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }
                else
                {
                    Support.AreEqual("7", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("14.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("84.00", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0064()
        {
            try
            {
                Reports.TestDescription = "EWC_21_0001: User modifies Loan Amount in Loan Details section after update the Loan Liability amount.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Modify a lender Name";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                else
                {
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                    FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0065()
        {
            try
            {
                Reports.TestDescription = "EWC_22_0001: If Due Date field has a date value and user adds or modifies.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD.";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Note Tab and Enter details.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteConstructionMortgage.FASetCheckbox(true);
                FastDriver.NewLoan.NotePaymentType.FASelectItem("Principal & Interest");
                FastDriver.NewLoan.NoteInterestRate.FASetText("1");
                FastDriver.NewLoan.NoteBaseRate.FASetText("0.5");
                FastDriver.NewLoan.NotePlusMinusRate.FASetText("0.75");
                FastDriver.NewLoan.NoteEquivalentRate.FASetText("0.25");
                FastDriver.NewLoan.NoteMaxChargeRate.FASetText("0.15");
                FastDriver.NewLoan.NoteBalloonPayment.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_Percentagetext.FASetText("5");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("15");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("08-11-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("11-06-2012");
                FastDriver.NewLoan.NoteLastPaymentDue.FASetText("04-19-2013");
                FastDriver.NewLoan.NoteDueDate.FASetText("08-25-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("2500.00");
                FastDriver.NewLoan.NotePaymentDate_and_Period.FASetText("First Monday Of Every Month");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Quarter");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("15");
                FastDriver.NewLoan.NoteLoanterm_Month.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0066()
        {
            try
            {
                Reports.TestDescription = "EWC_23_0001: Recalculated Loan Due Date falls on a Saturday or Sunday.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("FHA");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("5000");
                FastDriver.NewLoan.FindGABCode("255");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("09-21-2012");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-21-2012");
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteInterestFrom.FASetText("09-21-2012");
                FastDriver.NewLoan.NotePayablePer.FASelectItem("Day");
                FastDriver.NewLoan.NoteLoanTerm.FASetText("1");
                FastDriver.NewLoan.NotePaymentDate_and_Period.Click();

                Reports.TestStep = "Select a date and verify message.";
                FastDriver.WeekendWarning.WaitForScreenToLoad();
                Support.AreEqual("Loan Due Date falls on a Saturday.", FastDriver.WeekendWarning.RescissionNotice.Text.Clean());
                FastDriver.WeekendWarning.rdoMonday.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0067()
        {
            try
            {
                Reports.TestDescription = "EWC_24_0001: When the user enters an invalid email address.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("FHA");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("5000");
                FastDriver.NewLoan.LoanDetailsEdit.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsEmailAddress.FASetText("yxyxz.jns.com");
                FastDriver.NewLoan.LoanDetailsDays.Click();

                Reports.TestStep = "Validate email Address.";
                Support.AreEqual("Email address is invalid. Valid Examples: xyz@abc.com xyz@abc.com.uk xyz_123@abc.com xyz-12.wuv@abc.cnn.edu.uk", FastDriver.NewLoan.LoanDetailsEmailAddress.FAGetAttribute("title").Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0068()
        {
            try
            {
                Reports.TestDescription = "EWC_25_0001: User changes the business party of New Lender on a New Loan AND the new loan had Mortgage Product already populated for the loan.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("177");
                FastDriver.NewLoan.LoanDetailsMortgageProduct.FASelectItem("50 - i Declare - Regular");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter a GAB Code and click on Find Button.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("255");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0069()
        {
            try
            {
                Reports.TestDescription = "EWC_26_0001: User attempted to add a second instance of any of the follow four LenderOriginate Branch, Lender Mortgage Centre, Lender Sign Location or Lender Mobile Banker, into a sale New Loan record.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("255");
                //FastDriver.NewLoan.LoanDetailsMortgageProduct.FASelectItem("50 - i Declare - Regular");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter a details in Related parties tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Lender- Originating Branch");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "247");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter a duplicate in Related parties tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItemBySendkeys, "Lender- Funding");
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0070()
        {
            try
            {
                Reports.TestDescription = "EWC_27_0001: User deletes New Loan Lender and tries to navigate away from New Loan functionality without enter Lender or Mortgage Broker.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Remove button in Loan Details Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validate: Error(s) occurred. See Message pane.";
                Support.AreEqual("Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("BusOrgID : Lender or Mortgage Broker Business Party Name is required field.", FastDriver.NewLoan.MessagePaneTop.Text.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0071()
        {
            try
            {
                Reports.TestDescription = "EWC_28_0001: The user attempts to change the 1 or 2 New Loan Liability amount after a Fee has been calculated.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to file fees and calculate fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AllFees.FAClick();
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Select a Fee and click on next.";
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.TitleFeesRateTypes.FASelectItem("New Home Rate - Title Only");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Enter details for Fee.";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 6, TableAction.SelectItem, "Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.FAFindElement(ByLocator.Id, "tCF_tCS_ucCSFs_grCalcSummary_0_ddlFastFees").FASelectItemByIndex(1);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan and delete entry";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0072()
        {
            try
            {
                Reports.TestDescription = "EWC_29_0001: The user attempts to remove or delete the 1 or 2 new loan liability instance from the New Loan Summary screen.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "New Encumbrance", sellerCredit: 500.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "Loan Amount", sellerCharge: 500.00);
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter details for a instance in new loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100");
                FastDriver.NewLoan.FindGABCode("266");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to file fees and calculate fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AllFees.FAClick();
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Select a Fee and click on next.";
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.TitleFeesRateTypes.FASelectItem("New Home Rate - Title Only");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Enter details for Fee.";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 6, TableAction.SelectItem, "Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 7, TableAction.SetText, "10.00");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.FAFindElement(ByLocator.Id, "tCF_tCS_ucCSFs_grCalcSummary_0_ddlFastFees").FASelectItemByIndex(1);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0073()
        {
            try
            {
                Reports.TestDescription = "EWC_30_0001: The user attempts to change the 1 new loan liability after a fee has been issued.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "New Encumbrance", sellerCredit: 500.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "Loan Amount", sellerCharge: 500.00);
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter details for a instance in new loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100");
                FastDriver.NewLoan.FindGABCode("266");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to file fees and calculate fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AllFees.FAClick();
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Select a Fee and click on next.";
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.TitleFeesRateTypes.FASelectItem("New Home Rate - Title Only");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Enter details for Fee.";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 6, TableAction.SelectItem, "Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 7, TableAction.SetText, "10.00");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.FAFindElement(ByLocator.Id, "tCF_tCS_ucCSFs_grCalcSummary_0_ddlFastFees").FASelectItemByIndex(1);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "To click on Fee Transfer button in Active Disbursement Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select a instance and edit it.";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();

                Reports.TestStep = "Edit Liability Amount.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("200");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0074()
        {
            try
            {
                Reports.TestDescription = "EWC_31_0001: The user attempts to change the 2nd new loan liability after a fee has been issued.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "New Encumbrance", sellerCredit: 500.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "Loan Amount", sellerCharge: 500.00);
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter details for a instance in new loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100");
                FastDriver.NewLoan.FindGABCode("266");
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                Support.AreEqual("*ALTA Expanded (Eagle Loan) Policy", FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Navigate to file fees and calculate fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AllFees.FAClick();
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Select a Fee and click on next.";
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.TitleFeesRateTypes.FASelectItem("New Home Rate - Title Only");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Enter details for Fee.";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 6, TableAction.SelectItem, "Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 7, TableAction.SetText, "10.00");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.FAFindElement(ByLocator.Id, "tCF_tCS_ucCSFs_grCalcSummary_0_ddlFastFees").FASelectItemByIndex(1);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "To click on Fee Transfer button in Active Disbursement Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select a instance and edit it.";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0075()
        {
            try
            {
                Reports.TestDescription = "EWC_31_0002: The user attempts to change the 2nd new loan liability after a fee has been issued.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to New Loan and Enter GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "New Encumbrance", sellerCredit: 500.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "Loan Amount", sellerCharge: 500.00);
                }
                
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Enter details for a instance in new loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100");
                FastDriver.NewLoan.FindGABCode("266");
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                Support.AreEqual("*ALTA Expanded (Eagle Loan) Policy", FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Navigate to file fees and calculate fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AllFees.FAClick();
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Select a Fee and click on next.";
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.TitleFeesRateTypes.FASelectItem("New Home Rate - Title Only");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Enter details for Fee.";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 6, TableAction.SelectItem, "Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 7, TableAction.SetText, "10.00");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.FAFindElement(ByLocator.Id, "tCF_tCS_ucCSFs_grCalcSummary_0_ddlFastFees").FASelectItemByIndex(1);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "To click on Fee Transfer button in Active Disbursement Summary.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();

                Reports.TestStep = "Select a instance and edit it.";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0076()
        {
            try
            {
                Reports.TestDescription = "EWC_32_0001: For Interest on New Loan, user enters Buyer Credit and tabs out of Buyer Credit field.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Buyer Charge and Buyer Credit in New Loan Charges Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Interest on new loan", buyerCharge: 220.00);
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 4, TableAction.SetText, "100");
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", buyerCharge: 220.00);
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 4, TableAction.SetText, "100.00");
                    FastDriver.NewLoan.CreditChargeIRSPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                
                Reports.TestStep = "Validate buyer charge in loan charges Tab.";
                Support.AreEqual("", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0077()
        {
            try
            {
                Reports.TestDescription = "EWC_33_0001: For Interest on New Loan, user enters Buyer Credit and tabs out of Buyer Credit field.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Buyer Charge and Buyer Credit in New Loan Charges Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Interest on new loan", buyerCharge: 220.00);
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 4, TableAction.SetText, "100");
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.SetText, "220.00");
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", buyerCredit: 220.00);
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 4, TableAction.SetText, "100.00");
                    FastDriver.NewLoan.CreditChargeIRSPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 3, TableAction.SetText, "220.00");
                    FastDriver.NewLoan.CreditChargeIRSPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }

                Reports.TestStep = "Validate buyer credit in loan charge Tab.";
                Support.AreEqual("", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0078()
        {
            try
            {
                Reports.TestDescription = "EWC_34_0001: User tries to change HUD Type on Loan Details tab.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();;
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Buyer Charge and Buyer Credit in New Loan Charges Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Interest on new loan", buyerCredit: 220.00);
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", buyerCredit: 220.00);
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 4, TableAction.SetText, "220.00");
                    FastDriver.NewLoan.CreditChargeIRSPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }


                Reports.TestStep = "Enter details for an instance.";
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB("255");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select HUD Type as Legacy on New Loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.FormType_CD.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                else
                {
                    FastDriver.NewLoan.FormType_HUD.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                
                

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0079()
        {
            try
            {
                Reports.TestDescription = "EWC_35_0001: User deletes first loan instance of New Loan.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Buyer Charge and Buyer Credit in New Loan Charges Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Interest on new loan", buyerCredit: 220.00);
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", buyerCredit: 220.00);
                    FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 4, TableAction.SetText, "220.00");
                    FastDriver.NewLoan.CreditChargeIRSPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }


                Reports.TestStep = "Enter details for an instance.";
                FastDriver.NewLoan.ClickLoanDetailsTab();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500");
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB("255");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete us Shortcut Keys.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0080()
        {
            try
            {
                Reports.TestDescription = "EWC_36_0001: User clicks Remove button to remove Lender.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Loan Charges and Enter details for CD/HUD.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1.5");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-06-2012");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("06-27-2013");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("250");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 250);
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.5");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Selected.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("200.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("100.00");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.75");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 5, monthlyCharge: 14);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage insurance", months: 6, monthlyCharge: 5);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal fee", gfeAmount: 101.00);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("100.00");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 250.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 200, loanEstimate: 100);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.75");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 5, monthlyCharge: 14, loanEstimate: 100);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Mortgage Insurance", months: 6, monthlyCharge: 5);
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50.00");
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50.00");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Remove button in Loan Details Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            } 
        }

        [TestMethod]
        public void FMUC0047_REG0081()
        {
            try
            {
                Reports.TestDescription = "EWC_37_0001: User clicks Remove button to remove Mortgage Broker.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details CD/HUD.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 50);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 250.00, sellerCharge: 150.00, gfeAmount: 100.00);
                }
                else 
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 50.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 250.00, sellerCharge: 150.00, loanEstimate: 100.00);
                }
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Remove button in Mortgage broker Tab.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("50.00", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());


            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0082()
        {
            try
            {
                Reports.TestDescription = "EWC_38_0001: User tries to change HUD Type after removal of charges on New Loan.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("10000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                Support.AreEqual("10,000.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("V100M07");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("L00100");
                FastDriver.NewLoan.LoanDetailsSalesRep1.FASelectItem("FATICO, Firstam");
                FastDriver.NewLoan.LoanDetailsFundingDate.FASetText("03-16-2011");
                FastDriver.NewLoan.LoanDetailsSigningDate.FASetText("08-03-2012");
                FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FASetText("12-12-2012");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("50");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.Click();
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FirstAm is not responsible for this.");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Mortgage Broker and Enter details CD.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageSalesRep1.FASelectItem("FATICO, Firstam");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 0.00);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit report", buyerCharge: 0.00, sellerCharge: 0.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 0.00);
                    FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(Row: 1, buyerCharge: 250.00, sellerCharge: 150.00);
                    //FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", buyerCharge: 0.00, sellerCharge: 0.00);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select HUD Type as Legacy on New Loan screen.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.NewLoan.FormType_CD.FAClick();
                }
                else
                {
                    FastDriver.NewLoan.FormType_HUD.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.FormType_CD.Selected.ToString());
                }
                else
                {
                    Support.AreEqual("False", FastDriver.NewLoan.FormType_HUD.IsSelected().ToString());
                }
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0083()
        {
            try
            {
                Reports.TestDescription = "EWC_39_0001: User tries to change HUD Type while access New Loan 1 Lender or New Loan 1 Mortgage Broker through GFE Entry screen.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Click on GFE tab and Select New Loan 1- Mortgage Broker from the GFE3 Process ";
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.LeftNavigation.Navigate<GFEEntryLoanTerms>("GFE Entry").WaitForScreenToLoad();
                    FastDriver.GFEEntryGFE.GFEtab.FAClick();
                    FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItemBySendingKeys("N");
                    FastDriver.GFEEntryGFE.GFE3ChgProcessType.FASelectItemBySendingKeys("N");
                    FastDriver.NewLoanDlg.WaitForScreenToLoad();
                    FastDriver.NewLoanDlg.LoanDetails.FAClick();
                    FastDriver.NewLoanDlg.CD.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("New Loan", true, 30);
                    FastDriver.NewLoanDlg.SwitchToDialogContentFrame();
                    FastDriver.DialogBottomFrame.ClickCancel();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.GFEEntryGFE.SwitchToContentFrame();
                }
                else 
                {
                    Reports.StatusUpdate("Flow was not designed for CD.", true);
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0084()
        {
            try
            {
                Reports.TestDescription = "EWC_44_42_43_0001: 1.User changes the Loan Type from FHA or VA to other loan type and itemized charges are not disbursed 2.User changes the Loan Type from FHA or VA to other loan type and itemized charges are not disburs";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("4000");
                FastDriver.NewLoan.FindGABCode("247");

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "“EWC_42 Aggregate of Itemized charges cannot exceed Our origination charge” <OK> ";
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCharge: 100.00);
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 1, TableAction.SetText, "Extra Charges");
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 4, TableAction.Click);
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 4, TableAction.SetText, "500.00");
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 5, TableAction.Click);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 3, TableAction.SetText, "50.00");
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForScreenToLoad();
                    //FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                    FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                    FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(4, 1, TableAction.On);
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Print Check";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                    FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                    FastDriver.ActiveDisbursementSummary.Print.FAClick();
                    FastDriver.PrintChecks.WaitForScreenToLoad();
                    FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 1, TableAction.Click);
                    FastDriver.PrintChecks.Deliver.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.PrintDlg.WaitForScreenToLoad();
                    FastDriver.PrintDlg.Print.FAClick();
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 210);
                    FastDriver.BottomFrame.Done();
                    FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("No flow has been included for CD-type files. Ending test", true);
                    FastDriver.WebDriver.Quit();
                }
                

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0085()
        {
            try
            {
                Reports.TestDescription = "EWC_47_0001: 1.If the file is subject to Itemization and for Our Origination Charge, user enters Buyer Credit and tabs out of Buyer Credit field.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("4000");
                FastDriver.NewLoan.FindGABCode("247");

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "“EWC_42 Aggregate of Itemized charges cannot exceed Our origination charge” <OK> ";
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCharge: 100.00);
                    FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.SetText, "100.00");
                    FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.SetText, "100.00");
                    FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    Reports.StatusUpdate("No flow has been included for CD-type files. Ending test", true);
                    FastDriver.WebDriver.Quit();
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0086()
        {
            try
            {
                Reports.TestDescription = "EWC_48_0001: 1.If the file is subject to Itemization and for Our Origination Charge, user enters Buyer Charge and tabs out of Buyer Charge field.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Enter the Loan Details in New Loan.";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                    FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("4000");
                    FastDriver.NewLoan.FindGABCode("247");
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Validate: Our Origination Charge is a Buyer Charge. Itemized Charge cannot be a Buyer Credit.";
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCharge: 100.00);
                    FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.SetText, "100.00");
                    FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    Reports.StatusUpdate("No flow included in this test for CD type files.", true);
                    FastDriver.WebDriver.Quit();
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0087()
        {
            try
            {
                Reports.TestDescription = "EWC_49_0001: If Our Origination Charge is a Buyer Charge and User enters buyer credit amount for Itemized Charges.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Enter the Loan Details in New Loan.";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                    FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("4000");
                    FastDriver.NewLoan.FindGABCode("247");
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Validate: Our Origination Charge is a Buyer Charge. Itemized Charge cannot be a Buyer Credit.";
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCredit: 100.00);
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 1, TableAction.SetText, "Charges");
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 3, TableAction.Click);
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 3, TableAction.SetText, "75.00");
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 5, TableAction.Click);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    Reports.StatusUpdate("No flow included in this test for CD type files.", true);
                    FastDriver.WebDriver.Quit();
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0088()
        {
            try
            {
                Reports.TestDescription = "EWC_50_0001: If Our Origination Charge is a Buyer Credit and User enters buyer charge amount for Itemized Charges.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Enter the Loan Details in New Loan.";
                    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                    FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                    FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("4000");
                    FastDriver.NewLoan.FindGABCode("247");
                    FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Validate: Our Origination Charge is a Buyer Charge. Itemized Charge cannot be a Buyer Credit.";
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 1, TableAction.SetText, "Charges");
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 4, TableAction.Click);
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 4, TableAction.SetText, "75.00");
                    FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 5, TableAction.Click);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    Support.AreEqual("", FastDriver.NewLoan.ItemizationOriginationChargesTable.PerformTableAction(1, 3, TableAction.GetInputValue).Message.Clean());

                    Reports.TestStep = "Validate: Buyer Charge and Buyer Credit cannot exist together for Our Origination Charge. Do you wish to remove Buyer Credit?.";
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCharge: 100.00);
                    FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.SetText, "100");
                    FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 5, TableAction.Click);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else 
                {
                    Reports.StatusUpdate("No flow included in this test for CD type files.", true);
                    FastDriver.WebDriver.Quit();
                }
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0089()
        {
            try
            {
                Reports.TestDescription = "EWC_51_45_46_0001: 1.For Our Origination Charge, user enters Buyer Credit and tabs out of Buyer Credit field 2.For Our Origination Charge, user enters Buyer Charge and tabs out of Buyer Charge field 3.User tries to save";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Remove button in Loan Details Tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("4000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Our origination charge", buyerCharge: 100);
                    FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.SetText, "100");
                    FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 100.00);
                    FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(2, 4, TableAction.SetText, "100.00");
                    FastDriver.NewLoan.CreditChargeIRSPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }
                

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0091()
        {
            try
            {
                Reports.TestDescription = "FD_EQUAL_0001: Enter details to check Field Validations.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //fileRequest.formType = FormType.CD;
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)7000.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)7000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                Support.value = FastDriver.NewLoan.LoanDetailsLoantype.Text.Clean();
                Support.AreEqual(Support.value, FastDriver.NewLoan.LoanDetailsLoantype.Text.Clean());
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("12345678901.01");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcd");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn");

                Reports.TestStep = "Enter Details for Field Validations.";
                FastDriver.NewLoan.LoanDetailsDays.FASetText("99");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstu");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Enter Details for Field Validations.";
                if (fileRequest.formType == FormType.HUD)
                {
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCredit.Exists().ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationCharge.Exists().ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesInterestCalculationZero.Exists().ToString());
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("12345678901.01");
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("12.4567");
                    FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FASetText("12345678901.01");
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FASetText("12345678901.01");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCharge.Displayed.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Displayed.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsZero.Displayed.ToString());
                    //FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FASetText("12345678901.01");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("12.4545");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FASetText("12345678901.01");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 10, monthlyCharge: 12345678901.01, buyerCharge: 12345678901.01, sellerCharge: 12345678901.01);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 12345678901.01);
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCharge.Displayed.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Displayed.ToString());
                    Support.AreEqual("False", FastDriver.NewLoan.LoanChargesCredit_ChargePointsZero.Displayed.ToString());
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 12345678901.01, loanEstimate: 12345678901.01);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("12.454");
                    FastDriver.NewLoan.CreditChargeIRSPoints.FASetText("12345678901.01");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 10, monthlyCharge: 12345678901.01, buyerCharge: 12345678901.01, sellerCharge: 12345678901.01);
                }

                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCredit.Displayed.ToString());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.Displayed.ToString());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentZero.Displayed.ToString());
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("12345678901.01");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("12345678901.01");
                if (fileRequest.formType == FormType.HUD)
                {
                    FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FASetText("12345678901.01");
                }
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                if (fileRequest.formType == FormType.HUD)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 12345678901.01, newDescription: "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghi");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 12345678901.01, newDescription: "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghi");
                }
                FastDriver.NewLoan.ClickNoteTab();
                Support.AreEqual("False", FastDriver.NewLoan.NoteConstructionMortgage.Selected.ToString());
                Support.AreEqual("False", FastDriver.NewLoan.NoteAssignmentofRents.Selected.ToString());
                Support.value = FastDriver.NewLoan.NotePaymentType.Text.Clean();
                Support.AreEqual(Support.value, FastDriver.NewLoan.NotePaymentType.Text.Clean());
                FastDriver.NewLoan.NoteBaseRate.FASetText("1234.12345");
                FastDriver.NewLoan.NoteInterestRate.FASetText("1234.12345");
                FastDriver.NewLoan.NotePlusMinusRate.FASetText("1234.12345");
                FastDriver.NewLoan.NoteEquivalentRate.FASetText("1234.12345");
                FastDriver.NewLoan.NoteMaxChargeRate.FASetText("1234.12345");
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("999");
                FastDriver.NewLoan.NoteLateChargeof_Amountradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_AmountText.FASetText("12345678901.01");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("10-08-2012");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("10-25-2012");
                FastDriver.NewLoan.NoteLastPaymentDue.FASetText("10-25-2013");
                FastDriver.NewLoan.NoteDueDate.FASetText("11-09-2012");
                FastDriver.NewLoan.NoteAgreementDate.FASetText("10-05-2012");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("12345678901.01");
                FastDriver.NewLoan.NotePaymentDate_and_Period.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn");
                Support.value = FastDriver.NewLoan.NotePayablePer.Text.Clean();
                Support.AreEqual(Support.value, FastDriver.NewLoan.NotePayablePer.Text.Clean());
                FastDriver.NewLoan.NoteLoanTerm.FASetText("999");
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesTrustorMortgagor.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn12345");
                FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn12345");
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                Support.value = FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean();
                Support.AreEqual(Support.value, FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean());
                FastDriver.NewLoan.ClickRcdgMortageeTab();
                FastDriver.NewLoan.RCDG_MortageTrustDeedDate.FASetText("10-08-2012");
                FastDriver.NewLoan.RCDG_MortageRecordingDate.FASetText("10-05-2012");
                FastDriver.NewLoan.RCDG_MortageInstrument.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn");
                FastDriver.NewLoan.RCDG_MortageBook.FASetText("ABCDEFGHIJKLMNOPQRST");
                FastDriver.NewLoan.RCDG_MortagePage.FASetText("ABCDEFGHIJKLMNOPQRST");
                FastDriver.NewLoan.RCDG_MortageTitleInsuranceMortagagee.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn");
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();

                Reports.TestStep = "Enter details for field validations.";
                FastDriver.NewLoan.ClickNoteTab();
                Support.AreEqual("False", FastDriver.NewLoan.NoteConstructionMortgage.Selected.ToString());
                Support.AreEqual("False", FastDriver.NewLoan.NoteAssignmentofRents.Selected.ToString());
                Support.value = FastDriver.NewLoan.NotePaymentType.Text.Clean();
                Support.AreEqual(Support.value, FastDriver.NewLoan.NotePaymentType.Text.Clean());
                FastDriver.NewLoan.NoteBaseRate.FASetText("12345");
                FastDriver.NewLoan.NoteInterestRate.FASetText("12345");
                FastDriver.NewLoan.NotePlusMinusRate.FASetText("12345");
                FastDriver.NewLoan.NoteEquivalentRate.FASetText("12345");
                FastDriver.NewLoan.NoteMaxChargeRate.FASetText("12345");
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Percentageradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("999");
                FastDriver.NewLoan.NoteLateChargeof_Amountradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_AmountText.FASetText("123456789012");
                FastDriver.NewLoan.NoteInterestFrom.FASetText("10/022");
                FastDriver.NewLoan.NoteFirstPaymentDue.FASetText("10/022");
                FastDriver.NewLoan.NoteLastPaymentDue.FASetText("10/022");
                FastDriver.NewLoan.NoteDueDate.FASetText("10/022");
                FastDriver.NewLoan.NoteAgreementDate.FASetText("10/022");
                FastDriver.NewLoan.NotePaymentAmount.FASetText("123456789012");
                FastDriver.NewLoan.NotePaymentDate_and_Period.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn");
                Support.value = FastDriver.NewLoan.NotePayablePer.Text.Clean();
                Support.AreEqual(Support.value, FastDriver.NewLoan.NotePayablePer.Text.Clean());
                FastDriver.NewLoan.NoteLoanTerm.FASetText("999");

                Reports.TestStep = "Validate the fields.";
                Support.AreEqual("Value cannot be greater than 9999.99999", FastDriver.NewLoan.NoteBaseRate.FAGetAttribute("title"));
                Support.AreEqual("Value cannot be greater than 9999.99999", FastDriver.NewLoan.NoteInterestRate.FAGetAttribute("title"));
                Support.AreEqual("Value cannot be greater than 9999.99999", FastDriver.NewLoan.NotePlusMinusRate.FAGetAttribute("title"));
                Support.AreEqual("Value cannot be greater than 9999.99999", FastDriver.NewLoan.NoteEquivalentRate.FAGetAttribute("title"));
                Support.AreEqual("Value cannot be greater than 9999.99999", FastDriver.NewLoan.NoteMaxChargeRate.FAGetAttribute("title"));
                Support.AreEqual("Date is Invalid", FastDriver.NewLoan.NoteInterestFrom.FAGetAttribute("title"));
                Support.AreEqual("Date is Invalid", FastDriver.NewLoan.NoteFirstPaymentDue.FAGetAttribute("title"));
                Support.AreEqual("Date is Invalid", FastDriver.NewLoan.NoteLastPaymentDue.FAGetAttribute("title"));
                Support.AreEqual("Date is Invalid", FastDriver.NewLoan.NoteDueDate.FAGetAttribute("title"));
                Support.AreEqual("Date is Invalid", FastDriver.NewLoan.NoteAgreementDate.FAGetAttribute("title"));
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.NotePaymentAmount.FAGetAttribute("title"));
                Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn", FastDriver.NewLoan.NotePaymentDate_and_Period.FAGetValue());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0092()
        {
            try
            {
                Reports.TestDescription = "FD_GREATER_0001: Enter details to check Field Validations.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.formType = FormType.CD;
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("123456789012");
                FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("123456789012");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcd");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmn");
                FastDriver.NewLoan.LoanDetailsDays.FASetText("11");
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuv");

                Reports.TestStep = "Validate the fields.";
                Support.AreEqual("Cal Vet", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetAttribute("title"));
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetAttribute("title"));
                Support.AreEqual("11", FastDriver.NewLoan.LoanDetailsDays.FAGetValue());
                Support.AreNotEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuv", FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FAGetValue());
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Enter details for field validations.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "Loan Amount", buyerCredit: 123456789012);
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tLC_NLC_cgPB_dcs_0_tbd").FAGetAttribute("title"));
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.PrincipalBalanceChargesTable, "Loan Amount", buyerCredit: 0.00);
                if (fileRequest.formType == FormType.HUD)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("123456789012");
                    FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FASetText("123456789012");
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("123");
                    FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FASetText("123456789012");
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FASetText("123456789012");
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCharge.Displayed.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsCredit.Displayed.ToString());
                    Support.AreEqual("True", FastDriver.NewLoan.LoanChargesCredit_ChargePointsZero.Displayed.ToString());
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("123456789012");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("123456789012");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("123");
                    FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FASetText("123456789012");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FASetText("123456789012");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 12, monthlyCharge: 123456789012, buyerCharge: 123456789012, buyerCredit: 123456789012);
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99.9999", FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FAGetAttribute("title"));

                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", loanEstimate: 123456789012);
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 123456789012, loanEstimate: 123456789012);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("123");
                    FastDriver.NewLoan.CreditChargePointsPercentageIRSPoints.FASetText("123456789012");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 12, monthlyCharge: 123456789012, buyerCharge: 123456789012, sellerCharge: 123456789012);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(2, 7, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tLC_NLC_IPror_CGrid_dcs_0_tga").FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tLC_NLC_cgCCP_dcs_0_tbc").FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 7, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tLC_NLC_cgCCP_dcs_0_tga").FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99.999", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.CreditChargePointsPercentageIRSPoints.FAGetAttribute("title"));
                    Support.AreEqual("12", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tLC_NLC_icgIC_dcs_0_tmc").FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tLC_NLC_icgIC_dcs_0_tbc").FAGetAttribute("title"));
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 6, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tLC_NLC_icgIC_dcs_0_tsc").FAGetAttribute("title"));  
                }
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.Displayed.ToString());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCredit.Displayed.ToString());
                Support.AreEqual("True", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentZero.Displayed.ToString());
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("123456789012");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("123456789012");
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetAttribute("title"));
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.Click();
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FAGetAttribute("title"));
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Enter details for field validations.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                if (fileRequest.formType == FormType.HUD)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 123456789012, newDescription: "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghi");
                    Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghi", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tMB_NMB_aYSP_dcs_0_tbc").FAGetAttribute("title"));
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 123456789012, newDescription: "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghi");
                    Support.AreEqual("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghi", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "tNL_tMB_NMB_aYSP_dcs_0_tbc").FAGetAttribute("title"));
                }

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0093()
        {
            try
            {
                Reports.TestDescription = "FD_GREATERDecimal_0001: Enter details to check Field Validations.";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.formType = FormType.CD;
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter the Loan Details in New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("RHS");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("12345678901.123");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsDays.FASetText("10");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (fileRequest.formType == FormType.HUD)
                {
                    FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FASetText("12345678901.123");
                    FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FASetText("12345678901.123");
                    FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FASetText("1.12345");
                    FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FASetText("12345678901.123");
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FASetText("12345678901.123");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FASetText("12345678901.123");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FASetText("12345678901.123");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FASetText("12345678901.123");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FASetText("1.12345");
                    FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.Click();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FASetText("12345678901.123");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's insurance", months: 12, monthlyCharge: 12345678901.123, buyerCharge: 12345678901.123, buyerCredit: 12345678901.123);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.CreditChargePointsTable, "% of Loan Amount (Points)", buyerCharge: 12345678901.123, loanEstimate: 12345678901.123);
                    FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.1234");
                    FastDriver.NewLoan.CreditChargePointsPercentageIRSPoints.FASetText("12345678901.123");
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.AggregateAccountingAdjustmentTable, "Homeowner's Insurance", months: 11, monthlyCharge: 12345678901.123, buyerCharge: 12345678901.123, sellerCharge: 12345678901.123);
                }
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("12345678901.123");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("12345678901.123");
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                if (fileRequest.formType == FormType.HUD)
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Yield Spread Premium", amount: 12345678901.123, newDescription: "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghi");
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.NewLoan.BrokerFeeTable, "Broker Fee", amount: 12345678901.123, newDescription: "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghi");
                }
                FastDriver.NewLoan.ClickNoteTab();
                FastDriver.NewLoan.NoteBaseRate.FASetText("123.123456");
                FastDriver.NewLoan.NoteInterestRate.FASetText("123.123456");
                FastDriver.NewLoan.NotePlusMinusRate.FASetText("123.123456");
                FastDriver.NewLoan.NoteEquivalentRate.FASetText("123.123456");
                FastDriver.NewLoan.NoteMaxChargeRate.FASetText("123.123456");
                FastDriver.NewLoan.NoteLateChargeof_checkbox.FASetCheckbox(true);
                FastDriver.NewLoan.NoteLateChargeof_Amountradio.FAClick();
                FastDriver.NewLoan.NoteLateChargeof_AmountText.FASetText("12345678901.123");
                FastDriver.NewLoan.NoteLateChargeofDays.FASetText("999");
                FastDriver.NewLoan.ClickPartiesTab();
                FastDriver.NewLoan.PartiesFindGAB(GABCode: "247");
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                Support.value = FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean();
                Support.AreEqual(Support.value, FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean());
                FastDriver.NewLoan.ClickRecapTab().WaitForRecapToLoad();
                Debug.Print(FastDriver.NewLoan.RecapTable.Text.Clean());

                Reports.TestStep = "Validate the fields.";
                FastDriver.NewLoan.ClickLoanDetailsTab();
                Support.AreEqual("RHS", FastDriver.NewLoan.LoanDetailsLoantype.FAGetSelectedItem());
                Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue());
                Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue());
                Support.AreEqual("10", FastDriver.NewLoan.LoanDetailsDays.FAGetValue());
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                if (fileRequest.formType == FormType.HUD)
                {
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue());
                    Support.AreEqual("1.1234", FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetValue());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanChargesOriginationChargeAmount.FAGetValue());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanChargesCredit_ChargePoints_Amount.FAGetValue());
                    Support.AreEqual("-12,345,678,901.12", FastDriver.NewLoan.LoanChargesCredit_ChargePointsBuyerCharge.FAGetValue());
                    Support.AreEqual("-12,345,678,901.12", FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FAGetValue());
                    Support.AreEqual("1.1234", FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue());
                    Support.AreEqual("12", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(2, 6, TableAction.GetInputValue).Message.Clean());
                }
                else
                {
                    Support.AreEqual("138,641,974.06", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("1.123", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.CreditChargePointsPercentageIRSPoints.FAGetValue());
                    Support.AreEqual("11", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                    Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(2, 6, TableAction.GetInputValue).Message.Clean());
                }
                Support.AreEqual("-12,345,678,901.12", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue());
                Support.AreEqual("-12,345,678,901.12", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FAGetValue());
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.BrokerFeeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                FastDriver.NewLoan.ClickNoteTab();
                Support.AreEqual("123.12345", FastDriver.NewLoan.NoteBaseRate.FAGetValue());
                Support.AreEqual("123.12345", FastDriver.NewLoan.NoteInterestRate.FAGetValue());
                Support.AreEqual("123.12345", FastDriver.NewLoan.NotePlusMinusRate.FAGetValue());
                Support.AreEqual("123.12345", FastDriver.NewLoan.NoteEquivalentRate.FAGetValue());
                Support.AreEqual("123.12345", FastDriver.NewLoan.NoteMaxChargeRate.FAGetValue());
                Support.AreEqual("999", FastDriver.NewLoan.NoteLateChargeofDays.FAGetValue());
                Support.AreEqual("12,345,678,901.12", FastDriver.NewLoan.NoteLateChargeof_AmountText.FAGetValue());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0094()
        {
            try
            {
                Reports.TestDescription = "FM_1510: Copy Loan Amount to Buyer/Borrower Credit ";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.formType = FormType.CD;
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details in New Loan screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Seller Carryback");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("220000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Click in LoanCharges Tab and verify the Borrower Credit amount";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                Support.AreEqual("220,000.00", FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0095()
        {
            try
            {
                Reports.TestDescription = "MF1_002:Create First New Loan with HUD type Legacy";
                Login(AutoConfig.FASTHomeURL);
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("MORTLNDR"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.NewLender,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                        RoleTypeObjectCD = "DirectedBy",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.LenderOriginatingBranch,
                        },
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        RoleTypeObjectCD = "ASSOTDPTY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.MortgageBroker,
                        },
                    }
                };
                #endregion
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details in New Loan screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("177");
                FastDriver.NewLoan.LoanDetailsMortgageProduct.FASelectItem("50 - i Declare - Regular");
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsLoantype.Text.Contains("Cal Vet").ToString());
                FastDriver.BottomFrame.Done();
                Support.AreEqual("Loan Type selection is required.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false));
                FastDriver.WebDriver.HandleDialogMessage(false, false, 10);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("177");
                FastDriver.NewLoan.LoanDetailsMortgageProduct.FASelectItem("52 - i Second - Regular");
                Support.AreEqual("True", FastDriver.NewLoan.LoanDetailsLoantype.Text.Contains("Seller Carryback").ToString());
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Seller Carryback");
                
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0096()
        {
            try
            {
                Reports.TestDescription = "AlterNate Course_22:Select a Loan Investor";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Enter details in New Loan screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanInvestors.FAClick();
                FastDriver.LoanInvestors.WaitForScreenToLoad();
                FastDriver.LoanInvestors.Add.FAClick();
                FastDriver.LoanInvestorsDlg.WaitForScreenToLoad();
                FastDriver.LoanInvestorsDlg.LoanInvestorsTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LoanInvestors.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            } 
        }

        [TestMethod]
        public void FMUC0047_REG0097()
        {
            try
            {
                Reports.TestDescription = "EWC_53:Sale Price, Loan Amount or Liability Amounts cannot be changed. Changing these parameters results in calculated fees less than the total of the Split $ amounts on Split Fees screen.";
                Login(AutoConfig.FASTHomeURL);
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Selecting ALTA Extended Loan Policy";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.AddRemoveProducts.FAClick();
                FastDriver.ProductListDlg.WaitScreenToLoad();
                FastDriver.ProductListDlg.ProductType.FASelectItem("Lender Policy");
                FastDriver.ProductListDlg.Table.PerformTableAction(2, "*ALTA Extended Loan Policy", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, "*ALTA Extended Loan Policy", 2, TableAction.Click);
                Support.AreEqual("*ALTA Extended Loan Policy", FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Enter details in New Loan screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2000000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to file fees and calculate fees.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.TitleRates.FAClick();
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Select a Fee and click on next.";
                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select 1064_Title_Lender_Policy option.";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.SelectItemBySendkeys, "1064_Title_Lender_Policy");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.SelectItemBySendkeys, "Buyer");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Split Fees, Select Payee & enter split amount";
                FastDriver.LeftNavigation.Navigate<SplitFeeDisbursements>("Split Fees/Assign State").WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.FABResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 10);
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
                FastDriver.SplitFeeDisbursements.Scissor1.FAClick();
                FastDriver.SplitFeeDisbursements.WaitForScreenToBeReady(Element: FastDriver.SplitFeeDisbursements.Payee);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 2, TableAction.SelectItemBySendkeys, "buyer" + FAKeys.Tab);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(2, 5, TableAction.SetText, "2000");
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 3, TableAction.Click);

                Support.AreNotEqual("0.00", FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(2, 6, TableAction.GetText).Message.Clean(), "Payee Table updated.");
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan screen and enter Loan Amount";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2000");
                FastDriver.NewLoan.LoanDetailsDays.Click();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0047_REG0098_PH()
        {
            try
            {
                Reports.TestDescription = "3521,US 230116 - Escrow Charge Setup Filter Templates - Filtering for New Loan and Mortgage Broker";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.StatusUpdate("This Flow has NOT been Automated Please perform this MANUALLY", true);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        //Team                                    : ServReq-Galaxy
        //Iteration                               : r04
        //UserStory                               : User Story 673027:REQ0834263 - Republic - When liability amounts are changed, recalculate all fees instead of remove
        //TestCase                                : 731637
        //Appended By/ Created By                 : Sheetal Gothi
        public void FMUC0047_REG0099()
        {
            try
            {
                #region data setup

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[] { };
                fileRequest.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                    {
                        new FASTWCFHelpers.FastFileService.FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    };
                fileRequest.File.Products = new FASTWCFHelpers.FastFileService.Product[]
                {
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 884,
                    },
                    new FASTWCFHelpers.FastFileService.Product()
                    {
                        ProductID = 886,
                    }
                };

                #endregion data setup

                Reports.TestDescription = "Remove the policies for whom the override reason is associated on click of remove all option";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                //FastDriver.TopFrame.SearchFileByFileNumber("40342");
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Setting an amount to Lenders Policy Liablity.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("500" + FAKeys.Tab);
                //Reports.TestStep = "Verify for the message after change the New Loan amount.";
                //Support.AreEqual("Loan Amount has changed. Do you wish to update the Loan Amount to the Loan Liability?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                //FastDriver.NewLoan.LoanDetailsLoanLiability.FASetText("500" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "In Fee entry screen Select All fee checkbox & Click on Calculate Fees button.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad(FastDriver.FileFees.AllFees);
                FastDriver.FileFees.AllFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                Reports.TestStep = "Create Title Fees..";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.TitleFeesTitlePolicy);
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");

                Reports.TestStep = "Click on Add on Title Policy..";
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();

                Reports.TestStep = "Add Endorsement Fee.";
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();

                Reports.TestStep = "Select Endorsement Fee.";
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();
                string strFACCEndorsementFees = FastDriver.FACCEndorsementsDlg.SelectEndorsementName.FAGetText().Clean();
                Reports.StatusUpdate("Using FACC Endorsement Fee: " + strFACCEndorsementFees, true);
                FastDriver.FACCEndorsementsDlg.SelectEndorsement.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Calculate Recording Fee.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingFeesRecordingDocument);
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItemBySendingKeys("mortgage");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("3");
                FastDriver.CalculateFees.RecordingFeesConsiderationAmount.FASetText("500.00");

                Reports.TestStep = "Click on Add to Add Recording Fee.";
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Click on Next Button.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.Next);
                FastDriver.CalculateFees.Next.FAClick();

                Reports.TestStep = "Select View More option.";
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryFastFeeDescription);
                FastDriver.CalculateFees.SummaryFastFeeDescription.Click();
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASendKeys("+" + FAKeys.Tab);

                Reports.TestStep = "Select Title Loan Policy fee.";
                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable);
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction("#2", "ALTA Ext Loan Policy 1056.06 (6-17-06) - 2", "#1", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Select Descriptions For the Fee.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);

                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItem("ALTA Ext Loan Policy 1056.06 (6-17-06) - 2");
                FastDriver.CalculateFees.SummaryChargeTo.FASelectItem("Buyer");
                FastDriver.CalculateFees.SummaryOverrideReason.FASelectItem("Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryOverrideAmount.FASetText("200.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);
                FastDriver.CalculateFees.SummarySplitPercentage.FASetText("50.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);

                FastDriver.CalculateFees.SummaryFastFeeDescription2.FASelectItemByIndex(1);
                FastDriver.CalculateFees.SummaryChargeTo2.FASelectItem("Seller");
                FastDriver.CalculateFees.SummaryOverrideReason2.FASelectItem("Permitted Rate Reduction");

                FastDriver.CalculateFees.SummaryFastFeeDescription3.Click();
                FastDriver.CalculateFees.SummaryFastFeeDescription3.FASendKeys("+" + FAKeys.Tab);
                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem("Recording Fee - Mortgage");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable);
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction("#2", "Record Mortgage - 1", "#1", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.SummaryChargeTo3.FASelectItem("Seller");
                FastDriver.CalculateFees.SummaryOverrideReason3.FASelectItem("Centralized Loan Rate");
                FastDriver.CalculateFees.SummaryOverrideAmount3.FASetText("100.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);
                FastDriver.CalculateFees.SummarySplitPercentage3.FASetText("45.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #region "FACC Recalculate Fees"

                Reports.TestStep = "Navigate to New Loan, verify form Type is " + AutoConfig.FormType + " and enter charges.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItemBySendingKeys("small loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("50000.00" + FAKeys.Tab);

                Reports.TestStep = "Verify for the message after change the New Loan amount.";
                Support.AreEqual("Loan Amount has changed. Do you wish to update the Loan Amount to the Loan Liability?", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
                Playback.Wait(3000);

                FastDriver.FACCRecalculationConfirmDlg.WaitForScreenToLoad();
                FastDriver.FACCRecalculationConfirmDlg.Recalculate.FAClick();
                Playback.Wait(2000);

                Reports.TestStep = "Validate:Changing the Loan Amount or Liability Amounts will result in the Recalculation of Impacted fees. If Calculated Rates have override details, system can recalculate or remove overridden fees. What would you like to do?";
                var value = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Recalculation of fees will result in removal of override reason, override amount and split $ amount. Fees will be recalculated.", value);
                Playback.Wait(2000);

                //Click Done in New Loan
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify whether Lender Policy Endorsement and Mortage has been recalcualted.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary").WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                string val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "Eagle Loan Policy", "Calculated Rate", TableAction.GetText).Message;
                Support.AreEqual("435.00", val, "Eagle Loan Policy Calculated Rate");
                Support.AreEqual("50.00", FastDriver.CalculateFees.SummarySplitPercentage.FAGetValue().Clean(), "SplitPercentage1");

                val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "[ALTA 3-06] Zoning - unimproved land", "Calculated Rate", TableAction.GetText).Message;
                Support.AreEqual("100.00", val, "Endorsement Calculated Rate");
                val = FastDriver.CalculateFees.SummaryTable.PerformTableAction("Description", "MORTGAGE - Recording Fee", "Calculated Rate", TableAction.GetText).Message;
                Support.AreEqual("31.00", val, "MORTGAGE - Recording Fee Calculated Rate");

                Support.AreEqual("45.00", FastDriver.CalculateFees.SummarySplitPercentage3.FAGetValue().Clean(), "SplitPercentage3");
                //Support.AreEqual("45.00", FastDriver.CalculateFees.SummarySplitPercentage3.FAGetValue());
                /*Reports.TestStep = "Setting Override Reason.";
                FastDriver.CalculateFees.SummaryOverrideReason.FASelectItem("Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryOverrideAmount.FASetText("200.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);
                FastDriver.CalculateFees.SummarySplitPercentage.FASetText("50.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);
                FastDriver.CalculateFees.SummaryOverrideReason3.FASelectItem("Permitted Rate Reduction");
                FastDriver.CalculateFees.SummaryOverrideAmount3.FASetText("50.00" + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Delete + FAKeys.Tab);*/

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0047_REG00100()
        {
            try
            {
                Reports.TestDescription = "User Story - 752782: Verify Paid by Other and Payment method fields are disabled for the Future Recording fees, If Buyer/Seller Charge does not have a section defined in Escrow Charge setup";
                
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file with Sale wMortage transaction type.";
                var fileNumber = CreateFile("FL", "", "", "", "COMMERCIAL", "SALECONSLN");

                Reports.TestStep = "Navigate to the New Loan Section and Enter the Charges in Future Recording Fees";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender);
                FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee - Assignment", 100.99, null, null, null, null, null, null, null);
                
                Reports.TestStep = "Verify Paid by Others and corresponding Payment Method options are enabled Only for the Borrower Charge";
                FastDriver.NewLoan.LoanChargesGFE_7FutureRecordingFeescollectedbyLender_MB_PaymentDetails.FADoubleClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("25.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");               
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PaidbySellerOthers.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.IsEnabled().ToString());

                Reports.TestStep = "Verify the Display (L) on CD is checked automatically, while selecting 'Lender' in payment method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.IsEnabled().ToString());
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");    

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Same Above Scenario for Mortgage Broker Fee.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageFindGABCode("248");                
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee - Assignment", 100.99, null, null, null, null, null, null, null);
                FastDriver.NewLoan.MortgageGFE_7FutureRecordingFeescollectedbyLenderMBPaymentDetails.FADoubleClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("25.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PaidbySellerOthers.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.IsEnabled().ToString());

                Reports.TestStep = "Verify the Display (L) on CD is checked automatically, while selecting 'Lender' in payment method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.IsEnabled().ToString());

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "User Story - 752782: Verify Paid by Other and Payment method fields are enabled for the Future Recording fees, If Buyer/Seller Charge have a section defined in Escrow Charge setup in Refinance files";
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.RecapTab);
                FastDriver.NewLoan.RecapTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.RecapTable);
                Support.AreEqual("-$100.99", FastDriver.NewLoan.LenderFutrRecFeesPaidToLender.FAGetText().ToString());
                Support.AreEqual("-$100.99", FastDriver.NewLoan.MrtgFutrRecFeesPaidToMrtgBroker.FAGetText().ToString());
                Support.AreEqual("$100.99", FastDriver.NewLoan.LenderDetailsPaidAtClosingRBL.FAGetText().ToString());
                Support.AreEqual("$25.00", FastDriver.NewLoan.LenderDetailsPaidByOthersPOC.FAGetText().ToString());
                Support.AreEqual("$100.99", FastDriver.NewLoan.MrtgBrokerDetailsPaidAtClosingRBL.FAGetText().ToString());
                Support.AreEqual("$25.00", FastDriver.NewLoan.MrtgBrokerDetailsPaidByOthersLender.FAGetText().ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the OTC Screen and Verify Recording Fees and Future Recording Fees in Recording Fees &amp; Transfer Taxes section is populated with the New Loan and Mortgage Broker buyer's paid by others values.";
                FastDriver.OutsideTitleCompanyDetail.Open();
                Support.AreEqual("$251.98", FastDriver.OutsideTitleCompanyDetail.RFeesFRFeesBuyerLabel.FAGetText().ToString());

                Reports.TestStep = "Navigate to CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Expand Other Costs section and Click on the ItemizedRecordingFeePlusIcon";
                FastDriver.ClosingDisclosure.ExpandOtherCosts();
                FastDriver.ClosingDisclosure.ItemizedRecordingFeePlusIcon.FAClick();

                Support.AreEqual("Future Recording Fee - Lender", FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(1, 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$100.99", FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(1, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$100.99", FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(1, "Future Recording Fee - Assignment to Lenders Advantage A", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$25.00", FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(1, "Future Recording Fee - Assignment to Lenders Advantage A", 6, TableAction.GetText).Message.Trim());
                                
                Support.AreEqual("Future Recording Fee - Mortgage Broker", FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable_1.PerformTableAction(1, 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$100.99", FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable_1.PerformTableAction(1, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$100.99", FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable_1.PerformTableAction(1, "Future Recording Fee - Assignment", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$25.00", FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable_1.PerformTableAction(1, "Future Recording Fee - Assignment", 6, TableAction.GetText).Message.Trim());
                
                Reports.TestStep = "Click on Done";
                FastDriver.ClosingDisclosure.RecordingFeeDone.FAClick();

                Reports.TestStep = "Select Delivery option tab and preview the CD PDF for Combined client format. Should display the details as in CD screen.";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad(FastDriver.ClosingDisclosure.Combined);
                FastDriver.ClosingDisclosure.Combined.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.IncludeItemizedRecFees.FASetCheckbox(true);

                Reports.TestStep = "Deliver Closing Disclosure Preview.";
                string PDFName = PreviewDeliveryReturnPDFName("CDDEL", "Preview");              
                
                Reports.TestStep = "Validate the PDF has Details for : Verify the Future Recording details are match with the CD screen in PDF";
                Support.AreEqual("True", Support.ReadPdfFile(PDFName).Contains("E.  Recording Fees  $201.98").ToString());
                Support.AreEqual("True", Support.ReadPdfFile(PDFName).Contains("Recording Fee - Lender $100.99").ToString());
                Support.AreEqual("True", Support.ReadPdfFile(PDFName).Contains("Future Recording Fee - Assignment $100.99    $25.00").ToString());
                Support.AreEqual("True", Support.ReadPdfFile(PDFName).Contains("Recording Fee - Mortgage Broker $100.99").ToString());
                Support.AreEqual("True", Support.ReadPdfFile(PDFName).Contains("Future Recording Fee - Assignment $100.99    (L)$25.00").ToString());
                
                Reports.TestStep = "Navigate to View Settlement statement screen";                
                FastDriver.ViewSettlementStatement.Open();
                Support.AreEqual(true, FastDriver.WebDriver.FindElement(By.CssSelector("#table-8 tr:last-child table")).FAGetText().Contains("100.99"), "Verifying amounts are displayed on for Buyer on New Loan table");
                Support.AreEqual(true, FastDriver.WebDriver.FindElement(By.CssSelector("#table-8 tr:last-child table")).FAGetText().Contains("$25.00"), "Future Recording Fee - Assignment  to Lenders Advantage A Division Of First American Title Ins.  POC $25.00 (POC 25.00) ");
                
                Reports.TestStep = "Navigate to Settlement Statement and preview it and Verify the Future Recording details are match with the SS screen in PDF "+
                "Government Recording and Transfer Charges details should match with the View Settlement Statement";
                FastDriver.PrintEscrowSetlleStmt.Open();

                Reports.TestStep = "Deliver Settlement Statement and preview";
                PDFName = PreviewDeliveryReturnPDFName("PESS", "Preview");
                
                Reports.TestStep = "Validate the PDF has Details for : Future Recording Fee - Assignment to Lenders Advantage A Division Of First American Title Ins. POC $25.00 and Future Recording Fee - Assignment to Midwest Financial Group POC-L $25.00";
                Support.AreEqual("True", Support.ReadPdfFile(PDFName).Contains("Lender: Lenders Advantage A Division Of First \nAmerican Title Ins. \n100.99  Future Recording Fee - Assignment to Lenders Advantage A   \nDivision Of First American Title Ins. POC $25.00").ToString());
                Support.AreEqual("True", Support.ReadPdfFile(PDFName).Contains("Mrtg. Broker: Midwest Financial Group \n100.99  Future Recording Fee - Assignment to Midwest Financial   \nGroup POC-L $25.00").ToString());
                Support.AreEqual("True", Support.ReadPdfFile(PDFName).Contains("201.98 Cash (X From) (  To) Buyer").ToString());
                
                Reports.TestStep = "Navigate to File Balance Summary. Verify the File Balance Summary (Projected ) details not included the Future recording Fees Paid by others value from New Loan and Mortgage broker.	Should not display the Paid by others details in File Balance Summary.";
                FastDriver.EscrowFileBalanceSummary.Open();
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad(FastDriver.EscrowFileBalanceSummary.FBSProjectedTable);
                Support.AreEqual("False", FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.FAGetText().Contains("$25.00").ToString());
                Support.AreEqual("False", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.FAGetText().Contains("$25.00").ToString());
                Support.AreEqual("False", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.FAGetText().Contains("$25.00").ToString());
                Support.AreEqual("False", FastDriver.EscrowFileBalanceSummary.DepositOrDisbursementSummaryTable.FAGetText().Contains("$25.00").ToString());
                Support.AreEqual("False", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.FAGetText().Contains("$25.00").ToString());
                Support.AreEqual("False", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.FAGetText().Contains("$25.00").ToString());
                
                Reports.TestStep = "Deliver Escrow File Balance Summary Preview.";
                PDFName = PreviewDeliveryReturnPDFName("PESS", "Preview");

                Reports.TestStep = "Validate the PDF has Details for : Verify the File Balance Summary (Projected ) details not included the Future recording Fees Paid by others value from New Loan and Mortgage broker.	Should not display the Paid by others details in File Balance Summary.";
                Support.AreEqual("False", Support.ReadPdfFile(PDFName).Contains("$25.00").ToString());


                Reports.TestStep = "Create a new file with Refinance transaction type.";
                fileNumber = CreateFile("FL", "", "", "", "COMMERCIAL", "REFI");

                Reports.TestStep = "Navigate to the New Loan Section and Enter the Charges in Future Recording Fees for Refinance File";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender);
                FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();                
                FastDriver.NewLoan.AddChargeRefinance(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee - Assignment", 300.00, null, null);          
 

                Reports.TestStep = "Verify Paid by Others and corresponding Payment Method options are enabled Only for the Borrower Charge Refinance File";
                FastDriver.NewLoan.LoanChargesGFE_7FutureRecordingFeescollectedbyLender_MB_PaymentDetails.FADoubleClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("25.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PaidbySellerOthers.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.IsEnabled().ToString());

                Reports.TestStep = "Verify the Display (L) on CD is checked automatically, while selecting 'Lender' in payment method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.IsEnabled().ToString());
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Same Above Scenario for Mortgage Broker Fee.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageFindGABCode("248");
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription);
                FastDriver.NewLoan.AddChargeRefinance(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee - Assignment", 300.00, null, null);                
                FastDriver.NewLoan.MortgageGFE_7FutureRecordingFeescollectedbyLenderMBPaymentDetails.FADoubleClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("25.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.PaidbySellerOthers.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.IsEnabled().ToString());

                Reports.TestStep = "Verify the Display (L) on CD is checked automatically, while selecting 'Lender' in payment method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.IsSelected().ToString());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.IsEnabled().ToString());

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                             
            }
            catch (Exception ex)
            {
                FailTest(ex.Message.Trim());
            }

        }


        #endregion

        #region Useful methods
        private void Login(string Key)
        {

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(Key, credentials, true);
        }

        public static int CreateFile()
        {
            var customFile = RequestFactory.GetDetailedCreateFileDefaultRequest();

            try
            {
                int? FileID = FileService.CreateFile(customFile).FileID;
                return (int)FileID;
            }
            catch (Exception)
            {

                throw new Exception("Unable to retrieve FileID.");
            }

        }
        
        private string CreateFile(string State, string County, string City, string Country, string BusinessSegment, string TransactionType, bool OnDemandRequest = false, string GABCode = "", bool IsAutoNumber = true)
        {
            string fileNumber = "";
            string buyerRandomVal = Support.RandomString("AAAAAZ");
            //string[] State = { "CR", "AR" };
            Reports.TestStep = "Generate a random buyer name.";
            Support.DataSave("RandomBuyerName", buyerRandomVal);


            try
            {
                Reports.TestStep = "Create File using web service.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = State;
                fileRequest.File.Properties[0].PropertyAddress[0].County = County;
                fileRequest.File.Properties[0].PropertyAddress[0].City = City;
                fileRequest.File.Properties[0].PropertyAddress[0].Country = Country;
                fileRequest.File.BusinessSegmentObjectCD = BusinessSegment;
                fileRequest.File.TransactionTypeObjectCD = TransactionType;


                fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch //If not able to create file via web service, create file via FAST GUI
            {
                return "";
            }
            return fileNumber;
        }


        /// <summary>
        /// Function Performs the Delivery Process of Opening the PDF and Saving it. - Here ScreenName = PRINTESCRSETLSTMT, CDDEL, DOCREP, FEES INVOICE, EFBS and DeliveryMethod = Preview
        /// 
        /// 
        /// </summary>
        
        private string PreviewDeliveryReturnPDFName(string ScreenName, string DeliveryMethod)
        {

            string PDFName = null;           
                       

            if (ScreenName == "PESS")
            {
                FastDriver.PrintEscrowSetlleStmt.WaitForScreenToLoad(FastDriver.PrintEscrowSetlleStmt.Method);
                FastDriver.PrintEscrowSetlleStmt.Method.FASelectItem(DeliveryMethod);
                FastDriver.PrintEscrowSetlleStmt.Deliver.FAClick();
            }

            else if (ScreenName == "CDDEL")
            {
                FastDriver.ClosingDisclosure.WaitForScreenToLoad(FastDriver.ClosingDisclosure.DeliveryMethod);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem(DeliveryMethod);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
            }

          
            else if (ScreenName == "DOCREP")
            {

                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.Method);
                FastDriver.DocumentRepository.Method.FASelectItem(DeliveryMethod);
                FastDriver.DocumentRepository.Deliver.FAClick();
            }


            else if (ScreenName == "FEES")
            {
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.DeliverMethod);
                FastDriver.FileFees.DeliverMethod.FASelectItem(DeliveryMethod);
                FastDriver.FileFees.Deliver.FAClick();
            }

            else if (ScreenName == "INVOICE")
            {
                FastDriver.InvoiceFees.WaitForScreenToLoad(FastDriver.InvoiceFees.cboMethod);
                FastDriver.InvoiceFees.cboMethod.FASelectItem(DeliveryMethod);
                FastDriver.InvoiceFees.Deliver.FAClick();
            }

            else if (ScreenName == "EFBS")
            {
                FastDriver.EscrowFileBalanceSummary.WaitForScreenToLoad(FastDriver.EscrowFileBalanceSummary.cboMethod);
                FastDriver.EscrowFileBalanceSummary.cboMethod.FASelectItem(DeliveryMethod);
                FastDriver.EscrowFileBalanceSummary.btnDeliver.FAClick();
            }

            else
            {
                Reports.TestStep = "Preview of the " + ScreenName + " Screen did Not Perform Delivery"; 
            }


            if (HandleDeliveryFailure(DeliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 250 ? 250 : int.Parse(AutoConfig.WaitTime) * 3))
            {
                if (!Directory.Exists(Reports._resultsdir + "\\PDF Documents\\" + Reports._testname))
                {
                    Directory.CreateDirectory(Reports._resultsdir + "\\PDF Documents\\" + Reports._testname);
                }

                Reports.TestStep = "Save PDF file";
                string tempPdfFile = Reports._resultsdir + "\\PDF Documents\\" + Reports._testname + "\\" + Reports._testname + "_.PDF";
                PDFName = SavePDFFile(tempPdfFile);
            }

            return PDFName;
        }

        public enum ScreenNameToEnter { PrintEscrowSettlementStatement, CDDeliveryOptions, DocumentRepository, FileFees, InvoiceFees};
        public enum DeliverMethod { Preview };

        public bool HandleDeliveryFailure(string deliveryMethod, int timeoutSeconds)
        {
            try
            {
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, timeoutSeconds);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                Reports.StatusUpdate(string.Format("'{0}' failed after {1} seconds.", deliveryMethod, timeoutSeconds), false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return false;
            }
        }


        private string SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                //Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Random ran = new Random();
                int ranNumber = ran.Next(250);
                Playback.Wait(5000);
                PDFFilePath = PDFFilePath.Replace(".PDF", ranNumber + ".PDF");
                Reports.TestStep = "Save PDF file : Refer " + PDFFilePath + " for Verification";

                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");


            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This close the dialog

                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }

            return PDFFilePath;

        }



        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

       
    }
}


