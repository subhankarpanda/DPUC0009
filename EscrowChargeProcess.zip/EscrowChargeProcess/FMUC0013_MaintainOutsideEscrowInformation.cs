﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using OpenQA.Selenium;
using System.Linq;
using System.Collections.Generic;
using FASTWCFHelpers.FastFileService;


namespace EscrowChargeProcess
{
    /// <summary>
    /// Summary description for FMUC0013_MaintainOutsideEscrowInformation
    /// </summary>
    [CodedUITest]
    public class FMUC0013_MaintainOutsideEscrowInformation : MasterTestClass
    {
        public FMUC0013_MaintainOutsideEscrowInformation()
        {
        }

        #region - BAT
        [TestMethod]
        public void FMUC0013_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Create Outside Escrow Company Process.";
                Login(AutoConfig.FASTHomeURL);

                //

                Reports.TestStep = "Creating file.";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Creating an OEC Instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC1");
                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.SetText, "Test OEC");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "Test OEC", buyerCharge: 50.00, sellerCharge: 50.00, newDescription: "OECChargeDescription1");
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating an OEC Instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                Support.AreEqual("OECChargeDescription1", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("50.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("50.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.New();

                //

                Reports.TestStep = "Create a second OEC Instance.";
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC2");
                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.SetText, "Test OEC");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "Test OEC", buyerCharge: 100.00, sellerCharge: 100.00, newDescription: "OECChargeDescription2");
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating second OEC Instance.";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                Support.AreEqual("OECChargeDescription2", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("100.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("100.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Edit an Instance and Verify the same.";
                Login(AutoConfig.FASTHomeURL);

                //

                Reports.TestStep = "Creating file.";
                int FileID = CreateFile();

                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                
                //

                Reports.TestStep = "Creating Outside Escrow Company Instances";

                OECRequest("OECDescription1", FileID, 1, 100.00);
                OECRequest("OECChargeDescription3", FileID, 2, 100.00);
                
                //

                Reports.TestStep = "Editing 1st created instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanySummary>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(2, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC3");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing 2nd created instance";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription3", buyerCharge: 200.00, sellerCharge: 200.00, newDescription: "OECChargeDescription2");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Select the 2nd instance from summary to edit and cancel";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);

                Reports.TestStep = "Validate Edited Second Instance.";
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                Support.AreEqual("OECChargeDescription2", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("200.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("200.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF6: Cancel the Edited Instance.";
                Login(AutoConfig.FASTHomeURL);

                //

                Reports.TestStep = "Creating file.";
                int FileID = CreateFile();

                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Creating Outside Escrow Company Instances";

                OECRequest("OECDescription1", FileID, 1, 100.00);
                OECRequest("OECChargeDescription2", FileID, 2, 200.00);
                
                //

                Reports.TestStep = "Editing 2nd created instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanySummary>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Editing and cancelling the 2nd created instance";
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription2", buyerCharge: 100.00, sellerCharge: 100.00);
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the Edited and Cancelled instance.";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                Support.AreEqual("OECChargeDescription2", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("200.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue());
                Support.AreEqual("200.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF6: Cancel the Edited Instance.";
                Login(AutoConfig.FASTHomeURL);

                //

                Reports.TestStep = "Creating file.";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Creating Outside Escrow Company Instance";
                OECRequest("OECChargeDescription1", FileID, 1, 100.00);
                OECRequest("OECChargeDescription2", FileID, 2, 100.00);
               
                //

                Reports.TestStep = "AF2: Delete an Instance.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanySummary>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                Support.AreEqual("Available", FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean());


            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF6: Cancel the Edited Instance.";
                Login(AutoConfig.FASTHomeURL);

                //

                Reports.TestStep = "Creating file.";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Creating an OEC Instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC1");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription1", buyerCharge: 50.00, sellerCharge: 50.00, addNewRow: true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC1");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription1", buyerCharge: 50.00, sellerCharge: 50.00, addNewRow: true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "validate a OEC Instance.";
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                Support.AreEqual("OECChargeDescription1", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("50.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("50.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF4: Cancelling the second instance.";
                Login(AutoConfig.FASTHomeURL);

                //

                Reports.TestStep = "Creating file.";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Creating Outside Escrow Company Instance";
                OECRequest("OECChargeDescription1", FileID, 1, 50.00);    

                //

                Reports.TestStep = "Cancelling the 2nd instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC2");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription2", buyerCharge: 100.00, sellerCharge: 100.00, addNewRow: true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC2");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription2", buyerCharge: 100.00, sellerCharge: 100.00, addNewRow: true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "validate 2nd OEC Instance.";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                Support.AreEqual("OECChargeDescription2", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("100.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("100.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF5: Cancelling the third Instance.";
                Login(AutoConfig.FASTHomeURL);

                //

                Reports.TestStep = "Creating file.";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Creating Outside Escrow Company Instance";
                OECRequest("OECChargeDescription1", FileID, 1, 50.00);
                OECRequest("OECChargeDescription2", FileID, 2, 50.00);
                
                //

                Reports.TestStep = "Creating a 3rd instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanySummary>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.New.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC2");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription3", buyerCharge: 100.00, sellerCharge: 100.00, addNewRow: true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanySummary>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.New.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC2");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription3", buyerCharge: 100.00, sellerCharge: 100.00, addNewRow: true);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the 3rd instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanySummary>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(4, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                Support.AreEqual("OECChargeDescription3", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("100.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("100.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        #endregion

        #region - REGRESSION

        [TestMethod]
        public void FMUC0013_REG0001()
        {
            try
            {
                Reports.TestDescription = "MF1: Create Outside Escrow Company Process.";
                Login(AutoConfig.FASTHomeURL);

                //

                Reports.TestStep = "Creating & searching for a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Creating an OEC Instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC1");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OEC", buyerCharge: 8.99, sellerCharge: 8.99, addNewRow: true);
                
                Reports.TestStep = "Verify payment details enter for OEC";
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-OEC");
                Support.AreEqual("Sanity-OEC", FastDriver.PaymentDetailsDlg.Description.FAGetValue());
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                Reports.TestStep = "Click on Find To enter GAB through Address Book Search.";
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("Test");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForResultsToLoad();
                FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Check for check amount.";
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                Support.AreEqual("Check Amount: $ 17.98", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                Playback.Wait(1000);
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Overdraft Confirmation");
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change Payee To whom check issued.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Enter Less Amount than Issued Charge.";
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText("5.99");
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Enter Greater Amount than Issued Charge.";
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText("9.99");
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Delete Description.";
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Delete The Payee have Issued Instance.";
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Clicking on new to create 2nd instance";
                FastDriver.BottomFrame.New();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC3");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription3", buyerCharge: 200.00, sellerCharge: 200.00, addNewRow: true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the second Instance from summary to Edit and Cancel.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanySummary>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Instance from summary and use shortcut key to Delete.";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                Keyboard.SendKeys("%R");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                //

                
            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_REG0002()
        {
            #region - DataSetup
            var deposit = new DepositParameters()
            {
                Amount = 6,
                TypeofFunds = "Cash",
                Representing = "Initial Deposit",
                ReceivedFrom = "Buyer",
                Payor = "Sanity Payor",
                CreditToSeller = false
            };

            var details = new PaymentDetailsParameters()
            {
                Description = "Sanity-OEC",
                BuyerAtClosing = 8.99,
                SellerPaidAtClosing = 8.99
            };
            #endregion

            try
            {
                Reports.TestDescription = "ES6094: 1:Display Charge/Credit Totals for Sub Escrow Files";
                Reports.TestStep = "Login to IIS & Create a File";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating an OEC Instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC1");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OEC", buyerCharge: 0.00, addNewRow: true);
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Click on Payment details and enter charges.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Sanity-OEC");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("8.99");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("8.99");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a cash deposit.";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.DepositInEscrow.WaitForScreenToLoad();

                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", "New Home Rate (Title Only)", "Sel", TableAction.On);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "New Home Rate (Title Only)", buyerCharge: 1.99, sellerCharge: 2.99);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Check for check amount.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                Support.AreEqual("Check Amount: $ 17.98", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();
            }

            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_REG0003()
        {
            try
            {
                Reports.TestDescription = "EWC6_EWC8_EWC9_EWC10_EWC11_EWC13_EWC_14: 1:“ID Code not found.”  2:User cancels entry of the FIRST new instance using Cancel button on framework before saving a new process instance. 3:User cancels entry of the SECOND in";
                Reports.TestStep = "Login in to IIS & create a file";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating an OEC Instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("ASDFH");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC2");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription2", buyerCharge: 100.00, sellerCharge: 100.00, addNewRow: true);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC1");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription1", buyerCharge: 50.00, sellerCharge: 50.00, addNewRow: true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the OEC Instance.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                Support.AreEqual("OECChargeDescription1", FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("50.00", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("50.00", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.New();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Create a second OEC Instance.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC2");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription2", buyerCharge: 100.00, sellerCharge: 100.00, addNewRow: true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create a third OEC instance using a shortcut and then cancel it.";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                Keyboard.SendKeys("%N");
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Select the Instance from summary and use shortcut key to Edit.";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.Click);
                Keyboard.SendKeys("%E");
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the Instance from summary to Edit.";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.OutsideEscrowCompanySummary.Edit.FAClick();

                Reports.TestStep = "Enter Contact when Edit Name is checked.";
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.EditName.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.EditName.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit GAB contact and enter invalid email ID";
                FastDriver.OutsideEscrowCompanySummary.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanySummary.SummaryTable.PerformTableAction(3, 3, TableAction.DoubleClick);
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.EditContact.FASetCheckbox(true);
                FastDriver.OutsideEscrowCompanyDetail.EmailAddress.FASetText("test@test");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_REG0004()
        {
            try
            {
                Reports.TestDescription = "EWC12_EWC15: 1: “BusOrgID: Business Party required” 2:User tries to change a Business Party which has a Reference number specified against it.";
                Reports.TestStep = "Login to IIS & Create a new file";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //

                Reports.TestStep = "Creating an OEC Instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("HUDOUTESC1");
                FastDriver.OutsideEscrowCompanyDetail.Reference.FASetText("9876542321");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OECChargeDescription1", buyerCharge: 50.00, sellerCharge: 50.00, addNewRow: true);
                FastDriver.BottomFrame.Done();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("HUDOUTESC2");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_REG0005()
        {
            try
            {
                Reports.TestDescription = "FD: Field Definitions";
                Reports.TestStep = "Login to IIS & Create a new file";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("HUDFLINSR");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.EditContact.FASetCheckbox(true);
                FastDriver.OutsideEscrowCompanyDetail.BusinessPhone.FASetText("123456789");
                FastDriver.OutsideEscrowCompanyDetail.BusFax.FASetText("123456789");
                FastDriver.OutsideEscrowCompanyDetail.Pager.FASetText("123456789");
                FastDriver.OutsideEscrowCompanyDetail.CellPhone.FASetText("123456789");
                FastDriver.OutsideEscrowCompanyDetail.EmailAddress.FASetText("test.test");
                FastDriver.OutsideEscrowCompanyDetail.Name.FAClick();
                Support.AreEqual("Field is invalid", FastDriver.OutsideEscrowCompanyDetail.BusinessPhone.GetAttribute("title").Clean());
                Support.AreEqual("Field is invalid", FastDriver.OutsideEscrowCompanyDetail.BusFax.GetAttribute("title").Clean());
                Support.AreEqual("Field is invalid", FastDriver.OutsideEscrowCompanyDetail.Pager.GetAttribute("title").Clean());
                Support.AreEqual("Field is invalid", FastDriver.OutsideEscrowCompanyDetail.CellPhone.GetAttribute("title").Clean());
                Support.AreEqual("Email address is invalid. Valid Examples: xyz@abc.com xyz@abc.com.uk xyz_123@abc.com xyz-12.wuv@abc.cnn.edu.uk", FastDriver.OutsideEscrowCompanyDetail.EmailAddress.GetAttribute("title").Clean());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with lower Boundary Value. #2";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("HUDFLINSR");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.EditName.FASetCheckbox(true);
                FastDriver.OutsideEscrowCompanyDetail.Name.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456");
                FastDriver.OutsideEscrowCompanyDetail.Reference.FASetText("0123456789012345678901234567890123456789012345678");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", buyerCharge: 99999999999.99, sellerCharge: 99999999999.99, addNewRow: true);
                Support.AreEqual("0123456789012345678901234567890123456789012345678", FastDriver.OutsideEscrowCompanyDetail.Reference.FAGetValue().Clean());
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetValue().Clean());
                Support.AreEqual("99,999,999,999.99", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("99,999,999,999.99", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with Exact Value.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.EditContact.FASetCheckbox(true);
                FastDriver.OutsideEscrowCompanyDetail.EditName.FASetCheckbox(true);
                FastDriver.OutsideEscrowCompanyDetail.BusinessPhone.FASetText("1234567899");
                FastDriver.OutsideEscrowCompanyDetail.BusFax.FASetText("1234567899");
                FastDriver.OutsideEscrowCompanyDetail.Pager.FASetText("1234567899");
                FastDriver.OutsideEscrowCompanyDetail.CellPhone.FASetText("1234567899");
                FastDriver.OutsideEscrowCompanyDetail.EmailAddress.FASetText("test@test.com");
                FastDriver.OutsideEscrowCompanyDetail.Name.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456");
                FastDriver.OutsideEscrowCompanyDetail.Reference.FASetText("0123456789012345678901234567890123456789012345678");
                FastDriver.TableCharges.Enter(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", buyerCharge: 99999999999.99, sellerCharge: 99999999999.99, addNewRow: true);
                Support.AreEqual("(123)456-7899", FastDriver.OutsideEscrowCompanyDetail.BusinessPhone.FAGetValue().Clean());
                Support.AreEqual("(123)456-7899", FastDriver.OutsideEscrowCompanyDetail.BusFax.FAGetValue().Clean());
                Support.AreEqual("(123)456-7899", FastDriver.OutsideEscrowCompanyDetail.Pager.FAGetValue().Clean());
                Support.AreEqual("(123)456-7899", FastDriver.OutsideEscrowCompanyDetail.CellPhone.FAGetValue().Clean());
                Support.AreEqual("test@test.com", FastDriver.OutsideEscrowCompanyDetail.EmailAddress.FAGetValue().Clean());
                Support.AreEqual("0123456789012345678901234567890123456789012345678", FastDriver.OutsideEscrowCompanyDetail.Reference.FAGetValue().Clean());
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetValue().Clean());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with Upper Boundary Value.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("HUDFLINSR12");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.OutsideEscrowCompanyDetail.EditContact.FASetCheckbox(true);
                FastDriver.OutsideEscrowCompanyDetail.EditName.FASetCheckbox(true);
                FastDriver.OutsideEscrowCompanyDetail.BusinessPhone.FASetText("12345678999");
                FastDriver.OutsideEscrowCompanyDetail.BusFax.FASetText("12345678999");
                FastDriver.OutsideEscrowCompanyDetail.Pager.FASetText("123456789999");
                FastDriver.OutsideEscrowCompanyDetail.CellPhone.FASetText("12345678999");
                FastDriver.OutsideEscrowCompanyDetail.EmailAddress.FASetText("test@test.com");
                FastDriver.OutsideEscrowCompanyDetail.Name.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456");
                FastDriver.OutsideEscrowCompanyDetail.Reference.FASetText("0123456789012345678901234567890123456789012345678");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ" + FAKeys.Tab);
                FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText("10000000000000000" + FAKeys.Tab);
                FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FASetText("10000000000000000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OutsideEscrowCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.Click();
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.GetAttribute("title").Clean());
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.OutsideEscrowCompanyDetail.SellerCharge.GetAttribute("title").Clean());
                Support.AreEqual("(123)456-7899", FastDriver.OutsideEscrowCompanyDetail.BusinessPhone.FAGetValue().Clean());
                Support.AreEqual("(123)456-7899", FastDriver.OutsideEscrowCompanyDetail.BusFax.FAGetValue().Clean());
                Support.AreEqual("(123)456-7899", FastDriver.OutsideEscrowCompanyDetail.Pager.FAGetValue().Clean());
                Support.AreEqual("(123)456-7899", FastDriver.OutsideEscrowCompanyDetail.CellPhone.FAGetValue().Clean());
                Support.AreEqual("test@test.com", FastDriver.OutsideEscrowCompanyDetail.EmailAddress.FAGetValue().Clean());
                Support.AreEqual("0123456789012345678901234567890123456789012345678", FastDriver.OutsideEscrowCompanyDetail.Reference.FAGetValue().Clean());
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetValue().Clean());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0013_REG0006_PH()
        {
            try
            {
                Reports.TestDescription = "ES10896_ES10897_ES10898_ES10900: ES10900 is invalid BR other BR's check manually.";

                // 

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region - Recurrent Methods
        
        public static int CreateFile()
        {
            var customFile = RequestFactory.GetCreateFileDefaultRequest();
            customFile.formType = FormType.CD;

            try
            {
                int? FileID = FileService.CreateFile(customFile).FileID;
                return (int)FileID;
            }
            catch (Exception)
            {
                
                throw new Exception("Unable to retrieve FileID.");
            }
            
        }

        public void OECRequest(string ChargeDescription, int FileD, int seqNum, double Amount)
        {
            var CreateOEC = new FASTWCFHelpers.FastFileService.OECRequest
            {

                FileID = FileD,
                EmployeeID = 1,
                Source = "FAMOS",
                Target = "FAST",
                OECInformation = new FASTWCFHelpers.FastFileService.OECInformation
                {
                    OECCharges = new FASTWCFHelpers.FastFileService.OECCharge
                    {
                        CDPaymentDetails = new FASTWCFHelpers.FastFileService.CDChargePaymentDetails[]
                            {
                                new FASTWCFHelpers.FastFileService.CDChargePaymentDetails()
                                {
                                    Description = ChargeDescription,
                                    BuyerCharge = (decimal)Amount,
                                    SellerCharge= (decimal)Amount,
                                },
                                
                            },
                    },

                    OECFileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDOUTESC3"),
                    },

                    SeqNum = seqNum,
                },
            };

            var response = FileService.CreateOutsideEscrowCompany(CreateOEC);
            if (response.Status != 1)
            {
                Reports.StatusUpdate(response.StatusDescription, false);
            }
            else
                Reports.StatusUpdate(response.StatusDescription, true);
        }

        public void OECRequestHUD(string ChargeDescription, int FileD, int seqNum, double Amount)
        {
            var CreateOECHUD = new FASTWCFHelpers.FastFileService.OECRequest
            {
                FileID = FileD,
                EmployeeID = 1,
                Source = "FAMOS",
                Target = "FAST",
                OECInformation = new FASTWCFHelpers.FastFileService.OECInformation
                {
                    OECCharges = new FASTWCFHelpers.FastFileService.OECCharge
                    {
                       PaymentDetails = new FASTWCFHelpers.FastFileService.ChargePaymentDetails[] 
                       { 
                           new FASTWCFHelpers.FastFileService.ChargePaymentDetails()
                           {
                               Description = ChargeDescription,
                               BuyerCharge = (decimal)Amount,
                               SellerCharge = (decimal)Amount,
                           }
                       }
                    },

                    OECFileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDOUTESC3"),
                    },

                    SeqNum = seqNum,
                },
            };

            var response = FileService.CreateOutsideEscrowCompany(CreateOECHUD);
            if (response.Status != 1)
            {
                Reports.StatusUpdate(response.StatusDescription, false);
            }
            else
                Reports.StatusUpdate(response.StatusDescription, true);
        }

        private void Login(string Key)
        {

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(Key, credentials, true);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
