﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using OpenQA.Selenium;
using System.Linq;
using System.Collections.Generic;
using FASTWCFHelpers.FastFileService;


namespace EscrowChargeProcess
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]
    public class FMUC0044_Insurance : MasterTestClass
    {
        public FMUC0044_Insurance()
        {
        }

        #region BAT

        [TestMethod]
        public void FMUC0044_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Create an instance of Insurance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance of Fire Insurance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FindGAB(GABName: "Insurance CompanyName 1");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's insurance", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate Insurance amount.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.Text.Clean());
                Support.AreEqual("5,100.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Clean());
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue1.Text.Clean());
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text.Clean());

                Reports.TestStep = "Verify pending check for Insurance.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                Support.AreEqual("300.55", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 7, TableAction.GetText).Message.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Create an instance of Flood Insurance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance of Fire Insurance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(5, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                FastDriver.Insuranceflood.FindGAB(GABName: "Insurance CompanyName 1");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Flood Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Flood insurance premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate Insurance amount.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.Text.Clean());
                Support.AreEqual("5,100.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Clean());
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue1.Text.Clean());
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text.Clean());

                Reports.TestStep = "Verify pending check for Insurance.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                Support.AreEqual("300.55", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 7, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0003()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Create an instance of Flood Insurance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance of Fire Insurance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(7, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                FastDriver.InsuranceWind.FindGAB(GABName: "Insurance CompanyName 1");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceWind.WindChargesTable, "Wind Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceWind.WindChargesTable, "Wind insurance premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate Insurance amount.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.Text.Clean());
                Support.AreEqual("5,100.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Clean());
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue1.Text.Clean());
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text.Clean());

                Reports.TestStep = "Verify pending check for Insurance.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                Support.AreEqual("300.55", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 7, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0004()
        {
            try
            {
                Reports.TestDescription = "Create an instance of Earth Quake Insurance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(9, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                FastDriver.InsuranceWind.FindGAB(GABName: "Insurance CompanyName 1");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceEarth.EarthChargesTable, "Earthquake Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceEarth.EarthChargesTable, "Earthquake insurance premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate Insurance amount.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.Text.Clean());
                Support.AreEqual("5,100.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Clean());
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue1.Text.Clean());
                Support.AreEqual("5,100.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text.Clean());

                Reports.TestStep = "Verify pending check for Insurance.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                Support.AreEqual("300.55", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 7, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0005()
        {
            try
            {
                Reports.TestDescription = "MF1_00: Create an instance of Insurance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Insurance amount.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,656.52", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.Text.Clean());
                Support.AreEqual("5,355.97", FastDriver.EscrowFileBalanceSummary.NetSellerCheck.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify pending check for Insurance.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                Support.AreEqual("300.55", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 7, TableAction.GetText).Message.Clean());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF1_00: Edit Insurance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Insurance Instance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "otheinsure Name 1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceEdited");
                FastDriver.InsuranceOther.FindUnderwriterGAB("otheinsure Name 1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE EDITED");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("22,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("6");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", newDescription: "Insurance Premium DescEdited", buyerCharge: 200.00, sellerCharge: 300.55, loanEstimate: 20.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", newDescription: "Insurance Premium DescEdited", buyerCharge: 200.00, sellerCharge: 300.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherAmount.FASetText("1000.00");
                FastDriver.InsuranceOther.OtherBuyerCharge1.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherFromDate.FASetText("09-19-2012");
                FastDriver.InsuranceOther.OtherBuyerCharge1.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherBuyerCharge1.FASetText("121.00");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();

                Reports.TestStep = "Validate the Edited Data.";
                Support.AreEqual("ReferenceEdited", FastDriver.InsuranceOther.OthertextReference.FAGetValue());
                Support.AreEqual("UWREFERENCE EDITED", FastDriver.InsuranceOther.OtherReferenceUnderwriter.FAGetValue());
                Support.AreEqual("22,500.00", FastDriver.InsuranceOther.OthertextPremium.FAGetValue());
                Support.AreEqual("6", FastDriver.InsuranceOther.OthertextTerm.FAGetValue());
                Support.AreEqual("Insurance Premium DescEdited", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("200.00", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("300.55", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                if (AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("20.00", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }
                Support.AreEqual("1,000.00", FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual("09-19-2012", FastDriver.InsuranceOther.OtherFromDate.FAGetValue());
                Support.AreEqual("Check Amount: $ 500.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF2_00: Delete instance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete the instance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryRemoveOther.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                Support.AreEqual("Available", FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF3_00: Cancel 1st New Insurance Instance Creation.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Cancel 2nd New Insurance Instance Creation.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Cancel 2nd Insurance Instance Creation.";
                FastDriver.BottomFrame.New();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Cancel 2nd New Insurance Instance Creation.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0010()
        {
            try
            {
                Reports.TestDescription = "AF5_00: Cancel 3rd / Subsequent New Insurance Instance Creation.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create 1st insurance instance";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Create 2nd Insurance Instance";
                FastDriver.BottomFrame.New();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Create 3rd Insurance Instance";
                FastDriver.BottomFrame.New();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Cancel 3rd New Insurance Instance Creation.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_BAT0011()
        {
            try
            {
                Reports.TestDescription = "AF6_00: Cancel Changes to Exist Insurance Instance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create 1st insurance instance";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancel Changes to Existing Insurance Instance.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "otheinsure Name 1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "otheinsure Name 1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE EDITED");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("22,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("6");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", newDescription: "Insurance Premium DescEdited", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", newDescription: "Insurance Premium DescEdited", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherAmount.FASetText("1000.00");
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherFromDate.FASetText("09-19-2012");
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherToDate.FASetText("09-19-2013");
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();

                Reports.TestStep = "Verify changes were reverted";
                Support.AreEqual("ReferenceINS1", FastDriver.InsuranceOther.OthertextReference.FAGetValue());
                Support.AreEqual("UWREFERENCE1", FastDriver.InsuranceOther.OtherReferenceUnderwriter.FAGetValue());
                Support.AreEqual("10,500.00", FastDriver.InsuranceOther.OthertextPremium.FAGetValue());
                Support.AreEqual("5", FastDriver.InsuranceOther.OthertextTerm.FAGetValue());
                Support.AreEqual("Insurance Premium", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("100.00", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("200.55", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                if (AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("25.00", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }
                Support.AreEqual("555.00", FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual("07-19-2012", FastDriver.InsuranceOther.OtherFromDate.FAGetValue());
                Support.AreEqual("07-19-2013", FastDriver.InsuranceOther.OtherToDate.FAGetValue());
            
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

       
        #endregion

        #region REGRESSION

        [TestMethod]
        public void FMUC0044_Precondition()
        {
            try
            {
                Reports.TestDescription = "";
                Login(AutoConfig.FASTAdmURL);

                Reports.TestStep = "Selecting Region to have Region-level access";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);

                Reports.TestStep = "Get the value of Amount";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").WaitForScreenToLoad();
                if (FastDriver.OfficeSetupOffice.OverDraftAmount.FAGetValue() == "50.00")
                {
                    FastDriver.BottomFrame.Done();
                }

                else 
                {
                    Reports.TestStep = "Enter amount as 50";
                    FastDriver.OfficeSetupOffice.OverDraftAmount.FASetText("50.00");
                    FastDriver.BottomFrame.Done();
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0001()
        {
            try
            {
                Reports.TestDescription = "BR_FM1576_ER13: Required Data for Insurance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on New button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();

                Reports.TestStep = "Enter only the Charge and click on Done.";
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", newDescription: "Insurance Premium DescEdited", buyerCharge: 200.00, sellerCharge: 300.55, loanEstimate: 20.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", newDescription: "Insurance Premium DescEdited", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 20.00);
                }
                
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0002()
        {
            try
            {
                Reports.TestDescription = "BR_FM1228_1229_1230: Multiple Insurance Processes.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Select the Fire Insurance from Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceFire.FireFind.FAClick();
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's insurance", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();

                Reports.TestStep = "Validating that more than one Fire Insurance instance cannot be created";
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                if (FastDriver.InsuranceFire.FireGABLabel.Text.Clean() == "STARTINCO")
                {
                    Reports.StatusUpdate(controlDescription: "Fire Instance was created. New instance cannot be created.", status: true);
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    Reports.StatusUpdate(controlDescription: "New instance can be created.", status: false);
                    FastDriver.BottomFrame.Delete();
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                Reports.TestStep = "Select the Flood Insurance from Summary.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(5, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                FastDriver.Insuranceflood.FloodName.FASetText("Insurance CompanyName 1");
                FastDriver.Insuranceflood.FloodFind.FAClick();
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.Insuranceflood.FloodChargesTable, "Flood Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.Insuranceflood.FloodChargesTable, "Flood insurance premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating that more than one Fire Insurance instance cannot be created";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(5, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                if (FastDriver.Insuranceflood.FloodGABLabel.Text.Clean() == "STARTINCO")
                {
                    Reports.StatusUpdate(controlDescription: "Flood Instance was created. New instance cannot be created.", status: true);
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    Reports.StatusUpdate(controlDescription: "New instance can be created", status: false);
                    FastDriver.BottomFrame.Delete();
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                Reports.TestStep = "Select the Wind Insurance from Summary.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(7, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                FastDriver.InsuranceWind.WindName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceWind.WindFind.FAClick();
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceWind.WindChargesTable, "Wind Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceWind.WindChargesTable, "Wind insurance premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }


                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating that more than one Wind Insurance instance cannot be created";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(7, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                if (FastDriver.InsuranceWind.WindGABLabel.Text.Clean() == "STARTINCO")
                {
                    Reports.StatusUpdate(controlDescription: "Wind Instance was created. New instance cannot be created.", status: true);
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    Reports.StatusUpdate(controlDescription: "New instance can be created.", status: false);
                    FastDriver.BottomFrame.Delete();
                    FastDriver.WebDriver.HandleDialogMessage();
                }

                Reports.TestStep = "Select the Earth Insurance from Summary.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(9, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                FastDriver.InsuranceEarth.EarthName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceEarth.EarthFind.FAClick();
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceEarth.EarthChargesTable, "Earthquake Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceEarth.EarthChargesTable, "Earthquake insurance premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating that more than one Wind Insurance instance cannot be created";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(9, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                if (FastDriver.InsuranceWind.WindGABLabel.Text.Clean() == "STARTINCO")
                {
                    Reports.StatusUpdate(controlDescription: "Earthquake Instance was created. New instance cannot be created.", status: true);
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    Reports.StatusUpdate(controlDescription: "New instance can be created.", status: false);
                    FastDriver.BottomFrame.Delete();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0003()
        {
            try
            {
                Reports.TestDescription = "BR_FM1231_1028_1235_1245_1238_1578_1236_ES10892 : Multiple Other Insurance Type.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on New button in Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.OtherName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                Support.AreEqual("True", FastDriver.InsuranceOther.OtherSellerCredit1.Exists().ToString());
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.00");
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                Support.AreEqual("YEAR", FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem());
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "FM1578_FM1238_ Edit Manual Charge Description";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", newDescription: "Changed Premium Description");
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("Changed Premium Description", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FindElement(By.Id("CG_dcs_0_tdsc")).FAGetValue());
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();

                Reports.TestStep = "Create a new instance of Insurance.";
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the multiple instance of Other Insurance created.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(3, 2, TableAction.Click);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0004()
        {
            try
            {
                Reports.TestDescription = "BR_FM2072: Update File Address Book.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherFind.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search");
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FAClick();
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction(5, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickCancel();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0005()
        {
            try
            {
                #region DataSetup
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Services[0] = new Service()
                    {
                        OfficeInfo = new OfficeInfo()
                        {
                            RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                            BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID),
                            ProductionOffices = new ProductionOffice[]
                            {
                                new ProductionOffice()
                                {
                                    BUID = 0,
                                    OfficeCode = 0,
                                    RegionID = 0,
                                    SeqNum = 0
                                }
                            }
                        },
                        ServiceTypeObjectCD = "SEO"
                    };
                #endregion

                Reports.TestDescription = "BR_ES6089: Disable Prorations Entry in Sub Escrow Files.";
                Login(AutoConfig.FASTHomeURL);
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "In SubEscrow, System disables entry of the insurance charge proration.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                Support.AreEqual("False", FastDriver.InsuranceOther.OtherCreditSeller.Enabled.ToString());
                Support.AreEqual("False", FastDriver.InsuranceOther.OtherDayofClose.Enabled.ToString());
                Support.AreEqual("False", FastDriver.InsuranceOther.OtherAmount.Enabled.ToString());
                Support.AreEqual("False", FastDriver.InsuranceOther.OtherFromDate.Enabled.ToString());
                Support.AreEqual("False", FastDriver.InsuranceOther.OtherfromInclusive.Enabled.ToString());
                Support.AreEqual("False", FastDriver.InsuranceOther.OtherToDate.Enabled.ToString());
                Support.AreEqual("False", FastDriver.InsuranceOther.OthertoInclusive.Enabled.ToString());
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0006()
        {
            try
            {
                Reports.TestDescription = "BR_FM1276_1239: Display Check Amount.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Enter charges for Other Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Click on payment Details button.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem());
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem());
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());
                    FastDriver.PaymentDetailsDlg.Description.FASetText("REG-FMUC44_Insurance");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("3.99");
                    FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("3.99");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("RBL");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("RBL");
                    FastDriver.PaymentDetailsDlg.Description.FASetText("REG-FMUC44_Insurance");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("3.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("3.99");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                if (AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("Check Amount: $ 7.98", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                }
                else
                {
                    Support.AreEqual("Check Amount: $ 0.00", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                }
                

                Reports.TestStep = "Change Seller Charge Payment method to POC.";
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0.00");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("3.99");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("0.00");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("3.99");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("POC-S");
                }
                
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the Pencil Icon.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FindElement(By.XPath("//img[contains(@src,'/images/ico_write.gif')]")).Exists().ToString());
                Support.AreEqual("True", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FindElement(By.XPath("//img[contains(@src,'/images/ico_write.gif')]")).Displayed.ToString());

                Reports.TestStep = "Verify the Check Amount after editing the Buyer charge in PDD.";
                Support.AreEqual("Check Amount: $ 0.00", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0007()
        {
            try
            {
                Reports.TestDescription = "BR_FM1240 : Edit Check Description Details.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Select the Fire Insurance from Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceFire.FireFind.FAClick();
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's insurance", buyerCharge: 100.00, sellerCharge: 200.55);
                }

                Reports.TestStep = "Click on Check Details for Fire Insurance.";
                FastDriver.InsuranceFire.FireGABCheckDetails.FAClick();
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.CheckDetailsDlg.Description.FASetText("Edited Check Description");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Voucher info edited for Insurance.");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0008()
        {
            try
            {
                Reports.TestDescription = "ER_1: User deletes a charge process instance that has issued checks.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>("Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Pend check for Insurance Charge and click on Print.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Insurance Summary and click on Remove.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryRemoveOther.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();


            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0009()
        {
            try
            {
                Reports.TestDescription = "ER_2_BR_FM2460: User deletes a charge process instance that does not have issued checks.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Select the Fire Insurance from Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceFire.FireFind.FAClick();
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceFire.InsuranceChargesTable, "Homeowner's insurance", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the already created Fire Insurance from Summary to delete.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                Support.AreEqual("Available", FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 2, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0010()
        {
            try
            {
                Reports.TestDescription = "ER_3: User tries to delete a charge description that has a charge amount.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherName.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the already Insurance Instance from Summary to edit.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", newDescription: " ");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0011()
        {
            try
            {
                Reports.TestDescription = "ER_6: The business party is a payee on an issued check and user tries to edit or replace it with another business party.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>("Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Pend check for Insurance Charge and click on Print.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Highlight the Other insurance created and click on Edit.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABCode: "HUDFLINSR1");
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0012()
        {
            try
            {
                Reports.TestDescription = "ER_7: User searches for a business party on ID Code and system does not find an exact match.";               
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>("Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Pend check for Insurance Charge and click on Print.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Highlight the Other insurance created and click on Edit.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABCode: "144");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.InsuranceOther.CheckAmount.FindElement(By.XPath("//img[contains(@src,'/Images2/ico_checkissued.gif')]")).Exists().ToString());
                Support.AreEqual("True", FastDriver.InsuranceOther.CheckAmount.FindElement(By.XPath("//img[contains(@src,'/Images2/ico_checkissued.gif')]")).Displayed.ToString());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0013()
        {
            try
            {
                Reports.TestDescription = "ER_4: User tries to decrease or delete a charge amount with payment method of CHK after the payee check is issued.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>("Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Pend check for Insurance Charge and click on Print.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Highlight the Other insurance created and click on Edit.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherBuyerCharge.FASetText("10.00");
                FastDriver.InsuranceOther.OtherSellerCharge.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("100.00", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                FastDriver.InsuranceOther.OtherBuyerCharge.FASetText("10.00");
                FastDriver.InsuranceOther.OtherSellerCharge.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("Check Amount: $ 210.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0014()
        {
            try
            {
                Reports.TestDescription = "ER_5: User tries to add or increase a charge amount with payment method of CHK after the payee check is issued.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>("Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Pend check for Insurance Charge and click on Print.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.CheckListTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Print.FAClick();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Highlight the Other insurance created and click on Edit.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherSellerCharge.FASetText("500.55");
                FastDriver.InsuranceOther.OtherBuyerCharge.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("200.55", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                FastDriver.InsuranceOther.OtherSellerCharge.FASetText("500.55");
                FastDriver.InsuranceOther.OtherBuyerCharge.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("Check Amount: $ 600.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0015()
        {
            try
            {
                Reports.TestDescription = "ER_14: When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Select the Fire Insurance from Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceFire.FireEditNameCheckbox.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0016()
        {
            try
            {
                Reports.TestDescription = "ER_15: When the user enters an invalid e-Mail address.";
                
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Select the Fire Insurance from Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();

                Reports.TestStep = "Check Edit checkbox in Fire Insurance and enter invalid email.";
                FastDriver.InsuranceFire.FireEdit.FASetCheckbox(true);
                FastDriver.InsuranceFire.FireEmailAddress.FASetText("xyz");
                FastDriver.InsuranceFire.FireName.Click();
                Support.AreEqual("Email address is invalid. Valid Examples: xyz@abc.com xyz@abc.com.uk xyz_123@abc.com xyz-12.wuv@abc.cnn.edu.uk", FastDriver.InsuranceFire.FireEmailAddress.FAGetAttribute("title").Clean());
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0017()
        {
            try
            {
                Reports.TestDescription = "ER_16: User tries to change a Business Party which has a Reference number specified against it.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.OtherNameUnderwriter.FASetText("Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancel Changes to Existing Insurance Instance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "otheinsure Name 1");

                Reports.TestStep = "Change the Bus Party in Insurance screen. Click on Cancel.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.InsuranceOther.OthertextReference.FAGetValue());

                Reports.TestStep = "Validate the reference is removed in Agent section.";
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceEdited");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "otheinsure Name 1");

                Reports.TestStep = "Change the Bus Party in Insurance screen. Click on Ok.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("UWREFERENCE1", FastDriver.InsuranceOther.OtherReferenceUnderwriter.FAGetValue());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0018()
        {
            try
            {
                Reports.TestDescription = "ER_12_1: User changes Amount Per Period From Date To Date Credit Seller Inclusive Prorate Date Day of Close Paid by Seller Based on Days.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to TDS screen and Enter Prorate as on Date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.ProrateAsOf.FASetText("07-19-2012");
                FastDriver.TermsDatesStatus.DisbursementDate.Click();
                FastDriver.ProrationDateChangedDlg.WaitForScreenToLoad();
                FastDriver.ProrationDateChangedDlg.Insurance.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancel Changes to Existing Insurance Instance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "otheinsure Name 1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();

                Reports.TestStep = "Uncheck the Credit Seller checkbox.";
                FastDriver.InsuranceOther.OtherCreditSeller.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(false);
                Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherBuyerCharge1.FAGetValue());

                Reports.TestStep = "Uncheck Days of Close Paid by seller.";
                FastDriver.InsuranceOther.OtherDayofClose.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherBuyerCharge1.FAGetValue());

                Reports.TestStep = "Edit the amount in Proration.";
                FastDriver.InsuranceOther.OtherAmount.FASetText("250.00");
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherBuyerCharge1.FAGetValue());

                Reports.TestStep = "Edit Per.";
                FastDriver.InsuranceOther.OtherPer.FASelectItemBySendingKeys("MONTH");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherBuyerCharge1.FAGetValue());

                Reports.TestStep = "Edit To Date.";
                FastDriver.InsuranceOther.OtherToDate.FASetText("09-19-2013");
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherBuyerCharge1.FAGetValue());

                Reports.TestStep = "Uncheck From Inclusive.";
                FastDriver.InsuranceOther.OtherfromInclusive.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(false);
                Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherBuyerCharge1.FAGetValue());

                Reports.TestStep = "Edit the Based On Days.";
                FastDriver.InsuranceOther.OtherBasedOn.FASelectItemBySendingKeys("360");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                //Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherBuyerCharge1.FAGetValue());

                Reports.TestStep = "Check the From Prorate Date.";
                FastDriver.InsuranceOther.OtherfromProrate.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherfromProrate.FASetCheckbox(true);
                //Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherBuyerCharge1.FAGetValue());

                Reports.TestStep = "Check the To Prorate Date.";
                FastDriver.InsuranceOther.OthertoProrate.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoProrate.FASetCheckbox(true);
                //Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherBuyerCharge1.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0019()
        {
            try
            {
                Reports.TestDescription = "ER_12_2: User changes Amount Per Period From Date To Date Credit Seller Inclusive Prorate Date Day of Close Paid by Seller Based on Days.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to TDS screen and Enter Prorate as on Date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.ProrateAsOf.FASetText("07-19-2012");
                FastDriver.TermsDatesStatus.DisbursementDate.Click();
                FastDriver.ProrationDateChangedDlg.WaitForScreenToLoad();
                FastDriver.ProrationDateChangedDlg.Insurance.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, gfeAmount: 25.00);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancel Changes to Existing Insurance Instance.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "otheinsure Name 1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();

                Reports.TestStep = "Uncheck the Credit Seller checkbox.";
                FastDriver.InsuranceOther.OtherCreditSeller.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(false);
                Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());

                Reports.TestStep = "Uncheck Days of Close Paid by seller.";
                FastDriver.InsuranceOther.OtherDayofClose.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(false);
                Support.AreEqual("556.52", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());

                Reports.TestStep = "Edit the amount in Proration.";
                FastDriver.InsuranceOther.OtherAmount.FASetText("250.00");
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("250.68", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());

                Reports.TestStep = "Edit Per.";
                FastDriver.InsuranceOther.OtherPer.FASelectItemBySendingKeys("MONTH");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("3,008.06", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());

                Reports.TestStep = "Edit To Date.";
                FastDriver.InsuranceOther.OtherToDate.FASetText("09-19-2013");
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("3,513.17", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());

                Reports.TestStep = "Edit From Date.";
                FastDriver.InsuranceOther.OtherFromDate.FASetText("09-19-2012");
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("3,008.33", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());

                Reports.TestStep = "Uncheck From Inclusive.";
                FastDriver.InsuranceOther.OtherfromInclusive.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(false);
                Support.AreEqual("3,000.00", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());

                Reports.TestStep = "Uncheck To Inclusive.";
                FastDriver.InsuranceOther.OthertoInclusive.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(false);
                Support.AreEqual("2,991.67", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());

                Reports.TestStep = "Edit the Based On Days.";
                FastDriver.InsuranceOther.OtherBasedOn.FASelectItemBySendingKeys("360");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();

                Reports.TestStep = "Check the From Prorate Date.";
                FastDriver.InsuranceOther.OtherfromProrate.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherfromProrate.FASetCheckbox(true);
                Support.AreEqual("3,491.67", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());

                Reports.TestStep = "Check the To Prorate Date.";
                FastDriver.InsuranceOther.OthertoProrate.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoProrate.FASetCheckbox(true);
                Support.AreEqual("", FastDriver.InsuranceOther.OtherSellerCharge1.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0020()
        {
            try
            {
                Reports.TestDescription = "FD_1: Work pane Specific Buttons / Icons.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.InsuranceSummary.SummaryEdit.Exists().ToString());
                Support.AreEqual("True", FastDriver.InsuranceSummary.SummaryRemove.Exists().ToString());
                Support.AreEqual("True", FastDriver.InsuranceSummary.SummaryNew.Enabled.ToString());
                Support.AreEqual("True", FastDriver.InsuranceSummary.SummaryEditOther.Exists().ToString());
                Support.AreEqual("True", FastDriver.InsuranceSummary.SummaryRemoveOther.Exists().ToString());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0021()
        {
            try
            {
                Reports.TestDescription = "FD_2: Work pane Specific Buttons / Icons.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an instance of Insurance.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Highlight the Other insurance created and click on Edit.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual("True", FastDriver.BottomFrame.btnDelete.Enabled.ToString());
                Support.AreEqual("True", FastDriver.BottomFrame.btnNew.Enabled.ToString());
                Support.AreEqual("True", FastDriver.BottomFrame.btnReset.Enabled.ToString());
                Support.AreEqual("True", FastDriver.BottomFrame.btnAutoSave.Enabled.ToString());
                Support.AreEqual("True", FastDriver.BottomFrame.btnDone.Enabled.ToString());
                FastDriver.BottomFrame.btnDelete.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0022()
        {
            try
            {
                Reports.TestDescription = "FD_3: Field Definitions In Display Order – Insurance Summary screen.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an insurance instance for Field Validations.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherEditNamecheckBox.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherEditName.FASetText("Insurance CompanyName 1Insurance CompanyName 2Insurance CompanyName 3Insurance CompanyName 4");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the OtherInsuranceName.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                Support.AreEqual("Insurance CompanyName 1Insurance CompanyName 2Insurance CompanyName 3Insurance CompanyName 4", FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 3, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate the Other Insurance Bus Phone number.";
                Support.AreEqual("(111)111-1111", FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 4, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate the Other Insurance Bus Fax number.";
                Support.AreEqual("(222)222-2222", FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 5, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0023()
        {
            try
            {
                Reports.TestDescription = "FD_4: Field Definitions In Display Order – Insurance instance detail screen.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.FireSummary.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = "Click on Edit Insurance Summary.";
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FindGAB(GABCode: "251");
                Support.AreEqual("true", FastDriver.InsuranceFire.FireIssuecheck1.FAGetAttribute("checked").ToString());
                bool IsItemChecked = FastDriver.InsuranceFire.FireIssuecheck2.FAGetAttribute("checked") != null;
                Support.AreNotEqual("True", IsItemChecked.ToString());
                IsItemChecked = FastDriver.InsuranceFire.FireImpound.FAGetAttribute("checked") != null;
                Support.AreNotEqual("True", IsItemChecked.ToString());
                Support.AreEqual("true", FastDriver.InsuranceFire.FireoptYears.FAGetAttribute("checked").ToString());
                IsItemChecked = FastDriver.InsuranceFire.FireoptMonths.FAGetAttribute("checked") != null;
                Support.AreNotEqual("True", IsItemChecked.ToString());

                Reports.TestStep = "Validate for 11.2 chars in Premium Textbox.";
                FastDriver.InsuranceFire.FirePremium.FASetText("12345678912.34");
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("12,345,678,912.34", FastDriver.InsuranceFire.FirePremium.FAGetValue());
                FastDriver.InsuranceFire.FirePremium.Clear();
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("0.00", FastDriver.InsuranceFire.FirePremium.FAGetValue());

                Reports.TestStep = "Validate for 11.2 chars in Premium Textbox.";
                FastDriver.InsuranceFire.FirePremium.FASetText("12345678912");
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("12,345,678,912.00", FastDriver.InsuranceFire.FirePremium.FAGetValue());
                FastDriver.InsuranceFire.FirePremium.Clear();
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("0.00", FastDriver.InsuranceFire.FirePremium.FAGetValue());

                Reports.TestStep = "Validate for 14 chars in Premium Textbox.";
                FastDriver.InsuranceFire.FirePremium.FASetText("12345678912333");
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.InsuranceFire.FirePremium.FAGetAttribute("title"));
                FastDriver.InsuranceFire.FirePremium.Clear();
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("0.00", FastDriver.InsuranceFire.FirePremium.FAGetValue());

                Reports.TestStep = "Validate for 13 chars in Premium Textbox.";
                FastDriver.InsuranceFire.FirePremium.FASetText("1234567891233");
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.InsuranceFire.FirePremium.FAGetAttribute("title"));
                FastDriver.InsuranceFire.FirePremium.Clear();
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("0.00", FastDriver.InsuranceFire.FirePremium.FAGetValue());

                Reports.TestStep = "Validate for 12 chars in Premium Textbox.";
                FastDriver.InsuranceFire.FirePremium.FASetText("123456789123");
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.InsuranceFire.FirePremium.FAGetAttribute("title"));
                FastDriver.InsuranceFire.FirePremium.Clear();
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("0.00", FastDriver.InsuranceFire.FirePremium.FAGetValue());

                Reports.TestStep = "Enter one numeric char for term.";
                FastDriver.InsuranceFire.FiretextTerm.FASetText("4");
                FastDriver.InsuranceFire.FireBuyerCharge1.Click();
                Support.AreEqual("4", FastDriver.InsuranceFire.FiretextTerm.FAGetValue());
                FastDriver.InsuranceFire.FiretextTerm.Clear();
                Support.AreEqual("0", FastDriver.InsuranceFire.FiretextTerm.FAGetValue());

                Reports.TestStep = "Enter two numeric character for term.";
                FastDriver.InsuranceFire.FiretextTerm.Click();
                FastDriver.InsuranceFire.FiretextTerm.FASetText(FAKeys.Tab);
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                Support.AreEqual("12", FastDriver.InsuranceFire.FiretextTerm.FAGetValue());
                FastDriver.InsuranceFire.FiretextTerm.Clear();
                Support.AreEqual("0", FastDriver.InsuranceFire.FiretextTerm.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create an insurance instance with maximum value for buyer and seller charge.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad(); 
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 99999999999.99, sellerCharge: 99999999999.99);
                Support.AreEqual("Check Amount: $ 199,999,999,999.98", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0024()
        {
            try
            {
                Reports.TestDescription = "ER8: Cancel 1st New Insurance Instance Creation.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an insurance instance for Field Validations.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Cancel 2nd Insurance Instance Creation.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceSummary.WaitForScreenToLoad(); 

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0025()
        {
            try
            {
                Reports.TestDescription = "ER9: Cancel 2nd New Insurance Instance Creation.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create an insurance instance for Field Validations.";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Create 2nd instance of Insurance.";
                FastDriver.BottomFrame.New();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Cancel 2nd New Insurance Instance Creation.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0026()
        {
            try
            {
                Reports.TestDescription = "ER10: Cancel 3rd / Subsequent New Insurance Instance Creation.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create 1st insurance instance";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Create 2nd Insurance Instance";
                FastDriver.BottomFrame.New();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Create 3rd Insurance Instance";
                FastDriver.BottomFrame.New();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());

                Reports.TestStep = "Cancel 3rd New Insurance Instance Creation.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0027()
        {
            try
            {
                Reports.TestDescription = "ER11: Cancel Changes to Exist Insurance Instance.";
                Login(AutoConfig.FASTHomeURL);
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Insurance Summary.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                Reports.TestStep = "Create 1st insurance instance";
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OthertextReference.FASetText("ReferenceINS1");
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "Insurance CompanyName 1");
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE1");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("10,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("5");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherDayofClose.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherAmount.FASetText("555.000");
                FastDriver.InsuranceOther.OtherFromDate.FASetText("07-19-2012");
                FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(true);
                FastDriver.InsuranceOther.OtherToDate.FASetText("07-19-2013");
                FastDriver.InsuranceOther.OthertoInclusive.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(true);
                Support.AreEqual("Check Amount: $ 300.55", FastDriver.InsuranceOther.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancel Changes to Existing Insurance Instance.";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB(GABName: "otheinsure Name 1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindUnderwriterGAB(GABName: "otheinsure Name 1");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherReferenceUnderwriter.FASetText("UWREFERENCE EDITED");
                FastDriver.InsuranceOther.OthertextPremium.FASetText("22,500.00");
                FastDriver.InsuranceOther.OthertextTerm.FASetText("6");
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55, loanEstimate: 25.00);
                }
                else
                {
                    FastDriver.TableCharges.Enter(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", buyerCharge: 100.00, sellerCharge: 200.55);
                }
                FastDriver.InsuranceOther.OtherAmount.FASetText("1000.00");
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherFromDate.FASetText("09-19-2012");
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.OtherToDate.FASetText("09-19-2013");
                FastDriver.InsuranceOther.OtherBuyerCredit1.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.WaitForScreenToLoad();

                Reports.TestStep = "Verify changes were reverted";
                Support.AreEqual("ReferenceINS1", FastDriver.InsuranceOther.OthertextReference.FAGetValue());
                Support.AreEqual("UWREFERENCE1", FastDriver.InsuranceOther.OtherReferenceUnderwriter.FAGetValue());
                Support.AreEqual("10,500.00", FastDriver.InsuranceOther.OthertextPremium.FAGetValue());
                Support.AreEqual("5", FastDriver.InsuranceOther.OthertextTerm.FAGetValue());
                Support.AreEqual("Insurance Premium", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("100.00", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.Clean());
                Support.AreEqual("200.55", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.Clean());
                if (AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("25.00", FastDriver.InsuranceOther.InsuranceChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message.Clean());
                }
                Support.AreEqual("555.00", FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual("07-19-2012", FastDriver.InsuranceOther.OtherFromDate.FAGetValue());
                Support.AreEqual("07-19-2013", FastDriver.InsuranceOther.OtherToDate.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0044_REG0029_PH()
        {
            try
            {
                Reports.TestDescription = "ES10893_ES10894_FM1023_FM1245 Prevent enter GFE Amount for a Non-GFE Charge.";


                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Fail("This Flow has NOT been Automated. Please perform this MANUALLY");
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

        #region Useful methods
        private void Login(string Key)
        {

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(Key, credentials, true);
        }

        public static int CreateFile()
        {
            var customFile = RequestFactory.GetCreateFileDefaultRequest();
            customFile.File.SalesPriceAmount = (decimal)5000.00;

            try
            {
                int? FileID = FileService.CreateFile(customFile).FileID;
                return (int)FileID;
            }
            catch (Exception)
            {

                throw new Exception("Unable to retrieve FileID.");
            }

        }
        #endregion
    }
}
