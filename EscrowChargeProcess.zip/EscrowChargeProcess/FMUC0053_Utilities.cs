﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using SeleniumInternalHelpers;
using System.Runtime.Serialization;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Collections.Generic;
using System.Windows.Input;

namespace EscrowChargeProcess
{
    [CodedUITest]
    public class FMUC0053_Utilities : MasterTestClass
    {
        public FMUC0053_Utilities()
        {

        }

        #region BAT
        [TestMethod]
        public void FMUC0053_BAT0001() 
        {
            try
            {
                Reports.TestDescription = "MF_01: Create Utility Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                #endregion
                #region Enter payment details for UTILITY
                if (IsFormTypeCD)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.Description.FASetText(@"Sanity-UTILITY");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.Description.FASetText(@"Sanity-UTILITY");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.WaitForScreenToLoad();
                }
                #endregion
                #region Click on Payment Details
                Reports.TestStep = "Click on Payment Details";
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                #endregion
                #region Verify Payment Details for UTILITY
                Reports.TestStep = "Verify Payment Details for UTILITY";
                if (IsFormTypeCD)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual(@"Sanity-UTILITY", FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().ToString());
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    Support.AreEqual(@"Sanity-UTILITY", FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToString());
                    Support.AreEqual(@"8.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().ToString());
                    Support.AreEqual(@"8.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().ToString());
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                #endregion
                #region Enter Proration Details
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.UtilityDetail.ProrationAmount.FASetText(@"50.00");
                FastDriver.UtilityDetail.FromDate.FASetText(@"07/10/2020");
                FastDriver.UtilityDetail.BasedOn.FASelectItem(@"365");
                FastDriver.UtilityDetail.Per.FASelectItem(@"MONTH");
                FastDriver.UtilityDetail.ToDate.FASetText("07/17/2020");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate Entered Proration Details
                Reports.TestStep = "Validate Entered Proration Details";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.ProrationAmount.FAGetValue());
                Support.AreEqual(@"07-10-2020", FastDriver.UtilityDetail.FromDate.FAGetValue());
                Support.AreEqual(@"365", FastDriver.UtilityDetail.BasedOn.FAGetSelectedItem());
                Support.AreEqual(@"MONTH", FastDriver.UtilityDetail.Per.FAGetSelectedItem());
                Support.AreEqual(@"07-17-2020", FastDriver.UtilityDetail.ToDate.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate the data in Escrow File Balance Summary
                Reports.TestStep = "Validate the data in Escrow File Balance Summary";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual(@"SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText());
                Support.AreEqual(@"5,020.28", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());
                Support.AreEqual(@"5,020.28", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText());
                Support.AreEqual(@"5,002.30", FastDriver.EscrowFileBalanceSummary.NetSellerCheck.FAGetText());
                #endregion
                #region Navigate to Utility screen and change payment method
                Reports.TestStep = "Navigate to Utility screen and change payment method";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                if (!IsFormTypeCD)
                {
                    SetBuyerPaymentMethod("POC");
                }
                else
                {
                    SetBuyerPaymentMethod("No Check");
                }
                #endregion
                #region FM2536 Validate pencil icon when payment method is changed
                Reports.TestStep = "FM2536 Validate pencil icon when payment method is changed";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.UtilityDetail.Pencil.Exists().ToString().ToLower());
                Support.AreEqual("true", FastDriver.UtilityDetail.Pencil.Displayed.ToString().ToLower());
                if(!IsFormTypeCD)
                {
                    Support.AreEqual("Buyer:POC Seller:CHK", FastDriver.UtilityDetail.Pencil.FAGetAttribute("title").ToString());
                }
                else
                {
                    Support.AreEqual("Buyer: No Check - $8.99;\r\nSeller: Check - $8.99;", FastDriver.UtilityDetail.Pencil.FAGetAttribute("title").ToString());
                }
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_BAT0001 failed because " + e.Message);
            }

        }

        [TestMethod]
        public void FMUC0053_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF_02: Create second Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                #endregion
                #region Create a new Instance
                Reports.TestStep = "Create a new Instance.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Validate Data for a new Instance
                Support.AreEqual("Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_BAT0002 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF1_AF6: Edit the Utility Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                #endregion
                #region Create a new Instance
                Reports.TestStep = "Create a new Instance.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Validate Date for a new Instance
                Reports.TestStep = "Validate Date for a new Instance";
                Support.AreEqual("Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Select the Instance and Click on Edit
                Reports.TestStep = "Select the Instance and Click on Edit";
                FastDriver.LeftNavigation.Navigate<UtilitySummary>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#2", "utility name 1", "#2", TableAction.Click);
                FastDriver.UtilitySummary.Edit.Click();
                #endregion
                #region Edit the Instance
                Reports.TestStep = "Edit the Instance";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"100.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"100.00");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Select the Instance and Click on Edit again
                Reports.TestStep = "Select the Instance and Click on Edit again";
                FastDriver.LeftNavigation.Navigate<UtilitySummary>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#2", "utility name 1", "#2", TableAction.Click);
                FastDriver.UtilitySummary.Edit.Click();
                #endregion
                #region Validate the Edited Instance
                Reports.TestStep = "Validate the Edited Instance";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual("Utilities", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"100.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"100.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Select The Instance and Click on Edit 3
                Reports.TestStep = "Select The Instance and Click on Edit 3";
                FastDriver.LeftNavigation.Navigate<UtilitySummary>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#2", "utility name 1", "#2", TableAction.Click);
                FastDriver.UtilitySummary.Edit.Click();
                #endregion
                #region Edit and cancel the Instance
                Reports.TestStep = "Edit and cancel the Instance";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText(@"220");
                FastDriver.UtilityDetail.Find.Click();
                FastDriver.UtilityDetail.WaitForValue(FastDriver.UtilityDetail.GabCodeLabel, @"220");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge1");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Validate Data for a new Instance
                Reports.TestStep = "Validate Data for a new Instance";
                Support.AreEqual("Utility Charge1", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                #endregion
                #region Click on Reset
                Reports.TestStep = "Click on Reset";
                FastDriver.BottomFrame.Reset();
                #endregion
                #region Click on Cancel
                Reports.TestStep = "Click on Cancel";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Validate Data after canceling reset operation
                Reports.TestStep = "Validate Data after canceling reset operation";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual("true", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().Contains(@"220").ToString().ToLower());
                Support.AreEqual(@"Utility Charge1", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                #endregion
                #region Click on Reset
                Reports.TestStep = "Click on Reset";
                FastDriver.BottomFrame.Reset();
                #endregion
                #region Click on Ok
                Reports.TestStep = "Click on Ok";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Verify Edited and Cancelled Instance
                Reports.TestStep = "Verify Edited and Cancelled Instance";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual("UTILITY", FastDriver.UtilityDetail.GabCodeLabel.FAGetText());
                Support.AreEqual(@"Utilities", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"100.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"100.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate the data in Escrow File Balance Summary
                Reports.TestStep = "Validate the data in Escrow File Balance Summary";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>(@"Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual(@"SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.FAGetText());
                Support.AreEqual(@"5,150.00", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.FAGetText());
                Support.AreEqual(@"5,150.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText());
                Support.AreEqual(@"4,850.00", FastDriver.EscrowFileBalanceSummary.NetSellerCheck.FAGetText());
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_BAT0003 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF2: Delete the Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                #endregion
                #region Create a new Instance
                Reports.TestStep = "Create a new Instance.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Validate Date for a new Instance
                Reports.TestStep = "Validate Date for a new Instance";
                Support.AreEqual("Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Select the Instance and Remove it
                Reports.TestStep = "Select the Instance and Remove it";
                FastDriver.LeftNavigation.Navigate<UtilitySummary>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#2", "utility name 1", "#2", TableAction.Click);
                FastDriver.UtilitySummary.Remove.Click();
                #endregion
                #region Click on Ok
                Reports.TestStep = "Click on Ok";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Verify for removal of Instance
                Reports.TestStep = "Verify for removal of Instance";
                FastDriver.LeftNavigation.Navigate<UtilitySummary>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#2", "Available", "#2", TableAction.Click);
                #endregion
                #region Click on Edit
                Reports.TestStep = "Click on Edit";
                FastDriver.UtilitySummary.Edit.Click();
                #endregion
                #region Validate First Instance was canceled
                Reports.TestStep = "Validate First Instance was canceled";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual(@"", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetText());
                Support.AreEqual(@"", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetText());
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_BAT0004 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF3: Cancel the First Instance and creating First Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Cancel First Instance
                Reports.TestStep = "Cancel First Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"#");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"#");
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on OK button
                Reports.TestStep = "Click on OK button";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                #endregion
                #region Enter payment details for UTILITY
                if (IsFormTypeCD)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.Description.FASetText(@"Sanity-UTILITY");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.Description.FASetText(@"Sanity-UTILITY");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.WaitForScreenToLoad();
                }
                #endregion
                #region Click on Payment Details
                Reports.TestStep = "Click on Payment Details";
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                #endregion
                #region Verify Payment Details for UTILITY
                Reports.TestStep = "Verify Payment Details for UTILITY";
                if (IsFormTypeCD)
                {
                    Support.AreEqual(@"Sanity-UTILITY", FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().ToString());
                }
                else
                {
                    Support.AreEqual(@"Sanity-UTILITY", FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToString());
                    Support.AreEqual(@"8.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().ToString());
                    Support.AreEqual(@"8.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().ToString());
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_BAT0005 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF4: Cancel the second Instance and creating second Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                #endregion
                #region Cancel Second Instance
                Reports.TestStep = "Cancel Second Instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Reset();
                #endregion
                #region Click on OK button
                Reports.TestStep = "Click on OK button";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Click on New again
                Reports.TestStep = "Click on New again.";
                FastDriver.BottomFrame.New();
                #endregion
                #region Create a new instance
                Reports.TestStep = "Create a new instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Validate Data for a new instance
                Reports.TestStep = "Validate Data for a new instance";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual(@"Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_BAT0006 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF4: Cancel the second Instance and creating second Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                #endregion
                #region Set a second instance of Utility details
                Reports.TestStep = "Set a second instance of Utility details.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"ELENDER");
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New again.";
                FastDriver.BottomFrame.New();
                #endregion
                #region Cancel Third Instance
                Reports.TestStep = "Cancel Third Instance.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on OK button
                Reports.TestStep = "Click on OK button";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Click on New again to create third instance
                Reports.TestStep = "Click on New again to create third instance.";
                FastDriver.UtilitySummary.WaitForScreenToLoad(timeout: 10);
                FastDriver.UtilitySummary.New.Click();
                #endregion
                #region Create a new third instance
                Reports.TestStep = "Create a new third instance.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Validate Data for a new third instance
                Reports.TestStep = "Validate Data for a new third instance";
                Support.AreEqual(@"Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_BAT0007 failed because " + e.Message);
            }
        }
        #endregion

        #region REGRESSION
        [TestMethod]
        public void FMUC0053_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM1855_FM3271_FM2536_FM2537_FM1870_FM1870: 1:Utilities 2:Allow Multiple Instances 3:Display Payment Details 4:Display Check Details 5:Allow Both Charge Types.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                #endregion
                #region Enter payment details for UTILITY
                if (IsFormTypeCD)
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.Description.FASetText(@"Sanity-UTILITY");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.WaitForScreenToLoad();
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.Description.FASetText(@"Sanity-UTILITY");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(@"8.99");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.UtilityDetail.WaitForScreenToLoad();
                }
                #endregion
                #region Click on Payment Details
                Reports.TestStep = "Click on Payment Details";
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                #endregion
                #region Verify Payment Details for UTILITY
                Reports.TestStep = "Verify Payment Details for UTILITY";
                if (IsFormTypeCD)
                {
                    Support.AreEqual(@"Sanity-UTILITY", FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().ToString());
                    Support.AreEqual(@"$8.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().ToString());
                }
                else
                {
                    Support.AreEqual(@"Sanity-UTILITY", FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToString());
                    Support.AreEqual(@"8.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().ToString());
                    Support.AreEqual(@"8.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().ToString());
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                #endregion
                #region Enter Proration Details
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.UtilityDetail.ProrationAmount.FASetText(@"50.00");
                FastDriver.UtilityDetail.FromDate.FASetText(@"07/10/2020");
                FastDriver.UtilityDetail.BasedOn.FASelectItem(@"365");
                FastDriver.UtilityDetail.Per.FASelectItem(@"MONTH");
                FastDriver.UtilityDetail.ToDate.FASetText("07/17/2020");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate Entered Proration Details
                Reports.TestStep = "Validate Entered Proration Details";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.ProrationAmount.FAGetValue());
                Support.AreEqual(@"07-10-2020", FastDriver.UtilityDetail.FromDate.FAGetValue());
                Support.AreEqual(@"365", FastDriver.UtilityDetail.BasedOn.FAGetSelectedItem());
                Support.AreEqual(@"MONTH", FastDriver.UtilityDetail.Per.FAGetSelectedItem());
                Support.AreEqual(@"07-17-2020", FastDriver.UtilityDetail.ToDate.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Click on New
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.New();
                #endregion
                #region Create a new instance of Utility Details
                Reports.TestStep = "Create a new instance of Utility Details";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.WaitForValue(FastDriver.UtilityDetail.GabCodeLabel, @"247");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Validate Data for a new instance
                Reports.TestStep = "Validate Data for new instance of Utility Details";
                Support.AreEqual("Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New";
                FastDriver.LeftNavigation.Navigate<UtilitySummary>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.New.Click();
                #endregion
                #region Create a new Instance
                Reports.TestStep = "Create a new Instance";
                FastDriver.UtilityDetail.FindGABcode("ELENDER");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Validate data for a new instance
                Support.AreEqual("Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Click on Edit
                Reports.TestStep = "Click on Edit.";
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#2", "utility name 1", "#2", TableAction.Click);
                FastDriver.UtilitySummary.Edit.Click();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Click on Remove
                Reports.TestStep = "Click on Remove.";
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#2", "utility name 1", "#2", TableAction.Click);
                FastDriver.UtilitySummary.Remove.Click();
                #endregion
                #region Click on Ok
                Reports.TestStep = "Click on Ok";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Verify for removal of Instance
                Reports.TestStep = "Verify for removal of Instance";
                FastDriver.LeftNavigation.Navigate<UtilitySummary>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#2", "Available", "#2", TableAction.Click);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_REG0001 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM2538_ES6091_FM1870_EWC_1_2_3_4_6_11: 1:Display Check Amounts 2:Prorate Pre-Paid Utility Charges 3:User deletes a charge process instance that has issued checks. 4:User deletes a charge process instance that does not have issues.";
                #region Initialize Variables
                string ExpectedMessage, ActualMessage = "";
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Set Default Check Printer
                SetDefaultCheckPrinter();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Set an instance of Utility details
                Reports.TestStep = "Set an instance of Utility details.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"UTILITY");
                FastDriver.UtilityDetail.Reference.FASetText(@"8198565");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("true", FastDriver.UtilityDetail.CheckAmount.FAGetText().Contains("100.00").ToString().ToLower());
                #endregion
                #region Enter Proration Details
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.UtilityDetail.ProrationAmount.FASetText(@"50.00");
                FastDriver.UtilityDetail.FromDate.FASetText(@"07/10/2020");
                FastDriver.UtilityDetail.BasedOn.FASelectItem(@"365");
                FastDriver.UtilityDetail.Per.FASelectItem(@"MONTH");
                FastDriver.UtilityDetail.ToDate.FASetText("07/17/2020");
                //FastDriver.UtilityDetail.ProrationBuyerCharge.FASetText(@"0");
                //FastDriver.UtilityDetail.ProrationSellerCharge.FASetText(@"0");
                //FastDriver.UtilityDetail.ProrationSellerCredit.FASetText(@"0");
                //FastDriver.UtilityDetail.ProrationDescription.FASetText(@"ProrationDescription");//looks like the description cannot be changed...
                FastDriver.UtilityDetail.ProrationBuyerCharge.FASetText(@"35");
                FastDriver.UtilityDetail.ProrationSellerCharge.FASetText(@"35");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate all Details to verify system allows both charge types
                Reports.TestStep = "Validate Entered Proration Details";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.ProrationAmount.FAGetValue());
                Support.AreEqual(@"07-10-2020", FastDriver.UtilityDetail.FromDate.FAGetValue());
                Support.AreEqual(@"365", FastDriver.UtilityDetail.BasedOn.FAGetSelectedItem());
                Support.AreEqual(@"MONTH", FastDriver.UtilityDetail.Per.FAGetSelectedItem());
                Support.AreEqual(@"07-17-2020", FastDriver.UtilityDetail.ToDate.FAGetValue());
                //Support.AreEqual(@"ProrationDescription", FastDriver.UtilityDetail.ProrationDescription.FAGetValue());
                Support.AreEqual(@"35.00", FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue());
                Support.AreEqual(@"35.00", FastDriver.UtilityDetail.ProrationSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Uncheck credit to Seller
                Reports.TestStep = "Uncheck credit to Seller";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(false);
                #endregion
                #region Validate Proration Message
                Reports.TestStep = "Validate Proration Message";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                ExpectedMessage = @"Proration formula values have changed. Do you wish to recalculate prorated charges?";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Validate Entered Proration Details not for credit to seller
                Reports.TestStep = "Validate Entered Proration Details not for credit to seller";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.ProrationAmount.FAGetValue(), "Verify Proration Amount value");
                Support.AreEqual(@"07-10-2020", FastDriver.UtilityDetail.FromDate.FAGetValue(), "Verify From Date value");
                Support.AreEqual(@"365", FastDriver.UtilityDetail.BasedOn.FAGetSelectedItem(), "Verify Based On value");
                Support.AreEqual(@"MONTH", FastDriver.UtilityDetail.Per.FAGetSelectedItem(), "Verify Month value");
                Support.AreEqual(@"07-17-2020", FastDriver.UtilityDetail.ToDate.FAGetValue(), "Verify To Date value");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Edit other proration details
                Reports.TestStep = "Edit other proration details";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.ProrationAmount.FASetText(@"60.00");
                FastDriver.UtilityDetail.ProrationAmount.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FromDate.FASetText(@"7/09/2020");
                FastDriver.UtilityDetail.FromDate.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.ToDate.FASetText(@"7/16/2021");
                FastDriver.UtilityDetail.ToDate.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.BasedOn.FASelectItemBySendingKeys(@"360");
                //FastDriver.UtilityDetail.BasedOn.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.Per.FASelectItemBySendingKeys(@"SEMIANNUAL");
                //FastDriver.UtilityDetail.Per.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Enter Invalid GAB or change the GAB for Issued instance
                Reports.TestStep = "Enter Invalid GAB or change the GAB for Issued instance";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText(@"XCHZ");
                FastDriver.UtilityDetail.Find.Click();
                #endregion
                #region ID Code Not Found
                Reports.TestStep = "ID Code Not Found";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                #endregion
                #region Print All Checks
                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.Click();
                FastDriver.PrintChecks.SwitchToContentFrame();
                #endregion
                #region Click on Deliver
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 20) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Enter Invalid GAB or Change the GAB for issued instance
                Reports.TestStep = "Enter Invalid GAB or Change the GAB for issued instance.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText(@"XCHZ");
                FastDriver.UtilityDetail.Find.Click();
                #endregion
                #region Change Payee To whom check issued
                Reports.TestStep = "Change Payee To whom check issued";
                ExpectedMessage = "A check has been issued for this Payee.  The Payee name cannot be changed.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Change the Charge Amount less than Existing Amount
                Reports.TestStep = "Change the Charge Amount less than Existing Amount";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"49.00");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Enter less than the issued amount
                Reports.TestStep = "Enter less than the issued amount";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true);
                ExpectedMessage = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Enter greater charge than the Existing Amount
                Reports.TestStep = "Enter greater charge than the Existing Amount";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"51.00");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Enter greater charge than the issued amount
                Reports.TestStep = "Enter greater charge than the issued amount";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true);
                ExpectedMessage = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Delete Charge Description
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"");
                FastDriver.UtilityDetail.UtilityChargesDescription.SendKeys(FAKeys.Tab);
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                ExpectedMessage = "Unable to delete charge description.  Charge description still has a charge amount.";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Click on Delete
                FastDriver.BottomFrame.Delete();
                #endregion
                #region Delete the payee have issued instance
                ActualMessage = "A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.";
                ExpectedMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_REG0002 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_REG0003()
        {
            try
            {
                Reports.TestDescription = "ES6092: Disable Proration's Entry in Sub Escrow Files";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Verify for FileHomepage
                Reports.TestStep = "Verify for FileHomepage";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.FileHomepage.ChangeOO.Exists().ToString().ToLower());
                #endregion
                //Old script expected this values to be false, apparently that is not valid anymore
                #region Verify Proration section is Disabled
                Reports.TestStep = "Verify Proration section is Disabled";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.UtilityDetail.CreditSeller.Enabled.ToString().ToLower());
                Support.AreEqual("true", FastDriver.UtilityDetail.ProrationDescription.Enabled.ToString().ToLower());
                Support.AreEqual("true", FastDriver.UtilityDetail.ProrationAmount.Enabled.ToString().ToLower());
                Support.AreEqual("true", FastDriver.UtilityDetail.FromDate.Enabled.ToString().ToLower());
                Support.AreEqual("true", FastDriver.UtilityDetail.ToDate.Enabled.ToString().ToLower());
                Support.AreEqual("true", FastDriver.UtilityDetail.BasedOn.Enabled.ToString().ToLower());
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_REG0003 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_REG0004()
        {
            try
            {
                Reports.TestDescription = "EWC_7_8_9_10 2: User cancels entry of the SECOND instance using Cancel button on framework before a saving s new process instance. 3:User cancels entry of the THIRD or SUBSEQUENT new instance using Cancel button on framework";
                #region Initialize Variables
                string ExpectedMessage, ActualMessage = "";
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Verify Check Amount
                Reports.TestStep = "Verify Check Amount";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.Reference.FASetText(@"8198565");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Click on Done
                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"70.00");
                #endregion
                #region Click on Reset 
                Reports.TestStep = "Click on Reset";
                FastDriver.BottomFrame.Reset();
                #endregion
                #region Cancel without save changes
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                ExpectedMessage = @"Cancel without saving changes?";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Click on Delete
                Reports.TestStep = "Click on Delete";
                FastDriver.BottomFrame.Delete();
                #endregion
                #region Delete the Payee that have not issued checks
                Reports.TestStep = "Delete the Payee that have not issued checks";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                ExpectedMessage = "All information will be removed for this Utility.  Continue?";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Validate that data is deleted
                Reports.TestStep = "Validate that data is deleted";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual(@" ", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().ToString());
                Support.AreEqual(@"", FastDriver.UtilityDetail.Reference.FAGetText().ToString());
                Support.AreEqual(@"", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetText().ToString());
                Support.AreEqual(@"", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetText().ToString());
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New";
                FastDriver.BottomFrame.New();
                #endregion
                #region Cancel without save changes again
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                ExpectedMessage = @"Cancel without save changes?";
                //Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Click on New to create 2nd instance
                Reports.TestStep = "Click on New to create 2nd instance";
                FastDriver.BottomFrame.New();
                #endregion
                #region Create a new Instance
                Reports.TestStep = "Create a new Instance.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"247");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Validate Data for a new Instance
                Support.AreEqual("Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                #endregion
                #region Click on New to create 3rd instance
                Reports.TestStep = "Click on New to create 3rd instance";
                FastDriver.BottomFrame.New();
                #endregion
                #region Create Third Instance
                Reports.TestStep = "Create Third Instance.";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode(@"HUDUTLCMP1");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Validate Data for a new Instance
                Support.AreEqual("Utility Charge", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"50.00", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate multiple instances on summary
                Reports.TestStep = "Validate multiple instances on summary";
                FastDriver.LeftNavigation.Navigate<UtilitySummary>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                try
                {
                    FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#1", "1", "#1", TableAction.Click);
                }
                catch
                {
                    Reports.StatusUpdate("Could not find first instance on Utility Summary table", false);
                }
                try
                {
                    FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#1", "2", "#1", TableAction.Click);
                }
                catch
                {
                    Reports.StatusUpdate("Could not find seconf instance on Utility Summary table", false);
                }
                try
                {
                    FastDriver.UtilitySummary.SummaryTable.PerformTableAction("#1", "3", "#1", TableAction.Click);
                }
                catch
                {
                    Reports.StatusUpdate("Could not find third instance on Utility Summary table", false);
                }
                
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_REG0004 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_REG0005() 
        {
            try
            {
                Reports.TestDescription = "EWC_5_13_14_15_12: 1:User searches for a business party on ID code and system does not find an exact match 2:User tries to save a charge process instace without the minimum required data.";
                #region Initialize Variables
                string ExpectedMessage, ActualMessage = "";
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Save without bus party
                Reports.TestStep = "Save without bus party";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"100.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"100.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Save changes without Bus Party
                Reports.TestStep = "Save changes without Bus Party";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                ExpectedMessage = "Error(s) occured. See Message pane.";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                #endregion
                #region Verify the Error Message
                Reports.TestStep = "Verify the Error Message";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.UtilityDetail.ErrorMessageList.FAGetText().Contains("BusOrgID: Business Party required").ToString().ToLower());
                #endregion
                #region Verify Check Amount
                Reports.TestStep = "Verify Check Amount";
                FastDriver.UtilityDetail.FindGABcode("HUDUTLCMP1");
                FastDriver.UtilityDetail.Reference.FASetText(@"8198565");
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Click on Done
                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.UtilityDetail.CheckAmount.FAGetText());
                #endregion
                #region Verify Enter Name if Checkbox is checked
                Reports.TestStep = "Verify Enter Name if Checkbox is checked";
                FastDriver.UtilityDetail.EditName.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Enter Contact when Edit Name is checked
                Reports.TestStep = "Enter Contact when Edit Name is checked";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                ExpectedMessage = @"Name field is required when Edit Name checkbox is selected.";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Verify Invalid Email Address
                Reports.TestStep = "Verify Invalid Email Address";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.Edit.FASetCheckbox(true);
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"test.com");
                FastDriver.UtilityDetail.EmailAddress.SendKeys(FAKeys.Tab);
                Support.AreEqual("?", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString().Trim());
                #endregion
                #region Invalid Email Address
                Reports.TestStep = "Invalid Email Address";
                FastDriver.UtilityDetail.GABcode.FASetText(@"247");
                FastDriver.UtilityDetail.Find.Click();
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                ExpectedMessage = "Please correct invalid data entered.";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Replace Existing GAB having Reference No with New one
                Reports.TestStep = "Replace Existing GAB having Reference No with New one";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"abc@test.com");
                FastDriver.UtilityDetail.EmailAddress.SendKeys(FAKeys.Tab);
                FastDriver.UtilityDetail.GABcode.FASetText(@"247");
                FastDriver.UtilityDetail.Find.Click();
                #endregion
                #region Change Business Party have Ref No.
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                ExpectedMessage = "Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_REG0005 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_REG0006() 
        {
            try
            {
                Reports.TestDescription = "FD: Field Definitions";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Verify the field with lower Boundary value
                Reports.TestStep = "Verify the field with lower Boundary value";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDFLINSR1");
                Support.AreEqual("HUDFLINSR1", FastDriver.UtilityDetail.GabCodeLabel.FAGetText());
                FastDriver.UtilityDetail.GABName.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789");
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789", FastDriver.UtilityDetail.GABName.FAGetValue().ToString());
                FastDriver.UtilityDetail.Edit.FASetCheckbox(true);
                Playback.Wait(3000);
                FastDriver.UtilityDetail.BusPhone.FASetText(@"123456789");
                FastDriver.UtilityDetail.BusPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.BusFax.FASetText(@"123456789");
                FastDriver.UtilityDetail.BusFax.SendKeys(FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.CellPhone.FASetText(@"123456789");
                FastDriver.UtilityDetail.CellPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.Pager.FASetText(@"123456789");
                FastDriver.UtilityDetail.Pager.SendKeys(FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"test.test");
                FastDriver.UtilityDetail.EmailAddress.SendKeys(FAKeys.Tab);
                Support.AreEqual("?", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString());
                FastDriver.BottomFrame.Cancel();
                #endregion               
                #region Click on OK button
                Reports.TestStep = "Click on OK button";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Verify the Field with lower Boundary value
                Reports.TestStep = "Verify the Field with lower Boundary value";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.Edit.FASetCheckbox(true);
                FastDriver.UtilityDetail.EditName.FASetCheckbox(true);
                FastDriver.UtilityDetail.Name.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456");
                FastDriver.UtilityDetail.Name.SendKeys(FAKeys.Tab); 
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456", FastDriver.UtilityDetail.Name.FAGetValue().ToString());
                FastDriver.UtilityDetail.Reference.FASetText(@"0123456789012345678901234567890123456789012345678");
                FastDriver.UtilityDetail.Reference.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"0123456789012345678901234567890123456789012345678", FastDriver.UtilityDetail.Reference.FAGetValue().ToString());
                FastDriver.UtilityDetail.Reference.SendKeys(FAKeys.Tab);
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH");
                FastDriver.UtilityDetail.UtilityChargesDescription.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.SendKeys(Keys.Home);
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.SendKeys(Keys.Delete);
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.SendKeys(@"99999999999.99");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(Keys.Home);
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(Keys.Delete);
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(@"99999999999.99");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationAmount.FASetText(@"99999999999.99");
                FastDriver.UtilityDetail.ProrationAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.UtilityDetail.ProrationAmount.FAGetValue().ToString());
                Support.AreEqual(@"360 365 366", FastDriver.UtilityDetail.BasedOn.FAGetText());
                Support.AreEqual(@"DAY MONTH QUARTER SEMIANNUAL TRIMESTER WEEK YEAR", FastDriver.UtilityDetail.Per.FAGetText());
                Playback.Wait(1000);
                FastDriver.UtilityDetail.ProrationDescription.SendKeys("");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.ProrationDescription.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Playback.Wait(1000);
                for (int i = 0; i <= 20; i++)
                {
                    FastDriver.UtilityDetail.ProrationDescription.SendKeys(Keys.Home);
                    FastDriver.UtilityDetail.ProrationDescription.SendKeys(Keys.Delete);
                }
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.UtilityDetail.ProrationDescription.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationBuyerCharge.SendKeys(Keys.Home);
                FastDriver.UtilityDetail.ProrationBuyerCharge.SendKeys(Keys.Delete); 
                FastDriver.UtilityDetail.ProrationBuyerCharge.SendKeys(@"99999999999.99");
                FastDriver.UtilityDetail.ProrationBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationBuyerCredit.SendKeys(Keys.Home);
                FastDriver.UtilityDetail.ProrationBuyerCredit.SendKeys(Keys.Delete);
                FastDriver.UtilityDetail.ProrationBuyerCredit.SendKeys(@"99999999999.99");
                FastDriver.UtilityDetail.ProrationBuyerCredit.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.UtilityDetail.ProrationBuyerCredit.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationSellerCharge.SendKeys(Keys.Home);
                FastDriver.UtilityDetail.ProrationSellerCharge.SendKeys(Keys.Delete);
                FastDriver.UtilityDetail.ProrationSellerCharge.SendKeys(@"99999999999.99");
                FastDriver.UtilityDetail.ProrationSellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.UtilityDetail.ProrationSellerCharge.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationSellerCredit.SendKeys(Keys.Home);
                FastDriver.UtilityDetail.ProrationSellerCredit.SendKeys(Keys.Delete);
                FastDriver.UtilityDetail.ProrationSellerCredit.SendKeys(@"99999999999.99");
                FastDriver.UtilityDetail.ProrationSellerCredit.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"99,999,999,999.99", FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue().ToString());
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on OK button
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Verify the Field with Exact value
                Reports.TestStep = "Verify the Field with Exact value";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("HUDFLINSR1");
                FastDriver.UtilityDetail.GABName.FASetText(@"ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890");
                FastDriver.UtilityDetail.Edit.FASetCheckbox(true);
                FastDriver.UtilityDetail.BusPhone.FASetText(@"1234567899");
                FastDriver.UtilityDetail.BusPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.BusFax.FASetText(@"1234567899");
                FastDriver.UtilityDetail.BusFax.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.UtilityDetail.BusFax.FAGetValue().ToString());
                FastDriver.UtilityDetail.CellPhone.FASetText(@"1234567899");
                FastDriver.UtilityDetail.CellPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.UtilityDetail.CellPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.Pager.FASetText(@"1234567899");
                FastDriver.UtilityDetail.Pager.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"(123)456-7899", FastDriver.UtilityDetail.Pager.FAGetValue().ToString());
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"test@test.com");
                FastDriver.UtilityDetail.EmailAddress.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"test@test.com", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString());
                FastDriver.UtilityDetail.EditName.FASetCheckbox(true);
                FastDriver.UtilityDetail.Name.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567");
                Support.AreEqual(@"ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.UtilityDetail.Name.FAGetValue().ToString());
                FastDriver.UtilityDetail.Reference.FASetText("01234567890123456789012345678901234567890123456789");
                Support.AreEqual(@"01234567890123456789012345678901234567890123456789", FastDriver.UtilityDetail.Reference.FAGetValue().ToString());
                Playback.Wait(1000); 
                for (int i = 0; i <= 40; i++)
                {
                    FastDriver.UtilityDetail.UtilityChargesDescription.SendKeys(Keys.Home);
                    FastDriver.UtilityDetail.UtilityChargesDescription.SendKeys(Keys.Delete);
                }
                FastDriver.UtilityDetail.UtilityChargesDescription.SendKeys(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI");
                FastDriver.UtilityDetail.UtilityChargesDescription.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationDescription.SendKeys("");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.ProrationDescription.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Playback.Wait(1000);
                for (int i = 0; i <= 20; i++)
                {
                    FastDriver.UtilityDetail.ProrationDescription.SendKeys(Keys.Home);
                    FastDriver.UtilityDetail.ProrationDescription.SendKeys(Keys.Delete);
                }
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI");
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.UtilityDetail.ProrationDescription.FAGetValue().ToString());
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on OK button again
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Verify the Field with Upper Boundary Value
                Reports.TestStep = "Verify the Field with Upper Boundary Value.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText("HUDFLINSR12");
                FastDriver.UtilityDetail.GABName.FASetText(@"ABCDEFGHIJABCDEFGHIJABCDEFGHIJ12345678901");
                Support.AreEqual(@"ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.UtilityDetail.GABName.FAGetValue().ToString());
                FastDriver.UtilityDetail.Edit.FASetCheckbox(true);
                FastDriver.UtilityDetail.BusPhone.FASetText(@"12345678999");
                FastDriver.UtilityDetail.BusPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.BusFax.FASetText(@"12345678999");
                FastDriver.UtilityDetail.BusFax.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.CellPhone.FASetText(@"12345678999");
                FastDriver.UtilityDetail.CellPhone.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.Pager.FASetText(@"12345678999");
                FastDriver.UtilityDetail.Pager.SendKeys(FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.UtilityDetail.BusPhone.FAGetValue().ToString());
                FastDriver.UtilityDetail.EmailAddress.FASetText(@"test@test.com");
                FastDriver.UtilityDetail.EmailAddress.SendKeys(FAKeys.Tab);
                Support.AreEqual("test@test.com", FastDriver.UtilityDetail.EmailAddress.FAGetValue().ToString());
                FastDriver.UtilityDetail.EditName.FASetCheckbox(true);
                FastDriver.UtilityDetail.Name.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678");
                Support.AreEqual(@"ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.UtilityDetail.Name.FAGetValue().ToString());
                FastDriver.UtilityDetail.Reference.FASetText("012345678901234567890123456789012345678901234567890");
                Support.AreEqual(@"01234567890123456789012345678901234567890123456789", FastDriver.UtilityDetail.Reference.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationDescription.SendKeys("");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.ProrationDescription.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Playback.Wait(1000);
                for (int i = 0; i <= 40; i++)
                {
                    FastDriver.UtilityDetail.ProrationDescription.SendKeys(Keys.Home);
                    FastDriver.UtilityDetail.ProrationDescription.SendKeys(Keys.Delete);
                }
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);


                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ");
                FastDriver.UtilityDetail.UtilityChargesDescription.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue().ToString());
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"10000000000000000");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"?", FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue().ToString());
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"10000000000000000");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"?", FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationAmount.FASetText(@"10000000000000000");
                FastDriver.UtilityDetail.ProrationAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"?", FastDriver.UtilityDetail.ProrationAmount.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationDescription.SendKeys("");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.ProrationDescription.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Playback.Wait(1000);
                for (int i = 0; i <= 40; i++)
                {
                    FastDriver.UtilityDetail.ProrationDescription.SendKeys(Keys.Home);
                    FastDriver.UtilityDetail.ProrationDescription.SendKeys(Keys.Delete);
                }
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual(@"ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.UtilityDetail.ProrationDescription.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationBuyerCharge.FASetText(@"10000000000000000");
                FastDriver.UtilityDetail.ProrationBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"?", FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationBuyerCredit.FASetText(@"10000000000000000");
                FastDriver.UtilityDetail.ProrationBuyerCredit.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"?", FastDriver.UtilityDetail.ProrationBuyerCredit.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationSellerCharge.FASetText(@"10000000000000000");
                FastDriver.UtilityDetail.ProrationSellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"?", FastDriver.UtilityDetail.ProrationSellerCharge.FAGetValue().ToString());
                FastDriver.UtilityDetail.ProrationSellerCredit.FASetText(@"10000000000000000");
                FastDriver.UtilityDetail.ProrationSellerCredit.SendKeys(FAKeys.Tab);
                Support.AreEqual(@"?", FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue().ToString());
                #endregion
                #region Click on Cancel
                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on OK button again 3
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion                
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_REG0006 failed because " + e.Message);
            }
        }

        [TestMethod]
        public void FMUC0053_REG0007() 
        {
            try
            {
                Reports.TestDescription = "FM2534_FM2537: 1:Required Data 2:Display Check Details";
                #region Initialize Variables
                string data = "";
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {    
                                State = "CA",  
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region To Click on Find button under business party
                Reports.TestStep = "To Click on Find button under business party";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.Find.FAClick();
                #endregion
                #region Search a Outside Escrow Company GAB and select it
                Reports.TestStep = "Search a Outside Escrow Company GAB and select it";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.EntityName);
                FastDriver.AddressBookSearchDlg.EntityName.FASetText(@"Test");
                FastDriver.AddressBookSearchDlg.Find.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: false, timeout: 10);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                try
                {
                    FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("#7", "AD194009", "#1", TableAction.Click);
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Could not select the element with the ID AD194009 on the Search Results table", false);
                }
                FastDriver.DialogBottomFrame.ClickDone(); 
                #endregion
                #region To enter Buyer charge
                Reports.TestStep = "To enter Buyer charge";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.UtilityChargesDescription.FASetText(@"Utility Charge");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText(@"50.00");
                FastDriver.UtilityDetail.UtilityChargesSellerCharge.FASetText(@"50.00");
                #endregion
                #region Click on Check Details
                FastDriver.UtilityDetail.CheckDetails.Click();
                #endregion
                #region Edit Description for Utility
                Reports.TestStep = "Edit Description for Utility";
                FastDriver.WebDriver.WaitForWindowAndSwitch(windowName: "Check Detail", timeoutSeconds: 10);
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.Description.FASetText(@"Description for Survey Company Regression");
                Support.DataSave("CheckDetailDescription", "Check_Desc", FastDriver.CheckDetailsDlg.Description.FAGetValue().ToString().Trim());
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText(@"Check Voucher info for Survey Company Regression");
                Support.DataSave("CheckDetailVoucherInfo", "VoucherInfo", FastDriver.CheckDetailsDlg.VoucherInfo.FAGetValue().ToString().Trim());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Validate Check Details
                Reports.TestStep = "Validate Check Details";
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.CheckDetails.Click();
                #endregion
                #region Verify Description for Utility
                Reports.TestStep = "Verify Description for Utility";
                FastDriver.WebDriver.WaitForWindowAndSwitch(windowName: "Check Detail", timeoutSeconds: 10);
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                Support.DataLoad("CheckDetailDescription", "Check_Desc");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.CheckDetailsDlg.Description.FAGetValue().ToString().Trim());
                Support.DataLoad("CheckDetailVoucherInfo", "VoucherInfo");
                data = Support.data;//has the data from the previous DataLoad method
                Support.AreEqualTrim(@data, FastDriver.CheckDetailsDlg.VoucherInfo.FAGetValue().ToString().Trim());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0053_REG0007 failed because " + e.Message);
            }
        }
        #endregion

        #region Methods
        private void SetBuyerPaymentMethod(string PaymentMethod)
        {
            FastDriver.UtilityDetail.WaitForScreenToLoad();
            FastDriver.UtilityDetail.PaymentDetails.FAClick();
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            if (AutoConfig.FormType == "CD")
            {
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItem(PaymentMethod);
            }
            else
            {
                FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem(PaymentMethod);
            }
            FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(); 
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
        }

        #region IISLOGIN
        private void _IISLOGIN(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }
        #endregion

        private void SetDefaultCheckPrinter()
        {
            Reports.TestStep = "Set default check printer";
            FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
            FastDriver.PrinterConfiguration.SetDefaultPrinter();
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}




