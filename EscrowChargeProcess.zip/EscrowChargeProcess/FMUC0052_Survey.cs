﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;


namespace EscrowChargeProcess
{
    [CodedUITest]
    public class FMUC0052 : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void FMUC0052_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1_00: Create Order. Create 2 instances of Survey. Delete 1st instance.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set an instance for Survey Details.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Sanity-SURVEY");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("7.99");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the charges entered.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("7.99", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean(), "Verify Buyer Charge field value");
                Support.AreEqual("7.99", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean(), "Verify Seller Charge field value");
                Support.AreEqual("Check Amount: $ 15.98", FastDriver.SurveyDetail.CheckAmount.Text, "Verify Check Amount text");

                Reports.TestStep = "Select the payment details.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Validate the payment details entered.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Sanity-SURVEY", FastDriver.PaymentDetailsDlg.DESCRPTION.FAGetValue(), "Verify description field value");
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean(), "Verify Buyer Charge field value");
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean(), "Verify Seller Charge field value");
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Clean(), "Verify Load Estimate Unrounded field value");
                Support.AreEqual("$8.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Clean(), "Verify Load Estimate Rounded field value");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Change the Business party for the survey and click on new.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("255");
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Create a second survey with charges.";
                FastDriver.SurveyDetail.FindGABCode("248");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Survey");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.50" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("12.50" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify first instance.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Midwest Financial Group", "Name", TableAction.Click);

                Reports.TestStep = "Verify second instance and click on delete.";
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Thomas Freeman", "Name", TableAction.Click);
                FastDriver.SurveySummary.Remove.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify for Available Instance.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF3_01: Navigate to Survey screen and Cancel 1st New Survey Instance Creation.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Cancel the creation of First instance.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Cancel Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF3_02: Validate that home or welcome screen is loaded.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Cancel the creation of First instance.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Cancel Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "ACTUAL SCOPE OF THIS TEST CASE: Validate that home or welcome screen is loaded.";
                FastDriver.HomePage.WaitForHomeScreen();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1_01: Navigate to Survey and create first instance.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter payment details for SURVEY.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Sanity-SURVEY");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1_02: Validate the data in Survey screen";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (FROM BAT0004)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY. (FROM BAT0004)";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Sanity-SURVEY");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");

                Reports.TestStep = "Click on Done in Dialog Box. (FROM BAT0004)";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Payment Details.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Verify payment details for SURVEY.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Sanity-SURVEY", FastDriver.PaymentDetailsDlg.DESCRPTION.FAGetValue(), "Verify description field value");
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean(), "Verify Buyer Charge field value");
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean(), "Verify Seller Charge field value");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1_03: Change the Description and charge, saves the changes. Validate the changed description and charge.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (FROM BAT0004)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY. (FROM BAT0004)";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Sanity-SURVEY");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");

                Reports.TestStep = "Click on Done in Dialog Box. (FROM BAT0004)";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Edit the instance and save the changes made.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");

                Reports.TestStep = "Auto Save details Edited by Navigating again to the Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                Support.AreEqual("Changed Desc", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("11.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0007()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF4_01: Cancel 2nd New Survey Instance Creation.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (FROM BAT0004)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY. (FROM BAT0004)";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Sanity-SURVEY");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");

                Reports.TestStep = "Click on Done in Dialog Box and Bottom Frame. (FROM BAT0004)";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Cancellation of 2nd instance.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Cancel 2nd");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0008()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF4_02: Validate that first instance screen is loaded.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (FROM BAT0004)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY. (FROM BAT0004)";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Sanity-SURVEY");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");

                Reports.TestStep = "Click on Done in Dialog Box. (FROM BAT0004)";
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Edit the instance and save the changes made. (FROM BAT0006)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");

                Reports.TestStep = "Auto Save details Edited by Navigating again to the Survey Screen. (FROM BAT0006)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                Reports.TestStep = "Click on New. (FROM BAT0007)";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Cancellation of 2nd instance. (FROM BAT0007)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Cancel 2nd");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate the edition made to 1st instance.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("Changed Desc", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("11.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0009()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF1_01: Creates another instance and navigate to Survey summary screen.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (STEP FROM PREVIOUS TEST CASES)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Creation of 2nd instance.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("2nd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify summary screen is loaded.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0010()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF1_02: Select one instance from summary screen and validate the details of the instance.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (STEP FROM PREVIOUS TEST CASES)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New. (FROM BAT0009)";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Creation of 2nd instance. (FROM BAT0009)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("2nd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify summary screen is loaded. (FROM BAT0009)";
                FastDriver.SurveySummary.WaitForScreenToLoad();

                Reports.TestStep = "Select instance from summary screen and edit the gab.";
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Flood Insurance 1 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Validate that 2nd instance is correct.";
                Support.AreEqual("2nd Instance", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("10.01", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("11.01", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());



            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0011()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF1_03: Edit second instance and Click on Find button.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (STEP FROM PREVIOUS TEST CASES)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New. (FROM BAT0009)";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Creation of 2nd instance. (FROM BAT0009)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("2nd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify summary screen is loaded. (FROM BAT0009)";
                FastDriver.SurveySummary.WaitForScreenToLoad();

                Reports.TestStep = "Select instance from summary screen and edit the gab. (FROM BAT0010)";
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Flood Insurance 1 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Click Find";
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "Set File address book radio button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad(element: FastDriver.AddressBookSearchDlg.FileaddressBookRadio);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio);
                FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Edit the instance and save the changes made.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");

                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "BuyerName BuyerLastName", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("Changed Desc", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("11.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0012()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF2_01: Select Second instance and click on Delete.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (STEP FROM PREVIOUS TEST CASES)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New. (FROM BAT0009)";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Creation of 2nd instance. (FROM BAT0009)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("2nd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify summary screen is loaded. (FROM BAT0009)";
                FastDriver.SurveySummary.WaitForScreenToLoad();

                Reports.TestStep = "Select instance from summary screen and edit the gab. (FROM BAT0010)";
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Flood Insurance 1 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Click Find. (FROM BAT0011)";
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "Set File address book radio button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookRadio, 10);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio, 10);
                FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Edit the instance and save the changes made. (FROM BAT0011)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "BuyerName BuyerLastName", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("Changed Desc", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("11.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select instance from summary screen and delete the instance.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "BuyerName BuyerLastName", "Name", TableAction.Click);
                FastDriver.SurveySummary.Remove.FAClick();

                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0013()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF2_02: Validate that Available is displayed in summary screen and no value is present in detail screen.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (STEP FROM PREVIOUS TEST CASES)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New. (FROM BAT0009)";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Creation of 2nd instance. (FROM BAT0009)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("2nd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify summary screen is loaded. (FROM BAT0009)";
                FastDriver.SurveySummary.WaitForScreenToLoad();

                Reports.TestStep = "Select instance from summary screen and edit the gab. (FROM BAT0010)";
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Flood Insurance 1 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Click Find. (FROM BAT0011)";
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "Set File address book radio button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookRadio, 10);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio, 10);
                FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Edit the instance and save the changes made. (FROM BAT0011)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "BuyerName BuyerLastName", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("Changed Desc", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("11.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select instance from summary screen and delete the instance. (FROM BAT0012)";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "BuyerName BuyerLastName", "Name", TableAction.Click);
                FastDriver.SurveySummary.Remove.FAClick();

                Reports.TestStep = "Click on Ok Button. (FROM BAT0012)";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate that available is present and no values present in detail screen.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("Survey", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0014()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF5_01: Cancel 3rd New Survey Instance Creation.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (STEP FROM PREVIOUS TEST CASES)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New. (FROM BAT0009)";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Creation of 2nd instance. (FROM BAT0009)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("2nd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify summary screen is loaded. (FROM BAT0009)";
                FastDriver.SurveySummary.WaitForScreenToLoad();

                Reports.TestStep = "Select instance from summary screen and edit the gab. (FROM BAT0010)";
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Flood Insurance 1 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Click Find. (FROM BAT0011)";
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "Set File address book radio button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookRadio, 10);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio, 10);
                FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Edit the instance and save the changes made. (FROM BAT0011)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "BuyerName BuyerLastName", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("Changed Desc", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("11.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select instance from summary screen and delete the instance. (FROM BAT0012)";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "BuyerName BuyerLastName", "Name", TableAction.Click);
                FastDriver.SurveySummary.Remove.FAClick();

                Reports.TestStep = "Click on Ok Button. (FROM BAT0012)";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate that available is present and no values present in detail screen. (FROM BAT0013)";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("Survey", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancellation of 3nd instance.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("3rd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0015()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF5_02: Validate that summary screen is loaded and deleted instance is not present.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance. (STEP FROM PREVIOUS TEST CASES)";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on New. (FROM BAT0009)";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Creation of 2nd instance. (FROM BAT0009)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("2nd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify summary screen is loaded. (FROM BAT0009)";
                FastDriver.SurveySummary.WaitForScreenToLoad();

                Reports.TestStep = "Select instance from summary screen and edit the gab. (FROM BAT0010)";
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Flood Insurance 1 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Click Find. (FROM BAT0011)";
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "Set File address book radio button.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookRadio, 10);
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio, 10);
                FastDriver.AddressBookSearchDlg.FileaddressBookResultsRadio.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Edit the instance and save the changes made. (FROM BAT0011)";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.LeftNavigation.Navigate<SurveySummary>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "BuyerName BuyerLastName", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("Changed Desc", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("11.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select instance from summary screen and delete the instance. (FROM BAT0012)";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "BuyerName BuyerLastName", "Name", TableAction.Click);
                FastDriver.SurveySummary.Remove.FAClick();

                Reports.TestStep = "Click on Ok Button. (FROM BAT0012)";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate that available is present and no values present in detail screen. (FROM BAT0013)";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("Survey", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancellation of 3nd instance.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("3rd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate that summary screen is loaded and 3rd instance is not present in summary screen.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                Support.AreEqual("3", FastDriver.SurveySummary.SummaryTable.GetRowCount().ToString(), "Row count should be 3 (1 header row and 2 body rows)");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_BAT0016()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF6_01: Change the Description and charge, cancel the changes. Validate the changed description and charge. AF6_02: Validate the changes does not reflect in cancellation in edited instance (BAT0017)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create an instance.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("1st instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit instance.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("edited instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01");
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok Button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate the changes does not reflect in cancellation in edited instance";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("1st instance", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                Support.AreEqual("10.00", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                Support.AreEqual("11.00", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region REG
        [TestMethod]
        public void FMUC0052_REG0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM1162_FM2442_FM2443_FM2444_FM2447_FM2445_FM2446_ES10895: 1:Survey 2:Required Data 3:Display Payment Details 4:Display Check Details 4:Enter Survey Details 5:Enter Charges 6:Display Check Amounts 7:Enter GFE Amounts for";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set an instance for Survey Details.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Enter payment details for SURVEY.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("Sanity-SURVEY");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("7.99");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("7.99");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Payment Details.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Verify payment details for SURVEY.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Sanity-SURVEY", FastDriver.PaymentDetailsDlg.DESCRPTION.FAGetValue(), "Verify description field value");
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Clean(), "Verify Buyer Charge field value");
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Clean(), "Verify Seller Charge field value");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Check Details.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.CheckDetails.FAClick();

                Reports.TestStep = "Edit Description for Utility.";
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.CheckDetailsDlg.Description.FASetText("Description for Survey Company Regression");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Check Voucher info for Survey Company Regression");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.CheckDetails.FAClick();
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Description for Survey Company Regression", FastDriver.CheckDetailsDlg.Description.FAGetValue().Clean(), "Verify Description field value");
                Support.AreEqual("Check Voucher info for Survey Company Regression", FastDriver.CheckDetailsDlg.VoucherInfo.FAGetValue().Clean(), "Verify Voucher Info field value");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Find To enter Gab from Address Book Search Dialog.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "Set an Homeowner Association id from Global address book.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.IDCode.FASetText("HOA1");
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.SearchResultsRadio);
                FastDriver.AddressBookSearchDlg.SearchResultsRadio.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Enter the details note.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.SurveyDetails.Click();
                FastDriver.SurveyDetail.SurveyDetails.FASetText("survey Details" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the details note.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("survey Details", FastDriver.SurveyDetail.SurveyDetails.FAGetValue().Clean(), "Verify Survey Details field value");

                Reports.TestStep = "Enter Borrower and GFE Charges and Verify for Check Amount.";
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("2nd Instance");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01");
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01" + FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 21.02", FastDriver.SurveyDetail.CheckAmount.Text.Clean(), "Verify Check Amount field text");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_REG0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "EWC1_EWC3_EWC4_EWC5_EWC7: 1:User deletes a charge process instance that has issued checks. 2:User tries to delete a charge description that has a charge amount 3:User tries to decrease or delete a charge amount with paym";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set an instance for Survey Details with charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00");

                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Perform Print.";
                FastDriver.PrintDlg.SelectPrinter("TEXT_FILE_PRINTER").Print.FAClick();
                FastDriver.PasswordConfirmationDlg.EnterOverdraftReason();
                FastDriver.WebDriver.WaitForDeliveryWindow(timeoutSeconds: 200);

                Reports.TestStep = "Navigate to Survey screen and delete.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();

                Reports.TestStep = "Delete The Payee have Issued Instance.";
                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Click on Find To enter Gab from Address Book Search Dialog.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "Change Payee To whom check issued.";
                Support.AreEqual(@"A check has been issued for this Payee. The Payee name cannot be changed.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Delete Charge Description Having Charges.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText(FAKeys.Tab);

                Reports.TestStep = "Delete Charge Description.";
                Support.AreEqual(@"Unable to delete charge description. Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter Less Amount Than Issued Amount.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1.11" + FAKeys.Tab);

                Reports.TestStep = "Enter Less Than the issued Amount.";
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?".Clean(), FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean());

                Reports.TestStep = "Enter Greater Amount Than Issued Amount.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("50.55" + FAKeys.Tab);

                Reports.TestStep = "Enter Greater Than the Issued Amount.";
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?".Clean(), FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "EWC2_EWC6_EWC8_EWC12_EWC13_EWC14_EWC15: 1:User deletes a charge process instance that does not have issued checks. 2:User searches for a business party on ID Code and system does not find an exact match. 3:User cancels e";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Invalid GAB.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("XCHZ");
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "ID Code Not Found.";
                Support.AreEqual(@"ID Code not found.", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Edit the instance and save the changes made.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("Changed Desc" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.00" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.00" + FAKeys.Tab);

                Reports.TestStep = "Save Changes without Bus Party.";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual(@"Error(s) occured. See Message pane.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Set an instance for Survey Details with Reference No and charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.Reference.FASetText("935525425" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("200" + FAKeys.Tab);

                Reports.TestStep = "Cancel.";
                FastDriver.BottomFrame.Cancel();
                Support.AreEqual(@"Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Set an instance for Survey Details with Reference No and charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.Reference.FASetText("935525425" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("200" + FAKeys.Tab);

                Reports.TestStep = "Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Modify GAB id for Instance Having Reference No.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("SURVEY");
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "Change Business Party have Ref No.";
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number. Do you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Enter Invalid Email ID.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.Edit.FASetCheckbox(true);
                FastDriver.SurveyDetail.EmailAddress.FASetText("Test.com" + FAKeys.Tab);

                Reports.TestStep = "Invalid Email Address.";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual(@"Please correct invalid data entered.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Check Edit Name Check Box.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.EditName.FASetCheckbox(true);

                Reports.TestStep = "Enter Contact when Edit Name is checked.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual(@"Name field is required when Edit Name checkbox is selected.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.SurveyDetail.SwitchToContentFrame();
                FastDriver.SurveyDetail.EditName.FASetCheckbox(false);

                Reports.TestStep = "Delete the Survey Payee not have Issued Checks.";
                FastDriver.BottomFrame.Delete();
                Support.AreEqual(@"All information will be removed for this Survey. Continue?", FastDriver.WebDriver.HandleDialogMessage().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "EWC9_EWC10_EWC11: 1:User cancels entry of the SECOND instance using Cancel button on framework before saving a new process instance. 2:User cancels entry of the THIRD or Subsequent new instance using Cancel button on fra";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set an instance for Survey Details with Reference No and charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.Reference.FASetText("935525425" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("200" + FAKeys.Tab);

                Reports.TestStep = "Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "New.";
                FastDriver.BottomFrame.New();
                FastDriver.SurveyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Cancel.";
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Cancel without save changes.";
                Support.AreEqual(@"Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Creation of 2nd instance.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("2nd Instance" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancellation of 3nd instance.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.New.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("hudflinsr1");
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("3rd Instance" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("10.01" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("11.01" + FAKeys.Tab);
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Cancel without save changes.";
                Support.AreEqual(@"Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Select instance from summary screen and edit.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Flood Insurance 1 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.SurveySummary.Edit.FAClick();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select instance from summary screen and delete the instance.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Flood Insurance 1 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.SurveySummary.Remove.FAClick();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify for Available Instance.";
                FastDriver.SurveySummary.WaitForScreenToLoad();
                FastDriver.SurveySummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_REG0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FD: Field Definitions";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("HUDFLINSR");
                Support.AreEqual("HUDFLINSR", FastDriver.SurveyDetail.GABcode.FAGetValue().Clean());
                FastDriver.SurveyDetail.GABName.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789");
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ123456789", FastDriver.SurveyDetail.GABName.FAGetValue().Clean());
                FastDriver.SurveyDetail.Edit.FASetCheckbox(true);
                FastDriver.SurveyDetail.BusinessPhone.FASetText("123456789" + FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.SurveyDetail.BusinessPhone.FAGetValue().Clean());
                FastDriver.SurveyDetail.BusinessFax.FASetText("123456789" + FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.SurveyDetail.BusinessFax.FAGetValue().Clean());
                FastDriver.SurveyDetail.CellPhone.FASetText("123456789" + FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.SurveyDetail.CellPhone.FAGetValue().Clean());
                FastDriver.SurveyDetail.Pager.FASetText("123456789" + FAKeys.Tab);
                Support.AreEqual("(???)???-????", FastDriver.SurveyDetail.Pager.FAGetValue().Clean());
                FastDriver.SurveyDetail.EmailAddress.FASetText("test.test" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.SurveyDetail.EmailAddress.FAGetValue().Clean());
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.EditName.FASetCheckbox(true);
                FastDriver.SurveyDetail.Name.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH123456", FastDriver.SurveyDetail.Name.FAGetValue().Clean());
                FastDriver.SurveyDetail.Reference.FASetText("0123456789012345678901234567890123456789012345678" + FAKeys.Tab);
                Support.AreEqual("0123456789012345678901234567890123456789012345678", FastDriver.SurveyDetail.Reference.FAGetValue().Clean());
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with Exact Value.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("HUDFLINSR");
                Support.AreEqual("HUDFLINSR", FastDriver.SurveyDetail.GABcode.FAGetValue().Clean());
                FastDriver.SurveyDetail.GABName.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890");
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.SurveyDetail.GABName.FAGetValue().Clean());
                FastDriver.SurveyDetail.Edit.FASetCheckbox(true);
                FastDriver.SurveyDetail.BusinessPhone.FASetText("1234567899" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.SurveyDetail.BusinessPhone.FAGetValue().Clean());
                FastDriver.SurveyDetail.BusinessFax.FASetText("1234567899" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.SurveyDetail.BusinessFax.FAGetValue().Clean());
                FastDriver.SurveyDetail.CellPhone.FASetText("1234567899" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.SurveyDetail.CellPhone.FAGetValue().Clean());
                FastDriver.SurveyDetail.Pager.FASetText("1234567899" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.SurveyDetail.Pager.FAGetValue().Clean());
                FastDriver.SurveyDetail.EmailAddress.FASetText("test@test.com" + FAKeys.Tab);
                Support.AreEqual("test@test.com", FastDriver.SurveyDetail.EmailAddress.FAGetValue().Clean());
                FastDriver.SurveyDetail.EditName.FASetCheckbox(true);
                FastDriver.SurveyDetail.Name.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.SurveyDetail.Name.FAGetValue().Clean());
                FastDriver.SurveyDetail.Reference.FASetText("01234567890123456789012345678901234567890123456789" + FAKeys.Tab);
                Support.AreEqual("01234567890123456789012345678901234567890123456789", FastDriver.SurveyDetail.Reference.FAGetValue().Clean());
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with Upper Boundary Value.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("HUDFLINSR12");
                Support.AreEqual("HUDFLINSR1", FastDriver.SurveyDetail.GABcode.FAGetValue().Clean());
                FastDriver.SurveyDetail.GABName.FASetText("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ12345678901");
                Support.AreEqual("ABCDEFGHIJABCDEFGHIJABCDEFGHIJ1234567890", FastDriver.SurveyDetail.GABName.FAGetValue().Clean());
                FastDriver.SurveyDetail.Edit.FASetCheckbox(true);
                FastDriver.SurveyDetail.BusinessPhone.FASetText("12345678999" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.SurveyDetail.BusinessPhone.FAGetValue().Clean());
                FastDriver.SurveyDetail.BusinessFax.FASetText("12345678999" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.SurveyDetail.BusinessFax.FAGetValue().Clean());
                FastDriver.SurveyDetail.CellPhone.FASetText("12345678999" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.SurveyDetail.CellPhone.FAGetValue().Clean());
                FastDriver.SurveyDetail.Pager.FASetText("12345678999" + FAKeys.Tab);
                Support.AreEqual("(123)456-7899", FastDriver.SurveyDetail.Pager.FAGetValue().Clean());
                FastDriver.SurveyDetail.EmailAddress.FASetText("test@test.com" + FAKeys.Tab);
                Support.AreEqual("test@test.com", FastDriver.SurveyDetail.EmailAddress.FAGetValue().Clean());
                FastDriver.SurveyDetail.EditName.FASetCheckbox(true);
                FastDriver.SurveyDetail.Name.FASetText("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH12345678ABCDEFGH1234567", FastDriver.SurveyDetail.Name.FAGetValue().Clean());
                FastDriver.SurveyDetail.Reference.FASetText("012345678901234567890123456789012345678901234567890" + FAKeys.Tab);
                Support.AreEqual("01234567890123456789012345678901234567890123456789", FastDriver.SurveyDetail.Reference.FAGetValue().Clean());
                FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.SurveyDetail.BorrowerSelectedServicesDescription.FAGetValue().Clean());
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("1000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "0" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FAGetValue().Clean());
                FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FASetText("1000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "0" + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.SurveyDetail.BorrowerSelectedServicesSellerCharge.FAGetValue().Clean());
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0052_REG0006()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Test Case Description";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set an instance for Survey Details with Reference No and charge amount entered.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.FindGABCode("247");
                FastDriver.SurveyDetail.Reference.FASetText("935525425" + FAKeys.Tab);
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("200" + FAKeys.Tab);

                Reports.TestStep = "Navigate to Survey & enter GAB.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("247");
                FastDriver.SurveyDetail.Find.FAClick();

                Reports.TestStep = "Change Business Party have Ref No.";
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number. Do you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Verify that system retains the Refrence Number.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("935525425", FastDriver.SurveyDetail.Reference.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete the refrence Number.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.Reference.FASetText(FAKeys.Tab);

                Reports.TestStep = "Verify that Refrence Number is deleted and reset.";
                Support.AreEqual("", FastDriver.SurveyDetail.Reference.FAGetValue().Clean());
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Cancel without saving changes.";
                Support.AreEqual(@"Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Verify that system retains the Refrence Number.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual("935525425", FastDriver.SurveyDetail.Reference.FAGetValue().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Selecting attention Field.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>("Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.Attention.FASelectItemByIndex(1);
                string SurveyAttentionValue = FastDriver.SurveyDetail.Attention.FAGetSelectedItem().Clean();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Survey Sequence Number. Note: If fails, please verify screenshots for sequence number.";
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                Support.AreEqual(SurveyAttentionValue, FastDriver.SurveyDetail.Attention.FAGetSelectedItem().Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}