﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpers;

namespace EscrowChargeProcess
{
     /// <summary>
    /// Summary description for FMUC0040_Attorney
    /// </summary>
    [CodedUITest]
    public class FMUC0040_Attorney : MasterTestClass
    {
        public FMUC0040_Attorney(){ }

        #region BAT

        [TestMethod]
        [Description("Create Attorney Buyer and Add Second - Subsequent Attorney from Detail.")]
        public void FMUC0040_BAT0001()
        {

            try
            {
                Reports.TestDescription = "MF1_AF2: Create Attorney Buyer and Add Second - Subsequent Attorney from Detail.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create the Attorney
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "50.00", SellerCharge: "50.00", ExpectedAmount: "$ 100.00", GabCode: "HUDBUYATT1");
                #endregion

                #region Create the 2ndInstance Attorney. 
                Reports.TestStep = "Create the 2ndInstance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Add Second-Subsequent Attorney from Summary.")]
        public void FMUC0040_BAT0002()
        {

            try
            {
                Reports.TestDescription = "AF1: Add Second-Subsequent Attorney from Summary.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create the Attorney
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "50.00", SellerCharge: "50.00", ExpectedAmount: "$ 100.00", GabCode: "HUDBUYATT1");
                #endregion

                #region Create the 2ndInstance Attorney.
                Reports.TestStep = "Create the 2ndInstance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Create the 3ndInstance Attorney.
                Reports.TestStep = "Create the 3ndInstance Attorney.";
                FastDriver.AttorneySummary.New.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge:"150.00", SellerCharge:"150.00", ExpectedAmount:"$ 300.00",GabCode:"HUDBUYATT3");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Edit Attorney Information.")]
        public void FMUC0040_BAT0003()
        {

            try
            {
                Reports.TestDescription = "AF3: Edit Attorney Information.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create the Attorney
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "50.00", SellerCharge: "50.00", ExpectedAmount: "$ 100.00", GabCode: "HUDBUYATT1");
                #endregion

                #region Create the 2ndInstance Attorney.
                Reports.TestStep = "Create the 2ndInstance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Create the 3ndInstance Attorney.
                Reports.TestStep = "Create the 3ndInstance Attorney.";
                FastDriver.AttorneySummary.New.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "150.00", SellerCharge: "150.00", ExpectedAmount: "$ 300.00", GabCode: "HUDBUYATT3");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Select Instance, Click on Edit and Edit the Buyer and Seller Charge.
                Reports.TestStep = "Select Instance, Click on Edit and Edit the Buyer and Seller Charge.";
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 3 for HUD Test Name 1",1,TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "50.00");
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "50.00");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                #endregion

                #region Select Instance, Click on Edit and Verify the Buyer and Seller Charge.
                Reports.TestStep = "Select Instance, Click on Edit and Verify the Buyer and Seller Charge.";
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 3 for HUD Test Name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Support.AreEqual("50.00", GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));
                Support.AreEqual("50.00", GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));

                Support.AreEqual("$ 100.00", FastDriver.AttorneyDetail.TotalCharges.Text);
                Support.AreEqual("$ 100.00", FastDriver.AttorneyDetail.NetcheckAmount.Text);
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Delete an Attorney.")]
        public void FMUC0040_BAT0004()
        {

            try
            {
                Reports.TestDescription = "AF4: Delete an Attorney.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create the Attorney
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "50.00", SellerCharge: "50.00", ExpectedAmount: "$ 100.00", GabCode: "HUDBUYATT1");
                #endregion

                #region Create the 2ndInstance Attorney.
                Reports.TestStep = "Create the 2ndInstance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Create the 3ndInstance Attorney.
                Reports.TestStep = "Create the 3ndInstance Attorney.";
                FastDriver.AttorneySummary.New.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "150.00", SellerCharge: "150.00", ExpectedAmount: "$ 300.00", GabCode: "HUDBUYATT3");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Remove the Instance.
                Reports.TestStep = "Remove the Instance.";
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 3 for HUD Test Name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Available", 1, TableAction.Click);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Cancel 1st New Attorney Instance Creation.")]
        public void FMUC0040_BAT0005()
        {

            try
            {
                Reports.TestDescription = "AF5: Cancel 1st New Attorney Instance Creation.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Cancel 1st Attorney.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Cancel the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.GABcode.FASetText("HUDBUYATT1");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneyDetail.Type.FASelectItem("Attorney- Primary");

                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "50.00");
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "50.00");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Navigate Buyer's  Attoyney and Create 1st Attorney.
                Reports.TestStep = " Navigate Buyer's  Attoyney and Create 1st Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "50.00", SellerCharge: "50.00", ExpectedAmount: "$ 100.00", GabCode: "HUDBUYATT1");
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Cancel 2nd New Attorney Instance Creation.")]
        public void FMUC0040_BAT0006()
        {

            try
            {
                Reports.TestDescription = "AF6: Cancel 2nd New Attorney Instance Creation.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create the Attorney
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "50.00", SellerCharge: "50.00", ExpectedAmount: "$ 100.00", GabCode: "HUDBUYATT1");
                #endregion

                #region Cancel the 2nd Instance Attorney.
                Reports.TestStep = "Cancel the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Cancel rd New Attorney Instance Creation.")]
        public void FMUC0040_BAT0007()
        {

            try
            {
                Reports.TestDescription = "AF7: Cancel 3rd Subsequent New Attorney Instance Creation.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create the Attorney
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "50.00", SellerCharge: "50.00", ExpectedAmount: "$ 100.00", GabCode: "HUDBUYATT1");
                #endregion
                              
                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                #endregion

                #region Cancel the 3rd Instance Attorney.
                Reports.TestStep = "Cancel the 3rd instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "150.00", SellerCharge: "150.00", ExpectedAmount: "$ 300.00", GabCode: "HUDBUYATT3");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                #endregion

                #region Cancel the 3rd Instance Attorney.
                Reports.TestStep = "Cancel the 3rd instance Attorney.";
                FastDriver.AttorneySummary.New.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "150.00", SellerCharge: "150.00", ExpectedAmount: "$ 300.00", GabCode: "HUDBUYATT3");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        [Description("Cancel Changes to Exist Attorney Instance.")]
        public void FMUC0040_BAT0008()
        {

            try
            {
                Reports.TestDescription = "AF8: Cancel Changes to Exist Attorney Instance.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create the Attorney
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create the Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "50.00", SellerCharge: "50.00", ExpectedAmount: "$ 100.00", GabCode: "HUDBUYATT1");
                #endregion

                #region Create the 2ndInstance Attorney.
                Reports.TestStep = "Create the 2ndInstance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Create the 3ndInstance Attorney.
                Reports.TestStep = "Create the 3ndInstance Attorney.";
                FastDriver.AttorneySummary.New.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "150.00", SellerCharge: "150.00", ExpectedAmount: "$ 300.00", GabCode: "HUDBUYATT3");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Select Instance and Click on Edit.
                Reports.TestStep = "Select Instance, Click on Edit and Verify the Buyer and Seller Charge.";
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 3 for HUD Test Name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
            
                #endregion

                #region Cancel de Edited instance
                Reports.TestStep = "Cancel the Edited Instance.";
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee","50.00");
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "50.00");
                FastDriver.AttorneyDetail.GABcode.SendKeys(FAKeys.Tab);

                Support.AreEqual("$ 100.00", FastDriver.AttorneyDetail.TotalCharges.Text);
                Support.AreEqual("$ 100.00", FastDriver.AttorneyDetail.NetcheckAmount.Text);
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                #endregion

                #region Verify the Created Attorney
                Reports.TestStep = "Verify the Created Attorney.";

                Support.AreEqual("Attorney- Primary", FastDriver.AttorneyDetail.Type.FAGetSelectedItem());
                Support.AreEqual("150.00", GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));
                Support.AreEqual("150.00", GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));

                Support.AreEqual("$ 300.00", FastDriver.AttorneyDetail.TotalCharges.Text);
                Support.AreEqual("$ 300.00", FastDriver.AttorneyDetail.NetcheckAmount.Text);

                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region REGRESSION

        [TestMethod]
        [Description("User cancels entry of the First instance for Buyer attorney and seller attorney us Cancel button on framework before save a new process instance.")]
        public void FMUC0040_REG0001()
        {

            try
            {
                Reports.TestDescription = "FM968_FM2111_EWC6_EWC8_EWC12_ES10918_ES10920: User cancels entry of the First instance for Buyer attorney and seller attorney us Cancel button on framework before save a new process instance.";
              
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create Attorney-Enter INVALID DATA in GAB Code.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create Attorney-Enter INVALID DATA in GAB Code.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.GABcode.FASetText("INVALID_ID");
                FastDriver.AttorneyDetail.Find.FAClick();

                Reports.TestStep = "ID Code Not Found.";

                Support.AreEqual("ID Code not found.", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Verify for Attorney Screen Load
                Reports.TestStep = "Verify for Attorney Screen Load.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Support.AreEqual("", FastDriver.AttorneyDetail.GABcode.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.BusPhone.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.BusFax.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.Pager.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.EmailAddress.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.NameEdit.FAGetValue());
                Support.AreEqual("Attorney- Primary", FastDriver.AttorneyDetail.Type.FAGetSelectedItem());

                Support.AreEqual("", GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));
                Support.AreEqual("", GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));

                FastDriver.AttorneyDetail.Name.FASetText("TEST" + Keys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneyDetail.Name.FASetText("" + Keys.Tab);
                #endregion

                #region Create Attorney with Valid Data ,Click on Cancel.
                Reports.TestStep = "Create Attorney with Valid Data ,Click on Cancel.";

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Support.AreEqual("BusOrgID: Business Party required",FastDriver.AttorneyDetail.ErrorList.Text);

                CreateAttorney(BuyerCharge: "10.1", SellerCharge: "20.2", GabCode: "ATTBUY3");
                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());
                #endregion

                #region Navigate Buyer's  Attoyney and Create Buyer Attorney with Valid Data, Click on Done.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create Buyer Attorney with Valid Data, Click on Done.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                string AttorneyName = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName.Text + " " +FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName1.Text;
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate Buyer's  Attoyney and Calculate Buyer Title Services and Lender's Title Insurance and Include POC charges.
                Reports.TestStep = @"Navigate Buyer's  Attoyney and Calculate Buyer Title Services and Lender's Title Insurance and Include POC charges";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                if (_GetCurrentFileFormType() == FormType.CD)
                {
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.Clear();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("10.10");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                }
                else {
                    Support.AreEqual("10.10", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("POC");
                }

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.BottomFrame.Done();
                
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();

                if (_GetCurrentFileFormType() == FormType.CD){
                    FastDriver.ViewSettlementStatement.MiscTable.PerformTableAction(3, "Attorney Fee to " + AttorneyName + "    POC $10.10", 3, TableAction.Click);                
                }else{
                    FastDriver.ViewSettlementStatement.ViewSettlementStatmentTable.PerformTableAction(3, "Attorney Fee to " + AttorneyName + "    POC $10.10", 3, TableAction.Click);                
                }
                #endregion

                #region Navigate Seller's  Attoyney and Create Attorney-Enter INVALID DATA in GAB Code.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create Attorney-Enter INVALID DATA in GAB Code.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.GABcode.FASetText("INVALID_ID");
                FastDriver.AttorneyDetail.Find.FAClick();

                Reports.TestStep = "ID Code Not Found.";

                Support.AreEqual("ID Code not found.", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Verify for Attorney Screen Load
                Reports.TestStep = "Verify for Attorney Screen Load.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Support.AreEqual("", FastDriver.AttorneyDetail.GABcode.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.BusPhone.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.BusFax.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.Pager.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.EmailAddress.FAGetValue());
                Support.AreEqual("", FastDriver.AttorneyDetail.NameEdit.FAGetValue());
                Support.AreEqual("Attorney- Primary", FastDriver.AttorneyDetail.Type.FAGetSelectedItem());

                Support.AreEqual("", GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));
                Support.AreEqual("", GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));

                FastDriver.AttorneyDetail.Name.FASetText("TEST" + Keys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneyDetail.Name.FASetText("" + Keys.Tab);
                #endregion

                #region Create Attorney with Valid Data ,Click on Cancel.
                Reports.TestStep = "Create Attorney with Valid Data ,Click on Cancel.";

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Support.AreEqual("BusOrgID: Business Party required", FastDriver.AttorneyDetail.ErrorList.Text);

                CreateAttorney(BuyerCharge: "10.1", SellerCharge: "20.2", GabCode: "ATTBUY3");
                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());
                #endregion

                #region Navigate Seller's  Attoyney and Create Buyer Attorney with Valid Data, Click on Done.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create Buyer Attorney with Valid Data, Click on Done.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion
            
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("User cancels entry of the First instance for Buyer attorney and seller attorney us Cancel button on framework before save a new process instance.")]
        public void FMUC0040_REG0002()
        {

            try
            {
                Reports.TestDescription = "FM968_FM2111_EWC6_EWC8_EWC12_ES10918_ES10920: User cancels entry of the First instance for Buyer attorney and seller attorney us Cancel button on framework before save a new process instance.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
               
                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate Seller's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                
                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance by Clicking on New-Buyer's Attorney.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance by Clicking on New-Buyer's Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "SELLERTS01");

                Reports.TestStep = "Cancel without save changes.";
                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?",FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false));

                Reports.TestStep = "Cancel without save changes.";
                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Create second instance.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.GABcode.FASetText("SELLERTS01");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate Seller's  Attoyney and Create an Attorney Instance by Clicking on New-Buyer's Attorney.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create an Attorney Instance by Clicking on New-Buyer's Attorney.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "SELLERTS01");

                Reports.TestStep = "Cancel without save changes.";
                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));

                Reports.TestStep = "Cancel without save changes.";
                FastDriver.BottomFrame.Cancel();
                Support.AreEqual("Cancel without saving changes?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Create second instance.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.GABcode.FASetText("SELLERTS01");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("Reduce Total Charges by Earnest Money Amount for Buyer Attorney and Seller Attorney.")]
        public void FMUC0040_REG0003()
        {

            try
            {
                Reports.TestDescription = "FM2134_FM2135_FM2137: Reduce Total Charges by Earnest Money Amount for Buyer Attorney and Seller Attorney.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate Seller's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Deposit Outside Escrow and Enter Attorney's Amount for Buyer and Seller.
                Reports.TestStep = "Navigate to Deposit Outside Escrow and Enter Attorney's Amount for Buyer and Seller.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();

                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("20.20");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Buyer's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("10.10");

                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem("Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText("10.10");

                FastDriver.BottomFrame.Save();
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();
                #endregion
                
                #region Navigate Buyer's  Attoyney and Verify Values.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Verify Values";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Att Buy 3 name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();


                #endregion

                #region Navigate Seller's  Attoyney and Verify Values.
                Reports.TestStep = "Navigate Seller's  Attoyney and Verify Values";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Att Buy 3 name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                #endregion


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("User deletes a charge process instance that have issued checks.")]
        public void FMUC0040_REG0004()
        {

            try
            {
                Reports.TestDescription = "EWC2_EWC1: User deletes a charge process instance that have issued checks.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate Seller's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Deposit Outside Escrow and Enter Attorney's Amount for Buyer and Seller.
                Reports.TestStep = "Navigate to Deposit Outside Escrow and Enter Attorney's Amount for Buyer and Seller.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();

                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("20.20");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Buyer's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("10.10");

                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem("Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText("10.10");

                FastDriver.BottomFrame.Save();
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();
                #endregion

                #region Navigate to Active Disbursement Summary and Print All Checks.
                Reports.TestStep = "Navigate to Active Disbursement Summary and Print All Checks.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();


                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();


                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);


                #endregion

                #region Navigate Buyer's  Attoyney, Select instance and click on Delete-Buyer.
                Reports.TestStep = " Navigate Buyer's  Attoyney, Select instance and click on Delete-Buyer";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Att Buy 3 name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Remove.FAClick();

                Reports.TestStep = "A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee. Cancel.";
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));

                Reports.TestStep = " Navigate Buyer's  Attoyney, Select instance and click on Delete-Buyer";
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 2 for HUD Test Name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Remove.FAClick();

                Reports.TestStep = "A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee. Cancel.";
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                #endregion


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("Verifying error message When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.")]
        public void FMUC0040_REG0005()
        {

            try
            {
                Reports.TestDescription = "EWC13: Verifying error message When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate Seller's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Deposit Outside Escrow and Enter Attorney's Amount for Buyer and Seller.
                Reports.TestStep = "Navigate to Deposit Outside Escrow and Enter Attorney's Amount for Buyer and Seller.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();

                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("20.20");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Buyer's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("10.10");

                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem("Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText("10.10");

                FastDriver.BottomFrame.Save();
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();
                #endregion

                #region Navigate to Active Disbursement Summary and Print All Checks.
                Reports.TestStep = "Navigate to Active Disbursement Summary and Print All Checks.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();


                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();


                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);


                #endregion

                #region Navigate Buyer's  Attoyney and Click New and Edit Name.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Click New and Edit Name.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.New.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.GABcode.FASetText("HUDFLINSR1");
                FastDriver.AttorneyDetail.Find.FAClick();

                if (!FastDriver.AttorneyDetail.EditName.Selected)
                {
                    FastDriver.AttorneyDetail.EditName.FAClick();
                }

                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Name field is required when Edit Name checkbox is selected.";
                Support.AreEqual("Name field is required when Edit Name checkbox is selected.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Enter name in Edit Name Text Box.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.NameEdit.FASetText("Edit Name");
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "10.01");
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "20.02");
                FastDriver.AttorneyDetail.NameEdit.SendKeys(FAKeys.Tab);

                if (_GetCurrentFileFormType() == FormType.CD)
                {
                    SetDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "", "DescriptionChanged" + FAKeys.Tab);
                }
                else {
                   FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction(3,1,TableAction.SetText, "DescriptionChanged" + FAKeys.Tab);
                }


                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "DescriptionChanged", "30.03");
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "DescriptionChanged", "40.04");

                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate Seller's  Attoyney and Click New and Edit Name.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Click New and Edit Name.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.New.FAClick();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.GABcode.FASetText("HUDFLINSR1");
                FastDriver.AttorneyDetail.Find.FAClick();

                if (!FastDriver.AttorneyDetail.EditName.Selected)
                {
                    FastDriver.AttorneyDetail.EditName.FAClick();
                }

                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Name field is required when Edit Name checkbox is selected.";
                Support.AreEqual("Name field is required when Edit Name checkbox is selected.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Enter name in Edit Name Text Box.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.NameEdit.FASetText("Edit Name");
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "10.01");
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "20.02");
                FastDriver.AttorneyDetail.NameEdit.SendKeys(FAKeys.Tab);


                if (_GetCurrentFileFormType() == FormType.CD)
                {
                    SetDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "", "DescriptionChanged" + FAKeys.Tab);
                }
                else
                {
                    FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction(3, 1, TableAction.SetText, "Description" + FAKeys.Tab);
                }
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "DescriptionChanged", "30.03");
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "DescriptionChanged", "40.04");
                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
                
        [TestMethod]
        [Description("The business party is a payee on an issued check and user tries to edit or replace it with another business party.")]
        public void FMUC0040_REG0006()
        {

            try
            {
                Reports.TestDescription = "EWC7_EWC4_EWC5: The business party is a payee on an issued check and user tries to edit or replace it with another business party.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate Seller's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Deposit Outside Escrow and Enter Attorney's Amount for Buyer and Seller.
                Reports.TestStep = "Navigate to Deposit Outside Escrow and Enter Attorney's Amount for Buyer and Seller.";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();

                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("20.20");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Buyer's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("10.10");

                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem("Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText("10.10");

                FastDriver.BottomFrame.Save();
                FastDriver.DepositOutsideEscrow.WaitForScreenToLoad();
                #endregion

                #region Navigate to Active Disbursement Summary and Print All Checks.
                Reports.TestStep = "Navigate to Active Disbursement Summary and Print All Checks.";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();


                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.SwitchToContentFrame();
                FastDriver.PrintChecks.Deliver.FAClick();


                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);


                #endregion

                #region Navigate to Attorney Summary-Buyer screen and Select First Instance.

                Reports.TestStep = "Navigate to Attorney Summary-Buyer screen and Select First Instance.";

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Att Buy 3 name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();

                Reports.TestStep = "Verify for the Issue check Image on Attorney Buyer Screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Support.AreEqual(true.ToString(),FastDriver.AttorneyDetail.Issuedcheckimage.Displayed.ToString());

                Reports.TestStep = "Edit created instance for which check is already issue.";
                FastDriver.AttorneyDetail.GABcode.FASetText("HUDFLINSR1");
                FastDriver.AttorneyDetail.Find.FAClick();

                Reports.TestStep = "A check has been issued for this Payee. The Payee name cannot be changed.";

                string EditedAttorneyMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(true.ToString(), EditedAttorneyMessage.Contains("A check has been issued for this Payee.").ToString());
                Support.AreEqual(true.ToString(), EditedAttorneyMessage.Contains("The Payee name cannot be changed.").ToString());

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File be out-of-balance. Do you wish to save the changes?.";
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "5.00");
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Contains("The effect of your changes may result in a check amount that is LESS than the charge total").ToString());

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File be out-of-balance. Do you wish to save the changes?.";
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "5.00");
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage().Contains("The effect of your changes may result in a check amount that is LESS than the charge total").ToString());

                Reports.TestStep = "Change Buyer Charge amount enter Greater then before.";

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "95.00");
               
                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?.";
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Contains("The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance.").ToString());
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "95.00");

                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?.";
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage().Contains("The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance.").ToString());
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                #endregion

                #region Navigate to Attorney Summary-Buyer screen and Select First Instance.

                Reports.TestStep = "Navigate to Attorney Summary-Buyer screen and Select First Instance.";

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Att Buy 3 name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();

                Reports.TestStep = "Verify for the Issue check Image on Attorney Buyer Screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.AttorneyDetail.Issuedcheckimage.Displayed.ToString());

                Reports.TestStep = "Edit created instance for which check is already issue.";
                FastDriver.AttorneyDetail.GABcode.FASetText("HUDFLINSR1");
                FastDriver.AttorneyDetail.Find.FAClick();

                Reports.TestStep = "A check has been issued for this Payee. The Payee name cannot be changed.";

                EditedAttorneyMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(true.ToString(), EditedAttorneyMessage.Contains("A check has been issued for this Payee.").ToString());
                Support.AreEqual(true.ToString(), EditedAttorneyMessage.Contains("The Payee name cannot be changed.").ToString());

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File be out-of-balance. Do you wish to save the changes?.";
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "5.00");
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Contains("The effect of your changes may result in a check amount that is LESS than the charge total").ToString());

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File be out-of-balance. Do you wish to save the changes?.";
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "5.00");
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage().Contains("The effect of your changes may result in a check amount that is LESS than the charge total").ToString());

                Reports.TestStep = "Change Buyer Charge amount enter Greater then before.";

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "95.00");

                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?.";
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false).Contains("The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance.").ToString());

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "95.00");

                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?.";
                Support.AreEqual(true.ToString(), FastDriver.WebDriver.HandleDialogMessage().Contains("The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance.").ToString());

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("When the user enters an invalid e-Mail address.")]
        public void FMUC0040_REG0007()
        {

            try
            {
                Reports.TestDescription = "EWC14_EWC11: When the user enters an invalid e-Mail address.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate Seller's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Attorney Summary-Buyer screen, Select First Instance and Verify Correct Email format

                Reports.TestStep = "Navigate to Attorney Summary-Buyer screen, Select First Instance and Verify Correct Email format.";

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Att Buy 3 name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();

                Reports.TestStep = "Verifying for Correct Email format on Attorney Screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                if (!FastDriver.AttorneyDetail.Edit.Selected)
                {
                    FastDriver.AttorneyDetail.Edit.FAClick();
                }

                FastDriver.AttorneyDetail.EmailAddress.FASetText("wrongemail@wrong.4");
                Reports.TestStep = "Invalid Email Address.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual(@"Please correct invalid data entered.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false);
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Attorney Summary-Seller screen, Select First Instance and Verify Correct Email format

                Reports.TestStep = "Navigate to Attorney Summary-Seller screen, Select First Instance and Verify Correct Email format.";

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Att Buy 3 name 1", 1, TableAction.Click);
                FastDriver.AttorneySummary.Edit.FAClick();

                Reports.TestStep = "Verifying for Correct Email format on Attorney Screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                if (!FastDriver.AttorneyDetail.Edit.Selected)
                {
                    FastDriver.AttorneyDetail.Edit.FAClick();
                }

                FastDriver.AttorneyDetail.EmailAddress.FASetText("wrongemail@wrong.4");
                Reports.TestStep = "Invalid Email Address.";
                FastDriver.BottomFrame.Done();
                Support.AreEqual(@"Please correct invalid data entered.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                #endregion


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("User tries to delete a charge description that has a charge amount.")]
        public void FMUC0040_REG0008()
        {

            try
            {
                Reports.TestDescription = "EWC3: User tries to delete a charge description that has a charge amount.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                if (_GetCurrentFileFormType() == FormType.CD)
                {
                Reports.TestStep = "Verifying for the description is required for Charge error.";
                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction(1, "Attorney Fee", 1, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).Clear();
                    FastDriver.AttorneyDetail.GABcode.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Delete Charge Description.";
                    Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                }
                else {
                    Reports.TestStep = "Verifying description is not editable.";
                    Support.AreEqual(false.ToString(), FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction(1, "Attorney Fee", 1, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).IsEnabled().ToString());
                }

                #endregion

              

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        
        [TestMethod]
        [Description("Function to Validate all the Hotkeys related to FMUC0040.")]
        public void FMUC0040_REG0009()
        {

            try
            {
                Reports.TestDescription = "HotKey: Function to Validate all the Hotkeys related to FMUC0040.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate Seller's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Seller's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "10.10", SellerCharge: "20.20", GabCode: "ATTBUY3");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create the 2nd Instance Attorney.
                Reports.TestStep = "Create the 2nd Instance Attorney.";
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                CreateAttorneyAndVerifyValues(BuyerCharge: "100.00", SellerCharge: "100.00", ExpectedAmount: "$ 200.00", GabCode: "HUDBUYATT2");
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Buyer Attorney Summary and Verify all hotkeys

                Reports.TestStep = "Navigate to Buyer Attorney Summary screen and us hotkey ALT+N.";

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneySummary.SwitchToContentFrame();

                Keyboard.SendKeys("%N");

                Reports.TestStep = "Verifying hot Keys ctrl+Q.";
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("^Q");
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Hotkeys CTRL+E.";
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, 2, TableAction.Click);
                Keyboard.SendKeys("%E");

                Reports.TestStep = "New us Shortcut Keys.";
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("^N");
                FastDriver.AttorneyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Verifying for Hot Keys ALT+P.";
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("%P");

                Reports.TestStep = "Enter charges and make payment method as CHK.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                if (_GetCurrentFileFormType() == FormType.CD)
                {
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                FastDriver.PaymentDetailsDlg.BuyerCharge.Clear();
                FastDriver.PaymentDetailsDlg.SellerCharge.Clear();
                FastDriver.PaymentDetailsDlg.BuyerCharge.SendKeys("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.SendKeys("2.60");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("CHK");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItemBySendingKeys("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.60");
                }

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Done us Shortcut Keys.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                Keyboard.SendKeys("^D");

                Reports.TestStep = "Hotkeys CTRL+E.";
                FastDriver.AttorneySummary.WaitForScreenToLoad();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, 2, TableAction.Click);
                Keyboard.SendKeys("%E");

                Reports.TestStep = "Verifying for Hot Keys ALT+P.";
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("%P");

                Reports.TestStep = "Change the payment details method in Homeowner screen.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                if (_GetCurrentFileFormType() == FormType.CD)
                {
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("No Check");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FASelectItemBySendingKeys("No Check");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("POC");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItemBySendingKeys("POC");
                }
              
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verifying for the Pencil Sign.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.AttorneyDetail.PencilImage.Displayed.ToString());
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("^R");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Delete us Shortcut Keys.";
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("^{DELETE}");

                Reports.TestStep = "All information will be removed for this Attorney. Continue? OK.";
                Support.AreEqual("All information will be removed for this Attorney.  Continue?",FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion

                #region Navigate to Seller Attorney Summary and Verify all hotkeys

                Reports.TestStep = "Navigate to Seller Attorney Summary screen and us hotkey ALT+N.";

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneySummary.SwitchToContentFrame();

                Keyboard.SendKeys("%N");

                Reports.TestStep = "Verifying hot Keys ctrl+Q.";
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("^Q");
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Hotkeys CTRL+E.";
                FastDriver.AttorneySummary.SwitchToContentFrame();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, 2, TableAction.Click);
                Keyboard.SendKeys("%E");

                Reports.TestStep = "New us Shortcut Keys.";
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("^N");
                FastDriver.AttorneyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Verifying for Hot Keys ALT+P.";
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("%P");

                Reports.TestStep = "Enter charges and make payment method as CHK.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
               
                if (_GetCurrentFileFormType() == FormType.CD)
                {
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                FastDriver.PaymentDetailsDlg.BuyerCharge.Clear();
                FastDriver.PaymentDetailsDlg.SellerCharge.Clear();
                FastDriver.PaymentDetailsDlg.BuyerCharge.SendKeys("2.50");
                FastDriver.PaymentDetailsDlg.SellerCharge.SendKeys("2.60");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("CHK");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItemBySendingKeys("CHK");
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2.50");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("2.60");
                }
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Done us Shortcut Keys.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                Keyboard.SendKeys("^D");

                Reports.TestStep = "Hotkeys CTRL+E.";
                FastDriver.AttorneySummary.WaitForScreenToLoad();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, 2, TableAction.Click);
                Keyboard.SendKeys("%E");


                Reports.TestStep = "Verifying for Hot Keys ALT+P.";
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("%P");

                Reports.TestStep = "Change the payment details method in Homeowner screen.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                if (_GetCurrentFileFormType() == FormType.CD)
                {
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("No Check");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FASelectItemBySendingKeys("No Check");
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys("POC");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItemBySendingKeys("POC");
                }
               
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verifying for the Pencil Sign.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.AttorneyDetail.PencilImage.Displayed.ToString());
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("^R");

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.AttorneyDetail.WaitForScreenToLoad();

                Reports.TestStep = "Delete us Shortcut Keys.";
                FastDriver.AttorneySummary.SwitchToContentFrame();
                Keyboard.SendKeys("^{DELETE}");

                Reports.TestStep = "All information will be removed for this Attorney. Continue? OK.";
                Support.AreEqual("All information will be removed for this Attorney.  Continue?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AttorneySummary.SwitchToContentFrame();

                #endregion
              

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("Function to Validate all the Dropdowns related to FMUC0040.")]
        public void FMUC0040_REG0010()
        {

            try
            {
                Reports.TestDescription = "DropDowns: Function to Validate all the Dropdowns related to FMUC0040.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Verify.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Verify";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verifying for Attorney type Drop Down Values.";
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneyDetail.WaitForScreenToLoad();

                Support.AreEqual("Attorney- Co-Counsel Attorney- Local Attorney- Primary Lender- Funding Lender- Loan Officer Lender- Mobile Banker Lender- Mortgage Centre Lender- Originating Branch Lender- Processor Lender- Signing Location Misc- Guarantor/Covenantor Misc- Lender Assignment Misc- Lender Policy Misc- Non-Titled Borrower", FastDriver.AttorneyDetail.Type.Text.Trim());
                FastDriver.BottomFrame.Done();

                #endregion
                
                #region Navigate Seller's  Attoyney and Verify.
                Reports.TestStep = "Navigate Seller's  Attoyney and Verify.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Reports.TestStep = "Verifying for Attorney type Drop Down Values.";
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.AttorneyDetail.WaitForScreenToLoad();

                Support.AreEqual("Attorney- Co-Counsel Attorney- Local Attorney- Primary Lender- Funding Lender- Loan Officer Lender- Mobile Banker Lender- Mortgage Centre Lender- Originating Branch Lender- Processor Lender- Signing Location Misc- Guarantor/Covenantor Misc- Lender Assignment Misc- Lender Policy Misc- Non-Titled Borrower", FastDriver.AttorneyDetail.Type.Text.Trim());
                FastDriver.BottomFrame.Done();

                #endregion


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("Verify Error warn on change the GAB CODE after enter Reference code.")]
        public void FMUC0040_REG0011()
        {

            try
            {
                Reports.TestDescription = "EWC15: Verify Error warn on change the GAB CODE after enter Reference code.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Enter Reference number.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Enter Reference number.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.WaitForScreenToLoad();


                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Reference.FASetText("123456789");
                              
                Reports.TestStep = "Enter Gab Code.";
                FastDriver.AttorneyDetail.GABcode.FASetText("Hudflinsr1");
                FastDriver.AttorneyDetail.Find.FAClick();

                Reports.TestStep = "Chang the Business Party will remove reference and loan number Click ok.";

                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AttorneyDetail.WaitForScreenToLoad();

                #endregion

                #region Verifying that system is not change reference number on click on OK.
                Reports.TestStep = "Verifying that system is not change reference number on click on OK.";

                Support.AreEqual(@"123456789", FastDriver.AttorneyDetail.Reference.FAGetValue());
               
                Reports.TestStep = "Enter Gab Code.";
                FastDriver.AttorneyDetail.GABcode.FASetText("Hudflinsr1");
                FastDriver.AttorneyDetail.Find.FAClick();
              
                Reports.TestStep = "Change the Business Party will remove reference and loan number Click cancel.";
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));

                #endregion

                #region Verifying that system is remove the reference number on click on Cancel.
                Reports.TestStep = "Verifying that system is remove the reference number on click on Cancel.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Support.AreEqual("", FastDriver.AttorneyDetail.Reference.FAGetValue());
                
                #endregion

                #region Navigate Seller's  Attoyney and Create an Enter Reference number.

                Reports.TestStep = "Navigate Seller's  Attoyney and Create an Enter Reference number.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.WaitForScreenToLoad();


                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Reference.FASetText("123456789");

                Reports.TestStep = "Enter Gab Code.";
                FastDriver.AttorneyDetail.GABcode.FASetText("Hudflinsr1");
                FastDriver.AttorneyDetail.Find.FAClick();

                Reports.TestStep = "Chang the Business Party will remove reference and loan number Click ok.";
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Verifying that system is not change reference number on click on OK.
                Reports.TestStep = "Verifying that system is not change reference number on click on OK.";
                FastDriver.AttorneyDetail.WaitForScreenToLoad();
                Support.AreEqual(@"123456789", FastDriver.AttorneyDetail.Reference.FAGetValue());

                Reports.TestStep = "Enter Gab Code.";
                FastDriver.AttorneyDetail.GABcode.FASetText("Hudflinsr1");
                FastDriver.AttorneyDetail.Find.FAClick();

                Reports.TestStep = "Change the Business Party will remove reference and loan number Click cancel.";
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));


                #endregion

                #region Verifying that system is remove the reference number on click on Cancel.
                Reports.TestStep = "Verifying that system is remove the reference number on click on Cancel.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Support.AreEqual("", FastDriver.AttorneyDetail.Reference.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("")]
        public void FMUC0040_REG0012()
        {

            try
            {
                Reports.TestDescription = "FM2456: ";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion

                #region Create A Basic file order.
                Reports.TestStep = "Create A Basic file order.";
                _CreateFile();
                #endregion

                #region Navigate Buyer's  Attoyney and Create an Attorney Instance.
                Reports.TestStep = "Navigate Buyer's  Attoyney and Create an Attorney Instance.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer");
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "50.00", SellerCharge: "50.00", GabCode: "HUDBUYATT1");

                FastDriver.BottomFrame.Done();

                #endregion

                #region Create an Attorney Instance by Clicking on New-Buyer's Attorney.
                FastDriver.BottomFrame.New();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                CreateAttorney(BuyerCharge: "100.00", SellerCharge: "100.00", GabCode: "HUDBUYATT3");

                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Attorney Instances were created
                Reports.TestStep = "Verify for the First Instance Created.";

                FastDriver.AttorneySummary.WaitForScreenToLoad();
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 1 for HUD Test Name 1", 1, TableAction.Click);
                
                Reports.TestStep = "Verify for the Second Instance Created.";
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 3 for HUD Test Name 1", 1, TableAction.Click);

                #endregion

                #region Verify for the First Instance Created and delete the same.
                Reports.TestStep = "Verify for the First Instance Created and delete the same.";
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Buyer's Attorney 1 for HUD Test Name 1", 1, TableAction.Click);

                FastDriver.AttorneySummary.Remove.FAClick();

                Reports.TestStep = "All information will be removed for this Attorney. Continue? OK.";
                Support.AreEqual("All information will be removed for this Attorney.  Continue?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AttorneySummary.WaitForScreenToLoad();

                Reports.TestStep = "Verify Removed Instance.";
                FastDriver.AttorneySummary.SummaryTable.PerformTableAction(2, "Available", 1, TableAction.Click);
                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        [Description("Verify these BRs Manually as we are not supposed to touch Charge Details screen in ADM.")]
        public void FMUC0040_REG0013_PH()
        {

            try
            {
                Reports.TestDescription = "ES10916_ES10917_ES10918_ES10920: Verify these BRs Manually as we are not supposed to touch Charge Details screen in ADM.";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Reports.TestStep = "This Flow has NOT been Automated Please perform this MANUALLY";
                Support.AreEqual(true.ToString(), false.ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion
        
        #region PRIVATE METHODS

        private void CreateAttorneyAndVerifyValues(string BuyerCharge, string SellerCharge, string GabCode, string ExpectedAmount)
        {

            CreateAttorney(BuyerCharge, SellerCharge, GabCode);
            #region Verify the Created Attorney
            Reports.TestStep = "Verify the Created Attorney.";

            Support.AreEqual("Attorney- Primary", FastDriver.AttorneyDetail.Type.FAGetSelectedItem());
            Support.AreEqual(BuyerCharge, GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));
            Support.AreEqual(SellerCharge, GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee"));

            Playback.Wait(4000);
            Support.AreEqual(ExpectedAmount, FastDriver.AttorneyDetail.TotalCharges.Text);
            Support.AreEqual(ExpectedAmount, FastDriver.AttorneyDetail.NetcheckAmount.Text);

            #endregion
        }

        private void CreateAttorney(string BuyerCharge, string SellerCharge, string GabCode)
        {
            #region Set Attorney's Data
            FastDriver.AttorneyDetail.GABcode.FASetText(GabCode);
            FastDriver.AttorneyDetail.Find.FAClick();
            FastDriver.AttorneyDetail.Type.FASelectItem("Attorney- Primary");

            SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", BuyerCharge);
            SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", SellerCharge);

            #endregion
        }
       
        private string GetBuyerCharge(IWebElement TableCharges, string DescriptionRow)
        {
            return TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.GetAttribute, "value").Message;
        }

        private void SetBuyerCharge(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue, int startOffRow = 1)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.SetText, BuyerCreditValue, startOffRow);
            TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.SendKeys, FAKeys.Tab, startOffRow);
           
        }

        private string GetSellerCharge(IWebElement TableCharges, string DescriptionRow)
        {
            return TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.GetAttribute, "value").Message;
        }

        private void SetSellerCharge(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue, int startOffRow = 1)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.SetText, BuyerCreditValue, startOffRow);
            TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.SendKeys, FAKeys.Tab, startOffRow);
           

        }

        private void SetDescription(IWebElement TableCharges, string DescriptionRow, string NewDescriptionValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 1, TableAction.SetText, NewDescriptionValue + Keys.Tab);
        }

        private void _CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = _GetCurrentFileFormType();
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 1000;
            customizableFileRequest.File.LiabilityAmount = 1000;
            
            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

        }

        private void _IISLOGIN(string UserName = null, string Password = null)
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }

        private bool isAlertPresent()
        {

            try
            {
               FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }
        
        private FormType _GetCurrentFileFormType()
        {
            return AutoConfig.FormType.ToUpper() == "CD" ? FormType.CD : FormType.HUD;
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

    
    }
}
