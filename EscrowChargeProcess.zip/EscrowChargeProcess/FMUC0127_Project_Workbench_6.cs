﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscrowChargeProcess
{
    public partial class FMUC0127_Project_Workbench : MasterTestClass
    {

        [TestMethod]
        public void US_535150()
        {
            try
            {
                
                Reports.TestDescription = "Create - Rename Buyer to Borrower for Refinance file";
                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file with a commercial business segment and refinance as transaction type.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Set file as Project File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                
                Reports.TestStep = "Navigate to Project Workbench page and click on Create Site Files";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Navigate to Project Workbench page and click on Create Site Files";
                Support.AreEqual(true, FastDriver.WebDriver.FAFindElement(ByLocator.Id, "lblBuyer").FAGetText().Equals("Borrower"), "Verifying that Buyer checkbox has been renamed to Borrower.");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.Seller.IsDisplayed(), "Verifying that Seller checkbox is not present.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void US_380077()
        {
            try
            {
                
                Reports.TestDescription = "US 380077: Update - Buyer";

                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL);

                #region Data Setup
                var individualBuyer = new BuyerParameters()
                {
                    BuyerType = "Individual",
                    First = "John",
                    Middle = "K.",
                    Last = "Doe",
                    SSN = "123-45-6789"
                };

                var spousesBuyer = new BuyerParameters()
                {
                    BuyerType = "Husband/Wife",
                    Husband1FirstName = "John",
                    Husband2LastName = "Doe",
                    HusbandSpouseFirstName = "Jane",
                    HusbandSpouse1SSN = "123-45-6789",
                };

                var businessEntity = new BuyerParameters()
                {
                    BuyerType = "Business Entity",
                    BusinessEntityShortname = "Buyer BusEntity Name",
                    StateofIncorp = "Alaska",
                    EntityType = "Business Trust",
                    BusinessEntitySsn = "53-4553543"
                };

                var trustEstate = new BuyerParameters()
                {
                    BuyerType = "Trust/Estate",
                    TrusteeName = "Trustee Buyer Name",
                    TrusteeShortNameTwo = "Trustee Buyer",
                    TrustSsnText = "53-4553543"
                };
                #endregion

                Reports.TestStep = "Create a file with a commercial business segment and refinance as transaction type.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Set file as Project File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Project Workbench page and click on Create Site Files";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Verify that Buyer checkbox is disabled due to lack of buyer entries.";
                Support.AreEqual("true", FastDriver.ProjectWorkBench.Buyer.FAGetAttribute("disabled"), "Verifying that Buyer checkbox is disabled.");

                Reports.TestStep = "Navigate to Buyer/Seller setup and create individual buyer entry.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(individualBuyer);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Buyer/Seller setup and create husband/buyer buyer entry.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(spousesBuyer);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Buyer/Seller setup and create business entity buyer entry.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(businessEntity);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Buyer/Seller setup and create Trust/Estate buyer entry.";
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerDetails(trustEstate);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench page and create a site file without selecting the Buyer checkbox.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 3, TableAction.On);
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Access Update Site Files section, select the Buyer checkbox and click on Ellipse button. All the buyers should be checked by default";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateBuyerChk);
                FastDriver.ProjectWorkBench.UpdateBuyerChk.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.UpdateBuyerDetails.FAClick();
                FastDriver.ProjectWorkBench.BuyerSelectionDlg.WaitForScreenToLoad();
                for (int i = 2; i <= FastDriver.ProjectWorkBench.BuyerSelectionDlg.BuyerSelectionTable.GetRowCount(); i++)
                {
                    Support.AreEqual(true, FastDriver.ProjectWorkBench.BuyerSelectionDlg.BuyerSelectionTable.PerformTableAction(i, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsSelected(), string.Format("Verifying that cell 4, on row {0} is selected", i));
                }
                FastDriver.ProjectWorkBench.BuyerSelectionDlg.Done.FAClick();

                Reports.TestStep = "Click on Site Files slider, check the checkbox for site file created and click on Done button.";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateBuyerChk);
                FastDriver.ProjectWorkBench.UpdateFileSlider.FAClick();
                FastDriver.ProjectWorkBench.WaitCreation(FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable);
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();

                Reports.TestStep = "System display message as 'Site File(s) updated Successfully.'";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateBuyerChk);
                FastDriver.ProjectWorkBench.WaitForValue(FastDriver.ProjectWorkBench.SiteFileStatus, "Site File(s) updated Successfully.");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.SiteFileStatus.FAGetText().Equals("Site File(s) updated Successfully."), "Verifying that site file was updated.");

                Reports.TestStep = "Select the site file and click on Done";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickOnListOfSiteFilesLink();
                FastDriver.ProjectWorkBench.SiteFilesInnerGridTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.ProjectWorkBench.SiteFilesInnerGridDone.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Buyers screen and validate if all buyers are copied in summary screen.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Buyers").WaitForScreenToLoad();
                Support.AreEqual(individualBuyer.First + " " + individualBuyer.Middle + " " + individualBuyer.Last, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean(), "Verifying if individual buyer was copied.");
                Support.AreEqual(spousesBuyer.Husband1FirstName + " " + spousesBuyer.Husband2LastName + " /" + spousesBuyer.HusbandSpouseFirstName + " " + spousesBuyer.Husband2LastName, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean(), "Verifying if individual buyer was copied.");
                Support.AreEqual(businessEntity.BusinessEntityShortname, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, 2, TableAction.GetText).Message.Clean(), "Verifying if individual buyer was copied.");
                Support.AreEqual(trustEstate.TrusteeShortNameTwo, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(5, 2, TableAction.GetText).Message.Clean(), "Verifying if individual buyer was copied.");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void US_543854()
        {
            try
            {


                Reports.TestDescription = "Verify Site File in Event log";

                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file with a commercial business segment and refinance as transaction type.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set file as Project File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Project Workbench page and create a site file.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 2, TableAction.SetText, "CA127");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 4, TableAction.SetText, "1 Main St.");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 5, TableAction.SetText, "ALBANY");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 6, TableAction.SelectItem, "CA");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 7, TableAction.SetText, "94706");
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Navigate to the FAST search in the title bar enter site file number and press the enter button";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForWindowToLoad();
                FastDriver.EventTrackingLog.SelectEventCategory("All");

                Reports.TestStep = "Verify System generate a Site File Opened Event in the file Event log when the user created site files from the Project workbench";
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[Site File(s) Created]");
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 5, "Following Site File(s) successfully created " + fileNumber + "CA1");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void US_662840()
        {
            try
            {

                /// <summary>
                /// This US covers functionalities tested in US 661717, 661721, 661725, 661729, 650461.
                /// 1- Allow user to select one lender at time to update.
                /// 2- Display site files which are applicable only for the selected lender.
                /// 3- Enable the select check boxes in the site files slider.
                /// 4- Update the Project file Lender information’s to site files Lender.
                /// 5- Update – New Lender –‘View’ and ‘update Details’.
                /// </summary>

                Reports.TestDescription = "US 662840: Update - Lender details to be updated to Site Files (Add functionality)";

                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file with a commercial business segment and refinance as transaction type.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set file as Project File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Project Workbench page and create a site file.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Verify that both Lender checkbox and New Lender button are disabled.";
                Support.AreEqual("true", FastDriver.ProjectWorkBench.Lender.FAGetAttribute("disabled"), "Verifying if Lender checkbox is disabled.");
                Support.AreEqual("true", FastDriver.ProjectWorkBench.CreateSiteFilesNewLendersEllipsis.FAGetAttribute("disabled"), "Verifying if Lender checkbox is disabled.");

                Reports.TestStep = "Create a site file.";
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 6, TableAction.SelectItem, "CA");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 2, TableAction.SetText, "SF1");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 4, TableAction.SetText, "1 Main St.");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 5, TableAction.SetText, "ALBANY");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 7, TableAction.SetText, "94706");
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Navigate to New Loan Screen and add a lender";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FMUC0127 - US 662840");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Mortgage Broker tab and add a GAB";
                FastDriver.NewLoan.WaitForScreenToLoad().ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageFindGAB(GABCode: "247");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Parties tab and add a GAB";
                FastDriver.NewLoan.WaitForScreenToLoad().ClickPartiesTab();
                FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FASetText("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin at turpis in urna vehicula egestas. Aliquam arcu dui, iaculis a euismod eget, tempor ut lorem. Aliquam bibendum maximus orci, rhoncus maximus metus scelerisque at. Nam vehicula varius tortor, nec laoreet tortor accumsan semper. Sed vulputate ante velit, eu ultrices purus pharetra vel. Sed dictum neque et risus ultricies volutpat. Sed non mollis libero. Aliquam lacus risus, scelerisque pharetra hendrerit vitae, viverra eleifend neque.");
                FastDriver.NewLoan.FindPartiesGAB(GABCode: "246");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Click on New, select Attorney- Local and add a GAB for the related party";
                FastDriver.NewLoan.WaitForScreenToLoad().ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.SelectItem, "Attorney- Local");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "248");

                Reports.TestStep = "Click on New, select Attorney- Co-Counsel and add a GAB for the related party";
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.SelectItem, "Attorney- Co-Counsel");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "245");

                Reports.TestStep = "Click on New, select Attorney- Primary and add a GAB for the related party";
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(4, 1, TableAction.SelectItem, "Attorney- Primary");
                FastDriver.NewLoan.FindRelatedPartyGAB(GABCode: "249");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Project Workbench page.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Verify that both Lender checkbox and New Lender button are enabled after adding a lender.";
                Support.AreEqual(true, FastDriver.ProjectWorkBench.Lender.IsEnabled(), "Verifying if Lender checkbox is enabled.");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.CreateSiteFilesNewLendersEllipsis.IsEnabled(), "Verifying if Lender checkbox is enabled.");

                Reports.TestStep = "Verifying that lender is displayed in Lender Selection table.";
                FastDriver.ProjectWorkBench.CreateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.ProjectWorkBench.LenderSelectionDlg.LenderSelectionTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Contains("Mortgage Lender 1"), "Verifying Lender Selection table contains newly added lender.");
                FastDriver.ProjectWorkBench.LenderSelectionDlg.Cancel.FAClick();

                Reports.TestStep = "Navigate to the Update Site Files section.";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateBuyerChk);
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);

                Reports.TestStep = "System should disable all the Check boxes (Select All/Transaction Type/Product(S)/Buyer/Seller/Notes).";
                Support.AreEqual("true", FastDriver.ProjectWorkBench.UpdateSelectAll.FAGetAttribute("disabled"), "Verifying UpdateSelectAll checkbox is disabled.");
                Support.AreEqual("true", FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.FAGetAttribute("disabled"), "Verifying UpdateTransactionTypeChk checkbox is disabled.");
                Support.AreEqual("true", FastDriver.ProjectWorkBench.UpdateProductsChk.FAGetAttribute("disabled"), "Verifying UpdateProductsChk checkbox is disabled.");
                Support.AreEqual("true", FastDriver.ProjectWorkBench.UpdateBuyerChk.FAGetAttribute("disabled"), "Verifying UpdateBuyerChk checkbox is disabled.");
                Support.AreEqual("true", FastDriver.ProjectWorkBench.UpdateNotesChk.FAGetAttribute("disabled"), "Verifying UpdateNotesChk checkbox is disabled.");

                Reports.TestStep = "View Lender(s) radio button should be checked by default and New Lender ellipsis is disabled.";
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsSelected(), "Verifying UpdateSiteFilesViewLenders checkbox is selected.");
                Support.AreEqual("true", FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAGetAttribute("disabled"), "Verifying UpdateSiteFilesNewLendersEllipsis checkbox is disabled.");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateFileSlider.IsEnabled(), "Verifying Slider menu was enabled.");

                Reports.TestStep = "Select the Add/ Delete Lender(S) Radio Button and click on the New Lender Ellipse Button";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FAClick();
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();

                Reports.TestStep = "Verify header title and lender name in Lender Selection table";
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText().Equals("Lender Selection"), "Verifying dialog title matches: Lender Selection");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean().Contains("Mortgage Lender 1"), "Verifying Lender Selection table contains newly added lender.");

                Reports.TestStep = "Select Lender and click on Done";
                FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateDone.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateBuyerChk);

                Reports.TestStep = "Open the Site File Slider";
                FastDriver.ProjectWorkBench.UpdateFileSlider.FAClick();

                Reports.TestStep = "Validate that header includes Lender Name and location";
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesSliderContainer.PerformTableAction(1, 1, TableAction.GetText).Message.Clean().Contains("Mortgage Lender 1"), "Verifying that Slider Header includes the selected lender name");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesSliderContainer.PerformTableAction(1, 1, TableAction.GetText).Message.Clean().Contains("City: Fullerton; State: CA;"), "Verifying that Slider Header includes the selected lender name");

                Reports.TestStep = "Validate the 1st checkbox for the first file is unchecked, the 2nd, 3rd checkboxes and the Done button are disabled.";
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsSelected(), "Verifying if checkbox is selected");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 3, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").FAGetAttribute("disabled") != null, "Verifying if checkbox is disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").FAGetAttribute("disabled") != null, "Verifying if checkbox is disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAGetAttribute("disabled") != null, "Verifying if checkbox is disabled");

                Reports.TestStep = "Validate that after 1st checkbox is selected, the 2nd becomes enabled.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 2, TableAction.On);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 3, TableAction.GetCell).Element.IsEnabled(), "Verifying if checkbox is enabled");

                Reports.TestStep = "Validate that after 2nd checkbox is selected, the 3rd becomes enabled.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 3, TableAction.On);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 4, TableAction.GetCell).Element.IsEnabled(), "Verifying if checkbox is enabled");

                Reports.TestStep = "Check the 3rd checkbox and click on Done.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(1, 4, TableAction.On);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();
                Support.AreEqual(true, FastDriver.ProjectWorkBench.SiteFileStatus.FAGetText().Equals("An Update is in Process. Please wait."), "Verifying file is being updated.");
                FastDriver.ProjectWorkBench.WaitForValue(FastDriver.ProjectWorkBench.SiteFileStatus, "Site File(s) updated Successfully.");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.SiteFileStatus.FAGetText().Equals("Site File(s) updated Successfully."), "Verifying that site file was updated.");

                Reports.TestStep = "Click on List of Site Files and select the updated one.";
                FastDriver.ProjectWorkBench.ClickOnListOfSiteFilesLink();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.SiteFilesReportTable.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.Done.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to the Site File New Loan Screen.";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("New Loan").WaitForScreenToLoad();

                Reports.TestStep = "System Should Successfully add the same lender three times and should display in a Table in an Ascending order.";
                Support.AreEqual(true, FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Contains("Mortgage Lender 1"), "Verifying that selected lender was added 3 times.");
                Support.AreEqual(true, FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean().Contains("Mortgage Lender 1"), "Verifying that selected lender was added 3 times.");
                Support.AreEqual(true, FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 2, TableAction.GetText).Message.Clean().Contains("Mortgage Lender 1"), "Verifying that selected lender was added 3 times.");

                Reports.TestStep = "Select one of the entries.";
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();

                Reports.TestStep = "Verify that GAB added on original file is listed and Hazard Insurance Loss Payee text was copied.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText().Equals("MORTLNDR"), "Verifying GAB lender name was copied.");
                Support.AreEqual(true, FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FAGetText().Equals("FMUC0127 - US 662840"), "Verifying if Hazard Insurance Loss Payee text was copied.");

                Reports.TestStep = "Verify that GAB added on Mortgage Broker gab was added.";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                Support.AreEqual(true, FastDriver.NewLoan.MortgageBrokerGABlabel.FAGetText().Equals("247"), "Verifying mortgage broker name was copied.");

                Reports.TestStep = "Verify that Beneficiary-Mortgagee text was copied.";
                FastDriver.NewLoan.ClickPartiesTab();
                Support.AreEqual(true, FastDriver.NewLoan.PartiesBeneficiaryMortgagee.FAGetText().Contains("Lorem ipsum dolor sit amet"), "Verifying that Beneficiary Mortgagee text was copied.");

                Reports.TestStep = "Verify that Trustee GAB info was added";
                Support.AreEqual(true, FastDriver.NewLoan.PartiesGABcodeLabel.FAGetText().Contains("246"), "Verifying that Beneficiary Mortgagee text was copied.");

                Reports.TestStep = "Verify all related party GABs and roles were copied";
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                Support.AreEqual(true, FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 1, TableAction.GetSelectedItem).Message.Clean().Equals("Attorney- Local"), "Verifying related party Attorney- Local was added.");
                Support.AreEqual(true, FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Equals("248"), "Verifying related party Attorney- Local was added.");
                Support.AreEqual(true, FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 1, TableAction.GetSelectedItem).Message.Clean().Equals("Attorney- Co-Counsel"), "Verifying related party Attorney- Co-Counsel was added.");
                Support.AreEqual(true, FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean().Equals("245"), "Verifying related party Attorney- Local was added.");
                Support.AreEqual(true, FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(4, 1, TableAction.GetSelectedItem).Message.Clean().Equals("Attorney- Primary"), "Verifying related party Attorney- Primary was added.");
                Support.AreEqual(true, FastDriver.NewLoan.RelatedPartiesSummaryTable.PerformTableAction(4, 2, TableAction.GetText).Message.Clean().Equals("249"), "Verifying related party Attorney- Primary was added.");

                Reports.TestStep = "Navigate to Event/Tracking Log";
                FastDriver.LeftNavigation.Navigate<EventTrackingLog>("Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 1, "[Update from Project File]");
                FastDriver.EventTrackingLog.VerifyEventTableData(1, 5, "The following field(s) were updated from Project File # " + fileNumber + " : Lender.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void US_634972()
        {
            try
            {

                /// <summary>
                /// Bug 892592 was found while coding test.
                ///                                
                /// </summary>

                Reports.TestDescription = "US 634972 - Delete lender functionality";
                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file with a commercial business segment and refinance as transaction type.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set file as Project File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan Screen and add a lender";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FMUC0127 - US 662840");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench page and create a site file.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);
                
                Reports.TestStep = "Create a site file.";
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 6, TableAction.SelectItem, "CA");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 2, TableAction.SetText, "SF1");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 4, TableAction.SetText, "1 Main St.");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 5, TableAction.SetText, "ALBANY");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 7, TableAction.SetText, "94706");
                FastDriver.ProjectWorkBench.CopyLenderData.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Load the created site file and verify that lender was added.";
                FastDriver.ProjectWorkBench.ClickOnListOfSiteFilesLink();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.SiteFilesReportTable.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.Done.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText().Equals("MORTLNDR"), "Verifying that Lender was copied.");

                Reports.TestStep = "Load Project file, then remove the Lender.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench page and create a site file.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);

                Reports.TestStep = "Click on List of Site File link and select the first site file, then click Done.";
                FastDriver.ProjectWorkBench.ClickOnListOfSiteFilesLink();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.SiteFilesReportTable.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.Done.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Verify that lender was removed from site file";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText() == string.Empty, "Verifying that lender was deleted.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void US_650474()
        {
            try
            {
                Reports.TestDescription = "Delete Lender - Validation / restrictions in site files";
                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file with a commercial business segment and refinance as transaction type.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set file as Project File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan screen and add 3 lender instances. (Lender 1, Lender 2 & Lender 3)";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("MORTLNDR");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FMUC0127 - US 650474");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad().FindGABCode("247");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FMUC0127 - US 650474");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad().FindGABCode("248");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FMUC0127 - US 650474");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench screen and create 5 site files with different State, County & City combinations from Create Site Files section with Lender checkbox selected.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption).WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);
                int rowCount = FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount();
                for (int rows = 6; rowCount < rows; rowCount++)
                {
                    FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(rowCount, 6, TableAction.SelectItemByIndex, rowCount.ToString());
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(rowCount, 2, TableAction.SetText, string.Format("SF{0}", rowCount));
                }
                FastDriver.ProjectWorkBench.CopyLenderData.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText().Clean().Equals("5 File(s) successfully created."), "Verifying that files were created.");

                Reports.TestStep = "Click on Update Site Files section from menu bar then check the New Lender checkbox";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption).WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                
                Reports.TestStep = "Select Add/Delete Lender(s) radio button and click on ellipse button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FAClick();
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();

                Reports.TestStep = "Lender Selection dialog will be opened. Select first lender from the dialog and click on Done button.";
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateDone.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateBuyerChk);

                Reports.TestStep = "Open the Site Files slider and verify that all site files are selected and highlighted.";
                FastDriver.ProjectWorkBench.UpdateFileSlider.FAClick();
                FastDriver.ProjectWorkBench.WaitCreation(FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable);
                rowCount = FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.GetRowCount();
                for (int rows = 0; rows < rowCount; rows++)
                {
                    Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(rowCount, 2, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").IsSelected(), "Verifying if checkbox is disabled");
                }
                foreach (var row in FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.FAFindElements(ByLocator.TagName, "tr"))
                {
                    Support.IsTrue(row.FAGetAttribute("class").Contains("highLightRow"), "Verifying that row is highlighted.");
                }

                Reports.TestStep = "Uncheck the checkbox from first row and click on Done button.";
                FastDriver.ProjectWorkBench.SliderTableHeader.FAFindElement(ByLocator.Id, "chkSF_All_1").FASetCheckbox(false);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();
                FastDriver.ProjectWorkBench.WaitCreation(FastDriver.ProjectWorkBench.ConfirmBoxOk);
                FastDriver.ProjectWorkBench.ConfirmBoxCancel.FAClick();

                Reports.TestStep = "Click on Done button.";
                FastDriver.ProjectWorkBench.WaitCreation(FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();
                FastDriver.ProjectWorkBench.WaitCreation(FastDriver.ProjectWorkBench.ConfirmBoxOk);
                FastDriver.ProjectWorkBench.ConfirmBoxOk.FAClick();
                
                Reports.TestStep = "Verify that updates to the file have been performed.";
                Support.AreEqual(true, FastDriver.ProjectWorkBench.SiteFileStatus.FAGetText().Equals("An Update is in Process. Please wait."), "Verifying file is being updated.");
                Playback.Wait(3000);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.SiteFileStatus.FAGetText().Equals("Site File(s) updated Successfully."), "Verifying that site file was updated.");

                Reports.TestStep = "Click on List of Site File link and select the first site file, then click Done.";
                FastDriver.ProjectWorkBench.ClickOnListOfSiteFilesLink();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.SiteFilesReportTable.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.Done.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan and verify that first lender has been deleted.";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("New Loan").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Equals("Available"), "Verifying that first lender was deleted.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void US_579970()
        {
            try
            {
                Reports.TestDescription = "Update - Lender";
                Reports.TestStep = "Log into FAST application.";
                FALogin(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file with a commercial business segment and refinance as transaction type.";
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Set file as Project File.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan screen and add 3 lender instances. (Lender 1, Lender 2 & Lender 3)";
                FastDriver.LeftNavigation.Navigate<NewLoan>("New Loan").WaitForScreenToLoad().FindGABCode("247");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FMUC0127 - US 579970");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad().FindGABCode("248");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FMUC0127 - US 579970");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad().FindGABCode("MORTLNDR");
                FastDriver.NewLoan.LoanDetailsFundsReceived.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsHazardInsuranceLossPayee.FASetText("FMUC0127 - US_579970");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench screen and create 5 site files with different State, County & City combinations from Create Site Files section with Lender checkbox selected.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad().ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption).WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);
                
                for (int rowCount = FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount(); rowCount < 6; rowCount++)
                {
                    
                    FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(rowCount, 6, TableAction.SelectItemByIndex, (rowCount + 3).ToString());
                    FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(rowCount, 2, TableAction.SetText, string.Format("SF{0}", rowCount));
                }
                FastDriver.ProjectWorkBench.CopyLenderData.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.CopyAllAddresses);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText().Clean().Equals("5 File(s) successfully created."), "Verifying that files were created.");

                Reports.TestStep = "Access the first site file and enter fees.";
                FastDriver.ProjectWorkBench.ClickOnListOfSiteFilesLink();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.SiteFilesReportTable.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.Done.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Add a county to the Site File";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Properties/Tax Info").WaitForScreenToLoad();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("Baldwin");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("Daphne");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Recording Fess Checkbox and CLick on Calculate Fess button.";
                FastDriver.LeftNavigation.Navigate<FileFees>("Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingFees.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.waitForScreenToLoad().EnterRecordingFees("Mortgage", "2");
                FastDriver.CalculateFees.EnterCalculationSummaryData("2", "", "", "", "");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Loan Investor";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad().LoanInvestors.FAClick();
                FastDriver.LoanInvestors.WaitForScreenToLoad().Add.FAClick();
                FastDriver.LoanInvestorsDlg.WaitForScreenToLoad().LoanInvestorsTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();

                Reports.TestStep = "Access the project file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Click on Update Site Files section from menu bar then check the New Lender checkbox";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad().ClickMortgageBrokerTab().MortgageFindGAB("247");

                Reports.TestStep = "Navigate back to Project Workbench screen and click on Update Site Files section from menu bar";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad().ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption).WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);

                Reports.TestStep = "Select Add/Delete Lender(s) radio button and click on ellipse button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesUpdateLenderDetails.FAClick();
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();

                Reports.TestStep = "Lender Selection dialog will be opened. Select first lender from the dialog and click on Done button.";
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(element: FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 5, TableAction.Click);
                FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateDone.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateBuyerChk);

                Reports.TestStep = "Open the Site Files slider and verify that all site files are selected and highlighted.";
                FastDriver.ProjectWorkBench.UpdateFileSlider.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.SliderTable);

                Reports.TestStep = "Uncheck the checkbox from first row and click on Done button.";
                FastDriver.ProjectWorkBench.SliderTable.PerformTableAction(1, 2, TableAction.On);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();

                Reports.TestStep = "Verify that updates to the file have been performed.";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.SiteFileStatus.FAGetText().Equals("An Update is in Process. Please wait."), "Verifying file is being updated.");
                FastDriver.ProjectWorkBench.WaitForValue(FastDriver.ProjectWorkBench.SiteFileStatus, "Site File(s) updated Successfully.");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.SiteFileStatus.FAGetText().Equals("Site File(s) updated Successfully."), "Verifying that site file was updated.");

                Reports.TestStep = "Access the first site file, navigate to New Loan screen and validate first lender instance. ";
                FastDriver.ProjectWorkBench.ClickOnListOfSiteFilesLink();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.SiteFilesReportTable.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.Done.FAClick();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Mortgage Broker instance should be displayed as added in the above steps.";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("New Loan").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad().ClickMortgageBrokerTab();
                Support.AreEqual(true, FastDriver.NewLoan.MortgageBrokerGABlabel.FAGetText().Equals("247"), "Verifying that Mortgage Broker was added to site file.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #region Useful Methods
        private void FALogin(string URL)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(URL, credentials, true);
        }
        #endregion
    }
}
