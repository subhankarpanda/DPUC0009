﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using AutoIt;

namespace EscrowChargeProcess
{
    public partial class FMUC0127_Project_Workbench : MasterTestClass
    {
        #region US 535683: Create - Warning message if the user navigates away

        [TestMethod]
        public void US_535683_TC_581386()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message when the user navigates to the other screen in FAST with the address details entered in the project workbench";

                #region UI Interaction

                Reports.TestStep = "Log into FAST IIS site.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                
                Reports.TestStep = "Enter the address details in the grid";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.State.FASelectItem("CA");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("First American Way");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Santa Ana");
                FastDriver.ProjectWorkBench.nameZip.FASetText("92708");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Orange");

                Reports.TestStep = "Navigate to the other screen from the left navigation pane and verify the warning message";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean()) ;

                Reports.TestStep = "Navigate again to the other screen";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Reports.StatusUpdate("Previously data entered should not be present.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 6, TableAction.GetSelectedItem).Message.Clean() == @"");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_581391()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message when the user navigates to the other tab in FAST with the address details entered in the project workbench";

                #region UI Interaction

                Reports.TestStep = "Log into FAST IIS site.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter the address details in the grid";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.State.FASelectItem("CA");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("First American Way");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Santa Ana");
                FastDriver.ProjectWorkBench.nameZip.FASetText("92708");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Orange");

                Reports.TestStep = "Navigate to the other tab in the Project Workbench screen and verify the warning message";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate again to the other tab";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Reports.StatusUpdate("Previously data entered should not be present.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 6, TableAction.GetSelectedItem).Message.Clean() == @"");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_581394()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message if the user tries to close the FAST application with the address details are entered in the project workbench";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                ClickOnCreateSiteFilesLink();
                Playback.Wait(2000);

                Reports.TestStep = "Enter the address details in the grid";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.State.FASelectItem("CA");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("First American Way");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Santa Ana");
                FastDriver.ProjectWorkBench.nameZip.FASetText("92708");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Orange");

                Reports.TestStep = "Try to close the FAST application and verify the warning message";
                Keyboard.SendKeys("%{F4}");
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(false, false).Clean());
                HandleIELeavingMessageBox();

                Reports.TestStep = "Close the FAST application again";
                Keyboard.SendKeys("%{F4}");
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(false, true).Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_581396()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message when the user navigates to the other screen/Tab in FAST with the address details are entered for multiple rows";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                ClickOnCreateSiteFilesLink();
                Playback.Wait(2000);

                Reports.TestStep = "Click on + Add button to add multiple rows";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.AddNewRow);
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();

                Reports.TestStep = "Enter the address details in the grid for all rows";
                //first row
                FastDriver.ProjectWorkBench.State.FASelectItem("CA");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("First American Way");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Santa Ana");
                FastDriver.ProjectWorkBench.nameZip.FASetText("92708");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Orange");
                //second row
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 6, TableAction.SelectItemBySendkeys, "CA");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 4, TableAction.SetText, "First American Way");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 5, TableAction.SetText, "Santa Ana");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 7, TableAction.SetText, "92708");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 8, TableAction.SetText, "Orange");

                Reports.TestStep = "Navigate to the other tab in the Project Workbench screen and verify the warning message";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate again to the other tab";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Reports.StatusUpdate("Previously data entered should not be present.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 6, TableAction.GetSelectedItem).Message.Clean() == @"");
                Reports.StatusUpdate("The table should have one row.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount() == 1);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_581398()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message when the user navigates to the other screen/tab in FAST with the address details copied from project file";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Click on Copy checkbox for a site file";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 3, TableAction.On);
                
                Reports.TestStep = "Navigate to the other tab in the Project Workbench screen and verify the warning message";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate again to the other tab";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Click on Add button to add maximum(5) site file rows";
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();

                Reports.TestStep = "Click on Copy All checkbox in the column header";
                FastDriver.ProjectWorkBench.CopyAllAddresses.FASetCheckbox(true);

                Reports.TestStep = "Navigate to the other tab in the Project Workbench screen and verify the warning message";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate again to the other tab";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Reports.StatusUpdate("Previously data entered should not be present.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 6, TableAction.GetSelectedItem).Message.Clean() == @"");
                Reports.StatusUpdate("CreateSiteFile table should have one row.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.GetRowCount() == 1);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_581400()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message when the user navigates to the other screen/Tab in FAST with the created site file and data entered in new row";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter the address details in the grid and click on create";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.State.FASelectItem("CA");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("First American Way");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Santa Ana");
                FastDriver.ProjectWorkBench.nameZip.FASetText("92708");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Orange");
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on + Add button to add a row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.AddNewRow);
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();

                Reports.TestStep = "Enter the address details in the grid";
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 6, TableAction.SelectItemBySendkeys, "CA");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 4, TableAction.SetText, "First American Way");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 5, TableAction.SetText, "Santa Ana");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 7, TableAction.SetText, "92708");
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 8, TableAction.SetText, "Orange");

                Reports.TestStep = "Navigate to the other tab in the Project Workbench screen and verify the warning message";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate again to the other tab";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Reports.StatusUpdate("Previously data entered should not be present.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 6, TableAction.GetSelectedItem).Message.Clean() == @"");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_581402()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message when the user navigates to the other screen/tab in FAST with the address details entered in the project workbench for Country Canada";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address(Country - Canada), also Project File checkbox checked with CD Form type";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = RequestFactory.GetCreateFileDefaultRequest(); 
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "CANADA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = null;
                fileRequest.File.Properties[0].PropertyAddress[0].City = null;
                fileRequest.File.Sellers = null;
                fileRequest.File.Buyers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter the address details in the grid";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.State.FASelectItem("ON");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("4803 Wellesley Street");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Toronto");
                FastDriver.ProjectWorkBench.nameZip.FASetText("M7A1N3");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Ontario");

                Reports.TestStep = "Navigate to the other tab in the Project Workbench screen and verify the warning message";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate again to the other tab";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Reports.StatusUpdate("Previously data entered should not be present.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 6, TableAction.GetSelectedItem).Message.Clean() == @"");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_581403()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message when the user navigates to the other screen/tab in FAST with the address details entered in the project workbench for International Country";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & international address(Ex: Country - Florida), also Project File checkbox checked with CD Form type";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "FL";
                fileRequest.File.Properties[0].PropertyAddress[0].County = null;
                fileRequest.File.Properties[0].PropertyAddress[0].City = null;
                fileRequest.File.Sellers = null;
                fileRequest.File.Buyers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter the address details in the grid";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.State.FASelectItem("FL");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("1807 Glenwood St. NE");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Brevard");
                FastDriver.ProjectWorkBench.nameZip.FASetText("32907");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Palm Bay");

                Reports.TestStep = "Navigate to the other tab in the Project Workbench screen and verify the warning message";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate again to the other tab";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Reports.StatusUpdate("Previously data entered should not be present.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 6, TableAction.GetSelectedItem).Message.Clean() == @"");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_586286()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message when the user enters/modifies data in Project Workbench screen and change the file number from MRU";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.State.FASelectItem("FL");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("1807 Glenwood St. NE");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Brevard");
                FastDriver.ProjectWorkBench.nameZip.FASetText("32907");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Palm Bay");

                Reports.TestStep = "Change the file number from MRU files drop down";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum1);
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Change the file number from MRU files drop down again";
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum2);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.State.FASelectItem("FL");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("1807 Glenwood St. NE");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Brevard");
                FastDriver.ProjectWorkBench.nameZip.FASetText("32907");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Palm Bay");
                FastDriver.TopFrame.SetNumberAndPressEnter(FileNum1);
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.WaitForScreenToLoad().ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Reports.StatusUpdate("Previously data entered should not be present.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 6, TableAction.GetSelectedItem).Message.Clean() == @"");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_586287()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message if the user navigates away from the project workbench screen when there are error messages displayed";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Create a site file with blank state/ blank custom site file#/Duplicate Custom site file#/Invalid Zip code";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                //Create Site File with blank state
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("1807 Glenwood St. NE");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Brevard");
                FastDriver.ProjectWorkBench.nameZip.FASetText("32907");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Palm Bay");
                FastDriver.ProjectWorkBench.SiteFileNum.FASetText(Support.RandomString("NA1"));
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                //Create Site File with blank Custom Site File #
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ErrorMessagePane.FAGetText().Clean().Contains("State/Province is a required field. Please enter State/Province before saving."),
                    "Verify whether Error Message contains: 'State/Province is a required field. Please enter State/Province before saving.'");
                FastDriver.ProjectWorkBench.State.FASelectItem("FL");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("1807 Glenwood St. NE");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Brevard");
                FastDriver.ProjectWorkBench.nameZip.FASetText("32907");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Palm Bay");
                FastDriver.ProjectWorkBench.SiteFileNum.FASetText("");
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                //Create Site File with invalid ZIP code
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ErrorMessagePane.FAGetText().Clean().Contains("Custom Site File # is a required field. Please enter Custom Site file # before saving."),
                    "Verify whether Error Message contains: 'Custom Site File # is a required field. Please enter Custom Site file # before saving.'");
                FastDriver.ProjectWorkBench.State.FASelectItemBySendingKeys("CA");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("First American Way");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Albany");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Alameda");
                FastDriver.ProjectWorkBench.nameZip.FASetText("15151-51");
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ErrorMessagePane.FAGetText().Clean().Contains("Error in Zip Code. Please verify."),
                    "Verify whether Error Message contains: 'Error in Zip Code. Please verify.'");

                Reports.TestStep = "Navigate to the other tab in the Project Workbench screen and verify the warning message";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate away from the project workbench screen again";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Reports.StatusUpdate("Previously data entered should not be present.", FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 6, TableAction.GetSelectedItem).Message.Clean() == @"");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_586289()
        {
            try
            {

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To ensure that there will be no warning message when the user refreshes the Project Workbench screen and try to navigate away";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create first Order.";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum1 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter the data in the site file row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.State.FASelectItem("FL");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("1807 Glenwood St. NE");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Brevard");
                FastDriver.ProjectWorkBench.nameZip.FASetText("32907");
                FastDriver.ProjectWorkBench.nameCounty.FASetText("Palm Bay");
                #endregion UI Interaction

                FastDriver.ProjectWorkBench.Refresh.FAClick();
                Playback.Wait(5000);
                FastDriver.ProjectWorkBench.ConfirmationDlgOK.FAClick();
                FastDriver.LeftNavigation.ClickHome();
            }
            catch (Exception e)
            {
                FailTest(e.Message);

            }
        }

        [TestMethod]
        public void US_535683_TC_586290()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To ensure that there will be no warning message when the user navigates away from the project workbench screen without making any changes";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Navigate away from the project workbench screen";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual(true, FastDriver.WebDriver.HandleDialogMessage(true, false).Clean() == "No dialog present", "Warning messages did not appear.");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_535683_TC_586292()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To validate the warning message if the user navigates away from the screen by making changes in the Optional data selection ellipse button for Buyer/seller/Lender";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(RequestFactory.GetCreateFileDefaultRequest()).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                var FileNum2 = FastDriver.TopFrame.GetFileNumber();

                Reports.TestStep = "Add Buyers, sellers and lenders";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode(@"247");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Expand the Create Site Files section under Create/Update tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Select the Optional data Buyer/Seller/Lender and click on their respective ellipse button and select the required Buyer/Seller/Lender";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.Buyer.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.Seller.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.Lender.FASetCheckbox(true);

                Reports.TestStep = "Navigate away from the project workbench screen";
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());

                Reports.TestStep = "Navigate away from the project workbench screen again";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.LeftNavigation.ClickHome();
                Support.AreEqual("Exit without saving changes?", FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.Buyer.Selected, "Verify whether Buyer checkbox is unchecked.");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.Seller.Selected, "Verify whether Seller checkbox is unchecked.");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.Lender.Selected, "Verify whether Lender checkbox is unchecked.");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #region Custom Methods

        public void HandleIELeavingMessageBox(bool switchBackToFast = true, bool leaveThisPage = false)
        {
            try
            {
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Playback.Wait(1000);

                AutoItX.WinWait("Windows Internet Explorer", "", 20); //Switch to Browser Window
                AutoItX.WinActivate("Windows Internet Explorer");

                if (leaveThisPage)
                {
                    Report.UpdateLog(FastDriver.WebDriver, "Button", "Leave this Page", () =>
                    {
                        AutoItX.ControlEnable("Windows Internet Explorer", "", "[CLASS:Button;Text:&Leave this page]");
                        Playback.Wait(5000);
                        AutoItX.ControlClick("Windows Internet Explorer", "", "[CLASS:Button;Text:&Leave this page]");
                    });
                }
                else
                {
                    Report.UpdateLog(FastDriver.WebDriver, "Button", "Stay on this Page", () =>
                    {
                        AutoItX.ControlEnable("Windows Internet Explorer", "", "[CLASS:Button;Text:&Stay on this page]");
                        Playback.Wait(5000);
                        AutoItX.ControlClick("Windows Internet Explorer", "", "[CLASS:Button;Text:&Stay on this page]");
                    });
                }

                if (switchBackToFast)           //Switch back to FAST window
                {
                    Playback.Wait(10000);
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    Reports.StatusUpdate("Switch back to FAST Window.", true);
                }

            }
            catch (Exception e)
            {
                Reports.StatusUpdate(String.Format("Error: {0}", e.Message), false);
            }
        }

        #endregion

        #endregion

        #region US 589408: Create - State mandatory for Canada

        [TestMethod]
        public void US_589408_TC_594231()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Ensure that State is mandatory for Site Files with Country=Canada";

                #region UI Interaction

                Reports.TestStep = "Login to FAST IIS with the user having 'File Entry Activity' rights.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type. In the Service Section, Check on 'Project File' option| Enter Property Address with Country=Canada, State made blank.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "CANADA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = null;
                fileRequest.File.Properties[0].PropertyAddress[0].City = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to 'Project Workbench' Screen via home|Order Entry| Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Click on 'Create Site Files' section in Project Workbench screen";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter a Custom Site File number and Select Country=Canada";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                //FastDriver.ProjectWorkBench.State.FASelectItem("QC");
                FastDriver.ProjectWorkBench.AddressLine1.FASetText("10-123 main st nw");
                FastDriver.ProjectWorkBench.nameCity.FASetText("Montreal");
                FastDriver.ProjectWorkBench.nameZip.FASetText("H3Z2Y7");
                FastDriver.ProjectWorkBench.SiteFileNum.FASetText(Support.RandomString("NZ1"));

                Reports.TestStep = "Click on 'Create' button to save the Site File.";
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.ErrorMessagePane);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ErrorMessagePane.FAGetText().Clean().Contains("State/Province is a required field. Please enter State/Province before saving."),
                    "Verify whether the Error Message contains text: 'State/Province is a required field. Please enter State/Province before saving.'");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_589408_TC_594260()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Ensure that user selects State in Site File creation when Country=Canada in Project File";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type. In the Service Section, Check on 'Project File' option| Enter Property Address with Country=Canada, State made blank.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "CANADA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = null;
                fileRequest.File.Properties[0].PropertyAddress[0].City = null;
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AB";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElement(ByLocator.XPath, "//select[@id='tabPTI_tabGnrl_GEN_ucPhyAddr_cboState']/option[text() = 'AB']").FAClick();
                FastDriver.WebDriver.HandleDialogMessage().Clean();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to 'Project Workbench' Screen via home|Order Entry| Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Click on 'Create Site Files' section in Project Workbench screen";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Check the 'Copy Addresses' checkbox.";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.CopyAllAddresses.FASetCheckbox(true);

                Reports.TestStep = "Click on 'Create' button to save the Site File.";
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Uncheck the 'Copy Addresses' checkbox in order to enter the State.";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.CopyAllAddresses.FASetCheckbox(false);

                Reports.TestStep = "Enter a State when Country=Canada";
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 6, TableAction.SelectItemBySendkeys, "BC");

                Reports.TestStep = "Now, Click on 'Create' button to save the site File";
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Click on Add Button twice";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();

                Reports.TestStep = "Repeat Steps 8 to 12 for creating 2 more site files";
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(3, 3, TableAction.On);
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(4, 6, TableAction.SelectItemBySendkeys, "MB");
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_589408_TC_597391()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate the error message when State is not entered for mutiple site files with Country=USA and Canada are being created";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type. In the Service Section, Check on 'Project File' option| Enter Property Address with Country=Canada, State made blank.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "CANADA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = null;
                fileRequest.File.Properties[0].PropertyAddress[0].City = null;
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AB";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                
                Reports.TestStep = "Navigate to 'Project Workbench' Screen via home|Order Entry| Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Click on 'Create Site Files' section in Project Workbench screen";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter custom Site File Number | Select a state when Country=USA in the first row";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.ddlCountries.FASelectItem("USA");
                FastDriver.ProjectWorkBench.SiteFileNum.FASetText(Support.RandomString("NZA1") + FAKeys.Tab);

                Reports.TestStep = "Click on add button (+)";
                FastDriver.ProjectWorkBench.AddNewRow.FAClick();

                Reports.TestStep = "Enter custom Site File Number | Do not Select a State";
                FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(2, 2, TableAction.SetText, Support.RandomString("NAA2"));

                Reports.TestStep = "Click on Create button";
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalFailedErrorMessage);
                Support.AreEqual("2 File(s) failed.", FastDriver.ProjectWorkBench.TotalFailedErrorMessage.FAGetText().Clean());
                Support.AreEqual("2", FastDriver.ProjectWorkBench.ErrorMessagePane.FAGetText().Clean().CountOccurrences("State/Province is a required field. Please enter State/Province before saving.").ToString(),
                    "Verify whether Error Message contains: 'State/Province is a required field. Please enter State/Province before saving.' twice.");
                
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_589408_TC_597399()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify error message for State field being blank when Site File with Canada address is created from WCF";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Login to FAST IIS, Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                var FileNum1 = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(FileNum1.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Create a Site File with Canada Address | Do not Enter a state/Province| Enter an invalid ZipCode for the Project File created in step 1 and invoke CreateFile web method (FastFileService.svc) using WCFStorm application.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.ddlCountries.FASelectItem("CANADA");
                FastDriver.ProjectWorkBench.SiteFileNum.FASetText(Support.RandomString("NZA1") + FAKeys.Tab);
                FastDriver.ProjectWorkBench.nameZip.FASetText(Support.RandomString("NZZZASSDF1"));
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalFailedErrorMessage);
                Support.AreEqual("1 File(s) failed.", FastDriver.ProjectWorkBench.TotalFailedErrorMessage.FAGetText().Clean());
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ErrorMessagePane.FAGetText().Clean().Contains("State/Province is a required field. Please enter State/Province before saving."),
                    "Verify whether Error Message contains: 'State/Province is a required field. Please enter State/Province before saving.'.");

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_589408_TC_597477()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate State field for Canada address when there is change of country from Interntional to Canada in Site File creation";

                #region UI Interaction

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project file with mandatory fields, Property details & address, also Project File checkbox checked with CD Form type. In the Service Section, Check on 'Project File' option| Enter Property Address with Country=Canada, State made blank.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "CANADA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = null;
                fileRequest.File.Properties[0].PropertyAddress[0].City = null;
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AB";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to 'Project Workbench' Screen via home|Order Entry| Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Click on 'Create Site Files' section in Project Workbench screen";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);

                Reports.TestStep = "Enter custom Site File Number | Select a state when Country=USA in the first row for USA address";
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.State);
                FastDriver.ProjectWorkBench.ddlCountries.FASelectItem("USA");
                FastDriver.ProjectWorkBench.State.FASelectItem("CA");

                Reports.TestStep = "Change to any International Country from USA";
                FastDriver.ProjectWorkBench.ddlCountries.FASelectItem("AFGHANISTAN");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.State.Enabled, "The State field should be disabled.");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.nameZip.Enabled, "The Zip Code field should be disabled.");
                Support.AreEqual(@"", FastDriver.ProjectWorkBench.SiteFileNum.FAGetValue().Clean(), "The Site File Number field should be blank.");
                Support.AreEqual(@"", FastDriver.ProjectWorkBench.AddressLine1.FAGetValue().Clean(), "The Address Line field should be blank.");

                Reports.TestStep = "Change the country to Canada from International";
                FastDriver.ProjectWorkBench.ddlCountries.FASelectItem("CANADA");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.State.Enabled, "The State field should be enabled.");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.nameZip.Enabled, "The Zip Code field should be enabled.");
                Support.AreEqual(@"", FastDriver.ProjectWorkBench.SiteFileNum.FAGetValue().Clean(), "The Site File Number field should be blank.");
                Support.AreEqual(@"", FastDriver.ProjectWorkBench.AddressLine1.FAGetValue().Clean(), "The Address Line field should be blank.");

                Reports.TestStep = "Enter custom Site File Number and click on 'Create' button";
                FastDriver.ProjectWorkBench.SiteFileNum.FASetText(Support.RandomString("NAZC1"));
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.ErrorMessagePane);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ErrorMessagePane.FAGetText().Clean().Contains("State/Province is a required field. Please enter State/Province before saving."),
                    "Verify whether Error Message contains: 'State/Province is a required field. Please enter State/Province before saving.'.");

                Reports.TestStep = "Select a state when Country=Canada in the first row";
                FastDriver.ProjectWorkBench.ddlCountries.FASelectItem("CANADA");
                FastDriver.ProjectWorkBench.State.FASelectItem("AB");

                Reports.TestStep = "Click on Create button";
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual(@"1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText().Clean());

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion
    }

}