﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using System.Linq;         
using System.Collections.Generic;
using System.Threading;

namespace EscrowChargeProcess
{
    [CodedUITest]
    public class FMUC0050 : MasterTestClass
    {
        #region BAT
        #region Test FMUC0050_BAT0001
        [TestMethod]
        public void FMUC0050_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF_001_AF_001: To add and edit a Real Estate Broker/Agent.";
                #region data setup
                #endregion

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To Add a Real Estate Broker/Agent and add commission percent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER",CommissionPercent:"10",BrokerContactGABcode:"256");
                Reports.TestStep = "Validate commission amount and REB seller charge.";
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                //
                Reports.TestStep = "To validate that sellers broker is created (autosave).";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                Support.AreEqual(FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAGetText(), "Assumption Lender 1 for HUD Test Name 1", true);
                //
                Reports.TestStep = "To validate SellerCommissionAmt and Netchk amount";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.SellerCommissionAmt.FAGetText());
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.NetCheckAmount.FAGetText());
                //
                Reports.TestStep = "To validate the real-estate disbursement.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Success", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Payee", TableAction.Click, "Assumption Lender 1 for HUD Test Name 1").Status.ToString());
                //
                Reports.TestStep = "Validate that File balance summary for RealEstateBroker.";
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().Equals("1,000.00").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText().Equals("900.00").ToString());
                //
                Reports.TestStep = "To edit Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER", GABCode:"220");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                //
                Reports.TestStep = "To validate the real estate broker after Edit on REB Summary screen.";
                Support.AreEqual(FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAGetText(), "Harris Bank Woodstock", true);
                Reports.TestStep = "To validate the real estate broker after Edit on REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqual("Harris Bank Woodstock", FastDriver.RealEstateBrokerAgent.GabNameLabel1.FAGetText());
                Support.AreEqual("220", FastDriver.RealEstateBrokerAgent.IDCode.FAGetText());
                //
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
#endregion Test
        
        #region Test FMUC0050_BAT0002
        [Obsolete,TestMethod]
        public void FMUC0050_BAT0002()
        {
            Reports.TestDescription = "AF_001: To Edit Real Estate Broker/Agent.";
            Reports.StatusUpdate("This flow is covered in BAT0001", true);

        }
        #endregion Test
        //
        #region Test FMUC0050_BAT0003
        [TestMethod]
        public void FMUC0050_BAT0003()
        {//bat0003 and bat0004

            try
            {
                Reports.TestDescription = "AF_002: To add two instances of 3rd Party Disbursements,AF_003: To delete 3rd Party Disbursement Entry and verify.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = @"To Add a Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER",CommissionPercent:"10");
                //
                Reports.TestStep = "To Add and verify 3rd Party Disbursements.";
                string[] ThirdPartyDisburstment1 = FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("230", "300.00");
                Support.AreEqual("Success", ThirdPartyDisburstment1[0]);
                //
                Reports.TestStep = "Add and Verify that second instance of 3rd Party Disbursement is added.";
                string[] ThirdPartyDisburstment2 = FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("240", "400.00");
                Support.AreEqual("Success", ThirdPartyDisburstment2[0]);
                //
                Reports.TestStep = "Verify disbursement amount";
                Support.AreEqual("700.00", FastDriver.RealEstateBrokerAgent.ListingBrokerDisbursements.FAGetText().Trim());
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().Trim());
                Support.AreEqual("-600.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Trim());
                //
                Reports.TestStep = @"FM2793 : Verify that Payment Details button does not exist under 3rd party disbursement section";
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CheckPaymentDetailsButton(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsHeaderTable).ToString());

                Reports.TestStep = "To validate the 3rd party real-estate disbursement.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Success", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "300.00", "Payee", TableAction.Click, ThirdPartyDisburstment1[1]).Status.ToString());
                //
                Reports.TestStep = "To validate the second instance of3rd party real-estate disbursement.";
                Support.AreEqual("Success", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "400.00", "Payee", TableAction.Click, ThirdPartyDisburstment2[1]).Status.ToString());
                //
                Reports.TestStep = "To delete 3rd Party Disbursement Entry and validate the same.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                RealEstateBrokerAgentSummary.StructDeletionResult DelResult = FastDriver.RealEstateBrokerAgent.DeleteThirdPartyDisbursementEntry(ThirdPartyDisburstment1[1]);
                Support.AreEqual("Success", DelResult.Status.ToString());
                Support.AreEqual("400.00", FastDriver.RealEstateBrokerAgent.ListingBrokerDisbursements.FAGetText().Trim());
                Support.AreEqual("-300.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().Trim());
                //
                Reports.TestStep = "To validate the 3rd party real-estate disbursement is deleted.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual(@"False", FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains(ThirdPartyDisburstment1[1]).ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_BAT0004
        [Obsolete,TestMethod]
        public void FMUC0050_BAT0004()
        {
            Reports.TestDescription = "AF_003: To delete 3rd Party Disbursement Entry and verify.";
            Reports.StatusUpdate("This flow is covered in BAT0003", true);
        }
#endregion Test
        #region Test FMUC0050_BAT0005
        [TestMethod]
        public void FMUC0050_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF_004: To delete Real Estate Broker Instance.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = @"To Add a Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER",CommissionAmount:"100");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = @"To validate that seller's broker is created.";
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAGetText(), "Assumption Lender 1 for HUD Test Name 1", true);
                //
                Reports.TestStep = "To check pending commission check or 3rd party disbursements from the Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqualTrim("Assumption Lender 1 for HUD Test Name 1",FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Payee", TableAction.GetText).Message.ToString());
                Reports.TestStep = "To delete Real Estate Broker Instance and verify the message.";
                string DeletionMessage = "All information will be removed for this Real Estate Broker.  Continue?";

                RealEstateBrokerAgentSummary.StructDeletionResult DeletionResult = FastDriver.RealEstateBrokerAgentSummary.DeleteAgentBroker("SELLERBROKER", "Assumption Lender 1 for HUD Test Name 1", DeletionMessage);
                Support.AreEqual("Success", DeletionResult.Status.ToString());
                Support.AreEqual("True", DeletionResult.isErrorWarningCorrect.ToString());
                //
                Reports.TestStep = "To validate seller's broker is deleted (Active disbursement summary).";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("SellerName SellerLastName", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "1,000.00", "Payee", TableAction.GetText).Message.ToString().Trim());

                Reports.TestStep = "Validate File balance summary after RealEstateBroker is deleted."; //query what all fields to validate
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText().Equals("1,000.00").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText().Equals("1,000.00-").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText().Equals("1,000.00").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().Equals("1,000.00").ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0050_BAT0006
        [TestMethod]
        public void FMUC0050_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF_005: Cancel 1st New Other Real Estate Broker Instance Creation.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To Cancel 1st New Other Real Estate Broker Instance Creation.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER");
                Reports.TestStep = "To Cancel 1st New Other Real Estate Broker Instance Creation.";
                Reports.TestStep = "To validate that Real Estate Broker/Agent Summary screen is loaded.";
                Object obj=FastDriver.RealEstateBrokerAgent.CancelREBInstance(@"Cancel without saving changes?");
                bool isREBSummaryPageLoaded = obj.GetType().Equals(FastDriver.RealEstateBrokerAgentSummary.GetType());
                Support.AreEqual("True", isREBSummaryPageLoaded.ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
#endregion Test
        //
        #region Test FMUC0050_BAT0007
        [TestMethod]
        public void FMUC0050_BAT0007()
        {

            try
            {
                Reports.TestDescription = "AF_006 and AF_007: Cancel 2nd and 3rd New Other Real Estate Broker Instance Creation.";
                //
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of Other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerByGABCode("OTHER", "220");

                Reports.TestStep = "Create 2nd New Other Real Estate Broker Instance.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER");
                Reports.TestStep = "To Cancel 2nd New Other Real Estate Broker Instance Creation.";
                Reports.TestStep = "To validate that Real Estate Broker/Agent Summary screen is loaded.";
                bool isREBSummaryPageLoaded = FastDriver.RealEstateBrokerAgent.CancelREBInstance(@"Cancel without saving changes?").GetType().Equals(FastDriver.RealEstateBrokerAgentSummary.GetType());
                Support.AreEqual("True", isREBSummaryPageLoaded.ToString());
                //
                Reports.TestStep = "To create second instance of Other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Create 3rd New Other Real Estate Broker Instance.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER");
                Reports.TestStep = "To Cancel 3rd New Other Real Estate Broker Instance Creation.";
                Reports.TestStep = "To validate that Real Estate Broker/Agent Summary screen is loaded.";
                isREBSummaryPageLoaded = FastDriver.RealEstateBrokerAgent.CancelREBInstance(@"Cancel without saving changes?").GetType().Equals(FastDriver.RealEstateBrokerAgentSummary.GetType());
                Support.AreEqual("True", isREBSummaryPageLoaded.ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
#endregion Test
        //
        #region Test FMUC0050_BAT0008
        [Obsolete,TestMethod]
        public void FMUC0050_BAT0008()
        {

            try
            {
                Reports.TestDescription = "AF_007: Cancel 3rd / Subsequent New Other Real Estate Broker Instance Creation.";
                Reports.StatusUpdate("This flow is covered in BAT0007", true);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
#endregion Test
        //
        #region Test FMUC0050_BAT0009
        [TestMethod]
        public void FMUC0050_BAT0009()
        {

            try
            {
                Reports.TestDescription = "AF_008: Cancel Changes to Exit Real Estate Broker Instance.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of Other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", "256", "10");
                string GABNameBeforeReset = FastDriver.RealEstateBrokerAgent.GabNameLabel1.FAGetText() +" "+ FastDriver.RealEstateBrokerAgent.GabNameLabel2.FAGetText();
                string GABIDBeforeReset = FastDriver.RealEstateBrokerAgent.IDCode.FAGetText();
                FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Cancel Changes to Existing Real Estate Broker Instance.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER", GABCode:"220");
                //
                Reports.TestStep = "Compare REB Gab details before and after cancellation";
                Support.AreEqualTrim(string.IsNullOrWhiteSpace(GABNameBeforeReset) ? "" : GABNameBeforeReset, FastDriver.RealEstateBrokerAgent.ResetREBInstance(@"Cancel without saving changes?"));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqualTrim(GABIDBeforeReset,FastDriver.RealEstateBrokerAgent.IDCode.FAGetText());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #endregion
        #region REG
        [TestMethod]
        #region Test FMUC0050_REG0001
        public void FMUC0050_REG0001()
        {

            try
            {
                Reports.TestDescription = "ER_0001: User cancels entry of the FIRST new instance using Reset button on framework before save a new process instance.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of Seller Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER"); ;
                string GABNameBeforeReset = FastDriver.RealEstateBrokerAgent.GabNameLabel1.FAGetText() + " " + FastDriver.RealEstateBrokerAgent.GabNameLabel2.FAGetText();
                //
                Reports.TestStep = "To reset the real estate broker info.";
                Reports.TestStep = "Compare REB Gab details before and after cancellation";
                Support.AreEqualTrim(string.IsNullOrWhiteSpace(GABNameBeforeReset) ? "" : GABNameBeforeReset, FastDriver.RealEstateBrokerAgent.ResetREBInstance(@"Cancel without saving changes?"));

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0002
        [TestMethod]
        public void FMUC0050_REG0002()
        { 
            try
            {
                Reports.TestDescription = "ER_0002: User cancels entry of the SECOND instance use Reset button on framework before save a new process instance.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER","220");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "To reset the second instance of real estate broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "220");
                Object obj = FastDriver.RealEstateBrokerAgent.CancelREBInstance(@"Cancel without saving changes?");
                Reports.TestStep = "Validate if summary page is loaded";
                bool isREBSummaryPageLoaded = obj.GetType().Equals(FastDriver.RealEstateBrokerAgentSummary.GetType());
                Support.AreEqual("True", isREBSummaryPageLoaded.ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
         #endregion Test
        [Obsolete]
        [TestMethod]
        public void FMUC0050_REG0003()
        {
            Reports.TestDescription = "ER_0003: User cancels entry of the THIRD or SUBSEQUENT new instance use Reset button on framework before save a new process instance.";
            Reports.StatusUpdate("This flow is covered in BAT0006", true);
        }
        #region Test FMUC0050_REG0004
        [TestMethod]
        public void FMUC0050_REG0004()
        {

            Reports.TestDescription = "ER_0004: User cancels entry using Reset button on framework before saving changes to an EXISTING process instance.";
            Reports.TestStep = "Log into FAST application.";
            IISLOGIN();
            Reports.TestStep = "Create File";
            CreateFile(0);
            Reports.TestStep = "Create agent broker";
            FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDFLINSR1");
            Reports.TestStep = "Click on Done.";
            FastDriver.BottomFrame.Done();
            //
            Reports.TestStep = "To Reset the real estate broker info.";
            FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER", CommissionAmount: @"200");
            FastDriver.BottomFrame.Reset();
            //
            Reports.TestStep = "Click on Ok button.";
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            Reports.TestStep = "To verify the information after Reset.";
            Support.AreEqualTrim(@"HUDFLINSR1", FastDriver.RealEstateBrokerAgent.IDCode.FAGetText());
            Support.AreEqualTrim(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
        }
        #endregion
        #region Test FMUC0050_REG0005
        [TestMethod]
        public void FMUC0050_REG0005()
        {
            try
            {
                Reports.TestDescription = "ER_0005: User searches for a business party on ID Code and system does not find an exact match.and ER_0006 : Minimum reqd data";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "Invalid ID Code for the business party.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER","INVALID_ID");
                Support.AreEqualTrim(@"ID Code not found.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Navigate away from REB screen.";
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.RealEstateBrokerAgent.ValidateErrorWarningMessageInPopUp(@"Error(s) occured. See Message pane.");
                FastDriver.WebDriver.HandleDialogMessage(true, false);
               Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.ValidateErrorWarningMessageInMessagePane(@"BusOrgID: Business Party required").ToString());
                //
               Reports.TestStep = "Navigate away from REB screen.";
               FastDriver.LeftNavigation.ClickHome();
               FastDriver.WebDriver.HandleDialogMessage(false);
               FastDriver.WebDriver.HandleDialogMessage();
               Reports.TestStep = "Missing mandatory data in Real Estate Broker screen.";
               FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
               FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
               FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("220");
               FastDriver.BottomFrame.Done();
               FastDriver.WebDriver.HandleDialogMessage();
               FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
               Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.ValidateErrorWarningMessageInMessagePane(@"BusOrgID: Business Party required").ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
           
        }
        #endregion Test
        #region Test FMUC0050_REG0006
        [TestMethod]
        public void FMUC0050_REG0006()
        {
            Reports.TestDescription = "ER_0006: User saves a charge process instance without the minimum required data. (For Real Estate Broker, this is Real Estate Broker Name.).";
            Reports.StatusUpdate("This flow is covered in REG0005", true);
        }
        #endregion Test
        #region Test FMUC0050_REG0007
        [TestMethod]
        public void FMUC0050_REG0007() 
        {
            try
            {
                Reports.TestDescription = "ER_0007: The business party is a payee on an issued check and user tries to edit or replace it with another business party.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information";               
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER","220");
                //
                Reports.TestStep = "To enter commission amount.";                
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@"700.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                //
                Reports.TestStep = "Select the check and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("700.00");
                //
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "To select and edit the first other broker instance.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER", GABCode:"HUDOTHRBR1");
                //
                Reports.TestStep = "Validate error/warning message on editing real estate broker have issued check.";
                Support.AreEqual(@"A check has been issued for this Payee.  The Payee name cannot be changed.", FastDriver.WebDriver.HandleDialogMessage());
                //

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0008
        [TestMethod]
        public void FMUC0050_REG0008()
        {
            try
            {
                Reports.TestDescription = "ER_0008_ER_0009_BR_FM2837: After system initially calculates commission amount, user edits commission amount and then changes commission percent.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information";
                CreateFile(SalesPrice: 1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "220");
                //
                Reports.TestStep = "To enter commission amount.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@"700.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                //
                Reports.TestStep = "Select the check and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("700.00");
                //
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "To edit the commission amount by changing the commission percent and click cancel";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText("10" + FAKeys.Tab, true);
                Support.AreEqual(@"Commission percentage has changed. Do you wish to recalculate commission amount?", FastDriver.WebDriver.HandleDialogMessage(true, false));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqualTrim("700.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Reports.TestStep = "To edit the commission amount by changing the commission percent and click ok";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText("10" + FAKeys.Tab, true);
                Support.AreEqual(@"Commission percentage has changed. Do you wish to recalculate commission amount?", FastDriver.WebDriver.HandleDialogMessage(false));
                Reports.TestStep = "Decrease the issued real estate broker commission amount.";
                string Message = "A check has been issued for the previously entered charges.  The effect of your change may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total.  Please verify that the appropriate Trust Accounting entries have been made.  (I.e. should the issued check be cancelled?) Additionally, this change may result in the File being out-of-balance.  Do you wish to make this change?";
                string ActualMessage = FastDriver.WebDriver.HandleDialogMessage(true, true);
                Support.AreEqualTrim(Message, ActualMessage);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqualTrim("100.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                //
                Reports.TestStep = "To edit the commission amount and click cancel";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("300" + FAKeys.Tab, true);
                Reports.TestStep = "Verify the commission amount";
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqualTrim("100.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0050_REG0009
        /// <summary>
        /// FM2834  Calculation Optional  
        /// Calculation of commission is optional; user may enter a flat amount without entering a percentage.

        /// FM2724  Manual Commission Entry  
        /// User may enter a fixed dollar amount for commission amount.

        ///FM2836  Edit Commission Amount  
        ///User may edit commission amount at any time, whether it was originally calculated, recalculated, entered manually or previously modified.

        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0009()
        {

            try
            {
                Reports.TestDescription = "ER_0010_FM2834_FM2724_FM2836: Increases the issued commission amount.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(0);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "220");

                Reports.TestStep = "To enter commission amount.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@"700.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Select the check and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("700.00");

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "To select and edit the first other broker instance.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER", GABCode: "HUDOTHRBR1");
                //
                Reports.TestStep = "Validate error/warning message on editing real estate broker have issued check.";
                Support.AreEqual(@"A check has been issued for this Payee.  The Payee name cannot be changed.", FastDriver.WebDriver.HandleDialogMessage());
                //
                Reports.TestStep = "To edit the commission amount by changing commission percent.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"1000.00" + FAKeys.Tab);
                //  Support.AreEqual(@"Commission percentage has changed. Do you wish to recalculate commission amount?", FastDriver.WebDriver.HandleDialogMessage(false));
                //           
                Reports.TestStep = "To increase issued REB commission amount and click cancel";
                string Message = @"A check has been issued for the previously entered charges.  The effect of your change may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance.  You may create an additional disbursement for the amount of the difference or you may cancel your change. Would you like to create an additional disbursement for this Payee?";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "Check on active disbursement summary screen";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("300.00").ToString());
                //
                Reports.TestStep = "To increase the issued REB commission amount. and click ok";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"1000.00" + FAKeys.Tab);
                //
                Reports.TestStep = "User increases a REB commission amount after check is issued. CLick Ok";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true, true));
                //
                Reports.TestStep = "Check on active disbursement summary screen";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.CheckIfDisbursementExists("300.00").ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0050_REG0010
        /// <summary>
        /// ER_0011: User removes a 3rd party  disbursement entry after the 3rd party disbursement check is issued.
        /// FM2790  Enter Check Amount  
        ///   The user may enter a Check Amount to be paid to the 3rd party disbursement payee.
        /// FM2791  Create Pending Disbursement  
        ///   When the user enters a 3rd party disbursement, the system creates a pending disbursement in the Active Disbursement Summary.
        ///   FM2821  Create Comm. Disbursement  
        ///     When the broker has a positive Net Check Amount, the system adds a 'pending' disbursement to the real estate broker for the Net Check Amount 
        ///     in the Active Disbursement Summary.
        /// FM2792  CHK Payment Method  
        ///   The system automatically assigns the CHK payment method to the 3rd party disbursement check amount.
        /// FM2795  Remove 3rd Party Disbursement  
        ///   part 1 -The user may remove an existing 3rd party disbursement entry from the real estate broker instance, if the 3rd party disbursement check is still pending 
        ///   (i.e., has not been disbursed/issued). 
        ///   part 2 - If the check has already been issued, the system warns the user and allows the user to remove the disbursement entry,
        ///   and displays an Out of Balance indicator for the check in the Active Disbursements Summary.
        /// FM2725  HUD-1/Closing Statements  
        ///  The system does not post 3rd party disbursement check amounts on the HUD-1 Settlement Statement or the Closing Statement.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0010()
        {
            try
            {
                Reports.TestDescription = "ER_0011_FM2790_FM2791_FM2792_FM2795_FM2725: User removes a 3rd party disbursement entry after the 3rd party disbursement check is issued.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", CommissionPercent:"10");

                Reports.TestStep = @"To add third party disbursement payee and amount (FM2790).";               
                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "500");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "FM2791 FM2721 Pending disbursement, FM2792 -CHK Payment Method";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "500.00", "Status", TableAction.Click, "Pending");
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "500.00", "Funds", TableAction.Click, "Check");
                //
                Reports.TestStep = "Select the third party disbursement check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("500.00","Other Broker 1 for HUD Test Name 1 Other");

                Reports.TestStep = "FM2795 part 2 To remove third party payee.";
                Reports.TestStep = "User removes a 3rd party disbursement entry after the 3rd party disbursement check is issued.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER"); 
                string Message=@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.";
                RealEstateBrokerAgentSummary.StructDeletionResult DelResult=FastDriver.RealEstateBrokerAgent.DeleteThirdPartyDisbursementEntry("Other Broker 1 for HUD Test Name 1", Message);
                Support.AreEqual("True", DelResult.isErrorWarningCorrect.ToString());
                Support.AreEqual("Fail", DelResult.Status.ToString());
                //
                Reports.TestStep = "Void Disbursement";
                FastDriver.ActiveDisbursementSummary.VoidDisbursement("500.00");
                //
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                //
                Reports.TestStep = "User removes a 3rd party disbursement entry.";
                DelResult = FastDriver.RealEstateBrokerAgent.DeleteThirdPartyDisbursementEntry("Other Broker 1 for HUD Test Name 1");
                Support.AreEqual("Success", DelResult.Status.ToString());

                //
                if (AutoConfig.FormType == "HUD")
                {
                    Reports.TestStep = "Preview in HUD";
                    PerformPreviewDeliveryHUD();
                }
                else
                {
                    Reports.TestStep = "Preview in CD";
                    PerformPreviewDeliveryCD();

                }
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }


        }
        #endregion Test
        #region Test FMUC0050_REG0011
        /// <summary>
        /// ER_0012: User decreases or deletes a 3rd party disbursement check amount after the 3rd party disbursement check is issued.
        /// FM2796  Edit 3rd Party Check Amount  
        ///  The user may change a 3rd party disbursement check amount if the 3rd party disbursement check is still pending (has not been disbursed/issued).
        ///  - If the user increases the check amount after the check is issued, the system warns the user and prompts the user to add a new pending disbursement for the difference. 
        ///  - If the user chooses to cancel the prompt, the system prevents the check amount change and restores the original check amount.
        ///  - If the user decreases or deletes the check amount after the check is issued, the system warns the user and allows the user to override
        ///  the warning to decrease or delete the check amount. If the user chooses to override the warning, the system accepts the  
        ///  new check amount and displays an Out of Balance indicator for the original check in the Active Disbursements Summary.
        ///  FM2882 Decrease/Delete Paid by RE Bkr – CD file 
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0011()
        {

            try
            {
                Reports.TestDescription = "ER_0012_FM2791_FM2792_FM2796: User decreases or deletes a 3rd party disbursement check amount after the 3rd party disbursement check is issued.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", CommissionAmount:"100");

                Reports.TestStep = "To add third party disbursement payee.";
                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "500");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the third party disbursement check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("500.00","Other Broker 1 for HUD Test Name 1 Other");
               //
                Reports.TestStep = "To decrease the third party disbursement check amount. Click Cancel";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText("200"+FAKeys.Tab);
                //
                Reports.TestStep = "User decreases or deletes a 3rd party disbursement check amount after the 3rd party disbursement check is issued.CLick Cancel";
                string Message=@"A check has been issued for the previously entered charges.  The effect of your change may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total.  Please verify that the appropriate Trust Accounting entries have been made.  (I.e. should the issued check be cancelled?) Additionally, this change may result in the File being out-of-balance.  Do you wish to make this change?";                    
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true,false));
                //
                Reports.TestStep = "Check on active disbursement summary screen";
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.CheckIfDisbursementExists("500.00").ToString());
                //
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                Reports.TestStep = "To decrease the third party disbursement check amount. Click Ok";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText("200" + FAKeys.Tab);
                //
                Reports.TestStep = @"Click ok.User decreases or deletes a 3rd party disbursement check amount after the 3rd party disbursement check is issued.";
                Message = @"A check has been issued for the previously entered charges.  The effect of your change may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total.  Please verify that the appropriate Trust Accounting entries have been made.  (I.e. should the issued check be cancelled?) Additionally, this change may result in the File being out-of-balance.  Do you wish to make this change?";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage());
                //
                Reports.TestStep = "Check on active disbursement summary screen"; 
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.CheckOutOfBalanceIndicator("500.00").ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion
        #region Test FMUC0050_REG0012
        /// <summary>
        /// ER_0013: User increases a 3rd party disbursement check amount after the 3rd party disbursement check is issued.
        /// FM2883 Increase Amount Paid by RE Bkr - CD File
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0012()
        {

          try
           {
                Reports.TestDescription = "ER_0013: User increases a 3rd party disbursement check amount after the 3rd party disbursement check is issued.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER",BrokerInformationGABcode:"HUDFLINSR1",CommissionAmount: "100");
               // FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@"#"+FAKeys.Tab);
                Reports.TestStep = "To add third party disbursement payee.";
                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "500");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the third party disbursement check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("500.00", "Other Broker 1 for HUD Test Name 1 Other");
              
                Reports.TestStep = "To increase the third party disbursement check amount. and click cancel";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText("700"+FAKeys.Tab);
                //
                Reports.TestStep = "User increases a 3rd party disbursement check amount after the 3rd party disbursement check is issued. CLick Cancel";
                string Message = @"A check has been issued for the previously entered charges.  The effect of your change may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance.  You may create an additional disbursement for the amount of the difference or you may cancel your change. Would you like to create an additional disbursement for this Payee?";                    
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true,false));
              //
                Reports.TestStep = "Check on active disbursement summary screen";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("200.00").ToString());
              //
                Reports.TestStep = "To increase the third party disbursement check amount. and click ok";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText("700" + FAKeys.Tab);
                //
                Reports.TestStep = @"User increases a 3rd party disbursement check amount after the 3rd party disbursement check is issued. CLick Ok";            
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true, true));
                //
                Reports.TestStep = "Check on active disbursement summary screen";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.CheckIfDisbursementExists("200.00").ToString());


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0013
        /// <summary>
        /// FM2821 : Covered in REG0010
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0013()
        {

            try
            {
                Reports.TestDescription = "ER_0014: User increases a 3rd party disbursement check amount after the broker net commission check is issued effectively decrease the broker net commission check amount.";


                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information";
                CreateFile(0);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", CommissionAmount:"600");
                //
                Reports.TestStep = "To add third party disbursement payee.";
                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "200");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the third party disbursement check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("400.00");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "To increase the third party disbursement check amount.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText("700" + FAKeys.Tab);
                //
                Reports.TestStep = "User increases a 3rd party disbursement check amount after the 3rd party disbursement check is issued.";
                string Message = @"Broker net commission check is issued. Please verify that the appropriate trust accounting entries have been made.  Allow changes?";
                Support.AreEqual(Message.Clean(), FastDriver.WebDriver.HandleDialogMessage().Clean(),true);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0014

        [TestMethod]
        public void FMUC0050_REG0014()
        {
            try
            {
                Reports.TestDescription = "ER_0015: User decreases or deletes a 3rd party disbursement check amount, or removes a 3rd party disbursement entry, after the broker net commission check is issued  effectively increase the broker net commission";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information";
                CreateFile(0);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER",CommissionAmount:"600");

                Reports.TestStep = "To add third party disbursement payee.";

                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "200");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the third party disbursement check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("400.00");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "To decrease the third party disbursement check amount and click cancel";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText("100"+FAKeys.Tab);
                //
                Reports.TestStep = "User decreases or deletes a 3rd party disbursement check amount after the 3rd party disbursement check is issued.CLick Cancel";
                       
                string Message = "Broker net commission check is issued. The effect of your change results in a check amount that is greater than the one previously issued. An additional check in the amount of the difference may be created or an accounting adjustment for the previously issued item must be made. Would you like to issue an additional check for the difference?";

                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true, false));
                Reports.TestStep = "Check on active disbursement summary screen";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("False", FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains("100.00").ToString());
                //
                Reports.TestStep = "To decrease the third party disbursement check amount.and click ok";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText("100" + FAKeys.Tab);
                //
                Reports.TestStep = "User decreases a 3rd party disbursement check amount after the 3rd party disbursement check is issued. CLick Ok";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true, true));
                //
                Reports.TestStep = "Check on active disbursement summary screen";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("True", FastDriver.ActiveDisbursementSummary.CheckIfDisbursementExists("100.00").ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }


        }
        #endregion Test
        #region Test FMUC0050_REG0015
        [TestMethod]
        public void FMUC0050_REG0015()
        {

            try
           {
                Reports.TestDescription = "ER_0016_FM2821: User decreases or deletes a Credit Buyer amount or a Credit Seller amount after the broker's net commission check is issued & effectively increase the broker net commission amount.";

                 Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER",CommissionAmount:"1000");
        
                Reports.TestStep = "To create REB and enter Buyer credit amount and commission amount.";
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc", sellerCredit: 400.00);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(3000);

                Reports.TestStep = "Select the brokers net check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("600.00");
                FastDriver.BottomFrame.Done();
       //
                Reports.TestStep = "Edit broker to decrease seller credit and click cancel.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc",sellerCredit:200.00);
                Reports.TestStep = @"Click Cancel.User decreases or deletes a Credit Buyer amount or a Credit Seller amount after the broker's net commission check is issued  effectively increase the broker net commission amount.";
                string Message = "Broker net commission check is issued. The effect of your change results in a check amount that is greater than the one previously issued. An additional check in the amount of the difference may be created or an accounting adjustment for the previously issued item must be made. Would you like to issue an additional check for the difference?";
                string ExpectedMessage=FastDriver.WebDriver.HandleDialogMessage(true,false);
                Support.AreEqual(ExpectedMessage.Clean(),Message.Clean());
                Reports.TestStep = "Validate seller credit amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable.PerformTableAction("Seller Credit", "400.00", "Seller Credit", TableAction.Click);
                //
                Reports.TestStep = "Edit broker to decrease seller credit and click Ok.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc", sellerCredit: 200.00);
                Reports.TestStep = @"Click Ok.User decreases or deletes a Credit Buyer amount or a Credit Seller amount after the broker's net commission check is issued  effectively increase the broker net commission amount.";
                Message = "Broker net commission check is issued. The effect of your change results in a check amount that is greater than the one previously issued. An additional check in the amount of the difference may be created or an accounting adjustment for the previously issued item must be made. Would you like to issue an additional check for the difference?";
                ExpectedMessage = FastDriver.WebDriver.HandleDialogMessage(true, true);
                Support.AreEqual(ExpectedMessage.Clean(), Message.Clean());
                Reports.TestStep = "Validate seller credit amount.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual("Success", FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable.PerformTableAction("Seller Credit", "200.00", "Seller Credit", TableAction.Click).Status.ToString());

           }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0050_REG0016
        [TestMethod]
        public void FMUC0050_REG0016()
        {

            try
            {
                Reports.TestDescription = "ER_0017_FM2821: User increases a Credit Buyer amount or a Credit Seller amount after the broker's net commission check is issued & effectively decrease the broker net commission check amount.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER",CommissionAmount:"1000");
                //
                Reports.TestStep = "To create REB and enter Buyer credit amount and commission amount.";
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc", sellerCredit: 400.00);

                Reports.TestStep = @"Select the broker's check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("600.00");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "User increases a Credit Buyer amount or a Credit Seller amount after the brokers net commission check is issued effectively decreasing the broker net commission check amount.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc", sellerCredit: 600.00);
                //
                Reports.TestStep = "Verify the message";
                string Message = @"Broker net commission check is issued. You cannot change this amount.";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage());
                //

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
#endregion Test

        #region Test FMUC0050_REG0017
        [TestMethod]
        public void FMUC0050_REG0017()
        {

            try
            {
                Reports.TestDescription = "ER_0018: User deletes a Real Estate Broker instance that has issued checks (broker's net commission check, 3rd party disbursement check, or both).";


                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information";
                CreateFile(0);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER",CommissionAmount:"600");
                //
                Reports.TestStep = "To create REB and enter Buyer credit amount and commission amount.";
                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "200");
                //
                Reports.TestStep = "Select the third party disbursement check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("400.00");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "User deletes a Real Estate Broker instance that has issued checks (broker's net commission check, 3rd party disbursement check, or both).";
                string Message="A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.";
                RealEstateBrokerAgentSummary.StructDeletionResult DeletionResult = FastDriver.RealEstateBrokerAgentSummary.DeleteAgentBroker("OTHER", "Assumption Lender 1 for HUD Test Name 1", Message,false);
                Support.AreEqual("Success", DeletionResult.Status.ToString());
                Support.AreEqual("True", DeletionResult.isErrorWarningCorrect.ToString());
                //
                Reports.TestStep = "Void disbursement";
                FastDriver.ActiveDisbursementSummary.VoidDisbursement("400.00");
                //
                Reports.TestStep = "Delete a Real Estate Broker instance.";
                Message = @"All information will be removed for this Real Estate Broker.  Continue?";
                DeletionResult = FastDriver.RealEstateBrokerAgentSummary.DeleteAgentBroker("OTHER", "Assumption Lender 1 for HUD Test Name 1", Message);
                Support.AreEqual("Success", DeletionResult.Status.ToString());
                Support.AreEqual("True", DeletionResult.isErrorWarningCorrect.ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
#endregion Test
        //
        #region Test FMUC0050_REG0018
        [TestMethod]
        public void FMUC0050_REG0018()
        {

            try
            {
                Reports.TestDescription = "ER_0019: User deletes Real Estate Broker instance that does not have issued checks.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", BrokerInformationGABcode:"HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("600.00");
                Reports.TestStep = "to add third party disbursement payee.";
                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "200");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Delete a Real Estate Broker instance and click cancel";
                string Message = @"All information will be removed for this Real Estate Broker.  Continue?";
                RealEstateBrokerAgentSummary.StructDeletionResult DeletionResult1 = FastDriver.RealEstateBrokerAgentSummary.CancelDeletionOfAgentBroker("OTHER", "Other Broker 1 for HUD Test Name 1", Message);
                Support.AreEqual("Success", DeletionResult1.Status.ToString());
                Support.AreEqual("True", DeletionResult1.isErrorWarningCorrect.ToString());
               Reports.TestStep = "Delete a Real Estate Broker instance and click ok";

               RealEstateBrokerAgentSummary.StructDeletionResult DeletionResult2 = FastDriver.RealEstateBrokerAgentSummary.DeleteAgentBroker("OTHER", "Other Broker 1 for HUD Test Name 1", Message);
               Support.AreEqual("Success", DeletionResult2.Status.ToString());
               Support.AreEqual("True", DeletionResult2.isErrorWarningCorrect.ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
#endregion Test
        //
        #region Test FMUC0050_REG0019
        //FM2729
        [TestMethod]
        public void FMUC0050_REG0019()
        {

            try
            {
                Reports.TestDescription = "ER_0020_ER_0021: User decreases or deletes a Credit Buyer amount or a Credit Seller amount and also increase the credit Buyer amount after the broker's net commission check is issued  effectively increase the broker net";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDOTHRBR1", CommissionAmount: "1,000.00");
                //FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1,000.00");
                Thread.Sleep(2000);
                Reports.TestStep = "To enter Credit Buyer's (Selling) Broker.";
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.ScrollIntoView();

                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad(FastDriver.RealEstateBrokerAgent.CreditBuyerBroker);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                Thread.Sleep(2000);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("400" + FAKeys.Tab);

                Reports.TestStep = "Select the broker's net commission check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("600.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"User decreases or deletes a Credit Buyer amount or a Credit Seller amount after the broker's net commission check is issued  (click cancel)";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                Thread.Sleep(5000);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.ScrollIntoView();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad(FastDriver.RealEstateBrokerAgent.CreditBuyerBroker);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                Thread.Sleep(2000);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("200"+FAKeys.Tab);

                string Message = @"(Seller's or Buyer's) Broker net commission check is issued. The effect of your change results in a check amount that is greater than the one previously issued. An additional check in the amount of the difference may be created or an accounting adjustment for the previously issued item must be made. Would you like to issue an additional check for the difference?";
                Support.AreEqualTrim(Message, FastDriver.WebDriver.HandleDialogMessage(true, false));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual("400.00", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetValue());
                //
                Reports.TestStep = @"User decreases or deletes a Credit Buyer amount or a Credit Seller amount after the broker's net commission check is issued  (click ok)";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.ScrollIntoView();
                Thread.Sleep(5000);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad(FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                Thread.Sleep(2000);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("200" + FAKeys.Tab);

                Reports.TestStep = @"Validate message.";
                Support.AreEqualTrim(Message, FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual("200.00", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetValue());

                Reports.TestStep = @"User increases Credit (Seller's or Buyer's) Broker amount after the Seller's or Buyer's Broker's net commission check is issued. (click cancel)";
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("600" + FAKeys.Tab);

                Message = @"(Seller's or Buyer's) Broker net commission check is issued. You cannot change this amount.";
                Support.AreEqualTrim(Message, FastDriver.WebDriver.HandleDialogMessage(true,false));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = @"Validate CreditBuyerBrokerAmt.";
                Support.AreEqual("200.00", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetValue());
                //
                Reports.TestStep = @"User increases Credit (Seller's or Buyer's) Broker amount after the Seller's or Buyer's Broker's net commission check is issued. (click ok)";
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("600" + FAKeys.Tab);
                Support.AreEqualTrim(Message, FastDriver.WebDriver.HandleDialogMessage());
                Reports.TestStep = @"Validate CreditBuyerBrokerAmt.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual("200.00", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetValue());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0020
        [TestMethod]
        public void FMUC0050_REG0020()
        {

            try
            {
                Reports.TestDescription = "ER_0022_BR_FM2904: User has entered commission distributions without enter or calculate a commission amount and tries to save the broker instance.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDOTHRBR1");
                //
                Reports.TestStep = "User has entered commission distributions without Enter or calculating a commission amount and tries to save the broker instance.";
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc", sellerCredit: 400.00);
                FastDriver.BottomFrame.Done();
                string Message=@"Commission Amount is required if commission distributions are greater than zero.";
                Support.AreEqualTrim(Message, FastDriver.WebDriver.HandleDialogMessage());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0021
        [TestMethod]
        public void FMUC0050_REG0021()
        {

            try
            {
                Reports.TestDescription = "ER_0023: When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name. \n"
                +"ER_0024: When the user enters an invalid e-Mail address. \n"
                +"ER_0025: User tries to change a Business Party which has a Reference number specified against it.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of other Real Estate Broker/Agent";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDOTHRBR1");

                Reports.TestStep = "When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name.";
                FastDriver.RealEstateBrokerAgent.BrokerInformationEditName.FASetCheckbox(true);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.";
                string Message = @"Name field is required when Edit Name checkbox is selected.";
                Support.AreEqualTrim(Message, FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationEditName.FASetCheckbox(false);
                //
                Reports.TestStep = "When the user enters an invalid e-Mail address.";
                FastDriver.RealEstateBrokerAgent.BrokerInformationEdit.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress.FASetText(@"abc.com"+FAKeys.Tab);
                //
                Reports.TestStep = "Validate invalid email id.";
                Support.AreEqual(@"?",FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress.FAGetValue());
                //
                Reports.TestStep = "Validate Hover Text.";               
                string HoverText=FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress.FAGetAttribute("title");
                string ExpectedHoverText = "Email address is invalid.\r\nValid Examples:\r\n\txyz@abc.com\r\n\txyz@abc.com.uk\r\n\txyz_123@abc.com\r\n\txyz-12.wuv@abc.cnn.edu.uk";
                Support.AreEqual(ExpectedHoverText.Clean(), HoverText.Clean());

                Reports.TestStep = "To clear invalid email id.";
                FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress.FASetText("");

                Reports.TestStep = "To uncheck Edit.";
                FastDriver.RealEstateBrokerAgent.BrokerInformationEdit.FASetCheckbox(false);

                Reports.TestStep = "ER_0025: User tries to change a Business Party which has a Reference number specified against it.";
                FastDriver.RealEstateBrokerAgent.BrokerInformationReference.FASetText(@"1234567891"+FAKeys.Tab);

                Reports.TestStep = "To change the business party.";
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("220");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                Reports.TestStep = "User tries to change a Business Party which has a Reference number specified against it.";
                Message = "Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?";
                string ActualMessage=FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqualTrim(Message.Clean(), ActualMessage.Clean());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test

        #region Test FMUC0050_REG0022
        [TestMethod]
        public void FMUC0050_REG0022()
        {


                Reports.TestDescription = "ER_0024: When the user enters an invalid e-Mail address.";
                Reports.StatusUpdate("THis flow is covered in Reg0021",true);

        }
        #endregion Test 
        #region Test FMUC0050_REG0023
        [TestMethod]
        public void FMUC0050_REG0023()
        {
            try
            {
                Reports.TestDescription = "ER_0025: User tries to change a Business Party which has a Reference number specified against it.";
                Reports.StatusUpdate("THis flow is covered in Reg0021", true);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test 
        //
        #region Test FMUC0050_REG0024
        [TestMethod]
        public void FMUC0050_REG0024()
        {

            try
            {
                Reports.TestDescription = "BR_FM1160: To add a Real Estate Broker/Agent.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of Real Estate Broker/Agent";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1",BrokerContactGABcode:"256",CommissionPercent:"10");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
               
                Reports.TestStep = "To validate that seller's broker is created.";

                Support.AreEqual(FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAGetText(), "Flood Insurance 1 for HUD Testing Name 1", true);

                Reports.TestStep = "To validate the real-estate disbursement.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Success", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Payee", TableAction.Click, "Assumption Lender 1 for HUD Test Name 1").Status.ToString());
                //
                Reports.TestStep = "Validate that File balance summary for RealEstateBroker.";
                FastDriver.EscrowFileBalanceSummary.Open();
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().Equals("1,000.00").ToString());
                Support.AreEqual("True", FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText().Equals("900.00").ToString());

                Reports.TestStep = "Issue an active disbursement";
                Support.AreEqual("Issued",FastDriver.ActiveDisbursementSummary.IssueManualCheck("100.00"));             

                Reports.TestStep = "Verify the message on try to remove the REB instance when it has active disbursement on REB Summary screen";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                string Message = @"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.";
                RealEstateBrokerAgentSummary.StructDeletionResult DeletionResult = FastDriver.RealEstateBrokerAgentSummary.DeleteAgentBroker("SELLERBROKER", "Flood Insurance 1 for HUD Testing Name 1", Message,false);
                Support.AreEqual("Success", DeletionResult.Status.ToString());
                Support.AreEqual("True", DeletionResult.isErrorWarningCorrect.ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0050_REG0025
        /// <summary>
        /// FM2116  Required Data for RE Broker  
        ///  Required data to add an instance of real estate broker is broker name, except when the broker instance is created 
        ///  by adding an agent name in the Quick Order Entry or Open Order Wizard. In this case, the agent name creates 
        ///  the real estate broker charge process instance and is the required data to save the instance.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0025()
        {

            try
            {
                Reports.TestDescription = "BR_FM2116: Required Data for RE Broker.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                Reports.TestStep = "CReate QFE. Use Additional Role as Real Estate agent.";
                CreateQFEWithAdditionalRoleREB();

                Reports.TestStep = "To verify the real estate broker creation with additional role.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                Support.AreEqual("Success",FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction("#3","Flood Insurance 1 for HUD Testing Name 1","#4",TableAction.Click).Status.ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        //
        #region Test FMUC0050_REG0026
        [TestMethod]
        public void FMUC0050_REG0026()
        {

            try
            {
                Reports.TestDescription = "BR_FM3948_FM3924_FM2823_FD: One Seller's Broker, One Buyer's Broker, Multiple Other Brokers.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create one instance of SELLER Real Estate Broker/Agent";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1", BrokerContactGABcode: "256", CommissionPercent: "10");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"1000.00");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc", sellerCredit: 200.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "CReate Buyer's Broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER", "HUDFLINSR1", CommissionPercent: "20");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"2000.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "One Seller's Broker, One Buyer's Broker, Multiple Other Brokers.";
                Reports.TestStep = "Multiple Other Brokers.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDOTHRBR1", CommissionPercent: "30");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"3000.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "One Seller's Broker, One Buyer's Broker, Multiple Other Brokers.";
                Reports.TestStep = "Multiple Other Brokers.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDOTHRBR1");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
               
                Reports.TestStep = "Display Total Commission Entry Recap.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                FastDriver.RealEstateBrokerAgent.TotalCommissionTable.PerformTableAction("#1", @"Seller's (Listing) Broker Commission Amount:", "#1", TableAction.Click);
                FastDriver.RealEstateBrokerAgent.TotalCommissionTable.PerformTableAction("#1", @"Buyer's (Selling) Broker Commission Amount:", "#1", TableAction.Click);
                FastDriver.RealEstateBrokerAgent.TotalCommissionTable.PerformTableAction("#1", @"Other Broker Commission Amount:", "#1", TableAction.Click);

                Support.AreEqual(@"1,000.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionAmt.FAGetText());
                Support.AreEqual(@"2,000.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionAmt.FAGetText());
                Support.AreEqual(@"3,000.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionAmt.FAGetText());
                Support.AreEqual(@"6,000.00", FastDriver.RealEstateBrokerAgent.TotalBrokerCommisionAmt.FAGetText());
                //
                Support.AreEqual(@"0 %", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionPct.FAGetText());
                Support.AreEqual(@"0 %", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionPct.FAGetText());
                Support.AreEqual(@"0 %", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionPct.FAGetText());
                Support.AreEqual(@"0 %", FastDriver.RealEstateBrokerAgent.TotalBrokerCommisionPct.FAGetText());
                //
                Support.AreEqual("800.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText());
                Support.AreEqual(@"2,000.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                Support.AreEqual(@"3,000.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0027
        [TestMethod]
        public void FMUC0050_REG0027()
        {
            #region datasetup
            string EntityTitleAgent = "FMUC0068 GAB1 Name 1";
            #endregion

            try
            {
                Reports.TestDescription = "BR_FM2917_FM2918: RE Broker Default Entity Type.";
                //
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To pull business party from address book.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();

                FastDriver.RealEstateBrokerAgent.FindGAB("",false);

                Reports.TestStep = "Select a Title Agent Entity Type and search.";
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(EntiType: "Title Agent", EntityName: EntityTitleAgent);
               
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test 
        //
        //
        #region Test FMUC0050_REG0028
        /// <summary>
        /// FM2470  Delete RE Broker Instance  
        ///   The user may delete a Real Estate Broker instance. This deletes all information including charges and payees in the instance, 
        ///   and leaves the instance 'Available' for reentry, with the word 'Available' with the same sequence number as the deleted
        ///   instance in the navigation tree and the charge process summary. Deletion of the instance has no effect on issued checks.
        ///   Note: Deletion of a Broker will also delete the Broker's Contact.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0028()
        {

            try
            {
                Reports.TestDescription = "BR_FM2470: Delete RE Broker Instance.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create REB and enter Credit Seller's (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDOTHRBR1", BrokerContactGABcode: "256", CommissionPercent: "10");
                //
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"1000.00");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("400.00");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();

                Reports.TestStep = "Delete RE Broker Instance.";
                string Message=@"All information will be removed for this Real Estate Broker.  Continue?";
                RealEstateBrokerAgentSummary.StructDeletionResult DeletionResult = FastDriver.RealEstateBrokerAgentSummary.DeleteAgentBroker("OTHER", "Other Broker 1 for HUD Test Name 1", Message);
                //
                Reports.TestStep = "Validate message and Click on Ok button.";
                Support.AreEqual("True", DeletionResult.isErrorWarningCorrect.ToString());
                //
                Reports.TestStep = "validation after Deleting RE Broker Instance.";
                Support.AreEqual("Success", DeletionResult.Status.ToString());
                //
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction("#2","Available","#2",TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                Support.AreEqual("0.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual("0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetValue());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0029
        /// <summary>
        /// FM2902  Show Original Percentage Value  
        ///If the user edits the commission amount, the system shall retain the existing percentage value.

        /// </summary>

        [TestMethod]
        public void FMUC0050_REG0029()
        {

            try
            {
                Reports.TestDescription = "BR_FM2723_FM2835_ES15135  : Calculate Broker Commission. BR_FM2902: Show Original Percentage Value.";

               Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);

                Reports.TestStep = "To create REB and enter Credit Seller's (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1", CommissionPercent: "10");
                //
                Reports.TestStep = "To validate commission amount.";
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());

                Reports.TestStep = "Edits the commission amount.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER",CommissionAmount:"200");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that system retain the existing percentage value even if the user edits the commission amount.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqual("0.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
           
        }
        #endregion Test
        #region Test FMUC0050_REG0030

        [TestMethod]
        public void FMUC0050_REG0030()
        {

                Reports.TestDescription = "BR_FM2902: Show Original Percentage Value.";
                Reports.StatusUpdate("This flow is covered in FMUC0050", true);
        }
        #endregion Test
        #region Test FMUC0050_REG0031
        /// <summary>
        /// FM2822  Calculate Commission Charge Amount  
        ///   When the user calculates or manually enters or modifies a commission amount in the Commission Summary section:
        ///   If the Transaction Type is not Refinance or Loan, the system subtracts any Earnest Money Deposit held by this broker from the commission amount, 
        ///   and defaults the result to the Seller Charge field in the Commission Charge Amount section. The system clears any amount in the Buyer Charge field.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0031()
        {

            try
            {
                Reports.TestDescription = "BR_FM2822A: Calculate Commission Charge Amount.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information.";
                CreateFile(0);

                Reports.TestStep = "To create REB instance.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1", CommissionPercent: "10");

                Reports.TestStep = "Enter Buyer charge for commission amount.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@"200.00"+FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Thread.Sleep(2000);
                Reports.TestStep = "Enter Seller charge for commission amount.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText(@"100.00"+FAKeys.Tab,false);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Enter Earnest Money amount and Earnest money distribution equally.";
                FastDriver.DepositOutsideEscrow.Open();
                DepositOutsideEscrowParameters DOEParams=new DepositOutsideEscrowParameters();
                DOEParams.TotalDeposit=20.00;
                DOEParams.EarnerstMoneyAmount_0=20.00;
                FastDriver.DepositOutsideEscrow.Deposit(DOEParams);               
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the Earnest money deducted from commission amount in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue());
                Support.AreEqual("280.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0032
        /// <summary>
        /// FM2822  Calculate Commission Charge Amount  
        ///   When the user calculates or manually enters or modifies a commission amount in the Commission Summary section:
        ///   If the Transaction Type is Refinance or Loan, the system subtracts any Earnest Money Deposit held by this broker from the commission amount, 
        ///   and defaults the result to the Borrower Charge field in the Commission Charge Amount section.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0032()
        {

            try
            {
                Reports.TestDescription = "BR_FM2822B: Calculate Commission Charge Amount for Refinance file.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateRefinanceFile(false);

                Reports.TestStep = "To create REB and enter Credit Seller's (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1");

                Reports.TestStep = "Enter Buyer charge for commission amount.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@"200"+FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Enter Earnest Money amount and Earnest money distribution equally.";
                FastDriver.DepositOutsideEscrow.Open();
                DepositOutsideEscrowParameters DOEParams=new DepositOutsideEscrowParameters();
                DOEParams.TotalDeposit=20.00;
                DOEParams.EarnerstMoneyAmount_0=20.00;
                FastDriver.DepositOutsideEscrow.Deposit(DOEParams);               
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the Earnest money deducted from commission amount in REB screen.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Reports.TestStep = "Validate borrower charge.";
                Support.AreEqual("180.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue());
                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0033
        /// <summary>
        /// FM2825  Edit Broker Comm Check Details  
        /// The broker business party section includes the Check Details button and the user may 
        /// edit check description and voucher details for the broker commission charges.
        ///
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0033()
        {

            try
            {
                Reports.TestDescription = "BR_FM2825: Edit Broker Comm. Check Details.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);

                Reports.TestStep = "To create REB and enter Credit Seller's (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1", CommissionAmount: "100");
                                
                Reports.TestStep = "Edit Broker Comm. Check Details.";
                FastDriver.RealEstateBrokerAgent.BrokerInformationCheckDetails.FAClick();

                Reports.TestStep = "Edit description for REB.";
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.CheckDetailsDlg.Description.FASetText(@"Description for REB");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText(@"Voucher Info for REB");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the edited check details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationCheckDetails.FAClick();

                Reports.TestStep = "Verify description and voucher info for REB.";
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Description for REB", FastDriver.CheckDetailsDlg.Description.FAGetValue());
                Support.AreEqual("Voucher Info for REB", FastDriver.CheckDetailsDlg.VoucherInfo.FAGetText());
                FastDriver.DialogBottomFrame.ClickDone();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0034
        /// <summary>
        /// FM2728A
        /// When the user checks the Credit Selling Broker checkbox on the Listing Broker screen and enters a credit amount, 
        /// the system shall deduct this amount from the Listing Broker's Net Check Amount and 
        /// add the amount to the 'Credit From Other Broker' field on the Selling Broker screen.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0034()
        {

            try
            {
                Reports.TestDescription = "BR_FM2728A: Credit Sell Broker.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information.";
                CreateFile(0);

                Reports.TestStep = "To create REB and enter Credit Seller's (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1", CommissionAmount: "300");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.ScrollIntoView();
                Thread.Sleep(5000);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                Thread.Sleep(2000);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("100.00"+FAKeys.Tab);
                Thread.Sleep(1000);
                //seller's (Listing broker's) net check amount
                Reports.TestStep = @"system shall deduct this amount from the Listing Broker's Net Check Amount";
                Support.AreEqual("200.00", FastDriver.RealEstateBrokerAgent.NetCheckAmt.FAGetText());
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Create seller (listing) broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER");
                Reports.TestStep = @"Validate the Credit Selling Broker amount added to the 'Credit From Other Broker' field on the Selling Broker screen.";
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.CreditfromOtherBroker.FAGetText());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0050_REG0035
        /// <summary>
        /// FM2728B
        /// When the user checks the Credit Selling Broker checkbox on the Other Broker screen and enters a credit amount, 
        /// the system shall deduct this amount from the Other Broker's Net Check Amount and 
        /// add the amount to the 'Credit From Other Broker' field on the Selling Broker screen. 
        /// If the Selling Broker's Net Commission check is issued, the system shall disable the Credit Selling Broker field.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0035()
        {

            try
            {
                Reports.TestDescription = "BR_FM2728B: Credit Selling Broker.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information ";
                CreateFile(0);
                //
                Reports.TestStep = "To create REB of type other ";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDOTHRBR1", CommissionAmount: "300");
                Reports.TestStep = "enter Credit selling Broker amount.";
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.ScrollIntoView();
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("100.00" + FAKeys.Tab);
                //other broker's net check amount
                Reports.TestStep = "system shall deduct this amount from the Other Broker's Net Check Amount";
                Support.AreEqual("200.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText());
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                FastDriver.BottomFrame.Done();
                //
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER");
                Reports.TestStep = "Add the Credit Selling Broker amount to the 'Credit From Other Broker' field on the Selling Broker screen.";
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.CreditfromOtherBroker.FAGetText());
                //
                Reports.TestStep = "Issue the Selling Broker's Net Commission check";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("100.00");
                Reports.TestStep = "If the Selling Broker's Net Commission check is issued, the system shall disable the Credit Selling Broker field.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER");
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.ScrollIntoView();
                if(!FastDriver.RealEstateBrokerAgent.CreditSellerBroker.IsSelected())
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FAClick();
                //FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("400.00" + FAKeys.Tab);
                Reports.TestStep = "Verify the message";
                string Message = @"(Seller's or Buyer's) Broker net commission check is issued. You cannot change this amount.";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion
        #region Test FMUC0050_REG0036
        /// <summary>
        /// FM2729  Credit Listing Broker  
        ///When the user checks the Credit Listing Broker checkbox on the Selling Broker screen and enters a credit amount, 
        ///the system shall deduct this amount from the Selling Broker's Net Check Amount and 
        ///add the amount to the 'Credit From Other Broker' field on the Listing Broker screen.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0036()
        {

            try
            {
                Reports.TestDescription = "BR_FM2729A: Credit List Broker.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create REB and enter Credit Sellers (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Add the Credit Selling Broker amount to the Credit From Other Broker field on the Selling (Buyer's)Broker screen.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER", "HUDOTHRBR1",CommissionAmount:"200");
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.ScrollIntoView();
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("100.00"+FAKeys.Tab);
                //Buyers's (Selling broker's) net check amount
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                //
                Reports.TestStep = @"Verify Credit From Other Broker field on the Listing Broker scree";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.CreditfromOtherBroker.FAGetText());                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0050_REG0037
        /// <summary>
        ///When the user checks the Credit Listing Broker checkbox on the Other Broker screen and enters a credit amount,
        ///the system shall deduct this amount from the Other Broker's Net Check Amount and add the amount to the 'Credit From Other Broker' field on the Listing Broker screen.
        ///If the Listing Broker's Net Commission Check is issued, the system shall disable the Credit Listing Broker field.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0037()
        { 
            try
            {
                Reports.TestDescription = "BR_FM2729B: Credit List Broker.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information ";
                CreateFile(0);
                //
                Reports.TestStep = "To create REB of type other and enter Credit Seller's (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDOTHRBR1", CommissionAmount: "300");
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.ScrollIntoView();
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("100.00" + FAKeys.Tab);
                //other broker's net check amount
                Support.AreEqual("200.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText());
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText());
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Add the Credit Listing Broker amount to the 'Credit From Other Broker' field on the listing Broker screen.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER");
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.CreditfromOtherBroker.FAGetText());
                Reports.TestStep = @"Issued the listing Broker's Net Commission check ";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("100.00");
                Reports.TestStep = @"If the listing Broker's Net Commission check is issued, the system shall disable the Credit listing Broker field.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.ScrollIntoView();
                if (!FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.IsSelected())
                    FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FAClick();
                //FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("400.00" + FAKeys.Tab);
                Reports.TestStep = "Verify the message";
                string Message = @"(Seller's or Buyer's) Broker net commission check is issued. You cannot change this amount.";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0038
        /// <summary>
        /// FM3925  Uncheck Credit Checkbox to Disable and Delete Entry  
        ///  If the user checks the checkbox for Credit Seller, or Credit Buyer, or Credit Buyer's (Selling) Broker, or Credit Seller's (Listing) Broker, enters an amount, 
        ///  and then un-checks the checkbox, the system will disable the amount field and delete the amount.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0038()
        {

            try
            {
                Reports.TestDescription = "BR_FM3925: Uncheck Credit Checkbox to Disable and Delete Entry.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);

                Reports.TestStep = "To create REB of type other and enter Credit Seller's (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDFLINSR1", CommissionAmount: "400");

                Reports.TestStep = "To create other broker with credit Buyer amt, credit seller amt, listing broker amt, selling broker amt.";
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc",buyerCredit:20.00, sellerCredit: 10.00);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.ScrollIntoView();
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText(@"30.00" + FAKeys.Tab);

                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText(@"40.00"+FAKeys.Tab);

                Support.AreEqual("300.00",FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText());

                Reports.TestStep = "To uncheck credit Buyer amt, credit seller amt, listing broker amt, selling broker amt.";
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(false);
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(false);

                Reports.TestStep = "To validate other broker net commission amt.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                Support.AreEqual("370.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText());
                Reports.TestStep = "To validate the disabled fields";
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.IsEnabled().ToString());
                Support.AreEqualTrim("", FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FAGetText().ToString());
                Support.AreEqualTrim("", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetText().ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0039
        /// <summary>
        ///  FM3340  Buyer's (Selling) Broker Holding Earnest Money  
        /// When the Buyer's (Selling) Broker instance is created, the system will retrieve  the amount designated as 'Earnest Money Deposit Held by Buyer's Broker'
        /// from the Deposit Outside Escrow screen, and add it to the 'Holding Earnest Money Amount' field in the Commission Summary - Buyer's (Selling) Broker section.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0039()
        {

            try
            {
                Reports.TestDescription = "BR_FM3340: Buyer's (Sell) Broker Hold Earnest Money.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateRefinanceFile();
                Reports.TestStep = "Enter Buyer's Broker held by amount.";
                FastDriver.DepositOutsideEscrow.Open();
                DepositOutsideEscrowParameters DOEParams = new DepositOutsideEscrowParameters();
                DOEParams.TotalDeposit = 100.00;
                DOEParams.EarnerstMoneyHeldBy_0 = @"Buyer's Broker";
                DOEParams.EarnerstMoneyName_0 = @"Buyer's Broker";
                DOEParams.EarnerstMoneyAmount_0 = 100.00;
                FastDriver.DepositOutsideEscrow.Deposit(DOEParams);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "To create Buyers broker ";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER", "HUDOTHRBR1", CommissionAmount: "200");

                Reports.TestStep = "To validate Holding Earnest Money Amount in Buyer broker screen.";
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText());

             }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0040
        /// <summary>
        /// FM3341  Seller's (Listing) Broker Holding Earnest Money  
        /// When the Seller's (Listing) Broker instance is created, the system will retrieve  the amount designated as 'Earnest Money Deposit Held by Seller's Broker' 
        /// from the Deposit Outside Escrow screen, and add it to the 'Holding Earnest Money Amount' field in the Commission Summary - Seller's (Listing) Broker section.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0040()
        {

            try
            {
                Reports.TestDescription = "BR_FM3341: Seller's (List) Broker Hold Earnest Money.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateRefinanceFile();
                Reports.TestStep = "Enter Seller's Broker held by amount.";
                FastDriver.DepositOutsideEscrow.Open();
                DepositOutsideEscrowParameters DOEParams = new DepositOutsideEscrowParameters();
                DOEParams.TotalDeposit = 100.00;
                DOEParams.EarnerstMoneyHeldBy_0 = @"Seller's Broker";
                DOEParams.EarnerstMoneyName_0 = @"Seller's Broker";
                DOEParams.EarnerstMoneyAmount_0 = 100.00;
                FastDriver.DepositOutsideEscrow.Deposit(DOEParams);
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "To create Buyers broker ";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1", CommissionAmount: "200");

                Reports.TestStep = "To validate Holding Earnest Money Amount in Seller broker screen.";
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText());

                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0041
        /// <summary>
        /// FM2787  Calculate Net Check Amount  
        /// FM4709  Enter Real Estate Broker Charges  
        /// The system shall provide the ability to enter additional charges to the buyer and/or seller. 
        /// Note:  Broker Standard/Miscellaneous charges will be coded to HUD-1 line 704+ in Escrow Charge Setup.
        /// FM4710  Add Real Estate Broker Charges to Broker's Net Check Amount  
        /// The system shall add Real Estate Broker Charges to the broker's net check amount.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0041()
        {

            try
            {
                Reports.TestDescription = "BR_FM2787_FM4709_FM4710_FD_US596192: Calculate Net Check Amount.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:5000);
                Reports.TestStep = "Enter Buyer's Broker held by amount.";
                FastDriver.DepositOutsideEscrow.Open();
                DepositOutsideEscrowParameters DOEParams = new DepositOutsideEscrowParameters();
                DOEParams.TotalDeposit = 100.00;
                DOEParams.EarnerstMoneyHeldBy_0 = @"Buyer's Broker";
                DOEParams.EarnerstMoneyName_0 = @"Buyer's Broker";
                DOEParams.EarnerstMoneyAmount_0 = 100.00;
                FastDriver.DepositOutsideEscrow.Deposit(DOEParams);
                FastDriver.BottomFrame.Save();
                //
                Reports.TestStep = "Create Seller broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1", CommissionAmount: "1000");
                Reports.TestStep = "Create Buyer broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER", "HUDOTHRBR1", CommissionAmount: "1000");
                Reports.TestStep = "Navigate to Home Warranty screen & enter charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty");
                FastDriver.HomeWarrantyDetail.FindGABCode("HUDOTHRBR1");
                Thread.Sleep(5000);
                if (AutoConfig.FormType == "HUD")
                {
                    FastDriver.HomeWarrantyDetail.PaidBuyer.FASetText("300.00");
                    FastDriver.HomeWarrantyDetail.paidSeller.FASetText("300.00");
                    FastDriver.BottomFrame.Done();
                }
                else
                {
                    FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("300.00");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("300.00");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("300.00");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("300.00");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                    FastDriver.DialogBottomFrame.ClickDone();

                }
                Reports.TestStep = "To create sellers broker ";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.ScrollIntoView();
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText(@"100.00" + FAKeys.Tab);
                Support.AreEqual("600.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText());
                //
                Reports.TestStep = "To validate Homewarranty,Earnest Money held, credit from other broker.";
                Thread.Sleep(3000);
                //FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER"); //, CommissionAmount: "4000.00");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc", buyerCredit: 400.00, sellerCredit: 200.00);
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable,2,chargeDescription: "Desc", sellerCharge: 600.00);
                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "700.00");
                if (AutoConfig.FormType == "HUD")
                {
                    Support.AreEqual(@"700.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                    Support.AreEqual(@"-100.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                    Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.HomeWarrantyChargesRow.FAGetText().Contains("300.00 -").ToString());
                    Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.OtherChargesPaidByBrokerRow.IsDisplayed().ToString());
                }
                else
                {
                    Support.AreEqual(@"700.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                    Reports.TestStep = "In Real Estate Broker/Agent screen, the home warranty deduction should be removed and any charges for the home warranty paid by a broker should be added into the Other Charges Paid by Broker field";
                    Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.HomeWarrantyChargesRow.IsDisplayed().ToString());
                    Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.OtherChargesPaidByBrokerRow.IsDisplayed().ToString());
                    Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.OtherChargesPaidByBrokerRow.FAGetText().Contains("300.00 -").ToString());
                    Support.AreEqual(@"300.00", FastDriver.RealEstateBrokerAgent.OtherChargesPaidByBroker.FAGetText());
                    Support.AreEqual(@"-100.00", FastDriver.RealEstateBrokerAgent.NetCheckAmount.FAGetText());
                }
                //
                Reports.TestStep = "To create other broker with credit Buyer amt, credit seller amt, listing broker amt, selling broker amt.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDFLINSR1", CommissionAmount: "400.00");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Amount", 20.00, 10.00);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.ScrollIntoView();
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText(@"30.00" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText(@"40.00" + FAKeys.Tab);
                Reports.TestStep = "To validate  credit from other broker.";
                Support.AreEqual(@"300.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText());
                //
                Reports.TestStep = "To Edit Buyers broker ";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER");
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.ScrollIntoView();
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText(@"100.00" + FAKeys.Tab);
                Support.AreEqual("630.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                Thread.Sleep(3000);
                Reports.TestStep = "Validate for Buyer broker that charges for the home warranty paid by a broker should be added into the Other Charges Paid by Broker field.";
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Credit Desc", buyerCredit: 400.00, sellerCredit: 200.00);
                Thread.Sleep(3000);
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, 2, chargeDescription: "Desc", sellerCharge: 600.00);
                Thread.Sleep(3000);
                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "700.00");
                    if (AutoConfig.FormType == "HUD")
                    {
                        Support.AreEqual(@"-70.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                        Support.AreEqual(@"-70.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                        Support.AreEqual(@"400.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionAmt.FAGetText());
                    }
                    else
                    {
                        Support.AreEqual(@"-70.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                        Reports.TestStep = "In Real Estate Broker/Agent screen, the home warranty deduction should be removed and any charges for the home warranty paid by a broker should be added into the Other Charges Paid by Broker field";
                        Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.HomeWarrantyChargesRow.IsDisplayed().ToString());
                        Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.OtherChargesPaidByBrokerRow.IsDisplayed().ToString());
                        Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.OtherChargesPaidByBrokerRow.FAGetText().Contains("300.00 -").ToString());
                        Support.AreEqual(@"300.00", FastDriver.RealEstateBrokerAgent.OtherChargesPaidByBroker.FAGetText());
                        Support.AreEqual(@"-70.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());
                    }
                
               
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0042
        /// <summary>
        /// FM4854  Enter Ad Hoc Charges  
        ///System shall provide the ability to enter an unlimited number of ad hoc charges in the Real Estate Broker Charges charge grid.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0042()
        {

            try
            {
                Reports.TestDescription = "BR_FM4854: Enter Ad Hoc Charges.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);

                Reports.TestStep = "To create REB of type other";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDFLINSR1", CommissionAmount: "4000");

                Reports.TestStep = "Enter broker charges";
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, 2, chargeDescription: "Desc", sellerCharge: 600.00,GenerateNewRow:true);
                Reports.TestStep = "To enter second instance of Real Estate broker charges.";
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, 3, chargeDescription: @"Broker charge Description1", sellerCharge: 600.00, GenerateNewRow: true);

                Reports.TestStep = "To enter third instance of Real Estate broker charges.";
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, 4, chargeDescription: @"Broker charge Description2", sellerCharge: 500.00);

                Reports.TestStep = "Verify entered charges";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.PerformTableAction("Description", "Desc", "Seller Charge", TableAction.GetInputValue).Message.Equals("600.00").ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.PerformTableAction("Description", "Broker charge Description1", "Seller Charge", TableAction.GetInputValue).Message.Equals("600.00").ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.PerformTableAction("Description", "Broker charge Description2", "Seller Charge", TableAction.GetInputValue).Message.Equals("500.00").ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0043
       /// <summary>
       ///  FM2788  Enter 3rd Party Disbursement  
        ///   The user may enter zero, one or more 3rd party disbursements within a real estate broker instance.
        ///   FM2789  Enter 3rd Party Disb. Payee  
        ///   The user may enter ad hoc, or select from the address book, one or more 3rd party disbursement business party payees.
        ///   FM2794  Edit 3rd Party Check Details  
///The 3rd party disbursement section includes the Check Details button and the user may edit check description and voucher details for the 3rd party disbursement.

       /// </summary>


        [TestMethod]
        public void FMUC0050_REG0043()
        {

            try
            {
                Reports.TestDescription = "BR_FM2788_FM2789: Enter 3rd Party Disbursement.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(0);

                Reports.TestStep = "To create REB of type Credit Seller's (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", CommissionAmount: "100.00");

                Reports.TestStep = "To enter one third party disbursement payee and validate creation";
               Support.AreEqual("Success", FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", @"500")[0]);


                Reports.TestStep = "To enter two third party disbursement payees.";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();

                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementAdHoc.FAClick();

                Reports.TestStep = "Enter REB ad-hoc details.";
                FastDriver.BusOrgAdhocDlg.WaitForScreenToLoad();
                FastDriver.BusOrgAdhocDlg.Name1.FASetText(@"REB001");
                FastDriver.BusOrgAdhocDlg.City.FASetText(@"Albany");
                FastDriver.BusOrgAdhocDlg.State.FASelectItem(@"CA");
                FastDriver.BusOrgAdhocDlg.County.FASetText(@"Alameda");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "To validate that disbursement payees are created.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction("#2", "REB001", "#3", TableAction.Click);

                Reports.TestDescription = "BR_FM2794: Edit 3rd Party Check Details.";

                Reports.TestStep = "To validate that disbursement payees are created.";

                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction("#2", "Other Broker 1 for HUD Test Name 1", "#3", TableAction.Click);
               
                Reports.TestStep = "Edit 3rd Party Check Details.";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckDetails.FAClick();

                Reports.TestStep = "Edit description for REB.";
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.CheckDetailsDlg.Description.FASetText(@"Description for REB");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText(@"Voucher Info for REB");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Validate the edited check details";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction("#2", "Other Broker 1 for HUD Test Name 1", "#3", TableAction.Click);

                Reports.TestStep = "Click on 3rd Party Check Details.";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckDetails.FAClick();

                Reports.TestStep = "Verify description and voucher info for REB.";
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Description for REB",FastDriver.CheckDetailsDlg.Description.FAGetValue());
                Support.AreEqual("Voucher Info for REB", FastDriver.CheckDetailsDlg.VoucherInfo.FAGetText());
                FastDriver.DialogBottomFrame.ClickDone();

                

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0044

        [Obsolete,TestMethod]
        public void FMUC0050_REG0044()
        {

            try
            {
                Reports.TestDescription = "BR_FM2796A: Edit 3rd Party Check Amount.";
                Reports.StatusUpdate("This BR is covered in REG0043", true);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0045
        /// <summary>
        /// FM2795A  Remove 3rd Party Disbursement  
        ///The user may remove an existing 3rd party disbursement entry from the real estate broker instance, 
        ///if the 3rd party disbursement check is still pending (i.e., has not been disbursed/issued). 
        ///
        /// 
        ///FM2839  Add Disb. Amts to Broker Check  
        ///If the user removes a 3rd party disbursement entry from the real estate broker instance, 
        ///the system will add the 3rd party disbursement check amount to the broker's Net Commission Check amount.
        ///FM2796A
        ///The user may change a 3rd party disbursement check amount if the 3rd party disbursement check is still pending (has not been disbursed/issued)
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0045()
        {

            try
            {
                Reports.TestDescription = "BR_FM2795_FM2839: Remove 3rd Party Disbursement.BR_FM2796A: Edit 3rd Party Check Amount.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(0);

                Reports.TestStep = "To create REB of type Credit Seller's (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", CommissionAmount: "100.00");
                Reports.TestStep = "To enter one third party disbursement payee and validate creation";
                Support.AreEqual("Success", FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", @"500")[0]);
                //
                Reports.TestStep = "To validate brokers net commission after 3rd party disbursement is added";
                FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.ScrollIntoView();
                Support.AreEqual(@"-400.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText());

                Reports.TestStep = "To remove third party payee having no issued check.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");

                RealEstateBrokerAgentSummary.StructDeletionResult DelResult = FastDriver.RealEstateBrokerAgent.DeleteThirdPartyDisbursementEntry("Other Broker 1 for HUD Test Name 1");
                Support.AreEqual("Success", DelResult.Status.ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "To verify that third party chk amt is added to broker net chk amt after deleting third party.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqual(@"100.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText()); //-400+500
                //
                Reports.TestStep = "Edit 3rd Party Check Amount.";
                Support.AreEqual("Success", FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", @"500")[0]);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"300"+FAKeys.Tab);
                Reports.TestStep = "To verify the edited 3rd Party Check amount.";
                FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.ScrollIntoView();
                Support.AreEqual(@"-200.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0046

        [Obsolete,TestMethod]
        public void FMUC0050_REG0046()
        {

            try
            {
                Reports.TestDescription = "BR_FM2796A: Edit 3rd Party Check Amount.";
                Reports.StatusUpdate("This BR is covered in REG0045", true);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0047
        /// <summary>
        /// FM2796  Edit 3rd Party Check Amount  
        ///The user may change a 3rd party disbursement check amount if the 3rd party disbursement check is still pending (has not been disbursed/issued).
        ///If the user increases the check amount after the check is issued, the system warns the user and prompts the user to add a new pending disbursement for the difference.
        ///If the user chooses to cancel the prompt, the system prevents the check amount change and restores the original check amount. 
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0047()
        {

            try
            {
                Reports.TestDescription = "BR_FM2796B: User increases a 3rd party disbursement check amount after the 3rd party disbursement check is issued.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create REB of type other.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDFLINSR1", CommissionAmount: "100.00");
                //
                Reports.TestStep = "To enter one third party disbursement payee and validate creation";
                Support.AreEqual("Success", FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", @"500.00")[0]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select the third party disbursement check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("500.00","Other Broker 1 for HUD Test Name 1 Other");
                //
                Reports.TestStep = "To increase the third party disbursement check amount.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"600"+FAKeys.Tab);
                //
                Reports.TestStep = "Click Cancel if User increases a 3rd party disbursement check amount after the 3rd party disbursement check is issued.";
                string Message = @"A check has been issued for the previously entered charges. The effect of your change may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your change. Would you like to create an additional disbursement for this Payee?";
                Support.AreEqual(Message.Clean(true), FastDriver.WebDriver.HandleDialogMessage(true, false).Clean(true));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                //
                Reports.TestStep = "To verify the edited 3rd Party Check amount after clicking on cancel button on Msg for increasing the chk amt.";
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Contains("500").ToString());
                //
                Reports.TestStep = "Increase 3rd party disbursement.";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"700" + FAKeys.Tab);
                //
                Reports.TestStep = "Click ok if User increases a 3rd party disbursement check amount after the 3rd party disbursement check is issued.";
                Message = @"A check has been issued for the previously entered charges.  The effect of your change may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance.  You may create an additional disbursement for the amount of the difference or you may cancel your change. Would you like to create an additional disbursement for this Payee?";
                Support.AreEqual(Message.Clean(true), FastDriver.WebDriver.HandleDialogMessage().Clean(true));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "Verify the increased 3rd party disbursement.";
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Contains("700").ToString());
                //
                Reports.TestStep = "Verify the check for increased third party disbursement check amount.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Success",FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "200.00", "Amount", TableAction.Click).Status.ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0048
        /// <summary>
        /// FM2796  Edit 3rd Party Check Amount
        /// If the user decreases or deletes the check amount after the check is issued, the system warns the user and allows the user to override 
        /// the warning to decrease or delete the check amount. If the user chooses to override the warning, the system accepts the  new check amount and displays an Out of Balance indicator for the original check in the Active Disbursements Summary
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0048()
        {

            try
            {
                Reports.TestDescription = "BR_FM2796C: User decreases or deletes a 3rd party disbursement check amount, or removes a 3rd party disbursement entry, after the broker net commission check is issued – effectively increase the broker net commission che";
                //
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create REB of type other.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDFLINSR1", CommissionAmount: "600.00");
                //
                Reports.TestStep = "To enter one third party disbursement payee and validate creation";
                Support.AreEqual("Success", FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", @"200.00")[0]);
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Select the third party disbursement check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("200.00", "Other Broker 1 for HUD Test Name 1 Other");
                //
                Reports.TestStep = "To decrease the third party disbursement check amount.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"100" + FAKeys.Tab);
                Reports.TestStep = "Click cancel if User decreases or deletes a 3rd party disbursement check amount, or removes a 3rd party disbursement entry, after the broker net commission check is issued – effectively increasing the broker net commission check amount.";
                string Message = @"A check has been issued for the previously entered charges.  The effect of your change may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total.  Please verify that the appropriate Trust Accounting entries have been made.  (I.e. should the issued check be cancelled?) Additionally, this change may result in the File being out-of-balance.  Do you wish to make this change?";
                Support.AreEqualTrim(Message.Clean(), FastDriver.WebDriver.HandleDialogMessage(true, false).Clean());
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "Verify the 3rd party disbursement.";
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Contains("200").ToString());
                Reports.TestStep = "decrease 3rd party disbursement.";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"100"+FAKeys.Tab);
                //
                Reports.TestStep = "Click ok if User decreases or deletes a 3rd party disbursement check amount after the 3rd party disbursement check is issued.";
                Support.AreEqual(Message.Clean(), FastDriver.WebDriver.HandleDialogMessage().Clean());
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "Verify the decreased 3rd party disbursement.";
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue().Contains("100").ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0050_REG0049
        /// <summary>
        /// FM2840 A.  Recalculate Commission if Sale Price Changes  
        ///  INFORMATION ONLY - not a system requirement for this use case:
        ///  If commission amounts have been calculated as percentage of Sale Price, and a user changes the Sale Price in the Terms/Dates/Status section within FAST, 
        ///  the system will prompt the user to re-calculate the commission amounts for Listing/Selling/Other brokers.  If user chooses to re-calculate commission, 
        ///  the system updates the following values:
        ///  1. Total Commission Amount (Total Commission section)
        ///  2. Commission Amount (Commission Summary for Listing/Selling/Other broker)
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0049()
        {

            try
            {
                Reports.TestDescription = "BR_FM2840A: Recalculate Commission if Sale Price Changes.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To create REB of type Seller.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDOTHRBR1", CommissionPercent: "10");
                Support.AreEqual("100.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Navigate to TDS screen and Change Sales Price.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SetSalesPriceAmount(@"9,000.00");
                //
                Reports.TestStep = "Calculate commission amount after changing the sales price.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqual("900.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue()); 
                Support.AreEqual("900.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText());
                Support.AreEqual("900.00", FastDriver.RealEstateBrokerAgent.NetCheckAmt.FAGetText());
                Support.AreEqual("900.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0050
        /// <summary>
        /// FM2840 B. Recalculate Commission if Sale Price Changes 
        /// 3. Commission Amount Charge Section for Listing/Selling/Other broker:  
        ///  o If amount is charged to seller  - recalculate Seller Charge amount according to BRFM2822.
        ///  o If amount is charged to buyer, or to both buyer and seller - recalculate Seller Charge amount according to BRFM2822 and clear Buyer Charge. 
        ///  (User can re-edit Buyer Charge if necessary.)
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0050()
        {

            try
            {
                Reports.TestDescription = "BR_FM2840B: Recalculate Commission if Sale Price Changes(If amount is charged to buyer, or to both buyer and seller ).";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);

                Reports.TestStep = "To create Real Estate broker with commission percent if amount is charged to both buyer and seller.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", CommissionPercent: "10");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@"50.00"+FAKeys.Tab);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "To create Real Estate broker with commission percent if amount is charged to both buyer and seller.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText(@"150.00"+FAKeys.Tab);
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "To enter commission percent.";
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText(@"20" + FAKeys.Tab);
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Navigate to TDS screen and Change Sales Price.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SetSalesPriceAmount(@"9,000.00");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Calculate commission amount after changing the sales price.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqual("1,800.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue());
                Support.AreEqual("1,800.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                Support.AreEqual("1,800.00", FastDriver.RealEstateBrokerAgent.TotalBrokerCommisionAmt.FAGetText());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0051
        /// <summary>
        /// ES13440  Default Address for Broker  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///  System shall default the address as mailing address for the broker. 
        ///  If mailing address is not available, then system shall default the business address. 
        ///  If both mailing and business address are not available, then system shall show the address as blank.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0051()
        {

            try
            {
                Reports.TestDescription = "BR_ES13440ADM: ADM setup for BR_ES13440.BR_ES13440IIS_ES13439: Default Address for Broker";
                //Reg0051,Reg0052.
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                #region GAB255
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("255");
                Reports.TestStep = "Enter mailing address.";
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                Dictionary<string,string> MailingAddress255=  FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
                BusinessOrganizationParameters BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Mailing";
                BusOrgParams.AddressLine1 = @"Mailing Address Line1";
                BusOrgParams.AddressLine2 = @"Mailing Address Line2";
                BusOrgParams.AddressLine3 = @"Mailing Address Line3";
                BusOrgParams.AddressLine4 = @"Mailing Address Line4";
                BusOrgParams.City = "Brookfield";
                BusOrgParams.State = "WI";
                BusOrgParams.Zip = "53005";
                BusOrgParams.County = "Waukesha";
                string value="Success";
                if (!MailingAddress255.TryGetValue("Status",out value))
                {
                    
                    FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Mailing", BusOrgParams);
                    
                }

                Reports.TestStep = "Enter business address";

                Dictionary<string, string> BusinessAddress255 = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Business");
                BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Business";
                BusOrgParams.AddressLine1 = @"Business Address Line1";
                BusOrgParams.AddressLine2 = @"Business Address Line2";
                BusOrgParams.AddressLine3 = @"Business Address Line3";
                BusOrgParams.AddressLine4 = @"Business Address Line4";
                BusOrgParams.City = "Brookfield";
                BusOrgParams.State = "WI";
                BusOrgParams.Zip = "53005";
                BusOrgParams.County = "Waukesha";
                    if (!BusinessAddress255.TryGetValue("Status", out value))
                {

                    FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Business", BusOrgParams);
                    
                }

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion
                #region GAB256
                Reports.TestStep = "Search a GAB in Address Book and Click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("256");
                Reports.TestStep = "Remove mailing address.";
                if (!FastDriver.BusPartyOrgSetUp.RemoveAddress("Mailing"))
                    Reports.StatusUpdate("Mailing Address does not exist", true);
                //
                Reports.TestStep = "Enter billing address.";
                Dictionary<string, string> BillingAddress256 = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Billing");
                BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Billing";
                BusOrgParams.AddressLine1 = @"Billing Address Line1";
                BusOrgParams.AddressLine2 = @"Billing Address Line2";
                BusOrgParams.AddressLine3 = @"Billing Address Line3";
                BusOrgParams.AddressLine4 = @"Billing Address Line4";
                BusOrgParams.City = "Brookfield";
                BusOrgParams.State = "WI";
                BusOrgParams.Zip = "53005";
                BusOrgParams.County = "Waukesha";
                if (!BillingAddress256.TryGetValue("Status", out value))
                {
                    FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Billing", BusOrgParams);
                }

                Reports.TestStep = "Enter business address";

                Dictionary<string, string> BusinessAddress256 = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Business");
                BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Business";
                BusOrgParams.AddressLine1 = @"Business Address Line1";
                BusOrgParams.AddressLine2 = @"Business Address Line2";
                BusOrgParams.AddressLine3 = @"Business Address Line3";
                BusOrgParams.AddressLine4 = @"Business Address Line4";
                BusOrgParams.City = "Brookfield";
                BusOrgParams.State = "WI";
                BusOrgParams.Zip = "53005";
                BusOrgParams.County = "Waukesha";
                    if (!BusinessAddress256.TryGetValue("Status", out value))
                {

                    FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Business", BusOrgParams);

                }
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion
                #region GAB257
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("257");

                Reports.TestStep = "Remove mailing address.";
                if (!FastDriver.BusPartyOrgSetUp.RemoveAddress("Mailing"))
                    Reports.StatusUpdate("Mailing Address does not exist", true);

                Reports.TestStep = "Enter Billing address.";
                Dictionary<string, string> BillingAddress257 = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Billing");
                BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Billing";
                BusOrgParams.AddressLine1 = @"Billing Address Line1";
                BusOrgParams.AddressLine2 = @"Billing Address Line2";
                BusOrgParams.AddressLine3 = @"Billing Address Line3";
                BusOrgParams.AddressLine4 = @"Billing Address Line4";
                BusOrgParams.City = "Brookfield";
                BusOrgParams.State = "WI";
                BusOrgParams.Zip = "53005";
                BusOrgParams.County = "Waukesha";

                if (!BillingAddress257.TryGetValue("Status", out value))
                {
                    FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Billing", BusOrgParams);
                }

                    Reports.TestStep = "Remove Business address.";
                    if (!FastDriver.BusPartyOrgSetUp.RemoveAddress("Business"))
                        Reports.StatusUpdate("Business Address does not exist", true);
                
               
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion
                Reports.TestStep = "Log into FAST application IIS.";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Default Address for Broker with Mailing and Business addresses.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "255", CommissionPercent: "10");
                Reports.TestStep = "GetBroker address";
                Dictionary<string,string>  BrokerAddress= FastDriver.RealEstateBrokerAgent.GetBrokerAddress();
                //
                Reports.TestStep = "Compare Mailing and Business addresses.";
                bool result=CompareDefaultAddress(MailingAddress255,BrokerAddress);
                Support.AreEqual("True", result.ToString());
                Reports.TestStep = "Verify Default Address for Broker with Business and Billing addresses.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER", GABCode:"256");
                Dictionary<string, string> BrokerBusinessAddress = FastDriver.RealEstateBrokerAgent.GetBrokerAddress();
                result = CompareDefaultAddress(BusinessAddress256, BrokerBusinessAddress);
                Support.AreEqual("True", result.ToString());
                //
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER", GABCode: "257");
                Reports.TestStep = "Default Address for Broker without Mailing and Business addresses.";
                Dictionary<string, string> BrokerBlankAddress = FastDriver.RealEstateBrokerAgent.GetBrokerAddress();
                Support.AreEqual("True", ValidateBlankAddress(BrokerBlankAddress).ToString());
       
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0052
        [TestMethod]
        public void FMUC0050_REG0052()
        {
            Reports.TestDescription = "BR_ES13440IIS_ES13439: Default Address for Broker";
            Reports.StatusUpdate("THis flow is covered in Reg0051", true);

        }
        #endregion Test
        #region Test FMUC0050_REG0053

        [TestMethod]
        public void FMUC0050_REG0053()
        {

            try
            {
                Reports.TestDescription = "BR_ES13440ADMRevert: ADM setup revert for BR_ES13440.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("256");

                Reports.TestStep = "Enter Mailing Address.";
                Dictionary<string, string> MailingAddress256 = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
                BusinessOrganizationParameters BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Mailing";
                BusOrgParams.AddressLine1 = @"Mailing Address Line1";
                BusOrgParams.AddressLine2 = @"Mailing Address Line2";
                BusOrgParams.AddressLine3 = @"Mailing Address Line3";
                BusOrgParams.AddressLine4 = @"Mailing Address Line4";
                BusOrgParams.City = "Brookfield";
                BusOrgParams.State = "WI";
                BusOrgParams.Zip = "53005";
                BusOrgParams.County = "Waukesha";
                string value = "Success";
                    if (!MailingAddress256.TryGetValue("Status", out value))
                {
                    FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyOrgSetUp.AddressesApply.FAClick();
                }

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("257");
                Reports.TestStep = "Enter Business address.";
                Dictionary<string, string> BusinessAddress257 = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Business");
                 BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Business";
                BusOrgParams.AddressLine1 = @"Business Address Line1";
                BusOrgParams.AddressLine2 = @"Business Address Line2";
                BusOrgParams.AddressLine3 = @"Business Address Line3";
                BusOrgParams.AddressLine4 = @"Business Address Line4";
                BusOrgParams.City = "Brookfield";
                BusOrgParams.State = "WI";
                BusOrgParams.Zip = "53005";
                BusOrgParams.County = "Waukesha";

                    if (!BusinessAddress257.TryGetValue("Status", out value))
                    {
                        FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
                        FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Business", BusOrgParams);
                    }
                    else

                    FastDriver.BusPartyOrgSetUp.AddressesApply.FAClick();
                

         Reports.TestStep = "Enter Mailing address.";
         Dictionary<string, string> MailingAddress257 = FastDriver.BusPartyOrgSetUp.GetAddressDetails("Mailing");
         BusOrgParams = new BusinessOrganizationParameters();
         BusOrgParams.Addresstype = "Mailing";
         BusOrgParams.AddressLine1 = @"Mailing Address Line1";
         BusOrgParams.AddressLine2 = @"Mailing Address Line2";
         BusOrgParams.AddressLine3 = @"Mailing Address Line3";
         BusOrgParams.AddressLine4 = @"Mailing Address Line4";
         BusOrgParams.City = "Brookfield";
         BusOrgParams.State = "WI";
         BusOrgParams.Zip = "53005";
         BusOrgParams.County = "Waukesha";
         if (!(MailingAddress257.Keys.Equals("Status") && MailingAddress257.Values.Equals("Success")))
         {

             FastDriver.BusPartyOrgSetUp.SetNewAddressDetails(BusOrgParams);
         }
         else
         {
             FastDriver.BusPartyOrgSetUp.ChangeAddressDetails("Mailing", BusOrgParams);

         }

        Reports.TestStep = "Click on Done.";
         FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0054
        /// <summary>
        /// ES13647  Update Commission Amount when Commission Charge Amount changes  
        /// When Seller Charge and/or Buyer Charge for Commission Charge Amount is changed, system shall provide the user an option to override Commission Amount based on the calculation below. System shall remove Commission Amount % when Commission Amount is overridden.
        ///  Calculation of Commission Amount
        ///  Commission Amount = (Buyer Charge + Seller Charge of Commission Charge Amount) + Holding Earnest Money Amount (if applicable)
        ///  Scenario 1:
        ///  Commission % = 2
        ///  Commission Amount = $12,000.00
        ///  Commission Charge Amount: Seller charge = $12,000.00(first time populated from Commission Amt). 
        ///  Step 1: User updates Seller Charge to $14,000, Warning message is displayed for user to select the option to override commission amount or not make any changes. 
        ///  Warning Message:
        ///  "Commission Charge Amount has changed. Do you wish to override Commission Amount and remove Commission %?"
        ///  OK -> Commission Amount is overridden with Total Commission Charge Amt and % is removed. Commission Amount = $14,000.00, Seller Charge = $14,000.00
        ///  Cancel -> No changes will be made. Commission Amount = $12,000.00, Seller Charge = $12,000.00
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0054()
        {

            try
            {
                Reports.TestDescription = "BR_ES13647A: Update Commission Amount when Commission Charge Amount changes.";

                Reports.TestStep = "Log into FAST application IIS.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "Enter both commission percent and commission amount for REB";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", CommissionPercent: @"2.0000", CommissionAmount: @"12,000.00"+FAKeys.Tab);
                Support.AreEqual(@"12,000.00",FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                //
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Reports.TestStep = "Change commission seller charge.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("14,000.00"+FAKeys.Tab);
                //
                Reports.TestStep = "User charges buyer/Seller commission charge amount and cancel.";
                string Message = "Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true,false));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                //
                Reports.TestStep = "To validate the commission seller charge.";
                Support.AreEqual(@"12,000.00",FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(@"12,000.00",FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                //
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Reports.TestStep = "Change commission seller charge.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("14,000.00"+FAKeys.Tab);
                //
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "To validate the commission seller charge.";
                Support.AreEqual(@"0.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());
                Support.AreEqual(@"14,000.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(@"14,000.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0055
        /// <summary>
        /// ES13647  Update Commission Amount when Commission Charge Amount changes 
        /// Scenario 2:
        ///  Commission % = 2
        ///  Commission Amount = $12,000.00
        ///  Commission Charge Amount: Seller charge = $12,000.00(first time populated from Commission Amt). 
        ///
        ///  Step 1: User updates Seller Charge to $14,000 and Buyer Charge to $2000.00. Warning message is displayed for user to select the option to override commission amount or not make any changes.
        ///  Warning Message:
        ///  "Commission Charge Amount has changed. Do you wish to override Commission Amount and remove Commission %?"
        ///  OK -> Commission Amount is overridden with Total Commission Charge Amt and % is removed. Commission Amount = $16,000.00, Seller Charge = $14,000.00, Buyer Charge = $2000.00
        ///  Cancel -> No changes will be made. Commission Amount = $12,000.00, Seller Charge = $12,000.00

        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0055()
        {

            try
            {
                Reports.TestDescription = "BR_ES13647B: Update Commission Amount when Commission Charge Amount changes.";

                Reports.TestStep = "Log into FAST application IIS.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information.";
                CreateFile(0);
                //
                Reports.TestStep = "Enter both commission percent and commission amount for REB";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", CommissionPercent: @"2.0000", CommissionAmount: @"12,000.00" + FAKeys.Tab);
                Support.AreEqual(@"12,000.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                //
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Reports.TestStep = "Enter commission buyer charge.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("2,000.00" + FAKeys.Tab);
                //
                Reports.TestStep = "User charges buyer/Seller commission charge amount and cancel.";
                string Message = "Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true, false));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "Change commission Seller charge.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("14,000.00" + FAKeys.Tab);

                Reports.TestStep = "User charges buyer/Seller commission charge amount and cancel.";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true, false));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "To validate the commission seller charge.";
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                Support.AreEqual(@"12,000.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(@"12,000.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
//
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Reports.TestStep = "To verify commission Buyer charge.";
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue());

                Reports.TestStep = "Change commission Buyer charge.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("2,000.00" + FAKeys.Tab);
          //
                Reports.TestStep = "User charges buyer/Seller commission charge amount.";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "Change commission Seller charge.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("14,000.00" + FAKeys.Tab,true);

                Reports.TestStep = "User charges buyer/Seller commission charge amount and cancel.";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "To validate commission percent, Buyer charge, and seller charge.";
                Support.AreEqual(@"0.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());
                Support.AreEqual(@"16,000.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(@"2,000.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue());
                Support.AreEqual(@"14,000.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0056
        /// <summary>
        /// Scenario 3:
        ///   Commission % = 2
        ///   Commission Amount = $12,000.00
        ///   Commission Charge Amount: Seller charge = $12,000.00(first time populated from Commission Amt). 
        ///
        ///   Step 1: Enter Holding Earnest Money Amount under Deposits Outside Escrow as $5000.00. Seller Charge under Commission Charge Amount is updated to $7000.00
        ///
        ///   Step 2: User modifies Seller Charge to $15,000. Warning message is displayed for user to select the option to override commission amount or not make any changes.
        ///   Warning Message:
        ///   "Commission Charge Amount has changed. Do you wish to override Commission Amount and remove Commission %?"
        ///   OK -> Commission Amount is overridden and % is removed. Commission Amount = $20,000.00, Seller Charge = $15,000.00
        ///   Cancel -> No changes will be made. Commission Amount = $12,000.00, Seller Charge = $7000.00

        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0056()
        {

            try
            {
                Reports.TestDescription = "BR_ES13647C: Update Commission Amount when Commission Charge Amount changes.";

                Reports.TestStep = "Log into FAST application IIS.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "Enter both commission percent and commission amount for REB";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", CommissionPercent: @"2.0000", CommissionAmount: @"12,000.00" + FAKeys.Tab);
                Support.AreEqual(@"12,000.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                //

                Reports.TestStep = "Enter Earnest Money amount and Earnest money distribution equally.";
                FastDriver.DepositOutsideEscrow.Open();
                DepositOutsideEscrowParameters DOEParams = new DepositOutsideEscrowParameters();
                DOEParams.TotalDeposit = 5000.00;
                DOEParams.EarnerstMoneyAmount_0 = 5000.00;
                FastDriver.DepositOutsideEscrow.Deposit(DOEParams);
                FastDriver.BottomFrame.Save();
//
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Reports.TestStep = "To validate the commission seller charge.";
                Support.AreEqual(@"0.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());
                Support.AreEqual(@"12,000.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(@"7,000.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                
                Reports.TestStep = "Change commission Seller charge.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("15,000.00" + FAKeys.Tab);

                Reports.TestStep = "User charges buyer/Seller commission charge amount and cancel.";
                string Message = "Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage(true, false));
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "To validate the commission seller charge.";
                Support.AreEqual(@"0.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());
                Support.AreEqual(@"12,000.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(@"7,000.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                Reports.TestStep = "Change commission Seller charge.";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("15,000.00" + FAKeys.Tab);

                Reports.TestStep = "User charges buyer/Seller commission charge amount and CLick ok.";
                Message = "Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?";
                Support.AreEqual(Message, FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "To validate the commission seller charge.";
                Support.AreEqual(@"0.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());
                Support.AreEqual(@"20,000.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(@"15,000.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0057
        /// <summary>
        /// A.
        /// ES13441  Display Broker Details  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///   System shall display the Business Phone, Business Fax, Cell phone, Pager and email for the Broker, even if the contact exists.
        ///   Note: If the Bus Org has a Contact in the Attention field, the system shall populate the Sales Rep fields according to the following rules:
        ///   If Contact has Sales Rep 1 and Sales Rep 2, system populates Contact's Sales Rep 1 and Sales Rep 2.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0057()
        {

            try
            {
                Reports.TestDescription = "BR_ES13441A: Display Broker Details and salesrep-Broker.";
                Reports.TestStep = "Precodition for REG0057";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");
                //
                Reports.TestStep = "Get sales rep";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                Thread.Sleep(2000);
                //string Expected_SalesRep1 = FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem();
                //string Expected_SalesRep2 = FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem();
               // if(string.IsNullOrEmpty(Expected_SalesRep1))
              //  {
                    FastDriver.BusPartyContactSetup.SalesRep1.FASelectItemByIndex(1);
                    string Expected_SalesRep1 = FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem();
                //}
                //if (string.IsNullOrEmpty(Expected_SalesRep2))
                //{
                    FastDriver.BusPartyContactSetup.SalesRep2.FASelectItemByIndex(1);
                    string Expected_SalesRep2 = FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem();
               // }
                Reports.TestStep = "Get phone details";
                string Expected_BusinessPhoneTypeNumber = FastDriver.BusPartyContactSetup.BusNumber.FAGetValue();
                string Expected_BusinessFaxTypeNumber = FastDriver.BusPartyContactSetup.BusFaxNumber.FAGetValue();
                string Expected_EmailNumber = FastDriver.BusPartyContactSetup.EmailNumber.FAGetValue();
                string Expected_PagerNumber = FastDriver.BusPartyContactSetup.PagerNumber.FAGetValue();
                string Expected_CellularNumber = FastDriver.BusPartyContactSetup.CellularNumber.FAGetValue();

                Reports.TestStep = "BR_ES13441A: Display Broker Details and sales rep-Broker.";
                Reports.TestStep = "Login to IIS";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                Reports.TestStep = "CReate File";
                CreateFile(SalesPrice:1000);         
                Reports.TestStep = @"To validate the Broker's electronic info.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER","HUDFLINSR1");
                Thread.Sleep(2000);
                if (!FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FAGetSelectedItem().Equals("Contact, Flood Insurance 1",StringComparison.CurrentCultureIgnoreCase))
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItemBySendingKeys("contact");
                //
                Thread.Sleep(2000);
                Reports.TestStep = "Validate phole details and sales rep";
                Support.AreEqualTrim(Expected_BusinessPhoneTypeNumber, FastDriver.RealEstateBrokerAgent.ContactBusinessPhone.FAGetValue());
                Support.AreEqualTrim(Expected_BusinessFaxTypeNumber, FastDriver.RealEstateBrokerAgent.ContactBusinessFax.FAGetValue());
                Support.AreEqualTrim(Expected_CellularNumber, FastDriver.RealEstateBrokerAgent.ContactCellphone.FAGetValue());
                Support.AreEqualTrim(Expected_PagerNumber, FastDriver.RealEstateBrokerAgent.ContactPager.FAGetValue());
                Support.AreEqualTrim(Expected_EmailNumber, FastDriver.RealEstateBrokerAgent.ContactEmailAddress.FAGetValue());
                string SalesRep1=FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep1.FAGetSelectedItem();
                string SalesRep2=FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep2.FAGetSelectedItem();
                if (!SalesRep1.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1);
                else
                {
                    int index = SalesRep1.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1.Remove(index, 1));
                }
                //
                if (!SalesRep2.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2);
                else
                {
                    int index = SalesRep2.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2.Remove(index, 1));
                }
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0058
        /// <summary>
        /// B.
        /// ES13441  Display Broker Details  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///   System shall display the Business Phone, Business Fax, Cell phone, Pager and email for the Broker, even if the contact exists.
        ///   Note: If the Bus Org has a Contact in the Attention field, the system shall populate the Sales Rep fields according to the following rules:
        ///   If Contact has Sales Rep 1 and no Sales Rep 2, system populates Contact's Sales Rep 1 and Sales Rep 2 is blank.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0058()
        {

            try
            {
                Reports.TestDescription = "BR_ES13441BADM1: To change salesrep2-Broker's contact in ADM setup. and BR_ES13441BIIS1_ES13439: salesrep1 and salesrep2 blank.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");
                //                
                Reports.TestStep = "To change sales rep2.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                Thread.Sleep(2000);
                //                
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();

                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItemByIndex(0);
                Reports.TestStep = "Get Sales rep details";
                //string Expected_SalesRep1 = FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem();
                string Expected_SalesRep2 = FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem();
                //if (string.IsNullOrEmpty(Expected_SalesRep1))
                //{
                    FastDriver.BusPartyContactSetup.SalesRep1.FASelectItemByIndex(1);
                    string Expected_SalesRep1 = FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem();
                //}
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "BR_ES13441BIIS1_ES13439: salesrep1 and salesrep2 blank.";
                Reports.TestStep = "Login to IIS";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                Reports.TestStep = "CReate File";
                CreateFile(SalesPrice:1000);
                //              
                Reports.TestStep = "To validate salesrep1 and salesrep2 for the broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                Thread.Sleep(2000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItemBySendingKeys("contact");
                Thread.Sleep(1000);
                Reports.TestStep = "Validate Sales rep";
                string SalesRep1 = FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep1.FAGetSelectedItem();
                string SalesRep2 = FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep2.FAGetSelectedItem();
                if (!SalesRep1.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1);
                else
                {
                    int index = SalesRep1.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1.Remove(index, 1));
                }
                //
                if (!SalesRep2.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2);
                else
                {
                    int index = SalesRep2.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2.Remove(index, 1));
                }

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0059

        [TestMethod]
        public void FMUC0050_REG0059()
        {

            try
            {
                Reports.TestDescription = "BR_ES13441BIIS1_ES13439: salesrep1 and salesrep2 blank.";
                Reports.StatusUpdate("This flow is covered in REG0058", true);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0060
        /// <summary>
        /// C.
        /// ES13441  Display Broker Details  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///   System shall display the Business Phone, Business Fax, Cell phone, Pager and email for the Broker, even if the contact exists.
        ///   Note: If the Bus Org has a Contact in the Attention field, the system shall populate the Sales Rep fields according to the following rules:
        ///   If Contact has Sales Rep 2 and no Sales Rep 1, system populates Contact's Sales Rep 2 and Sales Rep 1 is blank.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0060()
        {

            try
            {
                Reports.TestDescription = "BR_ES13441BADM2: To change salesrep1 and sales rep2-Broker's contact in ADM setup. and BR_ES13441BIIS2_ES13439: salesrep1 blank and salesrep2.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");
                //                
                Reports.TestStep = "To change sales rep2.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                Thread.Sleep(2000);
                //                
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem(@"");
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem(@"QA03 FAST");
                Reports.TestStep = "Get Sales rep details";
                string Expected_SalesRep1 = FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem();
                string Expected_SalesRep2 = FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem();
                if (string.IsNullOrEmpty(Expected_SalesRep2))
                {
                    FastDriver.BusPartyContactSetup.SalesRep1.FASelectItemByIndex(1);
                    Expected_SalesRep2 = FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem();
                }
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Login to IIS";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                Reports.TestStep = "CReate File";
                CreateFile(SalesPrice:1000);        
                Reports.TestStep = "To validate salesrep1 and salesrep2 for the broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                Thread.Sleep(2000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItemBySendingKeys("contact");
                Thread.Sleep(2000);
                Reports.TestStep = "Validate Sales rep";
                string SalesRep1 = FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep1.FAGetSelectedItem();
                string SalesRep2 = FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep2.FAGetSelectedItem();
                if (!SalesRep1.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1);
                else
                {
                    int index = SalesRep1.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1.Remove(index, 1));
                }
                //
                if (!SalesRep2.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2);
                else
                {
                    int index = SalesRep2.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2.Remove(index, 1));
                }

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0061

        [TestMethod]
        public void FMUC0050_REG0061()
        {
                //Covered in reg0060
            Reports.TestDescription = "BR_ES13441BIIS2_ES13439: salesrep1 blank and salesrep2.";
            Reports.StatusUpdate("This flow is covered in REG0060", true);
           
        }
        #endregion Test
        #region Test FMUC0050_REG0062
        /// <summary>
        /// D.
        /// ES13441  Display Broker Details  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///   System shall display the Business Phone, Business Fax, Cell phone, Pager and email for the Broker, even if the contact exists.
        ///   Note: If the Bus Org has a Contact in the Attention field, the system shall populate the Sales Rep fields according to the following rules:
        ///   If Contact has no Sales Rep 1 and no Sales Rep 2, system populates Bus Org's Sales Rep values (blank or not).
        ///   ES13445  Contact Info if Active or Inactive  	7.6 1528 - Enhance RE Broker Screen in FAST
         ///   FAST shall always display the contact's information from the contact's GAB record, regardless of whether the contact's current Status is Active or Inactive.

        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0062()
        {

            try
            {
                Reports.TestDescription = "BR_ES13441BADM3: To change salesrep1 and sales rep2-Broker's contact in ADM setup. and IIS verification";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");
                Reports.TestStep = "To click on Edit button in Business Party Contacts List and check contact status.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.ContactList.PerformTableAction("#3", "Contact", "#3", TableAction.Click);
                SetGABContactStatus("Active", "HUDFLINSR1");
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");
                //                
                Reports.TestStep = "To change sales rep2.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                Thread.Sleep(2000);
                //                
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem(@"");
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem(@"");
                Reports.TestStep = "Get Sales rep details";
                string Expected_SalesRep1 = FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem();
                string Expected_SalesRep2 = FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Login to IIS";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                Reports.TestStep = "CReate File";
                CreateFile(SalesPrice:1000);
                //              
                Reports.TestStep = "To validate salesrep1 and salesrep2 for the broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                Thread.Sleep(2000);
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItemBySendingKeys("contact");
                Thread.Sleep(2000);
                Reports.TestStep = "Validate Sales rep";
                string SalesRep1 = FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep1.FAGetSelectedItem();
                string SalesRep2 = FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep2.FAGetSelectedItem();
                if (!SalesRep1.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1);
                else
                {
                    int index = SalesRep1.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1.Remove(index, 1));
                }
                //
                if (!SalesRep2.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2);
                else
                {
                    int index = SalesRep2.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2.Remove(index, 1));
                }

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0063

        [TestMethod]
        public void FMUC0050_REG0063()
        {
            Reports.TestDescription = "BR_ES13441BIIS2_ES13439: salesrep1 blank and salesrep2.";
            Reports.StatusUpdate("This flow is covered in REG0062", true);


        }
        #endregion Test
        #region Test FMUC0050_REG0064

        [TestMethod]
        public void FMUC0050_REG0064()
        {

            try
            {
                Reports.TestDescription = "BR_ES13441BADM4_revert: Revert ADM setup for Broker's salesrep1 and salesrep2.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");
                //                
                Reports.TestStep = "To change sales rep2.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                Thread.Sleep(2000);
                //                
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.SalesRep1.FASelectItem(@"QA03 FAST");
                FastDriver.BusPartyContactSetup.SalesRep2.FASelectItem(@"QA03 FAST");
                Reports.TestStep = "Get Sales rep details";
                string Expected_SalesRep1 = FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem();
                string Expected_SalesRep2 = FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0065
        /// <summary>
        ///ES13442  Broker’s Contact Related Rules for RE Broker Screen  	7.6 1528 - Enhance RE Broker Screen in FAST
         ///   The following rules shall apply only for the RE Broker | Broker’s Contact Details section
         ///   
        ///  ES13444  Use Primary Contact as Attention  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///  If the selected business party has a primary business contact in the global address book, the system defaults the primary contact's name to the Attention field 
        ///  and expands the Broker’s Contact Details section.
        ///  
        ///  ES13443  Display Broker’s Contact Details  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///  If a contact is selected in Attention dropdown for the broker, FAST shall expand the Broker's Contact Details section and 
        ///  populate the contact's name, address, city, state, zip code, country, business phone number and extension, business fax number, 
        ///  pager number, cellular number, and email address in the section. 
        ///  If there is no contact selected in the Attention field, FAST shall collapse the section
        ///  
        ///  ES13445  Contact Info if Active or Inactive  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///  FAST shall always display the contact's information from the contact's GAB record, regardless of whether the contact's current Status is Active or Inactive.
        ///
        ///  ES13447  Edit Electronic Contact Details of Broker’s Contact  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///  System shall provide ability to edit (on selection of edit checkbox) the electronic contact details of the Broker Contact.
           /// ES13449  Broker’s Contact Entered Using Edit Name  	7.6 1528 - Enhance RE Broker Screen in FAST
         ///   If the contact is added by using “Edit Name” feature, then system shall expand the Broker’s Contact details” 
        ///section and populate the name entered as Contact Name. System shall default the address and electronic contact details of the Broker for the broker contact.
        ///ES13450 Weekly Status Email 
        /// </summary>

        [TestMethod]
        public void FMUC0050_REG0065()
        {

            try
            {
                Reports.TestDescription = "BR_ES13444_ADMSETUP  : To change the contact info for the primary contact.BR_ES13443_IIS1_ES13442_ES13444_ES13445_ES13446_ES13447_ES13450: Verify the contact info for broker's primary contact.";

                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");
                //
                string PrimaryContact = FastDriver.BusPartyOrgSetUp.PrimaryContact.FAGetSelectedItem().Trim().ToString();
                if (string.IsNullOrEmpty(PrimaryContact))
                {
                    FastDriver.BusPartyOrgSetUp.PrimaryContact.FASelectItemByIndex(1);
                    PrimaryContact = FastDriver.BusPartyOrgSetUp.PrimaryContact.FAGetSelectedItem().Trim().ToString();
                }
                Reports.TestStep = "Go to business party contact for the Bus Org.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                string LastName = PrimaryContact.Split(',')[0];

                FastDriver.BusPartyContactsList.ContactList.PerformTableAction("#3", LastName, "#3", TableAction.Click);
                SetGABContactStatus("Active", "HUDFLINSR1");
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");

                Reports.TestStep = "To change the contact info for the contact.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
               // FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.BusNumber.FASetText(@"(111)111-1111");
                FastDriver.BusPartyContactSetup.BusFaxNumber.FASetText(@"(222)222-2222");
                FastDriver.BusPartyContactSetup.EmailNumber.FASetText(@"test@test.com");
                FastDriver.BusPartyContactSetup.PagerNumber.FASetText(@"(333)333-3333");
                FastDriver.BusPartyContactSetup.CellularNumber.FASetText(@"(444)444-4444");
                //
                Reports.TestStep = "Get details";
                string Expected_SalesRep1 = FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem();
                string Expected_SalesRep2 = FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem();
                string Expected_BusinessPhoneTypeNumber = FastDriver.BusPartyContactSetup.BusNumber.FAGetValue();
                string Expected_BusinessFaxTypeNumber = FastDriver.BusPartyContactSetup.BusFaxNumber.FAGetValue();
                string Expected_EmailNumber = FastDriver.BusPartyContactSetup.EmailNumber.FAGetValue();
                string Expected_PagerNumber = FastDriver.BusPartyContactSetup.PagerNumber.FAGetValue();
                string Expected_CellularNumber = FastDriver.BusPartyContactSetup.CellularNumber.FAGetValue();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "BR_ES13443_IIS1_ES13442_ES13444_ES13445_ES13446_ES13447_ES13450: Verify the contact info for broker's primary contact.";

                Reports.TestStep = "Login to IIS";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                Reports.TestStep = "CReate File";
                CreateFile(SalesPrice:1000);
                //              
                Reports.TestStep = "To validate the contact info for active contact";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                //FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem(@"Contact, Flood Insurance 1");
                string SalesRep1= FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep1.FAGetSelectedItem();
                string SalesRep2 = FastDriver.RealEstateBrokerAgent.BrokerInformationSalesRep2.FAGetSelectedItem();
                //
                if (!SalesRep1.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1);
                else
                {
                    int index = SalesRep1.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep1, SalesRep1.Remove(index, 1));
                }
                //
                if (!SalesRep2.Contains(','))
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2);
                else
                {
                    int index = SalesRep2.IndexOf(',');
                    Support.AreEqualTrim(Expected_SalesRep2, SalesRep2.Remove(index, 1));
                }
                Support.AreEqualTrim(PrimaryContact, FastDriver.RealEstateBrokerAgent.BrokerContactsName.FAGetText());
                Support.AreEqualTrim(Expected_BusinessPhoneTypeNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsBusinessPhone.FAGetValue());
                Support.AreEqualTrim(Expected_BusinessFaxTypeNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsBusinessFax.FAGetValue());
                Support.AreEqualTrim(Expected_EmailNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsEmailAddress.FAGetValue());
                Support.AreEqualTrim(Expected_CellularNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsCellphone.FAGetValue());
                Support.AreEqualTrim(Expected_PagerNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsPager.FAGetValue());
                //
                Reports.TestStep = "To edit the contact info of the Broker's contact.";
                FastDriver.RealEstateBrokerAgent.ContactEdit.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.ContactBusinessPhone.FASetText(@"(111)111-2222");
                FastDriver.RealEstateBrokerAgent.ContactBusinessFax.FASetText(@"(222)333-2222");
                FastDriver.RealEstateBrokerAgent.ContactEmailAddress.FASetText(@"testedit@test.com");
                FastDriver.RealEstateBrokerAgent.ContactCellphone.FASetText(@"(444)555-4444");
                FastDriver.RealEstateBrokerAgent.ContactPager.FASetText(@"(333)333-6666");
                Reports.TestStep = "ES13450 Weekly Status Email ";
                FastDriver.RealEstateBrokerAgent.ContactweeklyEmailStatus.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0066

        [TestMethod]
        public void FMUC0050_REG0066()
        {

            try
            {
                Reports.TestDescription = "BR_ES13443_IIS1_ES13442_ES13444_ES13445_ES13446_ES13447_ES13450: Verify the contact info for broker's primary contact.";
                Reports.StatusUpdate("This flow is covered in REG0065", true);

            }

            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0067
        /// ES13443  Display Broker’s Contact Details  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///  If a contact is selected in Attention dropdown for the broker, FAST shall expand the Broker's Contact Details section and populate the contact's name, 
        ///  address, city, state, zip code, country, business phone number and extension, business fax number, pager number, cellular number, and email address
        /// in the section. If there is no contact selected in the Attention field, FAST shall collapse the section.

        [TestMethod]
        public void FMUC0050_REG0067()
        {

            try
            {
                Reports.TestDescription = "BR_ES13443_ADM_removeprimarycontact : Remove the primary contact for the Busorg.";
                Reports.TestDescription = "BR_ES13443_IIS2_ES13442_ES13445_ES13446 : Verify the contact info for broker's contact selected from Attention dropdown.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");

                Reports.TestStep = "To remove the contact from the primary contact field.";
                FastDriver.BusPartyOrgSetUp.PrimaryContact.FASelectItemByIndex(0);
                Reports.TestStep = "Go to business party contact for the Bus Org.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyContactsList.WaitForScreenToLoad();
                FastDriver.BusPartyContactsList.ContactList.PerformTableAction("#3", "Contact", "#3", TableAction.Click);
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");

                Reports.TestStep = "To change the contact info for the contact.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.Version.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                FastDriver.BusPartyContactSetup.BusNumber.FASetText(@"(111)111-1111");
                FastDriver.BusPartyContactSetup.BusFaxNumber.FASetText(@"(222)222-2222");
                FastDriver.BusPartyContactSetup.EmailNumber.FASetText(@"test@test.com");
                FastDriver.BusPartyContactSetup.PagerNumber.FASetText(@"(333)333-3333");
                FastDriver.BusPartyContactSetup.CellularNumber.FASetText(@"(444)444-4444");
                //
                Reports.TestStep = "Get details";
                string Expected_SalesRep1 = FastDriver.BusPartyContactSetup.SalesRep1.FAGetSelectedItem();
                string Expected_SalesRep2 = FastDriver.BusPartyContactSetup.SalesRep2.FAGetSelectedItem();
                string Expected_BusinessPhoneTypeNumber = FastDriver.BusPartyContactSetup.BusNumber.FAGetValue();
                string Expected_BusinessFaxTypeNumber = FastDriver.BusPartyContactSetup.BusFaxNumber.FAGetValue();
                string Expected_EmailNumber = FastDriver.BusPartyContactSetup.EmailNumber.FAGetValue();
                string Expected_PagerNumber = FastDriver.BusPartyContactSetup.PagerNumber.FAGetValue();
                string Expected_CellularNumber = FastDriver.BusPartyContactSetup.CellularNumber.FAGetValue();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Login to IIS";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                Reports.TestStep = "Create File";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "To verify that contact info is collapsed when attention value for Broker is blank.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                Support.AreEqualTrim("", FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FAGetSelectedItem());
                Support.AreEqualTrim("False", FastDriver.RealEstateBrokerAgent.BrokerContactsName.IsDisplayed().ToString());
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItemBySendingKeys("Contact");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "To select the contact for the Broker from the attention field and verify the contact info.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER");
                Support.AreEqualTrim("Contact, Flood Insurance 1", FastDriver.RealEstateBrokerAgent.BrokerContactsName.FAGetText());
                Support.AreEqualTrim(Expected_BusinessPhoneTypeNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsBusinessPhone.FAGetValue());
                Support.AreEqualTrim(Expected_BusinessFaxTypeNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsBusinessFax.FAGetValue());
                Support.AreEqualTrim(Expected_EmailNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsEmailAddress.FAGetValue());
                Support.AreEqualTrim(Expected_CellularNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsCellphone.FAGetValue());
                Support.AreEqualTrim(Expected_PagerNumber, FastDriver.RealEstateBrokerAgent.ContactDetailsPager.FAGetValue());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0068

        [TestMethod]
        public void FMUC0050_REG0068()
        {
            Reports.TestDescription = "BR_ES13443_IIS2_ES13442_ES13445_ES13446 : Verify the contact info for broker's contact selected from Attention dropdown.";
            Reports.StatusUpdate("This flow is covered in REG0067", true);

        }
        #endregion Test
        #region Test FMUC0050_REG0069
        /// <summary>
        /// ES13449  Broker’s Contact Entered Using Edit Name  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///  If the contact is added by using “Edit Name” feature, then system shall expand the Broker’s Contact details” section and 
        ///  populate the name entered as Contact Name. System shall default the address and electronic contact details of the Broker for the broker contact.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0069()
        {

            try
            {
                Reports.TestDescription = "BR_ES13449: Broker's Contact entered us Edit Name.";
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                Reports.TestStep = "Create File";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Check Edit Name checkbox.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER");
                FastDriver.RealEstateBrokerAgent.BrokerInformationEditName.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.BrokerInformationNameEdit.FASetText(@"ContactName"+FAKeys.Tab);
                Support.AreEqual("ContactName", FastDriver.RealEstateBrokerAgent.BrokerContactsName.FAGetText());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0070

        [TestMethod]
        public void FMUC0050_REG0070()
        {

            //review as this BR is removed from usecase doc

            try
            {
                Reports.TestDescription = "BR_ES13451 : Broker's Contact entered us Modify GAB request.";
                Reports.TestStep = "Login to IIS";
                IISLOGIN();
                Reports.TestStep = "Create File";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Click Find button.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad(FastDriver.RealEstateBrokerAgent.BrokerInformationFind);
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                Reports.TestStep = "Enter ID code and click on Find and select the search result and click on Modify GAB.";
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "HUDFLINSR1",ClickDone:false);
                FastDriver.AddressBookSearchDlg.ModifyGAB.FAClick();

                Reports.TestStep = "Add new contact.";

                FastDriver.GABEntryRequestDlg.WaitForDialogToLoad();
                FastDriver.GABEntryRequestDlg.ContactsAdd.FAClick();
                FastDriver.GABEntryRequestDlg.ContactsFirstName.FASetText("Newcontact");
                FastDriver.GABEntryRequestDlg.ContactsLastName.FASetText("Last");
                FastDriver.GABEntryRequestDlg.ContactsPhonesBusinessPhoneNumber.FASetText(@"(121)212-1212");
                FastDriver.GABEntryRequestDlg.ContactsPhonesBusinessFaxNumber.FASetText(@"(232)323-2323");
                FastDriver.GABEntryRequestDlg.ContactsPhonesEmailNumber.FASetText(@"contact@test.com");
                FastDriver.GABEntryRequestDlg.ContactsPhonesPagerNumber.FASetText(@"(343)434-3434");
                FastDriver.GABEntryRequestDlg.ContactsPhonesCellularNumber.FASetText(@"(454)545-4545");
                FastDriver.DialogBottomFrame.ClickDone();
                Thread.Sleep(4000);
                Reports.TestStep = "Verify the contact AND CONTACT DETAILS ADDED VIA Modify GAB.";
                FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.BrokerInformationEditName.IsSelected().ToString());
                Support.AreEqual(@"Newcontact Last", FastDriver.RealEstateBrokerAgent.BrokerInformationNameEdit.FAGetValue());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.ContactEdit.IsSelected().ToString());
                Support.AreEqual(@"(121)212-1212", FastDriver.RealEstateBrokerAgent.ContactBusinessPhone.FAGetValue());
                Support.AreEqual(@"(232)323-2323", FastDriver.RealEstateBrokerAgent.ContactBusinessFax.FAGetValue());
                Support.AreEqual(@"contact@test.com", FastDriver.RealEstateBrokerAgent.ContactEmailAddress.FAGetValue());
                Support.AreEqual(@"(454)545-4545", FastDriver.RealEstateBrokerAgent.ContactCellphone.FAGetValue());
                Support.AreEqual("(343)434-3434", FastDriver.RealEstateBrokerAgent.ContactPager.FAGetValue());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0071
        [TestMethod]
        public void FMUC0050_REG0071()
        {

            try
            {
                Reports.TestDescription = "BR_ES13443_ADMrevert: To revert the ADM setup for BR_ES13443.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Thread.Sleep(3000);
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");

                Reports.TestStep = "To remove the contact from the primary contact field.";
                FastDriver.BusPartyOrgSetUp.PrimaryContact.FASelectItemByIndex(0);
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0072
        /// <summary>
        ///FM2793  No Payment Details  
        /// The 3rd party disbursement section does not include the Payment Details button, and the user may not modify Payment Method 
        /// or Pay To fields for the 3rd party disbursement check amount. (Covered in BAT0003)
        /// FM2823  Comm Chg: CHK Pmt Method Only  
        /// The system automatically assigns the CHK payment method to the Commission Charge Amount charges.
        /// FM2824  Comm Chg: No Payment Details  
        /// The Commission Charge Amount section does not include the Payment Details button, and the user may not modify Payment Method or Pay To fields for the commission charges.
        /// FM4855  Prevent Payment Method Modification  
        /// The system shall not provide the ability to modify Payment Method for Real Estate Broker Charges. 
        /// Note: Default Payment Method for Broker Standard/Miscellaneous charges will be defined as CHK by procedure. (Covered in REG0029)

        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0072()
        {

            try
            {
                Reports.TestDescription = "BR_FM2793_FM4855_FM2824: No Payment Details.";
                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "To Add a Real Estate Broker/Agent.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", CommissionPercent: "10");
                //
                Reports.TestStep = "FM2824 : Verify that Payment Details button does not exist under commision charge amount section";
                Support.AreEqual("False",FastDriver.RealEstateBrokerAgent.CheckPaymentDetailsButton(FastDriver.RealEstateBrokerAgent.CommisionPaidAtSettlementHeader).ToString());


                Reports.TestStep = "FM4855  The system shall not provide the ability to modify Payment Method for Real Estate Broker Charges.";
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CheckPaymentDetailsButton(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesHeader).ToString());
                                
                Reports.TestStep = "To validate the 3rd party real-estate disbursement.";
                FastDriver.ActiveDisbursementSummary.Open(FastDriver.ActiveDisbursementSummary.Disbursements);
                Support.AreEqual("Success", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Funds", "Check", "Payee", TableAction.Click).Status.ToString());
                //              

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0073
        /// <summary>
        /// ES13448A  Default Address for Broker’s Contact  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///A.System shall default the address as mailing address for the broker contact. 
        ///B.If mailing address is not available, then system shall default the business address. 
        ///c. If both mailing and business address are not available, then system shall leave the address as blank.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0073()
        {

            try
            {
                Reports.TestDescription = "BR_ES13448_ADMsetup1: Set up mail, Business and Bill address for the contact. BR_ES13448_IIS1: Verify that mail address will be displayed if the contact has both mail and Business address.";

                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");
                Reports.TestStep = @"Edit/Enter mailing address.";
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
                Dictionary<string, string> MailingAddress = FastDriver.BusPartyContactSetup.GetAddressDetails("Mailing");
                BusinessOrganizationParameters BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Mailing";
                BusOrgParams.AddressLine1 = @"Mailing Address Line1";
                BusOrgParams.AddressLine2 = @"Mailing Address Line2";
                BusOrgParams.AddressLine3 = @"Mailing Address Line3";
                BusOrgParams.AddressLine4 = @"Mailing Address Line4";
                BusOrgParams.City = "Santa Ana";
                BusOrgParams.State = "CA";
                BusOrgParams.Zip = "92707";
                BusOrgParams.County = "Orange";
                string value = "Success";
                if (!MailingAddress.TryGetValue("Status", out value))
                {

                    FastDriver.BusPartyContactSetup.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyContactSetup.ChangeAddressDetails("Mailing", BusOrgParams);

                }

                Reports.TestStep = "Edit or Enter business address";

                Dictionary<string, string> BusinessAddress = FastDriver.BusPartyContactSetup.GetAddressDetails("Business");
                BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Business";
                BusOrgParams.AddressLine1 = @"Business Address Line1";
                BusOrgParams.AddressLine2 = @"Business Address Line2";
                BusOrgParams.AddressLine3 = @"Business Address Line3";
                BusOrgParams.AddressLine4 = @"Business Address Line4";
                BusOrgParams.City = "Irvine";
                BusOrgParams.State = "CA";
                BusOrgParams.Zip = "92706";
                BusOrgParams.County = "Orange";
                if (!BusinessAddress.TryGetValue("Status", out value))
                {

                    FastDriver.BusPartyContactSetup.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyContactSetup.ChangeAddressDetails("Business",BusOrgParams);
                    Thread.Sleep(3000);
                }
                //
                Reports.TestStep = "Edit ot Enter Billing address";
                Dictionary<string, string> BillingAddress = FastDriver.BusPartyContactSetup.GetAddressDetails("Billing");
                BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Billing";
                BusOrgParams.AddressLine1 = @"Billing Address Line1";
                BusOrgParams.AddressLine2 = @"Billing Address Line2";
                BusOrgParams.AddressLine3 = @"Billing Address Line3";
                BusOrgParams.AddressLine4 = @"Billing Address Line4";
                BusOrgParams.City = "Santa Ana";
                BusOrgParams.State = "CA";
                BusOrgParams.Zip = "92705";
                BusOrgParams.County = "Orange";
                value = "Success";
                if (!BillingAddress.TryGetValue("Status", out value))
                {
                    FastDriver.BusPartyContactSetup.SetNewAddressDetails(BusOrgParams);
                    
                }
                else
                {
                    FastDriver.BusPartyContactSetup.ChangeAddressDetails("Billing", BusOrgParams);
                }
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Log into FAST application IIS.";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Default Address for Broker with Mailing and Business addresses.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", CommissionPercent: "10");
                Dictionary<string, string> BrokerContactAddress = FastDriver.RealEstateBrokerAgent.GetBrokerContactAddress();
                //
                Reports.TestStep = "Validate Default Address.";
                CompareDefaultAddress(BrokerContactAddress, MailingAddress);


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0074

        [TestMethod]
        public void FMUC0050_REG0074()
        {
            Reports.TestDescription = "BR_ES13448_IIS1: Verify that mail address will be displayed if the contact has both mail and Business address.";
            Reports.StatusUpdate("This flow is covered in REG0073", true);

        }
        #endregion Test
        #region Test FMUC0050_REG0075
        /// <summary>
        /// B.
        /// ES13448  Default Address for Broker’s Contact  	7.6 1528 - Enhance RE Broker Screen in FAST
        ///If mailing address is not available, then system shall default the business address. 
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0075()
        {

            try
            {
                Reports.TestDescription = "BR_ES13448_ADMsetup2: Remove mail address for the contact.BR_ES13448_IIS2: Verify that Business address will be displayed if the contact does not have mail address."; 
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Reports.TestStep = "Remove mailing address.";
                FastDriver.BusPartyContactSetup.RemoveAddress("Mailing");
                Reports.TestStep = "Edit or Enter business address";
                Dictionary<string, string> BusinessAddress = FastDriver.BusPartyContactSetup.GetAddressDetails("Business");
                BusinessOrganizationParameters BusOrgParams = new BusinessOrganizationParameters();
                BusOrgParams.Addresstype = "Business";
                BusOrgParams.AddressLine1 = @"Business Address Line1";
                BusOrgParams.AddressLine2 = @"Business Address Line2";
                BusOrgParams.AddressLine3 = @"Business Address Line3";
                BusOrgParams.AddressLine4 = @"Business Address Line4";
                BusOrgParams.City = "Irvine";
                BusOrgParams.State = "CA";
                BusOrgParams.Zip = "92706";
                BusOrgParams.County = "Orange";
                string value = "Success";
                if (!BusinessAddress.TryGetValue("Status", out value))
                {

                    FastDriver.BusPartyContactSetup.SetNewAddressDetails(BusOrgParams);
                }
                else
                {
                    FastDriver.BusPartyContactSetup.ChangeAddressDetails("Business", BusOrgParams);
                }

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();;
                //
                Reports.TestStep = "Log into FAST application IIS.";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Create Seller broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", CommissionPercent: "10");
                Reports.TestStep = "GET Default Address for Broker with Mailing and Business addresses.";
                Dictionary<string, string> BrokerContactAddress = FastDriver.RealEstateBrokerAgent.GetBrokerContactAddress();
                //
                Reports.TestStep = "Verify Default Address for Broker with Mailing and Business addresses.";
                CompareDefaultAddress(BrokerContactAddress, BusinessAddress);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0076

        [TestMethod]
        public void FMUC0050_REG0076()
        {

            Reports.TestDescription = "BR_ES13448_ADMsetup2: Remove mail address for the contact.";
            Reports.StatusUpdate("This flow is covered in REG0075", true);

        }
        #endregion Test
        #region Test FMUC0050_REG0077
        /// <summary>
        /// C.
        /// ES13448  Default Address for Broker’s Contact  	7.6 1528 - Enhance RE Broker Screen in FAST
        /// If both mailing and business address are not available, then system shall leave the address as blank.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0077()
        {
            try
            {
                Reports.TestDescription = "BR_ES13448_ADMsetup3: Remove Business address for the contact. BR_ES13448_IIS3: Address will be blank if both Mailing and business address are not available.";
                Reports.TestStep = "Login to ADM";
                ADMLOGIN();
                SelectRegion();

                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.AddressBookSearch.EditGAB("HUDFLINSR1");
                //
                Reports.TestStep = "To click on Edit button in Business Party Contacts List.";
                FastDriver.BusPartyOrgSetUp.ViewAddContacts.FAClick();
                FastDriver.BusPartyContactsList.EditContactForGAB("Contact");
                FastDriver.BusPartyOrgSetUp.Version.FAClick();
                Reports.TestStep = "Remove mailing address.";
                FastDriver.BusPartyContactSetup.RemoveAddress("Mailing");
//
                Reports.TestStep = "Remove Business address.";
                FastDriver.BusPartyContactSetup.RemoveAddress("Business");
                FastDriver.BottomFrame.Done(); ;
                //
                Reports.TestStep = "Log into FAST application IIS.";
                MasterTestClass.PerformRequiredRegistrySettings(); 
                IISLOGIN();
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Create REB instance";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1", CommissionPercent: "10");
                Reports.TestStep = "Default Address for Broker with Mailing and Business addresses.";
                Dictionary<string, string> BrokerBlankAddress = FastDriver.RealEstateBrokerAgent.GetBrokerContactAddress();
                Reports.TestStep = "Validate Default Address for Broker with Mailing and Business addresses.";
               Support.AreEqual("True", ValidateBlankAddress(BrokerBlankAddress).ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0078

        [TestMethod]
        public void FMUC0050_REG0078()
        {
            Reports.TestDescription = "BR_ES13448_IIS3: Address will be blank if both Mailing and business address are not available.";
            Reports.StatusUpdate("This flow is covered in REG0077", true);
        }
        #endregion Test
        #region Test FMUC0050_REG0079

        [Obsolete,TestMethod]
        public void FMUC0050_REG0079()
        {


             Reports.TestDescription = "BR_ES13448_ADMsetup: Remove Billing address for the contact."; 
            Reports.StatusUpdate("BR_ES13448 is covered in REG0073 to REG0077", true);
               
        }
        #endregion Test
        
        #region Test FMUC0050_REG0080 - Commented as the BR is not valid.
        [Obsolete]
        [TestMethod]
        public void FMUC0050_REG0080()
        {///FM2727  Credit Seller/Buyer  
            ///When the user checks the Credit Seller or Credit Buyer checkbox, and the user enters an amount for the credit, 
             ///the system shall create a miscellaneous adjustment for the amount in the Miscellaneous Adjustments process for the buyer or seller.
             ///The system shall also subtract these amounts from the broker's commission amount. See Business Rules FM2108 and FM2109.
             Reports.TestDescription = "FM2727.";
             Reports.StatusUpdate("BR FM2727 is not valid",true);
        }
        #endregion Test
        #region Test FMUC0050_REG0081

        [TestMethod]
        public void FMUC0050_REG0081()
        {

            try
            {
                Reports.TestDescription = "FD_Commisionpercent: Field validation-Commision percent.";
                Reports.TestStep = "Log into FAST application IIS.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Default Address for Broker with Mailing and Business addresses.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                Reports.TestStep = "To verify the lower limit of the fields-Commission percent.";
                Support.AreEqual("True",ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommissionPercent,"123.111","123.1110",true).ToString());
                Reports.TestStep = "To verify the high limit of the fields-Commission percent.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CommissionPercent, "12345.111", "?", true).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-Commission percent.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommissionPercent, "1234.1111", "1234.1111", true).ToString());              

                Reports.TestStep = "To verify the low decimal limit of the fields-Commission percent.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommissionPercent, "1234.123", "1234.1230", true).ToString());
                Reports.TestStep = "To verify the exact decimal limit of the fields-Commission percent.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommissionPercent, "1234.1111", "1234.1111", true).ToString());
                Reports.TestStep = "To verify the high decimal limit of the fields-Commission percent.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CommissionPercent, "123.12345", "123.1234", true).ToString());

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerInformationGAB code";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode, "GAB", "GAB", false).ToString());
                
                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode, "2202202202", "2202202202", false).ToString());
                
                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode, "220220220200", "2202202202", false).ToString());
               
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerInformationName";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationName, "Name", "Name", false).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationName, @"Harris Bank Woodstock  Harris Bank WoodH", @"Harris Bank Woodstock  Harris Bank WoodH", false).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationName, @"Harris Bank Woodstock  Harris Bank WoodHarris Bank Wood", @"Harris Bank Woodstock  Harris Bank WoodH", false).ToString());
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerInformationBusinessPhone";
                FastDriver.RealEstateBrokerAgent.BrokerInformationEdit.FASetCheckbox(true);
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhone, "123", @"(???)???-????", false).ToString());
                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhone, "12345678901", @"(123)456-7890", false).ToString());
                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhone, "1234567890", @"(123)456-7890", false).ToString());

                



                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerInformationBusinessPhoneExtension";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhoneExtension, "123", "123", false).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhoneExtension, "1234567890", @"1234567890", false).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhoneExtension, "12345678901", @"1234567890", false).ToString());
               
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerInformationBusinessFax";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessFax, "123", @"(???)???-????", false).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessFax, "1234567890", @"(123)456-7890", false).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessFax, "12345678901", @"(123)456-7890", false).ToString());
               
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerInformationCellPhone";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationCellPhone, "123", @"(???)???-????", false).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationCellPhone, "1234567890", @"(123)456-7890", false).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationCellPhone, "12345678901", @"(123)456-7890", false).ToString());
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerInformationPager";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationPager, "123", @"(???)???-????", false).ToString());
                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationPager, "1234567890", @"(123)456-7890", false).ToString());
                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationPager, "12345678901", @"(123)456-7890", false).ToString());
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerInformationBrokerInformationEmailAddress";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress, "abc", @"?", false).ToString());
                
                //Upper
                string InputValue = @"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@aaaaadd.com";
                string OutputValue = @"?";
                 Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress, InputValue, OutputValue, false).ToString());
                 //Exact
                  InputValue = @"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@aaaaadd.com";
                 OutputValue = @"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@aaaaadd.com";
                 Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress, InputValue, OutputValue, false).ToString());
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerInformationReference";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationReference, "abc", @"abc", false).ToString());
                //Exact
                InputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekksk";
                OutputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekksk";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationReference, InputValue, OutputValue, false).ToString());
                //Upper
                InputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekkskabcd";
                OutputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekksk";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerInformationReference, InputValue, OutputValue, false).ToString());
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerContactGABcode";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactGABcode, "GAB", "GAB", false).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactGABcode, "2202202202", "2202202202", false).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerContactGABcode, "220220220200", "2202202202", false).ToString());
               

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerContactGABName";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactGABName, "Name", "Name", false).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactGABName, @"Harris Bank Woodstock  Harris Bank WoodH", @"Harris Bank Woodstock  Harris Bank WoodH", false).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerContactGABName, @"Harris Bank Woodstock  Harris Bank WoodHarris Bank Wood", @"Harris Bank Woodstock  Harris Bank WoodH", false).ToString());
                

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerContactBusinessPhone";

                FastDriver.RealEstateBrokerAgent.BrokerContactEdit.FASetCheckbox(true);
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactBusinessPhone, "123", @"(???)???-????", false).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactBusinessPhone, "1234567890", @"(123)456-7890", false).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerContactBusinessPhone, "12345678901", @"(123)456-7890", false).ToString());

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerContactBusinessPhoneExtension";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactBusinessPhoneExtension, "123", "123", false).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactBusinessPhoneExtension, "1234567890", @"1234567890", false).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerContactBusinessPhoneExtension, "12345678901", @"1234567890", false).ToString());

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerContactBusinessFax";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactBusinessFax, "123", @"(???)???-????", true).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactBusinessFax, "1234567890", @"(123)456-7890", true).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerContactBusinessFax, "12345678901", @"(123)456-7890", true).ToString());

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerContactCellPhone";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactCellPhone, "123", @"(???)???-????", true).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactCellPhone, "1234567890", @"(123)456-7890", true).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerContactCellPhone, "12345678901", @"(123)456-7890", true).ToString());

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerContactPager";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactPager, "123", @"(???)???-????", true).ToString());
                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactPager, "1234567890", @"(123)456-7890", true).ToString());
                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerContactPager, "12345678901", @"(123)456-7890", true).ToString());
                //
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerContactEmailAddress";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactEmailAddress, "abc", @"?", true).ToString());
                
                //Upper
                 InputValue=@"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@aaaaadd.com";
                 OutputValue=@"?";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerContactEmailAddress, InputValue, OutputValue, true).ToString());
                //Exact
                InputValue = @"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@aaaaadd.com";
                OutputValue = @"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@aaaaadd.com";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactEmailAddress, InputValue, OutputValue, true).ToString());

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-BrokerContactReference";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactReference, "abc", @"abc", true).ToString());
                //Exact
                InputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekksk";
                OutputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekksk";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.BrokerContactReference, InputValue, OutputValue, true).ToString());
                //Upper
                InputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekkskabcd";
                OutputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekksk";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.BrokerContactReference, InputValue, OutputValue, true).ToString());
            }

            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion Test
        #region Test FMUC0050_REG0082

        [TestMethod]
        public void FMUC0050_REG0082()
        {

            try
            {
                Reports.TestDescription = "FD_CommisionamountCreditsellerCreditbuyerCreditbuyerbroker: Field validation-Commisionamount,CreditsellerCreditbuyer, Creditbuyerbroker.";
                Reports.TestStep = "Log into FAST application IIS.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Create agent broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                Reports.TestStep = "To verify the lower limit of the fields-Commission amount";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommissionAmount, @"1,234,567,891.12", @"1,234,567,891.12", false).ToString());
                Reports.TestStep = "To verify the higher limit of the fields-Commission amount.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CommissionAmount, @"123456789123.12", "?", false).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-Commission amount.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommissionAmount, @"12,345,678,912.12", @"12,345,678,912.12", false).ToString());

                //
                Reports.TestStep = "To verify the lower limit of the fields-credit seller";
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed())
                {
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                }
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit Amount" + FAKeys.Tab);
                //
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit, @"1,234,567,891.12", @"1,234,567,891.12", false).ToString());
                Reports.TestStep = "To verify the higher limit of the fields-credit seller.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit, @"123456789123.12", "?", false).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-credit seller.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit, @"12,345,678,912.12", @"12,345,678,912.12", false).ToString());
                //
                Reports.TestStep = "To verify the lower limit of the fields-credit buyer";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit, @"1,234,567,891.12", @"1,234,567,891.12", false).ToString());
                Reports.TestStep = "To verify the higher limit of the fields-credit buyer.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit, @"123456789123.12", "?", false).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-credit buyer.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit, @"12,345,678,912.12", @"12,345,678,912.12", false).ToString());            
                //
                Reports.TestStep = "To verify the lower limit of the fields-credit buyer broker";

                if (!FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.IsSelected())
                {
                    FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);

                }
                //FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit Amount" + FAKeys.Tab);
                //
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt, @"1,234,567,891.12", @"1,234,567,891.12", false).ToString());
                Reports.TestStep = "To verify the higher limit of the fields-credit seller.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt, @"123456789123.12", "?", false).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-credit seller.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt, @"12,345,678,912.12", @"12,345,678,912.12", false).ToString());

                //credit seller, credit buyer, credit buyer broker.
                
              
                Reports.TestStep = "To clear the commission amount, credit seller, credit buyer, credit buyer broker.";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText(@"");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText(@"");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText(@"");

                Reports.TestStep = "To verify the decimal lower limit of the fields-Commission amount";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommissionAmount, @"12,345,678,912.1", @"12,345,678,912.10", false).ToString());
                Reports.TestStep = "To verify the decimal exact limit of the fields-Commission amount.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommissionAmount, @"12,345,678,912.12", @"12,345,678,912.12", false).ToString());
                Reports.TestStep = "To verify the decimal higher limit of the fields-Commission amount.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CommissionAmount, @"1,234,567,891.123", @"1,234,567,891.12", false).ToString());
                //
                Reports.TestStep = "To verify the decimal lower limit of the fields-Credit seller";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit, @"12,345,678,912.1", @"12,345,678,912.10", false).ToString());               
                Reports.TestStep = "To verify the decimal higher limit of the fields-Credit seller";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit, @"1,234,567,891.123", @"1,234,567,891.12", false).ToString());
                //
                Reports.TestStep = "To verify the decimal lower limit of the fields-Credit buyer";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit, @"12,345,678,912.1", @"12,345,678,912.10", false).ToString());                
                Reports.TestStep = "To verify the decimal higher limit of the fields-Credit buyer";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit, @"1,234,567,891.123", @"1,234,567,891.12", false).ToString());
                //
                Reports.TestStep = "To verify the decimal lower limit of the fields-Credit buyer broker";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt, @"12,345,678,912.1", @"12,345,678,912.10", false).ToString());                
                Reports.TestStep = "To verify the decimal higher limit of the fields-Credit buyer broker";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt, @"1,234,567,891.123", @"1,234,567,891.12", false).ToString());
                //
                Reports.TestStep = "To clear the commission amount, credit seller, credit buyer, credit buyer broker.";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText(@"");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText(@"");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText(@"");
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0083

        [TestMethod]
        public void FMUC0050_REG0083()
        {
            try
            {
                Reports.TestDescription = "FD_CommisionchargeamountBuyercharge: Field validation-CommisionchargeamountBuyercharge. CommisionchargeamountSellercharge";
                //
                Reports.TestStep = "Log into FAST application IIS.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Create agent broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                //
                Reports.TestStep = "To verify the lower limit of the fields-CommisionChargeAmountBuyerCharge";
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed())
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit Amount" + FAKeys.Tab);
                //
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge, @"1,234,567,891.12", @"1,234,567,891.12", true).ToString());
                Reports.TestStep = "To verify the higher limit of the fields-CommisionChargeAmountBuyerCharge.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge, @"123456789123.12", "?", true).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-CommisionChargeAmountBuyerCharge.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge, @"12,345,678,912.12", @"12,345,678,912.12", true).ToString());
                
                //credit seller, credit buyer, credit buyer broker.


                Reports.TestStep = "To clear the Commisionchargeamountbuyercharge";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@""+FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "To verify the decimal lower limit of the fields-CommisionChargeAmountBuyerCharge";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge, @"12,345,678,912.1", @"12,345,678,912.10", true).ToString());               
                Reports.TestStep = "To verify the decimal higher limit of the fields-CommisionChargeAmountBuyerCharge.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge, @"1,234,567,891.123", @"1,234,567,891.12", true).ToString());
                //
                Reports.TestStep = "To clear the Commisionchargeamountbuyercharge";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText(@""+FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                //
                Reports.TestStep = "To verify the lower limit of the fields-CommisionChargeAmountSellerCharge";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit Amount" + FAKeys.Tab);
                //
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge, @"1,234,567,891.12", @"1,234,567,891.12", true).ToString());
                Reports.TestStep = "To verify the higher limit of the fields-CommisionChargeAmountSellerCharge";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge, @"123456789123.12", "?", true).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-CommisionChargeAmountSellerCharge";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge, @"12,345,678,912.12", @"12,345,678,912.12", true).ToString());
                //credit seller, credit buyer, credit buyer broker.
                Reports.TestStep = "To clear the CommisionChargeAmountSellerCharge";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText(@""+FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "To verify the decimal lower limit of the fields-CommisionChargeAmountSellerCharge";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge, @"12,345,678,912.1", @"12,345,678,912.10", true).ToString());
                Reports.TestStep = "To verify the decimal higher limit of the fields-CommisionChargeAmountSellerCharge.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge, @"1,234,567,891.123", @"1,234,567,891.12", true).ToString());
                //
                Reports.TestStep = "To clear the CommisionChargeAmountSellerCharge";
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText(@""+FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0084

        [TestMethod]
        public void FMUC0050_REG0084()
        {
            Reports.TestDescription = "FD_Commisionchargeamountsellercharge: Field validation-CommisionchargeamountSellercharge.";
            Reports.StatusUpdate("This flow is covered in reg0083", true);
        }
        #endregion Test
        #region Test FMUC0050_REG0085

        [TestMethod]
        public void FMUC0050_REG0085()
        {
            try
            {
                Reports.TestDescription = "FD_REChgamtbuyerchgREChgamtsellerchgnetchkdisbamt: Field validation-Realestatebrokercharge - buyercharge, sellercharge, netchkdisbamt.";
                //
                Reports.TestStep = "Log into FAST application IIS.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = "Create agent broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1",CommissionAmount:"1000");
                //
                Reports.TestStep = "To verify the lower limit of the fields-Realestatebrokercharge - RealEstateBroker - buyercharge";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FASetText(@"Desc"+FAKeys.Tab);
                //
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge, @"1,234,567,891.12", @"1,234,567,891.12", true).ToString());
                Reports.TestStep = "To verify the higher limit of the fields-buyercharge.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge, @"123456789123.12", "?", true).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-buyercharge.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge, @"12,345,678,912.12", @"12,345,678,912.12", true).ToString());

                //
                Reports.TestStep = "To verify the lower limit of the fields-Realestatebrokercharge - RealEstateBroker - SellerCharge";
                //FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FASetText(@"Desc" + FAKeys.Tab);
                //
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge, @"1,234,567,891.12", @"1,234,567,891.12", true).ToString());
                Reports.TestStep = "To verify the higher limit of the fields-SellerCharge.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge, @"123456789123.12", "?", true).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-SellerCharge.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge, @"12,345,678,912.12", @"12,345,678,912.12", true).ToString());
                //
                Reports.TestStep = "Create new REB disbursement";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsGABcode.FASetText(@"HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsbFind.FAClick();
                //
                Reports.TestStep = "To verify the lower limit of the fields-Realestatebrokercharge - RealEstateBrokerDisbursementsCheckAmount";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FASetText(@"Desc" + FAKeys.Tab);
                //
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount, @"1,234,567,891.12", @"1,234,567,891.12", true).ToString());
                Reports.TestStep = "To verify the higher limit of the fields-RealEstateBrokerDisbursementsCheckAmount.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount, @"123456789123.12", "?", true).ToString());
                Reports.TestStep = "To verify the exact limit of the fields-RealEstateBrokerDisbursementsCheckAmount.";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount, @"12,345,678,912.12", @"12,345,678,912.12", true).ToString());
                

                Reports.TestStep = "To clear the Realestatebrokercharge, buyercharge, sellercharge, netchkdisbamt.";

                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FASetText(@"Desc");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText(@"");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText(@"");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(@"");              

                Reports.TestStep = "To verify the decimal lower limit of the fields-RealEstateBrokerChargesBuyerCharge";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge, @"12,345,678,912.1", @"12,345,678,912.10", true).ToString());
                Reports.TestStep = "To verify the decimal higher limit of the fields-RealEstateBrokerChargesBuyerCharge.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge, @"1,234,567,891.123", @"1,234,567,891.12", true).ToString());
                //
                Reports.TestStep = "To verify the decimal lower limit of the fields-RealEstateBrokerChargesSellerCharge";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge, @"12,345,678,912.1", @"12,345,678,912.10", true).ToString());
                Reports.TestStep = "To verify the decimal higher limit of the fields-RealEstateBrokerChargesSellerCharge.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge, @"1,234,567,891.123", @"1,234,567,891.12", true).ToString());
                //
                Reports.TestStep = "To verify the decimal lower limit of the fields-RealEstateBrokerDisbursementsCheckAmount";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount, @"12,345,678,912.1", @"12,345,678,912.10", true).ToString());
                Reports.TestStep = "To verify the decimal higher limit of the fields-RealEstateBrokerDisbursementsCheckAmount.";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount, @"1,234,567,891.123", @"1,234,567,891.12", true).ToString());
                

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-RealEstateBrokerDisbursementsGAB code";

                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsGABcode, "GAB", "GAB", true).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsGABcode, "2202202202", "2202202202", true).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsGABcode, "220220220200", "2202202202", true).ToString());
                

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-RealEstateBrokerDisbursementsName";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsName, "Name", "Name", true).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsName, @"Harris Bank Woodstock  Harris Bank WoodH", @"Harris Bank Woodstock  Harris Bank WoodH", true).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsName, @"Harris Bank Woodstock  Harris Bank WoodHarris Bank Wood", @"Harris Bank Woodstock  Harris Bank WoodH", true).ToString());
                

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-RealEstateBrokerDisbursementsBusinessPhone";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsEdit.FASetCheckbox(true);
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsBusinessPhone, "123", @"(???)???-????", true).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsBusinessPhone, "1234567890", @"(123)456-7890", true).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsBusinessPhone, "12345678901", @"(123)456-7890", true).ToString());
                

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-RealEstateBrokerDisbursementsBusinessPhoneExtension";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsBusinessPhoneExtension, "123", "123", true).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsBusinessPhoneExtension, "1234567890", @"1234567890", true).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsBusinessPhoneExtension, "12345678901", @"1234567890", true).ToString());
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-RealEstateBrokerDisbursementsBusinessFax";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsBusinessFax, "123", @"(???)???-????", true).ToString());
                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsBusinessFax, "1234567890", @"(123)456-7890", true).ToString());
                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsBusinessFax, "12345678901", @"(123)456-7890", true).ToString());
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-RealEstateBrokerDisbursementsCellPhone";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCellPhone, "123", @"(???)???-????", true).ToString());

                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCellPhone, "1234567890", @"(123)456-7890", true).ToString());

                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCellPhone, "12345678901", @"(123)456-7890", true).ToString());
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-RealEstateBrokerDisbursementsPager";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsPager, "123", @"(???)???-????", true).ToString());
                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsPager, "1234567890", @"(123)456-7890", true).ToString());
                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsPager, "12345678901", @"(123)456-7890", true).ToString());
                
                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-RealEstateBrokerDisbursementsRealEstateBrokerDisbursementsEmailAddress";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsEmailAddress, "abc", @"?", true).ToString());
                //Exact
                string InputValue = @"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@aaaaadd.com";
                string OutputValue = @"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@aaaaadd.com";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsEmailAddress, InputValue, OutputValue, true).ToString());
                //Upper
                InputValue = @"Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@aaaaadd.com";
                OutputValue = @"?";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsEmailAddress, InputValue, OutputValue, true).ToString());              

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-RealEstateBrokerDisbursementsReference";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsReference, "abc", @"abc", true).ToString());
                //Exact
                InputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekksk";
                OutputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekksk";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsReference, InputValue, OutputValue, true).ToString());
                //Upper
                InputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekkskabcd";
                OutputValue = @"abcdefghijklmnopqrstuvwxyzancwrvoergjepkqbekrekksk";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsReference, InputValue, OutputValue, true).ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0086

        [TestMethod]
        public void FMUC0050_REG0086()
        {
            try
            {

                Reports.TestDescription = "Btn: Work Pane Specific Button/Icons, shortcut keys in REB screen and REB Summary screen.";
                Reports.TestStep = "Log into FAST application IIS.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);

                Reports.TestStep = "To verify that edit/remove button is disabled for Selling/Listing broker.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.SellerBuyerRemove.IsEnabled().ToString());
                
                Reports.TestStep = "Create agent broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                Support.AreEqual("True", FastDriver.BottomFrame.btnDone.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.BottomFrame.btnNew.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.BottomFrame.btnReset.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.BottomFrame.btnDelete.IsEnabled().ToString());
                
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "To Reset the real estate broker info. with hot keys";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER", CommissionAmount: @"200");
                //FastDriver.BottomFrame.Reset();
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnReset.GiveFocus();
                FastDriver.BottomFrame.btnReset.SendKeys(FAKeys.Control+"R");
                Thread.Sleep(7000);
                //if sendkeys fails in first attempt
                Reports.TestStep = "Click on Ok button.";
                string Message=FastDriver.WebDriver.HandleDialogMessage();
                if (Message.Contains("No dialog present"))
                {
                    FastDriver.BottomFrame.SwitchToBottomFrame();
                    FastDriver.BottomFrame.btnReset.GiveFocus();
                    Support.SendKeys("^R");
                   Thread.Sleep(7000);
                   if (FastDriver.WebDriver.HandleDialogMessage().Contains("No dialog present"))
                    {
                        FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                        Reports.StatusUpdate("Hot keys to reset record are not working even after second attempt. Please try manually to confirm", false);
                    }
                }
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                Reports.TestStep = "To verify the information after Reset.";
                Support.AreEqualTrim(@"0.00",FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Reports.TestStep = "Delete record";
                //FastDriver.BottomFrame.Delete();
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDelete.GiveFocus();
                FastDriver.BottomFrame.btnDelete.SendKeys(FAKeys.Control + FAKeys.Delete);
                Thread.Sleep(7000);
                Reports.TestStep = "Click on Ok button.";
                Message = FastDriver.WebDriver.HandleDialogMessage();
                //if sendkeys fails in first attempt
                if (Message.Contains("No dialog present"))
                {
                    FastDriver.BottomFrame.SwitchToBottomFrame();
                    FastDriver.BottomFrame.btnDelete.GiveFocus();
                    Support.SendKeys("^{DELETE}");
                    Thread.Sleep(7000);
                    if (FastDriver.WebDriver.HandleDialogMessage().Contains("No dialog present"))
                    {
                        FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                        Reports.StatusUpdate("Hot keys to delete record are not working even after second attempt. Please try manually to confirm", false);
                    }
                }
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                Reports.TestStep = "To verify the record is removed after deletion.";
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction("#2","Available","#2",TableAction.Click).ToString();
                Reports.TestStep = "CReate REB Instance";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", "HUDFLINSR1");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "CReate REB Instance of type other broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDFLINSR1");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "To remove the instance from REB summary.";
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction("#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.RemoveOther.FAClick();
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                Reports.TestStep = "To verify the New, Edit and remove button under Other Real Estate Broker Agent Summary.";
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.NewOther.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgentSummary.EditOther.IsEnabled().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgentSummary.RemoveOther.IsEnabled().ToString());
                Reports.TestStep = "To verify the record is removed after deletion from summary.";
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction("#2", "Available", "#2", TableAction.Click).ToString();
                //
                Reports.TestStep = "Create other broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDFLINSR1", CommissionAmount: "200");
                FastDriver.RealEstateBrokerAgent.AddNewRealEstateBrokerDisbursement("HUDOTHRBR1", "500.00");
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Select the third party disbursement check amount in Real Estate Broker screen and click on print.";
                FastDriver.ActiveDisbursementSummary.DisburseCheck("500.00");
                //
                Reports.TestStep = "To verify Edit Remove button under Other summary and also verify issued check icon.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction("#1", "2", "#3", TableAction.Click);
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.EditOther.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgentSummary.RemoveOther.IsEnabled().ToString());
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.ScrollIntoView();
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.IssuedCheckImage.IsDisplayed().ToString());
                string result = FastDriver.RealEstateBrokerAgent.IssuedCheckImage.FAGetAttribute("title");
                Reports.StatusUpdate("Verify: Issued in Tooltip", result.Contains("Issued"));
                //               
                Reports.TestStep = "To verify the New, Delete button under Real Estate Broker Disbursement Summary.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER",CommissionAmount:"200");
                Support.AreEqual("True",FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.IsEnabled().ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryDelete.IsEnabled().ToString());
                Reports.TestStep = "To verify shortcut keys in REB disbursement summary section";
                Reports.TestStep = "shortcut keys for NEW REB disbursement";
                //Element.Sendkeys is not working so using support.Sendkeys
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.GiveFocus();
                //FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.SendKeys("%w");
                Support.SendKeys("%w");
                Thread.Sleep(3000);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsGABcode.FASetText(@"HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsbFind.FAClick();
                Thread.Sleep(3000);
                Reports.TestStep = "shortcut keys for DELETE REB disbursement";
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryDelete.GiveFocus();
                //Element.Sendkeys is not working so using support.Sendkeys
                //FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryDelete.SendKeys(FAKeys.Alt+"L");
                Support.SendKeys("%l");
                Thread.Sleep(3000);
                Reports.TestStep = "To verify that third party disbursement is removed after deletion.";
                string RowCount= FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.GetRowCount().ToString();
                Support.AreEqual(@"1", RowCount);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0087_PH

        [TestMethod]
        public void FMUC0050_REG0087_PH()
        {
            try
            {
                Reports.TestDescription = "BR_FM4711: Populate Default Charges from Template.";

                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0088_Prad_8_3
        /// <summary>
        /// ES15124  Itemize Real Estate Broker Credits
        ///System shall allow itemization of Real Estate Broker Credits for multiple Buyer's (Selling) Brokers, Seller's (Listing) Brokers and Other Brokers 
        /// for files with HUD Type = HUD. System shall allow user to enter Buyer Credits and/or Seller Credits.
        /// ES15126  Do not Itemize Credits to Selling or Listing Brokers
        ///System shall not provide ability to itemize Credits to Selling or Listing Brokers.
        ///ES15129  No Miscellaneous Adjustments for Broker Credits to Buyer/Seller
        ///System shall not create a Miscellaneous Adjustment for the Buyer/Seller Credits in Miscellaneous Adjustments charge process.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0088_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "ES15124_ES15126 : Itemize Real Estate Broker Credits, Enter and edit descriptions for Real Estate Broker Credits, Do not itemize Credits to Selling or Listing Broker, Aggregate of itemized Buyer Credits in Commission Summary, Aggregate of itemized Seller Credits in Commission Summary, No Miscellaneous Adjustments for Broker Credits to Buyer/Seller.";
                Reports.TestStep = "Log into FAST application IIS.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                Reports.TestStep = @"Itemization of Buyer credit and seller credit for Buyers (Selling) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER", "HUDFLINSR1", CommissionAmount: "1000");
                //
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
//
                Reports.TestStep = @"Validate REB Buyer seller credits.";
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue());
                //
                Thread.Sleep(3000);
                //
                Reports.TestStep = @"Validate REB Buyer seller pane.";
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                Thread.Sleep(3000);
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                
                Reports.TestStep = @"Itemization of Buyer credit and seller credit for Sellers (Listing) Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER", CommissionAmount: "1000");
                //
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                //
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue());

                //
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                Thread.Sleep(3000);
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());


                Reports.TestStep = "Itemization of Buyer credit and seller credit for New other real Estate Broker.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER", "HUDOTHRBR1", CommissionAmount: "1000");
                //
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                //
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FAGetValue());

                //
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                Thread.Sleep(3000);
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());

                Reports.TestStep = "Enter charges to Buyer and seller credit for Buyers (Selling) Broker,Aggregate of itemized Buyer Credits in Commission Summary.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER", CommissionAmount: "24");
                //
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit to Buyer Seller"+FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText(@"12.00");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText(@"12.00");
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());

//
                Reports.TestStep = "Enter charges to Buyer and seller credit for Sellers (Listing) Broker,Aggregate of itemized Buyer Credits in Commission Summary.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER", CommissionAmount: "24");
                //
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit to Buyer Seller" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText(@"12.00");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText(@"12.00");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.SendKeys(FAKeys.TabAway);
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());

                Reports.TestStep = "Enter charges to Buyer and seller credit for  New other real Estate Broker,Aggregate of itemized Buyer Credits in Commission Summary.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("OTHER", CommissionAmount: "24");
                //
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Credit to Buyer Seller"+FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText(@"12.00");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText(@"12.00");
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());

                Reports.TestStep = "Edit descriptions for Real Estate Broker Credits";
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
               //
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText(@"Edited Credit to Buyer Seller"+FAKeys.Tab);

                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FAGetValue());
                //
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue());
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText());


                Reports.TestStep = "Do not itemize Credits to Selling or Listing Broker.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER","Flood Insurance 1 for HUD Testing Name 1");
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText());

                Reports.TestStep = "No Miscellaneous Adjustments for Broker Credits to Buyer Seller.";
                FastDriver.AdjustmentMisc.Open();
                if (!AutoConfig.FormType.Equals("CD"))
                {
                    Support.AreEqualTrim(@"IBA Interest Paid", FastDriver.AdjustmentMisc.description.FAGetValue());
                }
                else
                    Support.AreEqual(@"Buyer Deposit Directly to Seller", FastDriver.AdjustmentMisc.description.FAGetValue());
                Support.AreEqual(@"", FastDriver.AdjustmentMisc.BuyerCharge.FAGetValue());
                Support.AreEqual(@"", FastDriver.AdjustmentMisc.BuyerCredit.FAGetValue());
                Support.AreEqual(@"", FastDriver.AdjustmentMisc.SellerCharge.FAGetValue());
                Support.AreEqual(@"", FastDriver.AdjustmentMisc.SellerCredit.FAGetValue());


                Reports.TestStep = "Verify other instance created.";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(@"#2", "Other Broker 1 for HUD Test Name 1", "#2", TableAction.Click);

                Reports.TestStep = "Verify Buyer Broker instance created.";
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(@"#2", "Flood Insurance 1 for HUD Testing Name 1", "#2", TableAction.Click);


                Reports.TestStep = "Verify Seller Broker instance created.";
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(@"#2", "Assumption Lender 1 for HUD Test Name 1", "#2", TableAction.Click);


                Reports.TestStep = "Perform Preview delivery.Please verify the Preview PDF for Buyer Charge,Buyer Credit,Charge Description,Seller Charge,Seller Credit under commision section.";
                FastDriver.PrintEscrowSetlleStmt.Open(); 
                FastDriver.PrintEscrowSetlleStmt.SelectDeliveryMethod("Preview");
                FastDriver.PrintEscrowSetlleStmt.ClickDeliver();
                HandleDeliveryFailure("Preview",200);
//
                Reports.TestStep = "Perform Preview delivery.Please verify the Preview PDF for Buyer Charge,Buyer Credit,Charge Description,Seller Charge,Seller Credit under commision section.";
                    if (AutoConfig.FormType == "HUD")
                    {
                        Reports.TestStep = "Preview in HUD";
                        PerformPreviewDeliveryHUD();
                    }
                    else
                    {
                        Reports.TestStep = "Preview in CD";
                        PerformPreviewDeliveryCD();

                    }
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0089_Prad_8_3

        [TestMethod]
        public void FMUC0050_REG0089_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "ES15134 : Collapse Real Estate Broker Credits and 'POC by Broker' section.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = @"Create instance for Buyers (Selling) Broker "; 
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER", CommissionPercent: "10");
                Reports.TestStep = @"verify the Credit Seller Earnest Money in excess of Commission amount is ZERO when earnet money is not present in file.";
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"100.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                //
                Reports.TestStep = @"Edit instance of Buyers (Selling) Broker "; 
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER");
                Reports.TestStep = @"System shall collapse Real Estate Broker Credits and POC by Broker section by default when there are no charges in these sections.";
                Support.AreEqual(@"True", FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.IsDisplayed().ToString());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsDisplayed().ToString());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.IsDisplayed().ToString());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.IsDisplayed().ToString());
                //
                Support.AreEqual(@"True", FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.IsDisplayed().ToString());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed().ToString());
                Support.AreEqual(@"False", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.IsDisplayed().ToString());
                
                Reports.TestStep = "Enter Commision percentage.";
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText(@"10.00"+FAKeys.Tab);
                Reports.TestStep = "Validate values after entering Commision percentage.";
                Support.AreEqual(@"100.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(@"100.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"100.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"100.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());
                //
                Reports.TestStep = "Validate values after  Modifying the commision amount.";
                Support.AreEqual(@"10.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"600.00" + FAKeys.Tab);
                //
                Support.AreEqual(@"600.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(@"600.00", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"600.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"600.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());
                 //            
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER","Flood Insurance 1 for HUD Testing Name 1");
                Reports.TestStep = "Sytems shall remove the Commission Amount % and default it to 0.0000 when Commission $ amount is modified";
                Support.AreEqual(@"0.0000", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue());
                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0090_Prad_8_3
        /// <summary>
        /// ES15131  Enter and edit descriptions for 'POC by Broker' items 
        ///   System shall allow user to enter and edit descriptions for POC amounts.
        ///
        ///   ES15132  Do not include 'POC by Broker' amounts in Net Check Amount calculation
        ///   System shall not include 'POC by Broker' amounts in calculation of Net Check Commission Amount.
        ///
        ///   ES15133  Do not create disbursement for 'POC by Broker' items
        ///   Do not create disbursement for 'POC by Broker' items.
        ///   ES15130  System shall allow user to enter Rebates or other Items 
        ///   paid to Buyer and/or Seller outside closing for files with HUD Type = HUD.
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0090_Prad_8_3()
        {
            try
            {
                Reports.TestDescription = "ES15133     : Enter 'POC by Broker' items,Enter and edit descriptions for 'POC by Broker' items,Enter and edit descriptions for 'POC by Broker' items, Do not include 'POC by Broker' amounts in Net Check Amount calculation.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information and Sales price.";
                CreateFile(SalesPrice:1000);
                //
                Reports.TestStep = "Create instance for Buyers (Selling) Broker to enter POC by Broker items Buyers (Selling) Broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER");

                Reports.TestStep = "Enter POC by Broker items Buyers (Selling) Broker";
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText(@"Poc Description"+FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText(@"12.00"+FAKeys.Tab);

                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());

                Reports.TestStep = @"Verify System shall not include POC by Broker amounts in calculation of Net Check Commission Amount.";

                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditfromOtherBroker.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());

                Reports.TestStep = @"Create instance for Sellers (Listing) Broker to enter POC by Broker items Sellers (Listing) Broker";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER");

                Reports.TestStep = "Enter POC by Broker items Sellers (Listing) Broker";
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText(@"Poc Description" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText(@"12.00" + FAKeys.Tab);
                //
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                //
                Reports.TestStep = "Verify System shall not include POC by Broker amounts in calculation of Net Check Commission Amount.";
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditfromOtherBroker.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());

                Reports.TestStep = "Enter POC by Broker items for Other Real Estate Broker";
                Reports.TestStep = "Create instance for Other Real Estate Broker to enter POC by Broker items ";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("OTHER");

                Reports.TestStep = "Enter POC by Broker items for Other Real Estate Broker";
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText(@"Poc Description" + FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText(@"12.00" + FAKeys.Tab);
                //
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                //
                Reports.TestStep = "Verify System shall not include POC by Broker amounts in calculation of Net Check Commission Amount.";
                Support.AreEqual(@"", FastDriver.RealEstateBrokerAgent.CommissionPercent.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerBrokerCommisionNetCheckAmt.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionNetCheckAmt.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionNetCheckAmt.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());
                

                Reports.TestStep = "Edit POC Description.";
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                    FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText(@"Edit Poc Description"+FAKeys.Tab);
                Support.AreEqual(@"Edit Poc Description", FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FAGetValue());
                Support.AreEqual(@"12.00", FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FAGetValue());
                //
                

                Reports.TestStep = "System shall not include POC by Broker amounts for disbursements.";
                FastDriver.ActiveDisbursementSummary.Open(FastDriver.ActiveDisbursementSummary.Disbursements);
                Support.AreEqual("1",FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString());

                Reports.TestStep = "Field validations for POC by Broker section.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER");
                if (!FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.IsDisplayed())
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-POCByBrokerDescription";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription, "POC", @"POC", false).ToString());
                //Exact
                string InputValue = @"POC by Broker Description POC by Broker Descr";
                string OutputValue = @"POC by Broker Description POC by Broker Descr";
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription, InputValue, OutputValue, false).ToString());
                //Upper
                InputValue = @"POC by Broker Description POC by Broker Description";
                OutputValue = @"POC by Broker Description POC by Broker Descr";
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription, InputValue, OutputValue, false).ToString());

               

                Reports.TestStep = @"To verify the lower/exact/upper limit of the fields-POCByBrokerAmount";
                //Lower
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount, @"23.00", @"23.00", false).ToString());
                //Upper
                Support.AreEqual("True", ValidateFieldForUpperLimit(FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount, "1234567890123", @"?", false).ToString());
                //Exact
                Support.AreEqual("True", ValidateFieldForLowerOrExactLimit(FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount, @"12,345,678,901.00", @"12,345,678,901.00", false).ToString());



                Reports.TestStep = "Perform Preview delivery.Please verify the Preview PDF for POC Description and charges under commision section.";
                FastDriver.PrintEscrowSetlleStmt.Open();
                FastDriver.PrintEscrowSetlleStmt.SelectDeliveryMethod("Preview");
                FastDriver.PrintEscrowSetlleStmt.ClickDeliver();
                HandleDeliveryFailure("Preview", 200);

                Reports.TestStep = "Perform Preview delivery.Please verify the Preview PDF for POC Charge Description and amount Under Settlement Charges section.";
                if (AutoConfig.FormType == "HUD")
                {
                    Reports.TestStep = "Preview in HUD";
                    PerformPreviewDeliveryHUD();
                }
                else
                {
                    Reports.TestStep = "Preview in CD";
                    PerformPreviewDeliveryCD();

                }

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #region Test FMUC0050_REG0091_Prad_8_3_FD
        /// <summary>
        /// ES15136  Credit Seller Earnest Money in excess of Commission 
        /// </summary>
        [TestMethod]
        public void FMUC0050_REG0091_Prad_8_3_FD()
        {
            try
            {
                Reports.TestDescription = "FMXXXX : Credit Seller Earnest Money in excess of Commission,Field Defination for Credit Seller Earnest Money in excess of Commission CheckBox and TextBox.";

                Reports.TestStep = "Log into FAST application.";
                IISLOGIN();
                //
                Reports.TestStep = "Create an order with basic information.";
                CreateFile(0);
                //
                Reports.TestStep = "Create instance for Buyers (Selling) Broker and verify the Credit Seller Earnest Money in excess of Commission amount is ZERO when earnet money is not present in file.";
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("BUYERBROKER","HUDFLINSR1", CommissionPercent: "10");

                Reports.TestStep = "Get buyer(Selling)broker name.";

               string BuyerBrokerfullName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText() +" " +
                     FastDriver.RealEstateBrokerAgent.BrokerName2.FAGetText();
                //

               Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
               Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
               Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
               Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
               Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
               Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
               Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());

                Reports.TestStep = "Create instance for Sellers (Listing) Broker"; 
                FastDriver.RealEstateBrokerAgentSummary.CreateAgentBroker("SELLERBROKER","HUDASLNDR1");
                                   string SellerBrokerfullName = FastDriver.RealEstateBrokerAgent.BrokerName1.FAGetText() +" " +
                     FastDriver.RealEstateBrokerAgent.BrokerName2.FAGetText();
                Reports.TestStep = "verify the Credit Seller Earnest Money in excess of Commission amount is ZERO when earnet money is not present in file.";
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());

                Reports.TestStep = "Enter Earnest Money amount and Earnest money distribution equally for Buyer Broker and seller Broker.";
                FastDriver.DepositOutsideEscrow.Open();
                DepositOutsideEscrowParameters DOEParams = new DepositOutsideEscrowParameters();
                DOEParams.TotalDeposit = 60;
                DOEParams.EarnerstMoneyHeldBy_0 = @"Seller's Broker";
               DOEParams.EarnerstMoneyAmount_0 = 30.00;
               DOEParams.EarnerstMoneyHeldBy_1 = @"Buyer's Broker";
               DOEParams.EarnerstMoneyAmount_1 = 30.00;

                FastDriver.DepositOutsideEscrow.Deposit(DOEParams);

               Support.AreEqual("True",  SellerBrokerfullName.Contains(FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetText()).ToString());
               Support.AreEqual("True", BuyerBrokerfullName.Contains(FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetText()).ToString());
               FastDriver.BottomFrame.Save();
               Thread.Sleep(3000);

                Reports.TestStep = "Verify when earnest money is greater than commision amout Credit Seller Earnest Money in excess of Commission check Box will be checked and the difference amount will be displayed in text Box for Buyer selling broker.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER");
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"-30.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());


                Reports.TestStep = "Enter commission amount less than earnest and verify diffference between earnest amount and commision amount.";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"10.00"+FAKeys.Tab);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                //
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"20.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"-20.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());

                Reports.TestStep = "Enter commission equal to earnest and verify diffference between earnest amount and commision amount.";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(@"30.00" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();

                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());

                Reports.TestStep = "Verify when earnest money is greater than commision amout Credit Seller Earnest Money in excess of Commission check Box will be checked and the difference amount will be displayed in text Box for seller listing Broker.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("SELLERBROKER", CommissionAmount: @"0.00");

                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"-30.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());
                //
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();
               
                Reports.TestStep = "Verify when earnest money is greater than commision amout Credit seller Earnest Money in excess of Commission check Box will be checked and the difference amount will be displayed in text Box for Buyer selling broker.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER", CommissionAmount: @"0.00");
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"-30.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());
                //
                FastDriver.LeftNavigation.ClickHome();
                FastDriver.WebDriver.HandleDialogMessage(false);
                FastDriver.WebDriver.HandleDialogMessage();
                //

                Reports.TestStep = "Enter commission amount less than earnest and verify diffference between earnest amount and commision amount.";
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker("BUYERBROKER", CommissionAmount: @"10.00");
                //FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(@"30.00", FastDriver.RealEstateBrokerAgent.HoldingEarnestMoneyAmount.FAGetText().ToString());
                Support.AreEqual("True", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.IsSelected().ToString());
                Support.AreEqual(@"20.00", FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesstextBox.FAGetValue().ToString());
                Support.AreEqual("False", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerCheckBox.IsSelected().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.CreditBuyerSellingBrokerTextBox.FAGetValue().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.BuyerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"0.00", FastDriver.RealEstateBrokerAgent.SellerCreditsPane.FAGetText().ToString());
                Support.AreEqual(@"-20.00", FastDriver.RealEstateBrokerAgent.NetCommissionCheckAmount.FAGetText().ToString());
                Support.AreEqual(@"10.00", FastDriver.RealEstateBrokerAgent.CommissionChargeAmount.FAGetText().ToString());

                //
                //Reports.TestStep = "Revert back value of commission amount";
                //FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("30.00" + FAKeys.Tab);
                //FastDriver.WebDriver.HandleDialogMessage(true);
                //
                Reports.TestStep = "Enter disburse as proceed amount.";
                FastDriver.DepositOutsideEscrow.Open();
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(@"70.00"+FAKeys.Tab);

                Support.AreEqual(@"Seller's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem());
                Support.AreEqual(@"30.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue());
                //
                Support.AreEqual(@"Buyer's Broker", FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem());
                Support.AreEqual(@"30.00", FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue());
                //
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText(@"10.00"+FAKeys.Tab);
                FastDriver.BottomFrame.Save();

                Thread.Sleep(5000);

                Reports.TestStep = "Perform Preview delivery.Please verify the Preview PDF for Disbursed as Proceeds amount.DISBURSE AS PROCCED =( (EARNEST AMOUNT - COMMISION AMOUNT) + FUNDS DUE FROM Broker/Attorney)";
                if (AutoConfig.FormType == "HUD")
                {
                    Reports.TestStep = "Preview in HUD";
                    PerformPreviewDeliveryHUD();
                }
                else
                {
                    Reports.TestStep = "Preview in CD";
                    PerformPreviewDeliveryCD();

                }
                
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        #endregion Test
        #endregion REG
        #region PRIVATEMETHODS
        private void IISLOGIN(string UserName = null, string Password = null)
        {
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, false);

        }
        //
        private void ADMLOGIN(string UserName = null, string Password = null)
        {
           
            UserName = UserName ?? AutoConfig.UserNameSU;
            Password = Password ?? AutoConfig.UserPasswordSU;
            Reports.TestStep = "Log in to the Admin site";
            Credentials credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

        }
        //
        private bool CreateFile(int SalesPrice=0)
        {
            try
            {
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                if (SalesPrice!=0)
                customizableFileRequest.File.SalesPriceAmount = SalesPrice;
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(customizableFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                return true;
            }
            catch (Exception)
            {
                try
                {
                    return CreateQFEWithSalesDetails(SalesPrice);
                }
                catch (Exception ex)
                {
                    throw new Exception("Unable to create QFE", ex);
                }

            }
        }
        //
        private bool CreateRefinanceFile(bool SetSalesPrice=true)
        {
            try
            {
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                if (SetSalesPrice)
                customizableFileRequest.File.SalesPriceAmount = 1000;
                customizableFileRequest.File.TransactionTypeObjectCD = "REFI";
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(customizableFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to create QFE", ex);
            }
        }
        //
        private bool CreateQFEWithSalesDetails(int SalesPrice = 0)
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            NewFileParameters QFEParams = new NewFileParameters();
            QFEParams = NewFileParameters.GetDefaultParams();
            if (SalesPrice!=0)
                QFEParams.TermsDatesSalesPrice = SalesPrice.ToString();
            QFEParams.PropertyInformationName = "J305";
            QFEParams.PropertyInformationType = "Single Family Residence";
            QFEParams.PropertyInformationLot = "Lot1";
            QFEParams.PropertyInformationBlock = "Block1";
            QFEParams.PropertyInformationUnit = "Unit1";
            QFEParams.PropertyPropTaxAPN1 = "Prop1APN1";
            QFEParams.PropertyPropTaxAPN2 = "9845012345";
            QFEParams.PropertyBookAddrLin1 = "J305";
            QFEParams.PropertyBookAddrLin2 = "JJEJAMQ";
            QFEParams.PropertyBookAddrLin3 = "JJEJAMQ";
            QFEParams.PropertyCity = "ALBANY";
            QFEParams.PropertyState = "CA";
            QFEParams.PropertyZipCode = "12345";
            QFEParams.PropertyCounty = "ALAMEDA";
            FastDriver.QuickFileEntry.CreateFile(QFEParams);
             try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }
             return true;
        }
        //
        private bool CreateQFEWithAdditionalRoleREB()
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            NewFileParameters QFEParams = new NewFileParameters();
            QFEParams = NewFileParameters.GetDefaultParams();
            QFEParams.BusinessSourceAdditionalRole = "Other Real Estate Agent";
            QFEParams.TermsDatesSalesPrice = "1000";
            QFEParams.PropertyInformationName = "J305";
            QFEParams.PropertyInformationType = "Single Family Residence";
            //QFEParams.PropertyInformationLot = "Lot1";
            //QFEParams.PropertyInformationBlock = "Block1";
            //QFEParams.PropertyInformationUnit = "Unit1";
            //QFEParams.PropertyPropTaxAPN1 = "Prop1APN1";
            //QFEParams.PropertyPropTaxAPN2 = "9845012345";
            QFEParams.PropertyBookAddrLin1 = "J305";
            QFEParams.PropertyBookAddrLin2 = "JJEJAMQ";
            QFEParams.PropertyBookAddrLin3 = "JJEJAMQ";
            QFEParams.PropertyCity = "ALBANY";
            QFEParams.PropertyState = "CA";
            QFEParams.PropertyZipCode = "12345";
            QFEParams.PropertyCounty = "ALAMEDA";
            FastDriver.QuickFileEntry.CreateFile(QFEParams);
            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }
            return true;
        }
        //
        //private void ValidateMessage(string ExpectedMessage)
        //{
        //    string Message = FastDriver.WebDriver.HandleDialogMessage();
        //    Support.AreEqualTrim(ExpectedMessage, Message);
        //}
        //
        private bool CompareDefaultAddress(Dictionary<string, string> ADMAddress, Dictionary<string, string> IISAddress)
        {
            int count = 0;
            bool result = false;
            foreach (var IISAddrItem in IISAddress)
            {
                
                string Value=IISAddrItem.Value;
                bool compare=ADMAddress.TryGetValue(IISAddrItem.Key, out Value);
                if(compare)
                {
                    count++;
                }
            }
            if (count == 8)
                result = true;
            else
                result = false;
            return result;
        }
        //
        private bool ValidateBlankAddress(Dictionary<string, string> IISAddress)
        {
            int count = 0;
            bool result = false;
            foreach (var KeyValuePair in IISAddress)
            {
                if (string.IsNullOrWhiteSpace(KeyValuePair.Value))
                {
                    count++;
                }
            }
            if (count == 8)
                result = true;
            else
                result = false;
            return result;
        }
        //
        private void SetGABContactStatus(string Status, string GAB)
        {
            
            FastDriver.BusPartyContactsList.WaitForScreenToLoad();
            Reports.TestStep = "BR_ES13445_ADMsetup: Set GAB contact status";
            FastDriver.BusPartyContactsList.ViewChangeStatus.FAClick();
            FastDriver.StatusEdit.WaitForScreenToLoad();

            if (Status.Equals("InActive", StringComparison.InvariantCultureIgnoreCase))
            {                
                if (FastDriver.StatusEdit.Deactivate.IsDisplayed())
                {
                    FastDriver.StatusEdit.Deactivate.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
            }

            else
            {
                if (FastDriver.StatusEdit.Activate.IsDisplayed())
                {
                    FastDriver.StatusEdit.Activate.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.WebDriver.HandleDialogMessage();
                }
            }

            FastDriver.BottomFrame.Done();
            FastDriver.BusPartyContactsList.WaitForScreenToLoad();

        }
        //
        private bool HandleDeliveryFailure(string deliveryMethod, int timeoutSeconds)
        {
            try
            {
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, timeoutSeconds);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                Reports.StatusUpdate(string.Format("'{0}' failed after {1} seconds.", deliveryMethod, timeoutSeconds), false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return false;
            }
        }
        private bool ValidateFieldForLowerOrExactLimit(IWebElement Element, string InputValue, string OutputValue, bool HandleDialog = false)
        { //we are using the random click to remove focus for field under test
            RandomClick();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            Element.FAClick();
            Element.FASetText(InputValue + FAKeys.Tab, false, true);

            if(HandleDialog)
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            if (OutputValue == Element.FAGetValue().Trim())
            {
                return true;
            }
            else

                return false;

        }
        //

        private bool ValidateFieldForUpperLimit(IWebElement Element, string InputValue, string OutputValue, bool HandleDialog = false)
        {
            //we are using the random click to remove focus for field under test
            RandomClick();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            Element.FAClick();
            Element.FASetText(InputValue + FAKeys.Tab, false, true);
            if (HandleDialog)
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            if (OutputValue == Element.FAGetValue().Trim())
                return true;
            else
                return false;
        }
        //we are using the random click to remove focus for field under test
        private void RandomClick()
        {
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.FileNumberEditBox.FAClick();
        }
        //
        private void SelectRegion()
        {
            
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
            Reports.TestStep = "Select QA Automation Region.";
            FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedRegionBUID);       
        }
        //
        private void SelectOffice()
        {
            
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
            Reports.TestStep = "Select QA Automation Region.";
            FastDriver.SecuritySelectRegionOffice.EnterBUID(AutoConfig.SelectedOfficeBUID);
        }
        //
        private void PerformPreviewDeliveryCD()
        {
            Thread.Sleep(500);
            Reports.TestStep = "Navigate to CD screen.";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
            Thread.Sleep(5000);
            FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
            Reports.TestStep = "Perform Preview delivery.";
            FastDriver.ClosingDisclosure.Combined.GiveFocus();
            //
            IWebElement Element = FastDriver.ClosingDisclosure.Combined.ScrollIntoView();
            Thread.Sleep(2000);
            if (!Element.IsDisplayed())
            {
                Reports.TestStep = @"Element is not displayed in a view.Scrolling... to display an elememt";
                FastDriver.ClosingDisclosure.ScrollToElement(FastDriver.ClosingDisclosure.Combined);
            }
            FastDriver.ClosingDisclosure.Combined.FASetCheckbox(true);
            //
            Element=FastDriver.ClosingDisclosure.DeliveryMethod.ScrollIntoView();
             Thread.Sleep(2000);
            if (!Element.IsDisplayed())
            {
                Reports.TestStep = @"Element is not displayed in a view.Scrolling... to display an elememt";
                FastDriver.ClosingDisclosure.ScrollToElement(FastDriver.ClosingDisclosure.DeliveryMethod);
            }
            FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
            
              // FastDriver.ClosingDisclosure.DeliveryButton.ScrollIntoView();

               FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
               HandleDeliveryFailure("Preview", 200);
               FastDriver.WebDriver.ClosePreviewWindow();
        }
        //
        private void PerformPreviewDeliveryHUD()
        {
            Thread.Sleep(500);
            Reports.TestStep = "Navigate to HUD-1 Statement screen.";
            FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>HUD-1 Statement");
            Thread.Sleep(5000);
            Reports.TestStep = "Perform Preview delivery.";
            FastDriver.HUD1PrintOptions.SwitchToContentFrame();
            FastDriver.HUD1PrintOptions.Method.FASelectItem("Preview");
            FastDriver.HUD1PrintOptions.Combined.FASetCheckbox(true);
            Thread.Sleep(2000);
            FastDriver.HUD1PrintOptions.Deliver.FAClick();
            HandleDeliveryFailure("Preview", 200);
            FastDriver.WebDriver.ClosePreviewWindow();
        }

  
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}


