﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using OpenQA.Selenium;
using System.Linq;
using SeleniumInternalHelpers;
using FASTWCFHelpers.FastFileService;


namespace EscrowChargeProcess
{
    /// <summary>
    /// Summary description for FMUC0056_MiscellaneousDisbursements
    /// </summary>
    [CodedUITest]
    public class FMUC0056_MiscellaneousDisbursements : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void FMUC0056_BAT0001()
        {
            try
            {
                Reports.TestStep = "Login to FAST";
                this.Login();


                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();


                //
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                FastDriver.MiscDisbursementDetail.Description.FASetText("Disbursemen2");
                FastDriver.MiscDisbursementDetail.Description.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("50.00");
                FastDriver.MiscDisbursementDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.SellerCharge.FASetText("50.00");
                FastDriver.MiscDisbursementDetail.SellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
                Support.AreEqual("Disbursemen2", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                FastDriver.MiscDisbursementDetail.Description.FASetText("Disbursemen1");
                FastDriver.MiscDisbursementDetail.Description.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("1.99");
                FastDriver.MiscDisbursementDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.MiscDisbursementDetail.SellerCharge.FASetText("1.99");
                FastDriver.MiscDisbursementDetail.SellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "validate a second Instance.";
                Support.AreEqual("Disbursemen1", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("1.99", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("1.99", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();
                Playback.Wait(1500);

                // 
                // 
                Reports.TestStep = "Verify the Miscelleneous Payee amount.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100.00", "Payee", TableAction.Click);
                //Playback.Wait(100000000);
                //Support.AreEqual(FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "100", "Payee", TableAction.GetCell).Element.FindElements(By.TagName("span"))
                // .FirstOrDefault(span => span.GetAttribute("id").Contains("_lblShortPayeeName") && span.Displayed).Text.Clean(), "Misc. Disbursement 1 for HUD Test Name 1");

                Support.AreEqual("Misc. Disbursement 1 for HUD Test Name 1", FastDriver.ActiveDisbursementSummary.Disbursementspayeename.Text.Clean());
                Support.AreEqual("Misc. Disbursement 2 for HUD Test Name 1", FastDriver.ActiveDisbursementSummary.Disbursementspayeename1.Text.Clean());
                Support.AreEqual("100.00", FastDriver.ActiveDisbursementSummary.DisbursementsAmount.Text.Clean());
                Support.AreEqual("3.98", FastDriver.ActiveDisbursementSummary.DisbursementsAmount1.Text.Clean());
                // Playback.Wait(100000000);
                // 
                // 
                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                FastDriver.LeftNavigation.Navigate<FileSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").SwitchToContentFrame();
                Support.AreEqual("SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.Text);
                Support.AreEqual("103.98-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text);
                Support.AreEqual("51.99", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text);
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }


        }

        [TestMethod]
        public void FMUC0056_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1: Create a Check Only No Buyer or Seller Charges Miscellaneous Disbursement.";

                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "50.00", SellerCharge: "50.00");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
                Support.AreEqual("Disbursemen2", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Playback.Wait(3000);


                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "Navigate to Summary screen and Click on NEW.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.New.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Create a Third Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(CheckOnlyDescription: "CheckDescription", CheckOnlyCharge: " $ 50.00");
                ;
                Support.AreEqual("Check Amount: $ 50.00", FastDriver.WebDriver.FindElement(By.Id("cgc_lblFooter")).Text);

                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Select Instance to Edit and Verify.";
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.WaitCreation(FastDriver.MiscellaneousDisbursementSummary.SummaryTable);
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "validate Third Instance.";
                Support.AreEqual("CheckDescription", FastDriver.MiscDisbursementDetail.CheckOnlyDescription.GetAttribute("value").ToString().Clean());
                Support.AreEqual("Check Amount: $ 50.00", FastDriver.WebDriver.FindElement(By.Id("cgc_lblFooter")).Text);
                FastDriver.BottomFrame.Done();

                // 
                //
                Reports.TestStep = "Verify the Miscelleneous Payee amount.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "50.00", "Payee", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                Support.AreEqual("SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.Text);
                Support.AreEqual("153.98-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text);
                Support.AreEqual("51.99", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text);

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0056_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF7: Cancel Changes to Existing Miscellaneous Disbursement Instance";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "50.00", SellerCharge: "50.00");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
                Support.AreEqual("Disbursemen2", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "Navigate to Summary screen and Click on NEW.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.New.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Create a Third Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(CheckOnlyDescription: "CheckDescription", CheckOnlyCharge: " $ 50.00");
                ;
                Support.AreEqual("Check Amount: $ 50.00", FastDriver.WebDriver.FindElement(By.Id("cgc_lblFooter")).Text);

                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Select Instance to Edit.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 1 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Edit and Cancel Instance.";
                this.FillMiscDisbursementDetail(BuyerCharge: "100.00", SellerCharge: "100.00");
                Support.AreEqual("Check Amount: $ 200.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Reset();

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "validate an Instance of Misc Disbursement Details.";
                Support.AreEqual("Disbursemen2", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0056_BAT0004()
        {
            try
            {
                //
                //
                Reports.TestDescription = "AF2: Edit a Miscellaneous Disbursement.";

                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "50.00", SellerCharge: "50.00");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
                Support.AreEqual("Disbursemen2", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                //
                //
                Reports.TestStep = "Select Instance to Edit.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 1 for HUD Test Name 1", "Name", TableAction.Click);

                //
                //
                Reports.TestStep = "Select Instance to Edit.";
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                this.FillMiscDisbursementDetail(BuyerCharge: "100.00", SellerCharge: "100.00");
                Support.AreEqual("Check Amount: $ 200.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Select Instance to Edit.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 1 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                // 
                // 
                Reports.TestStep = "Verify Edited the Instance.";
                Support.AreEqual("100.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("100.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("Check Amount: $ 200.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                // 
                // 
                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad().SwitchToContentFrame();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0056_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF3: Delete a Miscellaneous Disbursement.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "100.00", SellerCharge: "100.00");
                Support.AreEqual("Check Amount: $ 200.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
                //Support.AreEqual("Disbursemen2", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                //Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                //Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "Navigate to Summary screen and Click on NEW.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.New.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Create a Third Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(CheckOnlyDescription: "CheckDescription", CheckOnlyCharge: " $ 50.00");
                ;
                Support.AreEqual("Check Amount: $ 50.00", FastDriver.WebDriver.FindElement(By.Id("cgc_lblFooter")).Text);

                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();


                //
                //
                Reports.TestStep = "Select Instance to Remove.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Remove.FAClick();

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "verify deleted Instance.";
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                // 
                // 
                Reports.TestStep = "Verify the charge values after deleting an instance.";
                Support.AreEqual("", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("Check Amount: $ 0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Validate the data in Escrow File Balance Summary.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad().SwitchToContentFrame();
                Support.AreEqual("SHORT", FastDriver.EscrowFileBalanceSummary.Inbalance.Text);
                Support.AreEqual("203.98-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text);
                Support.AreEqual("101.99", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text);

                // 
                // 
                Reports.TestStep = "Verify the Miscelleneous Payee amount.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").SwitchToContentFrame();
                //"StatusS.FundsADocument #Issue DateAmountPayee\r\nPending   Check    0     200.00  Misc. Disbursement 1 for HUD Test Name 1 \r\n\r\nPending   Check    0     3.98  Misc. Disbursement 2 for HUD Test Name 1 
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", "200.00", "Payee", TableAction.Click);

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0056_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF4: Cancel 1st New Miscellaneous Disbursement Instance Creation.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "50.00", SellerCharge: "50.00");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                //
                //
                Reports.TestStep = "Cancel 1st Instance of Misc Disbursement Details.";
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                //
                ////
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "50.00", SellerCharge: "50.00");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
                Support.AreEqual("Disbursemen2", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0056_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF5: Cancel 2nd New Miscellaneous Disbursement Instance Creation.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "50.00", SellerCharge: "50.00");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                //
                //
                Reports.TestStep = "Cancel 1st Instance of Misc Disbursement Details.";
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                //
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "50.00", SellerCharge: "50.00");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "Cancel a second Instance.";
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "validate a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
                Support.AreEqual("Disbursemen2", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "validate a second Instance.";
                Support.AreEqual("Disbursemen1", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("1.99", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("1.99", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0056_BAT0008()
        {
            try
            {
                //
                //
                Reports.TestDescription = "AF6: Cancel 3rd or Subsequent New Miscellaneous Disbursement Instance Creation.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                // 
                Reports.TestStep = "Create a Instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "50.00", SellerCharge: "50.00");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Click New on Summary screen to create new instance.";
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.WaitCreation(FastDriver.MiscellaneousDisbursementSummary.SummaryTable);
                FastDriver.MiscellaneousDisbursementSummary.New.FAClick();

                // 
                // 
                Reports.TestStep = "Cancel a second Instance.";
                Playback.Wait(3000);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(3000);
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Click New on Summary screen to create new instance.";
                FastDriver.MiscellaneousDisbursementSummary.New.FAClick();

                // 
                // 
                Reports.TestStep = "Create a Third Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                Playback.Wait(2000);
                this.FillMiscDisbursementDetail(CheckOnlyDescription: "CheckDescription", CheckOnlyCharge: "50.00");
                //FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys("50.00");
                //Playback.Wait(20000000);
                //FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("Check Amount: $ 50.00", FastDriver.WebDriver.FindElement(By.Id("cgc_lblFooter")).Text);

                //Support.AreEqual("Check Amount: $ 50.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Select Instance to Edit and Verify.";
                FastDriver.MiscellaneousDisbursementSummary.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();


                // 
                // 
                Reports.TestStep = "validate Third Instance.";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Support.AreEqual("CheckDescription", FastDriver.MiscDisbursementDetail.CheckOnlyDescription.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.CheckOnlyCharge.GetAttribute("value").ToString().Clean());
                // Playback.Wait(10000000);
                IWebElement element = FastDriver.WebDriver.FindElement(By.Id("cgc_lblFooter"));
                Support.AreEqual("Check Amount: $ 50.00", element.Text.Clean());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion BAT

        #region REGRESSION

        [TestMethod]
        public void FMUC0056_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM1166_FM2549_FM2552_FM2553_FM2550_FM2551_EWC12: FMUC0056 Misc Disbursements, Required Data, Enter File Charge, Enter Buyer/Seller Charges, Display Check Amounts, Display Payment Details, Display Check Details.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Enter Buyer Description, Buyer Charge and seller charge and Click on Done.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                this.FillMiscDisbursementDetail(Description: "Disbursemen2", BuyerCharge: "50.00", SellerCharge: "50.00");
                Support.AreEqual("Check Amount: $ 100.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Validate: Error(s) occurred. See Message pane.";
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Error(s) occured. See Message pane.", message);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                //
                // 
                Reports.TestStep = "Verify for Business Party Require Error.";
                Support.AreEqual("BusOrgID: Business Party required", FastDriver.MiscDisbursementDetail.BusinessPartyRequired.Text.Clean());

                // 
                // 
                Reports.TestStep = "Enter Business Party for Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");

                // 
                // 
                Reports.TestStep = "Click on Check Details Button.";
                FastDriver.MiscDisbursementDetail.CheckDetails.FAClick();

                // 
                // 
                Reports.TestStep = "Edit Check Desc And Voucher Information.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.CheckDetailsDlg.Description.FASetText("Edited Check Details Description.");
                FastDriver.CheckDetailsDlg.VoucherInfo.FASetText("Edited Check Details Voucher Information.");
                FastDriver.CheckDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Click on payment details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                Playback.Wait(500);
                // Playback.Wait(30000000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();

                // 
                // 
                Reports.TestStep = "Change the payment details methods to POC.";
                //For CD- HUD remains to be coded.
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("0");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("50");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                    Playback.Wait(1500);
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod);
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem("POC");
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC");
                }
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                // 
                // 
                Reports.TestStep = "Verify that When the user enters the buyer and seller charge, the system shall disable the file charge entry.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                //Playback.Wait(5000000);
                Support.AreEqual("Disbursemen2", FastDriver.MiscDisbursementDetail.Description.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.BuyerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("50.00", FastDriver.MiscDisbursementDetail.SellerCharge.GetAttribute("value").ToString().Clean());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.CheckOnlyDescription.Exists().ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.CheckOnlyCharge.Exists().ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Click on payment details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                // 
                // 
                Reports.TestStep = "Change the payment details methods to POC.";
                if (AutoConfig.UseCDFormType)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0");
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("0");
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("50");
                    FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("50");
                    FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                    FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                }

                else
                {
                    FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItem("POC");
                    FastDriver.PaymentDetails.SellerPaidbyOthersPayMethod.FASelectItem("POC");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Verify for the Pencil Image after Edit Payment Method.";
                //Playback.Wait(100000000);

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0056_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM2106: When the user enters a check only charge, the system disables the buyer seller charge section.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                // 
                // 
                Reports.TestStep = "Create instance and Enter check only charges.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("247");
                this.FillMiscDisbursementDetail(CheckOnlyDescription: "AAANNNAA", CheckOnlyCharge:"-20");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //-
                //
                Reports.TestStep = "Verify for error message.";
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please correct invalid data entered.", message);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                this.FillMiscDisbursementDetail(CheckOnlyDescription: "Description13151719DescriptionDescription434547", CheckOnlyCharge: "100");
                FastDriver.BottomFrame.Done();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                Support.AreEqual("Description13151719DescriptionDescription4345",FastDriver.MiscDisbursementDetail.CheckOnlyDescription.GetAttribute("value").ToString().Clean());
               // Playback.Wait(200000000);

                //
                //
                Reports.TestStep = "Verify for error message when charge length is greater than 11";
               // while (true)
                //{
                    FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FAClick();
                   // Playback.Wait(100000000);
                    FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys("100000000000");
                    //if (FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FAGetValue().ToString().Clean().Equals("100000000000"))
                    //{ 
                    //    FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys(FAKeys.Tab);
                    //    break;
                    //}
                //}
                //FastDriver.BottomFrame.Done();
               // Playback.Wait(1000);
                //
                //
                Reports.TestStep = "Verify for error message.";
                FastDriver.BottomFrame.Done();
                string message2 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please correct invalid data entered.", message2);
                Playback.Wait(400);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
               
                ////
                ////
                //Reports.TestStep = "Verify for error message.";
                //string message3 = FastDriver.WebDriver.HandleDialogMessage();
                //Support.AreEqual("Please correct invalid data entered.", message2);
                //FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                //Playback.Wait(2000);

                //
                //Issue To Be fixed
                Reports.TestStep = "Enter Data";
                this.FillMiscDisbursementDetail(CheckOnlyDescription: "Description", CheckOnlyCharge: "20.20");
               // FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                //FastDriver.MiscDisbursementDetail.CheckOnlyDescription.SendKeys("Description" + FAKeys.Tab);
                //FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys("20.20");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);


                
                //
                // 
                Reports.TestStep = "Verify that When the user enters a check only charge, the system disables the buyer seller charge section.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                try 
                { 
                    Support.AreEqual("False", FastDriver.MiscDisbursementDetail.Description.Enabled.ToString()); 
                }
                catch(Exception )
                {
                Reports.StatusUpdate("Expected Condition: Description Field Disabled: true",true);
                }
                
                try
                {
                    Support.AreEqual("False", FastDriver.MiscDisbursementDetail.BuyerCharge.Enabled.ToString());
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Expected Condition: Buyer Charge Field Disabled: true", true);
                }

                try
                {
                    Support.AreEqual("False", FastDriver.MiscDisbursementDetail.SellerCharge.Enabled.ToString());
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Expected Condition: Buyer Charge Field Disabled: true", true);
                }
                Support.AreEqual("Description", FastDriver.MiscDisbursementDetail.CheckOnlyDescription.FAGetValue().ToString());
                Support.AreEqual("20.20", FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.Done();
            
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0056_REG0003()
        {
            try
            {
                Reports.TestDescription = "EW06_EW03_EW13_EW14: Verify the Error Warning Conditions.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();


                // 
                // 
                Reports.TestStep = "Enter Invalid ID.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("IN_VALID");

                // 
                // 
                Reports.TestStep = "ID Code Not Found.";
                string msg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("ID Code not found.", msg);

                // 
                // 
                Reports.TestStep = "Enter valid ID Code and charges.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                this.FillMiscDisbursementDetail(Description: "Description", BuyerCharge: "50.00", SellerCharge: "50.00");

                // 
                // 
                Reports.TestStep = "Delete Charge Description.";
                this.FillMiscDisbursementDetail(Description: "EMPTY");

                // 
                // 
                Reports.TestStep = "Delete Charge Description.";
                string msg1 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Unable to delete charge description. Charge description still has a charge amount.", msg1.Clean());

                // 
                // 
                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                string ms3 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Cancel without saving changes?", ms3);

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                // 
                // 
                Reports.TestStep = "Cancel a second Instance.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                string ms4 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Cancel without saving changes?", ms4);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Verify for the Two instance created and Click on New.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                Support.AreEqual("3", FastDriver.MiscellaneousDisbursementSummary.SummaryTable.GetRowCount().ToString());
                FastDriver.MiscellaneousDisbursementSummary.New.FAClick();

                // 
                // 
                Reports.TestStep = "Cancel a Third Instance.";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                string ms5 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Cancel without saving changes?", ms5);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Select Instance to Edit.";
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.WaitCreation(FastDriver.MiscellaneousDisbursementSummary.SummaryTable);
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 1 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();

                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                string ms6 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Cancel without saving changes?", ms6);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Select edit Name check Box and Enter invalid Email ID.";
                FastDriver.MiscDisbursementDetail.Edit.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.EmailAddress.FASetText("InValideMAIL");
                FastDriver.BottomFrame.Done();


                // 
                // 
                Reports.TestStep = "Enter invalid data.";
                string msg2 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please correct invalid data entered.", msg2);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Enter Valid Email Address and Checking Edit Name Check Box.";
                FastDriver.MiscDisbursementDetail.EmailAddress.FASetText("Misc@Disc.com");
                FastDriver.MiscDisbursementDetail.EditNamecheckbox.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Name field is required when Edit Name checkbox is selected.";
                string msg3 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Name field is required when Edit Name checkbox is selected.", msg3);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                Playback.Wait(10000);

                // 
                // 
                Reports.TestStep = "Enter name in Edit Name Text Field and reference Number.";
                if (!FastDriver.MiscDisbursementDetail.EditNamecheckbox.Selected)
                {
                    FastDriver.MiscDisbursementDetail.EditNamecheckbox.FAClick();
                }
                FastDriver.MiscDisbursementDetail.EditName.FASetText("EditName");
                FastDriver.MiscDisbursementDetail.Reference.FASetText("12345");

                // 
                // 
                Reports.TestStep = "Change GAB Code after Save reference Number.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDFLINSR1");

                // 
                // 
                Reports.TestStep = "Change Business Party have Ref No.";
                string msg4 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number. Do you want to retain the \"Reference\"/\"Loan\" Number?", msg4.Clean());
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate reference Number.";
                Support.AreEqual("12345", FastDriver.MiscDisbursementDetail.Reference.FAGetValue().Clean());

                // 
                // 
                Reports.TestStep = "Change GAB Code after Save reference Number.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDFLINSR1");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Validate reference Number is blank.";
                Support.AreEqual("", FastDriver.MiscDisbursementDetail.Reference.Text.Clean());

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0056_REG0004()
        {
            try
            {
                Reports.TestDescription = "EW15_EW2_EW1_EW7_EW4_EW5 : Verify the Error Warning Conditions.";

                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();


                // 
                // 
                Reports.TestStep = "Enter Invalid ID.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("IN_VALID");

                // 
                // 
                Reports.TestStep = "ID Code Not Found.";
                string msg = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("ID Code not found.", msg);

                // 
                // 
                Reports.TestStep = "Enter valid ID Code and charges.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                this.FillMiscDisbursementDetail(Description: "Description", BuyerCharge: "50.00", SellerCharge: "50.00");

                // 
                // 
                Reports.TestStep = "Delete Charge Description.";
                this.FillMiscDisbursementDetail(Description: "EMPTY");

                // 
                // 
                Reports.TestStep = "Delete Charge Description.";
                string msg1 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Unable to delete charge description. Charge description still has a charge amount.", msg1.Clean());

                // 
                // 
                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                string ms3 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Cancel without saving changes?", ms3);

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                // 
                // 
                Reports.TestStep = "Cancel a second Instance.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                string ms4 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Cancel without saving changes?", ms4);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Verify for the Two instance created and Click on New.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                Support.AreEqual("3", FastDriver.MiscellaneousDisbursementSummary.SummaryTable.GetRowCount().ToString());
                FastDriver.MiscellaneousDisbursementSummary.New.FAClick();

                // 
                // 
                Reports.TestStep = "Cancel a Third Instance.";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                string ms5 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Cancel without saving changes?", ms5);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Select Instance to Edit.";
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.WaitCreation(FastDriver.MiscellaneousDisbursementSummary.SummaryTable);
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 1 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();

                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                string ms6 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Cancel without saving changes?", ms6);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Select edit Name check Box and Enter invalid Email ID.";
                FastDriver.MiscDisbursementDetail.Edit.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.EmailAddress.FASetText("InValideMAIL");
                FastDriver.BottomFrame.Done();


                // 
                // 
                Reports.TestStep = "Enter invalid data.";
                string msg2 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please correct invalid data entered.", msg2);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Enter Valid Email Address and Checking Edit Name Check Box.";
                FastDriver.MiscDisbursementDetail.EmailAddress.FASetText("Misc@Disc.com");
                FastDriver.MiscDisbursementDetail.EditNamecheckbox.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Name field is required when Edit Name checkbox is selected.";
                string msg3 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Name field is required when Edit Name checkbox is selected.", msg3);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                Playback.Wait(10000);

                // 
                // 
                Reports.TestStep = "Enter name in Edit Name Text Field and reference Number.";
                if (!FastDriver.MiscDisbursementDetail.EditNamecheckbox.Selected)
                {
                    FastDriver.MiscDisbursementDetail.EditNamecheckbox.FAClick();
                }
                FastDriver.MiscDisbursementDetail.EditName.FASetText("EditName");
                FastDriver.MiscDisbursementDetail.Reference.FASetText("12345");

                // 
                // 
                Reports.TestStep = "Change GAB Code after Save reference Number.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDFLINSR1");

                // 
                // 
                Reports.TestStep = "Change Business Party have Ref No.";
                string msg4 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Changing the Business Party will remove \"Reference\"/\"Loan\" Number. Do you want to retain the \"Reference\"/\"Loan\" Number?", msg4.Clean());
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate reference Number.";
                Support.AreEqual("12345", FastDriver.MiscDisbursementDetail.Reference.FAGetValue().Clean());

                // 
                // 
                Reports.TestStep = "Change GAB Code after Save reference Number.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDFLINSR1");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Validate reference Number is blank.";
                Support.AreEqual("", FastDriver.MiscDisbursementDetail.Reference.Text.Clean());

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                // 
                // 
                Reports.TestStep = "Select Instance to Edit and Verify.";
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.WaitCreation(FastDriver.MiscellaneousDisbursementSummary.SummaryTable);
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);
                // 
                // 
                Reports.TestStep = "Verify for the Instance Edited and remove the same.";
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Flood Insurance 1 for HUD Testing Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Remove.FAClick();
                Playback.Wait(200);

                // 
                // 
                Reports.TestStep = "All information will be removed for this Miscellaneous Disbursement. Continue?.";
                string msg11 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("All information will be removed for this Miscellaneous Disbursement.  Continue?", msg11);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify for the Removal of instance.";
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Available", "Name", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Print All Checks.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod: "Print", timeoutSeconds: 400);
                //
                // 
                Reports.TestStep = "Try to delete the Instance after check Issued.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Remove.FAClick();

                //
                // 
                Reports.TestStep = "Validate: A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.";
                string msg12 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", msg12);
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Select Instance to Edit and Verify.";
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Enter Business Party for Instance.";
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");

                // 
                // 
                Reports.TestStep = "Validate: A check has been issued for this Payee. The Payee name cannot be changed.";
                string msg22 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("A check has been issued for this Payee. The Payee name cannot be changed.", msg22.Clean());
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Enter the Less amount as compared to Previously issued check.";
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("1.00" + FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Enter Less Than the issued Amount.";
                string msg32 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?", msg32.Clean());
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Enter the More amount as compared to Previously issued check.";
                FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("200.00" + FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Enter Greater Than the Issued Amount.";
                string msg323 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", msg323.Clean());
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }

        }

        [TestMethod]
        public void FMUC0056_REG0005()
        {
            try
            {
                Reports.TestDescription = "Verify_FieldValues: Verify the hot Keys.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                // 
                // 
                Reports.TestStep = "Verify the controls on Miscelleaous screen.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.AdHoc.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.CheckDetails.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.GABcode.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Find.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.IDCode.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Name.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Name1.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Edit.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.BusinessPhone.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.BusinessFax.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.CellPhone.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Pager.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.EmailAddress.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.StatusEmail.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Attention.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.EditNamecheckbox.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.EditName.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Reference.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.PaymentDetails.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Description.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.BuyerCharge.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.SellerCharge.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.CheckOnlyDescription.Exists().ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.CheckOnlyCharge.Exists().ToString());
                Support.AreEqual("Check Amount: $ 0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Verify for Enable Disable property of controls.";
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.AdHoc.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.CheckDetails.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.GABcode.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Find.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.IDCode.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Name.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Name1.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Edit.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.BusinessPhone.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.BusinessFax.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.CellPhone.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.Pager.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.EmailAddress.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.StatusEmail.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Attention.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.EditNamecheckbox.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.EditName.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Reference.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.PaymentDetails.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.Description.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.BuyerCharge.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.SellerCharge.Enabled.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.CheckOnlyDescription.Enabled.ToString());
                Support.AreEqual("False", FastDriver.MiscDisbursementDetail.CheckOnlyCharge.Enabled.ToString());
                Support.AreEqual("Check Amount: $ 0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Set an instance of Misc Disbursement Details.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("247");
                Playback.Wait(1500);
                this.FillMiscDisbursementDetail(Description: "misc description", BuyerCharge: "10.10", SellerCharge: "10.10");
                Playback.Wait(1500);

                // 
                // 
                Reports.TestStep = "Cancel using Shortcut Keys.";
                Reports.StatusUpdate("Used Shortcut Keys for BottomFrame Cancel", true);
                Keyboard.SendKeys("^Q");
                Playback.Wait(1500);
                // 
                // 
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                string message = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Cancel without saving changes?", message);

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                // 
                // 
                Reports.TestStep = "Delete us Shortcut Keys.";
                Reports.StatusUpdate("Used Shortcut Keys for BottomFrame Delete", true);
                Keyboard.SendKeys("^{DELETE}");
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "All information will be removed for this Miscellaneous Disbursement. Continue?.";
                message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("All information will be removed for this Miscellaneous Disbursement.  Continue?", message);
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Navigate to Misc Disbursement Details screen.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();


                // 
                // 
                Reports.TestStep = "New us Shortcut Keys.";
                Reports.StatusUpdate("Used Shortcut Keys for BottomFrame New", true);
                Keyboard.SendKeys("^N");

                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                Playback.Wait(1000);
                this.FillMiscDisbursementDetail(Description: "misc description", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Navigate to Summary screen and Click on NEW Using Hotkeys.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                Reports.StatusUpdate("Used Shortcut Keys for BottomFrame New", true);
                Keyboard.SendKeys("%N");

                //
                //
                Reports.TestStep = "Create a Third Instance.";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                this.FillMiscDisbursementDetail(CheckOnlyDescription: "CheckDescription", CheckOnlyCharge: "50");
                IWebElement element = FastDriver.WebDriver.FindElement(By.Id("cgc_lblFooter"));
                Support.AreEqual("Check Amount: $ 50.00", element.Text.Clean());
                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);


                //
                // 
                Reports.TestStep = "Print All checks.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ActiveDisbursementSummary.PrintAll.FAClick();
                FastDriver.PrintChecks.WaitForScreenToLoad();
                FastDriver.PrintChecks.Deliver.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod: "Print", timeoutSeconds: 400);

                // 
                // 
                Reports.TestStep = "Navigate to Summary screen and Click on EDIT Using Hotkeys.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 2 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad().SwitchToContentFrame();


                // 
                // 
                Reports.TestStep = "Reducing the amount after issuing the check.";
                this.FillMiscDisbursementDetail(BuyerCharge: "1.0");

                // 
                // 
                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File be out-of-balance. Do you wish to save the changes?.";
                message = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?", message.Clean());
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Reducing the amount after issuing the check.";
                this.FillMiscDisbursementDetail(BuyerCharge: "1.0");

                // 
                // 
                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File be out-of-balance. Do you wish to save the changes?.";
                message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?", message.Clean());
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Increasing the amount after issuing the check.";
                this.FillMiscDisbursementDetail(BuyerCharge: "10.0");

                // 
                // 
                Reports.TestStep = "A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?";
                message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", message.Clean());
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Delete Instance.";
                FastDriver.LeftNavigation.Navigate<MiscellaneousDisbursementSummary>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Remove.FAClick();
                //FastDriver.MiscDisbursementDetail.WaitForScreenToLoad().SwitchToContentFrame();

                //
                // 
                Reports.TestStep = "Validate: A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.";
                message = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", message.Clean());
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }


        [TestMethod]
        public void FMUC0056_REG0006()
        {
            try
            {
                Reports.TestDescription = "EW08_EW09_EW10_EW11 : Verify the Error Warning Conditions.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                // 
                Reports.TestStep = "Set an instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("247");
                this.FillMiscDisbursementDetail(Description: "misc description", BuyerCharge: "10.10", SellerCharge: "10.10");

                // 
                // 
                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "Verify Cancellation of First Instance.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                Support.AreEqual("", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());

                // 
                // 
                Reports.TestStep = "Set an instance of Misc Disbursement Details.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.FindGABcode("247");
                this.FillMiscDisbursementDetail(Description: "misc description", BuyerCharge: "10.10", SellerCharge: "10.10");

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Verify First Instance.";
                Support.AreEqual("misc description", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual("10.10", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("10.10", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());

                // 
                // 
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();

                // 
                // 
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Verify the Cancel.";
                Support.AreEqual("Disbursemen1", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual("1.99", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("1.99", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());

                // 
                // 
                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();


                // 
                // 
                Reports.TestStep = "Click on OK button.";
                FastDriver.WebDriver.HandleDialogMessage();

                // 
                // 
                Reports.TestStep = "Verify First Instance.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                Support.AreEqual("misc description", FastDriver.MiscDisbursementDetail.Description.FAGetValue().Clean());
                Support.AreEqual("10.10", FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue().Clean());
                Support.AreEqual("10.10", FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue().Clean());

                // 
                // 
                Reports.TestStep = "Create a second Instance.";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB2");
                this.FillMiscDisbursementDetail(Description: "Disbursemen1", BuyerCharge: "1.99", SellerCharge: "1.99");
                Support.AreEqual("Check Amount: $ 3.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Clean());


                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();

                // 
                // 
                Reports.TestStep = "Create a Third Instance.";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB3");
                this.FillMiscDisbursementDetail(CheckOnlyDescription: "CheckDescription", CheckOnlyCharge: "50");
                IWebElement element = FastDriver.WebDriver.FindElement(By.Id("cgc_lblFooter"));
                Support.AreEqual("Check Amount: $ 50.00", element.Text.Clean());
                //Playback.Wait(2000000);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Select Instance to Edit and Verify.";
                FastDriver.MiscellaneousDisbursementSummary.SwitchToContentFrame();
                FastDriver.MiscellaneousDisbursementSummary.WaitForScreenToLoad();
                FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction("Name", "Misc. Disbursement 3 for HUD Test Name 1", "Name", TableAction.Click);
                FastDriver.MiscellaneousDisbursementSummary.Edit.FAClick();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion REGRESSION

        #region Custom Methods

        private void Login(bool admLogin = false)
        {
            if (!admLogin)
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,                // AutoConfig.UserName,
                    Password = AutoConfig.UserPassword            //AutoConfig.UserPassword
                };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            }
            else
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            }

            //
            //

        }

        public static int CreateFile()
        {
            var customFile = RequestFactory.GetDetailedCreateFileDefaultRequest();
            customFile.formType = FormType.CD;
            customFile.File.Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA", 
                                    Zip= "92707"
                                } 
                            } 
                        } 
                    };
            try
            {
                int? FileID = FileService.CreateFile(customFile).FileID;
                return (int)FileID;
            }
            catch (Exception)
            {

                throw new Exception("Unable to retrieve FileID.");
            }
        }

        private void CreateFileWithWCF()
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }
        private void CreateFileWithWCF(CreateFileRequest fileRequest)
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }

        private void FillMiscDisbursementDetail(string Description = "", string BuyerCharge = "", string SellerCharge = "", string CheckOnlyDescription = "", string CheckOnlyCharge = "")
        {

            if (!Description.Equals(""))
            {
                if (!Description.Equals("EMPTY"))
                {
                    FastDriver.MiscDisbursementDetail.Description.FASetText(Description);
                    FastDriver.MiscDisbursementDetail.Description.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.Description.FASetText("");
                    FastDriver.MiscDisbursementDetail.Description.SendKeys(FAKeys.Tab);
                }
            }

            if (!BuyerCharge.Equals(""))
            {
                if (!BuyerCharge.Equals("EMPTY"))
                {
                    FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText(BuyerCharge);
                    FastDriver.MiscDisbursementDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.BuyerCharge.FASetText("");
                    FastDriver.MiscDisbursementDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                }
            }

            if (!SellerCharge.Equals(""))
            {
                if (!SellerCharge.Equals("EMPTY"))
                {
                    FastDriver.MiscDisbursementDetail.SellerCharge.FASetText(SellerCharge);
                    FastDriver.MiscDisbursementDetail.SellerCharge.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.SellerCharge.FASetText("");
                    FastDriver.MiscDisbursementDetail.SellerCharge.SendKeys(FAKeys.Tab);
                }
            }

            if (!CheckOnlyDescription.Equals(""))
            {
                if (!CheckOnlyDescription.Equals("EMPTY"))
                {
                    FastDriver.MiscDisbursementDetail.CheckOnlyDescription.FASetText(CheckOnlyDescription);
                    FastDriver.MiscDisbursementDetail.CheckOnlyDescription.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.CheckOnlyDescription.FASetText("");
                    FastDriver.MiscDisbursementDetail.CheckOnlyDescription.SendKeys(FAKeys.Tab);
                }
            }

            if (!CheckOnlyCharge.Equals(""))
            {
                if (!CheckOnlyCharge.Equals("EMPTY"))
                {
                    //FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FASetText("");
                    FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys(CheckOnlyCharge + FAKeys.Tab);
                    //FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys(FAKeys.Tab);
                }
                else
                {
                    FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FASetText("");
                    FastDriver.MiscDisbursementDetail.CheckOnlyCharge.SendKeys(FAKeys.Tab);
                }
            }



        }

        #endregion Custom Methods


        #region Class CleanUp
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
        #endregion Class Cleanup
    }
}
