﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;


namespace EscrowChargeProcess
{
    [CodedUITest]
    public class FMUC0054_Offset_MiscellaneousAdjustments : MasterTestClass
    {
        #region BAT
        [TestMethod]
        public void FMUC0054_BAT0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "MF1: Create Miscellaneous Adjustment Instance";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                    FastDriver.AdjustmentMisc.SellerCredit.FASetText("50.00" + FAKeys.Tab);
                Support.AreEqual("50.00", FastDriver.AdjustmentMisc.BuyerTotal.Text.Clean(), "Buyer Total amount");
                Support.AreEqual(AutoConfig.UseCDFormType ? "0.00" : "50.00", FastDriver.AdjustmentMisc.SellerTotal.Text.Clean(), "Seller Total amount");

                Reports.TestStep = "Validate Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                Support.AreEqual("50.00", FastDriver.AdjustmentMisc.BuyerCredit.FAGetValue().Clean(), "Validate Buyer Credit");
                if (!AutoConfig.UseCDFormType) Support.AreEqual("100.00", FastDriver.AdjustmentMisc.SellerCredit.FAGetValue().Clean(), "Validate Seller Credit");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate adjustment buyer and seller charge.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.UseCDFormType ? "50.00" : "100.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.Text.Clean(), "Net Total Disbursement Amount");
                Support.AreEqual(AutoConfig.UseCDFormType ? "50.00-" : "100.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Clean(), "File Balance Amount");
                Support.AreEqual("", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text.Clean(), "Buyer Funds Due Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0054_BAT0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF1: Create Off-Set Adjustment instance";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create Misc Adjustment Instance (data from test case BAT0001).";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                    FastDriver.AdjustmentMisc.SellerCredit.FASetText("50.00" + FAKeys.Tab);

                Reports.TestStep = "Create off-set adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("50.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("50.00" + FAKeys.Tab);
                }

                Reports.TestStep = "Validate off-set adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                Support.AreEqual("50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean(), "Buyer Charge amount");
                Support.AreEqual("50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean(), "Seller Credit amount");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("50.00", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean(), "Buyer Credit amount");
                    Support.AreEqual("50.00", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean(), "Seller Charge amount");
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate adjustments in File Balance Summary.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.UseCDFormType ? "50.00" : "100.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.Text.Clean(), "Net Total Disbursement Amount");
                Support.AreEqual(AutoConfig.UseCDFormType ? "50.00-" : "100.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Clean(), "File Balance Amount");
                Support.AreEqual("", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text.Clean(), "Buyer Funds Due Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0054_BAT0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF2: Modify Misc. Adjustment";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create Misc Adjustment Instance (data from test case BAT0001).";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType) FastDriver.AdjustmentMisc.SellerCredit.FASetText("50.00" + FAKeys.Tab);

                Reports.TestStep = "Create off-set adjustment (data from test case BAT0002).";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("50.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("50.00" + FAKeys.Tab);
                }

                Reports.TestStep = "Modify Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.BuyerCredit.FASetText("100.00" + FAKeys.Tab);
                Support.AreEqual("100.00", FastDriver.AdjustmentMisc.BuyerTotal.Text.Clean(), "Buyer Total amount");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentMisc.SellerCredit.FASetText("100.00" + FAKeys.Tab);
                    Support.AreEqual("100.00", FastDriver.AdjustmentMisc.SellerTotal.Text.Clean(), "Seller Total amount");
                }

                Reports.TestStep = "Verify Modified Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                Support.AreEqual("100.00", FastDriver.AdjustmentMisc.BuyerCredit.FAGetValue().Clean(), "Validate Buyer Credit");
                if (!AutoConfig.UseCDFormType) Support.AreEqual("100.00", FastDriver.AdjustmentMisc.SellerCredit.FAGetValue().Clean(), "Validate Seller Credit");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate adjustment buyer and seller charge.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.UseCDFormType ? "100.00" : "200.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.Text.Clean(), "Net Total Disbursement Amount");
                Support.AreEqual(AutoConfig.UseCDFormType ? "100.00-" : "200.00-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Clean(), "File Balance Amount");
                Support.AreEqual("", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text.Clean(), "Buyer Funds Due Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0054_BAT0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "AF3: Delete Misc. Adjustment";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Delete Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.BuyerCredit.FASetText(FAKeys.Tab);
                if (!AutoConfig.UseCDFormType) FastDriver.AdjustmentMisc.SellerCredit.FASetText(FAKeys.Tab);

                Reports.TestStep = "Verify Deleted Misc Adjustment Instance.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.AdjustmentMisc.BuyerCredit.FAGetValue().Clean(), "Validate Buyer Credit");
                if (!AutoConfig.UseCDFormType) Support.AreEqual("", FastDriver.AdjustmentMisc.SellerCredit.FAGetValue().Clean(), "Validate Seller Credit");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate adjustment buyer and seller charge.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.Text.Clean(), "Net Total Disbursement Amount");
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Clean(), "File Balance Amount");
                Support.AreEqual("", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.Text.Clean(), "Buyer Funds Due Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG
        [TestMethod]
        public void FMUC0054_REG0001()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM1164_FM2107_FM2350: 1: Adjustments. 2: Create Off-Set. 3: Update Entry Recap Totals.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Buyer charge and Verify for Seller credit.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("50.00" + FAKeys.Tab);
                Support.AreEqual("50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean(), "Seller Credit amount");
                Support.AreEqual("50.00", FastDriver.AdjustmentMisc.SellerTotal.Text.Clean(), "Seller Total amount");
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Enter Buyer credit and Verify for Seller charge.";
                FastDriver.AdjustmentOffset.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                    Support.AreEqual("50.00", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean(), "Seller Charge amount");
                    Support.AreEqual("50.00", FastDriver.AdjustmentMisc.BuyerTotal.Text.Clean(), "Buyer Total amount");
                }
                else
                {
                    Support.AreEqual("False", FastDriver.AdjustmentOffset.BuyerCredit.Enabled.ToString(), "Buyer Credit should be disabled");
                    Support.AreEqual("False", FastDriver.AdjustmentOffset.SellerCharge.Enabled.ToString(), "Seller Charge should be disabled");
                }
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Enter Seller charge.";
                FastDriver.AdjustmentOffset.WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("50.00" + FAKeys.Tab);
                    Support.AreEqual("50.00", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean(), "Buyer Credit amount");
                }
                else
                {
                    Support.AreEqual("False", FastDriver.AdjustmentOffset.BuyerCredit.Enabled.ToString(), "Buyer Credit should be disabled");
                    Support.AreEqual("False", FastDriver.AdjustmentOffset.SellerCharge.Enabled.ToString(), "Seller Charge should be disabled");
                }
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Enter Seller Credit.";
                FastDriver.AdjustmentOffset.WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("50.00" + FAKeys.Tab);

                Reports.TestStep = "Verify for Buyer charge.";
                Support.AreEqual("50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean(), "Buyer Charge amount");
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Create offset adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("50.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("50.00" + FAKeys.Tab);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0054_REG0002()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM2108_FM2618: 1: Add Buyer or Seller Credit from Real Estate Broker. 2: Update Buyer/Seller Credit.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create offset adjustment. (data from REG0001)";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("50.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("50.00" + FAKeys.Tab);
                }

                Reports.TestStep = "Enter Buyer credit and Seller credit for Seller Listing Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("100.00");
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("50.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Buyer credit and Seller credit for Buyer Selling Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("100.00");
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("50.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Buyer credit and Seller credit for Other Broker.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDOTHRBR1");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("100.00");
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("50.00");
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("50.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Listing Broker Credit to Buyer and Listing Broker Credit to Seller are not present here.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.AdjustmentMisc.BuyerCredit.FAGetValue().Clean(), "Verify Buyer Credit");
                Support.AreEqual("", FastDriver.AdjustmentMisc.SellerCredit.FAGetValue().Clean(), "Verify Seller Credit");
                Support.AreEqual("", FastDriver.AdjustmentMisc.BuyerCredit2.FAGetValue().Clean(), "Verify Buyer Credit 2");
                Support.AreEqual("", FastDriver.AdjustmentMisc.SellerCredit2.FAGetValue().Clean(), "Verify Seller Credit 2");

                Reports.TestStep = "Validate offset adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                Support.AreEqual("50.00", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean(), "Verify Buyer Charge");
                Support.AreEqual("50.00", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean(), "Verify Seller Credit");
                if (!AutoConfig.UseCDFormType)
                {
                    Support.AreEqual("50.00", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean(), "Verify Buyer Credit");
                    Support.AreEqual("50.00", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean(), "Verify Seller Charge");
                }
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0054_REG0003()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var createFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                createFileRequest.File.Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    } 
                                }
                            },
                            ServiceTypeObjectCD = "EO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "SEO"
                        }
                    };
                #endregion

                Reports.TestDescription = "FM1164_ES6087: 1: Adjustments. 2: Disable Adjustment Entry in Sub Escrow Files.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF(createFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Verify for Disable charges if file is subescrow.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                Support.AreEqual(AutoConfig.UseCDFormType ? "True" : "False", FastDriver.AdjustmentMisc.description.Enabled.ToString(), "'Description' field should be " + (AutoConfig.UseCDFormType ? "enabled." : "disabled."));
                Support.AreEqual("False", FastDriver.AdjustmentMisc.BuyerCharge.Enabled.ToString(), "'Buyer Charge' field should be disabled.");
                Support.AreEqual("True", FastDriver.AdjustmentMisc.BuyerCredit.Enabled.ToString(), "'Buyer Credit' field should be enabled.");
                Support.AreEqual(AutoConfig.UseCDFormType ? "True" : "False", FastDriver.AdjustmentMisc.SellerCharge.Enabled.ToString(), "'Seller Charge' field should be " + (AutoConfig.UseCDFormType ? "enabled." : "disabled."));
                Support.AreEqual("True", FastDriver.AdjustmentMisc.SellerCredit.Enabled.ToString(), "'Seller Credit' field should be enabled.");
                Support.AreEqual(AutoConfig.UseCDFormType ? "False" : "True", FastDriver.AdjustmentMisc.description2.Enabled.ToString(), "'Description 2' field should be " + (AutoConfig.UseCDFormType ? "disabled." : "enabled."));
                Support.AreEqual("False", FastDriver.AdjustmentMisc.BuyerCharge2.Enabled.ToString(), "'Buyer Charge 2' field should be disabled.");
                //Support.AreEqual("False", FastDriver.AdjustmentMisc.BuyerCredit2.Enabled.ToString(), "'Buyer Credit 2' field should be disabled."); //this one failed on CD form type
                Support.AreEqual(AutoConfig.UseCDFormType ? "True" : "False", FastDriver.AdjustmentMisc.BuyerCredit2.Enabled.ToString(), "'Buyer Credit 2' field should be " + (AutoConfig.UseCDFormType ? "enabled." : "disabled."));
                Support.AreEqual("False", FastDriver.AdjustmentMisc.SellerCharge2.Enabled.ToString(), "'Seller Charge 2' field should be disabled.");
                Support.AreEqual(AutoConfig.UseCDFormType ? "False" : "True", FastDriver.AdjustmentMisc.SellerCredit2.IsReadOnly().ToString(), "'Seller Credit 2' field " + (AutoConfig.UseCDFormType ? "shouldn't" : "should") + " be read-only");

                Reports.TestStep = "To verify Adjustments-Off set link doesn't exist.";
                bool exists = false;
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                try { exists = FastDriver.LeftNavigation.TreeView.FindElement(By.LinkText("Off-Set")).Displayed; }
                catch (Exception) { exists = false; }
                Support.AreEqual("False", exists.ToString(), "'Off-Set' link shouldn't be displayed.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0054_REG0004()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM1164_FM3930_EWC1: 1: Adjustments. 2: Delete an Adjustment Entry. 3: User tries to delete a charge description that has a charge amount.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create off-set adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("50.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("50.00" + FAKeys.Tab);
                }
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete Charge.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("#" + Keys.Delete);
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create off-set adjustment.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("50.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("50.00" + FAKeys.Tab);
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("50.00" + FAKeys.Tab);
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("50.00" + FAKeys.Tab);
                }
                FastDriver.BottomFrame.Done();

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Delete Charge description.";
                    FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                    FastDriver.AdjustmentOffset.description.FASetText(FAKeys.Tab);
                    Support.AreEqual(@"Unable to delete charge description. Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage().Clean());
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0054_REG0005()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FD: Field Definitions";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var fileNumber = FastDriver.FACreateFileFromWCF();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean(), "Buyer Charge field text should be properly masked.");
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean(), "Seller Credit field text should be properly masked.");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.description.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH" + FAKeys.Tab);
                    Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.AdjustmentOffset.description.FAGetValue().Clean(), "Description field text should be properly updated.");
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                    Support.AreEqual("99,999,999,999.99", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean(), "Buyer Credit field text should be properly masked.");
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                    Support.AreEqual("99,999,999,999.99", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean(), "Seller Charge field text should be properly masked.");
                }
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.description.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI" + FAKeys.Tab);
                    Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.AdjustmentOffset.description.FAGetValue().Clean(), "Description field text should be properly updated.");
                }
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with Exact Value.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("10000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AdjustmentOffset.BuyerCharge.FAGetValue().Clean(), "Buyer Charge field text should be reset because of unsupported amount.");
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("10000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AdjustmentOffset.SellerCredit.FAGetValue().Clean(), "Seller Credit field text should be reset because of unsupported amount.");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentOffset.description.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ" + FAKeys.Tab);
                    Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.AdjustmentOffset.description.FAGetValue().Clean(), "Description field text should remove extra chars.");
                    FastDriver.AdjustmentOffset.BuyerCredit.FASetText("10000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                    Support.AreEqual("?", FastDriver.AdjustmentOffset.BuyerCredit.FAGetValue().Clean(), "Buyer Credit field text should be reset because of unsupported amount.");
                    FastDriver.AdjustmentOffset.SellerCharge.FASetText("10000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                    Support.AreEqual("?", FastDriver.AdjustmentOffset.SellerCharge.FAGetValue().Clean(), "Seller Charge field text should be reset because of unsupported amount.");
                }
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.SellerCredit2.SendKeys(FAKeys.Tab);
                FastDriver.AdjustmentMisc.description3.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGH", FastDriver.AdjustmentMisc.description3.FAGetValue().Clean(), "Description field text should be properly updated.");
                FastDriver.AdjustmentMisc.BuyerCredit3.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AdjustmentMisc.BuyerCredit3.FAGetValue().Clean(), "Buyer Credit field text should be properly masked.");
                FastDriver.AdjustmentMisc.SellerCharge3.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                Support.AreEqual("99,999,999,999.99", FastDriver.AdjustmentMisc.SellerCharge3.FAGetValue().Clean(), "Seller Charge field text should be properly masked.");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentMisc.BuyerCharge3.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                    Support.AreEqual("99,999,999,999.99", FastDriver.AdjustmentMisc.BuyerCharge3.FAGetValue().Clean(), "Buyer Charge field text should be properly masked.");
                    FastDriver.AdjustmentMisc.SellerCredit3.FASetText("99999999999.9" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + "9" + FAKeys.Tab);
                    Support.AreEqual("99,999,999,999.99", FastDriver.AdjustmentMisc.SellerCredit3.FAGetValue().Clean(), "Seller Credit field text should be properly masked.");
                }
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button."; 
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with lower Boundary Value.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.SellerCredit2.SendKeys(FAKeys.Tab);
                FastDriver.AdjustmentMisc.description3.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.AdjustmentMisc.description3.FAGetValue().Clean(), "Description field text should be properly updated.");
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verify the Field with Exact Value.";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.SellerCredit2.SendKeys(FAKeys.Tab);
                FastDriver.AdjustmentMisc.description3.FASetText("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIJ" + FAKeys.Tab);
                Support.AreEqual("ABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHIABCDEFGHI", FastDriver.AdjustmentMisc.description3.FAGetValue().Clean(), "Description field text should be properly updated.");
                FastDriver.AdjustmentMisc.BuyerCredit3.FASetText("10000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AdjustmentMisc.BuyerCredit3.FAGetValue().Clean(), "Buyer Credit field text should be reset because of unsupported amount.");
                FastDriver.AdjustmentMisc.SellerCharge3.FASetText("10000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Support.AreEqual("?", FastDriver.AdjustmentMisc.SellerCharge3.FAGetValue().Clean(), "Seller Charge field text should be reset because of unsupported amount.");
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.AdjustmentMisc.BuyerCharge3.FASetText("10000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                    Support.AreEqual("?", FastDriver.AdjustmentMisc.BuyerCharge3.FAGetValue().Clean(), "Buyer Charge field text should be reset because of unsupported amount.");
                    FastDriver.AdjustmentMisc.SellerCredit3.FASetText("10000000000000000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                    FastDriver.WebDriver.HandleDialogMessage();
                }
                FastDriver.BottomFrame.Reset();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0054_REG0006_PH()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "FM3932_FM3931_ES9769: 1:No Check Details for Adjustments 2:No Payment Details for Adjustments 3:Populate IBA Interest as Miscellaneous Adjustment Credit";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Assert.Inconclusive("This Flow has NOT been Automated Please perform this MANUALLY");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}