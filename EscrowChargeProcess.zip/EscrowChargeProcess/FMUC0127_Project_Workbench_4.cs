﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UITesting;
using FASTWCFHelpers.Factories;
using System.IO;

namespace EscrowChargeProcess
{
    public partial class FMUC0127_Project_Workbench : MasterTestClass
    {
        #region User_Story_473025_1

        [TestMethod]
        public void User_Story_473025_1_2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "US473025: TC553382 TC553389: Project Summary - Project file Information";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "DFTCOM";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();

                Reports.TestStep = "Verify Project Summary fields are listed";
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyNameTitle.IsVisible(), "Verifying Property Name is visible");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyNameValue.IsVisible(), "Verifying Property Name is visible");

                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyAddressTitle.IsVisible(), "Verifying Property Address is visible");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyAddressValue.IsVisible(), "Verifying Property Address is visible");

                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryBusinessSourceTitle.IsVisible(), "Verifying Business Source is visible");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryBusinessSourceValue.IsVisible(), "Verifying Business Source is visible");

                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryServiceTypeTitle.IsVisible(), "Verifying Service Type is visible");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryServiceTypeValue.IsVisible(), "Verifying Service Type is visible");

                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTransactionTypeTitle.IsVisible(), "Verifying Transaction Type is visible");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTransactionTypeValue.IsVisible(), "Verifying Transaction Type is visible");

                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryEscrowOwningOfficeTitle.IsVisible(), "Verifying Escrow Owning Office is visible");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryEscrowOwningOfficeValue.IsVisible(), "Verifying Escrow Owning Office is visible");

                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTitleOwningOfficeTitle.IsVisible(), "Verifying Title Owning Office is visible");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTitleOwningOfficeValue.IsVisible(), "Verifying Title Owning Office is visible");

                Reports.TestStep = "Navigate to File Homepage";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Change Title and Escrow Owning Office";
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FASelectItem("QA Automation Office1 - DO NOT TOUCH PR: STEST Off: 7879 (2811)");
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                var titleOwninOffice = FastDriver.ChangeOwningOfficeRemoveServiceType.TitleOwningOffice.FAGetSelectedItem();
                FastDriver.BottomFrame.Done();
                FastDriver.WarningDlg.Handle(true);

                Reports.TestStep = "Change Transaction Type";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Sale/Cash");
                var transactionType = FastDriver.FileHomepage.TransactionType.FAGetSelectedItem();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Property/Tax Info";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();

                Reports.TestStep = "Modify Property Name & Address";
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("New Name PI");
                var propertyName = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().Clean();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("ALAMEDA");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();

                Reports.TestStep = "Verify changes in Project Summary fields";
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyNameValue.FAGetText().Contains(propertyName), "Verifying Property Name value");                
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyAddressValue.FAGetText().Contains("ALAMEDA CA ALAMEDA USA"), "Verifying Property Address value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryServiceTypeValue.FAGetText().Contains("Title"), "Verifying Service Type value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTransactionTypeValue.FAGetText().Contains(transactionType), "Verifying Transaction Type value");
                //Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryEscrowOwningOfficeValue.IsVisible(), "Verifying Escrow Owning Office is visible");               
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTitleOwningOfficeValue.FAGetText().Contains("QA Automation Office1 - DO NOT TOUCH"), "Verifying Title Owning Office value");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void User_Story_473025_3_4()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "US473025: TC553819 TC557202: Project Summary - Project file Information";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "DFTCOM";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();

                Reports.TestStep = "Verify Project Summary has collapsible icon";
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTab.IsVisible(), "Verifying Project Summary has collapsible icon");
                FastDriver.ProjectWorkBench.ProjSummaryTab.FAClick();
                FastDriver.ProjectWorkBench.ProjSummaryTab.FAClick();

                Reports.TestStep = "Navigate to Property/Tax Info";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();

                Reports.TestStep = "Modify Property Name & Address";
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("New Name PI");
                var propertyName = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().Clean();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("ALAMEDA");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a new address";
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("New Name PI 2");
                var propertyName2 = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().Clean();
                FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("ALACHUA");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("ALACHUA");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("FL");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PropertiesSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.PropertiesSummary.PropertiesSummaryTable.FAGetText().Contains(propertyName2) ,"Verifying second address is added");

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();

                Reports.TestStep = "Verify changes in Project Summary fields";
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyNameValue.FAGetText().Contains(propertyName), "Verifying Property Name value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyAddressValue.FAGetText().Contains("ALAMEDA CA ALAMEDA USA"), "Verifying Property Address value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryServiceTypeValue.FAGetText().Contains("Title / Escrow"), "Verifying Service Type value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTransactionTypeValue.FAGetText().Contains("Sale w/Mortgage"), "Verifying Transaction Type value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryEscrowOwningOfficeValue.FAGetText().Contains("QA Automation Office - DO NOT TOUCH"), "Verifying Escrow Owning Office is visible");               
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTitleOwningOfficeValue.FAGetText().Contains("QA Automation Office - DO NOT TOUCH"), "Verifying Title Owning Office value");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void User_Story_473025_5()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "US473025: TC558476: Project Summary - Project file Information";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "DFTCOM";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.ChangeOO.FAClick();
                FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
                FastDriver.ChangeOwningOfficeRemoveServiceType.Escrow.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Set Sub Escrow for the file";
                FastDriver.FileHomepage.SubEscrow.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Terms/Dates/Status and set Liability";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("5000" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Property/Tax Info";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();

                Reports.TestStep = "Modify Property Name & Address";
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("New Name PI");
                var propertyName = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().Clean();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("ALAMEDA");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();

                Reports.TestStep = "Verify changes in Project Summary fields";
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyNameValue.FAGetText().Contains(propertyName), "Verifying Property Name value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyAddressValue.FAGetText().Contains("ALAMEDA CA ALAMEDA USA"), "Verifying Property Address value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryServiceTypeValue.FAGetText().Contains("Title / Sub Escrow"), "Verifying Service Type value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTransactionTypeValue.FAGetText().Contains("Sale w/Mortgage"), "Verifying Transaction Type value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTitleOwningOfficeValue.FAGetText().Contains("QA Automation Office - DO NOT TOUCH"), "Verifying Title Owning Office value");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void User_Story_473025_6_7()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "US473025: TC558907 TC558932: Project Summary - Project file Information";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a Project File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "DFTCOM";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.FindBusPartyGAB("ID00007");
                Playback.Wait(500);
                var gabName = FastDriver.FileHomepage.BusinessPartyNameField.FAGetText().Clean();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Navigate to Properties / Tax Info";
                FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();

                Reports.TestStep = "Modify Property Name & Address with maximum ";
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FASetText("QAZWSXEDCRFVTGBYHNUJMIKOLPQAZWSXEDC");
                var propertyName = FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue().Clean();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FASetText("EEEEEEEEEEEEEEEEEEEEEEEEEEEEEE");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF");
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FASetText("91201-0001");

                Reports.TestStep = "Verify maximum length on Address detail fields";
                Support.AreEqual(true, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Clean().Length == 35, "Verifying Address Line 1 maximum length is 35 characters");
                Support.AreEqual(true, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Clean().Length == 35, "Verifying Address Line 2 maximum length is 35 characters");
                Support.AreEqual(true, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Clean().Length == 35, "Verifying Address Line 3 maximum length is 35 characters");
                Support.AreEqual(true, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FAGetValue().Clean().Length == 35, "Verifying Address Line 4 maximum length is 35 characters");
                Support.AreEqual(true, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Clean().Length == 30, "Verifying Address City maximum length is 30 characters");
                Support.AreEqual(true, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Clean().Length == 35, "Verifying Address County maximum length is 35 characters");
                Support.AreEqual(true, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailZip.FAGetValue().Clean().Length == 10, "Verifying Address Zip maximum length is 10 characters");
                Support.AreEqual(true, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Clean().Length == 2, "Verifying Address State maximum length is  characters");

                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FASetText("ALAMEDA");
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Navigate to Project Workbench";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();

                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyNameValue.FAGetText().Contains(propertyName), "Verifying Property Name value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryBusinessSourceValue.FAGetText().Contains(gabName), "Verifying Business Source value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.PropAddressLine1.FAGetText().Contains("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"), "Verifying Property Address Line 1 value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.PropAddressLine2.FAGetText().Contains("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"), "Verifying Property Address Line 2 value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.PropAddressLine3.FAGetText().Contains("CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC"), "Verifying Property Address Line 3 value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.PropAddressLine4.FAGetText().Contains("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD"), "Verifying Property Address Line 4 value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryPropertyAddressValue.FAGetText().Contains("EEEEEEEEEEEEEEEEEEEEEEEEEEEEEE CA 91201-0001 ALAMEDA USA"), "Verifying Property Address value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryServiceTypeValue.FAGetText().Contains("Title / Escrow"), "Verifying Service Type value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTransactionTypeValue.FAGetText().Contains("Sale w/Mortgage"), "Verifying Transaction Type value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryTitleOwningOfficeValue.FAGetText().Contains("QA Automation Office - DO NOT TOUCH"), "Verifying Title Owning Office value");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ProjSummaryEscrowOwningOfficeValue.FAGetText().Contains("QA Automation Office - DO NOT TOUCH"), "Verifying Title Owning Office value");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
    }
}