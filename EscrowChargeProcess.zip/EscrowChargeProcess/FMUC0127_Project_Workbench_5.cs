﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using FASTWCFHelpers.Factories;

namespace EscrowChargeProcess
{
    public partial class FMUC0127_Project_Workbench : MasterTestClass
    {

        #region User Story 521994: Update - Disable data checkbox if the information is not available in the project file
        [TestMethod]
        public void User_Story_521994()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Update - Disable data checkbox if the information is not available in the project file";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD Commercial file with Project file checkbox checked. Make sure Buyer, Seller, File Notes and Lenders are not defined.";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                _createCDCommercialFile();

                Support.AreEqual(string.Empty, FastDriver.QuickFileEntry.Buyer1FirstName.FAGetValue(), "Verify that the Buyer1 FirstName field is empty");
                Support.AreEqual(string.Empty, FastDriver.QuickFileEntry.Buyer1LastName.FAGetValue(), "Verify that the Buyer1 LastName field is empty");
                Support.AreEqual(string.Empty, FastDriver.QuickFileEntry.Buyer2FirstName.FAGetValue(), "Verify that the Buyer2 FirstName field is empty");
                Support.AreEqual(string.Empty, FastDriver.QuickFileEntry.Buyer2LastName.FAGetValue(), "Verify that the Buyer2 LastName field is empty");
                Support.AreEqual(string.Empty, FastDriver.QuickFileEntry.LenderIdCode.FAGetText(), "Verify that the there's not Lender Information");
                Support.AreEqual(string.Empty, FastDriver.QuickFileEntry.Notes.FAGetValue(), "Verify that the File Notes field is empty");

                FastDriver.BottomFrame.Done();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                var fileNumber = FastDriver.QuickFileEntry.FileNum.FAGetValue();

                Reports.TestStep = "Navigate to Project Workbench screen and access Update Site files section";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesBuyerEllipsis);

                Reports.TestStep = "Validate the Buyer, Seller, Notes and New Lender checkboxes are disabled along with its corresponding ellipses buttons. Also validate the tool tip on hover of mouse over the checkbox/ellipse buttons.";
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify if the Buyer checkbox is disabled");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify if the Seller checkbox is disabled");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify if the Notes checkbox is disabled");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify if the New Lender checkbox is disabled");
                
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateSiteFilesBuyerEllipsis.IsEnabled(), "Verify if the Buyer ellipsis button is disabled");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis.IsEnabled(), "Verify if the Seller ellipsis button is disabled");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateSiteFilesNotesEllipsis.IsEnabled(), "Verify if the Notes ellipsis button is disabled");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify if the New Lender ellipsis button is disabled");

                Support.AreEqual("No Buyer Data In Project File", FastDriver.ProjectWorkBench.UpdateBuyerChk.FAGetAttribute("title").Clean(), true);
                Support.AreEqual("No Seller Data In Project File", FastDriver.ProjectWorkBench.UpdateSellerChk.FAGetAttribute("title").Clean(), true);
                Support.AreEqual("No File Notes Data In Project File", FastDriver.ProjectWorkBench.UpdateNotesChk.FAGetAttribute("title").Clean(), true);
                Support.AreEqual("No New Lender Data In Project File", FastDriver.ProjectWorkBench.UpdateNewLenderChk.FAGetAttribute("title").Clean(), true);

                Support.AreEqual("No Buyer Data In Project File", FastDriver.ProjectWorkBench.UpdateSiteFilesBuyerEllipsis.FAGetAttribute("title").Clean(), true);
                Support.AreEqual("No Seller Data In Project File", FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis.FAGetAttribute("title").Clean(), true);
                Support.AreEqual("No File Notes Data In Project File", FastDriver.ProjectWorkBench.UpdateSiteFilesNotesEllipsis.FAGetAttribute("title").Clean(), true);
                Support.AreEqual("No New Lender Data In Project File", FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAGetAttribute("title").Clean(), true);

                Reports.TestStep = "Navigate to Project Workbench screen, access Create Site files section and create a site file.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                var siteFileNumber = _createNewSiteFile(fileNumber:"CA1", state: "CA");

                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);

                Reports.TestStep = "Load the site file by searching from File Search screen and navigate to File Homepage screen.";
                FastDriver.ProjectWorkBench.ClickOnListOfSiteFilesLink();

                FastDriver.ProjectWorkBench.SiteFilesReportDlg.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SiteFilesReportDlg.SiteFilesReportTable.PerformTableAction(1, siteFileNumber, 1, TableAction.DoubleClick);

                Reports.TestStep = "Validate the 'Use as Master File' checkbox is disabled.";
                FastDriver.FileHomepage.WaitForScreenToLoad();
                Support.AreEqual(true, !FastDriver.FileHomepage.UseAsMasterFile.IsEnabled(), "Verify if 'Use as Master File' checkbox is disabled");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region User Story 590035: Project File's Status update to be cascaded to all Site files
        
        #region Test Cases
        [TestMethod]
        [Description("US590035: Test Cases 619734 and 619770")]
        public void User_Story_590035_TC619734_and_TC619770()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:- Site File Status always Should be in Open Status if Project File Status will be in Open";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected ";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                var dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Home | Order Entry | Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify the Open status is displayed");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(dateAndTime[0]), "Verify 'Status Date' is equals as when file was created");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(dateAndTime[1] + " " + dateAndTime[2]), "Verify 'Status Time' is equals as when file was created");
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify 'Overwrite Site sile Status' check box should be unnchecked");

                Reports.TestStep = "Navigate to Project Workbench Node and Create a Site file by entering Custom Site file number and Seleting State and Click on Create button";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                var siteFileDateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                var siteFileName = _createNewSiteFile(copyFromProjectFile: true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);

                Reports.TestStep = "Navigate to Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Site File Status should be in Open Status if Project File Status will be in Open Status.");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify 'Status Date' is equals as when site file was created");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(siteFileDateAndTime[1] + " " + siteFileDateAndTime[2]), "Verify 'Status Time' is equals as when site file was created");

                Reports.TestStep = "Navigate back to Project File, Home | Order Entry | Terms/Date/Status.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad(FastDriver.TermsDatesStatus.OverwriteStatus);
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify: 'Overwrite Site File Status' check box should be unncheked by Default.");

                Reports.TestStep = "Check the Overwrite Site File Status check box and Change the status from 'Open' to 'Cancelled'.";
                FastDriver.TermsDatesStatus.OverwriteStatus.FASetCheckbox(true);
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");

                Reports.TestStep = "Click on Cancel Button.";
                var warningMessage1 = FastDriver.WebDriver.HandleDialogMessage(false, false);
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?", 
                                  warningMessage1, 
                                  "Verify the displayed message is as expected"
                                 );
                Support.AreEqual(true, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify: 'Overwrite Site File Status' checkbox should be checked");
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Site File Status should be in Open Status");

                Reports.TestStep = "Again Change the Status from Open to Cancelled.";
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");

                Reports.TestStep = "Click on Ok Button.";
                var warningMessage2 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                siteFileDateAndTime = dateAndTime;
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?",
                                  warningMessage2,
                                  "Verify the displayed message is as expected"
                                 );
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Site File Status has changed from Open to Cancelled");

                Reports.TestStep = "Navigate to Project Workbench Node and Try to create a Site File.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.ErrorMessage);
                Support.AreEqual("Site file(s) cannot be created, as the Project File's status is 'Closed', 'Opened in Error' or 'Cancelled'.", 
                                  FastDriver.ProjectWorkBench.ErrorMessage.FAGetText(), 
                                  "Verify if error message is displayed when trying to create a site file"
                                 );
                Support.AreEqual(false, FastDriver.ProjectWorkBench.Create.IsEnabled(), "Verify Create button is disabled when trying to create a site file");

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);

                Reports.TestStep = "Navigate to Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify that the site file status should be updated with Project File Status (Cancelled)");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify that the site file status date should be the date when the System updates Status in site File");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(siteFileDateAndTime[1] + " " + siteFileDateAndTime[2]), "Verify that the site file status date should be the time when the System updates Status in site File");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        [Description("US590035: Test Case 619772")]
        public void User_Story_590035_TC619772()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:- Site File Status should be updated with Project File Status ( Closed ) if User Select Overwrite Site File Status Option";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected ";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                var dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Home | Order Entry | Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify the Open status is displayed");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(dateAndTime[0]), "Verify 'Status Date' is equals as when file was created");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(dateAndTime[1] + " " + dateAndTime[2]), "Verify 'Status Time' is equals as when file was created");
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify 'Overwrite Site sile Status' check box should be unnchecked");

                Reports.TestStep = "Navigate to Project Workbench Node and Create a Site file by entering Custom Site file number and Seleting State and Click on Create button";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                var siteFileDateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                var siteFileName = _createNewSiteFile();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);

                Reports.TestStep = "Navigate to Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Site File Status should be in Open Status if Project File Status will be in Open Status.");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify 'Status Date' is equals as when site file was created");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(siteFileDateAndTime[1] + " " + siteFileDateAndTime[2]), "Verify 'Status Time' is equals as when site file was created");

                Reports.TestStep = "Navigate back to Project File, Home | Order Entry | Terms/Date/Status.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad(FastDriver.TermsDatesStatus.OverwriteStatus);
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify: 'Overwrite Site File Status' check box should be unncheked by Default.");

                Reports.TestStep = "Check the Overwrite Site File Status check box and Change the status from Open to Closed.";
                FastDriver.TermsDatesStatus.OverwriteStatus.FASetCheckbox(true);
                FastDriver.TermsDatesStatus.Status.FASelectItem("Closed");

                Reports.TestStep = "Click on Cancel Button.";
                var warningMsg = FastDriver.WebDriver.HandleDialogMessage(false, false);
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?", 
                                  warningMsg, 
                                  "Verify: System is displaying warning message when trying to change file status"
                                 );
                Support.AreEqual(true, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify: 'Overwrite Site File Status' checkbox should be checked");
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Site File Status should be in Open Status");

                Reports.TestStep = "Again Change the Status from Open to Closed.";
                var settlementDate = DateTime.Now.ToPST().ToDateString();
                FastDriver.TermsDatesStatus.SettlementDate.FASendKeys(settlementDate);
                FastDriver.TermsDatesStatus.Status.FASelectItem("Closed");

                Reports.TestStep = "Click on Ok Button.";
                var warningMsg2 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                siteFileDateAndTime = dateAndTime;
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?",
                                  warningMsg2,
                                  "Verify: System is displaying warning message when trying to change file status"
                                 );
                Support.AreEqual("Closed", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Changes have been saved");

                Reports.TestStep = "Navigate to Project Work bench Node and Try to create a Site File.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.ErrorMessage);
                Support.AreEqual("Site file(s) cannot be created, as the Project File's status is 'Closed', 'Opened in Error' or 'Cancelled'.",
                                  FastDriver.ProjectWorkBench.ErrorMessage.FAGetText(),
                                  "Verify if error message is displayed when trying to create a site file"
                                 );

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);

                Reports.TestStep = "Navigate to Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Closed", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify that the site file status should be updated with Project File Status (Closed)");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify that the Site File Status date should be the date when the System updates Status in site File");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(siteFileDateAndTime[1] + " " + siteFileDateAndTime[2]), "Verify that the Site File Status date should be the time when the System updates Status in site File");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.SettlementDate.FAGetValue().Contains(settlementDate), "Verify that the Site File Status 'Settlement Date' should be the time when the System updates Status in site File");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US590035: Test Cases 619774 and 619778")]
        public void User_Story_590035_TC619774_and_TC619778()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:- Site File Status should be updated with Project File Status ( Open In Error ) if User Select Overwrite Site File Status Option";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected ";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                var dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Home | Order Entry | Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify the Open status is displayed");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(dateAndTime[0]), "Verify 'Status Date' is equals as when file was created");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(dateAndTime[1] + " " + dateAndTime[2]), "Verify 'Status Time' is equals as when file was created");
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify 'Overwrite Site sile Status' check box should be unnchecked");

                Reports.TestStep = "Navigate to Project Workbench Node and Create a Site file by entering Custom Site file number and Seleting State and Click on Create button";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                var siteFileDateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                var siteFileName = _createNewSiteFile();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);

                Reports.TestStep = "Navigate to Project File Home | Order Entry | Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify the Open status is displayed");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(dateAndTime[0]), "Verify 'Status Date' is equals as when file was created");
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify 'Overwrite Site sile Status' check box should be unnchecked");

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);

                Reports.TestStep = "Navigate to Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Site File Status should be in Open Status if Project File Status will be in Open Status.");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify 'Status Date' is equals as when site file was created");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(siteFileDateAndTime[1] + " " + siteFileDateAndTime[2]), "Verify 'Status Time' is equals as when site file was created");

                Reports.TestStep = "Navigate back to Project File, Home | Order Entry | Terms/Date/Status.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad(FastDriver.TermsDatesStatus.OverwriteStatus);
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify: 'Overwrite Site File Status' check box should be unncheked by Default.");

                Reports.TestStep = "Check the Overwrite Site File Status check box and Change the status from Open to Open In Error.";
                FastDriver.TermsDatesStatus.OverwriteStatus.FASetCheckbox(true);
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open In Error");

                Reports.TestStep = "Click on Cancel Button.";
                var warningMsg = FastDriver.WebDriver.HandleDialogMessage(false, false);
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?",
                                  warningMsg,
                                  "Verify: System is displaying warning message when trying to change file status"
                                 );
                Support.AreEqual(true, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify: 'Overwrite Site File Status' checkbox should be checked");
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Site File Status should be in Open Status");

                Reports.TestStep = "Again Change the Status from Open to Cancelled.";
                FastDriver.TermsDatesStatus.Status.FASelectItem("Open In Error");

                Reports.TestStep = "Click on Ok Button.";
                var warningMsg2 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                siteFileDateAndTime = dateAndTime;
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?",
                                  warningMsg2,
                                  "Verify: System is displaying warning message when trying to change file status"
                                 );
                Support.AreEqual("Open In Error", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Changes have been saved");

                Reports.TestStep = "Navigate to Project Work bench Node and Try to create a Site File.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.ErrorMessage);
                Support.AreEqual("Site file(s) cannot be created, as the Project File's status is 'Closed', 'Opened in Error' or 'Cancelled'.",
                                  FastDriver.ProjectWorkBench.ErrorMessage.FAGetText(),
                                  "Verify if error message is displayed when trying to create a site file"
                                 );

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Navigate to Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open In Error", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify that the site file status should be updated with Project File Status (Open In Error)");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify that the Site File Status date should be the date when the System updates Status in site File");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(siteFileDateAndTime[1] + " " + siteFileDateAndTime[2]), "Verify that the Site File Status date should be the time when the System updates Status in site File");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US590035: Test Case 619781")]
        public void User_Story_590035_TC619781()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:- System should display warning message from the Disburesement Screen if user select Overwrite Site File Status Option in Project File.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected ";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "CASH";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                var dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Home | Order Entry | Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify the Open status is displayed");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(dateAndTime[0]), "Verify 'Status Date' is equals as when file was created");
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify 'Overwrite Site sile Status' check box should be unnchecked");

                Reports.TestStep = "Check the Overwrite Site File Status Check box.";
                FastDriver.TermsDatesStatus.OverwriteStatus.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify 'Overwrite Site sile Status' check box should be checked");

                Reports.TestStep = "Navigate to Project Work bench Node and Create a Site file by entering Custom Site file number and selecting state and Click on Create button";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                var siteFileDateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                var siteFileName = _createNewSiteFile();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);

                Reports.TestStep = "Navigate to Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Site File Status should be in Open Status if Project File Status will be in Open Status.");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify 'Status Date' is equals as when site file was created");

                Reports.TestStep = "Navigate to Project File Home | Order Entry | Title/Escrow Fees| Fee Entry";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 4, TableAction.SetText, "20.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, 7, TableAction.SetText, "20.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Navigate to Home | Order Entry | Escrow Closing| Disbursement | Active Disbursement";
                FastDriver.ActiveDisbursementSummary.Open(FastDriver.ActiveDisbursementSummary.FeeTransfer);

                Reports.TestStep = "Select the status row and click on fee Transfer";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.FeeTransfer.FAClick();
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();

                Reports.TestStep = "Click on OK Button";
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                FastDriver.ChangeFileStatusDlg.WaitForScreenToLoad();

                Reports.TestStep = "Change the status from Closed to ( Cancelled or Open In Error ) and Click on Done Button.";
                FastDriver.ChangeFileStatusDlg.FileStatus.FASelectItem("Cancelled");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click Ok Button";
                var warningMsg = FastDriver.WebDriver.HandleDialogMessage(false, true);
                dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                siteFileDateAndTime = dateAndTime;
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?", 
                                  warningMsg,
                                  "Verify if the dialog is showing the right warning message"
                                  );
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Now navigate to Terms Date Status Screen.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify if made changes are really sync");

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);

                Reports.TestStep = "Navigate to Terms/Date/Status";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify if made changes are really sync");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify if made changes are really sync");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US590035: Test Case 621854")]
        public void User_Story_590035_TC621854()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:- Event Log should get captured in all the Site File";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected ";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                var dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Home | Order Entry | Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify the Open status is displayed");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(dateAndTime[0]), "Verify 'Status Date' is equals as when file was created");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(dateAndTime[1] + " " + dateAndTime[2]), "Verify 'Status Time' is equals as when file was created");
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify 'Overwrite Site sile Status' check box should be unnchecked");

                Reports.TestStep = "Navigate to Project Workbench Node and Create a Site file by entering Custom Site file number and Seleting State and Click on Create button";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                var siteFileDateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                var siteFileName = _createNewSiteFile();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);

                Reports.TestStep = "Navigate to Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Site File Status should be in Open Status if Project File Status will be in Open Status.");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify 'Status Date' is equals as when site file was created");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(siteFileDateAndTime[1] + " " + siteFileDateAndTime[2]), "Verify 'Status Time' is equals as when site file was created");

                Reports.TestStep = "Navigate back to Project File, Home | Order Entry | Terms/Date/Status.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.TermsDatesStatus.WaitForScreenToLoad(FastDriver.TermsDatesStatus.OverwriteStatus);
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify: 'Overwrite Site File Status' check box should be unncheked by Default.");

                Reports.TestStep = "Check the Overwrite Site File Status check box and Change the status from Open to Closed.";
                FastDriver.TermsDatesStatus.OverwriteStatus.FASetCheckbox(true);
                var settlementDate = DateTime.Now.ToPST().ToDateString();
                FastDriver.TermsDatesStatus.SettlementDate.FASendKeys(settlementDate);
                FastDriver.TermsDatesStatus.Status.FASelectItem("Closed");

                Reports.TestStep = "Click on Ok Button.";
                var warningMsg2 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                siteFileDateAndTime = dateAndTime;
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?",
                                  warningMsg2,
                                  "Verify: System is displaying warning message when trying to change file status"
                                 );
                Support.AreEqual("Closed", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Changes have been saved");

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Number.FASendKeys(siteFileName);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50);

                Reports.TestStep = "Navigate to Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Closed", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify that the site file status should be updated with Project File Status (Closed)");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify that the Site File Status date should be the date when the System updates Status in site File");
                //Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusTime.FAGetValue().Contains(siteFileDateAndTime[1] + " " + siteFileDateAndTime[2]), "Verify that the Site File Status date should be the time when the System updates Status in site File");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.SettlementDate.FAGetValue().Contains(settlementDate), "Verify that the Site File Status 'Settlement Date' should be the time when the System updates Status in site File");

                Reports.TestStep = "Navigate to Event Log";
                FastDriver.EventTrackingLog.Open().WaitForScreenToLoad(FastDriver.EventTrackingLog.EventTable);
                Support.AreEqual(credentials.UserName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1,6, TableAction.GetText).Message, true);
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US590035: Test Cases 624839 and 624901")]
        public void User_Story_590035_TC624839_and_TC624901()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-Project File Status should remain unchange if User click on Reset button";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected ";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                var fileName = FastDriver.FACreateFileFromWCF(fileRequest);
                var dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                FastDriver.TopFrame.SearchFileByFileNumber(fileName);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Home | Order Entry | Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify the Open status is displayed");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(dateAndTime[0]), "Verify 'Status Date' is equals as when file was created");
                Support.AreEqual(false, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify 'Overwrite Site sile Status' check box should be unnchecked");

                Reports.TestStep = "Check the Overwrite Site File Status check box and Change the status from Open to ( Cancelled ,Open In Error or Closed )";
                FastDriver.TermsDatesStatus.OverwriteStatus.FASetCheckbox(true);
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");

                Reports.TestStep = "Click on Cancel Button.";
                var warningMsg = FastDriver.WebDriver.HandleDialogMessage(false, false);
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?",
                                  warningMsg,
                                  "Verify: System is displaying warning message when trying to change file status"
                                 );
                Support.AreEqual(true, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify: 'Overwrite Site File Status' checkbox should be checked");
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: File Status should be in Open Status");

                Reports.TestStep = "Again Change the Status from Open to Cancelled.";
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");

                Reports.TestStep = "Click on Ok Button.";
                var warningMsg2 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?",
                                  warningMsg2,
                                  "Verify: System is displaying warning message when trying to change file status"
                                 );
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Changes have been saved");

                Reports.TestStep = "Now Click on Reset Button.";
                FastDriver.BottomFrame.Reset();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad(FastDriver.TermsDatesStatus.Status);
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: File Status should be in Open Status");

                Reports.TestStep = "Create a Site file from Project Workbench node.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                var siteFileDateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                var siteFileName = _createNewSiteFile(true);

                Reports.TestStep = "Navigate to Site File Terms Date Screen";
                FastDriver.TopFrame.SearchFileByFileNumber(siteFileName);
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify the Open status is displayed");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(siteFileDateAndTime[0]), "Verify 'Status Date' is equals as when file was created");

                Reports.TestStep = "Perform steps 3 to 7.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileName);
                FastDriver.TermsDatesStatus.Open();

                Reports.TestStep = "Check the Overwrite Site File Status check box and Change the status from Open to ( Cancelled ,Open In Error or Closed )";
                FastDriver.TermsDatesStatus.OverwriteStatus.FASetCheckbox(true);
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");

                Reports.TestStep = "Click on Cancel Button.";
                warningMsg = FastDriver.WebDriver.HandleDialogMessage(false, false);
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?",
                                  warningMsg,
                                  "Verify: System is displaying warning message when trying to change file status"
                                 );
                Support.AreEqual(true, FastDriver.TermsDatesStatus.OverwriteStatus.IsSelected(), "Verify: 'Overwrite Site File Status' checkbox should be checked");
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: File Status should be in Open Status");

                Reports.TestStep = "Again Change the Status from Open to Cancelled.";
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");

                Reports.TestStep = "Click on Ok Button.";
                warningMsg2 = FastDriver.WebDriver.HandleDialogMessage(false, true);
                Support.AreEqual("This will update the status in all the site files. Are you sure you want to change the Status of the Project File?",
                                  warningMsg2,
                                  "Verify: System is displaying warning message when trying to change file status"
                                 );
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Changes have been saved");

                Reports.TestStep = "Now Click on Reset Button.";
                FastDriver.BottomFrame.Reset();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad(FastDriver.TermsDatesStatus.Status);
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: File Status should be in Open Status");

                Reports.TestStep = "Navigate back to QFE and craete a Non Project File.";
                var fileRequest2 = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                var dateAndTime2 = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Terms Date Screen and Perform steps 3 to 6.";
                FastDriver.TermsDatesStatus.Open();

                Reports.TestStep = "Check the Overwrite Site File Status check box and Change the status from Open to ( Cancelled ,Open In Error or Closed )";
                FastDriver.TermsDatesStatus.Status.FASelectItem("Cancelled");

                Reports.TestStep = "Click on Ok (Done) Button.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Cancelled", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify: Changes have been saved");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US590035: Test Case 624910")]
        public void User_Story_590035_TC624910()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:- Overwrite Site File Status Check box should display in FAST View Screen";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected ";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                var dateAndTime = DateTime.Now.ToPST().ToString("MM-dd-yyyy hh:mm tt").Split(' ');
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Home | Order Entry | Terms/Date/Status.";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem(), "Verify if default status is Open");
                Support.AreEqual(true, FastDriver.TermsDatesStatus.StatusDate.FAGetValue().Contains(dateAndTime[0]), "Verify if status date is equals as when files was created");

                Reports.TestStep = "Click on Fast View on Top of the Screen.";
                FastDriver.TopFrame.ClickFastViewTab();
                FastDriver.WebDriver.WaitForWindowAndSwitch("FAST View", switchBackToFAST: false);

                Reports.TestStep = "Enter the Project File Number in Number Section and click on Find Button.";
                FastDriver.FASTView.WaitForScreenToLoad();
                FastDriver.FASTView.FileNumber.FASendKeys(fileNumber);
                FastDriver.FASTView.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 50, false);

                Reports.TestStep = "Click on File Activities and navigate to Terms Date Screen.";
                FastDriver.FASTView.WaitForScreenToLoad();
                Keyboard.SendKeys("%A");
                Playback.Wait(2000);
                Keyboard.SendKeys("+T", modifierKeys: System.Windows.Input.ModifierKeys.Control);
                Playback.Wait(3000);
                //Check if Overwrite Site File Status Checkbox is displayed
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion //bug

        #endregion

        //Test Cases for this US Cannot be completed as specified at: User Stories: 667588 and 629927
        #region User Story 606707: Cascade 'Form Type' from Project file to Site files

        #region Test Case 639744
        [TestMethod]
        public void User_Story_606707_TC639744()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify if Form Type has been cascaded to site file automatically after changing in project file (New Loan screen)";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Create basic Project File
                Reports.TestStep = "Create a basic Project File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal) 12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal) 6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal) 6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "Navigate to Project Workbench via Home|Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Click on the 'Menu' icon and Click on Create Site Files option in the 'Create/Update' hyperlink";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Create site file(s) with mandatory details and save them";
                var siteFileNumber = _createNewSiteFile(true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.SiteFileNum.IsReadOnly(), "Verify: Site File Number field is read only");

                Reports.TestStep = "Load the site file created and navigate to File Homepage";
                FastDriver.TopFrame.SearchFileByFileNumber(siteFileNumber);
                FastDriver.FileHomepage.Open();
                Support.AreEqual(true, FastDriver.FileHomepage.FormTypeCD.IsSelected(), "Verify: Form type CD radio button is selected on FileHomepage for Site File");

                Reports.TestStep = "Navigate to New Loan screen in site file";
                FastDriver.NewLoan.Open();
                Support.AreEqual(true, FastDriver.NewLoan.FormType_CD.IsSelected(), "Verify: Form Type CD radio button is selected on New Loan for Site File");

                Reports.TestStep = "Load the Project file| Navigate to New Loan screen in Project file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.NewLoan.Open();
                Support.AreEqual(true, FastDriver.NewLoan.FormType_CD.IsSelected(), "Verify: Form type CD radio button is selected for Project File");

                Reports.TestStep = "Change the form type to HUD in new loan screen";
                /*
                 Cannot be completed as specified at: User Stories: 667588 and 629927
                 */
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region User Story 634964: [Technical] - Update – Rearrange Update section
        
        #region Test Cases 
        [TestMethod]
        [Description("US634964: Test Cases 639925, 640080, 641042 and 641112")]
        public void User_Story_634964_TC_639925_TC640080_TC641042_and_TC641112()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify that New Lender field is placed in the next coulmnn";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Create basic Project File
                Reports.TestStep = "Create a basic Project File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "Navigate to New Loans screen and add a lender";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench via navigation tree";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Click on the 'Menu' icon and Click on Create Site Files option in the 'Create/Update' hyperlink";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.CopyForSiteFile1);

                Reports.TestStep = "Create site file(s) with mandatory details and save them";
                var siteFileNum = _createNewSiteFile(true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.SiteFileNum.IsEnabled(), "Verify: created site file must be in read only mode in the site files grid");

                Reports.TestStep = "Click on the 'Menu' icon and Click on Update Site Files option in the 'Create/Update' hyperlink";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateTransactionTypeChk);

                Reports.TestStep = "Select any one of the fields under Select All column";
                FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.FASetCheckbox(true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender checkbox is disabled when one of the fields under Select All is checked");

                Reports.TestStep = "Uncheck the Transaction Type checkbox";
                FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.FASetCheckbox(false);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender checkbox is now enabled");

                Reports.TestStep = "Check the 'New Lender' checkbox";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: Checkbox is disabled when New Lender is checked");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: Checkbox is disabled when New Lender is checked");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: Checkbox is disabled when New Lender is checked");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: Checkbox is disabled when New Lender is checked");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Checkbox is disabled when New Lender is checked");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: Checkbox is disabled when New Lender is checked");
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(false);

                Reports.TestStep = "Select Transaction Type under Select All column and press tab key from keyboard";
                FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.FASetCheckbox(true);
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(500);

                Reports.TestStep = "Press 'space' key from keyboard";
                Keyboard.SendKeys(" ");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateProductsChk.IsSelected(), "Verify: Product(s) checkbox should be selected upon pressing 'space' key");

                Reports.TestStep = "Press tab key from keyboard";
                Keyboard.SendKeys("{TAB}");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateProductsOverwrite.IsSelected(), "Verify: Overwrite option is selected by default");

                Reports.TestStep = "Repeat step 11 for each of the fields under Select All column and press 'space' key for selection of each of the fields";
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys(" ");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsSelected(), "Verify: Buyer checkbox is now checked");

                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys(" ");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSellerChk.IsSelected(), "Verify: Seller checkbox is now checked");

                Reports.TestStep = "In update section, press tab key from keyboard";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSelectAll);
                Keyboard.SendKeys("{TAB}");
                Keyboard.SendKeys("{TAB}");

                Reports.TestStep = "Press 'space' key from keyboard when the highlight is at New Lender checkbox";
                Keyboard.SendKeys(" ");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsSelected(), "Verify: New Lender checkbox is now checked");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US634964: Test Cases 639926 and 639927")]
        public void User_Story_634964_TC_639926_TC639927()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify that select all is not applicable for New lender checkbox";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Create basic Project File
                Reports.TestStep = "Create a basic Project File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "Navigate to File Notes screen and add a FileNote";
                FastDriver.FileNotes.Open();
                FastDriver.FileNotes.New.FAClick();
                FastDriver.FileNotesEditor.WaitForScreeToLoad();
                var note = Support.RandomString("aANZ");
                FastDriver.FileNotesEditor.AddNote(note);
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();
                Support.AreEqual(note, FastDriver.FileNotes.Table.PerformTableAction(2, 1, TableAction.GetText).Message, "Verify: the note was added");

                Reports.TestStep = "Navigate to Sellers screen and add a seller";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                var seller = RequestFactory.GetAddBuyerSellerRequest("individual");
                seller.BuyerSeller.FirstName = "Tom";
                seller.BuyerSeller.LastName = "Cruice";                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Buyers Screen and add a buyer";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true);
                FastDriver.BuyerSellerSummary.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                var buyer = RequestFactory.GetAddBuyerSellerRequest("business entity");
                buyer.BuyerSeller.FirstName = "Silvester";
                buyer.BuyerSeller.LastName = "Stallone";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to New Loans screen and add a lender";
                FastDriver.NewLoan.Open();
                FastDriver.BottomFrame.New();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Navigate to Project Workbench via navigation tree";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Click on the 'Menu' icon and Click on Create Site Files option in the 'Create/Update' hyperlink";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.Create);

                Reports.TestStep = "Create site file(s) with mandatory details and save them";
                var siteFileNumber = _createNewSiteFile(true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.SiteFileNum.IsEnabled(), "Verify: created site file must be in read only mode in the site files grid");

                Reports.TestStep = "Click on the 'Menu' icon and Click on Update Site Files option in the 'Create/Update' hyperlink";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSelectAll);

                Reports.TestStep = "Check the Select All checkbox";
                FastDriver.ProjectWorkBench.UpdateSelectAll.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsSelected(), "Verify: Checkbox is checked when Select All is checked");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateProductsChk.IsSelected(), "Verify: Checkbox is checked when Select All is checked");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsSelected(), "Verify: Checkbox is checked when Select All is checked");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSellerChk.IsSelected(), "Verify: Checkbox is checked when Select All is checked");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateNotesChk.IsSelected(), "Verify: Checkbox is checked when Select All is checked");
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: Checkbox is disabled when Select All is checked");

                Reports.TestStep = "Select any one of the fields under Select All column (Ex. Transaction Type)";
                FastDriver.ProjectWorkBench.UpdateSelectAll.FASetCheckbox(false);
                FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.FASetCheckbox(true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender checkbox is disabled when one of the fields ('Transaction Type') under Select All column is checked.");

                Reports.TestStep = "Repeat step 12 for each of the fields under Select All column (Products, Buyers, Seller, Notes)";
                FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.FASetCheckbox(false);
                FastDriver.ProjectWorkBench.UpdateProductsChk.FASetCheckbox(true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender checkbox is disabled when one of the fields ('Products') under Select All column is checked.");

                FastDriver.ProjectWorkBench.UpdateProductsChk.FASetCheckbox(false);
                FastDriver.ProjectWorkBench.UpdateBuyerChk.FASetCheckbox(true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender checkbox is disabled when one of the fields ('Buyer') under Select All column is checked.");

                FastDriver.ProjectWorkBench.UpdateBuyerChk.FASetCheckbox(false);
                FastDriver.ProjectWorkBench.UpdateSellerChk.FASetCheckbox(true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender checkbox is disabled when one of the fields ('Seller') under Select All column is checked.");

                FastDriver.ProjectWorkBench.UpdateSellerChk.FASetCheckbox(false);
                FastDriver.ProjectWorkBench.UpdateNotesChk.FASetCheckbox(true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender checkbox is disabled when one of the fields ('Notes') under Select All column is checked.");

                Reports.TestStep = "Now, Select another checkbox (Ex: Buyer/Seller) along with transaction type checked";
                FastDriver.ProjectWorkBench.UpdateNotesChk.FASetCheckbox(false);
                FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.UpdateBuyerChk.FASetCheckbox(true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender checkbox is disabled when any of the fields under Select All column is checked.");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        [Description("US634964: Test Case 639930")]
        public void User_Story_634964_TC_639930()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "To verify that New lender checkbox remains disabled when there are no lender(s) in the project file";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region Create basic Project File
                Reports.TestStep = "Create a basic Project File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "Navigate to Project Workbench via navigation tree";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Click on the 'Menu' icon and Click on Create Site Files option in the 'Create/Update' hyperlink";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.Create);

                Reports.TestStep = "Create site file(s) with mandatory details and save them";
                var siteFileNumber = _createNewSiteFile(true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.SiteFileNum.IsEnabled(), "Verify: created site file must be in read only mode in the site files grid");

                Reports.TestStep = "Click on the 'Menu' icon and Click on Update Site Files option in the 'Create/Update' hyperlink";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender check box is disabled when there is not lender(s) in the project file");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region User Story 650471: Update - Select Lender

        #region Test Cases
        [TestMethod]
        [Description("US650471: Test Case 667104")]
        public void User_Story_650471_TC667104()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-New Lender Ellipse Button Should be Enabled";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";                
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan and add three different Lenders(Lender1 ,Lender2 , Lender3).";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("226");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.FindGABCode("246");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.FindGABCode("212");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Project Workbench screen via Home | Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Mouse Over to that Icon and Click on Update Site Files Link.";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: Checkbox is checked when New Lender is checked");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: Checkbox is checked when New Lender is checked");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: Checkbox is disabled when New Lender is checked");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Checkbox is checked when New Lender is checked");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: Checkbox is checked when New Lender is checked");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: New Lender Ellipsis is disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsSelected(), "View Lender(s) radio button should be checked by default");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: System Should Enable the New Lender Ellipse Button");

                Reports.TestStep = "Select the Update Lender  Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesUpdateLenderDetails.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesUpdateLenderDetails.IsEnabled(), "System Should Enable the New Lender Ellipse Button");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US650471: Test Case 667111")]
        public void User_Story_650471_TC667111()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-System Should not display the Removed Lender in New Lender Ellipse button";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan and add three different Lenders(Lender1 ,Lender2 , Lender3).";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("226");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.FindGABCode("246");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.FindGABCode("212");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Select the Second Lender ( Lender2 ) from the list and Click on Remove button.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad(FastDriver.NewLoanSummary.LoanSummaryTable);
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();

                Reports.TestStep = "Click on Ok button";
                var errorMessage = FastDriver.WebDriver.HandleDialogMessage(false, true).Clean();
                Support.AreEqual("All information will be removed for this New Loan. Continue?",
                                 errorMessage,
                                 "Verify: System is displaying error/warning message when user tries to remove a lender");
                FastDriver.NewLoanSummary.WaitForScreenToLoad(FastDriver.NewLoanSummary.LoanSummaryTable);
                var rowName = FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message;
                Support.AreEqual("Available", rowName, "Verify: System should display 'Available' in the second position");

                Reports.TestStep = "Navigate to Project Workbench screen via Home | Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Mouse Over to that Icon and Click on Update Site Files Link.";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual("2", 
                                 FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.FAFindElements(ByLocator.TagName, "input").Count().ToString(), 
                                 "Verify: System should display only two Lenders"
                                 );
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US650471: Test Case 667116")]
        public void User_Story_650471_TC667116()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-System Should diplay Lender Name,City,State and Contact details of the Site File inside New Lender Ellipse Button";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan and add three different Lenders(Lender1 ,Lender2 , Lender3).";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("226");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.FindGABCode("246");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.FindGABCode("212");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.NewLoanSummary.WaitForScreenToLoad(FastDriver.NewLoanSummary.LoanSummaryTable);

                Support.AreEqual("1", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message, "Verify: The first lender # is equalas to 1");
                Support.AreEqual("2", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 1, TableAction.GetText).Message, "Verify: The second lender # is equals to 2");
                Support.AreEqual("3", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 1, TableAction.GetText).Message, "Verify: The third (last) lender # is equals to 3");

                Reports.TestStep = "Navigate to Project Workbench screen via Home | Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Mouse Over to that Icon and Click on Create Site Files Link.";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.Lender);

                Reports.TestStep = "Select the Lender Checkbox and Create a Site file by entering Custom Site file number and by selecting State City and County.";
                FastDriver.ProjectWorkBench.Lender.FASetCheckbox(true);
                var siteFileNumber = _createNewSiteFile(true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.AddressLine1.IsEnabled(), "Verify: created site file must be in read only mode in the site files grid");

                Reports.TestStep = "Navigate to Site Files New Loan Screen";
                FastDriver.TopFrame.SearchFileByFileNumber(siteFileNumber);
                FastDriver.NewLoanSummary.Open();

                Support.AreEqual("1", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message, "Verify: The first lender # is equalas to 1");
                Support.AreEqual("2", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 1, TableAction.GetText).Message, "Verify: The second lender # is equals to 2");
                Support.AreEqual("3", FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(4, 1, TableAction.GetText).Message, "Verify: The third (last) lender # is equals to 3");

                Reports.TestStep = "Navigate back to Project File Update Site Files Section.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipsis' button should be enabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual("3",
                                 FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.FAFindElements(ByLocator.TagName, "input").Count().ToString(),
                                 "Verify: System should display all three Lenders"
                                 );
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US650471: Test Case 667177 and part of 667226")]
        public void User_Story_650471_TC667177()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-System Should disabled the New Lender Checkbox and Ellipse button if Site file has only Mortgage Broker without Lender";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan Screen";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Click on Mortgage Broker Tab and add a Mortgage Broker and Click on Done Button";
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.MortgageGABcode);

                FastDriver.NewLoan.MortgageFindGAB("1258");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Navigate to Project Workbench screen via Home | Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Mouse Over to that Icon and Click on Create Site Files Link.";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.Create);

                Reports.TestStep = "Select the Lender Checkbox and Create a Site file by entering Custom Site file number and by selecting State.";
                //In order to the system allow the user to check the Lender checkbox on the Project WorkBench Screen, a Lender should be added previously to this step
                //but, if user add a lender then the last step will fail because is validating the New Lender Chk on the Update Site Files to be disabled
                FastDriver.ProjectWorkBench.Lender.FASetCheckbox(true);
                var siteFileNumber = _createNewSiteFile(true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.AddressLine1.IsEnabled(), "Verify: created site file must be in read only mode in the site files grid");

                Reports.TestStep = "Navigate to Site file New Loan Mortgage Broker Tab.";
                FastDriver.TopFrame.SearchFileByFileNumber(siteFileNumber);
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.MortgageGABcode);
                Support.AreEqual("1258", FastDriver.NewLoan.MortgageBrokerGABlabel.FAGetText(), "Verify: the system should display the created mortgage");

                Reports.TestStep = "Navigate to Project File Project Workbench Update Section";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNewLenderChk.IsEnabled(), "Verify: New Lender Checkbox should be disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: Ellipse button should be disabled");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        } //need to fix this

        [TestMethod]
        [Description("US650471: Test Case 667216")]
        public void User_Story_650471_TC667216()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-Display of the Order of the Combination of Lenders ( Lender , Deleted Lender , Mortgage Broker Without Lender and Adhoc Lender) inside the New Lender Ellipse Button";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan Screen";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Add Lender in the below Format";
                FastDriver.NewLoan.FindGABCode("LENAUTO1");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.FindGABCode("LENAUTO2");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.FindGABCode("260");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.MortgageBrokerTab);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.NewLoan.MortgageFindGABCode("990");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.FindGABCode("AD91910");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.NewLoanSummary.WaitForScreenToLoad(FastDriver.NewLoanSummary.LoanSummaryTable);

                Reports.TestStep = "Select the Second Lender ( Lender2 ) from the list and Click on Remove button.";
                FastDriver.NewLoanSummary.WaitForScreenToLoad(FastDriver.NewLoanSummary.LoanSummaryTable);
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.NewLoanSummary.Remove.FAClick();

                Reports.TestStep = "Click on Ok button";
                var errorMessage = FastDriver.WebDriver.HandleDialogMessage(false, true).Clean();
                Support.AreEqual("All information will be removed for this New Loan. Continue?",
                                 errorMessage,
                                 "Verify: System is displaying error/warning message when user tries to remove a lender");
                FastDriver.NewLoanSummary.WaitForScreenToLoad(FastDriver.NewLoanSummary.LoanSummaryTable);
                var rowName = FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message;
                Support.AreEqual("Available", rowName, "Verify: System should display 'Available' in the second position");

                Reports.TestStep = "Navigate to Project Workbench screen via Home | Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Mouse Over to that Icon and Click on Update Site Files Link.";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipsis' button should be enabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual("3",
                                 FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.FAFindElements(ByLocator.TagName, "input").Count().ToString(),
                                 "Verify: System should display all three Lenders"
                                 );

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US650471: Test Cases 672098 and 672106")]
        public void User_Story_650471_TC672098_and_TC672106()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-The Contact name inside the New Lender Ellipse button When Contact name of the Lender Changed from one to another Contact name";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan Screen Loan and add a Lender Lender1 with Contact name Ex .( ABCD )";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("212");
                FastDriver.NewLoan.LoanDetailsEditName.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsName.FASendKeys("ABC");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Navigate to Project Workbench screen via Home | Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Mouse Over to that Icon and Click on Create Site Files Link.";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.Create);

                Reports.TestStep = "Select the Lender Checkbox and Create a Site file by entering Custom Site file number and by selecting State City and County.";
                FastDriver.ProjectWorkBench.Lender.FASetCheckbox(true);
                var siteFileNumber = _createNewSiteFile(true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.AddressLine1.IsEnabled(), "Verify: created site file must be in read only mode in the site files grid");

                Reports.TestStep = "Navigate to Site Files New Loan Screen";
                FastDriver.TopFrame.SearchFileByFileNumber(siteFileNumber);
                FastDriver.NewLoan.Open();
                Support.AreEqual("ABC", FastDriver.NewLoan.NewLoanDetails_ContactName.FAGetText(), "Verify: System should display Lender1 with contact name on site file");

                Reports.TestStep = "Navigate back to Project File Update Site Files Section.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be enabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual("ABC", 
                                  FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 4, TableAction.GetText).Message,
                                  "Verify: System should display the Lender Lender1 with Contact name"
                                 );

                Reports.TestStep = "Navigate to New Loan Screen and Change the Contact details from ABCD to XYZ and Click on done button.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsName.FASetText("XYZ", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Navigate back to Project File Update Site Files Section.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be enabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual("XYZ",
                                  FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 4, TableAction.GetText).Message,
                                  "Verify: System should display the Lender Lender1 with Contact name"
                                 );

                Reports.TestStep = "Navigate to New Loan Screen and delete the Contact name ABCD ( make it blank ) and Click on done button.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsEditName.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Navigate back to Project File Update Site Files Section.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be enabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual(string.Empty,
                                  FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 4, TableAction.GetText).Message,
                                  "Verify: System should display the Lender Lender1 without Contact name"
                                 );
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US650471: Test Case 672111")]
        public void User_Story_650471_TC672111()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-The Contact name Should display inside the New Lender Ellipse button When Contact name added to the Lender";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan and add a Lender Lender1 without Contact name.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("212");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Navigate to Project Workbench screen via Home | Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Mouse Over to that Icon and Click on Create Site Files Link.";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.Create);

                Reports.TestStep = "Select the Lender Checkbox and Create a Site file by entering Custom Site file number and by selecting State City and County.";
                FastDriver.ProjectWorkBench.Lender.FASetCheckbox(true);
                var siteFileNumber = _createNewSiteFile(true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.AddressLine1.IsEnabled(), "Verify: created site file must be in read only mode in the site files grid");

                Reports.TestStep = "Navigate to Site Files New Loan Screen";
                FastDriver.TopFrame.SearchFileByFileNumber(siteFileNumber);
                FastDriver.NewLoan.Open();
                Support.AreEqual(string.Empty, FastDriver.NewLoan.NewLoanDetails_ContactName.FAGetText(), "Verify: System should display Lender1 without contact name on site file");

                Reports.TestStep = "Navigate back to Project File Update Site Files Section.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be enabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual(string.Empty,
                                  FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 4, TableAction.GetText).Message,
                                  "Verify: System should display the Lender Lender1 with Contact name"
                                 );

                Reports.TestStep = "Navigate to New Loan Screen and add the Contact name ABCD and Click on done button.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsEditName.FASetCheckbox(true);
                FastDriver.NewLoan.LoanDetailsName.FASetText("ABCD", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Navigate back to Project File Update Site Files Section.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be enabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual("ABCD",
                                  FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 4, TableAction.GetText).Message,
                                  "Verify: System should display the Lender Lender1 with Contact name 'ABCD'"
                                 );
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US650471: Test Cases 672156 and 672204")]
        public void User_Story_650471_TC672156_and_TC672204()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-Display of the Adhoc GAB Lender with Name1 and Name2 inside the New Lender Ellipse button.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan and Click on Find button under Lender Information section.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.EntityType);
                Support.AreEqual(false, FastDriver.AddressBookSearchDlg.NewGAB.IsEnabled(), "Verify: New GAB button is disabled");

                Reports.TestStep = "Enter XYZ in Entity Name and Click on Find button.";
                FastDriver.AddressBookSearchDlg.EntityName.FASetText("XYZ", true);
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);
                Support.AreEqual(true, FastDriver.AddressBookSearchDlg.NewGAB.IsEnabled(), "Verify: New GAB button is enabled");

                Reports.TestStep = "Click on New GAB button and create a Lender with Name1 and Name2.";
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad(FastDriver.GABEntryRequestDlg.EntityType);
                FastDriver.GABEntryRequestDlg.CreateGAB("Lender", "First", "American", "1 First American Title", "Santa Ana", "33197", "CA");
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.LoanDetailsGabcodeLabel);
                var gabID = FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText();

                Reports.TestStep = "Navigate to ADM Side|Home|System Maintenance|GAB Entry Request Queue and Select the Region.";
                FastDriver.WebDriver.Quit();
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                FastDriver.GABEntryRequestQueue.Open();
                FastDriver.GABEntryRequestQueue.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");

                Reports.TestStep = "Select the Adhoc GAB and Double Click on it and Click on Add GAB and Select the Status as ADD.";
                FastDriver.GABEntryRequestQueue.GABEntryRequestTable.PerformTableAction(7, gabID, 1, TableAction.DoubleClick);
                FastDriver.AddressBookSearch.WaitForScreenToLoad(FastDriver.AddressBookSearch.Find);
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.AddressBookSearch.WaitForScreenToLoad(FastDriver.AddressBookSearch.AddToGAB);
                FastDriver.AddressBookSearch.AddToGAB.FAClick();

                FastDriver.BusinessOrgSearchDlg.WaitForScreenToLoad(FastDriver.BusPartyOrgSetUpAddToGABDlg.Status);
                FastDriver.BusPartyOrgSetUpAddToGABDlg.Status.FASelectItem("Added");
                FastDriver.BusPartyOrgSetUpAddToGABDlg.Done.FAClick();
                FastDriver.GABEntryRequestQueue.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to IIS Side New Loan Screen.";
                FastDriver.WebDriver.Quit();
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.NewLoan.Open();
                Support.AreEqual(true, FastDriver.NewLoan.BusinessPartyNameField.FAGetText().Contains("First"), "Verify: System should display Lender with Name1 (First)");
                Support.AreEqual(true, FastDriver.NewLoan.BusinessPartyNameField2.FAGetText().Contains("American"), "Verify: System should display Lender with Name2 (American)");


                Reports.TestStep = "Navigate to Project Workbench screen via Home | Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Mouse Over to that Icon and Click on Create Site Files Link.";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.Create);

                Reports.TestStep = "Select the Lender Checkbox and Create a Site file by entering Custom Site file number and by selecting State City and County.";
                FastDriver.ProjectWorkBench.Lender.FASetCheckbox(true);
                var siteFileNumber = _createNewSiteFile(true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual("1 File(s) successfully created.", FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText(), true);
                Support.AreEqual(true, !FastDriver.ProjectWorkBench.AddressLine1.IsEnabled(), "Verify: created site file must be in read only mode in the site files grid");

                Reports.TestStep = "Navigate to Site Files New Loan Screen";
                FastDriver.TopFrame.SearchFileByFileNumber(siteFileNumber);
                FastDriver.NewLoan.Open();
                Support.AreEqual("First", FastDriver.NewLoan.LenderName.FAGetText(), "Verify: System should display the Adhoc Lender with Name1 (First)");
                Support.AreEqual("American", FastDriver.NewLoan.BusinessPartyNameField2.FAGetText(), "Verify: System should display the Adhoc Lender with Name2 (American)");

                Reports.TestStep = "Navigate back to Project File Update Site Files Section.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be enabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual("First American",
                                  FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 1, TableAction.GetText).Message,
                                  "Verify: System should display Adhoc GAB Lender with name1 (First) and Name2 (American)"
                                 );

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("US650471: Test Case 672233")]
        public void User_Story_650471_TC672233()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-System should display Lender Mailing/Business address City State inside the New Lender Ellipse button and Should not display for Billing and Business";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)12000.00;
                fileRequest.File.FirstNewLoanAmount = (decimal)6500.00;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)6500.00;
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan and add a adhoc GAB Lender with only Mailing /Billing or Business address.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.EntityType);
                FastDriver.AddressBookSearchDlg.EntityName.FASetText("XYZ", true);
                FastDriver.AddressBookSearchDlg.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad(FastDriver.AddressBookSearchDlg.NewGAB);
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad(FastDriver.GABEntryRequestDlg.EntityType);
                FastDriver.GABEntryRequestDlg.CreateGAB("Lender", "First", "American", "1 First American Title", "Santa Ana", "33197", "CA");
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.LoanDetailsGabcodeLabel);
                var gabID = FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText();

                Reports.TestStep = "Navigate to ADM Side and Approved the Adhoc GAB";
                FastDriver.WebDriver.Quit();
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                FastDriver.GABEntryRequestQueue.Open();
                FastDriver.GABEntryRequestQueue.Region.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.GABEntryRequestQueue.GABEntryRequestTable.PerformTableAction(7, gabID, 1, TableAction.DoubleClick);
                FastDriver.AddressBookSearch.WaitForScreenToLoad(FastDriver.AddressBookSearch.Find);
                FastDriver.AddressBookSearch.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.AddressBookSearch.WaitForScreenToLoad(FastDriver.AddressBookSearch.AddToGAB);
                FastDriver.AddressBookSearch.AddToGAB.FAClick();
                FastDriver.BusinessOrgSearchDlg.WaitForScreenToLoad(FastDriver.BusPartyOrgSetUpAddToGABDlg.Status);
                FastDriver.BusPartyOrgSetUpAddToGABDlg.Status.FASelectItem("Added");
                FastDriver.BusPartyOrgSetUpAddToGABDlg.Done.FAClick();
                FastDriver.GABEntryRequestQueue.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to New Loan Screen.";
                FastDriver.WebDriver.Quit();
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.NewLoan.Open();
                Support.AreEqual("1 First American Title", FastDriver.NewLoan.LenderAddress.PerformTableAction(1, 1, TableAction.GetText).Message, "Verify: displayed address is equals as entered");
                Support.AreEqual("Santa Ana, CA, 33197, USA", FastDriver.NewLoan.LenderAddress.PerformTableAction(2, 1, TableAction.GetText).Message, "Verify: displayed address is equals as entered");

                Reports.TestStep = "Navigate to Project workbench Update Site Files Section.";
                FastDriver.ProjectWorkBench.Open();
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateNewLenderChk);

                Reports.TestStep = "Select New Lender Check box.";
                FastDriver.ProjectWorkBench.UpdateNewLenderChk.FASetCheckbox(true);
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSelectAll.IsEnabled(), "Verify: 'Select All' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateTransactionTypeChk.IsEnabled(), "Verify: 'Transaction' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateProductsChk.IsEnabled(), "Verify: 'Product(s)' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateBuyerChk.IsEnabled(), "Verify: 'Buyer' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSellerChk.IsEnabled(), "Verify: Seller check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateNotesChk.IsEnabled(), "Verify: 'Notes' check box is disabled");
                Support.AreEqual(false, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be disabled");
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesViewLenders.IsEnabled(), "Verify: 'View Lender(s)' radio button should be checked");

                Reports.TestStep = "Select the Add/ Delete Lender (S) Radio Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesAddDeleteLenders.FASetCheckbox(true);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.IsEnabled(), "Verify: 'New Lender Ellipse' button should be enabled");

                Reports.TestStep = "Click on New Lender Ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateSiteFilesNewLendersEllipsis.FAClick();
                FastDriver.ProjectWorkBench.LenderSelectionDlg.WaitForScreenToLoad(FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable);
                Support.AreEqual("Lender Selection", FastDriver.ProjectWorkBench.LenderSelectionDlg.DialogTitle.FAGetText(), "Verify: System should display header as Lender Selection.");
                Support.AreEqual("First American",
                                  FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 1, TableAction.GetText).Message,
                                  "Verify: System should display Lender with Name"
                                 );
                Support.AreEqual("Santa Ana",
                                  FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 2, TableAction.GetText).Message,
                                  "Verify: System should display Lender with City"
                                 );
                Support.AreEqual("CA",
                                  FastDriver.ProjectWorkBench.LenderSelectionDlg.UpdateLenderSelectionTable.PerformTableAction(2, 3, TableAction.GetText).Message,
                                  "Verify: System should display Lender with State"
                                 );
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #endregion

        #region User Story 609855: Update - Exchange company and GAB - Buyer and seller
        [TestMethod]
        [Description("US650471: Test Case 619048")]
        public void User_Story_609855_TC619048()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Validate:-System Should not display the Removed Lender in New Lender Ellipse button";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a CD File with Project File checkbox selected via Home | Order Entry | Quick File Entry";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.Buyers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                fileRequest.File.Sellers = new FASTWCFHelpers.FastFileService.BuyerSeller[0];
                var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Buyers/Sellers screen via Home | Order Entry | Buyers/Sellers";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);

                Reports.TestStep = "Create multiple Buyers/Sellers of type (Individual. Husband/Wife, Trust/Estate, Business Entity) Click on Exchange Company button and add a GAB with Contact and save the screen";
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("BuyerFirstName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("BuyerLastName");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.FindGAB(gabcode: "257").WaitForScrenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.btnNew);

                FastDriver.BuyerSellerSetup.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.BuyerTypes);
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Buyer2FirstName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Buyer2LastName");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.FindGAB(gabcode: "23062016").WaitForScrenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.GetRowCount() >= 2, "Verify: System has saved the changes");

                FastDriver.BuyerSellerSetup.Open(isBuyer: false);
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("SellerFirstName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("SellerLastName");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.FindGAB(gabcode: "220").WaitForScrenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.btnNew);

                FastDriver.BuyerSellerSetup.New();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.BuyerTypes);
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Seller2FirstName");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Seller2LastName");
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.FindGAB(gabcode: "215").WaitForScrenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.GetRowCount() >= 2, "Verify: System has saved the changes");

                Reports.TestStep = "Navigate to Project Workbench screen via Home | Order Entry | Project Workbench";
                FastDriver.ProjectWorkBench.Open();

                Reports.TestStep = "Create a Site file by entering Custom Site file number, and by selecting state and Click on Create button";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.CreateSiteFileOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.Create);

                var siteFileNumber = _createNewSiteFile(copyFromProjectFile: true);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles);
                Support.AreEqual(true, 
                                  FastDriver.ProjectWorkBench.TotalSuccessCreatedFiles.FAGetText().Contains("1 File(s) successfully created"), 
                                  "Verify: System displays message when user created a site file"
                                );

                Reports.TestStep = "Expand the update Site Files section/Tab";
                FastDriver.ProjectWorkBench.ClickCreateUpdateMenu(FastDriver.ProjectWorkBench.UpdateSiteFilesOption);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateBuyerChk);

                Reports.TestStep = "Select Buyer/Seller Checkbox from 'Choose Data to be Copied: ' and Click on respective ellipse Button.";
                FastDriver.ProjectWorkBench.UpdateBuyerChk.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.UpdateSellerChk.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.UpdateSiteFilesBuyerEllipsis.FAClick();
                FastDriver.ProjectWorkBench.BuyerSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Select the Buyer/Seller from Buyer/Seller Selection Dialog box and Click on done button.";
                FastDriver.ProjectWorkBench.BuyerSelectionDlg.CheckAll.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.BuyerSelectionDlg.Done.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis);

                FastDriver.ProjectWorkBench.UpdateSiteFilesSellerEllipsis.FAClick();
                FastDriver.ProjectWorkBench.SellerSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProjectWorkBench.SellerSelectionDlg.CheckAll.FASetCheckbox(true);
                FastDriver.ProjectWorkBench.SellerSelectionDlg.Done.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.SlidingTitle);

                Reports.TestStep = "Now Expand Site Files Tab and Select the site file which needs to be updated and click on update button.";
                Keyboard.SendKeys("S", modifierKeys: System.Windows.Input.ModifierKeys.Alt);
                FastDriver.ProjectWorkBench.WaitCreation(FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTableCheckboxSelectAll);
                FastDriver.ProjectWorkBench.UpdateSiteFilesSliderTable.PerformTableAction(2, siteFileNumber, 1, TableAction.Click);
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderDone.FAClick();

                Reports.TestStep = "Navigate to File Search screen via Home | Oder Entry | File Search";
                FastDriver.FileSearch.NavigateTo();

                Reports.TestStep = "Search for the Site file by entering the File number as Project file number + Site File number";
                FastDriver.FileSearch.Numbers.FASetText(siteFileNumber);
                FastDriver.FileSearch.FindNow.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 40);
                FastDriver.FileHomepage.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Buyer/Sellers screen and verify the Exchange Company details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true);
                Support.AreEqual(true, 
                                 FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.GetRowCount() >= 2, 
                                 "Verify: Site file has the same buyers as the project file"
                                 );
                Support.AreEqual(true, 
                                 FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 7, TableAction.GetText).Message.Length > 0, 
                                 "Verify: Site file has Exchange Company details"
                                );
                Support.AreEqual(true,
                                 FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 7, TableAction.GetText).Message.Length > 0,
                                 "Verify: Site file has Exchange Company details"
                                );

                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                Support.AreEqual(true,
                                 FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.GetRowCount() >= 2,
                                 "Verify: Site file has the same buyers as the project file"
                                 );
                Support.AreEqual(true,
                                 FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 7, TableAction.GetText).Message.Length > 0,
                                 "Verify: Site file has Exchange Company details"
                                );
                Support.AreEqual(true,
                                 FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(3, 7, TableAction.GetText).Message.Length > 0,
                                 "Verify: Site file has Exchange Company details"
                                );
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region private methods
        private void _createCDCommercialFile() {
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.txtBusinessSourceGABID.FASendKeys("246");
            FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();
            Playback.Wait(2000);

            FastDriver.QuickFileEntry.cbxServiceEscrow.FASetCheckbox(true);
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItem("Commercial");
            FastDriver.QuickFileEntry.TransactionType.FASelectItem("Accommodation");
            FastDriver.QuickFileEntry.ProjectFile.FASetCheckbox(true);
            FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
        }

        private string _createNewSiteFile(bool copyFromProjectFile=false, string fileNumber = "CA1", string state = "CA")
        {
            string siteFileNumber = string.Empty;

            FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.CopyForSiteFile1);
            siteFileNumber = FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 1, TableAction.GetText).Message;
            if (copyFromProjectFile)
            {
                FastDriver.ProjectWorkBench.CopyForSiteFile1.FASetCheckbox(true);
                siteFileNumber += FastDriver.ProjectWorkBench.tblCreateSiteFiles.PerformTableAction(1, 2, TableAction.GetInputValue).Message;
            }
            else {
                FastDriver.ProjectWorkBench.SiteFileNum.FASendKeys(fileNumber);
                FastDriver.ProjectWorkBench.State.FASelectItem(state);
                siteFileNumber += fileNumber;
            }

            FastDriver.ProjectWorkBench.Create.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

            return siteFileNumber;
        }
        #endregion
    }
}
