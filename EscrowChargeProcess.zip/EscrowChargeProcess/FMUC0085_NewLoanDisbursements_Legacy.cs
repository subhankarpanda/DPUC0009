﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.Common;
using OpenQA.Selenium;
using System.Text.RegularExpressions;

namespace EscrowChargeProcess
{
    [CodedUITest]
    public class FMUC0085_NewLoanDisbursements_Legacy : MasterTestClass
    {
        #region Fee Names - to handle both HUD and CD forms

        private string ApplicationFee = "Application Fee";
        private string HomeOwnersInsurance = "Homeowner's Insurance";
        private string AppraisalFee = "Appraisal Fee";
        private string PrepaidInterest = "Prepaid Interest";
        
        #endregion

        #region BAT

        [TestMethod]
        public void FMUC0085_ASetup()
        {
            try
            {
                Reports.TestDescription = "Setup for QC Closing.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to address book.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                
                Reports.TestStep = "Search for a gab code.";
                FastDriver.AddressBookSearch.SearchAddressBook("248");
                FastDriver.AddressBookSearch.EditAddress("248");

                Reports.TestStep = "Select QC @ Closing Client checkbox.";
                FastDriver.BusPartyOrgSetUp.QCClosingClient.FASetCheckbox(true);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Continuation from FMUC0085_BAT0001A";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(HomeOwnersInsurance, buyerCharge: 44.00, sellerCharge: 33.00);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                // test case BAT0001B. 
                Reports.TestStep = "Verify QC @ Closing tab is enabled.";
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case BAT0001C. 
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                // start of BAT0001D
                Reports.TestStep = "Click Loan Charge Tab";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Click on New for Enter New payee.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("247");

                Reports.TestStep = "Select " + PrepaidInterest + " from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);
               
                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Add a new payee1.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("249");

                Reports.TestStep = "Select Application Fee and Appraisal Fee from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Add a new payee1.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("250");

                Reports.TestStep = "Select Homewoner's Insurance from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, HomeOwnersInsurance, 1, TableAction.On);
       
                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                var payee = "David W. Silver & Associates";
                Reports.TestStep = "Validate payees added in newloan - " + payee;
                var status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Status", TableAction.GetText).Message;
                Support.AreEqual("Pending", status, "Disburment status for " + payee);
                var amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Amount", TableAction.GetText).Message.Trim();
                Support.AreEqual("12.00", amount, "Disburment amount for " + payee);

                payee = "Fritz Tellefsen";
                Reports.TestStep = "Validate payees added in newloan - " + payee;
                status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Status", TableAction.GetText).Message;
                Support.AreEqual("Pending", status, "Disburment status for " + payee);
                amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Amount", TableAction.GetText).Message.Trim();
                Support.AreEqual("77.00", amount, "Disburment amount for " + payee);

                payee = "Lenders Advantage A Division Of First Am";
                Reports.TestStep = "Validate payees added in newloan - " + payee;
                status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Status", TableAction.GetText).Message;
                Support.AreEqual("Pending", status, "Disburment status for " + payee);
                amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Amount", TableAction.GetText).Message.Trim();
                Support.AreEqual("2.00", amount, "Disburment amount for " + payee);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_BAT0002()
        {
            try
            {
                Reports.TestDescription = "AF1_AF3: Deselect New Loan Charges.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(HomeOwnersInsurance, buyerCharge: 44.00, sellerCharge: 33.00);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);
                               
                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Click on New for Enter New payee.";
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("247");

                Reports.TestStep = "Select " + PrepaidInterest + " from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Add a new payee1.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("249");

                Reports.TestStep = "Select Application Fee and Appraisal Fee from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Add a new payee1.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("250");

                Reports.TestStep = "Select Homewoner's Insurance from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, HomeOwnersInsurance, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                // start of actual test for BAT0002
                Reports.TestStep = "Navigate to New Loan screen and Loan Charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Deselect New Loan Charges.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.Off);
                Support.AreEqual("0.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check Amount");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Validate when a payee is un-selected";
                int count = Regex.Matches(FastDriver.ActiveDisbursementSummary.Disbursements.Text, "Lenders Advantage").Count;
                Support.AreEqual("0", count.ToString(), "Number of times 'Lenders Advantage' appears on the Disbursement Table");

                Reports.TestStep = "Navigate to New Loan screen and Loan Charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Select New Loan Charges.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to New Loan screen and Loan Charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Deselect New Loan Charges.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.Off);
                Support.AreEqual("0.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check Amount");

                Reports.TestStep = "Remove the selected payee by using Alt+R";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.SendKeys("%R");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to New Loan screen and Loan Charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Validate the removal of the payee.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.Off);
                Support.AreEqual("0.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check Amount");

                Reports.TestStep = "Remove the selected payee by using Alt+R";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.SendKeys("%R");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Validate the removal of the payee.";
                count = Regex.Matches(FastDriver.NewLoanDisbursements.PayeeSummaryTable.Text, "Lenders Advantage").Count;
                Support.AreEqual("1", count.ToString(), "Number of times 'Lenders Advantage' appears on the Payee Summary Table");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Add Duplicate Disbursement Payee.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(HomeOwnersInsurance, buyerCharge: 44.00, sellerCharge: 33.00);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                // start of actual test for BAT0003
                Reports.TestStep = "Click on New for Enter New payee.";
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.New.FAClick();

                Reports.TestStep = "Add Duplicate Disbursement Payee.";
                FastDriver.NewLoanDisbursements.FindGABCode("248");

                Reports.TestStep = "Select " + PrepaidInterest  + " from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to New Loan screen and Loan Charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Select New Loan Charges.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                
                Reports.TestStep = "Validate the duplicate payee";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                int count = Regex.Matches(FastDriver.NewLoanDisbursements.PayeeSummaryTable.Text, "Midwest Financial Group").Count;
                Support.AreEqual("2", count.ToString(), "Number of times 'Midwest Financial Group' appears on the Payee Summary Table");


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF2_00: Edit New Loan Charges.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(HomeOwnersInsurance, buyerCharge: 44.00, sellerCharge: 33.00);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Click on New for Enter New payee.";
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("250");

                Reports.TestStep = "Select " + PrepaidInterest + " from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                
                // start of actual test for BAT0004
                Reports.TestStep = "Enter Aggregate Accounting Adjustment charges";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(1, buyerCharge: 66.00, sellerCharge: 77.00);

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Edit New Loan Charges.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Fritz Tellefsen", 2, TableAction.Click);
                var buyerCharge = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, HomeOwnersInsurance, 4, TableAction.GetText).Message;
                Support.AreEqual("66.00", buyerCharge, "Homeowner's Insurance Buyer Charge");
                var sellerCharge = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, HomeOwnersInsurance, 6, TableAction.GetText).Message;
                Support.AreEqual("77.00", sellerCharge, "Homeowner's Insurance Seller Charge");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Add Duplicate Disbursement Payee.As updated in 8.2 release.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(HomeOwnersInsurance, buyerCharge: 44.00, sellerCharge: 33.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges("33.00", addNewRow: true);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);
                

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                // Test case BAT0005B
                Reports.TestStep = "(BAT0005B in CUI framework) Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // Test case BAT0005C
                Reports.TestStep = "(BAT0005C in CUI framework)Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                
                // Test case BAT0005D
                Reports.TestStep = "Click on Loan Charge tab.";
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Select a Charges for disbursement - " + PrepaidInterest;
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Select a Charges for disbursement - " + ApplicationFee;
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);
                
                Reports.TestStep = "Verify the total check amount after selecting charges.";
                Support.AreEqual("5.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check amount");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Click on New and add the duplicate payee.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("248");

                Reports.TestStep = "Select a Charges for disbursement - Appraisal Fee.";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.On);

                Reports.TestStep = "Select a Charges for disbursement for duplicate payee.";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, HomeOwnersInsurance, 1, TableAction.On);

                Reports.TestStep = "Verify the total check amount after selecting charges.";
                Support.AreEqual("86.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check amount");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Validate the status and payee names of duplicate.";
                int count = Regex.Matches(FastDriver.ActiveDisbursementSummary.Disbursements.Text, "Midwest Financial Group").Count;
                Support.AreEqual("2", count.ToString(), "Number of times 'Midwest Financial Group' appears on the Disbursement Table");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        #endregion

        #region REG

        [TestMethod]
        public void FMUC0085_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM4239_FM4240_FM4242_FM4243_FM4244_FM4245_FM4246_FM4281_FM4249_FM4250_FM4251: New Loan Disbursements." + 
                                          "This test combined REG0001A to REG0001D";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(HomeOwnersInsurance, buyerCharge: 44.00, sellerCharge: 33.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges("33.00", addNewRow: true);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                Reports.TestStep = "Click Charge Tab";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Display Charges in Order";
                Support.AreEqual(AutoConfig.FormType=="HUD"?"New Encumbrance":"Loan Amount", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, 2, TableAction.GetText).Message, "1st Charge");
                Support.AreEqual(PrepaidInterest, FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(3, 2, TableAction.GetText).Message, "2nd Charge");
                Support.AreEqual(ApplicationFee, FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(4, 2, TableAction.GetText).Message, "3rd Charge");
                Support.AreEqual(AppraisalFee, FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(5, 2, TableAction.GetText).Message, "4th Charge");
                Support.AreEqual(HomeOwnersInsurance, FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(6, 2, TableAction.GetText).Message, "5th Charge");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                // test case REG0001B. 
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case REG0001C. 
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);

                // start of REG0001D
                Reports.TestStep = "Click Charge Tab";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                
                Reports.TestStep = "Click on New for Enter New payee.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("247");

                Reports.TestStep = "Select " + PrepaidInterest + " from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Add a new payee1.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("249");

                Reports.TestStep = "Select Application Fee and Appraisal Fee from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Select the payee.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);
                Support.AreEqual("247", FastDriver.NewLoanDisbursements.IDCode.Text, "Verify Lenders Advantage's GAB code");

                Reports.TestStep = "Click on New button";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad().SwitchToContentFrame();
                Support.AreEqual("", FastDriver.NewLoanDisbursements.IDCode.Text.Trim(), "Verify new payee's GAB code is blank");

                Reports.TestStep = "Enter the GAB details and validate no selectable charge.";
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.Charges1.Enabled.ToString(), (AutoConfig.FormType=="HUD"?"New Encumbrance":"Loan Amount") + " checkbox is disabled");
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.Charges2.Enabled.ToString(), PrepaidInterest + " checkbox is disabled");
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.Charges3.Enabled.ToString(), "Application Fee checkbox is disabled");
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.Charges4.Enabled.ToString(), "Appraisal Fee checkbox is disabled");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Validate the 1st buyer and seller charges in charges table.";
                Support.AreEqual("Midwest Financial Group", FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(2, 1, TableAction.GetText).Message, "Verify first buyer");

                Reports.TestStep = "Validate the 2nd buyer and seller charges in charges table.";
                Support.AreEqual("Lenders Advantage", FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(3, 1, TableAction.GetText).Message, "Verify second buyer");
                Support.AreEqual("2.00", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 4, TableAction.GetText).Message, "Paid by Borrower at Closing");
                Support.AreEqual("True", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(3, 1, TableAction.GetCell).Element.Enabled.ToString(), PrepaidInterest + " checkbox is enabled");

                Reports.TestStep = "Validate the 3rd buyer and seller charges in charges table.";
                Support.AreEqual("David W. Silver & Associates", FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(4, 1, TableAction.GetText).Message, "Verify third buyer");
                Support.AreEqual("3.00", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 4, TableAction.GetText).Message, "Paid by Borrower at Closing");
                Support.AreEqual("True", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.GetCell).Element.Enabled.ToString(), "Application Fee checkbox is enabled");

                Reports.TestStep = "Validate the 4th buyer and seller charges in charges table.";
                Support.AreEqual("David W. Silver & Associates", FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(4, 1, TableAction.GetText).Message, "Verify third buyer");
                Support.AreEqual("4.00", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 4, TableAction.GetText).Message, "Paid by Borrower at Closing");
                Support.AreEqual("True", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.GetCell).Element.Enabled.ToString(), "Appraisal Fee checkbox is enabled");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0002()
        {
            try
            {
                Reports.TestDescription = "FM4254_FM4238_FM4265_FM4255_FM4256_FM4268_FM4270_FM4266_FM4267: Deselect Payee Charges.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges("4.00", addNewRow: true);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Click on New for Enter New payee.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("247");

                Reports.TestStep = "Select " + PrepaidInterest + " from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Add a new payee1.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("249");

                Reports.TestStep = "Select Application Fee and Appraisal Fee from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                if (AutoConfig.FormType == "CD")
                {
                    Reports.TestStep = "Click on Loan Charges tab";
                    FastDriver.NewLoan.ClickChargesTab();
                }

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                // start of REG0002
                Reports.TestStep = "Deselect the charge assigned to a payee.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.Off);
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.CheckAmount.Enabled.ToString(), "Check Amount is enabled");

                Reports.TestStep = "Verify the payment method for the charge before Select it.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.Off);
                Support.AreEqual("0.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check Amount");
                Support.AreEqual("Buyer: RBL Seller: RBL", FastDriver.NewLoanDisbursements.ChargesPayeeName1.FAGetAttribute("title").Trim(), "HelpText");

                Reports.TestStep = "Assign the charge and validate the payee name.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Validate the payment method for the selected charge.";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 3, TableAction.Click);
                Support.AreEqual("2.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check Amount");
                Support.AreEqual("Buyer: CHK Seller: CHK", FastDriver.NewLoanDisbursements.ChargesPayeeName1.FAGetAttribute("title").Trim(), "HelpText");

                Reports.TestStep = "Validate the lender can be removed.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Midwest Financial Group", 2, TableAction.Click);
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.Remove.Enabled.ToString(), "Remove button is enabled");

                Reports.TestStep = "Deselect the charge assigned to a payee.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.Off);
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.CheckAmount.Enabled.ToString(), "Check Amount is enabled");

                Reports.TestStep = "Verify the remove button enabled after deselect the charges.";
                Support.AreEqual("True", FastDriver.NewLoanDisbursements.Remove.Enabled.ToString(), "Remove button is enabled");

                Reports.TestStep = "Remove the selected payee.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.SendKeys("%R");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM4247: Update Edits to Main Page.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("249");
                req.File.TransactionTypeObjectCD = "REFI";
                req.File.FirstNewLoanAmount = 2480000m;
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                //FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1000);  // buyer charge is not enabled.
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1100");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("04-07-2015");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("05-14-2015" + FAKeys.Tab);
                var buyerActualPrice = FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue();

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                Reports.TestStep = "Click on Loan Charges tab";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Calculated Buyer charge is displayed in New Loan Disbursements page";
                Support.AreEqual(buyerActualPrice, FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(3, 4, TableAction.GetText).Message, "Paid by Borrower At Closing");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Change Per Diem Amount and Calculate the Buyer Amount";
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1300" + FAKeys.Tab);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Get buyer charge for comparison";
                FastDriver.NewLoan.SwitchToContentFrame();
                buyerActualPrice = FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue();

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                Reports.TestStep = "Navigate to New Loan Disbursements page and Verify the Calculated Buyer charges are Updated";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Calculated Buyer charge is displayed in New Loan Disbursements page";
                Support.AreEqual(buyerActualPrice, FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(3, 4, TableAction.GetText).Message, "Paid by Borrower At Closing");


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0004()
        {
            try
            {
                Reports.TestDescription = "Continuation from FMUC0085_REG0004. This test combined REG0004A to REG0004D";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and Loan Charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(HomeOwnersInsurance, buyerCharge: 44.00, sellerCharge: 33.00);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);

                // test case REG0004B.
                Reports.TestStep = "Verify QC @ Closing tab is enabled.";
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case REG0004C.
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                // start of REG0004D
                Reports.TestStep = "Click Charge Tab";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Validate the payee for 1st charge should be lender by default.";
                Support.AreEqual("Midwest Financial Group", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, 3, TableAction.GetText).Message, "1st Payee");

                Reports.TestStep = "Validate the payee for 2nd charge should be lender by default.";
                Support.AreEqual("Midwest Financial Group", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(3, 3, TableAction.GetText).Message, "2nd Payee");

                Reports.TestStep = "Validate the payee for 3rd charge should be lender by default.";
                Support.AreEqual("Midwest Financial Group", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(4, 3, TableAction.GetText).Message, "3rd Payee");

                Reports.TestStep = "Validate the payee for 4th charge should be lender by default.";
                Support.AreEqual("Midwest Financial Group", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(5, 3, TableAction.GetText).Message, "4th Payee");

                Reports.TestStep = "Click on New for Enter New payee.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("247");

                Reports.TestStep = "Select " + PrepaidInterest  + " from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Add a new payee1.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("249");

                Reports.TestStep = "Select Application Fee and Appraisal Fee from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to Active Disbursement Summary screen";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                var payee = "David W. Silver & Associates";
                Reports.TestStep = "Validate payees added in newloan - " + payee;
                var status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Status", TableAction.GetText).Message;
                Support.AreEqual("Pending", status, "Disburment status for " + payee);
                var amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Amount", TableAction.GetText).Message.Trim();
                Support.AreEqual("12.00", amount, "Disburment amount for " + payee);

                payee = "Lenders Advantage A Division Of First Am";
                Reports.TestStep = "Validate payees added in newloan - " + payee;
                status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Status", TableAction.GetText).Message;
                Support.AreEqual("Pending", status, "Disburment status for " + payee);
                amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", payee, "Amount", TableAction.GetText).Message.Trim();
                Support.AreEqual("2.00", amount, "Disburment amount for " + payee);

                Reports.TestStep = "Validate the details of the new loan disbursement.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Lenders Advantage A Division Of First Am", "Payee", TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Validate the charge details of the charge created in new loan.";
                Support.AreEqual(PrepaidInterest.Replace(" ", "") + ":2.00", FastDriver.EditDisbursement.VoucherChargeDetail.Text.Replace(" ", ""), "Charge detail (remove all blank spaces for comparison)");

                Reports.TestStep = "Navigate to Active Disbursement Summary screen";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();
                FastDriver.IssueDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Wait for SDN search to complete.";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(50);

                Reports.TestStep = "Navigate to Active Disbursement Summary screen";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                Reports.TestStep = "Click on Disburse All.";
                FastDriver.ActiveDisbursementSummary.DisburseAll.FAClick();
                FastDriver.IssueDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Issue The Wires.";        
                FastDriver.IssueDisbursements.Disburse.FAClick();

                Reports.TestStep = "Perform Print Deliveries.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print", true, 20);
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                Playback.Wait(1000);
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad(Support.FASTWindowName);    
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                                
                // Delivery window
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);
                                
                Reports.TestStep = "Navigate to New Loan screen and Loan Charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Click Charge Tab";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Verify the new loans are disbursed by checking the existence of image.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);
                Support.AreEqual("True", FastDriver.NewLoanDisbursements.CheckIssuedIcon.Exists().ToString(), "Check Issue icon exists?");

                Reports.TestStep = "Verify the details for the image - Issued and amount.";
                var helpText = FastDriver.NewLoanDisbursements.CheckIssuedIcon.FAGetAttribute("title");
                Support.AreEqual("True", helpText.Contains("Issued").ToString(), "Tooltip contains 'Issued'");
                Support.AreEqual("True", helpText.Contains("2.00").ToString(), "Tooltip contains amount '2.00'");
                               

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0005()
        {
            try
            {
                Reports.TestDescription = "FM4382_FM4259_FM4262_FM4263: Update Payee Name to ‘Pay To’ on Payment Details. " + 
                                          "This test combined REG0005A to REG0005D";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and Loan Charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);

                // test case REG0005B.
                Reports.TestStep = "Verify QC @ Closing tab is enabled.";
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case REG0005C. Reports.TestDescription = "If enabled, enter the data for QC @Closing - Dependency Flow";
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();

                // test case REG0005D.
                Reports.TestStep = "Click Charge Tab";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Click on New for Enter New payee.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("247");

                Reports.TestStep = "Select " + PrepaidInterest + " from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "Add a new payee1.";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("249");

                Reports.TestStep = "Select Application Fee and Appraisal Fee from Disbursement Charges Table";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Select the payee.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Lenders Advantage", 2, TableAction.Click);

                Reports.TestStep = "Edit the check details for the payee.";
                FastDriver.NewLoanDisbursements.CheckDetails.FAClick(); //Keyboard.SendKeys("%H");

                Reports.TestStep = "Click on cancel.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Check Detail");
                FastDriver.CheckDetailsDlg.WaitForScreenToLoad();
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Click Done";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click on Interest calculation section Payment details.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Pay To Name for the Interest calculation section.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                if (AutoConfig.FormType == "HUD")
                {
                    Support.AreEqual("CHK", FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FAGetSelectedItem() ?? "", "Seller Payment method");
                    Support.AreEqual("CHK", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FAGetSelectedItem() ?? "", "Buyer Payment method");
                }
                else
                {
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem() ?? "", "Seller Payment method");
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem() ?? "", "Buyer Payment method");
                }
                Support.AreEqual("Lenders Advantage", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue(), "Pay To");

                Reports.TestStep = "Click on cancel.";
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Click on GFE #3 section Payment details.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Pay To Name for the GFE #3 section.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                if (AutoConfig.FormType == "HUD")
                {
                    Support.AreEqual("CHK", FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FAGetSelectedItem() ?? "", "Seller Payment method");
                    Support.AreEqual("CHK", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FAGetSelectedItem() ?? "", "Buyer Payment method");
                }
                else
                {
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem() ?? "", "Seller Payment method");
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem() ?? "", "Buyer Payment method");
                }
                Support.AreEqual("David W. Silver & Associates", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().Trim(), "Pay To");

                Reports.TestStep = "Verify the fields in Payment details dialog."; // just check if they exist???
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.usedefault.Exists().ToString(), "Use Default checkbox exists.");
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.Description.Exists().ToString(), "Description field exists.");
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PayTo.Exists().ToString(), "Pay To field exists.");
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerCharge.Exists().ToString(), "Buyer Charge field exists.");
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.SellerCharge.Exists().ToString(), "Seller Charge field exists.");
                if (AutoConfig.FormType == "HUD")
                {
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.GFEType.Exists().ToString(), "GFE Type dropdown exists.");
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.LenderSelectedProvider.Exists().ToString(), "Lender Selected Provicder exists.");
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.SellerPaymentMethod.Exists().ToString(), "Seller Payment Method dropdown exists.");
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.Exists().ToString(), "Buyer Payment Method dropdown exists.");
                }
                else
                {
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Exists().ToString(), "Seller Payment Method dropdown exists.");
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Exists().ToString(), "Buyer Payment Method dropdown exists.");
                }

                Reports.TestStep = "Verify the FEE payment method in Payment details dialog.";
                if (AutoConfig.FormType == "HUD")
                {
                    Support.AreNotEqual("FEE", FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FAGetAttribute("InnerText"), "Seller Payment method != FEE");
                    Support.AreNotEqual("FEE", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FAGetAttribute("InnerText"), "Buyer Payment method != FEE");
                }
                else
                {
                    Support.AreNotEqual("FEE", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetAttribute("InnerText"), "Seller Payment method != FEE");
                    Support.AreNotEqual("FEE", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetAttribute("InnerText"), "Buyer Payment method != FEE");
                }

                Reports.TestStep = "Click on cancel.";
                FastDriver.DialogBottomFrame.ClickCancel();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0006()
        {
            try
            {
                Reports.TestDescription = "FM4275: Change Columns for Refi/Loan Transaction Type.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("249");
                req.File.TransactionTypeObjectCD = "REFI";
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, borrowerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, borrowerCredit: 1.00);
                
                // test case REG0006B. Reports.TestDescription = "Validated for QC @Closing tab is enabled.";
                //Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                //Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case REG0006C. Reports.TestDescription = "If enabled, enter the data for QC @Closing - Dependency Flow";
                //Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                //FastDriver.NewLoan.ClickQCClosingTab();
                //FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                // Test case REG0006D
                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Borrower credit and borrower charge fields in charges table for refinance type of loan.";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.VerifyColumn("Borrower Charge");
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.VerifyColumn("Borrower Credit");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0007()
        {
            try
            {
                Reports.TestDescription = "ES11635_ES11636_FM4252_FM4253_ES12625: Third party payee for Itemized Origination Charges.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("FHA");
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCredit: 2.00);
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 10.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                if (AutoConfig.FormType == "HUD")
                {
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 2.00, sellerCharge: 1.00);
                    FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingDescription2.FASetText("Itemized charge" + FAKeys.Tab);
                    FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingBuyerCharge2.FASetText("5.00" + FAKeys.Tab);
                }
                else
                {
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);
                    FastDriver.NewLoan.NewLoanChargesTable.EnterCharges("Escrow Waiver Fee", newDescription: "4.00");
                }
                 
                // test case REG0007B. 
                Reports.TestStep = "Verify QC @ Closing tab is enabled.";
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case REG0007C.
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                // Test case REG0007D
                Reports.TestStep = "Click on Loan Charges Tab";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                if (AutoConfig.FormType == "HUD")
                {
                    Reports.TestStep = "Verify the Itemized charge can be selected.";
                    Support.AreEqual("True", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, "Itemized charge", 1, TableAction.GetCell).Element.Enabled.ToString(), "Verify Itemized charge can be selected");

                    Reports.TestStep = "Verify the Origination charge (Remaining) can be selected.";
                    Support.AreEqual("True", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, "Our Origination Charge (Remaining)", 1, TableAction.GetCell).Element.Enabled.ToString(), "Verify charge can be selected");

                    Reports.TestStep = "Verify the Itemized charge amount.";
                    Support.AreEqual("5.00", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, "Our Origination Charge (Remaining)", 4, TableAction.GetText).Message, "Verify Origination charge amount");

                    Reports.TestStep = "Verify the Origination charge (Remaining) amount.";
                    Support.AreEqual("5.00", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, "Itemized charge", 4, TableAction.GetText).Message, "Verify Itemize charge amount");
                }
                else
                {
                    Reports.TestStep = "Verify the Application Fee can be selected.";
                    Support.AreEqual("True", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, "Application Fee", 1, TableAction.GetCell).Element.FindElement(By.TagName("input")).Enabled.ToString(), "Verify charge can be selected");

                    Reports.TestStep = "Verify the Application Fee amount.";
                    Support.AreEqual("10.00", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, "Application Fee", 4, TableAction.GetText).Message, "Verify Application Fee amount");
                }

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                if (AutoConfig.FormType == "HUD")
                {
                    Reports.TestStep = "Click on Itemized origination charges payment details.";
                    FastDriver.NewLoan.LoanChargesItemizedOriginationCharges_PaymentDetails.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                    Reports.TestStep = "Change the Payment method of buyer to POC for Itemized origination charges.";
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");

                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerCredit.Exists().ToString(), "Buyer Credit exists");
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.SellerCredit.Exists().ToString(), "Seller Credit exists");

                    Reports.TestStep = "Click on done dialog.";
                    FastDriver.DialogBottomFrame.ClickDone();

                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    
                    Reports.TestStep = "Click on Pay Charges.";
                    FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                    FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                    Reports.TestStep = "Verify the POC charge cannot be selected.";
                    Support.AreEqual("False", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(4, 1, TableAction.GetCell).Element.FindElement(By.TagName("input")).Enabled.ToString(), "Verify 3rd charge cannot be selected");
                   
                    Reports.TestStep = "Click Done";
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    
                    Reports.TestStep = "Click on GFE #3 section Payment details.";
                    FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                    Reports.TestStep = "Change the Payment method of buyer to POC for Itemized origination charges.";
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("POC-B");

                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BuyerCredit.Exists().ToString(), "Buyer Credit exists");
                    Support.AreEqual("True", FastDriver.PaymentDetailsDlg.SellerCredit.Exists().ToString(), "Seller Credit exists");

                    Reports.TestStep = "Click on done dialog.";
                    FastDriver.DialogBottomFrame.ClickDone();

                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Click on Pay Charges.";
                    FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                    FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                    Reports.TestStep = "Select the charge created with different payment methods.";
                    FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.On);

                    Reports.TestStep = "Verify tooltip";
                    Support.AreEqual("Buyer: POC-B Seller: CHK", FastDriver.NewLoanDisbursements.ChargesPayeeName2.GetAttribute("title"), "Verify payee tooltip");

                    Reports.TestStep = "Click Done";
                    FastDriver.BottomFrame.Done();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Click on GFE #3 section Payment details.";
                    FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                    FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                    Reports.TestStep = "Add POC amount for Itemized Origination Charges.";
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("RBL");
                    FastDriver.PaymentDetailsDlg.POCEnterPost.FASetCheckbox(true);
                    FastDriver.PaymentDetailsDlg.POCAmount.Exists(5); // wait for POCAmount to become enabled.
                    FastDriver.PaymentDetailsDlg.POCAmount.FASetText("10.00");
                    FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("#");

                    Reports.TestStep = "Click on done dialog.";
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                }

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Verify the POC charge amount in the table.";
                Support.AreEqual("4.00", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 4, TableAction.GetText).Message, AppraisalFee + " charge amount");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0008()
        {
            try
            {
                Reports.TestDescription = "FM4241_FM4277: Allow Selection of Net Credit Charge Rows.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);

                // test case REG0008B.
                Reports.TestStep = "Verify QC @ Closing tab is enabled.";
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case REG0008C.
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                Reports.TestStep = "Click Loan Charges tab";
                FastDriver.NewLoan.ClickChargesTab();

                // Test case REG0007D
                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Click on New Click on Find.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.Find.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", true, 10);

                Reports.TestStep = "Enter a Name and find it.";
                FastDriver.AddressBookSearchDlg.WaitForScreenToLoad();
                FastDriver.AddressBookSearchDlg.FindContact(EntityName: "abc").WaitForResultsToLoad();

                Reports.TestStep = "Click on New GAB button.";
                FastDriver.AddressBookSearchDlg.NewGAB.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Request GAB Entry");

                Reports.TestStep = "Verify the Entity type.";
                FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
                Support.AreEqual("Miscellaneous", FastDriver.GABEntryRequestDlg.EntityType.FAGetSelectedItem(), "Selected Entity type");

                Reports.TestStep = "Click on Cancel in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Click Cancel on Address Book Business Organization Search";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", true, 10);
                FastDriver.DialogBottomFrame.ClickCancel();

                Reports.TestStep = "Click Done";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Click on New for Enter New payee.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("247");

                Reports.TestStep = "Select 2nd charge";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(3, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Add a new payee1.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("249");

                Reports.TestStep = "Select 3rd and 4th charges";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(4, 1, TableAction.On);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(5, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Verify the check amount before adding the credits.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "David W. Silver & Associates", 1, TableAction.Click);
                Support.AreEqual("12.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check amount");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                if (AutoConfig.FormType == "HUD")
                {
                    Reports.TestStep = "Add the credits to the loan.";
                    FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCredit: 4.00, sellerCredit: 5.00);
                }

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                if (AutoConfig.FormType == "HUD")
                {
                    Reports.TestStep = "Verify the check amount after adding the net credits.";
                    FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "David W. Silver & Associates", 1, TableAction.Click);
                    Support.AreEqual("3.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check amount");
                }

                Reports.TestStep = "Verify the HUD-1 Line Number tool tips.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "David W. Silver & Associates", 1, TableAction.Click);

                if (AutoConfig.FormType == "CD")
                {
                    Support.AreEqual("Section : ", FastDriver.NewLoanDisbursements.BuyerCharge.FAGetAttribute("title"), "tool tip of Buyer Charge");
                    Support.AreEqual("Section : L", FastDriver.NewLoanDisbursements.BuyerCredit.FAGetAttribute("title"), "tool tip of Buyer Credit");
                    Support.AreEqual("Section : N", FastDriver.NewLoanDisbursements.SellerCharge.FAGetAttribute("title"), "tool tip of Seller Charge");
                    Support.AreEqual("Section : ", FastDriver.NewLoanDisbursements.SellerCredit.FAGetAttribute("title"), "tool tip of Buyer Credit");
                }
                else 
                {
                    Support.AreEqual("HUD1 line Number : 104", FastDriver.NewLoanDisbursements.BuyerCharge.FAGetAttribute("title"), "tool tip of Buyer Charge");
                    Support.AreEqual("HUD1 line Number : 202", FastDriver.NewLoanDisbursements.BuyerCredit.FAGetAttribute("title"), "tool tip of Buyer Credit");
                    Support.AreEqual("HUD1 line Number : 506", FastDriver.NewLoanDisbursements.SellerCharge.FAGetAttribute("title"), "tool tip of Seller Charge");
                    Support.AreEqual("HUD1 line Number : 404", FastDriver.NewLoanDisbursements.SellerCredit.FAGetAttribute("title"), "tool tip of Buyer Credit");
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0009()
        {
            try
            {
                Reports.TestDescription = "FM4273_FM4397_FM4268_ES7442_ES7441: Mortgage Broker Disbursements.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Click on Mortgage broker tab";
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                
                Reports.TestStep = "Find GAB code";
                FastDriver.NewLoan.MortgageFindGABCode("248");

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("10.00");
                FastDriver.NewLoan.MortgageBrokerChargesTable.EnterCharges(AppraisalFee, buyerCharge: 5.00, sellerCharge: 4.00);

                Reports.TestStep = "Click Pay Charges";
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Yield Spread Premium for the lender.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Midwest Financial Group", 1, TableAction.Click);
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.Remove.Enabled.ToString(), "Remove button is not enabled");
                Support.AreEqual("True", FastDriver.NewLoanDisbursements.Charges1.Enabled.ToString(), "Charge1 is enabled");

                Reports.TestStep = "Verify the Yield Spread Premium is not allowed to selected for a payee.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("247");

                Reports.TestStep = "Verify Charge1 field";
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.Charges1.Enabled.ToString(), "Charge1 is not enabled");

                Reports.TestStep = "Select charge2";
                FastDriver.NewLoanDisbursements.Charges2.FAClick();

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0010()
        {
            try
            {
                Reports.TestDescription = "FM4255_FM4244_FM4255 : Highlight Payee to Display Detail";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.InterestCalculationTable.EnterCharges(1, buyerCharge: 2.00);
                //FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("2.00");
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(HomeOwnersInsurance, buyerCharge: 44.00, sellerCharge: 33.00);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);

                // test case REG00010B.
                Reports.TestStep = "Verify QC @ Closing tab is enabled.";
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case REG00010C.
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");
                
                // Test case REG00010D
                Reports.TestStep = "Click Loan Charges tab";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Select a Charges for disbursement.";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);

                Reports.TestStep = "Verify the total check amount after selecting charges.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Midwest Financial Group",1, TableAction.Click);
                Support.AreEqual("5.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check amount");

                Reports.TestStep = "Verify that check Amount is read only,user cant modify.";
                Support.AreEqual("False", FastDriver.NewLoanDisbursements.CheckAmount.Enabled.ToString(), "Check Amount field is Enabled");

                Reports.TestStep = "Validate the lender Name.";
                Support.AreEqual("Midwest Financial Group", FastDriver.NewLoanDisbursements.PayeeName.Text, "Name");

                Reports.TestStep = "Validate the Address of Payee.";
                Support.AreEqual("500 Cascade West Parkway", FastDriver.NewLoanDisbursements.PayeeAddress.Text, "Address");

                Reports.TestStep = "Validate the Business Phone,business Fax and Email.";
                Support.AreEqual("(847)382-8844", FastDriver.NewLoanDisbursements.BusinessPhone.FAGetValue(), "Business Phone");
                Support.AreEqual("(847)382-8844", FastDriver.NewLoanDisbursements.BuinesssFax.FAGetValue(), "Business Fax");
                Support.AreEqual("True", FastDriver.NewLoanDisbursements.EmailAddress.FAGetValue().Contains("@aol.com").ToString(), "Email Address contains '@aol.com'");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0011()
        {
            try
            {
                Reports.TestDescription = "ES14685_FM4282 : Create Multiple Disbursements to Lender";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                FastDriver.NewLoan.InterestCalculationTable.EnterCharges(1, buyerCharge: 2.00);
                FastDriver.NewLoan.OriginationChargesTable.EnterCharges(ApplicationFee, buyerCharge: 3.00);
                FastDriver.NewLoan.NewLoanChargesTable.EnterCharges(AppraisalFee, buyerCharge: 4.00, sellerCharge: 5.00);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.EnterCharges(HomeOwnersInsurance, buyerCharge: 44.00, sellerCharge: 33.00);
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, buyerCharge: 1.00, sellerCharge: 1.00);
                else
                {
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, sellerCharge: 1.00);
                    FastDriver.NewLoan.NewLoanChargesTable.EnterCharges("Escrow Waiver Fee", newDescription: "4.00");
                }

                // test case REG00011B.
                Reports.TestStep = "Verify QC @ Closing tab is enabled.";
                Support.AreEqual("True", FastDriver.NewLoan.QCClosingTab.Enabled.ToString(), "QC @ Closing is enabled");

                // test case REG00011C.
                Reports.TestStep = "Enter QC Closing GAB code and verify QC @ Closing tab.";
                FastDriver.NewLoan.ClickQCClosingTab();
                FastDriver.NewLoan.TransactionType.FASelectItem("Refinance");

                // Test case REG00011D
                Reports.TestStep = "Click Loan Charges tab";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                
                Reports.TestStep = "Select a Charges for disbursement.";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, ApplicationFee, 1, TableAction.On);

                Reports.TestStep = "Verify the total check amount after selecting charges.";
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(1, "Midwest Financial Group", 1, TableAction.Click);
                Support.AreEqual("5.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check amount");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Click on New and add the duplicate payee.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.FindGABCode("248");
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, AppraisalFee, 1, TableAction.On);

                Reports.TestStep = "Select a Charges for disbursement for duplicate payee.";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, HomeOwnersInsurance, 1, TableAction.On);

                Reports.TestStep = "Verify the payee.";
                // why verify using row count??  should we count number of times the payee appear
                Support.AreEqual("3", FastDriver.NewLoanDisbursements.PayeeSummaryTable.GetRowCount().ToString(), "Row count of Disbursement Charge Table");
                Support.AreEqual("86.00", FastDriver.NewLoanDisbursements.CheckAmount.FAGetValue(), "Check amount");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen";
                FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                Reports.TestStep = "Validate the status and payee names of duplicate.";
                var status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Midwest Financial Group", "Status", TableAction.GetText).Message;
                Support.AreEqual("Pending", status, "Disburment status for Midwest Financial Group");
                var amount = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Payee", "Midwest Financial Group", "Amount", TableAction.GetText).Message.Trim();
                Support.AreEqual("86.00", amount, "Disburment amount for Midwest Financial Group");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        
        [TestMethod]
        public void FMUC0085_REG0012()
        {
            try
            {
                Reports.TestDescription = "FM4250_FM4251_FM6264: Change Payment Method to CHK for Selected Charges, " +
                                          "Display Payee Name for Selected Charge  and Remove FEE Payment Method Selection";
                
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a new file.";
                var req = RequestFactory.GetCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("249");
                req.File.TransactionTypeObjectCD = "REFI";
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan screen and charges tab";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter charges";
                if (AutoConfig.FormType == "HUD")
                    FastDriver.NewLoan.PrincipalBalanceChargesTable.EnterCharges(1, borrowerCharge: 1000);
                
                FastDriver.NewLoan.InterestCalculationTable.EnterCharges(1, borrowerCharge: 100);
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();

                Reports.TestStep = "Change Payment Method";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                if (AutoConfig.FormType == "HUD")
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem("RBL");
                //else
                    //FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItem("RBL");  // already selected
                
                Reports.TestStep = "Verify the FEE Payment Method Selection is not available in PaymentDetails Dlg";
                if (AutoConfig.FormType == "HUD")
                    Support.AreNotEqual("True", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.Text.Contains("FEE").ToString(), "FEE is not availe in dropdown");
                else
                    Support.AreNotEqual("True", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Text.Contains("FEE").ToString(), "FEE is not availe in dropdown");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click Done";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Click Loan Charge tab";
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Click on Pay Charges.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();

                Reports.TestStep = "Select a Charge for disbursement.";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, PrepaidInterest, 1, TableAction.On);

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify the Payment method has changed to CHK and Pay to name has changed";
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                if (AutoConfig.FormType == "HUD")
                    Support.AreEqual("CHK", FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FAGetSelectedItem().ToString(), "Buyer payment method");
                else
                    Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString(), "Buyer payment method");
                Support.AreEqual("Lenders Advantage", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue(), "Pay to");

                Reports.TestStep = "Click on Done in Dialog Box.";
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click Done";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0085_REG0013()
        {
            try
            {
                //UAT 10.6
                //INC2933058_830337
                //INC2936636_752434

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Error when trying to access Loan Charges tab for 2nd New Loan / ALTA SS printing unnecessary 2nd page.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                // FastDriver.SecuritySelectRegionOffice.Open().EnterBUID(AutoConfig.SelectedRegionBUID);

                //
                Reports.TestStep = "Create File using web service.";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //Covers 10.6 UAT Fixes for Work Item 830337
                //
                Reports.TestStep = "Navigate to Escro Closing settlement statement";
                FastDriver.LeftNavigation.Navigate<PrintEscrowSetlleStmt>("Home>Order Entry>Escrow Closing>Settlement Statement").WaitForScreenToLoad();
                FastDriver.PrintEscrowSetlleStmt.Delivery("Imagedoc");
                FastDriver.ImageDocDlg.Deliver();
                DateTime dt = DateTime.Now;
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PrintEscrowSetlleStmt.WaitForScreenToLoad();

                //
                Reports.TestStep = "Navigate to Escro Closing settlement statement";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Escrow Closing>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);

                string savePath = @"C:\Reports\" + DateTime.Today.ToString("MMMddyyyy");
                Playback.Wait(20000);
                IOHelper.CreateDirectory(savePath);
                string tempPdfFile = PDFHelper.SavePDFFile("UAT");
                Reports.StatusUpdate("The file has already been saved....", true);
                Playback.Wait(1000);
                string pdfContent = Support.ReadPdfFile(tempPdfFile);
                Support.AreEqual("True", pdfContent.Contains(dt.ToString("h:mm tt")).ToString());
                Reports.StatusUpdate("The time of the first PDF generated is:  " + dt.ToString("h:mm tt"), true);

                //
                Reports.TestStep = "Repeat steps to test if the hour has changed";
                FastDriver.LeftNavigation.Navigate<PrintEscrowSetlleStmt>("Home>Order Entry>Escrow Closing>Settlement Statement").WaitForScreenToLoad();
                FastDriver.PrintEscrowSetlleStmt.Delivery("Imagedoc");
                FastDriver.ImageDocDlg.Deliver();
                DateTime dt2 = DateTime.Now;
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PrintEscrowSetlleStmt.WaitForScreenToLoad();

                //
                Reports.TestStep = "Navigate to Escrow Closing settlement statement";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Escrow Closing>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                Playback.Wait(10000);
                IOHelper.CreateDirectory(savePath);
                string tempPdfFile2 =  PDFHelper.SavePDFFile("UAT2");
                Reports.StatusUpdate("The file has already been saved....", true);
                pdfContent = Support.ReadPdfFile(tempPdfFile2);
                Support.AreEqual("True", pdfContent.Contains(dt2.ToString("h:mm tt")).ToString());
                Reports.StatusUpdate("The time of the Second PDF generated is:  " + dt2.ToString("h:mm tt"), true);
                
                //Covers 10.6 UAT Fixes for Work Item 752434
                Reports.TestStep = "TFS#752434: ALTA SS still printing unnecessary 2nd page";
                Support.AreEqual("True", (PDFHelper.GetPdfPageCount(tempPdfFile2) < 2).ToString(), "Page count < 2");
                Reports.StatusUpdate("The total pages count is :..." + PDFHelper.GetPdfPageCount(tempPdfFile2), true);

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

        [TestInitialize]
        public override void TestInitialize()
        {
            base.TestInitialize();
            if (AutoConfig.FormType == "HUD")
            {
                ApplicationFee = "Our origination charge";
                HomeOwnersInsurance = "Homeowner's insurance";
                AppraisalFee = "Appraisal fee";
                PrepaidInterest = "Interest on new loan";
            }
        }

    }
}