﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;


namespace EscrowChargeProcess
{

    [CodedUITest]
    public class FMUC0042_HomeWarranty : MasterTestClass
    {
        public FMUC0042_HomeWarranty()
        {
        }

        #region BAT
        [TestMethod]
        public void FMUC0042_BAT0001()
        {
            try
            {
                Reports.TestDescription = "AF3_00: Cancel 1st New Home Warranty Instance Creation.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Cancel 1st New Home Warranty Instance Creation.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomePage.WaitForHomeScreen();

                if (FastDriver.HomePage.SplashImage.Displayed)
                {
                    Reports.StatusUpdate("Navigated back to the Welcome Page successfully.", true);
                }

                else
                    Reports.StatusUpdate("Unable to navigate to the Welcome Page.", false);

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_01: Add a New Home Warranty Instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate the charge and Listing/Selling Real Estate Broker commission check amount in File balance summary screen before adding homewarranty charges.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,000.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().Clean());
                //Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.ListingBrokerFundsDue.Text.Clean());
                //Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.SellingBrokerFundsDue.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Create New Home Warranty Instance Creation.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("Home Warranty", FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG1_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("300.00", FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FAGetValue());
                Support.AreEqual("275.00", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());
                Support.AreEqual("562.00", FastDriver.HomeWarrantyDetail.Amount.FAGetValue());
                Support.AreEqual("Home Warranty - Early Coverage", FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG2_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("699.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                Support.AreEqual("845.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the charge and Listing/Selling Real Estate Broker commission check amount in File balance summary screen after adding homewarranty charges.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,999.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().Clean());
                //Support.AreEqual("250.00", FastDriver.EscrowFileBalanceSummary.ListingBrokerFundsDue.Text.Clean());
                //Support.AreEqual("300.00", FastDriver.EscrowFileBalanceSummary.SellingBrokerFundsDue.Text.Clean());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF4_00: Cancel 2nd New Home Warranty Instance Creation.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create New Home Warranty Instance Creation.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);

                Reports.TestStep = "Cancel 2nd New Home Warranty Instance Creation.";
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Cancel();

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("Home Warranty", FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG1_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("300.00", FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FAGetValue());
                Support.AreEqual("275.00", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());
                Support.AreEqual("562.00", FastDriver.HomeWarrantyDetail.Amount.FAGetValue());
                Support.AreEqual("Home Warranty - Early Coverage", FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG2_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("699.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                Support.AreEqual("845.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_BAT0004()
        {
            try
            {
                Reports.TestDescription = "MF1_02: Add a Subsequent Home Warranty Instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create New Home Warranty Instance Creation.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);

                Reports.TestStep = "Validate the charge and Listing/Selling Real Estate Broker commission check amount in File balance summary screen before adding homewarranty charges.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,999.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().Clean());
                //Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.ListingBrokerFundsDue.Text.Clean());
                //Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.SellingBrokerFundsDue.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add a Home Warranty Instance/Subsequent new instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                Reports.TestStep = "Click New.";
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Add a Home Warranty Instance/Subsequent new instance.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate New Home Warranty Instance.";
                FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.HomeWarrantySummary.Edit.FAClick();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("Home Warranty", FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG1_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("200.00", FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FAGetValue());
                Support.AreEqual("250.00", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());
                Support.AreEqual("100.00", FastDriver.HomeWarrantyDetail.Amount.FAGetValue());
                Support.AreEqual("Home Warranty - Early Coverage", FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG2_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("100.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                Support.AreEqual("50.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the charge and Listing/Selling Real Estate Broker commission check amount in File balance summary screen before adding homewarranty charges.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("6,299.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF5_00: Cancel 3rd Instance. Subsequent new instance from summary.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating 2 Home Warranty Instances";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.New();

                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);

                Reports.TestStep = "Cancel 3rd New Home Warranty Instance Creation.";
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate New button.";
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();
                FastDriver.HomeWarrantySummary.New.Exists();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF1_00: Edit Home Warranty Information.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating 2 Home Warranty Instances";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.New();

                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Home Warranty Information.";
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();
                FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.HomeWarrantySummary.Edit.FAClick();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", sellerCharge: 300.00);
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-02-2012");
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("07-16-2012");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 200.00, sellerCharge: 300.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify new Saved Home Warranty Information.";
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();
                FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.HomeWarrantySummary.Edit.FAClick();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("300.00", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());
                Support.AreEqual("07-02-2012", FastDriver.HomeWarrantyDetail.FromDate.FAGetValue());
                Support.AreEqual("07-16-2012", FastDriver.HomeWarrantyDetail.ToDate.FAGetValue());
                Support.AreEqual("Home Warranty - Early Coverage", FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG2_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("200.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                Support.AreEqual("300.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF6_00: Cancel Changes to Exisisting Home Warranty Instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating 3 Home Warranty Instances";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 300.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-02-2012");
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("07-16-2012");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 200.00, sellerCharge: 300.00);
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancel Changes to Existing Home Warranty Instance.";
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();
                FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.HomeWarrantySummary.Edit.FAClick();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 123.00);
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();

                Reports.TestStep = "Edit Home Warranty Information.";
                FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.HomeWarrantySummary.Edit.FAClick();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("300.00", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());
                Support.AreEqual("07-02-2012", FastDriver.HomeWarrantyDetail.FromDate.FAGetValue());
                Support.AreEqual("07-16-2012", FastDriver.HomeWarrantyDetail.ToDate.FAGetValue());
                Support.AreEqual("Home Warranty - Early Coverage", FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG2_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("200.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                Support.AreEqual("300.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF2_00: Delete Home Warranty Information.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating 3 Home Warranty Instances";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 300.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-02-2012");
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("07-16-2012");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 200.00, sellerCharge: 300.00);
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the charge and Listing/Selling Real Estate Broker commission check amount in File balance summary screen before adding homewarranty charges.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("6,100.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete Home Warranty Information.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantySummary>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.HomeWarrantySummary.Edit.FAClick();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();

                Reports.TestStep = "Validate Available after Deletion in Summary screen.";
                Support.AreEqual("Available", FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(4, 2, TableAction.GetText).Message.Clean());

                Reports.TestStep = "Validate the charge and Listing/Selling Real Estate Broker commission check amount in File balance summary screen before adding homewarranty charges.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,800.00", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().Clean());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        #endregion

        #region REGRESSION

        [TestMethod]
        public void FMUC0042_REG0001()
        {
            try
            {
                Reports.TestDescription = "FD_Set1: Validate Home Warranty Detail field definition for lower boundary value.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate Home Warranty Detail fields with lower boundary.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.EditNameChk.FASetCheckbox(true);
                FastDriver.HomeWarrantyDetail.EditName.FASetText("abcdefghijklmnopqrstuvwxyzabcd123456789");
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcd123456789", FastDriver.HomeWarrantyDetail.EditName.FAGetValue());
                FastDriver.HomeWarrantyDetail.EditCont.FASetCheckbox(true);
                FastDriver.HomeWarrantyDetail.BusPhone.FASetText("616451229");
                FastDriver.HomeWarrantyDetail.BusFax.FASetText("616451229");
                //FastDriver.HomeWarrantyDetail.PolicyCharge.Click();
                Support.AreEqual("Field is invalid", FastDriver.HomeWarrantyDetail.BusPhone.GetAttribute("title"));
                Support.AreEqual("Field is invalid", FastDriver.HomeWarrantyDetail.BusPhone.GetAttribute("title"));
                //FastDriver.HomeWarrantyDetail.PolicyCharge.FASetText("123567890.12");
                //Support.AreEqual("123567890.12", FastDriver.HomeWarrantyDetail.PolicyCharge.FAGetValue());
                FastDriver.HomeWarrantyDetail.Amount.FASetText("123567890.12");
                Support.AreEqual("123567890.12", FastDriver.HomeWarrantyDetail.Amount.FAGetValue());
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-02-2012");
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("07-16-2012");
                Support.AreEqual("07-02-2012", FastDriver.HomeWarrantyDetail.FromDate.FAGetValue());
                Support.AreEqual("07-16-2012", FastDriver.HomeWarrantyDetail.ToDate.FAGetValue());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 20);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0002()
        {
            try
            {
                Reports.TestDescription = "FD_Set2: Validate Home Warranty Detail field definition for exact value.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate Home Warranty Detail fields with lower boundary.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.EditNameChk.FASetCheckbox(true);
                FastDriver.HomeWarrantyDetail.EditName.FASetText("abcdefghijklmnopqrstuvwxyzabcd123456789");
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcd123456789", FastDriver.HomeWarrantyDetail.EditName.FAGetValue());
                FastDriver.HomeWarrantyDetail.EditCont.FASetCheckbox(true);
                FastDriver.HomeWarrantyDetail.BusPhone.FASetText("6164512290");
                FastDriver.HomeWarrantyDetail.BusFax.FASetText("6164512290");
                ////FastDriver.HomeWarrantyDetail.PolicyCharge.Click();
                Support.AreEqual("(616)451-2290", FastDriver.HomeWarrantyDetail.BusPhone.FAGetValue());
                Support.AreEqual("(616)451-2290", FastDriver.HomeWarrantyDetail.BusPhone.FAGetValue());
                FastDriver.HomeWarrantyDetail.PolicyCharge.FASetText("1235678901.12" + FAKeys.Tab);
                //FastDriver.HomeWarrantyDetail.BuyerBroker.Click();
                Support.AreEqual("1,235,678,901.12", FastDriver.HomeWarrantyDetail.PolicyCharge.FAGetValue());
                FastDriver.HomeWarrantyDetail.Amount.FASetText("1235678901.12");
                Support.AreEqual("1235678901.12", FastDriver.HomeWarrantyDetail.Amount.FAGetValue());
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-02-2012");
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("07-16-2012");
                Support.AreEqual("07-02-2012", FastDriver.HomeWarrantyDetail.FromDate.FAGetValue());
                Support.AreEqual("07-16-2012", FastDriver.HomeWarrantyDetail.ToDate.FAGetValue());
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 12345678901.12, sellerCharge: 12345678901.12);
                Support.AreEqual("Home Warranty - Early Coverage", FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG2_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("12,345,678,901.12", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                Support.AreEqual("12,345,678,901.12", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0003()
        {
            try
            {
                Reports.TestDescription = "FD_Set3: Validate Home Warranty Detail field definition for upper boundary.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate Home Warranty Detail fields with upper boundary value.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.EditNameChk.FASetCheckbox(true);
                FastDriver.HomeWarrantyDetail.EditName.FASetText("abcdefghijklmnopqrstuvwxyzabcd123456789");
                Support.AreEqual("abcdefghijklmnopqrstuvwxyzabcd123456789", FastDriver.HomeWarrantyDetail.EditName.FAGetValue());
                FastDriver.HomeWarrantyDetail.EditCont.FASetCheckbox(true);
                FastDriver.HomeWarrantyDetail.BusPhone.FASetText("61645122901");
                FastDriver.HomeWarrantyDetail.BusFax.FASetText("61645122901");
                ////FastDriver.HomeWarrantyDetail.PolicyCharge.Click();
                Support.AreEqual("(616)451-2290", FastDriver.HomeWarrantyDetail.BusPhone.FAGetValue());
                Support.AreEqual("(616)451-2290", FastDriver.HomeWarrantyDetail.BusPhone.FAGetValue());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0004()
        {
            try
            {
                Reports.TestDescription = "FD_Set4: Validate Home Warranty Detail EarlyCoverageCharge fields with lower boundary value.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate Home Warranty Detail fields with lower boundary.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 1234567890.12, sellerCharge: 1234567890.12);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0005()
        {
            try
            {
                Reports.TestDescription = "FD_Set5: Validate Home Warranty Detail EarlyCoverageCharge fields with upper boundary value.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate Home Warranty Detail EarlyCoverageCharge fields with upper boundary value.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.Click();
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 123456789012.12);
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.GetAttribute("title"));
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0006()
        {
            try
            {
                Reports.TestDescription = "FD_Set6: Validate Home Warranty Detail EarlyCoverageSellerCharge field with lower boundary value.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate Home Warranty Detail EarlyCoverageSellerCharge field with lower boundary value.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.Click();
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 1234567890.12);
                Support.AreEqual("1,234,567,890.12", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0007()
        {
            try
            {
                Reports.TestDescription = "FD_Set7: Validate Home Warranty Detail EarlyCoverageSellerCharge field with upper boundary value.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate Home Warranty Detail EarlyCoverageSellerCharge field with upper boundary value.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.EarlyCoverageChargeDescription.Click();
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", sellerCharge: 123456789012.12);
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.GetAttribute("title"));
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0008()
        {
            try
            {
                Reports.TestDescription = "FD_Set8: Validate Home Warranty Detail PolicyCharge field with upper boundary value.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate Home Warranty Detail EarlyCoverageSellerCharge field with upper boundary value.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.PolicyCharge.FASetText("123456789012.12" + FAKeys.Tab);
                //FastDriver.HomeWarrantyDetail.BuyerBroker.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.HomeWarrantyDetail.PolicyCharge.GetAttribute("title"));
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0009()
        {
            try
            {
                Reports.TestDescription = "FD_Set9: Validate Home Warranty Detail Buyer Broker field with upper boundary value.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0010()
        {
            try
            {
                Reports.TestDescription = "FD_Set10: Validate Home Warranty Detail Amount field with upper boundary value.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate Home Warranty Detail Amount field with upper boundary value.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.Amount.FASetText("123456789012.12" + FAKeys.Tab);
                //FastDriver.HomeWarrantyDetail.BuyerBroker.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("Value cannot be greater than 99,999,999,999.99", FastDriver.HomeWarrantyDetail.Amount.GetAttribute("title"));
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0011()
        {
            try
            {
                Reports.TestDescription = "FD_HK1: Add/Create data in the new instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add another Home Warranty Instance Subsequent new instance from summary.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        [TestMethod]
        public void FMUC0042_REG0012()
        {
            try
            {
                Reports.TestDescription = "EWC13_FM1485_FM1487: There is an amount in Seller/Buyer Charge Not to Exceed field, and total of Buyer Charge and Seller Charge amounts exceed this limit.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate the warning message when Policy Charge Not to Exceed Amount is changed.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.PolicyCharge.FASetText("100.00" +FAKeys.Tab);
                ////FastDriver.HomeWarrantyDetail.BuyerBroker.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 0.00, sellerCharge: 0.00);
                FastDriver.HomeWarrantyDetail.PolicyCharge.FASetText("150.00" + FAKeys.Tab);
                //FastDriver.HomeWarrantyDetail.BuyerBroker.Click();
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 170.00);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Validate that the buyer charge is defaulted to zero upon clicking cancel button in the warning message.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FAGetValue());

                Reports.TestStep = "Validate the warning message when Seller Charge Amount is changed.";
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 100.00, sellerCharge: 170.00);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Validate that the seller charge is defaulted to zero upon clicking cancel button in the warning message.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());

                Reports.TestStep = "Validate the warning message when sum  of buyer and seller charge amount exceeds 'Policy charge not to exceed' amount.";
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("80.00");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("80.00" + FAKeys.Tab);
                //FastDriver.HomeWarrantyDetail.BuyerBroker.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);

                Reports.TestStep = "Validate that the buyer and seller charge is not defaulted to zero upon clicking OK button in the warning message.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("80.00", FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FAGetValue());
                Support.AreEqual("80.00", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());

                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0013()
        {
            try
            {
                Reports.TestDescription = "FD_HK2: Opens the highlighted Home Warranty instance and edits Home Warranty Detail.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add another Home Warranty Instance Subsequent new instance from summary.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("");
                //FastDriver.HomeWarrantyDetail.BuyerBroker.Click();

                Reports.TestStep = "Validate the information: Unable to delete charge description. Charge description still has a charge amount.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Reset();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0014()
        {
            try
            {
                Reports.TestDescription = "FD_HK3_FM2459: Deletes the highlighted Home Warranty instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create 2 Home Warranty instances";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete Home Warranty Information.";
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();
                FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(3, 2, TableAction.Click);
                Keyboard.SendKeys("%R");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();
                FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.HomeWarrantySummary.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate Available after Deletion in Summary screen.";
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();
                Support.AreEqual("Available", FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0015()
        {
            try
            {
                Reports.TestDescription = "FD_HK4: Cancels a new unsaved instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Cancels a new unsaved instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-03-2012");
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-17-2012");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("#");
                FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FASetText("#");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0015A()
        {
            try
            {
                Reports.TestDescription = "FD_HK5:Verify attention field.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.HomeWarrantyDetail.Attention.FASelectItem("L247");
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();
                Support.AreEqual("L247", FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(3, 3, TableAction.GetText).Message.Clean());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0016()
        {
            try
            {
                Reports.TestDescription = "EWC1_FM2459: User deletes a charge process instance that has issued checks.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disburse the survey.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Support.value = Support.RandomString("NNNNNNNN");
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.value);
                Support.AreEqual(Support.value, FastDriver.IssueManualCheck.CheckNo.FAGetValue());
                FastDriver.BottomFrame.Save();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                //FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason, 10);
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Issuing Manual Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete a payee in Home warranty instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0017()
        {
            try
            {
                Reports.TestDescription = "EWC8: The business party is a payee on an issued check and user tries to edit or replace it with another business party.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disburse the survey.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                FastDriver.BottomFrame.Save();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                //FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason, 10);
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Issuing Manual Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete a payee in Home warranty instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0018()
        {
            try
            {
                Reports.TestDescription = "EWC2: User deletes a charge process instance that does not have issued checks.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Delete the Home warranty instance.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0019()
        {
            try
            {
                Reports.TestDescription = "EWC7: User searches for a business party on ID Code and system does not find an exact match.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "User searches for a business party on ID Code and system does not find an exact match.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("xyz");
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0020()
        {
            try
            {
                Reports.TestDescription = "EWC9: User cancels entry of the FIRST new instance us Cancel button on framework before save a new process instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Cancel 1st New Home Warranty Instance Creation.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomePage.WaitForHomeScreen();

                if (FastDriver.HomePage.SplashImage.Displayed)
                {
                    Reports.StatusUpdate("Navigated back to the Welcome Page successfully.", true);
                }

                else
                    Reports.StatusUpdate("Unable to navigate to the Welcome Page.", false);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0021()
        {
            try
            {
                Reports.TestDescription = "EWC10: User cancels entry of the SECOND or SUBSEQUENT new instance us Cancel button on framework before save a new process instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 123.00, sellerCharge: 123.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("123.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 123.00, sellerCharge: 123.00, newDescription: "1st Home Warranty - Early Coverage");
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("Home Warranty", FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG1_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.Amount.FAGetValue());
                Support.AreEqual("1st Home Warranty - Early Coverage", FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG2_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0022()
        {
            try
            {
                Reports.TestDescription = "EWC11: User cancels entry of the THIRD or SUBSEQUENT new instance us Cancel button on framework before save a new process instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 123.00, sellerCharge: 123.00, newDescription: "1st Home Warranty");
                FastDriver.HomeWarrantyDetail.Amount.FASetText("123.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 123.00, sellerCharge: 123.00, newDescription: "1st Home Warranty - Early Coverage");
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 555.00, sellerCharge: 555.00, newDescription: "2nd Home Warranty");
                FastDriver.HomeWarrantyDetail.Amount.FASetText("555.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 555.00, sellerCharge: 555.00, newDescription: "2nd Home Warranty - Early Coverage");
                FastDriver.BottomFrame.New();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 200.00, sellerCharge: 250.00, newDescription: "3rd Home Warranty");
                FastDriver.HomeWarrantyDetail.Amount.FASetText("100.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 100.00, sellerCharge: 50.00, newDescription: "3rd Home Warranty - Early Coverage");
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantySummary.WaitForScreenToLoad();
                FastDriver.HomeWarrantySummary.SummaryTable.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.HomeWarrantySummary.Edit.FAClick();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("2nd Home Warranty", FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG1_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("555.00", FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FAGetValue());
                Support.AreEqual("555.00", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());
                Support.AreEqual("555.00", FastDriver.HomeWarrantyDetail.Amount.FAGetValue());
                Support.AreEqual("2nd Home Warranty - Early Coverage", FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG2_dcs_0_tdsc").FAGetValue());

                Support.AreEqual("555.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                Support.AreEqual("555.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0023()
        {
            try
            {
                Reports.TestDescription = "EWC12: User cancels entry us Reset button on framework before save changes to an EXIST process instance.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 123.00, sellerCharge: 123.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("123.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 123.00, sellerCharge: 123.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Cancel Changes to Existing Home Warranty Instance.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 11.00, sellerCharge: 11.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("11.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 11.00, sellerCharge: 11.00);
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validate that the new values are not set after reset and the old values are retained.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("Home Warranty", FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG1_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.Amount.FAGetValue());
                Support.AreEqual("Home Warranty - Early Coverage", FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "CG2_dcs_0_tdsc").FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.FAGetValue());
                Support.AreEqual("123.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0024()
        {
            try
            {
                Reports.TestDescription = "EWC15_FM1486: User tries to save a charge process instance without the minimum required data. (For Home Warranty, this is Home Warranty Company name.).";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 123.00, sellerCharge: 123.00);
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-02-2012");
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-16-2012");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 123.00, sellerCharge: 123.00);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0025()
        {
            try
            {
                Reports.TestDescription = "EWC16_FM1483_EWC17: User decreases or deletes and increases Paid by Seller’s Broker amount or Paid by Buyer’s Broker amount after the broker’s net commission check is issued.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Commission Amount for Home Warranty.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247", false);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("600.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disburse the survey.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, 3, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                FastDriver.BottomFrame.Save();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                //FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason, 10);
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Issuing Manual Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disb Summary and select the Pend charge and click on Manual.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                FastDriver.BottomFrame.Save();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                //FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason, 10);
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Issuing Manual Check");
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Decrease/Delete Paid by RE Bkr.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("550.00");
                FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Click();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0026()
        {
            try
            {
                Reports.TestDescription = "EWC3: User tries to delete a charge description that has a charge amount.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", buyerCharge: 300.00, sellerCharge: 275.00);
                FastDriver.HomeWarrantyDetail.Amount.FASetText("562.00");
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", buyerCharge: 699.00, sellerCharge: 845.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "User tries to delete a charge description that has a charge amount.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", newDescription: " ");
                //FastDriver.HomeWarrantyDetail.paidSeller.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Reset();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0027()
        {
            try
            {
                Reports.TestDescription = "EWC18: When user checks the Edit Name Check Box and user tries to save the split fee information without specify the Name.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "When user checks the Edit Name Check Box and user tries to save the split fee information without specifying the Name.";
                Reports.TestStep = "Add a Home Warranty Instance/New instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.EditNameChk.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.EditNameChk.FASetCheckbox(false);
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0028()
        {
            try
            {
                Reports.TestDescription = "EWC19: When the user enters an invalid e-Mail address.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "When the user enters an invalid e-Mail address.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.EditCont.FASetCheckbox(true);
                FastDriver.HomeWarrantyDetail.EmailAddress.FASetText("hfhskhkshdkhsh" +FAKeys.Tab);
               // //FastDriver.HomeWarrantyDetail.paidSeller.Click();
                Support.AreEqual("Email address is invalid. Valid Examples: xyz@abc.com xyz@abc.com.uk xyz_123@abc.com xyz-12.wuv@abc.cnn.edu.uk", FastDriver.HomeWarrantyDetail.EmailAddress.FAGetAttribute("title").Clean());

                Reports.TestStep = "Click on done without correcting the invalid email id and validate the error messgae.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Cancel without save changes.";
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0029()
        {
            try
            {
                Reports.TestDescription = "EWC20: User tries to change a Business Party which has a Reference number specified against it.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "User tries to change a Business Party which has a Reference number specified against it.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.Reference.FASetText("1234");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "User tries to change a Business Party which has a Reference number specified against it.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.BottomFrame.Delete();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0030()
        {
            try
            {
                Reports.TestDescription = "FM1484: Reduce RE Broker Commission.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0031()
        {
            try
            {
                Reports.TestDescription = "FM4180_FM1488_FM4181: Add Paid by Broker Amts to Check Amount.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Paid by buyer & Paid by seller(Listings) Broker amt.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0032()
        {
            try
            {
                Reports.TestDescription = "FM2882_FM2883_EWC5_EWC6: Decrease/Delete Paid by RE Broker/Increase Amount Paid by RE Broker.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Commission Amount for Home Warranty.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247", false);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("600.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Disburse the survey.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(2, 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();

                Reports.TestStep = "Issue Manual Check.";
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));
                FastDriver.BottomFrame.Save();
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
                //FastDriver.ManualCheckReceiptReason.WaitCreation(FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason, 10);
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("Issuing Manual Check");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, timeoutSeconds: 30);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "User tries to decrease a charge amount with payment method of CHK after the payee check is issued.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(1, 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("550.00");
                FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Delete Paid by RE Bkr.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("0.00");
                FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Increase Amount Paid by RE Bkr.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("700.00");
                FastDriver.RealEstateBrokerAgent.CreditSellerEarnestMoneyinexcesscheckbox.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0033()
        {
            try
            {
                Reports.TestDescription = "FM1482_FM2432_FM2433_FM1491_FM2627_FM4364: Calculate Early Coverage Charges.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Calculate Early Coverage Charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("123");
                FastDriver.HomeWarrantyDetail.Amount.FASetText("10000.00");
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-25-2012");
                FastDriver.HomeWarrantyDetail.InclusiveFrom.FASetCheckbox(true);
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("08-05-2012" + FAKeys.Tab);
                //FastDriver.HomeWarrantyDetail.paidSeller.Click();

                Support.AreEqual("100,000.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());

            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0034()
        {
            try
            {
                Reports.TestDescription = "FM1983_FM1986_FM1982_FM1981_EWC14: Recalculate Early Coverage Chg/Edit Early Coverage Charge.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Calculate Early Coverage Charges.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("123");
                FastDriver.HomeWarrantyDetail.Amount.FASetText("10000.00" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-25-2012" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.InclusiveFrom.FASetCheckbox(true);
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("08-05-2012"+ FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "After initial Early Coverage charge calculation, user changes Early Coverage formula values.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.Amount.Click();
                FastDriver.HomeWarrantyDetail.Amount.FASetText("400.00", false);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("4,000.00", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue());

                Reports.TestStep = "Edit dates for Early Coverage Formula.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("08-01-2012");
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("08-07-2012");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                string value = FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue();
                Support.AreEqual("True", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue().Contains(value).ToString(), "Verifying amount stays the same.");
                
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FMUC0042_REG0035()
        {
            try
            {
                Reports.TestDescription = "FM1984_FM1987: Do Not Recalculate after initial Early Coverage charge calculation, user changes Early Coverage formula values/Retain Formula Values.";
                Login(AutoConfig.FASTHomeURL);

                Reports.TestStep = "Create a file";
                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a home warranty instance.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>("Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.FindGABCode("248");
                FastDriver.HomeWarrantyDetail.Amount.FASetText("200.00" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.FromDate.FASetText("07-02-2012" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.ToDate.FASetText("08-03-2012" + FAKeys.Tab);
                System.Threading.Thread.Sleep(500);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate the message for Recalculation of Early coverage charges and click on cancel button.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.Amount.Click();
                FastDriver.HomeWarrantyDetail.Amount.FASetText("500.00", false);
                FastDriver.HomeWarrantyDetail.EarlyCoverageBuyerCharge.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                string value = FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Validate the charges when Recalculate is not choosen.";
                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                Support.AreEqual("500.00", FastDriver.HomeWarrantyDetail.Amount.FAGetValue());
                Support.AreEqual("True", FastDriver.HomeWarrantyDetail.EarlyCoverageSellerCharge.FAGetValue().Contains(value).ToString(), "Verifying amount stays the same.");
                //
                Reports.TestStep = @"US596132 Validate that Paid By Buyrs/sellers broker field are NOT present for CD file.";
                if(AutoConfig.FormType=="CD")
                {
                    Support.AreEqual("False", FastDriver.HomeWarrantyDetail.PaidBuyer.IsDisplayed().ToString());
                    Support.AreEqual("False", FastDriver.HomeWarrantyDetail.paidSeller.IsDisplayed().ToString());
                }
                else
                {
                    Support.AreEqual("True", FastDriver.HomeWarrantyDetail.PaidBuyer.IsDisplayed().ToString());
                    Support.AreEqual("True", FastDriver.HomeWarrantyDetail.paidSeller.IsDisplayed().ToString());
                }
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
        }
        #endregion

        #region Useful methods

        private void Login(string Key)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(Key, credentials, true);
        }

        private static int CreateFile()
        {
            var customFile = RequestFactory.GetCreateFileDefaultRequest();
            customFile.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.SellersAttorney;
            customFile.File.BusinessParties[0].CustomerReferenceNumber = "1234567890";
            customFile.File.SalesPriceAmount = (decimal)5000.00;
            
            try
            {
                int? FileID = FileService.CreateFile(customFile).FileID;
                return (int)FileID;
            }
            catch (Exception)
            {

                throw new Exception("Unable to retrieve FileID.");
            }
        }

        #endregion


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
