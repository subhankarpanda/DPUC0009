﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using SeleniumInternalHelpers;
using System.Runtime.Serialization;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Collections.Generic;
using System.Windows.Input;
using FASTWCFHelpers.Factories;
using System.Threading;

namespace EscrowChargeProcess
{
    [CodedUITest]
    public class FMUC0048_PayoffLoan : MasterTestClass
    {
        public FMUC0048_PayoffLoan()
        {
        }

        #region BAT
        [TestMethod]
        public void FMUC0048_BAT0001() 
        {
            try
            {
                Reports.TestDescription = "MF_001: To create first instance of payoff loan.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },
                    
                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Enter charges to Payoff loan
                Reports.TestStep = "Enter charges to Payoff loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys("");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Click();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Interest in Addition");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"07-02-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FASelectItemBySendingKeys(@"360");
                SelectInterestCalculationPercentRate();
                FastDriver.PayoffLoanCharges.InterestCalculationProrPercentRateval.FASetText(@"20");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"07-26-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.SendKeys("");
                FastDriver.BottomFrame.Done();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                SelectInterestCalculationInclusiveTo();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText(@"Principal Balance-payoff");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("300");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText("200");                
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                #endregion
                #region Enter second instance of interest calculation
                Reports.TestStep = "Enter second instance of interest calculation";
                FastDriver.PayoffLoanCharges.ChargesTab.Click(); 
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(@"6.94", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue());
                //FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.Click();
                //NumberOfDays = ((InterestCalculationToDate-InterestCalculationFromDate) + 1) //Assuming both dates are Inclusive
                //InterestCalculationSellerCharge = (((LoanChargesBuyerCharge + LoanChargesSellerCharge) * InterestCalculationPercentage ) / BasedOn) * NumberOfDays
                //6.94 = (((300 + 200)*20)/360)*25 
                
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                SelectInterestCalculationInclusiveTo();
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Best Prevailing");
                SelectInterestCalculationPerDiem();
                FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FASetText(@"2000");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"07-10-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FASelectItemBySendingKeys(@"366");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"07-25-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationChargeDesc.FASetText(@"InterestCalculation");
                Support.AreEqual(@"32,000.00", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue());
                Playback.Wait(2000);//the following fields get disabled while the description is being modified...
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"400");
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.FASetText(@"200"); //seems to be disabled because of DirectedBy GAB missing...
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"600");
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.FASetText(@"200"); //seems to be disabled because of DirectedBy GAB missing...
                #endregion
                #region Enter second instance of payoffloan charges
                Reports.TestStep = "Enter second instance of payoffloan charges";
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge1.FASetText(@"600");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit1.FASetText(@"100");
                FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge1.FASetText(@"200");
                FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit1.FASetText(@"200");
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.PrincipalBalance.Exists().ToString().ToLower());
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.TotalCharges.Exists().ToString().ToLower());
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.PayoffAmount.Exists().ToString().ToLower());
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.CheckAmt.Exists().ToString().ToLower());
                FastDriver.PayoffLoanCharges.PartiesTab.Click();
                FastDriver.PayoffLoanParites.WaitForScreeToLoan();
                FastDriver.PayoffLoanParites.TrustorMortgagor.FASetText(@"TrustorMortgagor (Borrower of Record) ");
                FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FASetText(@"BeneficiaryMortgagee");
                FastDriver.PayoffLoanParites.FindGABCode(@"HUDASLNDR1");
                FastDriver.PayoffLoanRecording.RecordingTab.Click(); 
                FastDriver.PayoffLoanRecording.WaitForScreeToLoan();
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FASetText(@"07-12-2012");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FASetText(@"07-22-2012");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FASetText(@"123");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FASetText(@"23");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FASetText(@"45");
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_BAT0001 failed because " + e.Message);
            }

        }
        [TestMethod]
        public void FMUC0048_BAT0002() 
        {
            try
            {
                Reports.TestDescription = "AF_001: Edit a Payoff Loan Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                //this test relied on the previous one, so the first instance is required
                #region Enter charges to Payoff loan
                Reports.TestStep = "Enter charges to Payoff loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Interest in Addition");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"07-02-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FASelectItemBySendingKeys(@"360");
                SelectInterestCalculationPercentRate();
                FastDriver.PayoffLoanCharges.InterestCalculationProrPercentRateval.FASetText(@"20");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"07-26-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.SendKeys("");
                FastDriver.BottomFrame.Done();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                SelectInterestCalculationInclusiveTo();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText(@"Principal Balance-payoff");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("300");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText("200");   
                #endregion
                #region Enter second instance of interest calculation
                Reports.TestStep = "Enter second instance of interest calculation";
                FastDriver.PayoffLoanCharges.ChargesTab.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                //NumberOfDays = ((InterestCalculationToDate-InterestCalculationFromDate) + 1) //Assuming both dates are Inclusive
                //InterestCalculationSellerCharge = (((LoanChargesBuyerCharge + LoanChargesSellerCharge) * InterestCalculationPercentage ) / BasedOn) * NumberOfDays
                //InterestCalculationSellerCharge = (((300 + 200)*20)/360)*25
                Support.AreEqual(@"6.94", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue());
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                SelectInterestCalculationInclusiveTo();
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Best Prevailing");
                SelectInterestCalculationPerDiem();
                FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FASetText(@"2000");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"07-10-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FASelectItemBySendingKeys(@"366");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"07-25-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationChargeDesc.FASetText(@"InterestCalculation");
                Support.AreEqual(@"32,000.00", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue());
                Playback.Wait(2000);//the following fields get disabled while the description is being modified...
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"400");
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.FASetText(@"200"); //seems to be disabled because of DirectedBy GAB missing...
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"600");
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.FASetText(@"200"); //seems to be disabled because of DirectedBy GAB missing...
                #endregion
                #region Clicking on New button in payoffloan screen
                Reports.TestStep = "Clicking on New button in payoffloan screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                #endregion
                #region Create second instance of payoffloan
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR1");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"400");
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"250");
                FastDriver.BottomFrame.Done();
                #endregion
                #region To click on Edit button
                Reports.TestStep = "To click on Edit button";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("Loan Amount", "250.00", "#1", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Edit Payoffloan
                Reports.TestStep = "Edit Payoffloan";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"700");
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"650");
                FastDriver.BottomFrame.Done();
                #endregion
                #region To click on Edit button for third entry
                Reports.TestStep = "To click on Edit button for the third entry";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("Loan Amount", "650.00", "#1", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Validate the payoffloan after Edit 
                Reports.TestStep = "Validate the payoffloan after Edit for the third entry";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                Support.AreEqual(@"700.00", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue());
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(@"650.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_BAT0002 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_BAT0003() 
        {
            try
            {
                Reports.TestDescription = "AF_002: To delete a Payoff Loan Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                //this test relied on the previous one, so the first instance is required
                #region Enter charges to Payoff loan
                Reports.TestStep = "Enter charges to Payoff loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Interest in Addition");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"07-02-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FASelectItemBySendingKeys(@"360");
                SelectInterestCalculationPercentRate();
                FastDriver.PayoffLoanCharges.InterestCalculationProrPercentRateval.FASetText(@"20");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"07-26-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.SendKeys("");
                FastDriver.BottomFrame.Done();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                SelectInterestCalculationInclusiveTo();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText(@"Principal Balance-payoff");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("300");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText("200"); 
                #endregion
                #region Enter second instance of interest calculation
                Reports.TestStep = "Enter second instance of interest calculation";
                FastDriver.PayoffLoanCharges.ChargesTab.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                //NumberOfDays = ((InterestCalculationToDate-InterestCalculationFromDate) + 1) //Assuming both dates are Inclusive
                //InterestCalculationSellerCharge = (((LoanChargesBuyerCharge + LoanChargesSellerCharge) * InterestCalculationPercentage ) / BasedOn) * NumberOfDays
                //InterestCalculationSellerCharge = (((300 + 200)*20)/360)*25
                Support.AreEqual(@"6.94", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue());
                
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                SelectInterestCalculationInclusiveTo();
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Best Prevailing");
                SelectInterestCalculationPerDiem();
                FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FASetText(@"2000");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"07-10-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FASelectItemBySendingKeys(@"366");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"07-25-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationChargeDesc.FASetText(@"InterestCalculation");
                Support.AreEqual(@"32,000.00", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue());
                Playback.Wait(2000);//the following fields get disabled while the description is being modified...
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"400");
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.FASetText(@"200"); //seems to be disabled because of DirectedBy GAB missing...
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"600");
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.FASetText(@"200"); //seems to be disabled because of DirectedBy GAB missing...
                #endregion
                #region Clicking on New button in payoffloan screen
                Reports.TestStep = "Clicking on New button in payoffloan screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                #endregion
                //this test relied on the previous one, so the second instance is required too                
                #region Create second instance of payoffloan
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR1");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"400");
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"250");
                FastDriver.BottomFrame.Done();
                #endregion
                #region To click on Edit button
                Reports.TestStep = "To click on Edit button";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("Loan Amount", "250.00", "#1", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Edit Payoffloan
                Reports.TestStep = "Edit Payoffloan";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"700");
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"650");
                FastDriver.BottomFrame.Done();
                #endregion
                #region To click on Edit button for third entry
                Reports.TestStep = "To click on Edit button for the third entry";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("Loan Amount", "650.00", "#1", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Validate the payoffloan after Edit
                Reports.TestStep = "Validate the payoffloan after Edit for the third entry";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                Support.AreEqual(@"700.00", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue());
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                Playback.Wait(2000);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(@"650.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
                #region To click on Remove button for third entry
                Reports.TestStep = "To click on Remove button for the third entry";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("Loan Amount", "650.00", "#1", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryRemove.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                #endregion
                #region To click on Edit button for third entry after its been removed
                Reports.TestStep = "To click on Edit button for the third entry after its been removed";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                //FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("Loan Amount", "0.00", "#1", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Available", "#1", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Validate the charges after deletion
                Reports.TestStep = "Validate the charges after deletion";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                Support.AreEqual(@"0.00", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue());
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(@"", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_BAT0003 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_BAT0004() 
        {
            try
            {
                Reports.TestDescription = "AF_003: To cancel 1st New Payoff Loan Instance Creation.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion                
                #region To cancel 1st New Payoff Loan Instance Creation
                Reports.TestStep = "To cancel 1st New Payoff Loan Instance Creation";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "700");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                #endregion
                #region To verify fasthomepage after deleting 1st payoff loan instance
                Reports.TestStep = "To verify fasthomepage after deleting 1st payoff loan instance";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                try
                {
                    Support.AreEqual("", FastDriver.PayoffLoanDetails.GABcodeLabel.FAGetValue().ToString());
                }
                catch(NullReferenceException)
                {
                    Reports.StatusUpdate("Verified instance is null", true);
                }                
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_BAT0004 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_BAT0005() 
        {
            try
            {
                Reports.TestDescription = "AF_004: To cancel 2nd New Payoff Loan Instance Creation.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion                
                #region To create first new Payoff loan instances
                Reports.TestStep = "To create first new Payoff loan instances";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "700");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                FastDriver.BottomFrame.New();
                #endregion
                #region To create 2nd New Payoff Loan Instance Creation
                Reports.TestStep = "To create 2nd New Payoff Loan Instance Creation";
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR2");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"800");
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                #endregion
                #region Validate the payoffloan after Edit
                Reports.TestStep = "Validate the payoffloan after Edit"; 
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                Support.AreEqual(@"Private Party", FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem().ToString());
                Support.AreEqual(@"700.00", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().ToString());
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_BAT0005 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF_005: To cancel 3rd / Subsequent New Payoff Loan Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region To create first new Payoff loan instances
                Reports.TestStep = "To create first new Payoff loan instances";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "700");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                FastDriver.BottomFrame.New();
                #endregion
                #region To create 2nd New Payoff Loan Instance Creation
                Reports.TestStep = "To create 2nd New Payoff Loan Instance Creation";
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR2");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"800");
                FastDriver.BottomFrame.New();
                #endregion
                #region To create 3rd New Payoff Loan Instance Creation
                Reports.TestStep = "To create 3rd New Payoff Loan Instance Creation";
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR3");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Collection Payoff lender");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"900");
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                #endregion
                #region Verify that payoffloan summary screen is loaded
                Reports.TestStep = "Verify that payoff loan summary screen is loaded";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                Support.AreEqual(@"0.00", FastDriver.PayoffLoanSummary.LoanSummaryTableRow1LoanAmount.FAGetText().ToString());
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_BAT0006 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_BAT0007() 
        {
            try
            {
                Reports.TestDescription = "AF_006: To Cancel Changes to Exist Payoff Loan Instance.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region To create first new Payoff loan instances
                Reports.TestStep = "To create first new Payoff loan instances";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "700");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                FastDriver.BottomFrame.New();
                #endregion
                #region To create 2nd New Payoff Loan Instance Creation
                Reports.TestStep = "To create 2nd New Payoff Loan Instance Creation";
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR2");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"800");
                FastDriver.BottomFrame.Done();
                #endregion
                #region To click on Edit button
                Reports.TestStep = "To click on Edit button";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "2", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Edit Payoffloan
                Reports.TestStep = "Edit Payoffloan";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Collection Payoff Lender");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"900");
                FastDriver.BottomFrame.Reset();
                #endregion
                #region Click on OK button with wait time
                Reports.TestStep = "Click on OK button with wait time.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.LenderLoanType); //.SwitchToContentFrame();
                #endregion
                #region Validate the payoffloan after Edit
                Reports.TestStep = "Validate the payoffloan after Edit";
                Support.AreEqual(@"Institutional", FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem().ToString());
                Support.AreEqual(@"800.00", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().ToString());
                #endregion                
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_BAT0007 failed because " + e.Message);
            }
        }

        #endregion

        #region REGRESSION
        [TestMethod]
        public void FMUC0048_REG0001() 
        {
            try
            {
                Reports.TestDescription = "2114_2390_1466_1465_3792_3794_3793_3795_3796_3529_3790_2384_FM1201: Create Basic File and Three instances on Payoff Loan Screen and Enter Data in All the TABS.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Enter all the data except GAB CODE
                Reports.TestStep = "Enter all the data except GAB CODE.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Save Changes without Bus Party
                Reports.TestStep = "Save Changes without Bus Party.";
                string ExpectedMessage = @"Error(s) occured. See Message pane.";
                string ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.ErrorMessageList); //.SwitchToContentFrame();
                #endregion
                #region  Verifying for Business Party Required Error,Enter INVALID GAB CODE and Clicking on Done
                Reports.TestStep = "Verifying for Business Party Required Error, Enter INVALID GAB CODE and Clicking on Done.";
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.ErrorMessageList.Exists().ToString().ToLower());
                string ErrorMessage = "BusOrgID: Business Party required";
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.ErrorMessageList.FAGetText().ToString().ToLower().Contains(ErrorMessage.ToLower()).ToString().ToLower());
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.LenderGABcode); //.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(@"INVALID_ID");
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                #endregion
                #region ID Code Not Found
                ExpectedMessage = @"ID Code not found.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.LenderGABcode); //.SwitchToContentFrame();
                #endregion
                #region Enter Valid ID Code, Loan Type, Principal Balance and clicking on Done
                Reports.TestStep = "Enter Valid ID Code, Loan Type, Principal Balance and Clicking on Done.";
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: @"PAYOFFLNDR", principalBalance: "700");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.PaymentDetails.Exists().ToString().ToLower());
                FastDriver.PayoffLoanCharges.FillChargesForm(buyerChange: "10.00", sellerChange: "12.12");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate the loan of Pay Off Loan Screen Details TAB
                Reports.TestStep = "Validate the loan of Pay Off Loan Screen Details TAB.";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.LenderFind);
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.LenderFind.Exists().ToString().ToLower());
                #endregion
                #region Validate the charges Entered in Charges TAB
                Reports.TestStep = "Validate the charges Entered in Charges TAB.";
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(@"10.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"12.12", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().ToString());
                #endregion 
                #region Navigate to Parties TAB and Clicking on Find
                Reports.TestStep = "Navigate to Parties TAB and Clicking on Find.";
                FastDriver.PayoffLoanDetails.PartiesTab.Click();
                Support.AreEqual("true", FastDriver.PayoffLoanParites.TrustorMortgagorRefresh.Exists().ToString().ToLower());
                Support.AreEqual("true", FastDriver.PayoffLoanParites.TrusteeFind.Exists().ToString().ToLower());
                FastDriver.PayoffLoanParites.TrusteeFind.Click();
                #endregion
                #region Select a Entity Type and search
                Reports.TestStep = "Select a Entity Type and search.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
                Playback.Wait(2000);
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.EntityType, 10);
                FastDriver.AddressBookSearchDlg.EntityType.FASelectItemBySendingKeys(@"Mortgage Broker");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText(@"a*");
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.Find.Click();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                try
                {
                    FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("#7", "AD193335", "#1", TableAction.Click);
                    Support.AreEqual("true", FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("#7", "AD193335", "#1", TableAction.GetAttribute, "selected").Message.ToString().ToLower());
                }
                catch(Exception)
                {
                    Reports.StatusUpdate("Could not find the value AD193335 on the Search Results table", false);
                }
                FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick(); 
                #endregion
                #region Navigate to Recording TAB
                Reports.TestStep = "Navigate to Recording TAB.";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanRecording.SwitchToContentFrame();
                FastDriver.PayoffLoanRecording.RecordingTab.Click();
                FastDriver.PayoffLoanRecording.WaitForScreeToLoan();
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FASetText(@"09-13-2012");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FASetText(@"09-13-2012");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FASetText(@"12345");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FASetText(@"3");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FASetText(@"2");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate Data on Recording TAB
                Reports.TestStep = "Validate Data on Recording TAB";
                FastDriver.PayoffLoanRecording.SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.PayoffLoanRecording.RecordingTab.Click();
                FastDriver.PayoffLoanRecording.WaitForScreeToLoan();
                Support.AreEqual(@"09-13-2012", FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FAGetValue());
                Support.AreEqual(@"09-13-2012", FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FAGetValue());
                Support.AreEqual(@"12345", FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FAGetValue());
                Support.AreEqual(@"3", FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FAGetValue());
                Support.AreEqual(@"2", FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FAGetValue());
                #endregion
                #region Navigate to payoff loan screen
                Reports.TestStep = "Navigate to payoff loan screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                #endregion 
                #region Click on New
                Reports.TestStep = "Click on New";
                FastDriver.BottomFrame.New();
                #endregion
                #region To create 2nd New Payoff Loan Instance Creation
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: @"HUDASLNDR2", principalBalance: "800");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                #endregion
                #region Click on Done   
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to Pay off Loan Summary screen and Clicking on New
                Reports.TestStep = "Navigate to Pay off Loan Summary screen and Clicking on New";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryNew.Click();
                #endregion
                #region To create 3rd New Payoff Loan Instance Creation
                Reports.TestStep = "To create 3rd New Payoff Loan Instance Creation";
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR3");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Collection Payoff lender");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"900");
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                #endregion
                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion
                #region Verify that payoffloan summary screen is loaded
                Reports.TestStep = "Verify that payoff loan summary screen is loaded";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                try
                {
                    FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                }
                catch(Exception)
                {
                    Reports.StatusUpdate("Could not find first instance on Loan Summary table", false);
                }
                #endregion
                #region Verify that payoffloan summary screen is loaded with second instance
                Reports.TestStep = "Verify that payoff loan summary screen is loaded with second instance";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                try
                {
                    FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "2", "#3", TableAction.Click);
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Could not find second instance on Loan Summary table", false);
                }
                #endregion
                #region Verify that payoffloan summary screen is loaded with third instance
                Reports.TestStep = "Verify that payoff loan summary screen is loaded with third instance";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                try
                {
                    FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "3", "#3", TableAction.Click);
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Could not find third instance on Loan Summary table", false);
                }
                #endregion
                #region Select First Instance and Clicking on Edit
                Reports.TestStep = "Select First Instance and Clicking on Edit.";
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen.";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Edit the Principal Amount and Charges
                Reports.TestStep = "Edit the Principal Amount and Charges";
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"6000");
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FASetText(@"10.10");
                FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FASetText(@"10.10");
                FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.SendKeys(FAKeys.Tab);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0001 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0002() 
        {
            try
            {
                Reports.TestDescription = "4236_3799_2464_4237_3530_2380_2383_2378_2379_2381_2382_1481_4183_2391_1896_EWC02: Enter and Verify data in Interest Calculation Section, Verify for The Borrower Charge and Borrower Credit Fields.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Enter Valid ID Code, Loan Type, Principal Balance and clicking on Done
                Reports.TestStep = "Enter Valid ID Code, Loan Type, Principal Balance and Clicking on Done.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: @"PAYOFFLNDR", principalBalance: "700");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.PaymentDetails.Exists().ToString().ToLower());
                FastDriver.PayoffLoanCharges.FillChargesForm(buyerChange: "10.00", sellerChange: "12.12");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Validate the loan of Pay Off Loan Screen Details TAB
                Reports.TestStep = "Validate the loan of Pay Off Loan Screen Details TAB.";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.LenderFind); //.SwitchToContentFrame();
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.LenderFind.Exists().ToString().ToLower());
                #endregion
                #region Validate the charges Entered in Charges TAB
                Reports.TestStep = "Validate the charges Entered in Charges TAB.";
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(@"10.00", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().ToString());
                Support.AreEqual(@"12.12", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().ToString());
                FastDriver.BottomFrame.New();
                #endregion 
                #region To create 2nd New Payoff Loan Instance Creation
                Reports.TestStep = "To create 2nd New Payoff Loan Instance Creation";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR2");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"800");
                //The summary screen can only appear if there's more than one instance created. So far there's only one...
               
                #endregion
                #region Clicking on the Payoff Loan Payment Details Button
                Reports.TestStep = "Clicking on the Payoff Loan Payment Details Button.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PaymentDetails.Click();
                #endregion
                #region Change the payment details methods to POC
                Reports.TestStep = "Change the payment details methods to POC.";
                if(IsFormTypeCD)
                {
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.BuyerAtClosing.FASetText(@"0");
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.SellerAtClosing.FASetText(@"0");
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.BuyerPaidByOthers.FASetText(@"10.10");
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.SellerPaidbyOthers.FASetText(@"10.10");
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.BuyerPaidbyOthersPayMethod.FASelectItemBySendingKeys(@"POC");
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.SellerPaidbyOthersPayMethod.FASelectItemBySendingKeys(@"POC");
                }
                else
                {
                    FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                    //Using PaymentDetailsNewLoanDlg PO because the Description element is not mapped w/ the same id 
                    //on the PaymentDetailsDlg PO
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys(@"POC");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItemBySendingKeys(@"POC");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen after Change Payment Mode to POC
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen after Change Payment Mode to POC.";
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                if(IsFormTypeCD)
                {
                    Support.AreEqual("$42.32", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                    Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                    Support.AreEqual("$42.32", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                    Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                }
                else
                {
                    Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                    Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                    Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                    Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                }
                #endregion
                #region Enter Interest Calculation data
                Reports.TestStep = "Enter Interest Calculation data.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Fixed Rate");
                FastDriver.PayoffLoanCharges.InterestCalculationPerDiem.FASetCheckbox(true);
                FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FASetText(@"10.11");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"09-02-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FASelectItemBySendingKeys(@"365");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"09-12-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FASetText(@"23.20");
                #endregion
                #region Change the interest calculation radio button
                Reports.TestStep = "Change the interest calculation radio button.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.FASetCheckbox(true);
                ExpectedMessage = "Interest calculation formula values have changed. \r\nDo you wish to recalculate interest charges?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.SendKeys("");
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.Click();
                //Don't use FASetCheckbox(true) because it does some JavaScript in the back and prevents the dialog 
                //from being handled properly...
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Change the Principal Amount Under Loan Section to verify Error Warning
                Reports.TestStep = "Change the Principal Amount Under Loan Section to verify Error Warning.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"7.00");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Select First Instance and Clicking on Edit
                Reports.TestStep = "Select First Instance and Clicking on Edit.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                try
                {
                    FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                    FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                }
                catch (NullReferenceException)
                {
                    Reports.StatusUpdate("Could not find Loan Summary table on Payoff Loan screen", false);
                }
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Clicking on Find on Details TAB
                Reports.TestStep = "Clicking on Find on Details TAB.";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                #endregion
                #region Select a Entity Type and search
                Reports.TestStep = "Select a Entity Type and search.";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
                Playback.Wait(2000);
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.EntityType, 10);
                FastDriver.AddressBookSearchDlg.EntityType.FASelectItemBySendingKeys(@"Mortgage Broker");
                FastDriver.AddressBookSearchDlg.EntityName.FASetText(@"a*");
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.Find.Click();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                try
                {
                    FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("#7", "AD193335", "#1", TableAction.Click);
                    Support.AreEqual("true", FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("#7", "AD193335", "#1", TableAction.GetAttribute, "selected").Message.ToString().ToLower());
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Could not find the value AD193335 on the Search Results table", false);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Select First Instance and Clicking on Delete
                Reports.TestStep = "Select First Instance and Clicking on Delete.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryRemove.Click();
                #endregion
                #region All information will be removed for this Payoff Loan. Continue?
                Reports.TestStep = "All information will be removed for this Payoff Loan. Continue?";
                ExpectedMessage = @"All information will be removed for this Payoff Loan.  Continue?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region To click on Edit button
                Reports.TestStep = "To click on Edit button";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                try
                {
                    FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Available", "#3", TableAction.Click);
                }
                catch (NullReferenceException)
                {
                    Reports.StatusUpdate("Could not find entry \"Available\" on the Name column at the Loan Summary table", false);
                }
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion                
                #region Create instance
                Reports.TestStep = "Create instance.";
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: @"PAYOFFLNDR", principalBalance: "5000.00");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.PaymentDetails.Exists().ToString().ToLower());
                FastDriver.PayoffLoanCharges.FillChargesForm(buyerChange: "10.00", sellerChange: "12.12");
                FastDriver.PayoffLoanCharges.PartiesTab.Click();
                FastDriver.PayoffLoanParites.WaitForScreeToLoan(FastDriver.PayoffLoanParites.TrusteeGABcode);
                FastDriver.PayoffLoanParites.FindGABCode(@"TRUSTEE1");
                FastDriver.PayoffLoanRecording.RecordingTab.Click();
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FASetText(@"09-13-2012");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FASetText(@"09-13-2012");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FASetText(@"12345");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FASetText(@"3");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FASetText(@"2");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Enter Vest information
                Reports.TestStep = "Enter Vest information.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers");
                try
                {
                    FastDriver.BuyerSellerSummary.WaitForBuyerSellerSummaryTableLoad();
                    FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                }
                catch(NullReferenceException)
                {
                    Reports.StatusUpdate("Could not find first element on Buyer/Seller summary table", false);
                }
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.Full_Vesting();
                FastDriver.BuyerVesting.SwitchToContentFrame();
                FastDriver.BuyerVesting.Names.FASetText(@"Name for PayOff Loan");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Select First Instance and Clicking on Edit again
                Reports.TestStep = "Select First Instance and Clicking on Edit again.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                try
                {
                    FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                    FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                }
                catch (NullReferenceException)
                {
                    Reports.StatusUpdate("Could not find Loan Summary table on Payoff Loan screen", false);
                }
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion 
                #region Validate for the vesting information updated in Seller Information
                Reports.TestStep = "Validate for the vesting information updated in Seller Information.";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.PartiesTab.Click();
                FastDriver.PayoffLoanParites.WaitForScreeToLoan();
                ExpectedMessage = @"Name for PayOff Loan";
                ActualMessage = FastDriver.PayoffLoanParites.TrustorMortgagor.FAGetValue();
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0002 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0003() 
        {
            try
            {
                Reports.TestDescription = "1895_ES12652_ES12653_ES12654_ES12655: When calculate loan interest for a Payoff Loan, if the transaction type is Refinance or Loan, the system will populate the calculated interest amount to the Borrower Charge field, If";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "REFI";//REFINANCE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Create instance and Verifying for the Borrower charge
                Reports.TestStep = "Create instance and Verifying for the Borrower charge.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"247");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"247");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                SelectInterestCalculationInclusiveTo(true);
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItem(@"Fixed Rate");
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASendKeys(FAKeys.Tab);
                Playback.Wait(5000);
                //Need to use sendkeys method to trigger event
                FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FAClick();
                FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FASendKeys(@"10.00" + FAKeys.Tab);
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"09-17-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"09-21-2012" + FAKeys.Tab);
                Support.AreEqual(@"50.00", FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FAGetValue().ToString());
                #endregion
                #region Change the Transaction type
                Reports.TestStep = "Change the Transaction type.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Sale w/Mortgage");
                //this will only pop up if there's a Program Type selected. Previous script did not select any...
                ExpectedMessage = @"Retain the Program Type that was selected for the previous Transaction Type?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                //Support.AreEqual(ExpectedMessage, ActualMessage);
                ExpectedMessage = @"Would you like to update the file Product and Search Type?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                //Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.BottomFrame.Save();
                #endregion
                #region Validate the Disable of Buyer and Seller credit Text Boxes on Payoff Charges screen
                Reports.TestStep = "Validate the Disable of Buyer and Seller credit Text Boxes on Payoff Charges screen.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Enabled.ToString().ToLower());
                #endregion
                #region Enter Loan Charges Buyer charge
                Reports.TestStep = "Enter Loan Charges Buyer charge.";
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"10.11");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Enter Loan Charges seller charge
                Reports.TestStep = "Enter Loan Charges seller charge.";
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"10.11");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Verifying that Buyer or Broker charge amount is disable irrespective of Transaction type
                Reports.TestStep = "Verifying that Buyer or Broker charge amount is disable irrespective of Transaction type.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                #endregion
                #region Change the Transaction type to Construction Loan
                //Modified Transaction Types list according to US431313!!!
                //Removed: "Construction Loan" and "Mortgage Modification"
                //Reports.TestStep = "Change the Transaction type to Construction Loan.";
                //FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                //FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Construction Loan");
                //ExpectedMessage = @"Retain the Program Type that was selected for the previous Transaction Type?";
                //ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                //Support.AreEqual(ExpectedMessage, ActualMessage);
                //ExpectedMessage = @"Would you like to update the file Product and Search Type?";
                //ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                //Support.AreEqual(ExpectedMessage, ActualMessage);
                //FastDriver.BottomFrame.Save();
                #endregion
                #region Validate the Disable of Buyer and Seller credit Text Boxes on Payoff Charges screen
                //Reports.TestStep = "Validate the Disable of Buyer and Seller credit Text Boxes on Payoff Charges screen.";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreeToLoad();
                //FastDriver.PayoffLoanDetails.ClickChargesTab();
                //FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                //Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                //Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Enabled.ToString().ToLower());                
                #endregion 
                #region Enter Loan Charges Buyer charge
                //Reports.TestStep = "Enter Loan Charges Buyer charge.";
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"10.11");
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Enter Loan Charges seller charge
                //Reports.TestStep = "Enter Loan Charges seller charge.";
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"10.11");
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Verifying for the Principal Amount change affetr Change the Buyer and seller charge
                //Reports.TestStep = "Verifying for the Principal Amount change affetr Change the Buyer and seller charge.";
                //FastDriver.PayoffLoanDetails.WaitForScreeToLoad();
                #endregion
                #region Verifying that Buyer or Broker charge amount is disable irrespective of Transaction type
                //Reports.TestStep = "Verifying that Buyer or Broker charge amount is disable irrespective of Transaction type.";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreeToLoad();
                //FastDriver.PayoffLoanDetails.ClickChargesTab();
                //Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Enabled.ToString().ToLower());
                //Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                #endregion
                #region Change the Transaction type to Construction Disbursement
                Reports.TestStep = "Change the Transaction type to Construction Disbursement.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Construction Disbursement");
                #endregion
                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                #endregion
                #region Click on Save
                Reports.TestStep = "Click on Save.";
                FastDriver.BottomFrame.Save();
                #endregion
                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion
                //Modified Transaction Types list according to US431313!!!
                //Removed: "Construction Loan" and "Mortgage Modification"
                #region Verifying the hidden of Seller Charge and Buyer Charge and Buyer and seller credit is Enable and  when Transaction Type is Construction Disbursement,Equity Loan,Mortgage Modification or Refinance
                Reports.TestStep = "Verifying the hidden of Seller Charge and Buyer Charge and Buyer and seller credit is Enable and  when Transaction Type is Construction Disbursement,Equity Loan,Mortgage Modification or Refinance.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge);
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.IsEnabled().ToString().ToLower(), "Buyer Charge");
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.IsEnabled().ToString().ToLower(), "Buyer Credit");
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.IsEnabled().ToString().ToLower(), "Seller Charge");
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.IsEnabled().ToString().ToLower(), "Seller Credit");
                #endregion
                #region Verifying that Buyer or Broker charge amount is disable irrespective of Transaction type
                Reports.TestStep = "Verifying that Buyer or Broker charge amount is disable irrespective of Transaction type.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                #endregion

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0003 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0004() 
        {
            try
            {
                Reports.TestDescription = "ES12652_ES12653_ES12654_ES12655: Verify Buyer Charge and seller charges Enable Disable for different Transactions-Buyer Seller charge Should be enable and visible for Accommodation, Bulk Sale, Construction Loan, Forecl";

                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                //Modified Transaction Types list according to US431313!!!
                //Removed: "Construction Loan" and "Mortgage Modification"
                #region Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types
                Reports.TestStep = "Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Sale w/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                //Modified Transaction Types list according to US431313!!!
                //Removed: "Construction Loan" and "Mortgage Modification"
                //List<string> TransactionTypes = new List<string>() { "Accommodation", "Bulk Sale", "Construction Disbursement", "Construction Loan", "Equity Loan", "Foreclosure", "Limited Escrow", "Mortgage Modification", "REO Sale w/Mortgage", "Refinance", "REO Sale/Cash", "Sale w/Mortgage", "Sale/Cash", "Sale/Exchange", "Search Package", "Second Mortgage", "Settlement Statement Only", "Short Sale w/Mortgage", "Short Sale/Cash" };
                List<string> TransactionTypes = new List<string>() { "Accommodation", "Bulk Sale", "Construction Disbursement", "Construction Finance", "Foreclosure", "Limited Escrow", "Refinance", "REO Sale w/Mortgage", "REO Sale/Cash", "Sale w/Construction Loan", "Sale w/Mortgage", "Equity Loan", "Sale/Cash", "Sale/Exchange", "Search Package", "Second Mortgage", "Settlement Statement Only", "Short Sale w/Mortgage", "Short Sale/Cash" };
                foreach (string TransactionType in TransactionTypes)
                {
                    Reports.TestStep = "Change the Transaction type to " + TransactionType;
                    FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                    FastDriver.FileHomepage.WaitForScreenToLoad();
                    FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(TransactionType);
                    //Modified Transaction Types list according to US431313!!!
                    //Removed: "Construction Loan" and "Mortgage Modification"
                    //if (TransactionType == "Construction Disbursement" || TransactionType == "Equity Loan" || TransactionType == "Mortgage Modification" || TransactionType == "Refinance")
                    if (TransactionType == "Construction Disbursement" || TransactionType == "Equity Loan" || TransactionType == "Refinance")
                    {
                        ExpectedMessage = "The sale price and all seller charges and credits will be removed, Continue?";
                        ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                        Support.AreEqual(ExpectedMessage, ActualMessage);
                        FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                        FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                        FastDriver.BottomFrame.Save();
                    }
                    else
                    {
                        FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                        FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                        FastDriver.BottomFrame.Save();
                    }

                    FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                    FastDriver.PayoffLoanDetails.ClickChargesTab();
                    FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                    if(TransactionType == "Construction Finance")
                    {
                        Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                        Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Enabled.ToString().ToLower());
                        FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("2");
                        FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                        Support.AreEqual("true", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString().Contains("2").ToString().ToLower(), "Verifying Principal Balance contains the value 2");
                    }
                    //Modified Transaction Types list according to US431313!!!
                    //Removed: "Construction Loan" and "Mortgage Modification"
                    //if (TransactionType == "Construction Disbursement" || TransactionType == "Equity Loan" || TransactionType == "Mortgage Modification" || TransactionType == "Refinance")
                    else if (TransactionType == "Construction Disbursement" || TransactionType == "Equity Loan" || TransactionType == "Refinance")
                    {
                        Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                        Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Enabled.ToString().ToLower());
                        FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("1");
                        FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                        Support.AreEqual("true", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString().Contains("1").ToString().ToLower(), "Verifying Principal Balance contains the value 1");
                    }                    
                    else
                    {
                        Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                        Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Enabled.ToString().ToLower());
                        Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Enabled.ToString().ToLower());
                        Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.Enabled.ToString().ToLower());
                        FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("2");
                        FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText("3");
                        FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.SendKeys(FAKeys.Tab);
                        Support.AreEqual("true", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString().Contains("5").ToString().ToLower(), "Verifying Principal Balance contains the value 5");
                    }
                }
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0004 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0005() 
        {
            try
            {
                Reports.TestDescription = "ES12652_ES12653_ES12654_ES12655_2: Verify Buyer Charge and seller charges Enable Disable for different Transactions Sale/Cash, Sale/Exchange, Search Package, Second Mortgage, Settlement Statement Only, Short Sale transac";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Change the Transaction type to REO Sale/Cash
                Reports.TestStep = "Change the Transaction type to REO Sale/Cash.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem(@"REO Sale/Cash");
                FastDriver.FileHomepage.TransactionType.FASendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 10, retryWithAutoIT: true);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types
                Reports.TestStep = "Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"11.06" + FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"11.06" + FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Enabled.ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen.";
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework
                Reports.TestStep = "Cancel using Cancel button in the bottom framework.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
                #region Change the Transaction type to Sale/Cash
                Reports.TestStep = "Change the Transaction type to Sale/Cash.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Sale/Cash");
                FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.BottomFrame.Save();    
                #endregion 
                #region Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Sale/Cash
                Reports.TestStep = "Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Sale/Cash.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"11.06" + FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"11.06" + FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Enabled.ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Sale/Cash
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Sale/Cash.";
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework for Sale/Cash
                Reports.TestStep = "Cancel using Cancel button in the bottom framework for Sale/Cash.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button for Sale/Cash
                Reports.TestStep = "Click on Ok button for Sale/Cash.";
                ExpectedMessage = @"Cancel without saving changes?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Change the Transaction type to Search Package
                Reports.TestStep = "Change the Transaction type to Search Package.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Search Package");
                FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
                #region Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Search Package
                Reports.TestStep = "Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Search Package.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"11.06" + FAKeys.Tab);
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"11.06" + FAKeys.Tab);
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Enabled.ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Search Package
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Search Package.";
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework for Search Package
                Reports.TestStep = "Cancel using Cancel button in the bottom framework for Search Package.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button for Search Package
                Reports.TestStep = "Click on Ok button for Search Package.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
                #region Change the Transaction type to Second Mortgage
                Reports.TestStep = "Change the Transaction type to Second Mortgage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Second Mortgage");
                FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.BottomFrame.Save();
                #endregion
                #region Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Second Mortgage
                Reports.TestStep = "Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Second Mortgage.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"11.06" + FAKeys.Tab);
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"11.06" + FAKeys.Tab);
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Enabled.ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Second Mortgage
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Second Mortgage.";
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework for Second Mortgage
                Reports.TestStep = "Cancel using Cancel button in the bottom framework for Second Mortgage.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button for Second Mortgage
                Reports.TestStep = "Click on Ok button for Second Mortgage.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
                #region Change the Transaction type to Settlement Statement Only
                Reports.TestStep = "Change the Transaction type to Settlement Statement Only.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Settlement Statement Only");
                FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.BottomFrame.Save();
                #endregion
                #region Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Settlement Statement Only
                Reports.TestStep = "Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Settlement Statement Only.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"11.06" + FAKeys.Tab);
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"11.06" + FAKeys.Tab);
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Enabled.ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Settlement Statement Only
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Settlement Statement Only.";
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework for Settlement Statement Only
                Reports.TestStep = "Cancel using Cancel button in the bottom framework for Settlement Statement Only.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button for Settlement Statement Only
                Reports.TestStep = "Click on Ok button for Settlement Statement Only.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
                #region Change the Transaction type to Short Sale transaction types
                Reports.TestStep = "Change the Transaction type to Short Sale transaction types.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Short Sale w/Mortgage");
                FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                FastDriver.BottomFrame.Save();
                #endregion
                #region Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Short Sale transaction types
                Reports.TestStep = "Verifying the Enable of Seller Charge and Buyer Charge must be editable and Disable of Buyer And Seller credit when Transaction Type is Accommodation,Bulk Sale,Construction Loan,Foreclosure,Limited Escrow,REO Sale w/Mortgage,REO Sale/Cash,Salew/Mortgage,Sale/Cash,Sale/Exchange,Search Package,Second Mortgage,Settlement Statement Only or Short Sale transaction types for Short Sale transaction types.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"11.06" + FAKeys.Tab);
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"11.06" + FAKeys.Tab);
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Enabled.ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Short Sale transaction types
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Short Sale transaction types.";
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework for Short Sale transaction types
                Reports.TestStep = "Cancel using Cancel button in the bottom framework for Short Sale transaction types.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button for Short Sale transaction types
                Reports.TestStep = "Click on Ok button for Short Sale transaction types.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
                
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0005 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0006() 
        {
            try
            {
                Reports.TestDescription = "ES12652_ES12653_ES12654_ES12655_3: Verify Buyer Charge and seller charges Enable Disable for different Transactions Sale/Cash, Sale/Exchange, Search Package, Second Mortgage, Settlement Statement Only, Short Sale transac";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Change the Transaction type to Construction Disbursement
                Reports.TestStep = "Change the Transaction type to Construction Disbursement.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Construction Disbursement");
                //FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.FileHomepage.SwitchToContentFrame();
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                #endregion
                #region Verifying that seller charge and seller credit in Not available on payoff loan screen and Borrower charge and borrower credit in present and Borrower credit in Disable
                Reports.TestStep = "Verifying that seller charge and seller credit in Not available on payoff loan screen and Borrower charge and borrower credit in present and Borrower credit in Disable.";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"22.12");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.Exists().ToString().ToLower());
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Exists().ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen.";
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework
                Reports.TestStep = "Cancel using Cancel button in the bottom framework.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
                #region Change the Transaction Type to Equity Loan
                Reports.TestStep = "Change the Transaction Type to Equity Loan.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Equity Loan");
                FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.BottomFrame.Save();
                #endregion
                #region Verifying that seller charge and seller credit in Not available on payoff loan screen and Borrower charge and borrower credit in present and Borrower credit in Disable for Equity Loan
                Reports.TestStep = "Verifying that seller charge and seller credit in Not available on payoff loan screen and Borrower charge and borrower credit in present and Borrower credit in Disable for Equity Loan.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"22.12");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.Exists().ToString().ToLower());
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Exists().ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Equity Loan
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Equity Loan.";
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework for Equity Loan
                Reports.TestStep = "Cancel using Cancel button in the bottom framework for Equity Loan.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button for Equity Loan
                Reports.TestStep = "Click on Ok button for Equity Loan.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
                //Modified Transaction Types list according to US431313!!!
                //Removed: "Construction Loan" and "Mortgage Modification"
                #region Change the Transaction Type to Mortgage Modification
                //Reports.TestStep = "Change the Transaction type to Mortgage Modification.";
                //FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                //FastDriver.FileHomepage.WaitForScreenToLoad();
                //FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Mortgage Modification");
                //FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                //FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                //FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                //FastDriver.BottomFrame.Save();
                #endregion
                #region Verifying that sellet charge and seller credit in Not availbale on payoff loan screen and Borrower charge and borrower credit in present and Borrower credit in Disable for Mortgage Modification
                //Reports.TestStep = "Verifying that sellet charge and seller credit in Not availbale on payoff loan screen and Borrower charge and borrower credit in present and Borrower credit in Disable for Mortgage Modification.";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreeToLoad();
                //FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                //FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                //FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"22.12");
                //FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                //Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                //Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.Exists().ToString().ToLower());
                //Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Exists().ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Mortgage Modification
                //Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Mortgage Modification.";
                //Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                //Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                //Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                //Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework for Mortgage Modification
                //Reports.TestStep = "Cancel using Cancel button in the bottom framework for Mortgage Modification.";
                //FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button for Mortgage Modification
                //Reports.TestStep = "Click on Ok button for Mortgage Modification.";
                //FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
                #region Change the Transaction Type to Refinance
                Reports.TestStep = "Change the Transaction type to Refinance.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Refinance");
                FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.BottomFrame.Save();
                #endregion
                #region Verifying that seller charge and seller credit in Not available on payoff loan screen and Borrower charge and borrower credit in present and Borrower credit in Disable for Refinance
                Reports.TestStep = "Verifying that seller charge and seller credit in Not available on payoff loan screen and Borrower charge and borrower credit in present and Borrower credit in Disable for Refinance.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.WaitForGABCode(@"HUDFLINSR1");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"22.12");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.Enabled.ToString().ToLower());
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.Exists().ToString().ToLower());
                Support.AreEqual("false", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.Exists().ToString().ToLower());
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Refinance
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen for Refinance.";
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$22.12", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Cancel using Cancel button in the bottom framework for Refinance
                Reports.TestStep = "Cancel using Cancel button in the bottom framework for Refinance.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Click on Ok button for Refinance
                Reports.TestStep = "Click on Ok button for Refinance.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0006 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0007()
        {
            try
            {
                Reports.TestDescription = "Error_Warning_Conditions_1_3_6_8_11_12_13_14_15_4_5_7_A: Verify for the various Error Conditions and Warn Messages for the payoff loan instances.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region To cancel 1st New Payoff Loan Instance Creation
                Reports.TestStep = "To cancel 1st New Payoff Loan Instance Creation";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "700");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Cancel without save changes and click on Cancel button
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                ExpectedMessage = @"Cancel without saving changes?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                #endregion
                #region Click on Cancel
                Reports.TestStep = "Click on Cancel.";
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Cancel without saving changes
                Reports.TestStep = "Cancel without saving changes.";
                ExpectedMessage = @"Cancel without saving changes?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                #endregion
                #region Enter all the data except GAB CODE
                Reports.TestStep = "Enter all the data except GAB CODE.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Save Changes without Bus Party
                Reports.TestStep = "Save Changes without Bus Party.";
                ExpectedMessage = "Error(s) occured. See Message pane.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.ErrorMessageList); //.SwitchToContentFrame();
                #endregion
                #region Verifying for Business Party Required Error,Enter INVALID GAB CODE and Clicking on Done
                Reports.TestStep = "Verifying for Business Party Required Error,Enter INVALID GAB CODE and Clicking on Done.";
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.ErrorMessageList.Exists().ToString().ToLower());
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.ErrorMessageList.FAGetText().Contains("Business Party required").ToString().ToLower());
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.LenderGABcode); //.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(@"INVALID_ID");
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                #endregion
                #region ID Code Not Found
                Reports.TestStep = "ID Code Not Found.";
                ExpectedMessage = @"ID Code not found.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Enter Valid ID Code,Loan Type,Principal Balance and clicking on Done
                Reports.TestStep = "Enter Valid ID Code,Loan Type,Principal Balance and clicking on Done.";
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: @"PAYOFFLNDR", principalBalance: "5000");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.PaymentDetails.Exists().ToString().ToLower());
                FastDriver.PayoffLoanCharges.FillChargesForm(buyerChange: "10.00", sellerChange: "12.12");
                FastDriver.BottomFrame.Done();               
                #endregion
                #region Edit the Principal Amount and Charges
                Reports.TestStep = "Edit the Principal Amount and Charges";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"6000");
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FASetText(@"10.10");
                FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FASetText(@"10.10");
                FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Click on Reset
                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();
                #endregion
                #region Cancel without save changes and click on Cancel button
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                ExpectedMessage = @"Cancel without saving changes?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, switchBackToFastWindow: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                #endregion
                #region Click on Reset
                Reports.TestStep = "Click on Reset.";
                FastDriver.BottomFrame.Reset();
                #endregion
                #region Cancel without saving changes
                Reports.TestStep = "Cancel without saving changes.";
                ExpectedMessage = @"Cancel without saving changes?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                // Sometimes an error is thrown.
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                #endregion
                #region Enter Valid ID Code,Loan Type,Principal Balance and clicking on Done
                Reports.TestStep = "Enter Valid ID Code,Loan Type,Principal Balance and clicking on Done.";
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: @"PAYOFFLNDR", principalBalance: "5000");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.PaymentDetails.Exists().ToString().ToLower());
                FastDriver.PayoffLoanCharges.FillChargesForm(buyerChange: "10.00", sellerChange: "12.12");
                FastDriver.BottomFrame.Done();               
                #endregion
                #region Select First Instance and Clicking on Edit
                Reports.TestStep = "Select First Instance and Clicking on Edit.";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Enter Interest Calculation data
                Reports.TestStep = "Enter Interest Calculation data.";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Fixed Rate");
                FastDriver.PayoffLoanCharges.InterestCalculationPerDiem.FASetCheckbox(true);
                FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FASetText(@"10.11");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"09-02-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FASelectItemBySendingKeys(@"365");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"09-12-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FASetText(@"23.20");
                #endregion
                #region Change the Principal Amount Under Loan Section to verify Error Warning
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"7.00");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Change the interest calculation radio button
                Reports.TestStep = "Change the interest calculation radio button.";
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.SendKeys("");
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.Click();
                //Don't use FASetCheckbox(true) because it does some JavaScript in the back and prevents the dialog 
                //from being handled properly...
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);
                ExpectedMessage = "Interest calculation formula values have changed. \r\nDo you wish to recalculate interest charges?";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Deleting the Charge Description
                Reports.TestStep = "Deleting the Charge Description.";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                //FastDriver.PayoffLoanDetails.WaitForScreeToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("");
                FastDriver.PayoffLoanCharges.LoanChargesDescription.SendKeys(Keys.Delete);
                FastDriver.PayoffLoanCharges.LoanChargesDescription.SendKeys(FAKeys.Tab);
                #endregion
                #region Delete Charge Description
                ExpectedMessage = @"Unable to delete charge description.  Charge description still has a charge amount.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion 

            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0007 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0008() 
        {
            try
            {
                Reports.TestDescription = "Error_Warning_Conditions_1_3_6_8_11_12_13_14_15_4_5_7_B: Verify for the various Error Conditions and Warn Messages for the payoff loan instances.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Enter Valid ID Code, Loan Type, Principal Balance and clicking on Done
                Reports.TestStep = "Enter Valid ID Code, Loan Type, Principal Balance and Clicking on Done.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: @"PAYOFFLNDR", principalBalance: "700");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.PaymentDetails.Exists().ToString().ToLower());
                FastDriver.PayoffLoanCharges.FillChargesForm(buyerChange: "10.00", sellerChange: "12.12");
                FastDriver.BottomFrame.New();
                #endregion
                #region To create 2nd New Payoff Loan Instance Creation
                Reports.TestStep = "To create 2nd New Payoff Loan Instance Creation";
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR2");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"800");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Select First Instance and Clicking on Edit
                Reports.TestStep = "Select First Instance and Clicking on Edit.";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Checking Edit Name check Box and Clicking on Done
                Reports.TestStep = "Checking Edit Name check Box and Clicking on Done.";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderEditName.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Name field is required when Edit Name checkbox is selected
                Reports.TestStep = "Name field is required when Edit Name checkbox is selected.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                ExpectedMessage = @"Name field is required when Edit Name checkbox is selected.";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.LenderEditContact); //.SwitchToContentFrame();
                #endregion
                #region Uncheck Edit Name checkbox and Enter Invalid Email ID
                Reports.TestStep = "Uncheck Edit Name checkbox and Enter Invalid Email ID.";
                FastDriver.PayoffLoanDetails.LenderEditContact.FASetCheckbox(true);
                FastDriver.PayoffLoanDetails.LenderEmailAddress.FASetText(@"Invalid_ID@@firstam.com");
                FastDriver.PayoffLoanDetails.LenderNameEdit.FASetText(@"Edit Name");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Enter invalid data
                Reports.TestStep = "Enter invalid data.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                ExpectedMessage = @"Please correct invalid data entered.";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.LenderEmailAddress); //.SwitchToContentFrame();
                #endregion
                #region Enter Valid Email ID
                Reports.TestStep = "Enter Valid Email ID.";
                FastDriver.PayoffLoanDetails.LenderEmailAddress.FASetText(@"Invalid@Firstam.com");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Print All Checks
                Reports.TestStep = "Print All Checks.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.PrintAll.Click();
                FastDriver.PrintChecks.SwitchToContentFrame();
                #endregion
                #region Click on Deliver
                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.Deliver.FAClick();
                if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    FailTest("Printer is not configured");
                }

                Reports.TestStep = "SendPrint.";
                FastDriver.PrintDlg.SendPrint();

                Reports.TestStep = "Handle Password Confirmation Dialog.";
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PrintChecks.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Select First Instance and Clicking on Delete
                Reports.TestStep = "Select First Instance and Clicking on Delete";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad(timeout: 15);
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryRemove.Click();
                #endregion 
                #region Handle Dialog: A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee
                Reports.TestStep = "Handle Dialog: A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee";
                ExpectedMessage = @"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad(timeout: 15);
                #endregion
                #region Select Second Instance and Clicking on Edit
                Reports.TestStep = "Select Second Instance and Clicking on Edit.";
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "2", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Change the Business Party
                Reports.TestStep = "Change the Business Party";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(@"247");
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                #endregion
                #region Handle Dialog: A check has been issued for this Payee. The Payee name cannot be changed
                //This won't show up because the check was issued for the first payee...
                //Reports.TestStep = "Handle Dialog: A check has been issued for this Payee. The Payee name cannot be changed.";
                //ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                //ExpectedMessage = @"A check has been issued for this Payee. The Payee name cannot be changed.";
                //Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Change the amount, Enter lesser than the amount previously entered
                Reports.TestStep = "Change the amount, Enter lesser than the amount previously entered.";
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"1.00");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Handle Dialog: A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File be out-of-balance. Do you wish to save the changes?
                Reports.TestStep = "Handle Dialog: A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Account entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File be out-of-balance. Do you wish to save the changes?.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                ExpectedMessage = @"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total. Please verify that the appropriate Trust Accounting entries have been made. (I.e. should the issued check be cancelled?) Additionally, these changes may result in the File being out-of-balance. Do you wish to save the changes?";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Change the amount, Enter greater than the amount previously entered
                Reports.TestStep = "Change the amount, Enter greater than the amount previously entered.";
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"100.00");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Handle Dialog: A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?
                Reports.TestStep = "Handle Dialog: A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?.";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                ExpectedMessage = @"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0008 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0009() 
        {
            try
            {
                Reports.TestDescription = "FM3793_FM3796_FM3794_ES12655_FM3797_FM1896: Verify that the system adds the net amount of buyer charges and credits to the Total Charges.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Enter Valid ID Code, Loan Type, Principal Balance and clicking on Done
                Reports.TestStep = "Enter Valid ID Code, Loan Type, Principal Balance and Clicking on Done.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"PAYOFFLNDR");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationChargeDesc.FASetText(@"Interest on Payoff Loan" + FAKeys.Tab);
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText(@"10.00" + FAKeys.Tab);
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCredit.FASetText(@"2.00" + FAKeys.Tab);
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FASetText(@"10.00" + FAKeys.Tab);
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCredit.FASetText(@"2.00" + FAKeys.Tab);
                //FastDriver.PayoffLoanCharges.InterestCalculationSellerCredit.SendKeys(FAKeys.Tab);
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen after Change Payment Mode to POC
                Reports.TestStep = "Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen after Change Payment Mode to POC.";
                Support.AreEqual("$0.00", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$16.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$16.00", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$16.00", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
                #region Enter Principal Balance Amount
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"10.00");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                #region Validate Principal Amount,Total charge amnt,Payoff amount and check Amount on Details Screen
                Support.AreEqual("$10.00", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText().ToString());
                Support.AreEqual("$16.00", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText().ToString());
                Support.AreEqual("$26.00", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().ToString());
                Support.AreEqual("$26.00", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().ToString());
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0009 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0010() 
        {
            try
            {
                Reports.TestDescription = "Error_Warning_Conditions_9_10_16: Verify for the various Error Conditions and Warn Messages for the payoff loan instances.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Cancel the first instance
                Reports.TestStep = "Cancel the first instance.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"PAYOFFLNDR");
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Cancel without save changes and click on Cancel button
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                ExpectedMessage = @"Cancel without saving changes?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion
                #region Click on New
                Reports.TestStep = "Click on New.";
                FastDriver.BottomFrame.New();
                #endregion
                #region Cancel the second instance
                Reports.TestStep = "Cancel the second instance.";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"247");
                FastDriver.PayoffLoanDetails.LenderReference.FASetText(@"12345");
                FastDriver.BottomFrame.Cancel();
                #endregion
                #region Cancel without save changes and click on Cancel button
                Reports.TestStep = "Cancel without save changes and click on Cancel button.";
                ExpectedMessage = @"Cancel without saving changes?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                Support.AreEqual(ExpectedMessage, ActualMessage);
                #endregion
                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion
                #region To click on Edit button
                Reports.TestStep = "To click on Edit button";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "2", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Change the Business Party
                Reports.TestStep = "Change the Business Party";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(@"247");
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                #endregion
                #region User tries to change a Business Party which has a Reference number specified against it
                Reports.TestStep = "User tries to change a Business Party which has a Reference number specified against it.";
                ExpectedMessage = "Changing the Business Party will remove \"Reference\"/\"Loan\" Number.\r\nDo you want to retain the \"Reference\"/\"Loan\" Number?";
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                #endregion


            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0010 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0011() 
        {
            try
            {
                Reports.TestDescription = "FM2380_FM2383_FM2378_FM2379_FM2381_FM2382_FM1481_ES12654: Verify that system updates the Trustor-Mortgagor information from Seller and Beneficiary Mortgagor information from Payoff Lender.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region To create first new Payoff loan instances
                Reports.TestStep = "To create first new Payoff loan instances";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "700");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                FastDriver.BottomFrame.New();
                #endregion
                #region To create 2nd New Payoff Loan Instance Creation
                Reports.TestStep = "To create 2nd New Payoff Loan Instance Creation";
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR2");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"800");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Edit the Trust and Mortgagor Information
                Reports.TestStep = "Edit the Trust and Mortgagor Information.";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "2", "#1", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.PartiesTab.Click();
                FastDriver.PayoffLoanParites.WaitForScreeToLoan();
                FastDriver.PayoffLoanParites.TrustorMortgagor.FASetText(@"Edit Trustor-Mortgagor");
                FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FASetText(@"Edit Beneficiary-Mortgagee");
                #endregion 
                #region Validate the refresh functionality on Properties Tab
                Reports.TestStep = "Validate the refresh functionality on Properties Tab.";
                FastDriver.PayoffLoanParites.SwitchToContentFrame();
                FastDriver.PayoffLoanParites.TrustorMortgagorRefresh.Click();
                //ExpectedMessage = @"Seller1Firstname Seller1Lastname and Seller2Firstname Seller2Lastname and Seller2SpouseName Seller2Lastname";
                ExpectedMessage = "SellerName SellerLastName";
                Support.AreEqual(ExpectedMessage, FastDriver.PayoffLoanParites.TrustorMortgagor.FAGetText());
                FastDriver.PayoffLoanParites.BeneficiaryMortgageeRefresh.Click();
                ExpectedMessage = @"Assumption Lender 2 for HUD Test Name 1, Assumption Lender 2 for HUD Test Name 2";
                Support.AreEqual(ExpectedMessage, FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FAGetText());
                #endregion
                #region Click on Done
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                #endregion
                #region Change the Business Party
                Reports.TestStep = "Change the Business Party";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad();
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "2", "#1", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryNew.Click();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(@"247");
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                #endregion
                #region Edit Payoffloan
                Reports.TestStep = "Edit Payoffloan";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Collection Payoff lender");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"900");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.SendKeys("^R");
                #endregion
                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                #endregion
                #region Enter Interest Calculation data
                Reports.TestStep = "Enter Interest Calculation data.";
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Fixed Rate");
                FastDriver.PayoffLoanCharges.InterestCalculationPerDiem.FASetCheckbox(true);
                FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FASetText(@"10.11");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(@"09-02-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FASelectItemBySendingKeys(@"365");
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(@"09-12-2012");
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FASetText(@"23.20");
                #endregion
                #region Change the Transaction Type to Refinance
                Reports.TestStep = "Change the Transaction type to Refinance.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(@"Refinance");
                //FastDriver.FileHomepage.TransactionType.SendKeys(FAKeys.Tab);
                //FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                //FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                //FastDriver.BottomFrame.Done();
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //FastDriver.FileHomepage.SwitchToContentFrame();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith();
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.FileHomepage.AcceptDialogAndCompareWith(SwitchToWindow: true);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0011 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0012() 
        {
            try
            {
                Reports.TestDescription = "Field_Validations: Verify for the various Field Definition for All the objects for the payoff loan instances.";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Enter data to verify the Payoff Loan Screen
                Reports.TestStep = "Enter data to verify the Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.CheckDetailsButton.Exists().ToString().ToLower());
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(@"HUDFLINSR12");
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.LenderFind.Exists().ToString().ToLower());
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                Support.AreEqual(@"", FastDriver.PayoffLoanDetails.LenderReference.FAGetText().ToString());
                Support.AreEqual(@"Institutional", FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem().ToString());
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"99999999999.9988");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                do
                {
                    FastDriver.PayoffLoanCharges.LoanChargesDescription.Click();
                    FastDriver.PayoffLoanCharges.LoanChargesDescription.SendKeys(Keys.Backspace);
                } 
                while (FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetText().Length > 0);
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText(@"LoanChargesDescriptionFieldAccepting45Characters");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"99,999,999,999.9988");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"99,999,999,999.9988");
                Support.AreEqual(@"", FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FAGetSelectedItem().ToString());
                Support.AreEqual(@"365", FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FAGetSelectedItem().ToString());
                FastDriver.PayoffLoanCharges.InterestCalculationChargeDesc.FASetText(@"InterestedCalculationDescription45FieldsAccepting");
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText(@"99,999,999,999.9988");
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCredit.FASetText(@"99,999,999,999.9988");
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FASetText(@"99,999,999,999.9988");
                FastDriver.PayoffLoanCharges.InterestCalculationSellerCredit.FASetText(@"99,999,999,999.9988");
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText(@"PayOffLoanChargesDescription45FieldsAcceptingChars");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"99,999,999,999.9988");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(@"99,999,999,999.9988");
                FastDriver.PayoffLoanCharges.PartiesTab.Click();
                FastDriver.PayoffLoanParites.WaitForScreeToLoan();
                FastDriver.PayoffLoanParites.TrustorMortgagor.FASetText("Accept 300 Alpha Numaric Characters FDHFHAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAKL LA AASDSDSDSADSADSDSDSA LAA AAAAAAAAAAAAAAAAAALKKKKKKKKKKKKKLLLLLLLLLLLLLAAAAAAAAA 3333333333333 66666666666666");
                FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FASetText(@"Flood Insurance 1 for HUD Testing Name 1, Flood Insurance 1 for HUD Testing Name 2-AAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAA LA AAAAAAAAAAAAAAAAAAAAAAAASSSSSSSSSSSSSSSSSSSSSSDKKKKKKKKKKKKKKKKKPPPPPPPPPPPPPPPSSSSSSSSSSSSSSS  SSSSSSSSSSSSSSSSSPKKKKKKKKKF 3333333333333333444444444444444444444 44444444444444444444444444444444 4 444444444444444 44444444444");
                FastDriver.PayoffLoanParites.TrusteeGABcode.FASetText(@"TRUSTEE");
                FastDriver.PayoffLoanParites.TrusteeGABcode.SendKeys("%F");
                FastDriver.PayoffLoanParites.RecordingTab.Click();
                FastDriver.PayoffLoanRecording.WaitForScreeToLoan();
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FASetText(@"09-13-2012");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FASetText(@"09-13-2012");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FASetText(@"123456789912345678901234577900993039039093940390");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FASetText(@"1234567899123456789978");
                FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FASetText(@"123456789978");
                #endregion
                #region Verifying for the data Entered
                Reports.TestStep = "Verifying for the data Entered";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                Support.AreEqual(@"$99,999,999,999.99", FastDriver.PayoffLoanCharges.PrincipalBalance.FAGetText(), "Verifying Principal Balance amount");
                Support.AreEqual(@"$99,999,999,999.99", FastDriver.PayoffLoanCharges.TotalCharges.FAGetText(), "Verifying Total Charges amount");
                Support.AreEqual(@"$199,999,999,999.98", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText(), "Verifying Payoff amount");
                Support.AreEqual(@"$299,999,999,999.97", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText(), "Verifying Check amount");
                FastDriver.PayoffLoanCharges.DetailsTab.Click();
                Support.AreEqual(@"", FastDriver.PayoffLoanDetails.LenderReference.FAGetText());
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Private Party");
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue(), "Verifying Original Principal Balance");
                FastDriver.PayoffLoanDetails.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(@"true", FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue().ToString().Contains("PayOffLoanChargesDescription45FieldsAccepting").ToString().ToLower(), "Verifying Loan Charges Description content");
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue(), "Verifying Buyer Charge amount");
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue(), "Verifying Seller Charge amount");
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys(@"Fixed Rate");
                Support.AreEqual(@"365", FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FAGetSelectedItem().ToString(), "Verifying Interest Calculation Based On Days value");
                Support.AreEqual(@"true", FastDriver.PayoffLoanCharges.InterestCalculationChargeDesc.FAGetValue().ToString().Contains("InterestedCalculationDescription45FieldsAccep").ToString().ToLower(), "Verifying Interest Calculation Description content");
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FAGetValue().ToString(), "Verifying Interest Calculation Buyer Charge amount");
                Support.AreEqual(@"", FastDriver.PayoffLoanCharges.InterestCalculationBuyerCredit.FAGetValue().ToString(), "Verifying Interest Calculation Buyer Credit amount");
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanCharges.InterestCalculationSellerCharge.FAGetValue().ToString(), "Verifying Interest Calculation Seller Charge");
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanCharges.InterestCalculationSellerCredit.FAGetValue().ToString(), "Verifying Interest Calculation Seller Credit");
                Support.AreEqual(@"true", FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue().ToString().Contains("PayOffLoanChargesDescription45FieldsAccepting").ToString().ToLower(), "Verifying Loan Charges Description content");
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().ToString(), "Verifying Loan Charges Buyer Charge amount");
                //Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.FAGetValue().ToString());
                Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().ToString(), "Verifying Loan Charges Seller Charge amount");
                //Support.AreEqual(@"99,999,999,999.99", FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.FAGetValue().ToString());
                FastDriver.PayoffLoanCharges.PartiesTab.FAClick();
                FastDriver.PayoffLoanParites.WaitForScreeToLoan();
                //Keyboard.SendKeys("%R");//TrustorMortgagor Refresh button
                FastDriver.PayoffLoanParites.TrustorMortgagorRefresh.FAClick();
                Support.AreEqual(@"SellerName SellerLastName", FastDriver.PayoffLoanParites.TrustorMortgagor.FAGetText().ToString());
                //Keyboard.SendKeys("%E");//TrustorMortgagor Refresh button
                FastDriver.PayoffLoanParites.BeneficiaryMortgageeRefresh.FAClick();
                Support.AreEqual(@"Flood Insurance 1 for HUD Testing Name 1, Flood Insurance 1 for HUD Testing Name 2", FastDriver.PayoffLoanParites.BeneficiaryMortgagee.FAGetText().ToString());
                FastDriver.PayoffLoanParites.RecordingTab.Click();
                FastDriver.PayoffLoanRecording.WaitForScreeToLoan();
                Support.AreEqual(@"09-13-2012", FastDriver.PayoffLoanRecording.PayoffLoanRecordingTrustDeedDate.FAGetValue(), "Verifying Recording Trust Deed Date value");
                Support.AreEqual(@"09-13-2012", FastDriver.PayoffLoanRecording.PayoffLoanRecordingRecordingDate.FAGetValue(), "Verifying Recording Recording Date value");
                Support.AreEqual(@"123456789912345678901234577900993039039093940390", FastDriver.PayoffLoanRecording.PayoffLoanRecordingInstrument.FAGetValue(), "Verifying Payoff Loan Recording Instrument value");
                Support.AreEqual(@"12345678991234567899", FastDriver.PayoffLoanRecording.PayoffLoanRecordingBook.FAGetValue(), "Verifying Payoff Loan Recording Book value");
                Support.AreEqual(@"1234567899", FastDriver.PayoffLoanRecording.PayoffLoanRecordingPage.FAGetValue(), "Verifying Payoff Loan Recording Page value");
                #endregion
                #region Clicking on the Payoff Loan Payment Details Button
                Reports.TestStep = "Clicking on the Payoff Loan Payment Details Button";
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.Click();
                #endregion
                #region Change the payment details methods to POC
                Reports.TestStep = "Change the payment details methods to POC.";
                if (IsFormTypeCD)
                {
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.BuyerAtClosing.FASetText(@"0");
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.SellerAtClosing.FASetText(@"0");
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.BuyerPaidbyOthersPayMethod.FASelectItemBySendingKeys(@"POC");
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.SellerPaidbyOthersPayMethod.FASelectItemBySendingKeys(@"POC");
                }
                else
                {
                    FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                    //Using PaymentDetailsNewLoanDlg PO because the Description element is not mapped w/ the same id 
                    //on the PaymentDetailsDlg PO
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys(@"POC");
                    FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItemBySendingKeys(@"POC");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Click on OK button
                if(IsFormTypeCD)
                {
                    Reports.TestStep = "Click on OK button";
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                #endregion
                #region Verifying for the pencil image after Change the payment mode
                Reports.TestStep = "Verifying for the pencil image after Change the payment mode";
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                //Support.AreEqual("true", FastDriver.PayoffLoanCharges.PencilImage.Exists().ToString().ToLower());//???
                #endregion
                #region Reset using Shortcut Keys
                Reports.TestStep = "Reset using Shortcut Keys";
                Keyboard.SendKeys("^R");
                #endregion
                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Delete using Shortcut Keys
                Reports.TestStep = "Delete using Shortcut Keys";
                Keyboard.SendKeys("{DELETE}");
                #endregion
                #region Click on Cancel button
                Reports.TestStep = "Click on Cancel button";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region New using Shortcut Keys
                Reports.TestStep = "New using Shortcut Keys";
                Keyboard.SendKeys("^N");
                #endregion
                #region To create 2nd New Payoff Loan Instance Creation and save
                Reports.TestStep = "To create 2nd New Payoff Loan Instance Creation and save";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode(@"HUDASLNDR2");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys(@"Institutional");
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"800");
                FastDriver.BottomFrame.Done();                   
                #endregion
                #region Select First Instance and Clicking on Edit-Using Sendkeys
                Reports.TestStep = "Select First Instance and Clicking on Edit-Using Sendkeys";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad(timeout: 10);
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryEdit.Click();
                #endregion
                #region Edit PayoffLoan
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FASetText(@"700");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"650");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Select First Instance and Clicking on Delete
                Reports.TestStep = "Select First Instance and Clicking on Delete";
                FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad(timeout: 10);
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("#1", "1", "#3", TableAction.Click);
                FastDriver.PayoffLoanSummary.LoanSummaryRemove.Click();
                #endregion
                #region Click on Ok button
                Reports.TestStep = "Click on Ok button";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Verifying the Deletion on Instance using Sendkeys
                Reports.TestStep = "Verifying the Deletion on Instance using Sendkeys";
                FastDriver.PayoffLoanSummary.WaitForScreenToLoad(timeout: 10); 
                FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Available", "#1", TableAction.Click);
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0012 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0013_PH()
        {
            try
            {
                Reports.TestDescription = "2388_3527_3528_3529_3530_IF13220_IF13221_IF13222_IF13223_IF13224_IF13225_IF13226_IF13227: Verify These BRs Manually.";
                Reports.TestStep = "Dummy subtest to use it as a Place holder for Non Automated scenarios.";
                Support.AreEqual("true", "false");//set it to fail, so manual team will look at it
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0013_PH failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0014() 
        {
            try
            {
                Reports.TestDescription = "1895_3795_3796_AF6 Create PayOff Loan_Update PayOff Loan_Demand PayOff Loan";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "REFI";//REFINANCE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Enter data to verify the Payoff Loan Screen
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(@"HUDFLINSR12");
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.LoanChargesTable.FAGetText().Contains("Borrower Charge").ToString().ToLower());//verify the column exists
                #endregion
                #region Update Payoff Amount
                Reports.TestStep = "Update Payoff Amount";
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("10");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FASetText("20");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.PayoffAmount.FAGetText().Contains("30").ToString().ToLower());
                #endregion
                #region Update Check Amount
                Reports.TestStep = "Update Check Amount";
                Support.AreEqual("true", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().Contains("30").ToString().ToLower());
                #endregion
                #region Change the payment method to CHK and verify the check amount
                Reports.TestStep = "Change the payment method to CHK and verify the check amount";
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.Click();                
                #endregion
                #region Change the payment details methods to POC
                Reports.TestStep = "Change the payment details methods to POC";
                if (IsFormTypeCD)
                {
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.WaitForScreenToLoad();
                    FastDriver.PaymentDetailsPayoffLoanLoanChargesDlg.BuyerPaidbyOthersPayMethod.FASelectItemBySendingKeys(@"POC");
                }
                else
                {
                    FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                    //Using PaymentDetailsNewLoanDlg PO because the Description element is not mapped w/ the same id 
                    //on the PaymentDetailsDlg PO
                    FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItemBySendingKeys(@"POC");
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                if(IsFormTypeCD)
                {
                    Support.AreEqual("true", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().Contains("30").ToString().ToLower());
                }
                else
                {
                    Support.AreEqual("true", FastDriver.PayoffLoanCharges.CheckAmt.FAGetText().Contains("10").ToString().ToLower());
                }
                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0014 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0015() 
        {
            try
            {
                Reports.TestDescription = "AL6_AL7_AL8 Request Payoff demand statement";
                #region ADMLOGIN
                _ADMLOGIN();
                #endregion
                #region Search a GAB in Address Book and click on Edit button
                Reports.TestStep = "Search a GAB in Address Book and click on Edit button.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>(@"Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.WaitForScreenToLoad();
                FastDriver.AddressBookSearch.EntityType.FASelectItemBySendingKeys("Lender");
                FastDriver.AddressBookSearch.EntityID.FASetText("ELENDER");
                FastDriver.AddressBookSearch.Find.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout:10);//Found more than 300 records.A maximum of 300 records will be displayed.In order to have less records please provide more data for search.
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AddressBookSearch.WaitForSearchResultsToLoad();
                FastDriver.AddressBookSearch.SwitchToContentFrame();
                //FastDriver.AddressBookSearch.EditAddress(@"ELENDER");
                FastDriver.AddressBookSearch.SearchResults.PerformTableAction(7, @"ELENDER", 1, TableAction.Click);
                FastDriver.AddressBookSearch.Edit.FAClick();
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
                FastDriver.BusPartyOrgSetUp.CorporateParent.FASelectItemBySendingKeys("Wells Fargo");
                FastDriver.BusPartyOrgSetUp.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region AL6_AL7_AL8
                Reports.TestStep = "AL6_AL7_AL8";
                #region Initialize Variables
                bool IsFormTypeCD = false;
                string ExpectedMessage, ActualMessage = "";
                string today = DateTime.Now.Date.ToString("MM/dd/yyyy");
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create an order with Seller's broker and Seller's Attorney as additional role
                Reports.TestStep = "Create an order with Seller's broker and Seller's Attorney as additional role.";
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            {   
                                
                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",  
                                City = "ALBANY", 
                                County = "ALAMEDA", 
                                Zip = "92707"
                            } 
                        } 
                    } 
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                IsFormTypeCD = customizableFileRequest.formType.ToString().Equals(@"CD");
                #endregion
                #region Update DirectedBy section
                Reports.TestStep = "Update DirectedBy section";
                var updateRequest = new UpdateFileRequest()
                {
                    FileID = _file.FileID,
                    Source = "famos",
                    Target = "fast",
                    UpdateProductAndSearchType = false,
                    UseLatestGabVersion = false,
                    formType = FormType.CD,
                    File = new File()
                    {
                        BusinessParties = new FileBusinessParty[] { 
                            new FileBusinessParty(){
                                AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDLEASE03"),
                                RoleTypeObjectCD = "DirectedBy",
                                RoleTypeCdID = 691, 
                                AdditionalRole = new AdditionalRoleList(){
                                    eAddtionalRole = AdditionalRoleType.SellersBroker
                                },
                            }
                        }
                    },

                };
                var response = FileService.UpdateOrderDetails(updateRequest);
                Support.AreEqual("Successfully Updated.", response.OperationResponse.StatusDescription.ToString());
                #endregion
                #region Enter data to verify the Payoff Loan Screen
                Reports.TestStep = "Enter data to verify the Payoff Loan Screen.";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
                Playback.Wait(2000);
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.EntityType, 10);
                FastDriver.AddressBookSearchDlg.EntityType.FASelectItemBySendingKeys(@"Lender");
                FastDriver.AddressBookSearchDlg.IDCode.FASetText(@"ELENDER");
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.Find);
                FastDriver.AddressBookSearchDlg.Find.Click();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 10);//Found more than 300 records.A maximum of 300 records will be displayed.In order to have less records please provide more data for search.
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
                FastDriver.AddressBookSearchDlg.SwitchToDialogContentFrame();
                FastDriver.AddressBookSearchDlg.WaitCreation(FastDriver.AddressBookSearchDlg.SearchResultsTable);
                try
                {
                    FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("#7", "ELENDER", "#1", TableAction.Click);
                    Support.AreEqual("true", FastDriver.AddressBookSearchDlg.SearchResultsTable.PerformTableAction("#7", "ELENDER", "#1", TableAction.GetAttribute, "selected").Message.ToString().ToLower());
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Could not find the value HUDASLNDR1 on the Search Results table", false);
                }
                FastDriver.AddressBookSearchDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick(); 
               
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.LenderReference); //.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderReference.FASetText(@"0987654321");
                FastDriver.BottomFrame.Done();
                
                ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, timeout: 15);
                ExpectedMessage = @"Automatic Payoff Demand Request Initiated";
                Support.AreEqual(ExpectedMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.RequestDemandStatement); //.SwitchToContentFrame();
                if(!FastDriver.PayoffLoanDetails.RequestDemandStatement.Enabled)
                {
                    Playback.Wait(10000);//Sometimes the button takes a loooong time to get enabled...
                    FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                }
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad(FastDriver.PayoffLoanDetails.RequestDemandStatement); //.SwitchToContentFrame();
                Reports.TestStep = "Verify Request Demand Statement button is enabled"; 
                FastDriver.PayoffLoanDetails.RequestDemandStatement.SendKeys("");
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.RequestDemandStatement.Enabled.ToString().ToLower());
                FastDriver.PayoffLoanDetails.RequestDemandStatement.FAClick();
                //The "RequestDemandStatement button is enabled through a process that takes several minutes...
                //These are the rules:
                //a) Button will be available if Payoff Lneder is 'eEnabled' for Payoff Request automation and the 'Restrict Automatic Updates' checkbox on Payoff Loan screen is de-selected.
                //b) Button disabled if Payoff lender is NOT 'eEnabled' or if 'Restrict Automatic Updates' checkbox is selected
                //c) Button is disabled while request is being processed
                //d) Button is disabled if Lender returns failed message indicating loan is not eligible for Automated Payoff Demand Request process.
                
                FastDriver.PayoffDemandManualRequestDlg.WaitForScreenToLoad();
                FastDriver.PayoffDemandManualRequestDlg.Date.FASetText(today);
                FastDriver.PayoffDemandManualRequestDlg.OK.Click();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to Event Tracking log
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();
                try
                {
                    Support.AreEqual("true", FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Payoff Demand Request Initiated").ToString().ToLower());
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("Could not find the value \"Payoff Demand Request Initiated\" on the Search Results table", false);
                }
                #endregion
                #endregion
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0016()
        {
            try
            {
                Reports.TestDescription = "To ensure that the details are populated in Response object returned by GetPayoffloandetails service, when no data enterted in PDD of payoffloan charges.";
                #region Login and create file
                Reports.TestStep = "Login to IIS";
                _IISLOGIN();
                Reports.TestStep = "Create file";
                Dictionary<string, int> FileData = CreateFile();
                #endregion
                #region Enter charges to Payoff loan
                Reports.TestStep = "Create Instance of Payoff loan and enter data";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys("");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Click();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }

                FastDriver.BottomFrame.Done();
                #endregion             
                #region Invoke GetPayoffLoanDetails service
                Reports.TestStep = "Invoke GetPayoffLoanDetails service to get the details of Payoff Loan instance";
                var Request = EscrowRequestFactory.GetServiceFileRequest(Convert.ToInt32(FileData["FileId"]));
                var PayOffRes = FASTWCFHelpers.EscrowService.GetPayoffLoanDetails(Request);
                #endregion
                #region Validate the details
                Reports.TestStep = "Validate the details of Payoff Loan instance";
                if (AutoConfig.FormType.Equals("CD"))
                {
                    Support.AreEqual("0", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCharge.ToString());
                    Support.AreEqual("0", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCredit.ToString());
                    Support.AreEqual("AtClosing", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCreditPaymentMethodTypeCdID.ToString());
                    Support.AreEqual("CHK", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].AtClosingBuyerPaymentMethodTypeID.ToString());
                    Support.AreEqual("0", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCharge.ToString());
                    Support.AreEqual("0", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCredit.ToString());
                    Support.AreEqual("AtClosing", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCreditPaymentMethodTypeCdID.ToString());
                    Support.AreEqual("CHK", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].AtClosingSellerPaymentMethodTypeID.ToString());
                }
                else
                {
                    Support.AreEqual("0", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].BuyerCharge.ToString());
                    Support.AreEqual("384", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].BuyerPaymentMethodTypeID.ToString()); //384 for CHK
                    Support.AreEqual("0", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].SellerCharge.ToString());
                    Support.AreEqual("384", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].SellerPaymentMethodTypeID.ToString());
                }
                #endregion
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0017()
        {
            try
            {
                Reports.TestDescription = "To ensure that the details are populated in Response object returned by GetPayoffloandetails service, with data enterted in PDD of payoffloan charges";
                #region Login and create file
                Reports.TestStep = "Login to IIS";
                _IISLOGIN();
                Reports.TestStep = "Create file";
                Dictionary<string, int> FileData = CreateFile();
                #endregion
                #region Enter charges to Payoff loan
                Reports.TestStep = "Create Instance of Payoff loan and enter data";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys("");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Click();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                FastDriver.BottomFrame.Done();
                #endregion
                #region Enter Pay off loan charges in PDD
                Reports.TestStep = "Enter Pay off loan charges in PDD";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                string BuyerCharge = string.Empty;
                string SellerCharge = string.Empty;
                string BuyerCredit = string.Empty;
                string SellerCredit = string.Empty;
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                if (AutoConfig.FormType.Equals("CD"))
                {
                    PaymentDetailsParameters PDParams = new PaymentDetailsParameters();
                    PDParams.SellerPaidAtClosing = 10;
                    PDParams.SellerPaidBeforeClosing = 5;
                    PDParams.SellerCredit = 1;
                    PDParams.BuyerAtClosing = 10;
                    PDParams.BuyerBeforeClosing = 5;
                    PDParams.BuyerCredit = 1;
                    //PDParams.
                    FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDParams);
                    FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                    BuyerCharge = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message;
                    SellerCharge = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message;
                    BuyerCredit = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message;
                    SellerCredit = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 6, TableAction.GetInputValue).Message;
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    if (FastDriver.PaymentDetailsDlg.BuyerCharge.IsEnabled())
                        FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("15");

                    if (FastDriver.PaymentDetailsDlg.SellerCharge.IsEnabled())
                        FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("15");
                    if (FastDriver.PaymentDetailsDlg.BuyerCredit.IsEnabled())
                        FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1");
                    if (FastDriver.PaymentDetailsDlg.SellerCredit.IsEnabled())
                        FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("1" + Keys.Tab);

                    BuyerCharge = string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim()) ? "" : FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue();
                    SellerCharge = string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim()) ? "" : FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue();
                    BuyerCredit = string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim()) ? "" : FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue();
                    SellerCredit = string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim()) ? "" : FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue();
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                FastDriver.BottomFrame.Done();
                Thread.Sleep(7000);
                #endregion
                #region Invoke GetPayoffLoanDetails service
                Reports.TestStep = "Invoke GetPayoffLoanDetails service to get the details of Payoff Loan instance";
                var Request = EscrowRequestFactory.GetServiceFileRequest(Convert.ToInt32(FileData["FileId"]));
                var PayOffRes = FASTWCFHelpers.EscrowService.GetPayoffLoanDetails(Request);
                #endregion
                #region Validate the details
                Reports.TestStep = "Validate the details of Payoff Loan instance";
                if (!string.IsNullOrEmpty(BuyerCharge))
                    BuyerCharge = BuyerCharge.Contains(".00") ? BuyerCharge.Replace(".00", " ").Trim() : BuyerCharge;
                else BuyerCharge = "0";
                if (!string.IsNullOrEmpty(BuyerCredit))
                    BuyerCredit = BuyerCredit.Contains(".00") ? BuyerCredit.Replace(".00", " ").Trim() : BuyerCredit;
                else BuyerCredit = "0";
                if (!string.IsNullOrEmpty(SellerCharge))
                    SellerCharge = SellerCharge.Contains(".00") ? SellerCharge.Replace(".00", " ").Trim() : SellerCharge;
                else SellerCharge = "0";
                if (!string.IsNullOrEmpty(SellerCredit))
                    SellerCredit = SellerCredit.Contains(".00") ? SellerCredit.Replace(".00", " ").Trim() : SellerCredit;
                else SellerCredit = "0";
                if (AutoConfig.FormType.Equals("CD"))
                {
                    Support.AreEqual(BuyerCharge, PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCharge.ToString());
                    Support.AreEqual("1", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCredit.ToString());
                    Support.AreEqual("AtClosing", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCreditPaymentMethodTypeCdID.ToString());
                    Support.AreEqual("CHK", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].AtClosingBuyerPaymentMethodTypeID.ToString());
                    Support.AreEqual(SellerCharge, PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCharge.ToString());
                    Support.AreEqual("1", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCredit.ToString());
                    Support.AreEqual("AtClosing", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCreditPaymentMethodTypeCdID.ToString());
                    Support.AreEqual("CHK", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].AtClosingSellerPaymentMethodTypeID.ToString());
                }
                else
                {
                    // FASTWCFHelpers.FastEscrowService.PaymentMethodType Pay = new FASTWCFHelpers.FastEscrowService.PaymentMethodType();
                    //string a= Pay.ToString();
                    Support.AreEqual(BuyerCharge, PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].BuyerCharge.ToString());
                    Support.AreEqual("384", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].BuyerPaymentMethodTypeID.ToString()); //384 for CHK
                    Support.AreEqual(SellerCharge, PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].SellerCharge.ToString());
                    Support.AreEqual("384", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].SellerPaymentMethodTypeID.ToString());
                }

                #endregion
            }
            catch (Exception e)
            {
                FailTest("Test case FMUC0048_REG0015 failed because " + e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0018()
        {
            try
            {
                Reports.TestDescription = "To ensure that the details are populated in xml pulled using GetPayoffloandetails service, with new party added in Pay charge disbursement screen (CD).";
                #region Login and create file
                Reports.TestStep = "Login to IIS";
                _IISLOGIN();
                Reports.TestStep = "Create file";
                Dictionary<string, int> FileData = CreateFile();
                #endregion
                #region Enter charges to Payoff loan
                Reports.TestStep = "Create Instance of Payoff loan and enter data";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys("");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Click();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }

                FastDriver.BottomFrame.Done();
                #endregion
                #region Enter Pay off loan charges in PDD
                Reports.TestStep = "Enter Pay off loan charges in PDD";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                double? BuyerCharge = 0.00;
                double? SellerCharge =0.00;
                double? BuyerCredit = 0.00;
                double? SellerCredit =0.00;
                double? BuyerChargeBeforeClosing = 0.00;
                double? SellerChargeBeforeClosing = 0.00;
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                if (AutoConfig.FormType.Equals("CD"))
                {
                    PaymentDetailsParameters PDParams = new PaymentDetailsParameters();
                    PDParams.SellerPaidAtClosing = 10.12;
                    PDParams.SellerPaidBeforeClosing = 5.11;
                    PDParams.SellerCredit = 1.11;
                    PDParams.BuyerAtClosing = 10.11;
                    PDParams.BuyerBeforeClosing = 5.11;
                    PDParams.BuyerCredit = 1.11;
                    //PDParams.
                    FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDParams);
                    FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                    BuyerCharge = Convert.ToDouble(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message);
                    SellerCharge = Convert.ToDouble(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message);
                    BuyerCredit = Convert.ToDouble(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message);
                    SellerCredit = Convert.ToDouble(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 6, TableAction.GetInputValue).Message);
                     SellerChargeBeforeClosing = PDParams.SellerPaidBeforeClosing;
                     BuyerChargeBeforeClosing = PDParams.BuyerBeforeClosing;
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    if (FastDriver.PaymentDetailsDlg.BuyerCharge.IsEnabled())
                        FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("10.12");
                    if (FastDriver.PaymentDetailsDlg.SellerCharge.IsEnabled())
                        FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("10.11");
                    if (FastDriver.PaymentDetailsDlg.BuyerCredit.IsEnabled())
                        FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1.11");
                    if (FastDriver.PaymentDetailsDlg.SellerCredit.IsEnabled())
                        FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("1.11");
                    BuyerCharge =  Convert.ToDouble(string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim()) ? "0" : FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                    SellerCharge=  Convert.ToDouble(string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim()) ? "0" : FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                    BuyerCredit =  Convert.ToDouble(string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim()) ? "0" : FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue());
                    SellerCredit=  Convert.ToDouble(string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim()) ? "0" : FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue());
                    FastDriver.DialogBottomFrame.ClickDone();
                    Thread.Sleep(2000);
                }
                #endregion
                #region Associate payoff loan charge to payee
                Reports.TestStep = "Click on pay charges button";
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayChargesBtn.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Reports.TestStep = "Associate payoff loan charge to payee";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                Reports.TestStep = "Navigate to active disbursement screen"; //incomplete
                FastDriver.ActiveDisbursementSummary.Open();
                bool Status = false;
                string value="";
                if(AutoConfig.FormType.Equals("CD"))
                     value=@"18.01";
                else
                     value=@"10.11";

                if (FastDriver.ActiveDisbursementSummary.Disbursements.FAGetText().Contains(value))
                {
                    Status = FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", value, "Status", TableAction.Click).Status.ToString().Contains("Success");
                }
                Support.AreEqual(Status.ToString(), "True");
                //FastDriver.Tab.DisbursementChargesTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                Reports.TestStep = "Navigate to pay off loan screen";
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayChargesBtn.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, 1, TableAction.Off);
                FastDriver.BottomFrame.Done();                
                #endregion
                #region Invoke GetPayoffLoanDetails service
                Reports.TestStep = "Invoke GetPayoffLoanDetails service to get the details of Payoff Loan instance";
                var Request = EscrowRequestFactory.GetServiceFileRequest(Convert.ToInt32(FileData["FileId"]));
                var PayOffRes = FASTWCFHelpers.EscrowService.GetPayoffLoanDetails(Request);
                #endregion
                #region Validate the details
                Reports.TestStep = "Validate the details of Payoff Loan instance in web service response";

                if (AutoConfig.FormType.Equals("CD"))
                {
                    double? CheckAmount = BuyerCharge-BuyerChargeBeforeClosing +SellerCharge-BuyerChargeBeforeClosing - BuyerCredit - SellerCredit;
                    Support.AreEqual("Assumption Lender 1 for HUD Test Name 1", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].PayeeNameOnCDOrSettlementStmt.ToString());
                                        Support.AreEqual(CheckAmount.ToString(), PayOffRes.PayOffLoanSummary[0].Recap.CheckAmount.ToString());

                    Support.AreEqual(BuyerCharge.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCharge.ToString());
                    Support.AreEqual(BuyerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCredit.ToString());
                    Support.AreEqual("AtClosing", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCreditPaymentMethodTypeCdID.ToString());
                    Support.AreEqual("CHK", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].AtClosingBuyerPaymentMethodTypeID.ToString());
                    Support.AreEqual(SellerCharge.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCharge.ToString());
                    Support.AreEqual(SellerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCredit.ToString());
                    Support.AreEqual("AtClosing", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCreditPaymentMethodTypeCdID.ToString());
                    Support.AreEqual("CHK", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].AtClosingSellerPaymentMethodTypeID.ToString());
                    //
                    Support.AreEqual(CheckAmount.ToString(),PayOffRes.PayOffLoanSummary[0].Recap.CheckAmount.ToString());
                    Reports.TestStep = "Validate disbursement charges";
                    Support.AreEqual((Convert.ToDouble(BuyerCharge)-BuyerChargeBeforeClosing).ToString(), PayOffRes.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[0].BuyerCharge.ToString());
                    Support.AreEqual((Convert.ToDouble(SellerCharge) - SellerChargeBeforeClosing).ToString(), PayOffRes.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[0].SellerCharge.ToString());
                    Support.AreEqual(BuyerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[0].BuyerCredit.ToString());
                    Support.AreEqual(SellerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[0].SellerCredit.ToString());
                }
                else
                {
                    // FASTWCFHelpers.FastEscrowService.PaymentMethodType Pay = new FASTWCFHelpers.FastEscrowService.PaymentMethodType();
                    Double CheckAmount = Convert.ToDouble(BuyerCharge) + Convert.ToDouble(SellerCharge) - Convert.ToDouble(BuyerCredit) - Convert.ToDouble(SellerCredit);
                    Support.AreEqual(BuyerCharge.ToString().Equals("0.0")?"0":BuyerCharge.ToString(), PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].BuyerCharge.ToString());
                    Support.AreEqual("384", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].BuyerPaymentMethodTypeID.ToString()); //384 for CHK
                    Support.AreEqual(SellerCharge.ToString().Equals("0.0")?"0":SellerCharge.ToString(), PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].SellerCharge.ToString());
                    Support.AreEqual("384", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].SellerPaymentMethodTypeID.ToString());
                    //
                    Reports.TestStep = "Validate disbursement charges";
                    Support.AreEqual((Convert.ToDouble(BuyerCharge) - BuyerChargeBeforeClosing).ToString(), PayOffRes.PayOffLoanSummary[0].PayCharges.DisbursementCharges[0].BuyerCharge.ToString());
                    Support.AreEqual(BuyerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].PayCharges.DisbursementCharges[0].BuyerCredit.ToString());
                    Support.AreEqual((Convert.ToDouble(SellerCharge) - SellerChargeBeforeClosing).ToString(), PayOffRes.PayOffLoanSummary[0].PayCharges.DisbursementCharges[0].SellerCharge.ToString());
                    Support.AreEqual(SellerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].PayCharges.DisbursementCharges[0].SellerCredit.ToString());
                    Support.AreEqual(CheckAmount.ToString(), PayOffRes.PayOffLoanSummary[0].Recap.CheckAmount.ToString());

                }
                #endregion
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0019()
        {
                Reports.TestDescription = "To ensure that the details are populated in Response object returned by GetPayoffloandetails service, when a payoffloan charge is deselected from third party (CD)..";
                #region Login and create file
                Reports.TestStep = "Login to IIS";
                _IISLOGIN();
                Reports.TestStep = "Create file";
                Dictionary<string, int> FileData = CreateFile();
                #endregion
                #region Enter charges to Payoff loan
                Reports.TestStep = "Create Instance of Payoff loan and enter data";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys("");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Click();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }

                FastDriver.BottomFrame.Done();
                #endregion
                #region Enter Pay off loan charges in PDD
                Reports.TestStep = "Enter Pay off loan charges in PDD";
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                double? BuyerCharge = 0.00;
                double? SellerCharge = 0.00;
                double? BuyerCredit = 0.00;
                double? SellerCredit = 0.00;
                double? BuyerChargeBeforeClosing = 0.00;
                double? SellerChargeBeforeClosing = 0.00;
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                if (AutoConfig.FormType.Equals("CD"))
                {
                    PaymentDetailsParameters PDParams = new PaymentDetailsParameters();
                    PDParams.SellerPaidAtClosing = 10.12;
                    PDParams.SellerPaidBeforeClosing = 5.11;
                    PDParams.SellerCredit = 1.11;
                    PDParams.BuyerAtClosing = 10.11;
                    PDParams.BuyerBeforeClosing = 5.11;
                    PDParams.BuyerCredit = 1.11;
                    //PDParams.
                    FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDParams);
                    FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                    BuyerCharge = Convert.ToDouble(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message);
                    SellerCharge = Convert.ToDouble(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message);
                    BuyerCredit = Convert.ToDouble(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message);
                    SellerCredit = Convert.ToDouble(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 6, TableAction.GetInputValue).Message);
                    SellerChargeBeforeClosing = PDParams.SellerPaidBeforeClosing;
                    BuyerChargeBeforeClosing = PDParams.BuyerBeforeClosing;
                }
                else
                {
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                    if (FastDriver.PaymentDetailsDlg.BuyerCharge.IsEnabled())
                        FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("10.12");
                    if (FastDriver.PaymentDetailsDlg.SellerCharge.IsEnabled())
                        FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("10.11");
                    if (FastDriver.PaymentDetailsDlg.BuyerCredit.IsEnabled())
                        FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1.11");
                    if (FastDriver.PaymentDetailsDlg.SellerCredit.IsEnabled())
                        FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("1.11");
                    BuyerCharge = Convert.ToDouble(string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim()) ? "0" : FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue());
                    SellerCharge = Convert.ToDouble(string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim()) ? "0" : FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue());
                    BuyerCredit = Convert.ToDouble(string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim()) ? "0" : FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue());
                    SellerCredit = Convert.ToDouble(string.IsNullOrEmpty(FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim()) ? "0" : FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue());
                    FastDriver.DialogBottomFrame.ClickDone();
                    Thread.Sleep(2000);
                }
                #endregion
                #region Associate payoff loan charge to payee
                Reports.TestStep = "Click on pay charges button";
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayChargesBtn.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Reports.TestStep = "Associate payoff loan charge to payee";
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                #endregion
                #region Invoke GetPayoffLoanDetails service
                Reports.TestStep = "Invoke GetPayoffLoanDetails service to get the details of Payoff Loan instance";
                var Request = EscrowRequestFactory.GetServiceFileRequest(Convert.ToInt32(FileData["FileId"]));
                var PayOffRes = FASTWCFHelpers.EscrowService.GetPayoffLoanDetails(Request);
                #endregion
                #region Validate the details
                Reports.TestStep = "Validate the details of Payoff Loan instance in web service response";
                if (AutoConfig.FormType.Equals("CD"))
                {
                    double? CheckAmount = BuyerCharge - BuyerChargeBeforeClosing + SellerCharge - BuyerChargeBeforeClosing - BuyerCredit - SellerCredit;
                    Support.AreEqual("Assumption Lender 1 for HUD Test Name 1", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].PayeeNameOnCDOrSettlementStmt.ToString());
                    Support.AreEqual(CheckAmount.ToString(), PayOffRes.PayOffLoanSummary[0].Recap.CheckAmount.ToString());

                    Support.AreEqual(BuyerCharge.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCharge.ToString());
                    Support.AreEqual(BuyerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCredit.ToString());
                    Support.AreEqual("AtClosing", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].BuyerCreditPaymentMethodTypeCdID.ToString());
                    Support.AreEqual("CHK", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].AtClosingBuyerPaymentMethodTypeID.ToString());
                    Support.AreEqual(SellerCharge.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCharge.ToString());
                    Support.AreEqual(SellerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCredit.ToString());
                    Support.AreEqual("AtClosing", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].SellerCreditPaymentMethodTypeCdID.ToString());
                    Support.AreEqual("CHK", PayOffRes.PayOffLoanSummary[0].CDPayoffLoanCharges[0].AtClosingSellerPaymentMethodTypeID.ToString());
                    //
                    Support.AreEqual(CheckAmount.ToString(), PayOffRes.PayOffLoanSummary[0].Recap.CheckAmount.ToString());
                    Reports.TestStep = "Validate disbursement charges";
                    Support.AreEqual((Convert.ToDouble(BuyerCharge) - BuyerChargeBeforeClosing).ToString(), PayOffRes.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[0].BuyerCharge.ToString());
                    Support.AreEqual((Convert.ToDouble(SellerCharge) - SellerChargeBeforeClosing).ToString(), PayOffRes.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[0].SellerCharge.ToString());
                    Support.AreEqual(BuyerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[0].BuyerCredit.ToString());
                    Support.AreEqual(SellerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[0].SellerCredit.ToString());
                }
                else
                {
                    // FASTWCFHelpers.FastEscrowService.PaymentMethodType Pay = new FASTWCFHelpers.FastEscrowService.PaymentMethodType();
                    Double CheckAmount = Convert.ToDouble(BuyerCharge) + Convert.ToDouble(SellerCharge) - Convert.ToDouble(BuyerCredit) - Convert.ToDouble(SellerCredit);
                    Support.AreEqual(BuyerCharge.ToString().Equals("0.0") ? "0" : BuyerCharge.ToString(), PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].BuyerCharge.ToString());
                    Support.AreEqual("384", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].BuyerPaymentMethodTypeID.ToString()); //384 for CHK
                    Support.AreEqual(SellerCharge.ToString().Equals("0.0") ? "0" : SellerCharge.ToString(), PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].SellerCharge.ToString());
                    Support.AreEqual("384", PayOffRes.PayOffLoanSummary[0].PayoffLoanCharges[0].SellerPaymentMethodTypeID.ToString());
                    //
                    Reports.TestStep = "Validate disbursement charges";
                    Support.AreEqual((Convert.ToDouble(BuyerCharge) - BuyerChargeBeforeClosing).ToString(), PayOffRes.PayOffLoanSummary[0].PayCharges.DisbursementCharges[0].BuyerCharge.ToString());
                    Support.AreEqual(BuyerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].PayCharges.DisbursementCharges[0].BuyerCredit.ToString());
                    Support.AreEqual((Convert.ToDouble(SellerCharge) - SellerChargeBeforeClosing).ToString(), PayOffRes.PayOffLoanSummary[0].PayCharges.DisbursementCharges[0].SellerCharge.ToString());
                    Support.AreEqual(SellerCredit.ToString(), PayOffRes.PayOffLoanSummary[0].PayCharges.DisbursementCharges[0].SellerCredit.ToString());
                    Support.AreEqual(CheckAmount.ToString(), PayOffRes.PayOffLoanSummary[0].Recap.CheckAmount.ToString());

                }
                #endregion
        }
        [TestMethod]
        public void FMUC0048_REG0020()
        {
            Reports.TestDescription = "To ensure that the users are able to set pay of loan charge to third party using the webservice.";
            try
            {
                #region Login and create file
                Reports.TestStep = "Login to IIS";
                _IISLOGIN();
                Reports.TestStep = "Create file";
                Dictionary<string, int> FileData = CreateFile();
                #endregion
                #region Enter charges to Payoff loan
                Reports.TestStep = "Create Instance of Payoff loan and enter data";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys("");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Click();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                #endregion
                #region Enter Pay off loan charges in PDD
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                PaymentDetailsParameters PDParams = new PaymentDetailsParameters();
                PDParams.SellerPaidAtClosing = 10.12;
                PDParams.SellerPaidBeforeClosing = 5.11;
                PDParams.SellerCredit = 1.11;
                PDParams.BuyerAtClosing = 10.11;
                PDParams.BuyerBeforeClosing = 5.11;
                PDParams.BuyerCredit = 1.11;
                EnterPayOffLoanDetailsInPDD(PDParams);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                PaymentDetailsParameters PDParams1 = new PaymentDetailsParameters();
                PDParams1.SellerPaidAtClosing = 14.12;
                PDParams1.SellerPaidBeforeClosing = 6.11;
                PDParams1.SellerCredit = 3.11;
                PDParams1.BuyerAtClosing = 14.11;
                PDParams1.BuyerBeforeClosing = 6.11;
                PDParams1.BuyerCredit = 3.11;
                EnterPayOffLoanDetailsInPDD(PDParams1);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                #endregion

                #region Invoke GetPayoffLoanDetails service
                Reports.TestStep = "Invoke GetPayoffLoanDetails service to get the details of Payoff Loan instance";
                var Request = EscrowRequestFactory.GetServiceFileRequest(Convert.ToInt32(FileData["FileId"]));
                var PayOffResDetails = FASTWCFHelpers.EscrowService.GetPayoffLoanDetails(Request);
                #endregion
                #region Variables
                   var cdPyoffLnpayoffloancharges = PayOffResDetails.PayOffLoanSummary[0].CDPayoffLoanCharges;
                   var PyoffLnpayoffloancharges = PayOffResDetails.PayOffLoanSummary[0].PayoffLoanCharges;
                #endregion
                #region Associate PayoffLoan charges using to payee web service
                Reports.TestStep = "Associate PayoffLoan charges using to payee web service";
                int? AddrBookEntryID = 8835211; //GAB 230
                int? ChargeID = AutoConfig.FormType.Equals("CD")?PayOffResDetails.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[1].ChargeID:PayOffResDetails.PayOffLoanSummary[0].PayCharges.DisbursementCharges[1].ChargeID;
                //
                FASTWCFHelpers.FastEscrowService.PayOffLoanPayChargeAssociationRequest PayChargeAssociationRequest = EscrowRequestFactory.PayOffLoanPayChargesAssociationReq(Convert.ToInt32(FileData["FileId"]),AddrBookEntryID,ChargeID);                
                FASTWCFHelpers.FastEscrowService.OperationResponse PayChargesAssociationRes = EscrowService.PayOffLoanPayChargesAssociation(PayChargeAssociationRequest);
                Support.AreEqual("1", PayChargesAssociationRes.Status.ToString(), PayChargesAssociationRes.StatusDescription);
                #endregion
                #region Verify PayoffLoan details in FAST
                Reports.TestStep = "Verify PayoffLoan details in FAST";
                FastDriver.PayoffLoanDetails.Open();
                //Support.AreEqual(cdPrincipalBalanceAmt.ToString(), FastDriver.PayoffLoanDetails.PrincipalBalanceAmt.FAGetText() ?? "", "PayoffLoanDetails.PrincipalBalanceAmt");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayChargesBtn.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(3, 1, TableAction.Click);
                Thread.Sleep(3000);
                int Row = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Description", @"Reconveyance Fee", "Description", TableAction.GetCell).CurrentRow;
                if (AutoConfig.FormType.Equals("CD"))
                {
                    Support.AreEqual(cdPyoffLnpayoffloancharges[1].PBBuyerAtClosing.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(++Row, 4, TableAction.GetText).Message.ToString());
                    Support.AreEqual(cdPyoffLnpayoffloancharges[1].BuyerCredit.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 5, TableAction.GetText).Message.ToString());
                    Support.AreEqual(cdPyoffLnpayoffloancharges[1].PBSellerAtClosing.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 6, TableAction.GetText).Message.ToString());
                    Support.AreEqual(cdPyoffLnpayoffloancharges[1].SellerCredit.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 7, TableAction.GetText).Message.ToString());
                    string Result = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 1, TableAction.GetAttribute,"selected").Message.ToString();
                    Support.AreEqual("True", Result,true);

                }
                else
                {
                    string BuyerChargePayOffDisb=FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(++Row, 4, TableAction.GetText).Message.ToString().Trim();
                    Support.AreEqual(PyoffLnpayoffloancharges[1].BuyerCharge.ToString(), string.IsNullOrEmpty(BuyerChargePayOffDisb) ? "0" : BuyerChargePayOffDisb);
                    string BuyerCreditPayOffDisb = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 5, TableAction.GetText).Message.ToString().Trim();
                    Support.AreEqual(PyoffLnpayoffloancharges[1].BuyerCredit.ToString(), string.IsNullOrEmpty(BuyerCreditPayOffDisb) ? "0" : BuyerCreditPayOffDisb);
                    string SellerChargePayOffDisb = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 6, TableAction.GetText).Message.ToString().Trim();
                    Support.AreEqual(PyoffLnpayoffloancharges[1].SellerCharge.ToString(), string.IsNullOrEmpty(SellerChargePayOffDisb) ? "0" : SellerChargePayOffDisb);
                    string SellerCreditPayOffDisb = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 7, TableAction.GetText).Message.ToString().Trim();
                    Support.AreEqual(PyoffLnpayoffloancharges[1].SellerCredit.ToString(), string.IsNullOrEmpty(SellerCreditPayOffDisb) ? "0" : SellerCreditPayOffDisb);
                    Support.AreEqual("True", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 1, TableAction.GetAttribute, "selected").Message.ToString(),true);

                }
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void FMUC0048_REG0021()
        {
            Reports.TestDescription = "To ensure that the users are able to set pay of loan charge to third party using the webservice.";
            try
            {
                #region Login and create file
                Reports.TestStep = "Login to IIS";
                _IISLOGIN();
                Reports.TestStep = "Create file";
                Dictionary<string, int> FileData = CreateFile();
                #endregion
                #region Create first instance of payoffloan
                Reports.TestStep = "Create first Instance of Payoff loan and enter data";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "220", principalBalance: "300").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys("");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Click();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                FastDriver.BottomFrame.Done();
                Thread.Sleep(4000);
                #endregion
                #region Create second instance of payoffloan
                Reports.TestStep = "Create second Instance of Payoff loan and enter data";
                FastDriver.BottomFrame.New();
                Thread.Sleep(2000);
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys("");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.Click();
                try
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction("#4", "0.0000", "#1", TableAction.Click);
                }
                catch (NullReferenceException e)
                {
                    Reports.StatusUpdate("Could not find \"0.0000\" on Interest Calculation Summary table. Will try to find another table." + e.Message, false);
                }
                #endregion
                #region Enter Pay off loan charges in PDD
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                PaymentDetailsParameters PDParams = new PaymentDetailsParameters();
                PDParams.SellerPaidAtClosing = 10.12;
                PDParams.SellerPaidBeforeClosing = 5.11;
                PDParams.SellerCredit = 1.11;
                PDParams.BuyerAtClosing = 10.11;
                PDParams.BuyerBeforeClosing = 5.11;
                PDParams.BuyerCredit = 1.11;
                EnterPayOffLoanDetailsInPDD(PDParams);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(3, 1, TableAction.Click);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                PaymentDetailsParameters PDParams1 = new PaymentDetailsParameters();
                PDParams1.SellerPaidAtClosing = 14.12;
                PDParams1.SellerPaidBeforeClosing = 6.11;
                PDParams1.SellerCredit = 3.11;
                PDParams1.BuyerAtClosing = 14.11;
                PDParams1.BuyerBeforeClosing = 6.11;
                PDParams1.BuyerCredit = 3.11;
                EnterPayOffLoanDetailsInPDD(PDParams1);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                #endregion

                #region Invoke GetPayoffLoanDetails service
                Reports.TestStep = "Invoke GetPayoffLoanDetails service to get the details of Payoff Loan instance";
                var Request = EscrowRequestFactory.GetServiceFileRequest(Convert.ToInt32(FileData["FileId"]));
                var PayOffResDetails = FASTWCFHelpers.EscrowService.GetPayoffLoanDetails(Request);
                #endregion
                #region Variables
                var cdPyoffLnpayoffloancharges = PayOffResDetails.PayOffLoanSummary[0].CDPayoffLoanCharges;
                var PyoffLnpayoffloancharges = PayOffResDetails.PayOffLoanSummary[0].PayoffLoanCharges;
                #endregion
                #region Associate PayoffLoan charges using to payee web service
                Reports.TestStep = "Associate PayoffLoan charges using to payee web service";
                int? AddrBookEntryID = 8835211; //GAB 230
                int? ChargeID = AutoConfig.FormType.Equals("CD") ? PayOffResDetails.PayOffLoanSummary[1].CDPayCharges.DisbursementCharges[1].ChargeID : PayOffResDetails.PayOffLoanSummary[1].PayCharges.DisbursementCharges[1].ChargeID;
                //int? SeqNum = AutoConfig.FormType.Equals("CD") ? PayOffResDetails.PayOffLoanSummary[1].CDPayCharges.DisbursementCharges[1].SeqNum : PayOffResDetails.PayOffLoanSummary[1].PayCharges.DisbursementCharges[1].SeqNum;
                int? SeqNum = PayOffResDetails.PayOffLoanSummary[1].SeqNum;
                FASTWCFHelpers.FastEscrowService.PayOffLoanPayChargeAssociationRequest PayChargeAssociationRequest = EscrowRequestFactory.PayOffLoanPayChargesAssociationReq(Convert.ToInt32(FileData["FileId"]), AddrBookEntryID, ChargeID,SeqNum);
                FASTWCFHelpers.FastEscrowService.OperationResponse PayChargesAssociationRes = EscrowService.PayOffLoanPayChargesAssociation(PayChargeAssociationRequest);
                Support.AreEqual("1", PayChargesAssociationRes.Status.ToString(), PayChargesAssociationRes.StatusDescription);
                #endregion
                if (PayChargesAssociationRes.Status.Equals(1))
                {
                    #region Verify PayoffLoan details in FAST
                    Reports.TestStep = "Verify PayoffLoan details in FAST";
                    FastDriver.PayoffLoanSummary.Open();
                    FastDriver.PayoffLoanSummary.LoanSummaryTable.PerformTableAction(3, 2, TableAction.Click);
                    FastDriver.PayoffLoanSummary.LoanSummaryEdit.FAClick();
                    FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                    FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                    FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                    FastDriver.PayoffLoanCharges.PayChargesBtn.FAClick();
                    FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                    FastDriver.NewLoanDisbursements.PayeeSummaryTable.PerformTableAction(3, 1, TableAction.Click);
                    Thread.Sleep(3000);
                    int Row = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Description", @"Reconveyance Fee", "Description", TableAction.GetCell).CurrentRow;
                    if (AutoConfig.FormType.Equals("CD"))
                    {
                        Support.AreEqual(cdPyoffLnpayoffloancharges[1].PBBuyerAtClosing.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(++Row, 4, TableAction.GetText).Message.ToString());
                        Support.AreEqual(cdPyoffLnpayoffloancharges[1].BuyerCredit.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 5, TableAction.GetText).Message.ToString());
                        Support.AreEqual(cdPyoffLnpayoffloancharges[1].PBSellerAtClosing.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 6, TableAction.GetText).Message.ToString());
                        Support.AreEqual(cdPyoffLnpayoffloancharges[1].SellerCredit.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 7, TableAction.GetText).Message.ToString());
                        string Result = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 1, TableAction.GetAttribute, "selected").Message.ToString();
                        Support.AreEqual("True", Result, true);

                    }
                    else
                    {
                        string BuyerChargePayOffDisb = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(++Row, 4, TableAction.GetText).Message.ToString().Trim();
                        Support.AreEqual(PyoffLnpayoffloancharges[1].BuyerCharge.ToString(), string.IsNullOrEmpty(BuyerChargePayOffDisb) ? "0" : BuyerChargePayOffDisb);
                        string BuyerCreditPayOffDisb = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 5, TableAction.GetText).Message.ToString().Trim();
                        Support.AreEqual(PyoffLnpayoffloancharges[1].BuyerCredit.ToString(), string.IsNullOrEmpty(BuyerCreditPayOffDisb) ? "0" : BuyerCreditPayOffDisb);
                        string SellerChargePayOffDisb = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 6, TableAction.GetText).Message.ToString().Trim();
                        Support.AreEqual(PyoffLnpayoffloancharges[1].SellerCharge.ToString(), string.IsNullOrEmpty(SellerChargePayOffDisb) ? "0" : SellerChargePayOffDisb);
                        string SellerCreditPayOffDisb = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 7, TableAction.GetText).Message.ToString().Trim();
                        Support.AreEqual(PyoffLnpayoffloancharges[1].SellerCredit.ToString(), string.IsNullOrEmpty(SellerCreditPayOffDisb) ? "0" : SellerCreditPayOffDisb);
                        Support.AreEqual("True", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 1, TableAction.GetAttribute, "selected").Message.ToString(), true);

                    }
                    #endregion
                }
                else
                    Reports.StatusUpdate("Unable to associate charge with third party for send instance of pay off loan", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
        #region Private methods
        private void SelectInterestCalculationInclusiveTo(bool IsFormTypeCD = true)
        {
            if (IsFormTypeCD)
            {
                do
                {
                    FastDriver.PayoffLoanCharges.InterestCalculationInclusiveTo.FASetCheckbox(true);
                }
                while (!FastDriver.PayoffLoanCharges.InterestCalculationInclusiveTo.Selected);
            }
        }
        private void SelectInterestCalculationPercentRate()
        {
            do
            {
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.FASetCheckbox(true);
            }
            while (!FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.Selected);
        }
        private void SelectInterestCalculationPerDiem()
        {
            do
            {
                FastDriver.PayoffLoanCharges.InterestCalculationPerDiem.FASetCheckbox(true);
            }
            while (!FastDriver.PayoffLoanCharges.InterestCalculationPerDiem.Selected);
        }
        public bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }
        #region IISLOGIN
        public void _IISLOGIN(string UserName = null, string Password = null)
        {
            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true);
        }
        #endregion
        #region ADMLOGIN
        public void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }
        #endregion
        private Dictionary<string, int> CreateFile(string TransactionType = "SALE", decimal SalesPriceAmount = 5000)
        {
            try
            {
                Reports.TestStep = "Create new file.";
                Dictionary<string, int> FileData = new Dictionary<string, int>();
                var defaultRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                if(AutoConfig.FormType.Equals("CD"))
                defaultRequest.formType = FormType.CD;
                else
                    defaultRequest.formType = FormType.HUD;
                defaultRequest.File.SalesPriceAmount = SalesPriceAmount;
                int FileId = (int)FileService.CreateFile(defaultRequest).FileID;
                string FileNumber = FileService.GetOrderDetails(FileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(FileNumber);
                FileData.Add("FileId", FileId);
                FileData.Add("FileNumber", Convert.ToInt32(FileNumber));
                return FileData;
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to create QFE", ex);
            }
        }
        private void EnterPayOffLoanDetailsInPDD(PaymentDetailsParameters PDParams)
        {
            Reports.TestStep = "Enter Pay off loan charges in PDD";
            //FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
            //FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
            //FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
            double? BuyerCharge = 0.00;
            double? SellerCharge = 0.00;
            double? BuyerCredit = 0.00;
            double? SellerCredit = 0.00;
            //FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            if (AutoConfig.FormType.Equals("CD"))
            {
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDParams);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
            }
            else
            {
                BuyerCharge = PDParams.BuyerAtClosing;
                SellerCharge = PDParams.SellerPaidAtClosing;
                BuyerCredit = PDParams.BuyerCredit;
                SellerCredit = PDParams.SellerCredit;
                if (FastDriver.PaymentDetailsDlg.BuyerCharge.IsEnabled())
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(BuyerCharge.ToString());
                if (FastDriver.PaymentDetailsDlg.SellerCharge.IsEnabled())
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(SellerCharge.ToString());
                if (FastDriver.PaymentDetailsDlg.BuyerCredit.IsEnabled())
                    FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText(BuyerCredit.ToString());
                if (FastDriver.PaymentDetailsDlg.SellerCredit.IsEnabled())
                    FastDriver.PaymentDetailsDlg.SellerCredit.FASetText(SellerCredit.ToString());

                FastDriver.DialogBottomFrame.ClickDone();
                Thread.Sleep(2000);
            }
        }
        #endregion
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
