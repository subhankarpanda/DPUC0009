﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using OpenQA.Selenium;
using System.Linq;
using SeleniumInternalHelpers;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium.Interactions;


namespace EscrowChargeProcess
{
    /// <summary>
    /// Summary description for FMUC0049_Prorations
    /// </summary>
    [CodedUITest]
    public class FMUC0049_Prorations : MasterTestClass
    {

        #region Additional test attributes



        #endregion

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>

        #region BAT
        [TestMethod]
        public void FMUC0049_BAT0001()
        {
            try
            {
                Reports.TestDescription = "MF1_01: Login TO FAST Application and create a file.";
                Reports.TestStep = "Login To FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_BAT0002()
        {
            try
            {
                Reports.TestDescription = "MF1_02: Navigate to Proration Tax screen and verify for Default value and enter data.";
                Reports.TestStep = "Login To FAST";
                this.Login();
                //Playback.Wait(5000000);
                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                //int fileID = CreateFile();
                //string fileNumber = FileService.GetOrderDetails(fileID).FileNumber.ToString();
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                //GetDetailedCreateFileDefaultRequest
                //54614
                //
                //
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                //FastDriver.ProrationTax.en
                //
                //
                Reports.TestStep = "Edit the Charge Description.";
                if (!AutoConfig.UseCDFormType)
                {
                    FastDriver.ProrationDetail.WaitForScreenToLoad();
                    //FastDriver.ProrationDetail.Description.FASetText("Edit Charge Description");
                    FastDriver.ProrationDetail.Description.SendKeys("Edit Charge Description");
                }
                //
                // 
                Reports.TestStep = "Verify the Proration Details screen.";
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.Text);
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.Text);
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                Support.AreEqual("YEAR", FastDriver.ProrationDetail.Per.FAGetSelectedItem());
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.Text);
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.Text);
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.Text);
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.Text);
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.Text);
                //FastDriver.BottomFrame.Done();
                //Playback.Wait(4000);

                //
                //
                Reports.TestStep = "Enter Description and Charges.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                FastDriver.ProrationDetail.Amount.FASetText("10.00");
                FastDriver.ProrationDetail.FromDate.FASetText("04-02-2012");
                FastDriver.ProrationDetail.BasedOn.FASelectItem("365");
                FastDriver.ProrationDetail.Per.FASelectItem("YEAR");
                // Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ProrationDetail.ToDate.FASetText("07-02-2012");
                FastDriver.BottomFrame.Done();


                // 
                // 
                Reports.TestStep = "Validate File balance summary for Proration.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad();
                Support.AreEqual("5,002.49", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.Text.Trim());
                Support.AreEqual("5,002.49-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Trim());

                //
                // 
                Reports.TestStep = "Navigate to Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.Amount.FASetText("100.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.ToDate.FASetText(DateTime.Now.ToDateString());
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.FromDate.FASetText(DateTime.Now.ToDateString());
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationDetail.SwitchToContentFrame();

                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationDetail.SwitchToContentFrame();

                if (!FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationDetail.SwitchToContentFrame();

                Support.AreEqual("0.27", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("0.27", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_BAT0003()
        {
            try
            {
                Reports.TestDescription = "AF1: Modify_Tax_Proration_Without_Re-calculation.";

                //
                //
                Reports.TestStep = "Login";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Modify_Tax_Proration_Without_Recalculation.";
                FastDriver.ProrationDetail.CreditSeller.FAClick();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                FastDriver.ProrationDetail.Amount.FASetText("15");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ProrationDetail.BuyerCharge.FASetText("0.27");
                FastDriver.ProrationDetail.SellerCredit.FASetText("0.27");
                // 
                // 
                Reports.TestStep = "Click on Cancel Button.";
                FastDriver.WebDriver.HandleDialogMessage(false);

                // 
                // 
                Reports.TestStep = "Verify formula without calculation";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("15.00", FastDriver.ProrationDetail.Amount.GetAttribute("value"));
                Support.AreEqual("0.27", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value"));
                Support.AreEqual("0.27", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value"));

                // 
                // 
                Reports.TestStep = "Validate File balance summary for Proration.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary").WaitForScreenToLoad().SwitchToContentFrame();
                Support.AreEqual("5,000.27", FastDriver.EscrowFileBalanceSummary.Payoffloannettotaldisb.Text.Clean());
                Support.AreEqual("5,000.27-", FastDriver.EscrowFileBalanceSummary.FileBalance.Text.Clean());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }


        [TestMethod]
        public void FMUC0049_BAT0004()
        {
            try
            {
                Reports.TestDescription = "AF2: Modify_Tax_Proration_With_Recalculation.";
                //
                //
                Reports.TestStep = "Login";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                //
                // 
                Reports.TestStep = "Verify the Proration Details screen.";
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.Text);
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.Text);
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                Support.AreEqual("YEAR", FastDriver.ProrationDetail.Per.FAGetSelectedItem());
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.Text);
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.Text);
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.Text);
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.Text);
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.Text);

                this.EnterProrationDescAndCharges();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Modify_Tax_Proration_Without_Recalculation.";
                // FastDriver.ProrationDetail.CreditSeller.FAClick();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                FastDriver.ProrationDetail.Amount.FASetText("15");
                Keyboard.SendKeys(FAKeys.TabAway);

                // 
                // 
                Reports.TestStep = "Click on Cancel Button.";
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Verify formula without calculation";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("15.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("2.49", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_BAT0005()
        {
            try
            {
                Reports.TestDescription = "AF2: Modify_Tax_Proration_With_Recalculation.";

                //
                //
                Reports.TestStep = "Login";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();


                this.EnterProrationDescAndCharges();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Modify_Tax_Proration_With_Recalculation.";
                // FastDriver.ProrationDetail.CreditSeller.FAClick();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                FastDriver.ProrationDetail.Amount.FASetText("20");
                Keyboard.SendKeys(FAKeys.TabAway);

                // 
                // 
                Reports.TestStep = "Click on Cancel Button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Verify formula without calculation";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").Clean());
                Support.AreEqual("4.99", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean());
                Support.AreEqual("4.99", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_BAT0006()
        {
            try
            {
                Reports.TestDescription = "AF3: Verify for Edited Modified tax Proration and verify for entered.";
                //
                //
                Reports.TestStep = "Login";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Edit Calculated Charge Amounts without affecting the Proration formula.";
                this.EnterProrationDescAndCharges();
                FastDriver.ProrationDetail.Amount.FASetText("20");//this step is done in the previous test case(the CodedUI version doesn't have this as is a continuation )
                FastDriver.ProrationDetail.BuyerCharge.FASetText("5.00");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("10.00");

                // 
                Reports.TestStep = "Verify the modified amount on Proration tax screen.";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                Support.AreEqual("365", FastDriver.ProrationDetail.BasedOn.GetAttribute("value").ToString());
                Support.AreEqual("YEAR", FastDriver.ProrationDetail.Per.FAGetSelectedItem());
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("5.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").ToString());
                Support.AreEqual("4.99", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Edit Calculated Charge Amounts without affectign the Proration formula.";
                FastDriver.ProrationDetail.BuyerCharge.FASetText("5.00");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("10.00");

                // 
                // 
                Reports.TestStep = "Verify the modified amount on Proration tax screen.";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                Support.AreEqual("365", FastDriver.ProrationDetail.BasedOn.GetAttribute("value").ToString());
                Support.AreEqual("YEAR", FastDriver.ProrationDetail.Per.FAGetSelectedItem());
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("5.00", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").ToString());
                Support.AreEqual("4.99", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString());
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_BAT0007()
        {
            try
            {
                Reports.TestDescription = "AF4: Delete_Tax_Proration_Charges and Verify.";

                //
                Reports.TestStep = "Login";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Edit Calculated Charge Amounts without affecting the Proration formula.";
                this.EnterProrationDescAndCharges();
                FastDriver.ProrationDetail.Amount.FASetText("20");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("5.00");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("10.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
                FastDriver.ProrationDetail.BuyerCharge.FASetText("0");
                FastDriver.ProrationDetail.SellerCredit.FASetText("0");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Verify the Deleted buyer charge and Seller credit on Proration tax screen.";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                Support.AreEqual("365", FastDriver.ProrationDetail.BasedOn.GetAttribute("value").ToString());
                Support.AreEqual("YEAR", FastDriver.ProrationDetail.Per.FAGetSelectedItem());
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString());
                Support.AreEqual("10.00", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString());
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0049_BAT0008()
        {
            try
            {
                Reports.TestDescription = "AF5: Deselect the Per field and verify.";
                //
                Reports.TestStep = "Login";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                Reports.TestStep = "Edit Calculated Charge Amounts without affecting the Proration formula.";
                this.EnterProrationDescAndCharges();
                FastDriver.ProrationDetail.Amount.FASetText("20");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("5.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Deselect the Per Field on Proration Tax screen.";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
                FastDriver.ProrationDetail.BuyerCharge.FASetText("0");
                FastDriver.ProrationDetail.SellerCredit.FASetText("0");
                FastDriver.ProrationDetail.Per.FASelectItem("");
                FastDriver.ProrationDetail.Per.SendKeys(FAKeys.TabAway);
                string message = FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString());
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Verify for the removal of Per field.";
                Support.AreEqual("True", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("20.00", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
                Support.AreEqual("04-02-2012", FastDriver.ProrationDetail.FromDate.GetAttribute("value").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                Support.AreEqual("365", FastDriver.ProrationDetail.BasedOn.GetAttribute("value").ToString());
                Support.AreEqual("YEAR", FastDriver.ProrationDetail.Per.FAGetSelectedItem());
                Support.AreEqual("07-02-2012", FastDriver.ProrationDetail.ToDate.GetAttribute("value").ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0049_BAT0009()
        {
            try
            {
                Reports.TestDescription = "AF6_01: Delete the proration Tax Instance from Proration - Tax Screen.";
                //
                Reports.TestStep = "Login";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0049_BAT0010()
        {
            try
            {
                Reports.TestDescription = "AF6_02: Verify for the deletion of Proration Tax Instance.";

                //
                //
                Reports.TestStep = "Login";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Verify the Proration Details screen.";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.GetAttribute("value").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                Support.AreEqual("YEAR", FastDriver.ProrationDetail.Per.FAGetSelectedItem());
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.GetAttribute("value").ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString());


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }


        #endregion BAT

        #region REGRESSION

        [TestMethod]
        public void FMUC0049_REG0001()
        {
            try
            {
                Reports.TestDescription = "FM1159_PRORATION_TAX: Create Instance for Proration Tax and Verify for the Error warnings by passing different parameters.";
                //
                //
                Reports.TestStep = "Login";
                this.Login();

                //
                //
                Reports.TestStep = "Create File";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
               // this.CreateFileWithWCF();
                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Verify the Proration Details screen.";
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.FromDate.GetAttribute("value").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                Support.AreEqual("YEAR", FastDriver.ProrationDetail.Per.FAGetSelectedItem());
                Support.AreEqual("", FastDriver.ProrationDetail.ToDate.GetAttribute("value").ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.toProrate.Selected.ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").ToString());
                Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString());

                //
                //
                Reports.TestStep = "Enter Description and Charges.";
                this.EnterProrationDescAndCharges();
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                //Playback.Wait(1000000);
                // 
                // 
                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("DAY");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 365 Day format - Per Day.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "365", Per: "DAY", ToDate: "07-02-2012", BuyerCharge: "910.00", SellerCredit: "910.00");

                // 
                // 
                Reports.TestStep = "Change the per Field to MONTH.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("MONTH");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message2 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message2, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 365 Day format - Per Month.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "365", Per: "MONTH", ToDate: "07-02-2012", BuyerCharge: "29.99", SellerCredit: "29.99");

                // 
                // 
                Reports.TestStep = "Change the per Field to QUARTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("QUARTER");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message3 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message3, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 365 Day format - Per Quarter.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "365", Per: "QUARTER", ToDate: "07-02-2012", BuyerCharge: "9.97", SellerCredit: "9.97");

                // 
                // 
                Reports.TestStep = "Change the per Field to SEMIANNUAL.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("SEMIANNUAL");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message4 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message4, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 365 Day format - Per Semiannual.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "365", Per: "SEMIANNUAL", ToDate: "07-02-2012", BuyerCharge: "4.99", SellerCredit: "4.99");

                // 
                // 
                Reports.TestStep = "Change the per Field to TRIMESTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("TRIMESTER");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message5 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message5, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 365 Day format - Per Trimester.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "365", Per: "TRIMESTER", ToDate: "07-02-2012", BuyerCharge: "7.48", SellerCredit: "7.48");

                // 
                // 
                Reports.TestStep = "Change the per Field to WEEK.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("WEEK");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message6 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message6, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 365 Day format - Per Week.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "365", Per: "WEEK", ToDate: "07-02-2012", BuyerCharge: "130.00", SellerCredit: "130.00");

                // 
                // 
                Reports.TestStep = "Change the per Field to YEAR.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("YEAR");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message7 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message7, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 365 Day format - Per Year.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "365", Per: "YEAR", ToDate: "07-02-2012", BuyerCharge: "2.49", SellerCredit: "2.49");

                // 
                //
                string message8 = "";
                Reports.TestStep = "Change Based on Days To 360.";
                while (!FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("360"))
                {
                    FastDriver.ProrationDetail.BasedOn.FASelectItem("360");
                   // Playback.Wait(1000000000);
                    message8 = FastDriver.WebDriver.HandleDialogMessage(true, true, 10, true);
                    if (!message8.Equals(""))
                    {
                        FastDriver.ProrationDetail.WaitForScreenToLoad();
                        if (FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("360"))
                        {
                            break;
                        }
                    }

                }

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual(message8, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify that Based on Days Changed successfully.";
                Support.AreEqual("360", FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString());

                // 
                // 
                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("DAY");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message9 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message9, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 360 Day format - Per Day.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "360", Per: "DAY", ToDate: "07-02-2012", BuyerCharge: "900.00", SellerCredit: "900.00");

                // 
                // 
                Reports.TestStep = "Change the per Field to MONTH.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("MONTH");


                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message10 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message10, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 360 Day format - Per Month.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "360", Per: "MONTH", ToDate: "07-02-2012", BuyerCharge: "30.00", SellerCredit: "30.00");

                // 
                // 
                Reports.TestStep = "Change the per Field to QUARTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("QUARTER");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message11 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message11, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 360 Day format - Per Quarter.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "360", Per: "QUARTER", ToDate: "07-02-2012", BuyerCharge: "10.00", SellerCredit: "10.00");

                // 
                // 
                Reports.TestStep = "Change the per Field to SEMIANNUAL.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("SEMIANNUAL");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message12 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message12, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 360 Day format - Per Semiannual.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "360", Per: "SEMIANNUAL", ToDate: "07-02-2012", BuyerCharge: "5.00", SellerCredit: "5.00");

                // 
                // 
                Reports.TestStep = "Change the per Field to TRIMESTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("TRIMESTER");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message13 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message13, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 360 Day format - Per Trimester.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "360", Per: "TRIMESTER", ToDate: "07-02-2012", BuyerCharge: "7.50", SellerCredit: "7.50");

                // 
                // 
                Reports.TestStep = "Change the per Field to WEEK.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("WEEK");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message14 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message14, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 360 Day format - Per Week.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "360", Per: "WEEK", ToDate: "07-02-2012", BuyerCharge: "130.00", SellerCredit: "130.00");

                // 
                // 
                Reports.TestStep = "Change the per Field to YEAR.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("YEAR");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message15 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message15, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 360 Day format - Per Year.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "360", Per: "YEAR", ToDate: "07-02-2012", BuyerCharge: "2.50", SellerCredit: "2.50");

                // 
                // 
                Reports.TestStep = "Change Based on Days To 366.";
                string message16 = "";
                while (!FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("366"))
                {
                    FastDriver.ProrationDetail.BasedOn.FASelectItem("366");
                    message16 = FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.ProrationDetail.SwitchToContentFrame();
                    if (!message8.Equals(""))
                    {
                        if (FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("366"))
                        {
                            break;
                        }
                    }
                }

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual(message16, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify that Based on Days Changed successfully.";
                Support.AreEqual("366", FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString());

                // 
                // 
                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("DAY");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message17 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message17, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 366 Day format - Per Day.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "DAY", ToDate: "07-02-2012", BuyerCharge: "910.00", SellerCredit: "910.00");

                // 
                // 
                Reports.TestStep = "Change the per Field to MONTH.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("MONTH");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message18 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message18, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 366 Day format - Per MONTH.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "MONTH", ToDate: "07-02-2012", BuyerCharge: "29.99", SellerCredit: "29.99");

                // 
                // 
                Reports.TestStep = "Change the per Field to QUARTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("QUARTER");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message19 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message19, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 366 Day format - Per QUARTER.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "QUARTER", ToDate: "07-02-2012", BuyerCharge: "9.95", SellerCredit: "9.95");

                // 
                // 
                Reports.TestStep = "Change the per Field to SEMIANNUAL.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("SEMIANNUAL");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message20 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message20, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 366 Day format - Per SEMIANNUAL.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "SEMIANNUAL", ToDate: "07-02-2012", BuyerCharge: "4.97", SellerCredit: "4.97");

                // 
                // 
                Reports.TestStep = "Change the per Field to TRIMESTER.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("TRIMESTER");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message21 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message21, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 366 Day format - Per Trimester.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "TRIMESTER", ToDate: "07-02-2012", BuyerCharge: "7.46", SellerCredit: "7.46");

                // 
                // 
                Reports.TestStep = "Change the per Field to WEEK.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("WEEK");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message22 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message22, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 366 Day format - Per Week.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "WEEK", ToDate: "07-02-2012", BuyerCharge: "130.00", SellerCredit: "130.00");

                // 
                // 
                Reports.TestStep = "Change the per Field to YEAR.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("YEAR");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message23 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message23, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Verify Formula for 366 Day format - Per Year.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "YEAR", ToDate: "07-02-2012", BuyerCharge: "2.49", SellerCredit: "2.49");


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_REG0002()
        {
            try
            {
                Reports.TestDescription = "Verify_ErrWarningCondition_PRORATION_TAX: Verify errors and warninngs for Proration TAX Screens.";

                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "Click on Edit";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                //
                //
                Reports.TestStep = "Enter Charges";
                this.EnterProrationDescAndCharges();
                string messagex = "";
                while (!FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("366"))
                {
                    FastDriver.ProrationDetail.BasedOn.FASelectItemBySendingKeys("366");
                    messagex = FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.ProrationDetail.SwitchToContentFrame();
                    if (!messagex.Equals(""))
                    {
                        if (FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("366"))
                        {
                            break;
                        }
                    }
                }

                // 
                // 
                Reports.TestStep = "Change the per Field to YEAR.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("YEAR");
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.ProrationTax.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Uncheck seller credit check Box.";
                if (FastDriver.ProrationDetail.CreditSeller.Selected)
                {
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                }

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(message, "Proration formula values have changed. Do you wish to recalculate prorated charges?");
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate Buyer credit and seller charge after Uncheck Buyer Credit Checkbox.";
                this.VerifyProrationDetailsData(CreditSeller: "False", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "YEAR", ToDate: "07-02-2012", BuyerCredit: "2.49", SellerCharge: "2.49");

                // 
                // 
                Reports.TestStep = "Change Prorate as of date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad().SwitchToContentFrame();
                Support.AreEqual("Open", FastDriver.TermsDatesStatus.Status.FAGetSelectedItem().ToString());

                FastDriver.TermsDatesStatus.ProrateAsOf.FASetText(DateTime.Now.ToDateString());
                FastDriver.TermsDatesStatus.ProrateAsOf.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Select Proration to calculate the re- Proration.";
                try
                {
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Weekend Warning");
                    FastDriver.WeekendWarning.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                catch (Exception )
                {
                    Reports.StatusUpdate("No Dialog for Weekend Warning-Continue Test Normally", true);
                }
                try
                {
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Re-calculate Prorations");
                    if (!FastDriver.ProrationDateChangedDlg.Insurance.Selected)
                    {
                        FastDriver.ProrationDateChangedDlg.Insurance.FAClick();
                    }
                    Playback.Wait(400);
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                catch (Exception)
                {
                    Reports.StatusUpdate("No Dialog for Recalculation-Continue Test Normally", true);


                }
                // 
                // 
                Reports.TestStep = "The Prorate As of Date has changed.";
                Support.AreEqual("The Prorate As of Date has changed. Would you like to update the Disbursement Date?", FastDriver.WebDriver.HandleDialogMessage(true, true));

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "check seller credit check Box.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                {
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                }

                // 
                // 
                Reports.TestStep = "Change prorate parameters in Insurance screen. Click on Cancel.";
                string message4 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message4);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Validate Buyer credit and seller charge after Uncheck Buyer Credit Checkbox.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "YEAR", ToDate: "07-02-2012", BuyerCredit: "2.49", SellerCharge: "2.49");

                // 
                // 
                Reports.TestStep = "Uncheck seller credit check Box.";
                if (FastDriver.ProrationDetail.CreditSeller.Selected)
                {
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                }

                // 
                // 
                Reports.TestStep = "Change prorate parameters in Insurance screen. Click on Cancel.";
                string message5 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message5);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "check seller credit check Box.";
                if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                {
                    FastDriver.ProrationDetail.CreditSeller.FAClick();
                }

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message6 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message6);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Verify Formula for 366 Day format - Per Year.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "True", fromProrate: "False", BasedOn: "366", Per: "YEAR", ToDate: "07-02-2012", BuyerCharge: "2.49", SellerCredit: "2.49");

                // 
                // 
                Reports.TestStep = "Uncheck Inclusive From Check Box.";
                if (FastDriver.ProrationDetail.fromInclusive.Selected)
                {
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                }

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message7 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message7);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Validate Buyer credit and seller charge after Uncheck Buyer Credit Checkbox.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "False", fromProrate: "False", BasedOn: "366", Per: "YEAR", ToDate: "07-02-2012", BuyerCharge: "2.46", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "2.46");

                // 
                // 
                Reports.TestStep = "check Inclusive From Check Box.";
                if (!FastDriver.ProrationDetail.fromInclusive.Selected)
                {
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                }
                //FastDriver.ProrationDetail.fromInclusive.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Change prorate parameters in Insurance screen. Click on Cancel.";
                string message8 = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message8);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Uncheck Inclusive From Check Box.";
                if (FastDriver.ProrationDetail.fromInclusive.Selected)
                {
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                }

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message9 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message9);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                // 
                // 
                Reports.TestStep = "Validate Buyer Charge and seller Credit after Uncheck the Inclusive Check Box for From.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "False", fromProrate: "False", BasedOn: "366", Per: "YEAR", ToDate: "07-02-2012", BuyerCharge: "2.46", SellerCredit: "2.46");

                // 
                // 
                Reports.TestStep = "check Inclusive To Check Box.";
                if (!FastDriver.ProrationDetail.toInclusive.Selected)
                {
                    FastDriver.ProrationDetail.toInclusive.FAClick();
                }
                //FastDriver.ProrationDetail.fromInclusive.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message10 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message10);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate Buyer Charge and seller Credit after check the Inclusive Check Box for TO.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "False", fromProrate: "False", BasedOn: "366", Per: "YEAR", ToDate: "07-02-2012", BuyerCharge: "2.49", SellerCredit: "2.49");

                // 
                // 
                Reports.TestStep = "Change Based on Value.";
                string message11 = "";
                while (!FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("360"))
                {
                    FastDriver.ProrationDetail.BasedOn.FASelectItemBySendingKeys("360");
                    message11 = FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.ProrationDetail.SwitchToContentFrame();
                    if (!message11.Equals(""))
                    {
                        if (FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("360"))
                        {
                            break;
                        }
                    }
                }

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message11);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate Buyer Charge and seller Credit Change Based on Field.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "False", toInclusive: "True", fromProrate: "False", BasedOn: "360", Per: "YEAR", ToDate: "07-02-2012", BuyerCharge: "2.50", SellerCredit: "2.50");

                // 
                // 
                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("DAY");

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message12 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message12);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate Buyer Charge and seller Credit Change Per Field.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "False", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "False", fromProrate: "False", BasedOn: "360", Per: "DAY", ToDate: "07-02-2012", BuyerCharge: "900.00", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "900.00");

                // 
                // 
                Reports.TestStep = "check Days of close by seller.";
                if (!FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                {
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();
                }
                //FastDriver.ProrationDetail.DayofClosePaidbySeller.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message13 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message13);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate Day of Close Paid by Seller.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "True", Amount: "10.00", FromDate: "04-02-2012", fromInclusive: "False", fromProrate: "False", BasedOn: "360", Per: "DAY", ToDate: "07-02-2012", BuyerCharge: "900.00", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "900.00");

                // 
                // 
                Reports.TestStep = "Change the amount.";
                FastDriver.ProrationDetail.Amount.FASetText("11.00");
                FastDriver.ProrationDetail.Amount.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message14 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message14);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate the changed amount.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "True", Amount: "11.00", FromDate: "04-02-2012", fromInclusive: "False", fromProrate: "False", BasedOn: "360", Per: "DAY", ToDate: "07-02-2012", BuyerCharge: "990.00", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "990.00");

                // 
                // 
                Reports.TestStep = "Change the From Date.";
                FastDriver.ProrationDetail.FromDate.FASetText("05-02-2012");
                FastDriver.ProrationDetail.FromDate.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message15 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message15);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate the changed From Date.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "True", Amount: "11.00", FromDate: "05-02-2012", fromInclusive: "False", fromProrate: "False", BasedOn: "360", Per: "DAY", ToDate: "07-02-2012", BuyerCharge: "660.00", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "660.00");

                // 
                // 
                Reports.TestStep = "Change the To Date.";
                FastDriver.ProrationDetail.ToDate.FASetText("8-2-2012");
                FastDriver.ProrationDetail.ToDate.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string message17 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message17);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate the changed To Date.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "True", Amount: "11.00", FromDate: "05-02-2012", fromInclusive: "False", fromProrate: "False", BasedOn: "360", Per: "DAY", ToDate: "08-02-2012", BuyerCharge: "990.00", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "990.00");


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0049_REG0003()
        {
            try
            {
                Reports.TestDescription = "FM2115_FM2468_PRORATION_TAX_EWC01: Required Data for Proration, Delete a Proration TAX Entry.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                //FastDriver.TopFrame.SearchFileByFileNumber("51065");
                // Playback.Wait(5000);
                //
                //
                Reports.TestStep = "Click on Edit";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                //
                //
                Reports.TestStep = "Enter Charges";
                this.EnterProrationDescAndCharges();
                string messagex = "";
                while (!FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("360"))
                {
                    FastDriver.ProrationDetail.BasedOn.FASelectItem("360");
                    messagex = FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.ProrationDetail.SwitchToContentFrame();
                    if (!messagex.Equals(""))
                    {
                        if (FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("360"))
                        {
                            break;
                        }
                    }
                }


                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", messagex);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Uncheck Inclusive From Check Box.";
                if (FastDriver.ProrationDetail.fromInclusive.Selected)
                {
                    FastDriver.ProrationDetail.fromInclusive.FAClick();
                }

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string messageFromInclusive = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", messageFromInclusive);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Change the per Field to DAY.";
                FastDriver.ProrationDetail.Per.FASelectItemBySendingKeys("DAY");

                //
                //
                Reports.TestStep = "Validate Proration Message.";
                string message17 = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", message17);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                //
                //
                Reports.TestStep = "Check To Inclusive.";
                if (!FastDriver.ProrationDetail.toInclusive.Selected)
                    FastDriver.ProrationDetail.toInclusive.FAClick();

                //
                //
                Reports.TestStep = "Validate Proration Message.";
                string messageToInclusive = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", messageToInclusive);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "check Days of close by seller.";
                if (!FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected)
                {
                    FastDriver.ProrationDetail.DayofClosePaidbySeller.FAClick();
                }

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string messageDaysOfClose = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", messageDaysOfClose);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Change Amount.";
                FastDriver.ProrationDetail.Amount.FASetText("11.00");
                FastDriver.ProrationDetail.Amount.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string messageAmountDelete = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", messageAmountDelete);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Change the From Date.";
                FastDriver.ProrationDetail.FromDate.FASetText("05-02-2012");
                FastDriver.ProrationDetail.FromDate.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string messageFromDate = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", messageFromDate);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Change the To Date.";
                FastDriver.ProrationDetail.ToDate.FASetText("8-2-2012");
                FastDriver.ProrationDetail.ToDate.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Validate Proration Message.";
                string messageToDate = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Proration formula values have changed. Do you wish to recalculate prorated charges?", messageToDate);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Click on Edit";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                if (!AutoConfig.UseCDFormType)
                {
                    // 
                    // 
                    Reports.TestStep = "Removing the charge description.";
                    FastDriver.ProrationDetail.Description.FAClick();
                    FastDriver.ProrationDetail.Description.SendKeys(Keys.Delete);
                    //FastDriver.ProrationDetail.Description.SendKeys(Keys.Delete);
                    FastDriver.ProrationDetail.Description.SendKeys(FAKeys.Tab);

                    // 
                    // 
                    Reports.TestStep = "Delete Charge Description.";
                    string deleteMessage = FastDriver.WebDriver.HandleDialogMessage();
                    Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", deleteMessage);
                    FastDriver.ProrationDetail.SwitchToContentFrame();

                }
                // 
                // 
                Reports.TestStep = "Delete amount.";
                FastDriver.ProrationDetail.Amount.FAClick();
                FastDriver.ProrationDetail.Amount.SendKeys(Keys.Delete);
                FastDriver.ProrationDetail.Amount.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Calculated charges will be removed. Do you wish to delete 'Amount' ?.";
                string deleteAmountMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);
                Support.AreEqual("Calculated charges will be removed. Do you wish to delete 'Amount' ?", deleteAmountMessage);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate That charge Description and amount are not removed.";
                this.VerifyProrationDetailsData(CreditSeller: "True", DayofClosePaidbySeller: "True", Amount: "11.00", FromDate: "05-02-2012", fromInclusive: "False", fromProrate: "False", BasedOn: "360", Per: "DAY", ToDate: "08-02-2012", BuyerCharge: "990.00", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "990.00");

                // 
                // 
                Reports.TestStep = "Delete the Proration Tax instance from Proration - Tax Screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();

                // 
                // 
                Reports.TestStep = "All information will be removed for this proration. Continue?.";
                string deleteProrationMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("All information will be removed for this proration.  Continue?", deleteProrationMessage);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Verify the Proration Details screen.";
                FastDriver.ProrationDetail.WaitForScreenToLoad().SwitchToContentFrame();
                this.VerifyProrationDetailsData(CreditSeller: "False", DayofClosePaidbySeller: "False", Amount: "EMPTY", FromDate: "EMPTY", fromInclusive: "True", fromProrate: "False", Per: "YEAR", ToDate: "EMPTY", toInclusive: "False", toProrate: "False", BuyerCharge: "EMPTY", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "EMPTY");

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_REG0004()
        {
            try
            {
                Reports.TestDescription = "ES6935_ES6576_ES6577_ES6936_ES7625_PRORATION_TAX: Set the 1099-s Activity date in ADM side.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login(true);

                // 
                // 
                Reports.TestStep = "Enter 1099-S Activity Date.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").SwitchToContentFrame();
                //Playback.Wait(1000000);
                Support.AreEqual("Residential", FastDriver.OfficeSetupOffice.BusinessSegment.FAGetSelectedItem().ToString());
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("7/12/2012");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FMUC0049_REG0005()
        {
            try
            {
                Reports.TestDescription = "Remaining_ES6935_ES6576_ES6577_ES6936_ES7625_PRORATION_TAX: Verify 1099s Warnings and errors with respect to Proration Tax screen.";


                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login(true);

                // 
                // 
                Reports.TestStep = "Enter 1099-S Activity Date.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").SwitchToContentFrame();
                //Playback.Wait(1000000);
                Support.AreEqual("Residential", FastDriver.OfficeSetupOffice.BusinessSegment.FAGetSelectedItem().ToString());
                FastDriver.OfficeSetupOffice.ActivityDate1099s.SendKeys("7/12/2012" + FAKeys.Tab);
                //FastDriver.OfficeSetupOffice.ActivityDate1099s.SendKeys(FAKeys.Tab);
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FireEvent("onchange");
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FireEvent("onblur");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.WebDriver.Quit();

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create Order";
                int FileID = CreateFile();
                //this.CreateFileWithWCF(RequestFactory.GetCreateFileDefaultRequest());
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                // 
                // 
                Reports.TestStep = "Enter Settlement Date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.AddDays(Convert.ToInt32("-1")).ToDateString() + FAKeys.Tab);
                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Verify the Proration Details screen.";
                this.VerifyProrationDetailsData(CreditSeller: "False", DayofClosePaidbySeller: "False", Amount: "EMPTY", FromDate: "EMPTY", fromInclusive: "True", fromProrate: "False", Per: "YEAR", ToDate: "EMPTY", toInclusive: "False", toProrate: "False", BuyerCharge: "EMPTY", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "EMPTY");

                // 
                // 
                Reports.TestStep = "Enter Buyer Charge and Click on Done.";
                FastDriver.ProrationDetail.Amount.FASetText("10.00");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("10.00");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                // 
                // 
                Reports.TestStep = "Delete the Proration Tax instance from Proration - Tax Screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();

                // 
                // 
                Reports.TestStep = "All information will be removed for this proration. Continue?.";
                string deleteProrationMessage = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("All information will be removed for this proration.  Continue?", deleteProrationMessage);
                FastDriver.ProrationDetail.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Enter Seller Details with 1099 S details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Sellers");
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Name", "Seller1FirstName Seller1Lastname", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                // FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Individual");
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Individual");
                //Playback.Wait(600);
                //FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Seller First Name");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Seller Last Name");
                FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItem("1099-S");
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText("A Street");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Alameda");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("92070");

                //Playback.Wait(10000000);
                //FastDriver.BuyerSellerSetup.foward

                if (!FastDriver.BuyerSellerSetup.ForwardngSetToProperty.Selected)
                {
                    FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
                }

                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Navigate to 10099-S screen and verify for property description.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S").SwitchToContentFrame();
                // Playback.Wait(1000000);
                Support.AreEqual("J305, JJEJAMQ, JJEJAMQ, ALBANY, CA 9270", FastDriver._1099S.PropertyDescription.GetAttribute("value").Clean());
                if (!FastDriver._1099S.PropertyConsideration.Selected)
                {
                    FastDriver._1099S.PropertyConsideration.FAClick();
                }

                Support.AreEqual("0.00", FastDriver._1099S.BuyerPartofRETAXDollor.GetAttribute("value"));
                FastDriver._1099S.SSNTIN.FASetText("1213456966");
                FastDriver._1099S.ActiveZip.FASetText("92070");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Verify the Proration Details screen.";
                this.VerifyProrationDetailsData(CreditSeller: "False", DayofClosePaidbySeller: "False", Amount: "EMPTY", FromDate: "EMPTY", fromInclusive: "True", fromProrate: "False", Per: "YEAR", ToDate: "EMPTY", toInclusive: "False", toProrate: "False", BuyerCharge: "EMPTY", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "EMPTY");

                // 
                // 
                Reports.TestStep = "Enter Buyer Charge and Click on Done.";
                FastDriver.ProrationDetail.Amount.FASetText("20.00");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("20.00");
                FastDriver.ProrationDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                Playback.Wait(1000);
                // 
                // 
                Reports.TestStep = "Please update the 1099-S record and print the 1099-S form for the seller.";
                string message1099_SRecord = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please update the 1099-S record and print the 1099-S form for the seller.", message1099_SRecord);

                // 
                // 
                Reports.TestStep = "Delete the Proration Tax instance from Proration - Tax Screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                Playback.Wait(300);

                //
                //
                Reports.TestStep = "All information will be removed for this proration. Continue?.";
                string messageForInformationRemoval = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                //Support.AreEqual("All information will be removed for this proration.  Continue?", messageForInformationRemoval);
                //FastDriver.ProrationTax.SwitchToContentFrame();
                Playback.Wait(400);

                // 
                // Old *to be commented*-Update Should work now.
                Reports.TestStep = "Please update the 1099-S record and print the 1099-S form for the seller.";
                string message20 = FastDriver.WebDriver.HandleDialogMessage();
                //Support.AreEqual("Please update the 1099-S record and print the 1099-S form for the seller.", message20);

                // 
                // 
                Reports.TestStep = "Navigate to 10099-S screen and check Ready For Extract check Box.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S").SwitchToContentFrame();

                if (!FastDriver._1099S.ActiveReadyForExtract.Selected)
                {
                    FastDriver._1099S.ActiveReadyForExtract.FAClick();
                }
                FastDriver.BottomFrame.Save();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Verify the Proration Details screen.";
                this.VerifyProrationDetailsData(CreditSeller: "False", DayofClosePaidbySeller: "False", Amount: "EMPTY", FromDate: "EMPTY", fromInclusive: "True", fromProrate: "False", Per: "YEAR", ToDate: "EMPTY", toInclusive: "False", toProrate: "False", BuyerCharge: "EMPTY", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "EMPTY");

                // 
                // 
                Reports.TestStep = "Enter Buyer Charge and Click on Done.";
                FastDriver.ProrationDetail.Amount.FASetText("30.00");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("30.00");
                FastDriver.ProrationDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Verifying Ready To Extract Warn.";
                string messageExtractWarn = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("The Ready for Extract flag has been removed for one or more 1099-S records. Please update each 1099-S record and print the 1099-S form for the seller.", messageExtractWarn);
                FastDriver.ProrationTax.SwitchToContentFrame();

                // 
                // check
                Reports.TestStep = "Verify 1099-S data has changed Message.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow");
                FastDriver.FileWorkflow.MessagesTable.PerformTableAction("Message", "1099-S data has changed. Please update and reprint 1099-S.", "Message", TableAction.Click);

                // 
                // 
                Reports.TestStep = "Enter Buyers Part of RE Tax Amount.";
                FastDriver.LeftNavigation.Navigate<_1099S>("Home>Order Entry>Escrow Closing>1099-S").SwitchToContentFrame();
                FastDriver._1099S.BuyerPartofRETAXDollor.FASetText("30.00");
                FastDriver.BottomFrame.Save();

                // 
                // 
                Reports.TestStep = "Verify 1099-S data has changed Message Vanished.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.FileWorkflow.MessagesTable.GetRowCount();

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Enter Buyer Charge so that Buyer's Part of R.E. Tax exceeds maximum for regular 1099-S creation.";
                FastDriver.ProrationDetail.BuyerCharge.FASetText("55555555.00");
                FastDriver.ProrationDetail.BuyerCharge.SendKeys(FAKeys.Tab);

                // 
                // 
                Reports.TestStep = "Please create a manual 1099-S for the seller.";
                string messageCreateManual = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Buyer's Part of R.E. Tax exceeds maximum for regular 1099-S creation. Please create a manual 1099-S for the seller.", messageCreateManual);
                FastDriver.ProrationTax.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Please update the 1099-S record and print the 1099-S form for the seller.";
                string messageUpdate = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Please update the 1099-S record and print the 1099-S form for the seller.", messageUpdate);
                FastDriver.ProrationTax.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Validate that 1099s clarification is N/A.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Sellers").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("No", "1", "No", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("1099-S", FastDriver.BuyerSellerSetup.Buyer1099sClassification.FAGetSelectedItem().ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_REG0006()
        {
            try
            {
                Reports.TestDescription = "ES6088_PRORATION_TAX: Disable Prorations Entry in Sub Escrow Files.";

                Reports.StatusUpdate("Expected Failure, Link Not Found", true);
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create Order";
                this.CreateFileWithWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());

                //
                //
                Reports.TestStep = "To verify Proration link doesn't exist.";
                try
                {
                    FastDriver.LeftNavigation.Navigate<EscrowChargeSetup>("Home>Order Entry>Escrow Charge Processes>Proration");
                    //Support.AreEqual(FastDriver.LeftFrame.Path.Contains<string>("Proration"));
                    //Playback.Wait(2000);
                    //FastDriver.LeftFrame.SwitchToLeftNavigationPane();
                    // bool linkExists=true;

                    //     IWebElement Element = FastDriver.WebDriver.FindElement(By.LinkText("Proration"));
                    //     if (Element == null)
                    //         linkExists = false;
                }
                catch (Exception )
                {
                    Reports.StatusUpdate("Expected Failure: Link Not Found", true);
                    // linkExists = false;
                }

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_REG0007()
        {
            try
            {
                Reports.TestDescription = "ES6934_PRORATION_TAX: Delete the 1099-s Activity date in ADM side.";

                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login(true);

                // 
                // 
                Reports.TestStep = "Making 1099-S Activity Date blank.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").SwitchToContentFrame();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("");
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_REG0008()
        {
            try
            {
                Reports.TestDescription = "Remaining_ES6934_PRORATION_TAX: Prevent 1099-S Messages if No Activity Date is set in ADM with respect to Proration Tax screen.";

                //
                //
                Reports.TestStep = "Login to ADM FAST";
                this.Login(true);

                // 
                // 
                Reports.TestStep = "Making 1099-S Activity Date blank.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").SwitchToContentFrame();
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText(" ");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);


                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();


                //
                //
                Reports.TestStep = "Create Order";

                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                // 
                // 
                Reports.TestStep = "Enter Settlement Date.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Today.AddDays(Convert.ToInt32("-1")).ToDateString());

                // 
                // 
                Reports.TestStep = "Enter Seller Details with 1099 S details.";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Sellers").SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("Name", "Seller1FirstName Seller1Lastname", "Name", TableAction.Click);
                FastDriver.BuyerSellerSummary.Edit();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("Individual");
                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Seller First Name");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Seller Last Name");
                FastDriver.BuyerSellerSetup.IndividualsClassification.FASelectItem("1099-S");

                if (!FastDriver.BuyerSellerSetup.ForwardngSetToProperty.Selected)
                {
                    FastDriver.BuyerSellerSetup.ForwardngSetToProperty.FAClick();
                }
                FastDriver.BottomFrame.Done();

                // 
                // 
                Reports.TestStep = "Enter zip code and SSN number";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>Escrow Closing>1099-S").SwitchToContentFrame();
                Support.AreEqual("J305, JJEJAMQ, JJEJAMQ, ALBANY, CA 9270", FastDriver._1099S.PropertyDescription.GetAttribute("value").ToString());

                if (!FastDriver._1099S.PropertyConsideration.Selected)
                {
                    FastDriver._1099S.PropertyConsideration.FAClick();
                }

                Support.AreEqual("0.00", FastDriver._1099S.BuyerPartofRETAXDollor.GetAttribute("value").ToString());
                FastDriver._1099S.SSNTIN.SendKeys("123456789");
                FastDriver._1099S.ActiveZip.SendKeys("92707");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                // 
                // 
                Reports.TestStep = "verify for Own Office’s 1099-S Activity Date is miss. and click on OK button.";
                string messageVerifyOwnOffice = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Owning Office’s 1099-S Activity Date is missing.", messageVerifyOwnOffice.Clean());
                FastDriver._1099S.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Verify the Proration Details screen.";
                this.VerifyProrationDetailsData(CreditSeller: "False", DayofClosePaidbySeller: "False", Amount: "EMPTY", FromDate: "EMPTY", fromInclusive: "True", fromProrate: "False", Per: "YEAR", ToDate: "EMPTY", toInclusive: "False", toProrate: "False", BuyerCharge: "EMPTY", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "EMPTY");

                // 
                // 
                Reports.TestStep = "Enter Buyer Charge and Click on Done.";
                FastDriver.ProrationDetail.Amount.FASetText("30.00");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("20.00");
                FastDriver.ProrationDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                // 
                // 
                Reports.TestStep = "Click on Edit on Proration Tax screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                // 
                // 
                Reports.TestStep = "Verify that no message is appeared on Change the buyer amount if Activity date is not set in ADM.";
                this.VerifyProrationDetailsData(CreditSeller: "False", DayofClosePaidbySeller: "False", Amount: "30.00", FromDate: "EMPTY", fromInclusive: "True", fromProrate: "False", Per: "YEAR", ToDate: "EMPTY", toInclusive: "False", toProrate: "False", BuyerCharge: "20.00", BuyerCredit: "EMPTY", SellerCharge: "EMPTY", SellerCredit: "EMPTY");

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_REG0009()
        {
            try
            {
                Reports.TestDescription = "SetUpForActivityDate_PRORATION_TAX: Reset the 1099-s Activity date in ADM side with respect to Proration TAX screen.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login(true);

                // 
                // 
                Reports.TestStep = "Making 1099-S Activity Date blank.";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878").SwitchToContentFrame();
                Support.AreEqual("Residential", FastDriver.OfficeSetupOffice.BusinessSegment.FAGetSelectedItem().ToString());
                FastDriver.OfficeSetupOffice.ActivityDate1099s.FASetText("7/12/2012");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_REG0010()
        {
            try
            {
                Reports.TestDescription = "EWC03: Verify for the Error Warn for Charge and description are mandatory fields.";

                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();
                //
                //
                Reports.TestStep = "Create Order";

                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);


                // 
                Reports.TestStep = "Click on New button.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.New.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                //
                //
                Reports.TestStep = "Enter the charge.";
                this.EnterProrationDescAndCharges();
                FastDriver.ProrationDetail.Description.SendKeys(Keys.Delete);
                FastDriver.ProrationDetail.Description.SendKeys(FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                // 
                // 
                Reports.TestStep = "Validate the message when user tries to save charges without entering the charge description.";
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Charge description and amount are required.", message.Clean());
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.BottomFrame.Cancel();
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_REG0011()
        {
            try
            {
                Reports.TestDescription = "Field Definitions and FM1579 and FM2715 Business Rules covered.";
                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();
                //
                //
                Reports.TestStep = "Create Order";

                int FileID = CreateFile();
                string fileNumber = FileService.GetOrderDetails(FileID).FileNumber.ToString();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //
                //
                Reports.TestStep = "Navigate to Proration - Rent screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad().SwitchToContentFrame(); ;
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.Amount.FASetText("500.00");
                FastDriver.ProrationDetail.Amount.SendKeys(FAKeys.Tab);
                FastDriver.ProrationDetail.ToDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ProrationDetail.ToDate.SendKeys(FAKeys.Tab);
                FastDriver.ProrationDetail.FromDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.ProrationDetail.FromDate.SendKeys(FAKeys.Tab);
                string messagex = "";
                while (!FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("360"))
                {
                    FastDriver.ProrationDetail.BasedOn.FASelectItem("360");
                    messagex = FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.ProrationDetail.SwitchToContentFrame();
                    if (!messagex.Equals(""))
                    {
                        if (FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem().ToString().Equals("360"))
                        {
                            break;
                        }
                    }
                }
                Support.AreEqual("16.67", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value"));
                Support.AreEqual("16.67", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value"));
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to Proration - Rent screen.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad().SwitchToContentFrame(); ;
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.BuyerCharge.FASetText("5.10");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("5.20");
                FastDriver.ProrationDetail.SellerCharge.FASetText("5.30");
                FastDriver.ProrationDetail.SellerCredit.FASetText("5.40");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Verify the entered Charges and Credits.";
                FastDriver.ProrationTax.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                this.VerifyProrationDetailsData(BuyerCharge: "5.10", BuyerCredit: "5.20", SellerCharge: "5.30", SellerCredit: "5.40");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to Proration - Miscellaneous screen.";
                FastDriver.LeftNavigation.Navigate<ProrationMisc>("Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationTax.Miscellaneous1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual("False", FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                FastDriver.ProrationDetail.Amount.FASetText("9999999999.999");
                FastDriver.ProrationDetail.Amount.SendKeys(FAKeys.Tab);
                Support.AreEqual("9,999,999,999.99", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
                String Date1 = DateTime.Today.ToDateString();
                String Date2 = DateTime.Today.AddDays(1).ToDateString();
                FastDriver.ProrationDetail.ToDate.FASetText(Date1);
                FastDriver.ProrationDetail.ToDate.SendKeys(FAKeys.Tab);
                FastDriver.ProrationDetail.FromDate.FASetText(Date2);
                FastDriver.ProrationDetail.ToDate.SendKeys(FAKeys.Tab);

                string messageToDate = FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual("'To Date' must be later than or equal to 'From Date'", messageToDate);
                Playback.Wait(400);
                FastDriver.ProrationDetail.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.ProrationDetail.FromDate.FASetText(Date1);

                Support.AreEqual("True", FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual("False", FastDriver.ProrationDetail.fromProrate.Selected.ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.Per.Text.ToString().Contains("DAY").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.Per.Text.ToString().Contains("MONTH").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.Per.Text.ToString().Contains("QUARTER").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.Per.Text.ToString().Contains("SEMIANNUAL").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.Per.Text.ToString().Contains("TRIMESTER").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.Per.Text.ToString().Contains("WEEK").ToString());
                Support.AreEqual("True", FastDriver.ProrationDetail.Per.Text.ToString().Contains("YEAR").ToString());
                FastDriver.ProrationDetail.Description.SendKeys("abcdefghij12345.,/;*abcdefghij12345.,/;*abcdedfd4545");
                FastDriver.ProrationDetail.Description.SendKeys(FAKeys.Tab);

                FastDriver.ProrationDetail.BuyerCharge.FASetText("9999999999.999");
                FastDriver.ProrationDetail.BuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCredit.FASetText("9999999999.999");
                FastDriver.ProrationDetail.BuyerCredit.SendKeys(FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCharge.FASetText("9999999999.999");
                FastDriver.ProrationDetail.SellerCharge.SendKeys(FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCredit.FASetText("9999999999.999");
                FastDriver.ProrationDetail.SellerCredit.SendKeys(FAKeys.Tab);

                this.VerifyProrationDetailsData(BuyerCharge: "9,999,999,999.99", BuyerCredit: "9,999,999,999.99", SellerCharge: "9,999,999,999.99", SellerCredit: "9,999,999,999.99");
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();

                //Workpane Specific Buttons

                //
                //
                Reports.TestStep = "Perform Hot key operation for Edit button.";
                FastDriver.ProrationTax.Miscellaneous1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                //
                //
                Reports.TestStep = "Perform Hot key operation for Done button.";
                Keyboard.SendKeys("^D");
                Playback.Wait(2000);

                //
                //
                Reports.TestStep = "Perform Hot key operation for Remove button.";
                Keyboard.SendKeys("%R");

                //
                //
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

                //
                //
                Reports.TestStep = "Perform Hot key operation for New button.";
                Keyboard.SendKeys("%N");
                Playback.Wait(3000);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.Description.FASetText("abcdef");
                FastDriver.ProrationDetail.Description.SendKeys(FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCharge.FASetText("5.00");
                FastDriver.ProrationDetail.BuyerCharge.SendKeys(FAKeys.Tab);

                //
                //
                Reports.TestStep = "Perform Hot key operation for Reset button.";
                Keyboard.SendKeys("^R");

                //
                //
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationTax.SwitchToContentFrame();
                //
                //
                Reports.TestStep = "Perform Hot key operation for Done button.";
                Keyboard.SendKeys("^D");
                FastDriver.ProrationMisc.SwitchToContentFrame();
                FastDriver.ProrationMisc.WaitCreation(FastDriver.ProrationMisc.Miscellaneous1);
                //
                //
                Reports.TestStep = "Perform Hot key operation for New button.";
                Keyboard.SendKeys("%N");
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                //
                //
                Reports.TestStep = "Perform Hot key operation for Cancel button.";
                Keyboard.SendKeys("^Q");
                Playback.Wait(1000);

                //
                //
                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FMUC0049_REG0012()
        {
            try
            {
                Reports.TestDescription = "Field Definitions and FM1579 and FM2715 Business Rules covered.";

                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create Order";
                this.CreateFileWithWCF();


                //
                //
                Reports.TestStep = "Click on Edit on Proration Tax1.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad().SwitchToContentFrame();
                string rowCount = FastDriver.ProrationTax.ProrationTaxTable.GetRowCount().ToString();
                FastDriver.ProrationTax.Tax1.FAClick();

                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Enter  Data.";
                FastDriver.ProrationDetail.Amount.FASetText("" + FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCharge.FASetText("22222.22" + FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCharge.FASetText("11111.11" + FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCredit.FASetText("11111.11" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCharge.FASetText("11111.11" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCredit.FASetText("11111.11" + FAKeys.Tab);
                FastDriver.ProrationDetail.ToDate.FASetText(DateTime.Now.ToString("MM-dd-yyyy" + FAKeys.Tab));
                FastDriver.ProrationDetail.FromDate.FASetText(DateTime.Now.ToString("MM-dd-yyyy" + FAKeys.Tab));
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.SwitchToContentFrame();

                //
                //
                Reports.TestStep = "Click on Edit on Proration Tax2.";
                FastDriver.ProrationTax.Tax2.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Enter  Data.";
                FastDriver.ProrationDetail.Amount.FASetText("22222.22" + FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCharge.FASetText("22222.22" + FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCredit.FASetText("22222.22" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCharge.FASetText("22222.22" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCredit.FASetText("22222.22" + FAKeys.Tab);
                FastDriver.ProrationDetail.ToDate.FASetText(DateTime.Now.ToString("MM-dd-yyyy" + FAKeys.Tab));
                FastDriver.ProrationDetail.FromDate.FASetText(DateTime.Now.ToString("MM-dd-yyyy" + FAKeys.Tab));
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.SwitchToContentFrame();

                //
                //
                Reports.TestStep = "Click on Edit on Proration Tax3.";
                FastDriver.ProrationTax.Tax3.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Enter  Data.";
                FastDriver.ProrationDetail.Amount.FASetText("33333.33" + FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCharge.FASetText("33333.33" + FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCredit.FASetText("33333.33" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCharge.FASetText("33333.33" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCredit.FASetText("33333.33" + FAKeys.Tab);
                FastDriver.ProrationDetail.ToDate.FASetText(DateTime.Now.ToString("MM-dd-yyyy" + FAKeys.Tab));
                FastDriver.ProrationDetail.FromDate.FASetText(DateTime.Now.ToString("MM-dd-yyyy" + FAKeys.Tab));
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.SwitchToContentFrame();

                //
                //
                Reports.TestStep = "Click on Remove on Proration Tax2.";
                FastDriver.ProrationTax.Tax2.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.ProrationTax.SwitchToContentFrame();
                FastDriver.ProrationTax.ProrationTaxTable.FireEvent("onchange");

                //
                //
                Reports.TestStep = "Click on Edit on Proration Tax2.";
                FastDriver.ProrationTax.Tax2.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();

                // 
                // 
                Reports.TestStep = "Enter  Data.";
                FastDriver.ProrationDetail.BuyerCharge.FASetText("2020.20" + FAKeys.Tab);
                FastDriver.ProrationDetail.BuyerCredit.FASetText("2020.20" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCharge.FASetText("2020.20" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCredit.FASetText("2020.20" + FAKeys.Tab);
                FastDriver.ProrationDetail.ToDate.FASetText(DateTime.Now.ToString("MM-dd-yyyy" + FAKeys.Tab));
                FastDriver.ProrationDetail.FromDate.FASetText(DateTime.Now.ToString("MM-dd-yyyy" + FAKeys.Tab));
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.SwitchToContentFrame();

                // 
                // 
                Reports.TestStep = "Check Proration Tax quantity";
                Support.AreEqual(rowCount, FastDriver.ProrationTax.ProrationTaxTable.GetRowCount().ToString());

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }


        //Team                           :  SRT-Team2
        //Iteration                      :  r10
        //UserStory                      :  User Story 638220:[Master - ROOT CAUSE] FAST - Tax Description Field has to be typed twice.
        // TestCase                      :  888220
        //Appended By/ Created By        :  Diego Hilario
        [TestMethod]
        public void FMUC0049_REG0013()
        {
            try
            {
                Reports.TestDescription = "To Verify US# 638220 - Proration Tax Description field to be saved correctly";

                Reports.TestStep = "Log in to FAST IIS ";
                Login();

                Reports.TestStep = "Create a basic HUD file ";
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FormType.HUD;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to Proration - Tax screen via (Home>Order Entry>Escrow Charge Processes>Poration>Tax) ";
                FastDriver.ProrationTax.Open();

                Reports.TestStep = "Select the first row 'Poration - Tax 1' and click on Edit ";
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();

                Reports.TestStep = "Change description field (for ex. 'TestDescription') and click on Done ";
                FastDriver.ProrationDetail.EnterProrationDetails("TestDescription", "YEAR", DateTime.Now.ToDateString(), DateTime.Now.ToDateString(), "500.00", false);

                Reports.TestStep = "Enter '500' on Amount:$ field and '500' on Buyer Charge field ";
                FastDriver.ProrationDetail.BuyerCharge.FASetText("15.00");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("30.00");
                FastDriver.ProrationDetail.SellerCharge.FASetText("45.00");
                FastDriver.ProrationDetail.SellerCredit.FASetText("60.00");
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();

                Reports.TestStep = "Ensure Poration - Tax 1 Description is updated and displaying the charge description entered on previous step (for ex. 'TestDescription')";
                Support.AreEqual(DateTime.Now.ToString("M-d-yyyy"), FastDriver.ProrationTax.NthFrom().FAGetText().Clean().ToString(), "Verifying From date is correct");
                Support.AreEqual(DateTime.Now.ToString("M-d-yyyy"), FastDriver.ProrationTax.NthTo().FAGetText().Clean().ToString(), "Verifying To date is correct");
                Support.AreEqual("$500.00", FastDriver.ProrationTax.NthAmount().FAGetText().Clean().ToString(), "Verifying Amount is correct");
                Support.AreEqual("Year", FastDriver.ProrationTax.NthPeriod().FAGetText().Clean().ToString(), "Verifying From date is correct");
                Support.AreEqual("15.00", FastDriver.ProrationTax.NthBuyerCharge().FAGetText().Clean().ToString(), "Verifying Buyer Charge is correct");
                Support.AreEqual("30.00", FastDriver.ProrationTax.NthBuyerCredit().FAGetText().Clean().ToString(), "Verifying Buyer Credit is correct");
                Support.AreEqual("45.00", FastDriver.ProrationTax.NthSellerCharge().FAGetText().Clean().ToString(), "Verifying Seller Charge is correct");
                Support.AreEqual("60.00", FastDriver.ProrationTax.NthSellerCredit().FAGetText().Clean().ToString(), "Verifying Seller Credit is correct");
                Support.AreEqual("TestDescription", FastDriver.ProrationTax.NthDescription().FAGetText().Clean().ToString(), "Verifying Description is correct");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion REGRESSION
        #region Custom Methods

        private void EnterProrationDescAndCharges()
        {
            if (!FastDriver.ProrationDetail.CreditSeller.Selected)
                FastDriver.ProrationDetail.CreditSeller.FAClick();
            FastDriver.ProrationDetail.Amount.FASetText("10.00");
            FastDriver.ProrationDetail.FromDate.FASetText("04-02-2012");
            FastDriver.ProrationDetail.BasedOn.FASelectItem("365");
            FastDriver.ProrationDetail.Per.FASelectItem("YEAR");
            // Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.ProrationDetail.ToDate.FASetText("07-02-2012");
        }


        public static int CreateFile()
        {
            var customFile = RequestFactory.GetDetailedCreateFileDefaultRequest();
            customFile.formType = FormType.CD;

            customFile.File.Properties = new Property[]
                    { 
                        new Property() 
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",

                            ProperyTypeCdID = 15, //Single Family Residence
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA", 
                                    Zip= "92707"
                                } 
                            } 
                        } 
                    };
            try
            {

                int? FileID = FileService.CreateFile(customFile).FileID;
                return (int)FileID;
            }
            catch (Exception)
            {

                throw new Exception("Unable to retrieve FileID.");
            }
        }

        private void Login(bool admLogin = false)
        {
            if (!admLogin)
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            }
            else
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            }

            //
            //

        }
        private void CreateFileWithWCF()
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }
        private void CreateCustomFileWithWCF()
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(this.GetCustomFileRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }

        private void CreateFileWithWCF(CreateFileRequest fileRequest)
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }


        private void FillPaymentDetailsDialog(string BuyerCharge = "", string PaidbyBuyerAtClosing = "", string SellerCharge = "", string PaidbySellerAtClosing = "", string PaidbySellerBeforeClosing = "", string PaidbySellerOthers = "", string sellerCredit = "", string SellerPaidbyOthersPaymentMethod = "", string description = "", string useDefault = "", string payeeName = "", string SellerCreditPaymentMethod = "")
        {

            Playback.Wait(250);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
            FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

            if (!BuyerCharge.Equals(""))
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(BuyerCharge);

            if (!SellerCharge.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(SellerCharge);

            if (!PaidbyBuyerAtClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(PaidbyBuyerAtClosing);

            if (!PaidbySellerAtClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(PaidbySellerAtClosing);

            if (!PaidbySellerBeforeClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(PaidbySellerBeforeClosing);

            if (!PaidbySellerOthers.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(PaidbySellerOthers);

            if (!sellerCredit.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText(sellerCredit);

            if (!SellerPaidbyOthersPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(SellerPaidbyOthersPaymentMethod);

            if (!SellerCreditPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem(SellerCreditPaymentMethod);


            if (!description.Equals(""))
                FastDriver.PaymentDetailsDlg.Description.FASetText(description);

            if (!useDefault.Equals("") && useDefault == true.ToString())
            {
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(true);
            }

            else if (!useDefault.Equals("") && useDefault == false.ToString())
            {
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
            }

            if (payeeName.Equals("EMPTY"))
            { FastDriver.PaymentDetailsDlg.PayeeName.FASetText(""); }

            else if (!payeeName.Equals(""))
            { FastDriver.PaymentDetailsDlg.PayeeName.FASetText(payeeName); }

            //closes the dialog window and switches back to the Fast window;
            FastDriver.PaymentDetailsNewLoanDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.btnDone.FAClick();
            Playback.Wait(500);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.PaymentDetailsDlg.SwitchToContentFrame();

        }

        private void SlowSetText(string textToSet, int miliSeconds = 250)
        {
            char[] arrayOfChar = textToSet.ToCharArray();
            foreach (char c in arrayOfChar)
            {
                Keyboard.SendKeys(c.ToString());
                Playback.Wait(miliSeconds);
            }

        }

        private void VerifyProrationDetailsData(string CreditSeller = "", string DayofClosePaidbySeller = "", string Description = "", string Amount = "", string FromDate = "", string fromInclusive = "", string fromProrate = "", string BasedOn = "", string Per = "", string ToDate = "", string toInclusive = "", string toProrate = "", string BuyerCharge = "", string BuyerCredit = "", string SellerCharge = "", string SellerCredit = "")
        {

            if (!CreditSeller.Equals(""))
            {
                Support.AreEqual(CreditSeller, FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
            }

            if (!DayofClosePaidbySeller.Equals(""))
            {
                Support.AreEqual(DayofClosePaidbySeller, FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
            }

            if (!Description.Equals(""))
            {
                if (!Description.Equals("EMPTY"))
                    Support.AreEqual(Description, FastDriver.ProrationDetail.Description.GetAttribute("value").ToString());

                else
                    Support.AreEqual("", FastDriver.ProrationDetail.Description.GetAttribute("value").ToString());
            }


            if (!Amount.Equals(""))
            {
                if (!Amount.Equals("EMPTY"))
                    Support.AreEqual(Amount, FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());

                else
                    Support.AreEqual("", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
            }

            if (!FromDate.Equals(""))
            {
                if (!FromDate.Equals("EMPTY"))
                    Support.AreEqual(FromDate, FastDriver.ProrationDetail.FromDate.GetAttribute("value").ToString());

                else
                    Support.AreEqual("", FastDriver.ProrationDetail.FromDate.GetAttribute("value").ToString());
            }

            if (!fromInclusive.Equals(""))
            {
                Support.AreEqual(fromInclusive, FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
            }

            if (!fromProrate.Equals(""))
            {
                Support.AreEqual(fromProrate, FastDriver.ProrationDetail.fromProrate.Selected.ToString());
            }


            if (!BasedOn.Equals(""))
            {
                if (!BasedOn.Equals("EMPTY"))
                    Support.AreEqual(BasedOn, FastDriver.ProrationDetail.BasedOn.GetAttribute("value").ToString());

                else
                    Support.AreEqual("", FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString());
            }

            if (!Per.Equals(""))
            {
                if (!Per.Equals("EMPTY"))
                    Support.AreEqual(Per, FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToString());
                else
                    Support.AreEqual("", FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToString());
            }

            if (!ToDate.Equals(""))
            {
                if (!ToDate.Equals("EMPTY"))
                    Support.AreEqual(ToDate, FastDriver.ProrationDetail.ToDate.GetAttribute("value").ToString());

                else
                    Support.AreEqual("", FastDriver.ProrationDetail.ToDate.GetAttribute("value").ToString());
            }

            if (!toInclusive.Equals(""))
            {
                Support.AreEqual(toInclusive, FastDriver.ProrationDetail.toInclusive.Selected.ToString());
            }

            if (!toProrate.Equals(""))
            {
                Support.AreEqual(toProrate, FastDriver.ProrationDetail.toProrate.Selected.ToString());
            }

            if (!BuyerCharge.Equals(""))
            {
                if (!BuyerCharge.Equals("EMPTY"))
                    Support.AreEqual(BuyerCharge, FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString());

                else
                    Support.AreEqual("", FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString());
            }

            if (!BuyerCredit.Equals(""))
            {
                if (!BuyerCredit.Equals("EMPTY"))
                    Support.AreEqual(BuyerCredit, FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString());

                else
                    Support.AreEqual("", FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString());
            }


            if (!SellerCharge.Equals(""))
            {
                if (!SellerCharge.Equals("EMPTY"))
                    Support.AreEqual(SellerCharge, FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").ToString());

                else
                    Support.AreEqual("", FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").ToString());
            }


            if (!SellerCredit.Equals(""))
            {
                if (!SellerCredit.Equals("EMPTY"))
                    Support.AreEqual(SellerCredit, FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString());

                else
                    Support.AreEqual("", FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString());
            }



        }


        private CreateFileRequest GetCustomFileRequest()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    TransactionTypeObjectCD = "CASH",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None
                            }
                        } 
                    },
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                {
                                    new ProductionOffice() 
                                    { 
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    } 
                                }
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = int.Parse(ClosingDisclosureSupport.IMDOfficeBUID), 
                                ProductionOffices = new ProductionOffice[] 
                                { 
                                    new ProductionOffice() 
                                    {
                                        BUID = 0, 
                                        OfficeCode = 0, 
                                        RegionID = 0, 
                                        SeqNum = 0 
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "CA", 
                                    City = "ALBANY", 
                                    County = "ALAMEDA", 
                                    Country = "USA" 
                                } 
                            } 
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            FirstName = "BuyerName", 
                            LastName = "BuyerLastName", 
                            EntityTypeID = 48, 
                            Type = "Individual" 
                        }
                        
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            FirstName = "SellerName",
                            LastName = "SellerLastName",
                            EntityTypeID = 48,
                            Type = "Individual"
                        }
                        
                    }
                }
            };
            #endregion
        }



        # endregion custom methods

        #region Class CleanUp
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
        #endregion Class Cleanup
    }

}



