﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using AutoIt;
using OpenQA.Selenium;
using System.Linq;
using System.Collections.Generic;

namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]//, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class SOT_Section_K : MasterTestClass
    {


        #region 393273- CD Screen – Section K: View details of the charges that are part of the charge group

        [TestMethod]
        public void US_393273_TC_407332_NO_01()
        {

            try
            {
                Reports.TestDescription = "VERIFY THE PRESENCE OF 1ST INSTANCE ASSUMPTION LOAN CHARGES IN LINE K04 POPUP";
                Reports.TestStep = "Login to FAST";
                Login("Home");

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 6000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();
                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Assumption Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("Document Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing the Assumption Loan Charges";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 12345678901.23);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$12,345,678,901.23", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 12345678901.23);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$12,345,678,901.23", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating charges in K04 Popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Assumption Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$691,357,802.46", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("Document Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407333_NO_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY ASSUMPTION LOAN CHARGES WITH EDITED PAYEE NAME AND DESCRIPTION IN LINE K04 POPUP";
                Reports.TestStep = "Login to FAST";
                Login("Home");

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 5000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description2");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 6000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name 1");
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Assumption Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Description1 to Payee Name 1", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("Description2", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();
                
                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }

            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407335_NO_04()
        {
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE ASSUMPTION LOAN CHARGES IN DIFFERENT SECTION WITH MULTIPLE PAYMENT METHOD  AND PAID BY OTHERS POC-L AMOUNT IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";
                Login("Home");

                // 

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 3000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-1000");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("3000");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 2000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.Click();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-7000");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("9000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Assumption Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("-$8,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $9,000.00 P.O.C. Lender", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("-$7,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("Document Fee to Lenders Advantage A Division Of First American Title Ins. $4,000.00 P.O.C.", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                //

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);

            }
        }

        [TestMethod]
        public void US_393273_TC_407336_NO_05()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE PRESENCE OF PAYOFF OF FIRST MORTGAGE LOAN IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                // 

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 9000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$9,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.GetAttribute("Title").Clean());
                Support.AreEqual("$9,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$9,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                //

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing Charges in Payoff Loan Screen";

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 12345678901.23);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$12,345,678,901.23", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                //

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407337_NO_06()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE PRESENCE OF PAYOFF OF FIRST MORTGAGE LOAN IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                // 

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name 1");
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$4,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Description1 to Payee Name 1", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$4,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                //

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407339_NO_08()
        {
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE PAYOFF OF FIRST MORTGAGE LOAN CHARGES IN DIFFERENT SECTION WITH MULTIPLE PAYMENT METHOD AND PAID BY OTHERS POC-L AMOUNT IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                // 

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 4000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("3500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("3000");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Reconveyance Fee", buyerCharge: 10000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge1.FASetText("10000");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-5000");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("15000");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("2000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("-$10,500.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $6,500.00 P.O.C.", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("-$3,500.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Lenders Advantage A Division Of First American Title Ins. $15,000.00 P.O.C. Lender", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("-$7,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407396_NO_10()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF FIRST MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES IN DIFFERENT SECTION WITH BUYER CREDIT PAYMENT METHOD AS POC AND AT CLOSING IN K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                // 

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Reconveyance Fee", buyerCharge: 3000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("2000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$7,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$4,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Lenders Advantage A Division Of First American Title Ins. $2,000.00 P.O.C.", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$3,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                //

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }

            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407397_NO_11()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF FIRST MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES IN DIFFERENT SECTION WITH BUYER CREDIT PAYMENT METHOD AS POC AND AT CLOSING IN K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                // 

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 0.00);
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                //

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }

            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407398_NO_12()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF FIRST MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES IN DIFFERENT SECTION WITH BUYER CREDIT PAYMENT METHOD AS POC AND AT CLOSING IN K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                //

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Creating Charges in HOA Screen";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("237");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$5,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 6000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$6,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();


                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$11,001.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Lien Payoff to Associated Great Northern Mortgage Co.", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("Lien Payoff to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$6,000.50", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                //

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407399_NO_13()
        {
            try
            {
                Reports.TestDescription = "VERIFY HOA CHARGES WITH EDITED PAYEE NAME AND DESCRIPTION IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                //

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Creating Charges in HOA Screen";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("237");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 6000.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description2");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();


                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("Description2", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407403_NO_15()
        {
            try
            {
                Reports.TestDescription = "VERIFY HOA CHARGES WITH PAID BY OTHER- SELLER BROKER AND BUYER BROKER AND MULTIPLE AMOUNT IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                //

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in HOA Screen";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("237");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("-$5,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Lien Payoff to Associated Great Northern Mortgage Co. $7,500.00 P.O.C. Buyer Broker", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("Lien Payoff to Midwest Financial Group $7,500.00 P.O.C. Seller Broker", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407403_NO_15_1()
        {
            try
            {
                Reports.TestDescription = "VERIFY HOA CHARGES WITH PAID BY OTHER- SELLER BROKER AND BUYER BROKER AND MULTIPLE AMOUNT IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                //

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in HOA Screen";

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("237");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("3500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("4000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 100.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$100.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("-$2,400.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("Lien Payoff to Associated Great Northern Mortgage Co. $7,500.00 P.O.C.", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("Lien Payoff to Midwest Financial Group", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());

                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407403_NO_16()
        {
            try
            {
                Reports.TestDescription = "VERIFY HOA CHARGES WITH PAID BY OTHER- SELLER BROKER AND BUYER BROKER AND MULTIPLE AMOUNT IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";

                Login("Home");

                //

                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("237");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 5000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$5,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", buyerCharge: 6000.50);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$6,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$11,001.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("a", FastDriver.ClosingDisclosure.K04SCSubSeqNo1.Text.Trim());
                Support.AreEqual("Property Taxes 1", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.K04SubTotalAmt1.Text.Trim());
                Support.AreEqual("Tax Installment: Amount to Associated Great Northern Mortgage Co.", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                Support.AreEqual("b", FastDriver.ClosingDisclosure.K04SCSubSeqNo2.Text.Trim());
                Support.AreEqual("Property Taxes 2", FastDriver.ClosingDisclosure.K04SubCharge3.Text.Trim());
                Support.AreEqual("$6,000.50", FastDriver.ClosingDisclosure.K04SubTotalAmt2.Text.Trim());
                Support.AreEqual("County Tax to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge4.Text.Trim());
                Support.AreEqual("$6,000.50", FastDriver.ClosingDisclosure.K04SubChargeAmt4.Text.Trim());

                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407411_NO_18()
        {
            try
            {
                Reports.TestDescription = "VERIFY SECOND PROPERTY TAX CHECK INSTANCE CHARGE IN SECTION K04 POPUP";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic File";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in Property Tax Check Screen for second instance";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("237");
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 5000.00);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", buyerCharge: 6000.00);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("a", FastDriver.ClosingDisclosure.K04SCSubSeqNo1.Text.Trim());
                Support.AreEqual("Property Taxes 2", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.K04SubTotalAmt1.Text.Trim());
                Support.AreEqual("Tax Installment: Amount to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                Support.AreEqual("County Tax to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.K04SubCharge3.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt3.Text.Trim());

                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407414_NO_19()
        {
            try
            {
                Reports.TestDescription = "VERIFY PROPERTY TAX CHECK MULTIPLE INSTANCE CHARGE WITH EDITED PAYEE NAME AND DESCRIPTION IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic File";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 5000.00);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", buyerCharge: 6000.00);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description2");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("a", FastDriver.ClosingDisclosure.K04SCSubSeqNo1.Text.Trim());
                Support.AreEqual("Property Taxes 1", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.K04SubTotalAmt1.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                Support.AreEqual("b", FastDriver.ClosingDisclosure.K04SCSubSeqNo2.Text.Trim());
                Support.AreEqual("Property Taxes 2", FastDriver.ClosingDisclosure.K04SubCharge3.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.K04SubTotalAmt2.Text.Trim());
                Support.AreEqual("Description2", FastDriver.ClosingDisclosure.K04SubCharge4.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt4.Text.Trim());

                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407418_NO_21()
        {
            try
            {
                Reports.TestDescription = "VERIFY PROPERTY TAX CHECK CHARGES WITH PAID BY OTHER- SELLER BROKER AND BUYER BROKER AND MULTIPLE METHODS AMOUNT IN LINE K04 POPUP";
                Reports.TestStep = "Login to file side";
                Login("Home");

                Reports.TestStep = "Create a basic File";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in Property Tax Check Screen for second instance";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("237");
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 5000.00);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "City Tax", buyerCharge: 5000.00);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", buyerCharge: 6000.00);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("8000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("-$7,500.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("a", FastDriver.ClosingDisclosure.K04SCSubSeqNo1.Text.Trim());
                Support.AreEqual("Property Taxes 2", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("-$7,500.00", FastDriver.ClosingDisclosure.K04SubTotalAmt1.Text.Trim());
                Support.AreEqual("Tax Installment: Amount to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Buyer Broker", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("City Tax to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller Broker", FastDriver.ClosingDisclosure.K04SubCharge3.Text.Trim());
                Support.AreEqual("County Tax to Lenders Advantage A Division Of First American Title Ins. $8,500.00 P.O.C.", FastDriver.ClosingDisclosure.K04SubCharge4.Text.Trim());

                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407450_NO_22()
        {
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE FEES IN SECTION K04 POPUP";
                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");

                Reports.TestStep = "Selecting Region to have Region-level access";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);
                
                Reports.TestStep = "Creating Fees";
                FastDriver.LeftNavigation.Navigate<FeeSetup>("Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad();
                FastDriver.FeeSetup.CreateFee("CDFee1", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.FeeSetup.CreateFee("CDFee2", "Recording Fee - Deed", false, true, "Payee Name", "K", "K");
                FastDriver.WebDriver.Quit();
                //

                Reports.TestStep = "Logging in to FAST IIS";
                Login("Home");
                
                Reports.TestStep = "Create a basic File";
                CreateCDFile();
                
                Reports.TestStep = "Navigate to File Fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee1");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Recording Fee - Deed");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee2");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "CDFee1", buyerCharge: 5000.00);
                FastDriver.FileFees.FeeDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("Additional1");
                string payee1 = FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FAGetValue();
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.RecordingandTax);
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.SelectRecording);
                FastDriver.FileFees.SelectRecording.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.RecordingTable, "CDFee2", buyerCharge: 6000.00);
                FastDriver.FileFees.RecordingTaxFeeDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("Additional2");
                string payee2 = FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FAGetValue();
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("CDFee1 Additional1 to " + payee1, FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("CDFee2 Additional2 to " + payee2, FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());

                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to File Fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                Support.AreEqual("on", FastDriver.FileFees.SelectCheckbox.FAGetValue());
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "CDFee1 Additional1", buyerCharge: 12345678901.23);
                FastDriver.FileFees.FeeDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$12,345,678,901.23", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.RecordingandTax);
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.SelectRecording);
                Support.AreEqual(true, FastDriver.FileFees.SelectRecording.IsSelected(), "Verifying if checkbox is selected.");
                FastDriver.TableCharges.Enter(FastDriver.FileFees.RecordingTable, "CDFee2 Additional2", buyerCharge: 12345678901.23);
                FastDriver.FileFees.RecordingTaxFeeDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$12,345,678,901.23", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$691,357,802.46", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("CDFee1 Additional1 to " + payee1, FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("CDFee2 Additional2 to " + payee2, FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407455_NO_23()
        {
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE FEES IN SECTION K04 POPUP";

                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");
                
                Reports.TestStep = "Selecting Region to have Region-level access";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);
                
                Reports.TestStep = "Creating Fees";
                FastDriver.LeftNavigation.Navigate<FeeSetup>("Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad();
                FastDriver.FeeSetup.CreateFee("CDFee3", "Escrow Fee", true, true, "", "K", "K");
                FastDriver.FeeSetup.CreateFee("CDFee4", "Escrow Fee", true, true, "", "K", "K");
                FastDriver.WebDriver.Quit();
                
                Reports.TestStep = "Logging in to FAST IIS";
                Login("Home");
                
                Reports.TestStep = "Create a basic File";
                CreateCDFile();
                
                Reports.TestStep = "Navigate to File Fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee3");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee4");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                //

                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "CDFee3", buyerCharge: 5000.00);
                FastDriver.FileFees.FeeDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.Description.FASetText("FDescription123");
                FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FASetText("FPayee123");
                string payee = FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FAGetValue();
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "CDFee4", buyerCharge: 6000.00);
                FastDriver.FileFees.FeeDetails1.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.Description.FASetText("SDescription123");
                FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FASetText("SPayee123");
                string payee2 = FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FAGetValue();
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("FDescription123 to " + payee, FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("SDescription123 to " + payee2, FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_393273_TC_407455_NO_25()
        {
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE FEES IN SECTION K04 POPUP";
                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");
                
                Reports.TestStep = "Selecting Region to have Region-level access";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);
                
                Reports.TestStep = "Creating Fees";
                FastDriver.LeftNavigation.Navigate<FeeSetup>("Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad();
                FastDriver.FeeSetup.CreateFee("CDFee5", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.FeeSetup.CreateFee("CDFee6", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.FeeSetup.CreateFee("CDFee7", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Logging in to FAST IIS";
                Login("Home");
                
                Reports.TestStep = "Create a basic File";
                CreateCDFile();

                Reports.TestStep = "Creating New Loan and Mortgage Broker Instances";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Navigate to File Fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee5");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee6");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee7");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "CDFee5", buyerCharge: 5000.00);
                FastDriver.FileFees.FeeDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                string payee = FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FAGetValue();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "CDFee6", buyerCharge: 1000.00);
                FastDriver.FileFees.SelectCheckbox1.FASetCheckbox(true);
                FastDriver.FileFees.FeeDetails1.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                string payee1 = FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FAGetValue();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Mortgage Broker");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "CDFee7", buyerCharge: 4000.00);
                FastDriver.FileFees.SelectCheckbox2.FASetCheckbox(true);
                FastDriver.FileFees.FeeDetails2.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                string payee2 = FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FAGetValue();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("3500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("3000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Mortgage Broker");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the K04 popup";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();

                Support.AreEqual("Buyer Charges", FastDriver.ClosingDisclosure.K04BuyerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.ClosingDisclosure.K04SubSecNo.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.k04PopupDesc.Text.Trim());
                Support.AreEqual("-$5,500.00", FastDriver.ClosingDisclosure.K04TotalAmt.Text.Trim());
                Support.AreEqual("CDFee5 to First American Title Company $7,500.00 P.O.C. Lender", FastDriver.ClosingDisclosure.K04SubCharge1.Text.Trim());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.K04SubChargeAmt1.Text.Trim());
                Support.AreEqual("CDFee6 to First American Title Company $1,500.00 P.O.C. MB", FastDriver.ClosingDisclosure.K04SubCharge2.Text.Trim());
                Support.AreEqual("-$500.00", FastDriver.ClosingDisclosure.K04SubChargeAmt2.Text.Trim());
                Support.AreEqual("CDFee7 to First American Title Company $6,500.00 P.O.C.", FastDriver.ClosingDisclosure.K04SubCharge3.Text.Trim());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.K04SubChargeAmt3.Text.Trim());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();

                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        #endregion

        #region 446851- CD Screen - Section K: Display Adjustments on lines K05 to K07

        [TestMethod]
        public void US_446851_TC_447594_NO_01()
        {

            try
            {

                Reports.TestDescription = "VERIFY OFFSET ADJUSTMENTS AMOUNTS IN SECTION K";
                Reports.TestStep = "Login to IIS";
                Login("Home");

                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Offset Adjustment Screen";

                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", buyerCharge: 5000.50);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 10000.50);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK05_Seqno.FAClick();

                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionK05_Seqno.Text);
                Support.AreEqual("Assign Tenant Lease/Rent", FastDriver.ClosingDisclosure.SectionK05_Label.Text);
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionK05_Amt.Text);
                FastDriver.ClosingDisclosure.SectionK06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionK06_Seqno.Text);
                Support.AreEqual("Assign Tenant Security Deposit", FastDriver.ClosingDisclosure.SectionK06_Label.Text);
                Support.AreEqual("$10,000.50", FastDriver.ClosingDisclosure.SectionK06_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void US_446851_TC_447602_NO_03()
        {
            try
            {

                Reports.TestDescription = "VERIFY ADHOC MISCELLANEOUS ADJUSTMENTS AMOUNTS IN SECTION K";
                Reports.TestStep = "Login to file side";
                Login("Home");

                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";

                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 1", buyerCharge: 12345678901.23, addNewRow: true);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 2", buyerCharge: 12345678901.23, addNewRow: true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK05_Seqno.FAClick();

                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionK05_Seqno.Text);
                Support.AreEqual("Miscellaneous Adhoc 1", FastDriver.ClosingDisclosure.SectionK05_Label.Text);
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionK05_Amt.Text);
                FastDriver.ClosingDisclosure.SectionK06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionK06_Seqno.Text);
                Support.AreEqual("Miscellaneous Adhoc 2", FastDriver.ClosingDisclosure.SectionK06_Label.Text);
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionK06_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_446851_TC_447607_NO_04()
        {
            try
            {

                Reports.TestDescription = "VERIFY OFFSET AND MISCELLANEOUS ADJUSTMENTS AMOUNTS IN SECTION K";
                Reports.TestStep = "Login to IIS";
                Login("Home");

                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Offset Adjustment Screen";

                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", buyerCharge: 5000.50);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 10000.50);
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";

                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 1", buyerCharge: 15000.50, addNewRow: true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK05_Seqno.FAClick();

                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionK05_Seqno.Text);
                Support.AreEqual("Assign Tenant Lease/Rent", FastDriver.ClosingDisclosure.SectionK05_Label.Text);
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionK05_Amt.Text);
                FastDriver.ClosingDisclosure.SectionK06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionK06_Seqno.Text);
                Support.AreEqual("Assign Tenant Security Deposit", FastDriver.ClosingDisclosure.SectionK06_Label.Text);
                Support.AreEqual("$10,000.50", FastDriver.ClosingDisclosure.SectionK06_Amt.Text);
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionK07_Seqno.Text);
                Support.AreEqual("Miscellaneous Adhoc 1", FastDriver.ClosingDisclosure.SectionK07_Label.Text);
                Support.AreEqual("$15,000.50", FastDriver.ClosingDisclosure.SectionK07_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing Charges in Offset Adjustment Screen";

                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", buyerCharge: 12345678901.23);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 12345678901.23);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing Charges in Miscellaneous Adjustment Screen";

                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 1", buyerCharge: 12345678901.23, newDescription: "Miscellaneous Adhoc @123");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK05_Seqno.FAClick();

                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionK05_Seqno.Text);
                Support.AreEqual("Assign Tenant Lease/Rent", FastDriver.ClosingDisclosure.SectionK05_Label.Text);
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionK05_Amt.Text);
                FastDriver.ClosingDisclosure.SectionK06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionK06_Seqno.Text);
                Support.AreEqual("Assign Tenant Security Deposit", FastDriver.ClosingDisclosure.SectionK06_Label.Text);
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionK06_Amt.Text);
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionK07_Seqno.Text);
                Support.AreEqual("Miscellaneous Adhoc @123", FastDriver.ClosingDisclosure.SectionK07_Label.Text);
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionK07_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_446851_TC_447609_NO_05()
        {
            try
            {

                Reports.TestDescription = "VERIFY OFFSET AND MISCELLANEOUS ADJUSTMENTS AMOUNTS IN LINE K05 TO K07";
                Reports.TestStep = "Login to IIS";
                Login("Home");

                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();


                Reports.TestStep = "Creating Charges in Offset Adjustment Screen";

                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 20000.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";

                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 1", buyerCharge: 30000.00, addNewRow: true);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 2", buyerCharge: 40000.00, addNewRow: true);
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK05_Seqno.FAClick();

                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionK05_Seqno.Text);
                Support.AreEqual("Assign Tenant Security Deposit", FastDriver.ClosingDisclosure.SectionK05_Label.Text);
                Support.AreEqual("$20,000.00", FastDriver.ClosingDisclosure.SectionK05_Amt.Text);
                FastDriver.ClosingDisclosure.SectionK06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionK06_Seqno.Text);
                Support.AreEqual("Miscellaneous Adhoc 1", FastDriver.ClosingDisclosure.SectionK06_Label.Text);
                Support.AreEqual("$30,000.00", FastDriver.ClosingDisclosure.SectionK06_Amt.Text);
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionK07_Seqno.Text);
                Support.AreEqual("Miscellaneous Adhoc 2", FastDriver.ClosingDisclosure.SectionK07_Label.Text);
                Support.AreEqual("$40,000.00", FastDriver.ClosingDisclosure.SectionK07_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deleting Charges in Offset Adjustment Screen";

                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 0.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deleting Charges in Miscellaneous Adjustment Screen";


                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 1", buyerCharge: 0.00);
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                FastDriver.ClosingDisclosure.SectionK05_Seqno.FAClick();

                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionK05_Seqno.Text);
                Support.AreEqual("Miscellaneous Adhoc 2", FastDriver.ClosingDisclosure.SectionK05_Label.Text);
                Support.AreEqual("$40,000.00", FastDriver.ClosingDisclosure.SectionK05_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";

                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region 447603 & 393272: CD Screen – Section K: Display Buyer Charges on line K 04 & CD Screen – Section K: Display Asterisk for charge groups

        [TestMethod]
        public void US_447603_TC_407518_NO_02()
        {
            try
            {

                Reports.TestDescription = "VERIFY  PRINCIPAL REDUCTION/Construction Holdback  CHARGE IN LINE K04 HAVING PAID BY BUYER BEFORE CLOSING AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");

                //
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                //
                Reports.TestStep = "Creating Charges in New Loan Screen";

                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 5000.00);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("7500");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.BottomFrame.Done();

                //
                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Description1 to Payee Name1 $7,500.00 P.O.C. Borrower", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407520_NO_04()
        {
            try
            {

                Reports.TestDescription = "VERIFY PRINCIPAL REDUCTION/Construction Holdback CHARGE IN LINE K04 HAVING BUYER PAID BY OTHERS LENDER AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");

                //
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 5000.00);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                //
                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group $7,500.00 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407521_NO_05()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion
                Reports.TestDescription = "VERIFY PRINCIPAL REDUCTION/Construction Holdback CHARGE IN LINE K04 HAVING BUYER PAID BY OTHERS MORTGAGE BROKER AMOUNT";

                //
                Reports.TestStep = "Login to file side";
                Login("Home");

                //
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in New Loan Screen";

                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 5000.00);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.BottomFrame.Done();

                //
                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group $7,500.00 P.O.C. MB", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407522_NO_06()
        {
            try
            {

                Reports.TestDescription = "VERIFY PRINCIPAL REDUCTION/Construction Holdback CHARGE IN LINE K04  HAVING  AMOUNT IN MULTIPLE METHOD";
                Reports.TestStep = "Login to file side";
                Login("Home");

                //

                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Charges in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", buyerCharge: 5000.00);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-3500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("8000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();

                //
                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Construction Holdback to Midwest Financial Group $8,500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString());
                Support.AreEqual("-$3,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_393272_TC_407523_NO_07()
        {
            try
            {

                Reports.TestDescription = "VERIFY  FIRST, SECOND AND  THIRD PROPERTY TAX CHECK INSTANCE CHARGES IN SECTION K";
                Reports.TestStep = "Login to file side";
                Login("Home");

                //

                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                //

                Reports.TestStep = "Creating Buyer and seller Broker Instance";

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("237");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 5000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", buyerCharge: 5000.50);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", buyerCharge: 5000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$15,001.50", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407525_NO_09()
        {
            try
            {

                Reports.TestDescription = "VERIFY  FIRST PROPERTY TAX CHECK INSTANCE CHARGE IN SECTION K HAVING PAID BY BUYER BEFORE CLOSING AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");

                //
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();

                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("237");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 5000.00);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("7500");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Description1 to Payee Name1 $7,500.00 P.O.C. Borrower", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407526_NO_10()
        {
            try
            {

                Reports.TestDescription = "VERIFY  FIRST PROPERTY TAX CHECK INSTANCE CHARGE IN SECTION K HAVING BUYER PAID BY OTHERS POC AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");

                //
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();

                Reports.TestStep = "Creating Buyer and seller Broker Instance";

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();

                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "City Tax", buyerCharge: 5000.00);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //
                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("City Tax $7,500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407527_NO_11()
        {
            try
            {
                Reports.TestDescription = "VERIFY  FIRST PROPERTY TAX CHECK INSTANCE CHARGE IN SECTION K HAVING BUYER PAID BY OTHERS BUYER BROKER AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", buyerCharge: 5000.00);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Tax Installment: Interest Due to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Buyer Broker", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407529_NO_13()
        {
            try
            {

                Reports.TestDescription = "VERIFY  FIRST PROPERTY TAX CHECK INSTANCE CHARGE IN SECTION K  HAVING  AMOUNT IN MULTIPLE METHOD";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Partial Payment Amt", buyerCharge: 5000.00);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Tax Installment: Partial Payment Amt to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_393272_TC_407545_NO_27()
        {
            try
            {

                Reports.TestDescription = "VERIFY  FIRST AND SECOND PAYOFF LOAN INSTANCE CHARGES IN SECTION K";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("5000");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.LoanChargesTable, "Principal Balance", buyerCharge: 5000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$9,000.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_393272_TC_407545_NO_27_1()
        {
            try
            {

                Reports.TestDescription = "VERIFY  FIRST AND SECOND PAYOFF LOAN INSTANCE CHARGES IN SECTION K";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.BottomFrame.New();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("BOA");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 6000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.LoanChargesTable, "Principal Balance", buyerCharge: 6000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section K in CD Screen";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Payoff Loan 2 Charges", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407546_NO_28()
        {
            try
            {


                Reports.TestDescription = "VERIFY CHARGE GROUP DESCRIPTION FOR SINGLE PAYOFF LOAN CHARGE IN SECTION K";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$4,000.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407550_NO_29()
        {
            try
            {

                Reports.TestDescription = "VERIFY PAYOFF LOAN CHARGE IN SECTION K HAVING BUYER CREDIT AS POC";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 0.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();

                //
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("sectionK_amt4", FastDriver.ClosingDisclosure.SectionK04_Amt.GetAttribute("id").ToString());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_393272_TC_407551_NO_30()
        {
            try
            {

                Reports.TestDescription = "VERIFY  FIRST, SECOND AND  THIRD HOMEOWNER ASSOCIATION INSTANCE CHARGES IN SECTION K";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in HOA Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("237");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$15,001.50", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407553_NO_32()
        {
            try
            {

                Reports.TestDescription = "VERIFY  FIRST HOMEOWNER ASSOCIATION INSTANCE CHARGE IN SECTION K HAVING PAID BY BUYER BEFORE CLOSING AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();

                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in HOA Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("7500");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("Description1 to Payee Name1 $7,500.00 P.O.C. Borrower", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407555_NO_33()
        {
            try
            {

                Reports.TestDescription = "VERIFY  FIRST HOMEOWNER ASSOCIATION INSTANCE CHARGE IN SECTION K HAVING BUYER PAID BY OTHERS BUYER BROKER AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in HOA Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("Lien Payoff $7,500.00 P.O.C. Buyer Broker", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407557_NO_35()
        {
            try
            {
                Reports.TestDescription = "VERIFY  FIRST HOMEOWNER ASSOCIATION INSTANCE CHARGE IN SECTION K HAVING BUYER PAID BY OTHERS POC AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in HOA Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("Lien Payoff to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407558_NO_36()
        {
            try
            {
                Reports.TestDescription = "VERIFY  FIRST HOMEOWNER ASSOCIATION INSTANCE CHARGE IN SECTION K HAVING  AMOUNT IN MULTIPLE METHOD";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in HOA Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 5000.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-3500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("8000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("Lien Payoff to Lenders Advantage A Division Of First American Title Ins. $8,500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Clean());
                Support.AreEqual("-$3,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_393272_TC_407559_NO_37()
        {
            try
            {
                Reports.TestDescription = "VERIFY FIRST AND SECOND ASSUMPTION LOAN CHARGES IN SECTION K";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 5000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.BottomFrame.Done();


                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("Assumption Loan 1 Charges", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Trim().Clean());
                Support.AreEqual("$10,000.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_393272_TC_407559_NO_37_1()
        {
            try
            {
                Reports.TestDescription = "VERIFY FIRST AND SECOND ASSUMPTION LOAN CHARGES IN SECTION K";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.BottomFrame.New();

                Reports.TestStep = "Adding Charges for Assumption Loan Second Instance";
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("248");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 6000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 6000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("Assumption Loan 2 Charges", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$12,000.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407561_NO_39()
        {
            try
            {
                Reports.TestDescription = "VERIFY  ASSUMPTION LOAN CHARGE IN SECTION K HAVING PAID BY BUYER BEFORE CLOSING AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("7500");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("Description1 to Payee Name1 $7,500.00 P.O.C. Borrower", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Trim().Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407563_NO_41()
        {
            try
            {
                Reports.TestDescription = "VERIFY ASSUMPTION LOAN CHARGE IN SECTION K HAVING BUYER PAID BY OTHERS POC-L AMOUNT";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Late Charge", buyerCharge: 5000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("Late Charge to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407564_NO_42()
        {
            try
            {
                Reports.TestDescription = "VERIFY ASSUMPTION LOAN CHARGE IN SECTION K  HAVING  AMOUNT IN MULTIPLE METHOD";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Late Charge", buyerCharge: 5000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-3500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("8000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("Late Charge to Lenders Advantage A Division Of First American Title Ins. $8,500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Clean());
                Support.AreEqual("-$3,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_393272_TC_407566_NO_43()
        {
            try
            {

                Reports.TestDescription = "VERIFY MULTIPLE FEES IN SECTION K";
                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");
                
                Reports.TestStep = "Selecting specific Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);

                Reports.TestStep = "Adding Fee values";
                FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad();
                FastDriver.FeeSetup.CreateFee("MyFeeDescription1", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.FeeSetup.CreateFee("MyFeeDescription2", "Recording Fee - Deed", false, false, "", "K", "K");
                FastDriver.WebDriver.Quit();
                
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Navigate to file fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("MyFeeDescription1");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Recording Fee - Deed");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("MyFeeDescription2");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Entering buyer charge for the fees";
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.AddFees);
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "MyFeeDescription1", buyerCharge: 5000.00);
                FastDriver.FileFees.FeeDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.RecordingandTax);
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.RecordingandTax);
                FastDriver.FileFees.SelectRecording.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.RecordingTable, "MyFeeDescription2", buyerCharge: 6000.00);
                FastDriver.FileFees.RecordingTaxFeeDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$6,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                Reports.TestStep = "Saving Fees";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text);
                Support.AreEqual("* Property Taxes", FastDriver.ClosingDisclosure.SectionK04_Label.Text.Clean());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407569_NO_45()
        {
            try
            {

                Reports.TestDescription = "VERIFY FEES IN SECTION K HAVING PAID BY BUYER BEFORE CLOSING AMOUNT";
                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");
                
                Reports.TestStep = "Selecting specific Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);
                
                Reports.TestStep = "Adding Fee values";
                FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad();
                FastDriver.FeeSetup.CreateFee("MyFeeDescription5", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.WebDriver.Quit();
                
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Navigate to file fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("MyFeeDescription5");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering buyer charge for the fees";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "MyFeeDescription5", buyerCharge: 5000.00);
                FastDriver.FileFees.FeeDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("Addl Desc123");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("7500");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Saving Fees";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("MyFeeDescription5 Addl Desc123 to First American Title Company $7,500.00 P.O.C. Borrower", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407571_NO_47()
        {
            try
            {

                Reports.TestDescription = "VERIFY FEES IN SECTION K HAVING BUYER PAID BY OTHERS LENDER AMOUNT";
                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");
                
                Reports.TestStep = "Selecting specific Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);
                
                Reports.TestStep = "Adding Fee values";
                FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad();
                FastDriver.FeeSetup.CreateFee("MyFeeDescription5", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.WebDriver.Quit();
                
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating New Loan Instances";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to file fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("MyFeeDescription5");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Entering buyer charge for the fees";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "MyFeeDescription5", buyerCharge: 5000.00);
                FastDriver.FileFees.FeeDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string PayTo = FastDriver.PaymentDetailsDlg.PayeeNameCD.FAGetValue();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem(@"Lender");
                FastDriver.DialogBottomFrame.ClickDone();
                
                Reports.TestStep = "Saving Fees";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("MyFeeDescription5 to " + PayTo + " $7,500.00 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407573_NO_48()
        {
            try
            {

                Reports.TestDescription = "VERIFY FEES IN SECTION K HAVING BUYER PAID BY OTHERS MORTGAGE BROKER AMOUNT";
                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");
                
                Reports.TestStep = "Selecting specific Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);
                
                Reports.TestStep = "Adding Fee values";
                FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad();
                FastDriver.FeeSetup.CreateFee("MyFeeDescription5", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.WebDriver.Quit();
                
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating New Loan and Mortgage Broker Instances";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to file fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("MyFeeDescription5");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Entering buyer charge for the fees";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "MyFeeDescription5", buyerCharge: 5000.00);
                FastDriver.FileFees.FeeDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string PayTo = FastDriver.PaymentDetailsDlg.PayeeNameCD.FAGetValue();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem(@"Mortgage Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                Reports.TestStep = "Saving Fees";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("MyFeeDescription5 to " + PayTo + " $7,500.00 P.O.C. MB", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447603_TC_407574_NO_49()
        {
            try
            {

                Reports.TestDescription = "VERIFY FEES IN SECTION K HAVING AMOUNT IN MULTIPLE METHOD";
                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");

                Reports.TestStep = "Selecting specific Region";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);
                
                Reports.TestStep = "Adding Fee values";
                FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad();
                FastDriver.FeeSetup.CreateFee("MyFeeDescription5", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.WebDriver.Quit();
                
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file.";
                CreateCDFile();
                
                Reports.TestStep = "Creating New Loan and Mortgage Broker Instances";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to file fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("MyFeeDescription5");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Entering buyer charge for the fees";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "MyFeeDescription5", buyerCharge: 5000.00);
                FastDriver.FileFees.FeeDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-3500.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("500.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("8000.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem(@"Mortgage Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                Reports.TestStep = "Saving Fees";
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the charges in Section K in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionK04_Seqno.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("MyFeeDescription5 to First American Title Company $8,500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").Clean());
                Support.AreEqual("-$3,500.00", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region  446855 - CD SCREEN - SECTION K - DISPLAY SUPPLEMENTAL SUMMARY LINE ON LINE K07

        [TestMethod]
        public void US_446855_TC_449591_NO_01()
        {

            try
            {
                Reports.TestDescription = "DISPLAY AND VERIFY SUPPLEMENTAL SUMMARY LINE ON LINE K07 IN CD SCREEN.";
                Reports.TestStep = "Logging in to FAST IIS";
                Login("Home");
                
                Reports.TestStep = "Create a basic File";
                CreateCDFile();
                
                Reports.TestStep = "NAVIGATE TO OFF-SET SCREEN AND ENTER BUYER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", buyerCharge: 100.00);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 12345678910.12);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Offset Adhoc 1", buyerCharge: 250.50, addNewRow: true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "NAVIGATE TO Miscellaneous SCREEN AND ENTER BUYER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Adjustment Adhoc 1", buyerCharge: 12345678910.12, addNewRow: true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionK07_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK07_Label.Text.Trim());
                Support.AreEqual("$345,679,160.62", FastDriver.ClosingDisclosure.SectionK07_Amt.Text.Trim());
                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionK07a_Seqno.Text.Trim());
                Support.AreEqual("Assign Tenant Security Deposit", FastDriver.ClosingDisclosure.SectionK07a_Label.Text.Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionK07a_Amt.Text.Trim());
                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionK07b_Seqno.Text.Trim());
                Support.AreEqual("Offset Adhoc 1", FastDriver.ClosingDisclosure.SectionK07b_Label.Text.Trim());
                Support.AreEqual("$250.50", FastDriver.ClosingDisclosure.SectionK07b_Amt.Text.Trim());

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region 446857-CD SCREEN - SECTION K: SUPPLEMENTAL ADJUSTMENTS FOR SECTION K

        [TestMethod]
        public void US_446857_TC_458225_NO_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE DESCRIPTION AND LINE NUMBERS FOR ADJUSTMENTS OFFSET AND ADHOC OFFSET AMOUNTS IN THE SUPPLEMENTAL PAGE.";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic File";
                CreateCDFile();
                
                Reports.TestStep = "NAVIGATE TO OFF-SET SCREEN AND ENTER BUYER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", buyerCharge: 100.00);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 200.50);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Offset Adhoc 1", buyerCharge: 12345678910.12, addNewRow: true);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Offset Adhoc 2", buyerCharge: 0.75, addNewRow: true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionK07_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK07_Label.Text.Trim());
                Support.AreEqual("$345,678,910.87", FastDriver.ClosingDisclosure.SectionK07_Amt.Text.Trim());
                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionK07a_Seqno.Text.Trim());
                Support.AreEqual("Offset Adhoc 1", FastDriver.ClosingDisclosure.SectionK07a_Label.Text.Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionK07a_Amt.Text.Trim());
                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionK07b_Seqno.Text.Trim());
                Support.AreEqual("Offset Adhoc 2", FastDriver.ClosingDisclosure.SectionK07b_Label.Text.Trim());
                Support.AreEqual("$0.75", FastDriver.ClosingDisclosure.SectionK07b_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_446857_TC_458227_NO_03()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE DESCRIPTION AND LINE NUMBERS FOR ADHOC OFF-SET AND ADHOC MISCELLANEOUS ADJUSTMENTS AMOUNTS IN THE SUPPLEMENTAL PAGE.";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic File";
                CreateCDFile();
                
                Reports.TestStep = "NAVIGATE TO OFF-SET SCREEN AND ENTER BUYER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", buyerCharge: 100.00);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 200.50);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Offset Adhoc 1", buyerCharge: 12345678910.12, addNewRow: true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO Miscellaneous SCREEN AND ENTER BUYER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 1", buyerCharge: 12345678910.12, addNewRow: true);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Miscellaneous Adhoc 2", buyerCharge: 0.75, addNewRow: true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionK07_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK07_Label.Text.Trim());
                Support.AreEqual("$691,357,820.99", FastDriver.ClosingDisclosure.SectionK07_Amt.Text.Trim());
                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionK07a_Seqno.Text.Trim());
                Support.AreEqual("Miscellaneous Adhoc 1", FastDriver.ClosingDisclosure.SectionK07a_Label.Text.Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionK07a_Amt.Text.Trim());
                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionK07b_Seqno.Text.Trim());
                Support.AreEqual("Miscellaneous Adhoc 2", FastDriver.ClosingDisclosure.SectionK07b_Label.Text.Trim());
                Support.AreEqual("$0.75", FastDriver.ClosingDisclosure.SectionK07b_Amt.Text.Trim());
                Support.AreEqual("07c", FastDriver.ClosingDisclosure.SectionKSupK03_Seqno.Text.Trim());
                Support.AreEqual("Offset Adhoc 1", FastDriver.ClosingDisclosure.SectionKSupK03_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionKSupK03_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region 213050-CD SCREEN - SECTION K: DUE FROM BORROWER AT CLOSING

        [TestMethod]
        public void US_213050_TC_456946_NO_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY K SECTION HEADER AMOUNT WHEN BUYER CHARGES ARE AVAILABLE FROM K08 TO K15.";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                Reports.TestStep = "Creating Charges in Proration tax Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                double PTBuyerCharge1 = double.Parse(FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "01/01/2015", "01/05/2015", "1000.00", true, "QUARTER"));
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                double PTBuyerCharge2 = double.Parse(FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "01/01/2015", "01/05/2015", "2000.00", true, "QUARTER"));
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                double PTBuyerCharge3 = double.Parse(FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "01/01/2015", "01/05/2015", "3000.00", true, "QUARTER"));
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();

                Reports.TestStep = "Creating Charges in Utility Screen";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.CreateUtilityCharges("314", "1000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                double UtilityBC1 = double.Parse(FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.New();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.CreateUtilityCharges("248", "2000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction(3, 2, TableAction.Click);
                FastDriver.UtilitySummary.Edit.FAClick();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                double UtilityBC2 = double.Parse(FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.New();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.CreateUtilityCharges("248", "3000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.UtilitySummary.Edit.FAClick();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                double UtilityBC3 = double.Parse(FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.New();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.CreateUtilityCharges("248", "4000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction(5, 2, TableAction.Click);
                FastDriver.UtilitySummary.Edit.FAClick();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                double UtilityBC4 = double.Parse(FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.New();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.CreateUtilityCharges("248", "5000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                FastDriver.UtilitySummary.SummaryTable.PerformTableAction(6, 2, TableAction.Click);
                FastDriver.UtilitySummary.Edit.FAClick();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                double UtilityBC5 = double.Parse(FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section K";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                double Amount = PTBuyerCharge1 + PTBuyerCharge2 + PTBuyerCharge3 + UtilityBC1 + UtilityBC2 + UtilityBC3 + UtilityBC4 + UtilityBC5;
                Support.AreEqual("K. Due from Borrower at Closing", FastDriver.ClosingDisclosure.SectionKHeader_Label.Text.Trim());
                Support.AreEqual(Amount.ToString().FormatAsMoney(true), FastDriver.ClosingDisclosure.SectionKHeader_Amt.Text.Trim());
                
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_213050_TC_456957_NO_03()
        {

            try
            {
                Reports.TestDescription = "VERIFY K SECTION HEADER AMOUNT WHEN BUYER CHARGES ARE AVAILABLE IN K01 TO K03 AND AMOUNT IS PAID BY BUYER AT CLOSING.";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("500");
                FastDriver.TermsDatesStatus.PropertyValue.Click();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating  Charge in AdjustmentOffset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 500.00);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating  Charge in New Loan 1 screen ";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.NewLoanChargesTable, "Mortgage Insurance Premium", buyerCharge: 12345678910.10);
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$12,345,678,910.10", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section K";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("K. Due from Borrower at Closing", FastDriver.ClosingDisclosure.SectionKHeader_Label.Text.Trim());
                Support.AreEqual("$345,679,910.10", FastDriver.ClosingDisclosure.SectionKHeader_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_213050_TC_457054_NO_04()
        {
            try
            {
                Reports.TestDescription = "VERIFY K SECTION HEADER AMOUNT WHEN BUYER CHARGES ARE AVAILABLE IN SUPPLEMENTAL LINES K04A, K04B, K04C AND K04D.";
                Reports.TestStep = "Login in to IIS";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating  Charge in New Loan 1 screen ";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 250.00);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("125.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("125.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", buyerCharge: 500.00);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("250.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("250.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "New Loan1 Adhoc", buyerCharge: 12345678910.12, addNewRow: true);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$12,345,677,910.12");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", buyerCharge: 2000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1000.50");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1000.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", buyerCharge: 12345678910.12);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("12345677910.12");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1000.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Trim());
                Support.AreEqual("K. Due from Borrower at Closing", FastDriver.ClosingDisclosure.SectionKHeader_Label.Text.Trim());
                Support.AreEqual("$691,357,195.74", FastDriver.ClosingDisclosure.SectionKHeader_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_213050_TC_457242_NO_05()
        {
            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            #endregion

            try
            {
                Reports.TestDescription = "VERIFY K SECTION HEADER AMOUNT WHEN BUYER CHARGES ARE AVAILABLE IN K05, K06 AND IN SUPPLEMENTAL ADJUSTMENTS.";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                Reports.TestStep = "Creating  Charge in AdjustmentOffset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", buyerCharge: 100.00);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 200.50);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Offset Adhoc 1", buyerCharge: 12345678910.12, addNewRow: true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "NAVIGATE TO Miscellaneous SCREEN AND ENTER BUYER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 1", buyerCharge: 12345678910.12, addNewRow: true);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Miscellaneous Adhoc 2", buyerCharge: 0.75, addNewRow: true);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("K. Due from Borrower at Closing", FastDriver.ClosingDisclosure.SectionKHeader_Label.Text.Trim());
                Support.AreEqual("$345,679,211.37", FastDriver.ClosingDisclosure.SectionKHeader_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region 447617-CD SCREEN - SECTION K: SUPPLEMENTAL CHARGES FOR SECTION K
        [TestMethod]
        public void US_447617_TC_453091_NO_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN 1 SUPPLEMENTAL CHARGES IN SECTION K HAVING PAID BY BUYER BEFORE CLOSING AND AT CLOSING AMOUNTS.";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                Reports.TestStep = "Creating  Charge in New Loan 1 screen ";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 12345678910.10);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$12,345,678,910.10", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", buyerCharge: 250.50);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$250.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "New Loan1 Adhoc", buyerCharge: 0.75, newDescription: "New Loan1 Adhoc", addNewRow: true);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$0.75", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Trim());
                Support.AreEqual("$345,679,161.35", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Trim());
                Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$345,678,910.10", FastDriver.ClosingDisclosure.SectionK04a_Amt.Text.Trim());
                Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04SupL02_Seqno.Text.Trim());
                Support.AreEqual("Construction Holdback to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04SupL02_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$250.50", FastDriver.ClosingDisclosure.SectionK04SupL02_Amt.Text.Trim());
                Support.AreEqual("04c", FastDriver.ClosingDisclosure.SectionK04SupL03_Seqno.Text.Trim());
                Support.AreEqual("New Loan1 Adhoc to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04SupL03_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$0.75", FastDriver.ClosingDisclosure.SectionK04SupL03_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447617_TC_453711_NO_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN 1 SUPPLEMENTAL CHARGES IN SECTION K HAVING POC, POC-L AND POC-MB AMOUNTS.";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                Reports.TestStep = "Creating  Charge in New Loan 1 screen ";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 12345678910.10);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$12,345,678,910.10");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", buyerCharge: 250.50);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$250.50");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "New Loan1 Adhoc", buyerCharge: 0.75, newDescription: "New Loan1 Adhoc", addNewRow: true);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$0.75");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK04_Label.Text.Trim());
                Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment  to Midwest Financial Group $345,678,910.10 P.O.C.", FastDriver.ClosingDisclosure.SectionK04a_Label.Text.Trim());
                Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04SupL02_Seqno.Text.Trim());
                Support.AreEqual("Construction Holdback  to Midwest Financial Group $250.50 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionK04SupL02_Label.Text.Trim());
                Support.AreEqual("04c", FastDriver.ClosingDisclosure.SectionK04SupL03_Seqno.Text.Trim());
                Support.AreEqual("New Loan1 Adhoc  to Midwest Financial Group $0.75 P.O.C. MB", FastDriver.ClosingDisclosure.SectionK04SupL03_Label.Text.Trim());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447617_TC_453717_NO_03()
        {
            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            #endregion
            try
            {
                Reports.TestDescription = "VERIFY FEES SUPPLEMENTAL CHARGE IN SECTION K HAVING BUYER PAID BY OTHERS LENDER AMOUNT.";

                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");

                //

                Reports.TestStep = "Selecting Region to have Region-level access";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);

                //

                Reports.TestStep = "Creating Fees";
                FastDriver.LeftNavigation.Navigate<FeeSetup>("Home>System Maintenance>Fee Setup>Fee Summary").SwitchToContentFrame();
                FastDriver.FeeList2.WaitCreation(FastDriver.FeeList2.New, 30);
                FastDriver.FeeSetup.CreateFee("CDFee23", "Escrow Fee", false, false, "", "K", "K");
                FastDriver.WebDriver.Quit();

                //

                Reports.TestStep = "Logging in to FAST IIS";
                Login("Home");

                //

                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                //

                Reports.TestStep = "Creating  Charge in New Loan 1 screen ";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 12345678910.10);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 30);
                Support.AreEqual("$12,345,678,910.10", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Navigate to File Fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.FeeSearchFeeTypes, 30);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee23");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees, 30);
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.TableCharges.Enter(FastDriver.FileFees.TitleandescrowTable, "CDFee23", buyerCharge: 5000.00);
                FastDriver.FileFees.FeeDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 30);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-$2500.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$7,500.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,676,410.10", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Trim());
                Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.10", FastDriver.ClosingDisclosure.SectionK04a_Amt.Text.Trim());
                Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04SupL02_Seqno.Text.Trim());
                Support.AreEqual("CDFee23 to First American Title Company $7,500.00 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionK04SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04SupL02_Amt.Text.Trim());

                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447617_TC_453915_NO_04()
        {
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN 1 SUPPLEMENTAL CHARGES IN SECTION K HAVING POC, POC-L AND POC-MB AMOUNTS.";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                Reports.TestStep = "Creating  Charge in New Loan 1 screen ";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.SearchGAB("237");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 2000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$500.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.SearchGAB("247");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 12345678910.12);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$12,345,677,910.12");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Reconveyance Fee", buyerCharge: 250.50);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$250.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK04_Label.Text.Trim());
                Support.AreEqual("$750.50", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Trim());
                Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Trim());
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.SectionK04a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.SectionK04a_SubAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Associated Great Northern Mortgage Co. $1,000.00 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionK04SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.SectionK04SupL02_Amt.Text.Trim());
                Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04SupL03_Seqno.Text.Trim());
                Support.AreEqual("Payoff Loan 2 Charges", FastDriver.ClosingDisclosure.SectionK04SupL03_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$250.50", FastDriver.ClosingDisclosure.SectionK04SupL03_SubAmt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $345,678,910.12 P.O.C.", FastDriver.ClosingDisclosure.SectionK04SupL04_Label.GetAttribute("Title").ToString().Trim());
                Reports.StatusUpdate("Empty value is verified on CD Screen", true);
                Support.AreEqual("Reconveyance Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionK04SupL05_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$250.50", FastDriver.ClosingDisclosure.SectionK04SupL05_Amt.Text.Trim());

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447617_TC_456867_NO_06()
        {
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN 1 SUPPLEMENTAL CHARGES IN SECTION K HAVING POC, POC-L AND POC-MB AMOUNTS.";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 12345678910.10);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$12,345,678,910.10", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", buyerCharge: 2000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$2,000.50", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", buyerCharge: 12345678910.10);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$12,345,677,910.10");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 500.00);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$250.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$125.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$125.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK04_Label.Text.Trim());
                Support.AreEqual("$691,359,070.70", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Trim());
                Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.10", FastDriver.ClosingDisclosure.SectionK04a_Amt.Text.Trim());
                Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04SupL02_Seqno.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.SectionK04SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,680,160.60", FastDriver.ClosingDisclosure.SectionK04SupL02_SubAmt.Text.Trim());
                Support.AreEqual("Property Taxes 1", FastDriver.ClosingDisclosure.SectionK04SupL03_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("Tax Installment: Interest Due to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04SupL04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$2,000.50", FastDriver.ClosingDisclosure.SectionK04SupL04_Amt.Text.Trim());
                Support.AreEqual("Tax Installment: Amount to Midwest Financial Group $250.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04SupL05_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$250.00", FastDriver.ClosingDisclosure.SectionK04SupL05_Amt.Text.Trim());
                Support.AreEqual("County Tax to Midwest Financial Group $1,000.00 P.O.C. Buyer Broker", FastDriver.ClosingDisclosure.SectionK04SupL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,677,910.10", FastDriver.ClosingDisclosure.SectionK04SupL06_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447617_TC_456872_NO_07()
        {
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN 1 SUPPLEMENTAL CHARGES IN SECTION K HAVING POC, POC-L AND POC-MB AMOUNTS.";
                Reports.TestStep = "Login to file side";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 12345678910.10);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$12,345,678,910.10", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in HomeownerAssociation Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 1500.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$500.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$500.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$500.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "HOA Adhoc 1", buyerCharge: 750.00, addNewRow: true);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$250.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$250.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$250.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK04_Label.Text.Trim());
                Support.AreEqual("$345,679,660.10", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Trim());
                Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment  to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04a_Label.Text.Trim());
                Support.AreEqual("$345,678,910.10", FastDriver.ClosingDisclosure.SectionK04a_Amt.Text.Trim());
                Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04SupL02_Seqno.Text.Trim());
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.SectionK04_A.Text.Trim());
                Support.AreEqual("$750.00", FastDriver.ClosingDisclosure.SectionK04SupL02_SubAmt.Text.Trim());
                Support.AreEqual("Lien Payoff  to Midwest Financial Group $1,000.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04SupL03_Label.Text.Trim());
                Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.SectionK04SupL03_Amt.Text.Trim());
                Support.AreEqual("HOA Adhoc 1  to Midwest Financial Group $500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04SupL04_Label.Text.Trim());
                Support.AreEqual("$250.00", FastDriver.ClosingDisclosure.SectionK04SupL04_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_447617_TC_456879_NO_08()
        {
            Reports.TestDescription = "VERIFY THE DESCRIPTION AND LINE NUMBERS FOR ASSUMPTION LOAN CHARGES IN THE SUPPLEMENTAL PAGE.";
            Reports.TestStep = "Login to file side";
            Login("Home");
            
            Reports.TestStep = "Create a basic file with New Lender";
            CreateCDFile();
            
            Reports.TestStep = "Creating Charges in 1st New Loan Charges";
            FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
            FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
            FastDriver.NewLoan.LoanDetailsFind.FAClick();
            FastDriver.BottomFrame.Done();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
            FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
            FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 12345678910.10);
            FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
            Support.AreEqual("$12,345,678,910.10", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
            FastDriver.DialogBottomFrame.ClickDone();
            
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Creating Charges in AssumptionLoan Screen";
            FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
            FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
            FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
            FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 1000.00);
            FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
            FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$500.00");
            FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$500.00");
            FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
            FastDriver.DialogBottomFrame.ClickDone();
            
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 750.00);
            FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
            FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$250.00");
            FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$250.00");
            FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$250.00");
            FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            FastDriver.BottomFrame.Done();
            
            Reports.TestStep = "Validating the Charges in Section N";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

            Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Trim());
            Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK04_Label.Text.Trim());
            Support.AreEqual("$345,679,660.10", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Trim());
            Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Trim());
            Support.AreEqual("Principal Reduction Payment  to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04a_Label.Text.Trim());
            Support.AreEqual("$345,678,910.10", FastDriver.ClosingDisclosure.SectionK04a_Amt.Text.Trim());
            Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04SupL02_Seqno.Text.Trim());
            Support.AreEqual("Assumption Loan 1 Charges", FastDriver.ClosingDisclosure.SectionK04_A.Text.Trim());
            Support.AreEqual("$750.00", FastDriver.ClosingDisclosure.SectionK04SupL02_SubAmt.Text.Trim());
            Support.AreEqual("Statement/Forwarding Fee  to Lenders Advantage A Division Of First American Title Ins. $500.00 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionK04SupL03_Label.Text.Trim());
            Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.SectionK04SupL03_Amt.Text.Trim());
            Support.AreEqual("Document Fee  to Lenders Advantage A Division Of First American Title Ins. $500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04SupL04_Label.Text.Trim());
            Support.AreEqual("$250.00", FastDriver.ClosingDisclosure.SectionK04SupL04_Amt.Text.Trim());
            FastDriver.BottomFrame.Done();
        }

        [TestMethod]
        public void US_447617_TC_463451_NO_09()
        {
            try
            {
                Reports.TestDescription = "DELETE AND VERIFY THE DESCRIPTION AND LINE NUMBERS FOR BUYER CHARGE AMOUNTS IN THE SUPPLEMENTAL PAGE";
                Reports.TestStep = "Login to admin side";
                Login("FASTADM_URL");
                
                Reports.TestStep = "Selecting Region to have Region-level access";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);
                
                Reports.TestStep = "Creating Fees";
                FastDriver.LeftNavigation.Navigate<FeeSetup>("Home>System Maintenance>Fee Setup>Fee Summary").WaitForScreenToLoad();
                FastDriver.FeeSetup.CreateFee("CDFee10", "Escrow Fee", true, true, "", "K", "K");
                FastDriver.WebDriver.Quit();
                
                Reports.TestStep = "Login to IIS";
                Login("Home");
                
                Reports.TestStep = "Create a basic CD File";
                CreateCDFile();
                
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("248");
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 12345678910.10);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                Support.AreEqual("$12,345,678,910.10", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to File Fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(element: FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee10");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.FileFees.buyercharge.FASetText("5000");
                FastDriver.FileFees.FeeDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                string PayeeName = FastDriver.PaymentDetailsDlg.GfeThirdPartyNameDefault.FAGetValue();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-$2500.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$7,500.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("248");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 500.00);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$250.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$125.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$125.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in HomeownerAssociation Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", buyerCharge: 1500.00);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$500.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$500.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$500.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in AssumptionLoan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 1000.00);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$500.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$500.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.SearchGAB("237");
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 2000.00);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(element: FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK04_Label.Text.Trim());
                Support.AreEqual("$345,678,660.10", FastDriver.ClosingDisclosure.SectionK04_Amt.Text.Trim());
                Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment  to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04a_Label.Text.Trim());
                Support.AreEqual("$345,678,910.10", FastDriver.ClosingDisclosure.SectionK04a_Amt.Text.Trim());
                Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04SupL02_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Amount  to Midwest Financial Group $250.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04_A.Text.Trim());
                Support.AreEqual("$250.00", FastDriver.ClosingDisclosure.SectionK04SupL02_Amt.Text.Trim());
                Support.AreEqual("04c", FastDriver.ClosingDisclosure.SectionK04SupL03_Seqno.Text.Trim());
                Support.AreEqual("CDFee10  to First American Title Company $7,500.00 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionK04SupL03_Label.Text.Trim());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionK04SupL03_Amt.Text.Trim());
                Support.AreEqual("04d", FastDriver.ClosingDisclosure.SectionK04SupL04_Seqno.Text.Trim());
                Support.AreEqual("Payoff Loan 1 Charges", FastDriver.ClosingDisclosure.SectionK04SupL04_Label.Text.Trim());
                Support.AreEqual("$1,000.00", FastDriver.ClosingDisclosure.SectionK04SupL04_SubAmt.Text.Trim());
                Support.AreEqual("04e", FastDriver.ClosingDisclosure.SectionK04SupL06_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff  to Midwest Financial Group $1,000.00 P.O.C.", FastDriver.ClosingDisclosure.SectionK04SupL06_Label.Text.Trim());
                Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.SectionK04SupL06_Amt.Text.Trim());
                Support.AreEqual("04f", FastDriver.ClosingDisclosure.SectionK04SupL07_Seqno.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee  to Lenders Advantage A Division Of First American Title Ins. $500.00 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionK04SupL07_Label.Text.Trim());
                Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.SectionK04SupL07_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region USER STORY -347861 :ClosingDisclosure SCREEN : SECTION K.01: ENTER AMOUNT  IN  SALES PRICE  TEXBOX UNDER SECTION.
        [TestMethod]
        public void US_347861_ITE_16_TestCase_1()
        {
            try
            {
                Reports.TestDescription = " USER STORY -347861 : SECTION K: ENTER AMOUNT  IN  SALES PRICE  TEXBOX UNDER SECTION.";
                Login("Home");
                
                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();
                
                Reports.TestStep = "ENTER THE SALES PRICE AMOUNT IN TEXTBOX AND SAVE.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("1200.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                
                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                FastDriver.ClosingDisclosure.SectionK01_Label.Click();
                Support.AreEqual("Sale Price of Property", FastDriver.ClosingDisclosure.SectionK01_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$1,200.00", FastDriver.ClosingDisclosure.SectionK01_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "VERIFY THE AMOUNT AFTER SAVE AND SET MAX VALUE(11.2 DIGITS).";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("1,200.00", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue());
                Support.AreEqual("1,200.00", FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue());
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("12345678901.23");
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.Click();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Done();
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                Support.AreEqual("12,345,678,901.23", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue());
                Support.AreEqual("12,345,678,901.23", FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue());
                
                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                FastDriver.ClosingDisclosure.SectionK01_Label.Click();
                Support.AreEqual("Sale Price of Property", FastDriver.ClosingDisclosure.SectionK01_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionK01_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "SET ZERO VALUES AND VARIFY THE AMOUNT AFTER SAVE .";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("0");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                FastDriver.ClosingDisclosure.SectionK01_Label.Click();
                Support.AreEqual("Sale Price of Property", FastDriver.ClosingDisclosure.SectionK01_Label.GetAttribute("Title").Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                
                FailTest(ex.Message);
            }
            
        }
        #endregion

        #region USER STORY -357815 : ClosingDisclosure SCREEN - SECTION K: DISPLAY "SALE PRICE OF ANY PERSONAL PROPERTY INCLUDED IN SALE" ON LINE K.02.
        [TestMethod]
        public void US_357815_ITE_16_TestCase_3()
        {
            try
            {
                Reports.TestDescription = " USER STORY -357815 : SECTION K: DISPLAY SALE PRICE OF ANY PERSONAL PROPERTY INCLUDED IN SALE ON LINE K.02.";
                Login("Home");

                Reports.TestStep = "Create a basic file with New Lender";
                CreateCDFile();

                Reports.TestStep = "ENTER THE BUYER CHARGE AMOUNT IN OFFSET ADJUSTMENT SCREEN AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 0.2578);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                FastDriver.ClosingDisclosure.SectionK01_Label.Click();
                Support.AreEqual("Sale Price of Any Personal Property Included in Sale", FastDriver.ClosingDisclosure.SectionK02_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$0.25", FastDriver.ClosingDisclosure.SectionK02_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER THE BUYER CHARGE AMOUNT IN OFFSET ADJUSTMENT SCREEN AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("0.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                FastDriver.ClosingDisclosure.SectionK01_Label.Click();
                Support.AreEqual("Sale Price of Any Personal Property Included in Sale", FastDriver.ClosingDisclosure.SectionK02_Label.GetAttribute("Title").Clean());
                Reports.StatusUpdate("Empty value is verified on ClosingDisclosure Screen", true);
                //Reports.StatusUpdate("Empty value is verified on ClosingDisclosure Screen", FastDriver.ClosingDisclosure.SectionK02_Amt.Text.Clean(), true);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region US-393838-CD Screen Section K : Ability to Edit Charge Group Description
        [TestMethod]
        public void FTR5_ITR48_US_393838_TC_489781_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS EDITABLE : FOR THE SOURCE SCREEN ASSUMPTION LOAN1, ASSUMPTION LOAN2+";
                Reports.TestStep = "LOGIN TO FILE SIDE AND CREATE A BASIC FILE";
                Login("Home");
                CreateCDFile();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("344");
                FastDriver.BottomFrame.Done();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 600.00);
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Late Charge", buyerCharge: 1500.00);
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Balance of Impounds/Reserves Acct.", buyerCharge: 1500.00);
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("344");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 6000.00);
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 600.00);
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Late Charge", buyerCharge: 1500.00);
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Balance of Impounds/Reserves Acct.", buyerCharge: 1500.00);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();

                bool isContentEditable = FastDriver.ClosingDisclosure.SectionK04a_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK04SupL06_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());

                var element = FastDriver.ClosingDisclosure.SectionK.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Assumption Loan 1") && i.Displayed);

                element.Clear();
                element.FASetText("Assumption Loan Group Charges 1");
                Keyboard.SendKeys(FAKeys.TabAway);

                element = FastDriver.ClosingDisclosure.SectionK.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Assumption Loan 2") && i.Displayed);

                element.Clear();
                element.FASetText("Assumption Loan Group Charges 2");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();

                Support.AreEqual("Assumption Loan Group Charges 1", FastDriver.ClosingDisclosure.SectionK04a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("Assumption Loan Group Charges 2", FastDriver.ClosingDisclosure.SectionK04SupL06_Label.GetAttribute("Title").Clean());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR48_US_393838_TC_491163_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS EDITABLE : FOR THE SOURCE SCREEN FEES";
                Reports.TestStep = "Creating Fees";

                Login("FASTADM_URL");
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(FASTWCFHelpers.ClosingDisclosureSupport.IMDRegionBUID);
                FastDriver.LeftNavigation.Navigate<FeeSetup>("Home>System Maintenance>Fee Setup>Fee Summary").SwitchToContentFrame();
                FastDriver.FeeList2.WaitCreation(FastDriver.FeeList2.New, 30);
                FastDriver.FeeSetup.CreateFee("CDFee25", "Escrow Fee", true, true, "", "K", "L");
                FastDriver.FeeSetup.CreateFee("CDFee26", "Escrow Fee", true, true, "", "K", "L");
                FastDriver.WebDriver.Quit();

                //

                Reports.TestStep = "Login to IIS and create a basic file";
                Login("Home");
                CreateCDFile();

                //

                Reports.TestStep = "Navigate to File Fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.FeeSearchFeeTypes, 30);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee25");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.FeeSearchFeeTypes, 30);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("CDFee26");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees, 30);
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                FastDriver.FileFees.buyercharge.FASetText("5000.00");
                FastDriver.FileFees.buyercharge1.FASetText("5000.00");
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionK04_Seqno.Text.Clean());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").Clean());

                var element = FastDriver.ClosingDisclosure.SectionK.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Property Taxes") && i.Displayed);

                element.Clear();
                element.FASetText("Buyer Fees");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                FastDriver.ClosingDisclosure.K04Plus.FAClick();
                Support.AreEqual("Buyer Fees", FastDriver.ClosingDisclosure.k04PopupDesc.GetAttribute("Title").Clean());
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR48_US_393838_TC_491163_03()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS EDITABLE : FOR THE SOURCE SCREEN PROPERTY TAX CHECK";
                Reports.TestStep = "Login to FAST IIS and create basic file";
                Login("Home");
                CreateCDFile();

                //

                Reports.TestStep = "Adding Buyer charges in Property Tax Check Source Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("344");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", buyerCharge: 6000.00);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 600.00);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Penalty Due", buyerCharge: 1500.00);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Partial Payment Amt", buyerCharge: 1500.00);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "City Tax", buyerCharge: 1500.00);
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("344");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", buyerCharge: 6000.00);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 600.00);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Penalty Due", buyerCharge: 1500.00);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Partial Payment Amt", buyerCharge: 1500.00);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.AdditionalChargesTable, "City Tax", buyerCharge: 1500.00);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("344");
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", buyerCharge: 5000.00);
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 600.00);
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Late Charge", buyerCharge: 1500.00);
                FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Balance of Impounds/Reserves Acct.", buyerCharge: 1500.00);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Editing Charge Group description in Line K04";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();

                Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Clean());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.SectionK04a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04Sup12_Seqno.Text.Clean());
                Support.AreEqual("Assumption Loan 1 Charges", FastDriver.ClosingDisclosure.SectionK04SupL12_Label.GetAttribute("Title").Clean());

                bool isContentEditable = FastDriver.ClosingDisclosure.SectionK04a_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK04SupL12_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());


                var element = FastDriver.ClosingDisclosure.SectionK.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Property Taxes") && i.Displayed);

                element.Clear();
                element.FASetText("Group Description Suplemental Section 1");
                Keyboard.SendKeys(FAKeys.TabAway);

                element = FastDriver.ClosingDisclosure.SectionK.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Assumption Loan 1 Charges") && i.Displayed);
                element.Clear();
                element.FASetText("Group Description Suplemental Section 2");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Verifying the group description is successfully updated or not";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();

                Support.AreEqual("04a", FastDriver.ClosingDisclosure.SectionK04a_Seqno.Text.Clean());
                Support.AreEqual("Group Description Suplemental Section 1", FastDriver.ClosingDisclosure.SectionK04a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("04b", FastDriver.ClosingDisclosure.SectionK04Sup12_Seqno.Text.Clean());
                Support.AreEqual("Group Description Suplemental Section 2", FastDriver.ClosingDisclosure.SectionK04SupL12_Label.GetAttribute("Title").Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR48_US_393838_TC_489719_04()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR THE LINE K03";
                Reports.TestStep = "Login to FAST IIS and create basic file";
                Login("Home");
                CreateCDFile();

                //

                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.InterestCalculationTable, "Prepaid Interest", buyerCharge: 600.00);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: 1500.00);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Origination Fee", buyerCharge: 1500.00);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Underwriting Fee", buyerCharge: 6000.00);
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Verification Fee", buyerCharge: 6000.00);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Editing Charge Group description in Line K04";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionK03_Seqno.Text.Clean());
                Support.AreEqual("Closing Costs Paid at Closing (J)", FastDriver.ClosingDisclosure.SectionK03_Label.GetAttribute("Title").Clean());
                bool isContentEditable = FastDriver.ClosingDisclosure.SectionK03_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") == null;
                Support.AreEqual("True", isContentEditable.ToString());
                Reports.StatusUpdate("Section K01 Label cannot be edited", true);
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR48_US_393838_TC_487680_06()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR THE LINE K01";
                Reports.TestStep = "Login in to IIS side and creating a Basic file";

                Login("Home");
                CreateCDFile();

                //

                Reports.TestStep = "ENTER THE SALES PRICE AMOUNT IN TEXTBOX AND SAVE.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("5000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                //

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                FastDriver.ClosingDisclosure.SectionK01_Label.Click();
                Support.AreEqual("Sale Price of Property", FastDriver.ClosingDisclosure.SectionK01_Label.GetAttribute("Title").Clean());
                bool isContentEditable = FastDriver.ClosingDisclosure.SectionK01_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") == null;
                Support.AreEqual("True", isContentEditable.ToString());
                Reports.StatusUpdate("Section K01 Label cannot be edited", true);
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 357827 CD Screen - Section K: Closing Costs Paid at Closing (J) on line K03

        [TestMethod]
        public void FTR5_ITR41_US_357827_TC_459828_SC2()
        {
            #region - Data Setup
            var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
            fileRequest.File.Properties[0].PropertyAddress[0].City = "";
            fileRequest.File.Properties[0].PropertyAddress[0].County = "";
            fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
            fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

            List<double> amounts = new List<double>();
            Random random = new Random(Environment.TickCount);
            for (int i = 0; i < 9; i++)
            {
                string index = (i + 1).ToString();
                amounts.Add((double)random.Next(1000, 2000));
            }
            #endregion

            try
            {
                Reports.TestDescription = " Edit and Verify Closing Cost at Line K03";
                Reports.TestStep = "Create a file using quick file entry";

                Login("Home");
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                //

                Reports.TestStep = "Editing new loan value and verifying line k03";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", buyerCharge: amounts[0], sellerCharge: amounts[0]);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Other_Costs.FAClick();
                Support.AreEqual("Closing Costs Subtotals (D + I)", FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean());
                Support.AreEqual(amounts[0].ToString().FormatAsMoney(true), FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean());
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                Support.AreEqual("Closing Costs Paid at Closing (J)", FastDriver.ClosingDisclosure.SectionK03_Label.GetAttribute("Title").Clean());
                Support.AreEqual(amounts[0].ToString().FormatAsMoney(true), FastDriver.ClosingDisclosure.SectionK03_Amt.Text.Clean());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 213052 CD Screen - Borrower Calculation when K > L & K < L

        [TestMethod]
        public void FTR5_ITR34_US_213052_TC_431558_SC1()
        {
            #region - Data Setup
            var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
            fileRequest.File.Properties[0].PropertyAddress[0].City = "";
            fileRequest.File.Properties[0].PropertyAddress[0].County = "";
            fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
            fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

            List<double> amounts = new List<double>();
            Random random = new Random(Environment.TickCount);
            for (int i = 0; i < 4; i++)
            {
                if (i % 2 == 0)
                    amounts.Add((double)random.Next(2001, 3000));
                else
                    amounts.Add((double)random.Next(1001, 2000));
            }
            #endregion

            try
            {
                Reports.TestDescription = "calculate Borrower Calculation when K > L";
                Reports.TestStep = "Create a file using quick file entry";
                Login("Home");
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                //

                Reports.TestStep = "Creating data";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("344");
                FastDriver.UtilityDetail.ProrationBuyerCharge.FASetText(amounts[0].ToString());
                FastDriver.UtilityDetail.ProrationBuyerCredit.FASetText(amounts[1].ToString());
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Verifying Section K Total charges in Calculations Section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                Support.AreEqual(FastDriver.ClosingDisclosure.SectionKHeader_Amt.Text.Clean(), FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean());
                Support.AreEqual(FastDriver.ClosingDisclosure.SectionL_Amt.Text.Clean(), FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(3, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean().Replace("- ", ""));
                decimal TotalK = decimal.Parse(FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean().Replace("$", "").Replace(",", ""));
                decimal TotalL = decimal.Parse(FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(3, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean().Replace("- ", "").Replace("$", "").Replace(",", ""));
                decimal diff = TotalK > TotalL ? TotalK - TotalL : TotalL - TotalK;
                Support.AreEqual(diff.ToString().FormatAsMoney(true), FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(4, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean());

                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR34_US_213052_TC_431562_SC2()
        {
            #region - Data Setup
            var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
            fileRequest.File.Properties[0].PropertyAddress[0].City = "";
            fileRequest.File.Properties[0].PropertyAddress[0].County = "";
            fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
            fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

            List<double> amounts = new List<double>();
            Random random = new Random(Environment.TickCount);
            for (int i = 0; i < 4; i++)
            {
                if (i % 2 == 0)
                    amounts.Add((double)random.Next(1001, 2000));
                else
                    amounts.Add((double)random.Next(2001, 3000));
            }
            #endregion

            try
            {
                Reports.TestDescription = "calculate Borrower Calculation when K < L";
                Reports.TestStep = "Create a file using quick file entry";
                Login("Home");
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                //

                Reports.TestStep = "Creating data";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.FindGABcode("344");
                FastDriver.UtilityDetail.ProrationBuyerCharge.FASetText(amounts[0].ToString());
                FastDriver.UtilityDetail.ProrationBuyerCredit.FASetText(amounts[1].ToString());
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Verifying Section K Total charges in Calculations Section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                Support.AreEqual(FastDriver.ClosingDisclosure.SectionKHeader_Amt.Text.Clean(), FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean());
                Support.AreEqual(FastDriver.ClosingDisclosure.SectionL_Amt.Text.Clean(), FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(3, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean().Replace("- ", ""));
                decimal TotalK = decimal.Parse(FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(2, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean().Replace("$", "").Replace(",", ""));
                decimal TotalL = decimal.Parse(FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(3, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean().Replace("- ", "").Replace("$", "").Replace(",", ""));
                decimal diff = TotalK > TotalL ? TotalK - TotalL : TotalL - TotalK;
                Support.AreEqual(diff.ToString().FormatAsMoney(true), FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(4, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("div:nth-child(2)")).Text.Clean());

                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }
        #endregion

        #region USER STORY 393777 CD Screen – Section K: Provide ability to edit the Charge Description on lines K02 to K15
        [TestMethod]
        public void FTR5_ITR41_US_393777_TC_457906_SC1()
        {
            #region - Data Setup
            var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
            fileRequest.File.Properties[0].PropertyAddress[0].City = "";
            fileRequest.File.Properties[0].PropertyAddress[0].County = "";
            fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
            fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA");
            #endregion
            try
            {
                Reports.TestDescription = "USERSTORY 393777_TESTCASE_457906_SCENARIO1 - CD Section K: Verify the Charge Description in line K02 to K15 are editable when a charge setup is editable at ADM site.";
                Reports.TestStep = "Create a file using quick file entry";
                Login("Home");
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                //

                Reports.TestStep = "ENTER THE SALES PRICE AMOUNT IN TEXTBOX AND SAVE.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("25000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();

                //

                Reports.TestStep = "Navigate to Adjustment Offset Screen and set BuyerCharge";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", buyerCharge: 1.01);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", buyerCharge: 2.02);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", buyerCharge: 3.03);
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Adjustment Offset Adhoc 1", buyerCharge: 4.04, newDescription: "Adjustment Offset Adhoc 1", addNewRow: true);
                FastDriver.BottomFrame.Done();

                // 

                Reports.TestStep = "Navigate to Adjustment Offset Screen and set BuyerCharge";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.TableCharges.Enter(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Adjustment Misc Adhoc 1", buyerCharge: 4.04, newDescription: "Adjustment Misc Adhoc 1", addNewRow: true);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Navigate to New Loan and set BuyerCharge";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.Click();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", buyerCharge: 6.06);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Navigate to Property Tax Check, enter GAB and charges";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("188");
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", buyerCharge: 7.07);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Penalty Due", buyerCharge: 8.08);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Navigate to Proration Tax screen, and fill out charges info.";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "09/21/2012", "09/21/2013", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/22/2013", "10/24/2014", "600.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "11/23/2014", "11/23/2015", "800.00", true);
                FastDriver.BottomFrame.Done();

                //

                FastDriver.LeftNavigation.Navigate<ProrationMisc>("Home>Order Entry>Escrow Charge Processes>Proration");
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                FastDriver.WebDriver.FindElements(By.LinkText("Miscellaneous"))[1].FAClick();
                FastDriver.ProrationMisc.WaitForScreenToLoad();
                FastDriver.ProrationMisc.ProrationTaxTable1.FAClick();
                FastDriver.ProrationMisc.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.EnterProrationDetails("Assessments", null, "08/28/2014", "08/28/2015", "12600.00", true);
                FastDriver.BottomFrame.Done();

                //

                Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
                FastDriver.ClosingDisclosure.SectionK.Click();

                Support.AreEqual("Sale Price of Any Personal Property Included in Sale", FastDriver.ClosingDisclosure.SectionK02_Label.GetAttribute("Title").Clean());
                bool isContentEditable = FastDriver.ClosingDisclosure.SectionK02_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") == null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Closing Costs Paid at Closing (J)", FastDriver.ClosingDisclosure.SectionK03_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK03_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") == null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK04_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK04_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") == null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionK04a_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK04a_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.SectionK04SupL02_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK04SupL02_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Property Taxes 1", FastDriver.ClosingDisclosure.SectionK04SupL03_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK04SupL03_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") == null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Tax Installment: Amount to Mblo Funding, Inc.", FastDriver.ClosingDisclosure.SectionK04SupL04_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK04SupL04_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Tax Installment: Penalty Due to Mblo Funding, Inc.", FastDriver.ClosingDisclosure.SectionK04SupL05_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK04SupL05_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Adjustment Misc Adhoc 1", FastDriver.ClosingDisclosure.SectionK05_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK05_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Adjustment Offset Adhoc 1", FastDriver.ClosingDisclosure.SectionK06_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK06_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionK07_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK07_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") == null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Assign Tenant Lease/Rent", FastDriver.ClosingDisclosure.SectionK07a_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK07a_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());

                Support.AreEqual("Assign Tenant Security Deposit", FastDriver.ClosingDisclosure.SectionK07b_Label.GetAttribute("Title").Clean());
                isContentEditable = FastDriver.ClosingDisclosure.SectionK07b_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());

                var AdjustmentKItem = FastDriver.ClosingDisclosure.SectionK_AdjustmentforItemsSubTable.PerformTableAction(2, 2, TableAction.GetCell).Element.FindElement(By.TagName("span"));
                isContentEditable = AdjustmentKItem.GetAttribute("contenteditable") == null;
                Support.AreEqual("True", isContentEditable.ToString());

                AdjustmentKItem = FastDriver.ClosingDisclosure.SectionK_AdjustmentforItemsSubTable.PerformTableAction(3, 2, TableAction.GetCell).Element.FindElement(By.TagName("span"));
                Support.AreEqual("True", isContentEditable.ToString());

                AdjustmentKItem = FastDriver.ClosingDisclosure.SectionK_AdjustmentforItemsSubTable.PerformTableAction(4, 2, TableAction.GetCell).Element.FindElement(By.TagName("span"));
                Support.AreEqual("True", isContentEditable.ToString());

                AdjustmentKItem = FastDriver.ClosingDisclosure.SectionK_AdjustmentforItemsSubTable.PerformTableAction(5, 2, TableAction.GetCell).Element.FindElement(By.TagName("span"));
                isContentEditable = AdjustmentKItem.GetAttribute("contenteditable") != null;
                Support.AreEqual("True", isContentEditable.ToString());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR41_US_393777_TC_457915_SC8()
        {
            #region - Data Setup
            var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
            fileRequest.File.Properties[0].PropertyAddress[0].City = "";
            fileRequest.File.Properties[0].PropertyAddress[0].County = "";
            fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
            fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA");
            #endregion

            Reports.TestDescription = "393777_TESTCASE_457915_SCENARIO2 - CD Section K: Verify the system behavior when Charge Description is edited with a blank value.";
            Reports.TestStep = "Login to file side & create a file";

            Login("Home");
            FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

            //

            Reports.TestStep = "Setting Buyer Charge in Assumptions Loan 1 screen";
            FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
            FastDriver.AssumptionLoanDetails.FindGABCode("234");
            FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            FastDriver.TableCharges.Enter(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Document Fee", buyerCharge: 20.09);
            FastDriver.BottomFrame.Done();

            //

            Reports.TestStep = "Verifying new Sales Price in Closure Disclosure screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
            FastDriver.ClosingDisclosure.Summaries_of_Transactions.FAClick();
            FastDriver.ClosingDisclosure.SectionK.Click();
            var isContentEditable = FastDriver.ClosingDisclosure.SectionK04_Label.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;
            Support.AreEqual("True", isContentEditable.ToString());

            var element = FastDriver.ClosingDisclosure.SectionK.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Document Fee") && i.Displayed);

            element.Clear();
            element.SendKeys(FAKeys.Tab);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.BottomFrame.Done();
        }
        #endregion

        #region Recursive calls

        public static void CreateCDFile()
        {
            var customFile = RequestFactory.GetCreateFileDefaultRequest();
            customFile.formType = FASTWCFHelpers.FastFileService.FormType.CD;
            string fileNumber = FastDriver.FACreateFileFromWCF(customFile);
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }

        private void Login(string URL)
        {

            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            //FASTLogin.Login(Support.GetRunCategoryOption("WEBSITE", URL), credentials, true);
            FASTLogin.Login( URL == "Home" ? AutoConfig.FASTHomeURL : AutoConfig.FASTAdmURL, credentials, true);
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
