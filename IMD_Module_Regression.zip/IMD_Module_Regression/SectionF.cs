﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium;


namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class SectionF : MasterTestClass
    {
        public SectionF()
        {
        }

        [TestMethod]
        public void SectionF_Scenario1()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section F – without entering values in PDD.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"); // BusinessSourceGABcode IDCode = 415
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.FirstNewLoanAmount = (decimal)4500.50; //TermsDatesNewLoanAmnt
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("59.99");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("03-02-2015");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("03-15-2015" + FAKeys.Tab);
                Support.AreEqual("779.87", FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue());
                FastDriver.NewLoan.InterestCalculation_Loan_Estimates_Row1.FASetText("5008.67" + FAKeys.Tab);

                Reports.TestStep = @"Enter values under New Loan Charges – “Mortgage Insurance Premium”
                    i)	Enter Buyer Charge = 3456.67
                    ii)	Enter Seller Charge = 4354.32
                    iii)	Enter Loan Estimate = 53434.56";
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.SetText, "3456.67");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 5, TableAction.SetText, "4354.32");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 7, TableAction.SetText, "53434.56");
                
                Reports.TestStep = @"Navigate to Insurance | Fire Insurance and enter values under Insurance Charges.
                    i)	Enter Insurance Agent GAB Code. (E.g. WF)
                    ii)	Enter Hazard Insurance Agent GAB Code. (E.g. BOA)
                    iii)	Enter Buyer Charge = 34534.64
                    iv)	Enter Seller Charge = 3423423.34
                    v)	Enter Loan Estimate = 2342343.43";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.FireGABcode.FASetText("WF");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("BOA");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("34534.64");
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("3423423.34");
                FastDriver.InsuranceFire.FireGFE11.FASetText("2342343.43");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"f)	Select Flood Insurance and enter values under Insurance Charges:
                    i)	 Enter Insurance Agent GAB Code. (E.g. 214)
                    ii)	Enter Hazard Insurance Agent GAB Code. (E.g. 415)
                    iii)	Enter Buyer Charge = 34234.34
                    iv)	Enter Seller Charge = 23423.23
                    v)	Enter Loan Estimate = 34343.32";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.FloodGABcode.FASetText("214");
                FastDriver.Insuranceflood.FloodFind.FAClick();
                FastDriver.Insuranceflood.FloodGABcodeunderwriter.FASetText("415");
                FastDriver.Insuranceflood.FloodFindunderwriter.FAClick();
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("34234.34");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("23423.23");
                FastDriver.Insuranceflood.FloodGFE11.FASetText("34343.32");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Wind Insurance and enter values under Insurance Charges:
                i)	 Enter Insurance Agent GAB Code. (E.g. 314)
                ii)	Enter Buyer Charge = 674564.45
                iii)	Enter Loan Estimate = 34345645.45";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WindGABcode.FASetText("314");
                FastDriver.InsuranceWind.WindFind.FAClick();
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText("674564.45");
                FastDriver.InsuranceWind.WindGFE11.FASetText("34345645.45");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Earthquake Insurance and enter values under Insurance Charges:
                    i)	Enter Hazard Insurance Agent GAB Code. (E.g. 214)
                    ii)	Enter Seller Charge = 234233.45";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.EarthGABcodeunderwriter.FASetText("214");
                FastDriver.InsuranceEarth.EarthFindunderwriter.FAClick();
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText("234233.45");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Other Insurance and enter values under Insurance Charges:
                    i)	Enter Hazard Insurance Agent GAB Code. (E.g. WF)
                    ii)	Enter Buyer Charge = 234234.23
                    iii)	Enter Seller Charge = 23423";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.OtherGABcodeUnderwriter.FASetText("WF");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherBuyerCharge.FASetText("234234.23");
                FastDriver.InsuranceOther.OtherSellerCharge.FASetText("23423.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to Property Taxes and enter values for Property Taxes.
                    i)	Add GAB information. (E.g. 312)
                    ii)	Enter Buyer Charge = 3423423.34
                    iii)	Enter Seller Charge = 2342342
                    iv)	Enter Loan Estimate = 352423.45";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("312");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("3423423.34");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("2342342.00");
                FastDriver.PropertyTaxCheck.PropertyTaxesLoanEstimate_1.FASetText("352423.45");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to CD Screen. Expand Other Cost and verify value in Section F.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                //FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader.FAClick();

                Support.AreEqual("01.  Homeowner's Insurance Premium ( Mos.) to Bank of America", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,534.64", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,423,423.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,343.43", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,343.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 8, TableAction.GetText).Message.Trim());

                Support.AreEqual("02.  Mortgage Insurance Premium ( Mos.) to Continental Mortgage", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,456.67", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,354.32", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$53,434.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 8, TableAction.GetText).Message.Trim());

                Support.AreEqual("03.  Prepaid Interest ( $59.99 per day from 3/2/15 to 3/15/15 ) to Continental", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$779.87", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,008.67", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,009.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 8, TableAction.GetText).Message.Trim());

                Support.AreEqual("04.  Property Taxes ( Mos.) to First Midwest", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,423,423.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,342.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$352,423.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$352,423.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 8, TableAction.GetText).Message.Trim());

                Support.AreEqual("05.  Earthquake Insurance Premium ( Mos.) to Pnc Mortgage Corp. Of America", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Earthquake Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,233.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Earthquake Insurance Premium", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("06.  Flood Insurance Premium ( Mos.) to Continental Mortgage", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Flood Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Flood Insurance Premium", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$23,423.23", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Flood Insurance Premium", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,343.32", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Flood Insurance Premium", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,343.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Flood Insurance Premium", 8, TableAction.GetText).Message.Trim());

                Support.AreEqual("07.  Insurance Premium ( Mos.) to Wells Fargo Bank", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,234.23", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$23,423.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("08.  Wind Insurance Premium ( Mos.) to Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$674,564.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,345,645.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,345,645.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 8, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionF_Scenario2()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section F – modifying values in CD and Source Screen.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"); // BusinessSourceGABcode IDCode = 415
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.FirstNewLoanAmount = (decimal)4500.50; //TermsDatesNewLoanAmnt
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("59.99");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("03-02-2015");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("03-15-2015" + FAKeys.Tab);
                Support.AreEqual("779.87", FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue());
                FastDriver.NewLoan.InterestCalculation_Loan_Estimates_Row1.FASetText("5008.67" + FAKeys.Tab);

                Reports.TestStep = @"Enter values under New Loan Charges – “Mortgage Insurance Premium”
                    i)	Enter Buyer Charge = 3456.67
                    ii)	Enter Seller Charge = 4354.32
                    iii)	Enter Loan Estimate = 53434.56";
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.SetText, "3456.67");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 5, TableAction.SetText, "4354.32");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 7, TableAction.SetText, "53434.56");

                Reports.TestStep = @"Navigate to Insurance | Fire Insurance and enter values under Insurance Charges.
                    i)	Enter Insurance Agent GAB Code. (E.g. WF)
                    ii)	Enter Hazard Insurance Agent GAB Code. (E.g. BOA)
                    iii)	Enter Buyer Charge = 34534.64
                    iv)	Enter Seller Charge = 3423423.34
                    v)	Enter Loan Estimate = 2342343.43";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.FireGABcode.FASetText("WF");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("BOA");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("34534.64");
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("3423423.34");
                FastDriver.InsuranceFire.FireGFE11.FASetText("2342343.43");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"f)	Select Flood Insurance and enter values under Insurance Charges:
                    i)	 Enter Insurance Agent GAB Code. (E.g. 214)
                    ii)	Enter Hazard Insurance Agent GAB Code. (E.g. 415)
                    iii)	Enter Buyer Charge = 34234.34
                    iv)	Enter Seller Charge = 23423.23
                    v)	Enter Loan Estimate = 34343.32";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.FloodGABcode.FASetText("214");
                FastDriver.Insuranceflood.FloodFind.FAClick();
                FastDriver.Insuranceflood.FloodGABcodeunderwriter.FASetText("415");
                FastDriver.Insuranceflood.FloodFindunderwriter.FAClick();
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("34234.34");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("23423.23");
                FastDriver.Insuranceflood.FloodGFE11.FASetText("34343.32");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Wind Insurance and enter values under Insurance Charges:
                i)	 Enter Insurance Agent GAB Code. (E.g. 314)
                ii)	Enter Buyer Charge = 674564.45
                iii)	Enter Loan Estimate = 34345645.45";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WindGABcode.FASetText("314");
                FastDriver.InsuranceWind.WindFind.FAClick();
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText("674564.45");
                FastDriver.InsuranceWind.WindGFE11.FASetText("34345645.45");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Earthquake Insurance and enter values under Insurance Charges:
                    i)	Enter Hazard Insurance Agent GAB Code. (E.g. 214)
                    ii)	Enter Seller Charge = 234233.45";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.EarthGABcodeunderwriter.FASetText("214");
                FastDriver.InsuranceEarth.EarthFindunderwriter.FAClick();
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText("234233.45");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Other Insurance and enter values under Insurance Charges:
                    i)	Enter Hazard Insurance Agent GAB Code. (E.g. WF)
                    ii)	Enter Buyer Charge = 234234.23
                    iii)	Enter Seller Charge = 23423";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.OtherGABcodeUnderwriter.FASetText("WF");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherBuyerCharge.FASetText("234234.23");
                FastDriver.InsuranceOther.OtherSellerCharge.FASetText("23423.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to Property Taxes and enter values for Property Taxes.
                    i)	Add GAB information. (E.g. 312)
                    ii)	Enter Buyer Charge = 3423423.34
                    iii)	Enter Seller Charge = 2342342
                    iv)	Enter Loan Estimate = 352423.45";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("312");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("3423423.34");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("2342342.00");
                FastDriver.PropertyTaxCheck.PropertyTaxesLoanEstimate_1.FASetText("352423.45");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to CD Screen. Expand Other Cost and verify value in Section F.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = @"Select CD Screen and modify values as below:
                                    i)	Homeowner’s Insurance Premium:
                                    (1)	Loan Estimate Unrounded: 76879.56";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 7, TableAction.SetText, "76879.56" + FAKeys.Tab);

                Reports.TestStep = @"ii)	Mortgage Insurance Premium:
                                    (1)	Loan Estimate Rounded: 234323.55";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 8, TableAction.SetText, "234323.55" + FAKeys.Tab);

                Reports.TestStep = @"iii)	Prepaid Interest:
                (1)	Click on + icon and Select Mortgage Broker.
                (a)	System should display Mortgage Broker.
                (2)	Modify Loan Estimate unrounded amount: 464532.45";
                FastDriver.ClosingDisclosure.F03PlusIcon.FAClick();
                FastDriver.ClosingDisclosure.RbNewMortgageBroker.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.PrepaidInterestDone.FAClick();
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 7, TableAction.SetText, "464532.45" + FAKeys.Tab);

                Reports.TestStep = @"iv) Property Taxes: (1)	Modify Loan Estimate Rounded: 67534";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 8, TableAction.SetText, "67534" + FAKeys.Tab);

                Reports.TestStep = @"v)	Earthquake Insurance: (1)	Remove charge description and verify error message.";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Earthquake Insurance Premium", 1, TableAction.SetText, "" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"v)	Earthquake Insurance:
                                    (2)	Enter Unrounded Amount. (E.g. 35634.56)";
                // Reload CD screen since the table get redrawed
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Earthquake Insurance Premium", 7, TableAction.SetText, "35634.56" + FAKeys.Tab);

                Reports.TestStep = @"vi)	Flood Insurance:
                                    (1)	Modify Charge Description. (E.g. Updated Flood Insurance)";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Flood Insurance Premium", 1, TableAction.SetText, "Updated Flood Insurance" + FAKeys.Tab);

                Support.AreEqual("01.  Homeowner's Insurance Premium ( Mos.) to Bank of America", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("02.  Mortgage Insurance Premium ( Mos.) to Continental Mortgage", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("03.  Prepaid Interest ( $59.99 per day from 3/2/15 to 3/15/15 )", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("04.  Property Taxes ( Mos.) to First Midwest", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("05.  Earthquake Insurance Premium ( Mos.) to Pnc Mortgage Corp. Of America", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Earthquake Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("06.  Insurance Premium ( Mos.) to Wells Fargo Bank", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("07.  Updated Flood Insurance ( Mos.) to Continental Mortgage", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Updated Flood Insurance", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("08.  Wind Insurance Premium ( Mos.) to Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 1, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Navigate to New Loan Screen and verify values for Prepaid Interest and Mortgage Insurance.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = @"Prepaid Interest
                (1)	Loan Estimate unrounded amount should be updated: 464532.45";
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$464,532.45" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$464,532.00" + FAKeys.Tab);

                Reports.TestStep = @"Prepaid Interest
                (2)	Open PDD and update values as below:
                (a)	Enter No. Months Prepaid. (E.g. 786)
                (b)	Buyer At Closing = 3433.23
                (c)	Buyer Before Closing = 3431.32
                (d)	Paid by Others = 9898.45 (POC)
                (e)	Loan Estimate Rounded amount = 88979.87
                (i)	Broken icon should be displayed.
                (f)	Uncheck “Use Default” and modify the Payee Name. (Modified Payee Name)
                (g)	Check Double Asterisk checkbox.
                (h)	Update Additional Description. (E.g. Update values)";
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("Update values");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("786");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("3433.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("3431.32");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("9898.45");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("88979.87" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Modified Payee Name"  + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = @"Update Per Diem Amount. (E.g. 87)
                                    (a)	System should display “Interest calculation formula values have changed. 
                                        Do you wish to recalculate interest charges?” Ok/Cancel. Click on Ok button.
                                    (b)	System should display “Charge has Multiple Paid By Methods.” Click on OK button.";
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("87" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"Mortgage Insurance | Modify Buyer Charge (E.g. 86745.56) and Seller Charge (E.g. 56853).";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.SetText, "86745.56" + FAKeys.Tab); //Buyer Charge
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 5, TableAction.SetText, "56853" + FAKeys.Tab); //Seller Charge

                Reports.TestStep = @"Select Mortgage Insurance screen and change the GAB Code (E.g. 312).";
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("312");
                FastDriver.NewLoan.MortgageFind.FAClick();

                Reports.TestStep = @"d)	Navigate to Insurance and verify values for Fire Insurance, 
                                        Earthquake Insurance and Flood Insurance.
                                        Fire Insurance:
                                        (1)	Fire Insurance Unrounded amount should be updated under Insurance Charges. (E.g. 76879.56)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.FirePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                Support.AreEqual("$76,879.56", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$76,880.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Select Insurance Agent radio button under contact details.";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.SwitchToContentFrame();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);

                Reports.TestStep = @"Modify Buyer Charge (E.g. 45645.7) and Seller Charge (E.g. 465685.56).";

                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("45645.7" + FAKeys.Tab);
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("465685.56" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Flood Insurance - Verify if Charge description is updated under Insurance Charges.";
                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Support.AreEqual("Updated Flood Insurance", FastDriver.Insuranceflood.FloodDescriptionInsuranceCharge.FAGetValue().Trim());

                Reports.TestStep = @"Flood Insurance -Modify Buyer Charge (E.g. 56345.45), Seller Charge (E.g. 45645.56) and Loan Estimate Unrounded amount (E.g. 557343.56).";
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("56345.45");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("45645.56");
                FastDriver.Insuranceflood.FloodGFE11.FASetText("557343.56");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Verify if charge description is not modified for Earthquake insurance.";
                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Support.AreEqual("Earthquake Insurance Premium", FastDriver.InsuranceEarth.EarthInsuranceChargeDescription.FAGetValue().Trim());

                Reports.TestStep = @"Remove Buyer Charge, Seller Charge.";
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText(" " + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"e)	Navigate to Property Tax Check.
                    i)	Open PDD and verify if Loan Estimate rounded amount is updated and broken link is displayed.
                    ii)	Update Addition Description. (E.g. City Taxes)
                    iii)	Uncheck Use Default and update payee name. (E.g. Modified Wells Fargo Payee Name)
                    iv)	Update Months for Property Taxes in No. Months Prepaid. (E.g. 456)
                    v)	Check Double asterisk indicator.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("City Taxes");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("456");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$67,534.00");
                Support.AreEqual("true", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString(), true);
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Modified Wells Fargo Payee Name");
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                
                Reports.TestStep = @"Add new instance of Property Tax and Add GAB code (E.g. WF).
                                    (1)	Update Buyer Charge. (E.g. 89798.98)";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("WF");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("89798.98" + FAKeys.Tab);

                Reports.TestStep = @"Navigate to CD Screen. Expand Other Cost and verify values in Section F.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("01.  Homeowner's Insurance Premium ( Mos.) to Wells Fargo Bank", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$45,645.70", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$465,685.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$76,879.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$76,880.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 8, TableAction.GetText).Message.Trim());

                Support.AreEqual("02.  Mortgage Insurance Premium ( Mos.) to Continental Mortgage", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$86,745.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$56,853.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$53,434.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,324.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 8, TableAction.GetText).Message.Trim());
                bool isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 8, TableAction.GetCell).Element);
                Support.AreEqual("True", isDisplayed.ToString(), true);

                Support.AreEqual("03.  ** Prepaid Interest ( $87.00 per day from 3/2/15 to 3/15/15 ) to First", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$1,131.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$464,532.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$88,980.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 8, TableAction.GetText).Message.Trim());
                isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 8, TableAction.GetCell).Element);
                Support.AreEqual("True", isDisplayed.ToString(), true);

                Support.AreEqual("04.  ** Property Taxes City Taxes ( 456 Mos.) to Modified Wells Fargo Payee", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes City Taxes", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,423,423.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes City Taxes", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,342.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes City Taxes", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$352,423.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes City Taxes", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$67,534.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes City Taxes", 8, TableAction.GetText).Message.Trim());
                isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes City Taxes", 8, TableAction.GetCell).Element);
                Support.AreEqual("True", isDisplayed.ToString(), true);

                Support.AreEqual("05.  Insurance Premium ( Mos.) to Wells Fargo Bank", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,234.23", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$23,423.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("08.  Wind Insurance Premium ( Mos.) to Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$674,564.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,345,645.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,345,645.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 8, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionF_Scenario3()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section F – modifying values in PDD.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"); // BusinessSourceGABcode IDCode = 415
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.FirstNewLoanAmount = (decimal)4500.50; //TermsDatesNewLoanAmnt
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region setup data
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("59.99");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("03-02-2015");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("03-15-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculation_Loan_Estimates_Row1.FASetText("5008.67" + FAKeys.Tab);

                Reports.TestStep = @"Enter values under New Loan Charges – “Mortgage Insurance Premium”
                    i)	Enter Buyer Charge = 3456.67
                    ii)	Enter Seller Charge = 4354.32
                    iii)	Enter Loan Estimate = 53434.56";
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.SetText, "3456.67");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 5, TableAction.SetText, "4354.32");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 7, TableAction.SetText, "53434.56");

                Reports.TestStep = @"Navigate to Insurance | Fire Insurance and enter values under Insurance Charges.
                    i)	Enter Insurance Agent GAB Code. (E.g. WF)
                    ii)	Enter Hazard Insurance Agent GAB Code. (E.g. BOA)
                    iii)	Enter Buyer Charge = 34534.64
                    iv)	Enter Seller Charge = 3423423.34
                    v)	Enter Loan Estimate = 2342343.43";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.FireGABcode.FASetText("WF");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("BOA");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("34534.64");
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("3423423.34");
                FastDriver.InsuranceFire.FireGFE11.FASetText("2342343.43");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"f)	Select Flood Insurance and enter values under Insurance Charges:
                    i)	 Enter Insurance Agent GAB Code. (E.g. 214)
                    ii)	Enter Hazard Insurance Agent GAB Code. (E.g. 415)
                    iii)	Enter Buyer Charge = 34234.34
                    iv)	Enter Seller Charge = 23423.23
                    v)	Enter Loan Estimate = 34343.32";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.FloodGABcode.FASetText("214");
                FastDriver.Insuranceflood.FloodFind.FAClick();
                FastDriver.Insuranceflood.FloodGABcodeunderwriter.FASetText("415");
                FastDriver.Insuranceflood.FloodFindunderwriter.FAClick();
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("34234.34");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("23423.23");
                FastDriver.Insuranceflood.FloodGFE11.FASetText("34343.32");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Wind Insurance and enter values under Insurance Charges:
                i)	 Enter Insurance Agent GAB Code. (E.g. 314)
                ii)	Enter Buyer Charge = 674564.45
                iii)	Enter Loan Estimate = 34345645.45";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WindGABcode.FASetText("314");
                FastDriver.InsuranceWind.WindFind.FAClick();
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText("674564.45");
                FastDriver.InsuranceWind.WindGFE11.FASetText("34345645.45");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Earthquake Insurance and enter values under Insurance Charges:
                    i)	Enter Hazard Insurance Agent GAB Code. (E.g. 214)
                    ii)	Enter Seller Charge = 234233.45";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.EarthGABcodeunderwriter.FASetText("214");
                FastDriver.InsuranceEarth.EarthFindunderwriter.FAClick();
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText("234233.45");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Other Insurance and enter values under Insurance Charges:
                    i)	Enter Hazard Insurance Agent GAB Code. (E.g. WF)
                    ii)	Enter Buyer Charge = 234234.23
                    iii)	Enter Seller Charge = 23423";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.OtherGABcodeUnderwriter.FASetText("WF");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherBuyerCharge.FASetText("234234.23");
                FastDriver.InsuranceOther.OtherSellerCharge.FASetText("23423.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to Property Taxes and enter values for Property Taxes.
                    i)	Add GAB information. (E.g. 312)
                    ii)	Enter Buyer Charge = 3423423.34
                    iii)	Enter Seller Charge = 2342342
                    iv)	Enter Loan Estimate = 352423.45";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("312");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("3423423.34");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("2342342.00");
                FastDriver.PropertyTaxCheck.PropertyTaxesLoanEstimate_1.FASetText("352423.45");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to CD Screen. Expand Other Cost and verify value in Section F.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = @"Select CD Screen and modify values as below:
                                    i)	Homeowner’s Insurance Premium:
                                    (1)	Loan Estimate Unrounded: 76879.56";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium", 7, TableAction.SetText, "76879.56" + FAKeys.Tab);

                Reports.TestStep = @"ii)	Mortgage Insurance Premium:
                                    (1)	Loan Estimate Rounded: 234323.55";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 8, TableAction.SetText, "234323.55" + FAKeys.Tab);

                Reports.TestStep = @"iii)	Prepaid Interest:
                (1)	Click on + icon and Select Mortgage Broker.
                (a)	System should display Mortgage Broker.
                (2)	Modify Loan Estimate unrounded amount: 464532.45";
                FastDriver.ClosingDisclosure.F03PlusIcon.FAClick();
                FastDriver.ClosingDisclosure.RbNewMortgageBroker.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.PrepaidInterestDone.FAClick();
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 7, TableAction.SetText, "464532.45" + FAKeys.Tab);

                Reports.TestStep = @"iv) Property Taxes: (1)	Modify Loan Estimate Rounded: 67534";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 8, TableAction.SetText, "67534" + FAKeys.Tab);

                Reports.TestStep = @"v)	Earthquake Insurance: (1)	Remove charge description and verify error message.";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Earthquake Insurance Premium", 1, TableAction.SetText, "" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"v)	Earthquake Insurance:
                                    (2)	Enter Unrounded Amount. (E.g. 35634.56)";
                // Reload CD screen since the table get redrawed
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Earthquake Insurance Premium", 7, TableAction.SetText, "35634.56" + FAKeys.Tab);

                Reports.TestStep = @"vi)	Flood Insurance:
                                    (1)	Modify Charge Description. (E.g. Updated Flood Insurance)";
                FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Flood Insurance Premium", 1, TableAction.SetText, "Updated Flood Insurance" + FAKeys.Tab);

                Reports.TestStep = @"Navigate to New Loan Screen and verify values for Prepaid Interest and Mortgage Insurance.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = @"Prepaid Interest
                (1)	Loan Estimate unrounded amount should be updated: 464532.45";
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$464,532.45" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$464,532.00" + FAKeys.Tab);

                Reports.TestStep = @"Prepaid Interest
                (2)	Open PDD and update values as below:
                (a)	Enter No. Months Prepaid. (E.g. 786)
                (b)	Buyer At Closing = 3433.23
                (c)	Buyer Before Closing = 3431.32
                (d)	Paid by Others = 9898.45 (POC)
                (e)	Loan Estimate Rounded amount = 88979.87
                (i)	Broken icon should be displayed.
                (f)	Uncheck “Use Default” and modify the Payee Name. (Modified Payee Name)
                (g)	Check Double Asterisk checkbox.
                (h)	Update Additional Description. (E.g. Update values)";
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("Update values");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("786");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("3433.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("3431.32");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("9898.45");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("88979.87" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Modified Payee Name" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);

                Reports.TestStep = @"Update Per Diem Amount. (E.g. 87)
                                    (a)	System should display “Interest calculation formula values have changed. 
                                        Do you wish to recalculate interest charges?” Ok/Cancel. Click on Ok button.
                                    (b)	System should display “Charge has Multiple Paid By Methods.” Click on OK button.";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("87.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                Reports.TestStep = @"Mortgage Insurance | Modify Buyer Charge (E.g. 86745.56) and Seller Charge (E.g. 56853).";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.SetText, "86745.56"); //Buyer Charge
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 5, TableAction.SetText, "56853.00"); //Seller Charge

                Reports.TestStep = @"Select Mortgage Insurance screen and change the GAB Code (E.g. 312).";
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("312");
                FastDriver.NewLoan.MortgageFind.FAClick();

                Reports.TestStep = @"d)	Navigate to Insurance and verify values for Fire Insurance, 
                                        Earthquake Insurance and Flood Insurance.
                                        Fire Insurance:
                                        (1)	Fire Insurance Unrounded amount should be updated under Insurance Charges. (E.g. 76879.56)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.FirePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$76,879.56");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$76,880.00");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Select Insurance Agent radio button under contact details.";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.SwitchToContentFrame();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);

                Reports.TestStep = @"Modify Buyer Charge (E.g. 45645.7) and Seller Charge (E.g. 465685.56).";
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("45645.7" + FAKeys.Tab);
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("465685.56" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Flood Insurance - Verify if Charge description is updated under Insurance Charges.";
                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = @"Flood Insurance -Modify Buyer Charge (E.g. 56345.45), Seller Charge (E.g. 45645.56) and Loan Estimate Unrounded amount (E.g. 557343.56).";
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("56345.45");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("45645.56");
                FastDriver.Insuranceflood.FloodGFE11.FASetText("557343.56");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Verify if charge description is not modified for Earthquake insurance.";
                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();

                Reports.TestStep = @"Remove Buyer Charge, Seller Charge.";
                FastDriver.InsuranceEarth.EarthSellerCharge.FASetText(" " + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"e)	Navigate to Property Tax Check.
                    i)	Open PDD and verify if Loan Estimate rounded amount is updated and broken link is displayed.
                    ii)	Update Addition Description. (E.g. City Taxes)
                    iii)	Uncheck Use Default and update payee name. (E.g. Modified Wells Fargo Payee Name)
                    iv)	Update Months for Property Taxes in No. Months Prepaid. (E.g. 456)
                    v)	Check Double asterisk indicator.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("City Taxes");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("456");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$67,534.00");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Modified Wells Fargo Payee Name");
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Add new instance of Property Tax and Add GAB code (E.g. WF).
                                    (1)	Update Buyer Charge. (E.g. 89798.98)";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("WF");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("89798.98" + FAKeys.Tab);
                #endregion

                Reports.TestStep = @"Navigate to CD Screen. Expand Other Cost and verify values in Section F.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = @"Click on + icon in F03 and select New Loan Lender.
                    i)	System should display modified payee name.
                    ii)	Save the same. Reload CD screen and verify the value displayed in F.03
                    (1)	System should display modified payee name.";
                FastDriver.ClosingDisclosure.F03PlusIcon.FAClick();
                FastDriver.ClosingDisclosure.RbNewLoanLender.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.PrepaidInterestDone.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                Support.AreEqual("03. ** Prepaid Interest ( $87.00 per day from 3/2/15 to 3/15/15 ) to Modified", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Clean());

                FastDriver.ClosingDisclosure.F03PlusIcon.FAClick();
                FastDriver.ClosingDisclosure.RbNone.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.PrepaidInterestDone.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                Support.AreEqual("03. ** Prepaid Interest ( $87.00 per day from 3/2/15 to 3/15/15 )", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Clean());

                FastDriver.ClosingDisclosure.F03PlusIcon.FAClick();
                FastDriver.ClosingDisclosure.RbNewMortgageBroker.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.PrepaidInterestDone.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                Support.AreEqual("03. ** Prepaid Interest ( $87.00 per day from 3/2/15 to 3/15/15 ) to First", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Clean());

                Reports.TestStep = @"Navigate to New Loan | Loan Charges.
                    Prepaid Interest
                    (1)	Loan Estimate unrounded amount should be updated: 464532.45";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = @"(2)	Modify Per Diem Amount. (E.g. 67.4)
                (a)	System should display below displayed pop up message:";
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("67.4");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();

                Reports.TestStep = @"Open PDD and update values as below:
                                    (a)	Buyer Credit: 34534.56
                                    (i)	System should display warning message.
                On Click of “OK” system should remove Buyer Charge (All values). On Click of “Cancel” system should remove Buyer Credit.
                (b)	Remove Double Asterisk checkbox.
                (c)	Remove additional description.
                (d)	Check “Use Default” checkbox.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("34534.56" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();
                /*Defect Raised as part if IMD*/
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"Mortgage Insurance Premium
                                    (1)	Open PDD and update values as below:
                                    (a)	Buyer At Closing = 3000.5
                                    (b)	Buyer Before Closing = 3500.49
                                    (c)	Paid by Others = 1500.45 (POC)
                                    (d)	Seller At Closing = 2324.34
                                    (e)	Seller Before Closing = 3546.56
                                    (f)	Paid by Others = 342132322.34(POC)
                                    (g)	Update Loan Estimate unrounded = 9847698983.45
                                    (h)	Uncheck “Use Default” and modify payee name to “Wells Fargo Modified”
                                    (i)	No. Months Prepaid=100";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.Click);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("9847698983.45" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Wells Fargo Modified" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("100" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("3000.5" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("3500.49" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("1500.45" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Enter seller details in PDD";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2324.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("3546.56" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("342132322.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"b)	Navigate to Insurance Screen. 
                                    Fire Insurance:
                                    (1)	Open PDD for Insurance Charges and update values as below:
                                    (a)	Buyer At Closing = 14500.34
                                    (b)	Buyer Before Closing = 232423.34
                                    (c)	Paid by Others = 342342.45 (POC)
                                    (d)	Seller At Closing = 323,423.35
                                    (e)	Seller Before Closing = 2,423,423.32
                                    (f)	Paid by Others = 234,234.32 (POC)
                                    (g)	No. Months Prepaid=99
                                    (h)	Additional Description = Complete Amount";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.FirePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("Complete Amount" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("99" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("14500.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("232423.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("342342.45" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Enter seller details in PDD";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("323423.35" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("2423423.32" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("234234.32" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Earthquake Insurance:
                                    (2)	Select and Remove.";
                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"Other Insurance:
                (1)	Add New other insurance with below mentioned details:
                (a)	GAB Insurance = 415 
                (2)	Open PDD for Insurance Charges and update values as below:
                (a)	Buyer At Closing = 234234.34
                (b)	Buyer Before Closing = 353523.234
                (c)	Paid by Others = 323423.34 (POC)
                (d)	Seller At Closing = 234233.34
                (e)	Seller Before Closing = 34233.32
                (f)	Paid by Others = 324234.33(POC)
                (g)	No. Months Prepaid=343
                (h)	Loan Estimate rounded = 4534534.45
                (i)	Broker icon should be displayed.
                (i)	Additional Description = Complete Amount
                (j)	Uncheck “Use Default” and remove Payee name.";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.OtherGABcode.FASetText("415");
                FastDriver.InsuranceOther.OtherFind.FAClick();
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.Description.FASetText("Insurance Premium Other" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("343" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("4534534.45" + FAKeys.Tab);
                Support.AreEqual("true", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString(), true);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("234234.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("353523.234" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("323423.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Enter seller details in PDD";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("234233.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("34233.32" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("324234.33" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"c)	Navigate to Property Tax Check. 
                i)	Edit 1st instance:
                (1)	Open PDD for Property Taxes:
                (a)	Buyer At Closing = 34324.34	
                (b)	Buyer Before Closing = 32343.98
                (c)	Paid by Others = 23423 (POC)
                (d)	No. Months Prepaid=10
                (e)	Loan Estimate unrounded = 323432.98
                (i)	Broker icon should not be displayed.
                (f)	Remove Additional Description.
                (g)	Check “Use Default”.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxSummary.WaitForScreenToLoad();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("10");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("323432.98");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("323432.98" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(true);
                Support.AreEqual("true", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString(), true);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("34324.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("32343.98" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("23423" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"ii)	Edit 2nd instance:
                (1)	Modify GAB Code (E.g. 415)
                (2)	No. Months Prepaid=20
                (3)	Open PDD for Property Taxes:
                (a)	Buyer At Closing = 674564.45
                (b)	Buyer Before Closing = 234353.54
                (c)	Paid by Others = 456457.56 (POC)
                (d)	Seller At Closing = 789565.67
                (e)	Seller Before Closing = 34534.67
                (f)	Paid by Others = 3453453.56 (POC)
                (g)	Uncheck “Use Default” and Remove Payee name.";
                FastDriver.PropertyTaxSummary.WaitForScreenToLoad();
                FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction(1, "2", 1, TableAction.Click);
                FastDriver.PropertyTaxSummary.Edit.FAClick();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("415");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("2nd Instance");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("20");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("674564.45" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("234353.54" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("456457.56" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("789565.67" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("34534.67" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("3453453.56" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"d)	Navigate to CD Screen, expand other cost and verify the values displayed in Section F, I and J.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("01. Homeowner's Insurance Premium Complete Amount ( 99 Mos.) to Wells Fargo", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium Complete Amount", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$14,500.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium Complete Amount", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$232,423.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium Complete Amount", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("$323,423.35", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium Complete Amount", 4, TableAction.GetText).Message.Clean());
                Support.AreEqual("$2,423,423.32", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium Complete Amount", 5, TableAction.GetText).Message.Clean());
                Support.AreEqual("$342,342.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium Complete Amount", 6, TableAction.GetText).Message.Clean());
                Support.AreEqual("$76,879.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium Complete Amount", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$76,880.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Homeowner's Insurance Premium Complete Amount", 8, TableAction.GetText).Message.Clean());

                Support.AreEqual("02. Mortgage Insurance Premium ( 100 Mos.) to Wells Fargo Modified", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$3,000.50", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$3,500.49", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("$2,324.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 4, TableAction.GetText).Message.Clean());
                Support.AreEqual("$3,546.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 5, TableAction.GetText).Message.Clean());
                Support.AreEqual("$1,500.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 6, TableAction.GetText).Message.Clean());
                Support.AreEqual("$847,698,983.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$847,698,983.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 8, TableAction.GetText).Message.Clean());

                Support.AreEqual("03. Prepaid Interest ( $67.40 per day from 3/2/15 to 3/15/15 ) to First", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("-$34,534.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$464,532.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$88,980.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 8, TableAction.GetText).Message.Clean());

                Support.AreEqual("04. ** Property Taxes ( 10 Mos.) to First Midwest", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$34,324.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$32,343.98", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("$2,342,342.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 4, TableAction.GetText).Message.Clean());
                Support.AreEqual("$234,230.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 6, TableAction.GetText).Message.Clean());
                Support.AreEqual("$323,432.98", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$323,433.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes", 8, TableAction.GetText).Message.Clean());

                Support.AreEqual("05. Insurance Premium ( Mos.) to Wells Fargo Bank", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$234,234.23", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$23,423.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium", 4, TableAction.GetText).Message.Clean());

                Support.AreEqual("06. Insurance Premium Other ( 343 Mos.) to Continental Mortgage", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium Other", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$234,234.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium Other", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$353,523.23", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium Other", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("$234,233.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium Other", 4, TableAction.GetText).Message.Clean());
                Support.AreEqual("$34,233.32", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium Other", 5, TableAction.GetText).Message.Clean());
                Support.AreEqual("$323,423.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium Other", 6, TableAction.GetText).Message.Clean());
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium Other", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$4,534,534.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Insurance Premium Other", 8, TableAction.GetText).Message.Clean());

                Support.AreEqual("07. Property Taxes 2nd Instance ( 20 Mos.)", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes 2nd Instance", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$674,564.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes 2nd Instance", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$234,353.54", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes 2nd Instance", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("$789,565.67", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes 2nd Instance", 4, TableAction.GetText).Message.Clean());
                Support.AreEqual("$34,534.67", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes 2nd Instance", 5, TableAction.GetText).Message.Clean());
                Support.AreEqual("$456,457.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Property Taxes 2nd Instance", 6, TableAction.GetText).Message.Clean());

                Support.AreEqual("08. Updated Flood Insurance ( Mos.) to Continental Mortgage", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Updated Flood Insurance", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$56,345.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Updated Flood Insurance", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$45,645.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Updated Flood Insurance", 4, TableAction.GetText).Message.Clean());
                Support.AreEqual("$557,343.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Updated Flood Insurance", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$557,344.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Updated Flood Insurance", 8, TableAction.GetText).Message.Clean());

                Support.AreEqual("09. Wind Insurance Premium ( Mos.) to Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$674,564.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$34,345,645.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$34,345,645.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Wind Insurance Premium", 8, TableAction.GetText).Message.Clean());

                Reports.TestStep = @"e)	Navigate to New Loan | Loan charges.
                Prepaid Interest
                (1)	Select Based On Days = 360";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("04-15-2015");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("2,965.60", FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue().Clean());
                //TODO: Need to look into this. Managed Debugging Assistant 'ContextSwitchDeadlock' has detected a problem in 'C:\Program Files (x86)\Microsoft Visual Studio 12.0\Common7\IDE\QTAgent32.exe'.
                //FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItemByIndex(0); //360
                //FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                //FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                //Support.AreEqual("2,898.20", FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue().Clean());

                Reports.TestStep = @"New Loan Charges | Mortgage Insurance Premium
                (1)	Open PDD and update values as below:
                (a)	Buyer At Closing = 23212.23
                (b)	Buyer Before Closing = 12312.23
                (c)	Paid by Others = 23233.34 (POC-L)
                (d)	Paid by Others = 32423.45(POC-L)";
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.Click);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("23212.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("12312.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("23233.34");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("32423.45");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                Reports.TestStep = @"Click on “Pay Charges”. Add new GAB Code. (E.g. 312).
                    (a)	Check Prepaid Interest. ";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("312");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                FastDriver.NewLoanDisbursements.Charges2.FAClick();

                Reports.TestStep = @"Add new GAB Code. (E.g. BOA).
                    (a)	Check Mortgage Insurance Premium. ";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("BOA");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                FastDriver.NewLoanDisbursements.Charges3.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to CD Screen, expand other cost and verify the values displayed in Section F, I and J.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Support.AreEqual("02. Mortgage Insurance Premium ( 100 Mos.) to Wells Fargo Modified", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$23,212.23", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$12,312.23", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("$2,324.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 4, TableAction.GetText).Message.Clean());
                Support.AreEqual("$3,546.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 5, TableAction.GetText).Message.Clean());
                Support.AreEqual("(L)$23,233.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 6, TableAction.GetText).Message.Clean());
                Support.AreEqual("$847,698,983.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$847,698,983.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 8, TableAction.GetText).Message.Clean());

                Support.AreEqual("03. Prepaid Interest ( $67.40 per day from 3/2/15 to 4/15/15 ) to First", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$2,965.60", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$464,532.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$88,980.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 8, TableAction.GetText).Message.Clean());

                Reports.TestStep = @"g)	Navigate to New Loan | Loan charges.
                Prepaid Interest
                (1)	Remove Buyer Charge";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("0");
                // To be continue ... The script ends here in CodedUI.

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionF_Scenario4()
        {
            try
            {
                Reports.TestDescription = "Continuation of Test Case 527784: Verify charges in Section F – modifying values in PDD. - For Automation Purpose";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"); // BusinessSourceGABcode IDCode = 415
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.FirstNewLoanAmount = (decimal)4500.50; //TermsDatesNewLoanAmnt
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                //TODO: Need to convert this setup data section to web service
                #region setup data
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("4,500.50" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("67.40");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("03-02-2015");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("04-15-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculation_Loan_Estimates_Row1.FASetText("464,532.45" + FAKeys.Tab);

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.SetText, "58,757.80" + FAKeys.Tab);
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 5, TableAction.SetText, "38,294.35" + FAKeys.Tab);
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 7, TableAction.SetText, "9,847,698,983.45" + FAKeys.Tab);
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.Click);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Wells Fargo Modified" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("100");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("23,212.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("12,312.23");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("23,233.34");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLBorrower.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("2,324.34");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("3,546.56");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("32,423.45");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLSeller.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Setup data on Insurance screen";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Insurance");
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.FireGABcode.FASetText("WF");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("BOA");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("589,266.13");
                FastDriver.InsuranceFire.FireSellerCharge.FASetText("2,981,080.99");
                FastDriver.InsuranceFire.FireGFE11.FASetText("76,879.56");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.FloodGABcode.FASetText("214");
                FastDriver.Insuranceflood.FloodFind.FAClick();
                FastDriver.Insuranceflood.FloodGABcodeunderwriter.FASetText("415");
                FastDriver.Insuranceflood.FloodFindunderwriter.FAClick();
                FastDriver.Insuranceflood.FloodBuyercharge.FASetText("56,345.45");
                FastDriver.Insuranceflood.FloodSellerCharge.FASetText("45,645.56");
                FastDriver.Insuranceflood.FloodGFE11.FASetText("557,343.56");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WindGABcode.FASetText("314");
                FastDriver.InsuranceWind.WindFind.FAClick();
                FastDriver.InsuranceWind.WindBuyerCharge.FASetText("674564.45");
                FastDriver.InsuranceWind.WindGFE11.FASetText("34345645.45");
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.OtherGABcodeUnderwriter.FASetText("WF");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherBuyerCharge.FASetText("234234.23");
                FastDriver.InsuranceOther.OtherSellerCharge.FASetText("23423.00");
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.OtherGABcodeUnderwriter.FASetText("415");
                FastDriver.InsuranceOther.OtherFindUnderwriter.FAClick();
                FastDriver.InsuranceOther.OtherBuyerCharge.FASetText("911,180.91");
                FastDriver.InsuranceOther.OtherSellerCharge.FASetText("592,700.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Setup data on Property Tax Check screen";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("312");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("300,898.32");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("2,342,342.00");
                FastDriver.PropertyTaxCheck.PropertyTaxesLoanEstimate_1.FASetText("323,432.98");
                FastDriver.BottomFrame.Done();
                
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("415");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("1,365,375.55");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("4,277,553.90");
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = @"New Loan Charges | Mortgage Insurance Premium
                (4)	Open PDD and update values as below:
                (a)	Paid by Others = 23233.34 (POC-MB)
                (b)	Paid by Others = 32423.45(POC-MB)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.Click);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.MonthPrepaidSelect.FASelectItemBySendingKeys("Months"); //US 434977
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-MB");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-MB");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Navigate to CD Screen, expand other cost and verify the values displayed in Section F, I and J.";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("02. Mortgage Insurance Premium ( 100 Months) to Wells Fargo Modified", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$23,212.23", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$12,312.23", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("$2,324.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 4, TableAction.GetText).Message.Clean());
                Support.AreEqual("$3,546.56", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 5, TableAction.GetText).Message.Clean());
                Support.AreEqual("$23,233.34", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 6, TableAction.GetText).Message.Clean());
                Support.AreEqual("$847,698,983.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$847,698,983.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Mortgage Insurance Premium", 8, TableAction.GetText).Message.Clean());

                Support.AreEqual("03. Prepaid Interest ( $67.40 per day from 3/2/15 to 4/15/15 ) to Continental", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$2,965.60", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$464,532.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$464,532.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 8, TableAction.GetText).Message.Clean());

                Reports.TestStep = @"i)	Navigate to New Loan | Loan charges.
                Prepaid Interest
                (1)	Remove Per Diem Amount, From Date and To Date.
                (2)	Open PDD and enter values as below
                (a)	Buyer At Closing =10
                (b)	Buyer Before Closing = 12
                (c)	Paid by Others = 24 (POC-L)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("");
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.MonthPrepaidSelect.FASelectItemBySendingKeys("Months"); //US 434977
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("10");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("12");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("24");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                Reports.TestStep = @"Navigate to CD Screen, expand other cost and verify the values displayed in Section F, I and J.";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("03. Prepaid Interest ( per day from to ) to Continental", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("$10.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$12.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.GetText).Message.Clean());
                Support.AreEqual("(L)$24.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 6, TableAction.GetText).Message.Clean());
                Support.AreEqual("$464,532.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$464,532.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 8, TableAction.GetText).Message.Clean());

                Reports.TestStep = @"Navigate to New Loan | Loan charges.
                Prepaid Interest
                (1)	Add Per Diem Amount, From Date Later than To Date (04-15-2015) and To Date (03-01-2015).
                (a)	Buyer Credit should be calculated.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.MonthPrepaidSelect.FASelectItemBySendingKeys("Months"); //US 434977
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("92.37");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("04-15-2015");
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("03-01-2015");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("4,156.65", FastDriver.NewLoan.LoanChargesInterestCalculationbuyercredit.FAGetValue().Clean());

                Reports.TestStep = @"Navigate to CD Screen, expand other cost and verify the values displayed in Section F, I and J.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("03. Prepaid Interest ( $92.37 per day from 4/15/15 to 3/1/15 ) to Continental", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 1, TableAction.GetText).Message.Clean());
                Support.AreEqual("-$4,156.65", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 2, TableAction.GetText).Message.Clean());
                Support.AreEqual("$464,532.45", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 7, TableAction.GetText).Message.Clean());
                Support.AreEqual("$464,532.00", FastDriver.ClosingDisclosure.OtherCostsSectionFTable.PerformTableAction(1, "Prepaid Interest", 8, TableAction.GetText).Message.Clean());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
