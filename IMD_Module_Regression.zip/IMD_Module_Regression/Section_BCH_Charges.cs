﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.Linq;
using OpenQA.Selenium;


namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class Section_BCH_Charges : MasterTestClass
    {
        #region New Loan Screen for Loan Charge Tab

        #region Verify charges in Sections B  without entering values in PDD For Loan Charges.

        [TestMethod, Description("VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD FOR LOAN CHARGES .")]
        public void Scenario1_Newloan_CD_B()
        {
            try
            {

                Reports.TestDescription = "VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD FOR LOAN CHARGES .";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string payeeLabel1 = string.Empty;
                string payeeLabel2 = string.Empty;
                string Payeename1 = string.Empty;
                string payeeLabel3 = string.Empty;
                string payeeLabel4 = string.Empty;
                string Payeename2 = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE NEW LOAN INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "ENTER THE VALUES IN lOAN CHARGE TAB IN LOAN CHARGE SECTION";
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", 9234656189.99, null, null, null, 8623623423.49);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", null, null, 6234356689.78, null, 12123523.56);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Flood Certification", 66643.55, null, 7854.54, null, null);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Tax Service", null, null, null, null, 9764.88);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge1", 42342.87, null, null, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge2", null, null, 978888.57, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge3", 8678678.98, null, 9589698.88, null, 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge4", null, null, null, null, 780890.58);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Verify the Charges and Amounts in CD Screen Page 2 Section";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Adhoc Charge1", 2);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, "Adhoc Charge1", 42342.87);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Adhoc Charge2", 3);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, "Adhoc Charge2", null, null, null, 978888.57);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Adhoc Charge3", 4);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, "Adhoc Charge3", 8678678.98, null, null, 9589698.88, null, null, false, 88434634.50, 88434635.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Appraisal Fee", 5);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.B, "Appraisal Fee", 234656189.99, null, null, null, null, null, false, 623623423.49, 623623423.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Credit Report", 6);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, "Credit Report", null, null, null, 234356689.78, null, null, false, 12123523.56, 12123524.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Flood Certification", 7);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.B, "Flood Certification", 66643.55, null, null, 7854.54, null, null, false, null, null);

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 Adhoc Charge1", null, null, 42342.87);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 03 Adhoc Charge3", 88434635, 88434634.50, 8678678.98);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 04 Appraisal Fee", 623623423, 623623423.49, 234656189.99);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 05 Credit Report", 12123524, 12123523.56);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 06 Flood Certification", null, null, 66643.55);
                //Line #6
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(6, "B 00 Adhoc Charge4", 780891, 780890.58);
                //Line #7
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(7, "B 00 Tax Service", 9765, 9764.88);

                //FastDriver.TopFrame.SearchFileByFileNumber("9731");
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECKBOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Playback.Wait(250);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Adhoc Charge3", true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Adhoc Charge1", false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Credit Report", false, 523423423.67, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.B, "Flood Certification", "Modified Charge Description in CD");
                
                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 Adhoc Charge1", 85432, 85432.34, 42342.87);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 03 Adhoc Charge3", 76544, 88434634.50, 8678678.98);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 04 Appraisal Fee", 623623423, 623623423.49, 234656189.99);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 05 Credit Report", 523423424, 523423423.67);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 06 Modified Charge Description in CD", null, null, 66643.55);
                //Line #6
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(6, "B 00 Adhoc Charge4", 780891, 780890.58);
                //Line #7
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(7, "B 00 Tax Service", 9765, 9764.88);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains("Charge3") && i.Displayed).FAClick();
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$88,434,634.50", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains("Charge1") && i.Displayed).FAClick();
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains("Credit Report") && i.Displayed).FAClick();
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains("Credit Report") && i.Displayed).FAClick();
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Modified Charge Description in CD");

                Reports.TestStep = "MODIFY THE VALUES IN SOURCE SCREEN";
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", editDescription: "Verify source Appraisal Fee");
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Verify source Appraisal Fee", buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Modified Charge Description in CD", buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Tax Service", buyerCharge: 8564.78);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge1", buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge2", editDescription: "M0d!f!3d @dh0c CHARGE");
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "M0d!f!3d @dh0c CHARGE", buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge4", buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, "Adhoc Charge1", BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, "Adhoc Charge4", BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.B, "Credit Report", BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "M0d!f!3d @dh0c CHARGE", 6);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, "M0d!f!3d @dh0c CHARGE", BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.B, "Modified Charge Description in CD", BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.B, "Tax Service", BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Verify source Appraisal Fee", 9);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.B, "Verify source Appraisal Fee", BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 Adhoc Charge1", 85432, 85432.34, 93653.76);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 02 Adhoc Charge3", 76544, 88434634.50, 8678678.98);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 03 Adhoc Charge4", 780891, 780890.58, 5233.54);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 04 Credit Report", 523423424, 523423423.67, 68598.00);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 05 M0d!f!3d @dh0c CHARGE", FinalBorrowerPaid: 4545345.00);
                //Line #6
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(6, "B 06 Modified Charge Description in CD", 53435, 53434.87, 8767559.42);
                //Line #7
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(7, "B 07 Tax Service", 9765, 9764.88, 8564.78);
                //Line #8
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(8, "B 08 Verify source Appraisal Fee", 623623423, 623623423.49, 876574.43);

                Reports.TestStep = "NAVIGATE TO NEW LOAN SCREEN AND CLICK ON PAYCHARGES BUTTON";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "CLICK ON NEW BUTTON AND SELECT THE ANY CHARGE AND ENTER THE GAB CODE";
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("321");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                payeeLabel1 = FastDriver.NewLoanDisbursements.ChargesPayeeName1.Text.Trim();
                FastDriver.NewLoanDisbursements.Charges2.FAClick();
                if (FastDriver.NewLoanDisbursements.ChargesPayeeName2.Displayed)
                    payeeLabel2 = FastDriver.NewLoanDisbursements.ChargesPayeeName2.Text.Trim();
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "CLICK ON NEW BUTTON AND SELECT THE ANY CHARGE AND ENTER THE GAB CODE";
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("BOA");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                payeeLabel3 = FastDriver.NewLoanDisbursements.ChargesPayeeName1.Text.Trim();

                if (FastDriver.NewLoanDisbursements.ChargesPayeeName2.Displayed)
                    payeeLabel4 = FastDriver.NewLoanDisbursements.ChargesPayeeName2.Text.Trim();
                FastDriver.BottomFrame.Done();
                Payeename2 = payeeLabel3 + " " + payeeLabel4;

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Playback.Wait(250);

                payeeLabel2 = "to " + payeeLabel2 + " A Division Of";
                payeeLabel1 = payeeLabel1.Trim() + " A Division Of First American Title Ins.";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, payeeLabel1, 5, false);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, payeeLabel2, 8, false, "Tax Service");
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section B with entering values in PDD For Loan Charges.

        [TestMethod, Description("VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD FOR LOAN CHARGES.")]
        public void Scenario2_Newloan_CD_B()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD FOR LOAN CHARGES.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE NEW LOAN INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                PDD obj = new PDD();
                obj.NewLoanTableId = "tNL_tLC_NLC_cgLC_dcs";
                obj.ChargeDescription = "Appraisal Fee";
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj1 = new PDD();
                obj1.NewLoanTableId = "tNL_tLC_NLC_cgLC_dcs";
                obj1.ChargeDescription = "Credit Report";
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC-L";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC-L";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = "tNL_tLC_NLC_cgLC_dcs";
                obj2.ChargeDescription = "Flood Certification";
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC-MB";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC-MB";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge1");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine("Adhoc Charge1", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge2");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine("Adhoc Charge2", FastDriver.NewLoan.NewLoanChargesTable);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Adhoc Charge3");

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = "tNL_tLC_NLC_cgLC_dcs";
                obj3.ChargeDescription = "Adhoc Charge1";
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC-MB";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = "tNL_tLC_NLC_cgLC_dcs";
                obj4.ChargeDescription = "Adhoc Charge2";
                obj4.LoanEstimateRounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC-L";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = "tNL_tLC_NLC_cgLC_dcs";
                obj5.ChargeDescription = "Adhoc Charge3";
                obj5.LoanEstimateUnrounded = 3452.49;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC-L";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC-L";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Save the New Loan changes";
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Verify the Charges and Amounts in CD Screen Page 2 Section";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Adhoc Charge1", 2);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, "Adhoc Charge1", null, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Adhoc Charge2", 3);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, "Adhoc Charge2", BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Adhoc Charge3", 4);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, "Adhoc Charge3", BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, BuyerPaidbyOther: 6654.77, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Appraisal Fee", 5);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.B, "Appraisal Fee", BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Credit Report", 6);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, "Credit Report", BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "Flood Certification", 7);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.B, "Flood Certification", BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);

                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 02 Adhoc Charge2", 67, null, 150.53);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 03 Adhoc Charge3", 3452, 3452.49, 766674.13);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 04 Appraisal Fee", 900, 900.00, 1050.00);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 05 Credit Report", 4342343, 4342342.56, 626345.11);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 06 Flood Certification", 11, 11.49, 94.37);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(1, "Non-Specific Lender Credits", 0);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(3, "B 02 Adhoc Charge2", -44.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(4, "B 03 Adhoc Charge3", -6654.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(5, "B 05 Credit Report", -143452.96);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(6, "B 06 Flood Certification", -1.89);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(7, "Lender Credits Total (J) Excluding Good Faith Violation", -150154.39);

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Adhoc Charge1", true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Credit Report", false, 76534.67, 5);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, "Adhoc Charge2", false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.B, "Flood Certification", "Modified Charge Description in CD");

                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 Adhoc Charge1", 2787, null, null);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 02 Adhoc Charge2", 457, 456.99, 150.53);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 03 Adhoc Charge3", 3452, 3452.49, 766674.13);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 04 Appraisal Fee", 900, 900.00, 1050.00);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 05 Credit Report", 76535, 76534.67, 626345.11);
                //Line #6
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(6, "B 06 Modified Charge Description in CD", 11, 11.49, 94.37);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(1, "Non-Specific Lender Credits", 0);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(3, "B 02 Adhoc Charge2", -44.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(4, "B 03 Adhoc Charge3", -6654.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(5, "B 05 Credit Report", -143452.96);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(6, "B 06 Modified Charge Description in CD", -1.89);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(7, "Lender Credits Total (J) Excluding Good Faith Violation", -150154.39);
                
                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                
                FastDriver.NewLoan.NewLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains("Charge1") && i.Displayed).FAClick();
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                
                FastDriver.NewLoan.NewLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains("Credit Report") && i.Displayed).FAClick();
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.NewLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains("Charge2") && i.Displayed).FAClick();
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                //FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Modified Charge Description in CD", editDescription: "Modified Charge Description in CD");
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj6 = new PDD();                
                obj6.NewLoanTableId = "tNL_tLC_NLC_cgLC_dcs";
                obj6.ChargeDescription = "Adhoc Charge3";
                obj6.PDDDescription = "M0d!f!3d @dh0c CHARGE";
                obj6.UseDefaultModify = false;
                obj6.PayeeName = "Modified Payee Name in PDD";
                obj6.BuyerAtClosing = 44.00;
                obj6.BuyerBeforeClosing = 88.00;
                obj6.BuyerPaidbyOther = 66.7;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC-L";
                obj6.SellerPaidAtClosing = 23.00;
                obj6.SellerPaidBeforeClosing = 53.00;
                obj6.SellerPaidbyOthers = 66.00;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj7 = new PDD();
                obj7.NewLoanTableId = "tNL_tLC_NLC_cgLC_dcs";
                obj7.ChargeDescription = "Appraisal Fee";
                obj7.LenderAffiliate = true;
                obj7.BuyerAtClosing = 243123876.22;
                obj7.BuyerBeforeClosing = 765423456.333;
                obj7.BuyerPaidbyOther = 1111111111.11;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.BuyerDoubleAsteriskChecked = true;
                obj7.SellerPaidAtClosing = 237654234.00;
                obj7.SellerPaidBeforeClosing = 134987353.99;
                obj7.SellerPaidbyOthers = 765432123.98;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = "tNL_tLC_NLC_cgLC_dcs";
                obj8.ChargeDescription = "Modified Charge Description in CD";
                obj8.SectionCDidShopFor = true;
                obj8.LoanEstimateUnrounded = 11.49;
                obj8.BuyerAtClosing = 6.68;
                obj8.BuyerBeforeClosing = 87.69;
                obj8.BuyerPaidbyOther = 1.89;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC-MB";
                obj8.SellerPaidAtClosing = 66.87;
                obj8.SellerPaidBeforeClosing = 6.44;
                obj8.SellerPaidbyOthers = 888.11;
                obj8.SellerPaidbyOtherPaymentMthd = "POC-MB";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Save the Fee Entry changes";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. ALSO VERIFY IF (L) IS NOT DISPLAYED FOR PAID BY OTHERS AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, "M0d!f!3d @dh0c CHARGE", 6);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, "M0d!f!3d @dh0c CHARGE", BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimateRoundedAmt: 3452.00, LoanEstimteUnroundedAmt: 3452.49);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, "Appraisal Fee", BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimateRoundedAmt: 900.00, LoanEstimteUnroundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD("Appraisal Fee", "tblLoanCostSubSection_B", true);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.C, "Modified Charge Description in CD", 2);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(500);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 Adhoc Charge1", 2787, null, null);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 02 Adhoc Charge2", 457, 456.99, 150.53);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 04 Credit Report", 76535, 76534.67, 626345.11);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 05 M0d!f!3d @dh0c CHARGE", 3452, 3452.49, 132.00);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(1, "Non-Specific Lender Credits", 0);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(3, "B 02 Adhoc Charge2", -44.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(4, "B 04 Credit Report", -143452.96);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(5, "B 05 M0d!f!3d @dh0c CHARGE", -66.70);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(6, "Lender Credits Total (J) Excluding Good Faith Violation", -143564.43);

                Reports.TestStep = @"Verify Good Faith Analysis 0% Category";
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory("tblZeroPerVariance", 1, "B 03 Appraisal Fee", 900, 900.00, 8547332.55);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory("tblZeroPerVariance", 2, "J 00 Lender Credits (See Lender Credit Analysis)", null, null, -143564.43);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Sections B  without entering values in PDD for Mortgage Broker.

        [TestMethod, Description("VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD FOR MORTGAGE BROKER .")]
        public void Scenario1_Mortgage_Broker_CD_B()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD FOR MORTGAGE BROKER .";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string AFMBCCHAR = "Appraisal Fee";
                string CRMBCCHAR = "Credit Report";
                string MBCADHOC1 = "Adhoc Charge1";
                string MBCADHOC2 = "Adhoc Charge2";
                string MBCADHOC3 = "Adhoc Charge3";
                string MBCADHOC4 = "Adhoc Charge4";
                string MBCADHOC5 = "Adhoc Charge5";
                string MBCADHOC6 = "Adhoc Charge6";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, Payeename2, payeeLabel1, payeeLabel2 = string.Empty, payeeLabel3, payeeLabel4 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Appraisal Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string MBCTABLEID = "tNL_tMB_NMB_aMCG_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE MORTGAGE BROKER INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "ENTER THE VALUES IN lOAN CHARGE TAB IN MORTGAGE BROKER CHARGES SECTION";
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, AFMBCCHAR, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, CRMBCCHAR, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC1, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC2, loanEstimate: 9764.88);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC3, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC4, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC5, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC6, loanEstimate: 780890.58);
                FastDriver.BottomFrame.Done();

                //FastDriver.TopFrame.SearchFileByFileNumber("3599");

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Verify the Charges and Amounts in CD Screen Page 2 Section";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, MBCADHOC3, 3);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, MBCADHOC3, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, MBCADHOC4, 4);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, MBCADHOC4, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, MBCADHOC5, 5);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.B, MBCADHOC5, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, AFMBCCHAR, 6);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, AFMBCCHAR, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, CRMBCCHAR, 7);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.B, CRMBCCHAR, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, MBCADHOC1, 2);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, MBCADHOC1, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);
                
                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 " + MBCADHOC1, null, null, 66643.55);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 02 " + MBCADHOC3, null, null, 42342.87);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 04 " + MBCADHOC5, 88434635, 88434634.50, 8678678.98);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 05 " + AFMBCCHAR, 623623423, 623623423.49, 234656189.99);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 06 " + CRMBCCHAR, 12123524, 12123523.56, null);
                //Line #6
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(6, "B 00 " + MBCADHOC2, 9765, 9764.88, null);
                //Line #7
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(7, "B 00 " + MBCADHOC6, 780891, 780890.58, null);

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, MBCADHOC5, true, 76543.89, 4);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, MBCADHOC3, false, 85432.34, 2);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, CRMBCCHAR, false, 523423423.67, 6);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.B, MBCADHOC1, EditChargeDesc);

                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 " + MBCADHOC3, 85432, 85432.34, 42342.87);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 03 " + MBCADHOC5, 76544, 88434634.50, 8678678.98);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 04 " + AFMBCCHAR, 623623423, 623623423.49, 234656189.99);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 05 " + CRMBCCHAR, 523423424, 523423423.67, null);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 06 " + EditChargeDesc, null, null, 66643.55);
                //Line #6
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(6, "B 00 " + MBCADHOC2, 9765, 9764.88, null);
                //Line #7
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(7, "B 00 " + MBCADHOC6, 780891, 780890.58, null);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.MortgageBrokerChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(MBCADHOC5) && i.Displayed).FAClick();
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$88,434,634.50", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.MortgageBrokerChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(MBCADHOC3) && i.Displayed).FAClick();
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.MortgageBrokerChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(CRMBCCHAR) && i.Displayed).FAClick();
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN SOURCE SCREEN";
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, AFMBCCHAR, editDescription: SourceChargeDesc);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, CRMBCCHAR, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC2, buyerCharge: 8564.78);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC3, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC4, editDescription: SourceChargeDesc1);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, MBCADHOC6, buyerCharge: 5233.54);

                Reports.TestStep = "Save the Mortgage Broker  Changes";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD..";
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, MBCADHOC3, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.B, MBCADHOC6, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, CRMBCCHAR, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, SourceChargeDesc1, 7);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.B, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.B, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, MBCADHOC2, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, SourceChargeDesc, 9);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.B, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 " + MBCADHOC2, 9765, 9764.88, 8564.78);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 02 " + MBCADHOC3, 85432, 85432.34, 93653.76);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 03 " + MBCADHOC5, 76544, 88434634.50, 8678678.98);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 04 " + MBCADHOC6, 780891, 780890.58, 5233.54);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 05 " + CRMBCCHAR, 523423424, 523423423.67, 68598.00);
                //Line #6
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(6, "B 06 " + SourceChargeDesc1, null, null, 4545345.00);
                //Line #7
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(7, "B 07 " + EditChargeDesc, 53435, 53434.87, 8767559.42);
                //Line #8
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(8, "B 08 " + SourceChargeDesc, 623623423, 623623423.49, 876574.43);

                Reports.TestStep = "NAVIGATE TO NEW LOAN SCREEN AND CLICK ON PAYCHARGES BUTTON";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "CLICK ON NEW BUTTON AND SELECT THE ANY CHARGE AND ENTER THE GAB CODE";
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("321");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                payeeLabel1 = FastDriver.NewLoanDisbursements.ChargesPayeeName1.Text.Trim();
                FastDriver.NewLoanDisbursements.Charges2.FAClick();
                if (FastDriver.NewLoanDisbursements.ChargesPayeeName2.Displayed)
                    payeeLabel2 = FastDriver.NewLoanDisbursements.ChargesPayeeName2.Text.Trim();
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "CLICK ON NEW BUTTON AND SELECT THE ANY CHARGE AND ENTER THE GAB CODE";
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("BOA");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                payeeLabel3 = FastDriver.NewLoanDisbursements.ChargesPayeeName1.Text.Trim();

                if (FastDriver.NewLoanDisbursements.ChargesPayeeName2.Displayed)
                    payeeLabel4 = FastDriver.NewLoanDisbursements.ChargesPayeeName2.Text.Trim();
                FastDriver.BottomFrame.Done();
                Payeename2 = payeeLabel3 + " " + payeeLabel4;

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Playback.Wait(250);

                payeeLabel2 = "to " + payeeLabel2 + " A Division Of";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, payeeLabel3, 5, false);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, payeeLabel2, 2, false, "Charge3");
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Verify charges in Sections B  without entering values in PDD for Mortgage Broker.

        #region Verify charges in Section B with entering values in PDD for Mortgage Broker.

        [TestMethod, Description("VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD FOR MORTGAGE BROKER .")]
        public void Scenario2_Mortgage_Broker_CD_B()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD FOR MORTGAGE BROKER .";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDAFMBCCHAR = "Appraisal Fee";
                string PDDCRMBCCHAR = "Credit Report";
                string PDDMBCADHOC1 = "Flood Certification";
                string PDDMBCADHOC2 = "Adhoc Charge1";
                string PDDMBCADHOC3 = "Adhoc Charge2";
                string PDDMBCADHOC4 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "tNL_tMB_NMB_aMCG_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE MORTGAGE BROKER INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.MortgageBrokerTab, 10);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "CREATE MORTGAGE BROKER INSTANCE AND VERIFY THE SAME.";
                PDD obj = new PDD();
                obj.NewLoanTableId = "tNL_tMB_NMB_aMCG_dcs";
                obj.ChargeDescription = PDDAFMBCCHAR;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj1 = new PDD();
                obj1.NewLoanTableId = "tNL_tMB_NMB_aMCG_dcs";
                obj1.ChargeDescription = PDDCRMBCCHAR;
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC-L";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC-L";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, PDDMBCADHOC1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, PDDMBCADHOC2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, PDDMBCADHOC3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, PDDMBCADHOC4);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = "tNL_tMB_NMB_aMCG_dcs";
                obj2.ChargeDescription = PDDMBCADHOC1;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC-MB";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC-MB";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = "tNL_tMB_NMB_aMCG_dcs";
                obj3.ChargeDescription = PDDMBCADHOC2;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC-MB";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = "tNL_tMB_NMB_aMCG_dcs";
                obj4.ChargeDescription = PDDMBCADHOC3;
                obj4.LoanEstimateRounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC-L";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = "tNL_tMB_NMB_aMCG_dcs";
                obj5.ChargeDescription = PDDMBCADHOC4;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC-L";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC-L";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Save the Mortgage Broker changes";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Verify the Charges and Amounts in CD Screen Page 2 Section";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, PDDMBCADHOC2, 2);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, PDDMBCADHOC2, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, PDDMBCADHOC3, 3);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, PDDMBCADHOC3, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, PDDMBCADHOC4, 4);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, PDDMBCADHOC4, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, PDDAFMBCCHAR, 5);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.B, PDDAFMBCCHAR, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, PDDCRMBCCHAR, 6);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, PDDCRMBCCHAR, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, PDDMBCADHOC1, 7);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.B, PDDMBCADHOC1, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);

                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 02 " + PDDMBCADHOC3, 67, null, 150.53);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 03 " + PDDMBCADHOC4, 3452, 3452.49, 766674.13);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 04 " + PDDAFMBCCHAR, 900, 900.00, 1050.00);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 05 " + PDDCRMBCCHAR, 4342343, 4342342.56, 626345.11);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 06 " + PDDMBCADHOC1, 11, 11.49, 94.37);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(1, "Non-Specific Lender Credits", 0);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(3, "B 02 Adhoc Charge2", -44.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(4, "B 03 Adhoc Charge3", -6654.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(5, "B 05 Credit Report", -143452.96);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(6, "B 06 Flood Certification", -1.89);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(7, "Lender Credits Total (J) Excluding Good Faith Violation", -150154.39);

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, PDDMBCADHOC2, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, PDDCRMBCCHAR, false, 76534.67, 5);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, PDDMBCADHOC3, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.B, PDDMBCADHOC1, EditChargeDesc);

                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 " + PDDMBCADHOC2, 2787, null, null);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 02 " + PDDMBCADHOC3, 457, 456.99, 150.53);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 03 " + PDDMBCADHOC4, 3452, 3452.49, 766674.13);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 04 " + PDDAFMBCCHAR, 900, 900.00, 1050.00);
                //Line #5
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(5, "B 05 " + PDDCRMBCCHAR, 76535, 76534.67, 626345.11);
                //Line #6
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(6, "B 06 " + EditChargeDesc, 11, 11.49, 94.37);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(1, "Non-Specific Lender Credits", 0);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(3, "B 02 Adhoc Charge2", -44.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(4, "B 03 Adhoc Charge3", -6654.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(5, "B 05 Credit Report", -143452.96);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(6, "B 06 Modified Charge Description in CD", -1.89);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(7, "Lender Credits Total (J) Excluding Good Faith Violation", -150154.39);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.MortgageBrokerChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDMBCADHOC2) && i.Displayed).FAClick();
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.MortgageBrokerChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDCRMBCCHAR) && i.Displayed).FAClick();
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.MortgageBrokerChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDMBCADHOC3) && i.Displayed).FAClick();
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, EditChargeDesc, editDescription: EditChargeDesc);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, PDDCRMBCCHAR, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj6 = new PDD();                
                obj6.NewLoanTableId = "tNL_tMB_NMB_aMCG_dcs";
                obj6.ChargeDescription = PDDMBCADHOC4;
                obj6.PDDDescription = pddChargeDesc;
                obj6.UseDefaultModify = false;
                obj6.PayeeName = PDDPayeeName;
                obj6.BuyerAtClosing = 44.00;
                obj6.BuyerBeforeClosing = 88.00;
                obj6.BuyerPaidbyOther = 66.7;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC-L";
                obj6.SellerPaidAtClosing = 23.00;
                obj6.SellerPaidBeforeClosing = 53.00;
                obj6.SellerPaidbyOthers = 66.00;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj7 = new PDD();
                obj7.NewLoanTableId = "tNL_tMB_NMB_aMCG_dcs";
                obj7.ChargeDescription = PDDAFMBCCHAR;
                obj7.LenderAffiliate = true;
                obj7.BuyerAtClosing = 243123876.22;
                obj7.BuyerBeforeClosing = 765423456.333;
                obj7.BuyerPaidbyOther = 1111111111.11;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.BuyerDoubleAsteriskChecked = true;
                obj7.SellerPaidAtClosing = 237654234.00;
                obj7.SellerPaidBeforeClosing = 134987353.99;
                obj7.SellerPaidbyOthers = 765432123.98;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = "tNL_tMB_NMB_aMCG_dcs";
                obj8.ChargeDescription = EditChargeDesc;
                obj8.SectionCDidShopFor = true;
                obj8.LoanEstimateUnrounded = 11.49;
                obj8.BuyerAtClosing = 6.68;
                obj8.BuyerBeforeClosing = 87.69;
                obj8.BuyerPaidbyOther = 1.89;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC-MB";
                obj8.SellerPaidAtClosing = 66.87;
                obj8.SellerPaidBeforeClosing = 6.44;
                obj8.SellerPaidbyOthers = 888.11;
                obj8.SellerPaidbyOtherPaymentMthd = "POC-MB";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Save the Mortgage Broker changes";
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. ALSO VERIFY IF (L) IS NOT DISPLAYED FOR PAID BY OTHERS AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.B, pddChargeDesc, 6);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimateRoundedAmt: 3452.00, LoanEstimteUnroundedAmt: 3452.49);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, PDDAFMBCCHAR, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimateRoundedAmt: 900.00, LoanEstimteUnroundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(PDDAFMBCCHAR, "tblLoanCostSubSection_B", true);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.C, true, EditChargeDesc, true, PayeeName);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(500);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Click on Good Faith Variance link in CD";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();

                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaithAnalysisCategoryTable, 10);
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(1, "B 01 " + PDDMBCADHOC2, 2787, null, null);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(2, "B 02 " + PDDMBCADHOC3, 457, 456.99, 150.53);
                //Line #3
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(3, "B 04 " + PDDCRMBCCHAR, 76535, 76534.67, 626345.11);
                //Line #4
                FastDriver.ClosingDisclosure.VerifyAmountForCategory(4, "B 05 " + pddChargeDesc, 3452, 3452.49, 132.00);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(1, "Non-Specific Lender Credits", 0);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(3, "B 02 Adhoc Charge2", -44.77);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(4, "B 04 Credit Report", -143452.96);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(5, "B 05 M0d!f!3d @dh0c CHARGE", -66.70);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(6, "Lender Credits Total (J) Excluding Good Faith Violation", -143564.43);

                Reports.TestStep = @"Verify Good Faith Analysis 0% Category";
                //Line #1
                FastDriver.ClosingDisclosure.VerifyAmountForCategory("tblZeroPerVariance", 1, "B 03 " + PDDAFMBCCHAR, 900, 900.00, 8547332.55);
                //Line #2
                FastDriver.ClosingDisclosure.VerifyAmountForCategory("tblZeroPerVariance", 2, "J 00 Lender Credits (See Lender Credit Analysis)", null, null, -143564.43);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion Verify charges in Section B with entering values in PDD for Mortgage Broker.

        #endregion New Loan Screen for Loan Charge Tab

        #region AssumptionLoan

        #region Verify charges in Section H without entering values in PDD for Assumption Loan.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR ASSUMPTION LOAN.")]
        public void Senario1_AssumptionLoan_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR ASSUMPTION LOAN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string ChrDesc = "Assumption Transfer Fee";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, Payeename2, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "M0d!f!3d @dh0c CHARGE";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE ASSUMPTION LOAN INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "ENTER THE VALUES IN ASSUMPTION LOAN CHARGES SECTION";
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(ChrDesc, buyerCharge: 9234656189.99, sellerCharge: 7654322765.32, loanEstimateUnrounded: 654312345.49);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H.";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection.H, ChrDesc, 2);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 234656189.99, SellerAtClosing: 654322765.32, LoanEstimteUnroundedAmt: 654312345.49, LoanEstimateRoundedAmt: 654312345.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE ROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc, true, 86543.89, 1);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, ChrDesc, EditChargeDesc);

                Reports.TestStep = "Navigate to New Assumption loan Screen and Validate changes";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);

                Reports.TestStep = "NAVIGATE TO CHARGES TAB IN ASSUMPTION LOAN SCREEN";
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(EditChargeDesc) && i.Displayed).FAClick();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$86,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$654,312,345.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual(EditChargeDesc, FastDriver.PaymentDetailsDlg.DESCRPTION.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                //FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(EditChargeDesc, updateDesc: EditChargeDesc);

                Reports.TestStep = "Modify the values for Charges in Assumption Loan Screen";
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(EditChargeDesc, updateDesc: SourceChargeDesc);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 0.00, loanEstimateUnrounded: 53434.87);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);

                Reports.TestStep = "CHANGE ASSUMPTION LOAN INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("241");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                Payeename1 = FastDriver.AssumptionLoanDetails.GABcodeName.Text.Trim();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

                Reports.TestStep = "NAVIGATE TO ASSUMPTION LOAN SCREEN AND CLICK ON PAYCHARGES BUTTON";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);

                Reports.TestStep = "NAVIGATE TO CHARGES TAB IN ASSUMPTION LOAN SCREEN";
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.PayCharges.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "CLICK ON NEW BUTTON AND SELECT THE ANY CHARGE AND ENTER THE GAB CODE";
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.Charges1.FAClick();
                FastDriver.NewLoanDisbursements.New.FAClick();
                Playback.Wait(250);
                FastDriver.NewLoanDisbursements.GABcode.FASetText("BOA");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                FastDriver.NewLoanDisbursements.Charges1.FAClick();
                payeeLabel1 = FastDriver.NewLoanDisbursements.PayeeName.Text.Clean();

                if (FastDriver.NewLoanDisbursements.PayeeNameLebel2.Displayed)
                    payeeLabel2 = FastDriver.NewLoanDisbursements.PayeeNameLebel2.Text.Clean();
                Payeename2 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename2);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Assumption Loan.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD.")]
        public void Senario2_AssumptionLoan_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string ChrDesc = "Assumption Transfer Fee";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD", PayeeNameinPDD;
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "tAL_tLC_ALC_cgs_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE ASSUMPTION LOAN INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "OPEN PDD AND ENTER THE VALUES IN CHARGES TAB FOR ASSUMPTION LOAN SCREEN";
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = ChrDesc;
                obj.LoanEstimateUnrounded = 4342342.56;
                obj.BuyerAtClosing = 2114.76;
                obj.BuyerBeforeClosing = 624230.35;
                obj.BuyerPaidbyOther = 143452.96;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 1342.36;
                obj.SellerPaidBeforeClosing = 42423.77;
                obj.SellerPaidbyOthers = 23423.45;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE ROUNDED AND VERIFY THE BROKEN LINK FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc, true, 67654.49, 1);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, ChrDesc, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN ASSUMPTION LOAN SCREEN";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                Reports.TestStep = "NAVIGATE TO CHARGES TAB IN ASSUMPTION LOAN SCREEN";
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(EditChargeDesc) && i.Displayed).FAClick();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$67,654.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$4,342,342.56", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(EditChargeDesc, loanEstimateUnrounded: 4342342.56);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND  CHANGE THE PAYEENAME  IN PDD AND VERIFY THE L-SYMBOL IN CD SCREEN ";
                PDD obj1 = new PDD();
                obj1.NewLoanTableId = TableID;
                obj1.ChargeDescription = EditChargeDesc;
                obj1.PDDDescription = pddChargeDesc;
                obj1.UseDefaultModify = false;
                obj1.PayeeName = PDDPayeeName;
                obj1.LoanEstimateUnrounded = 65432.51;
                obj1.BuyerAtClosing = 123876.22;
                obj1.BuyerBeforeClosing = 5423456.333;
                obj1.BuyerPaidbyOther = 3244566.49;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC-L";
                obj1.SellerPaidAtClosing = 7654234.55;
                obj1.SellerPaidBeforeClosing = 987353.99;
                obj1.SellerPaidbyOthers = 5432123.98;
                obj1.SellerPaidbyOtherPaymentMthd = "POC-L";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR CHARGE IN CD. ALSO VERIFY IF (L) IS DISPLAYED FOR PAID BY OTHERS AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 123876.22, BuyerBeforeClosing: 5423456.33, SellerAtClosing: 7654234.55, SellerBeforeClosing: 987353.99, BuyerPaidbyOther: 3244566.49, LoanEstimteUnroundedAmt: 65432.51, LoanEstimateRoundedAmt: 65433.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE ROUNDED AND VERIFY THE BROKEN LINK FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, pddChargeDesc, true, 87654.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, pddChargeDesc, false, 276.49, 1);
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN ASSUMPTION LOAN SCREEN AND CHANGE THE GAB CODE";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                Reports.TestStep = "CHANGE THE ASSUMPTION LOAN INSTANCE";
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("BOA");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);

                Reports.TestStep = "NAVIGATE TO CHARGES TAB IN ASSUMPTION LOAN SCREEN";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(pddChargeDesc) && i.Displayed).FAClick();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$276.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$276.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$6543.99");
                Keyboard.SendKeys(FAKeys.TabAway);
                PayeeNameinPDD = FastDriver.PaymentDetailsDlg.PayeeName.GetAttribute("value").Clean();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PayeeNameinPDD);
                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.H, pddChargeDesc, "verify", true, 6544.00M, false);
                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.H, pddChargeDesc, "verify", false, 276.49M, false);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion AssumptionLoan

        #region Outside Escrow Company

        #region Verify charges in Section H without entering values in PDD for Outside Escrow Company.

        [TestMethod, Description("VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD.")]
        public void Senario1_OutsideEscrowCompany_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string ChrDesc = "Appraisal Fee";
                string ChrDesc1 = "Credit Report";
                string ChrDesc2 = "Flood Certification";
                string ChrDesc3 = "Tax Service";
                string ChrDesc4 = "Adhoc Charge1";
                string ChrDesc5 = "Adhoc Charge2";
                string ChrDesc6 = "Adhoc Charge3";
                string ChrDesc7 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Appraisal Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE OUTSIDE ESCROW COMPANY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("247");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN OUTSIDE ESCROW COMPANY SCREEN";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                

                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc1, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc2, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc3, loanEstimate: 9764.88);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc4, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc5, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc6, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc7, loanEstimate: 780890.58);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Verify the Charges and Amounts in CD Screen Page 2 Section";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc4, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, ChrDesc5, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc6, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc6, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, ChrDesc1, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, ChrDesc2, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc6, true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc4, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc1, false, 523423423.67, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + ChrDesc2 ;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, ChrDesc2, EditChargeDesc);

                Reports.TestStep = "Navigate to OEC Screen and Validate changes";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc6) && i.Displayed).FAClick();
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc4) && i.Displayed).FAClick();
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc1) && i.Displayed).FAClick();
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN SOURCE SCREEN";
                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, ChrDesc, editDescription: SourceChargeDesc);
                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, ChrDesc1, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, ChrDesc3, buyerCharge: 8564.78);
                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, ChrDesc4, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, ChrDesc5, editDescription: SourceChargeDesc1);
                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, ChrDesc7, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc4, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc7, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ChrDesc1, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, ChrDesc3, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "CHANGE OUTSIDE ESCROW COMPANY INSTANCE";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("BOA");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                payeeLabel1 = FastDriver.OutsideEscrowCompanyDetail.BusinessPartyNameField.Text.Clean();

                if(FastDriver.OutsideEscrowCompanyDetail.BusinessPartyNameField2.Displayed)
                    payeeLabel2 = FastDriver.OutsideEscrowCompanyDetail.BusinessPartyNameField.Text.Clean();
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc4, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc7, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc3, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Outside Escrow Company.

        [TestMethod, Description("VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD.")]
        public void Senario2_OutsideEscrowCompany_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string ChrDesc = "Appraisal Fee";
                string ChrDesc1 = "Credit Report";
                string ChrDesc2 = "Flood Certification";
                string ChrDesc3 = "Adhoc Charge1";
                string ChrDesc4 = "Adhoc Charge2";
                string ChrDesc5 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "ocg_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE OUTSIDE ESCROW COMPANY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText("247");
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "CREATE THE ADHOC CHARGES IN OUTSIDE ESCROW COMPANY SCREEN";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc, FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc1, FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc2, FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc3, FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc4);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc4, FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, chargeDescription: ChrDesc5);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER THE VALUES FOR ADHOC CHARGES IN OUTSIDE ESCROW COMPANY SCREEN";
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = ChrDesc;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj1 = new PDD();
                obj1.NewLoanTableId = TableID;
                obj1.ChargeDescription = ChrDesc1;
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = ChrDesc2;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = ChrDesc3;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = ChrDesc4;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = ChrDesc5;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc3, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, ChrDesc4, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc5, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, ChrDesc1, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, ChrDesc2, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc3, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc1, false, 76534.67, 5);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc4, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, ChrDesc2, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc3) && i.Displayed).FAClick();
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc1) && i.Displayed).FAClick();
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc4) && i.Displayed).FAClick();
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, ChrDesc1, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = ChrDesc5;
                obj6.PDDDescription = pddChargeDesc;
                obj6.UseDefaultModify = false;
                obj6.PayeeName = PDDPayeeName;
                obj6.BuyerAtClosing = 44.00;
                obj6.BuyerBeforeClosing = 88.00;
                obj6.BuyerPaidbyOther = 66.7;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 23.00;
                obj6.SellerPaidBeforeClosing = 53.00;
                obj6.SellerPaidbyOthers = 66.00;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = ChrDesc;
                obj7.BuyerAtClosing = 243123876.22;
                obj7.BuyerBeforeClosing = 765423456.333;
                obj7.BuyerPaidbyOther = 1111111111.11;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.BuyerDoubleAsteriskChecked = true;
                obj7.SellerPaidAtClosing = 237654234.00;
                obj7.SellerPaidBeforeClosing = 134987353.99;
                obj7.SellerPaidbyOthers = 765432123.98;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = EditChargeDesc;
                obj8.SectionCDidShopFor = true;
                obj8.LoanEstimateUnrounded = 11.49;
                obj8.BuyerAtClosing = 6.68;
                obj8.BuyerBeforeClosing = 87.69;
                obj8.BuyerPaidbyOther = 1.89;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.SellerPaidAtClosing = 66.87;
                obj8.SellerPaidBeforeClosing = 6.44;
                obj8.SellerPaidbyOthers = 888.11;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj9 = new PDD();
                obj9.NewLoanTableId = TableID;
                obj9.ChargeDescription = ChrDesc4;
                obj9.SectionBdidnotShopFor = true;
                obj9.LoanEstimateRounded = 67.49;
                obj9.BuyerAtClosing = 62.87;
                obj9.BuyerBeforeClosing = 87.66;
                obj9.BuyerPaidbyOther = 44.77;
                obj9.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj9);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. ALSO VERIFY IF (L) IS NOT DISPLAYED FOR PAID BY OTHERS AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(ChrDesc, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(500);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.C, true, EditChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, ChrDesc4, true, PayeeName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Attorney Buyer

        #region Verify charges in Section H without entering values in PDD for Attorney Buyer.

        [TestMethod]
        public void Senario1_Attorney_Buyer_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION B WITHOUT ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string ChrDesc = "Attorney Fee";
                string ChrDesc1 = "Credit Report";
                string ChrDesc2 = "Flood Certification";
                string ChrDesc3 = "Tax Service";
                string ChrDesc4 = "Adhoc Charge1";
                string ChrDesc5 = "Adhoc Charge2";
                string ChrDesc6 = "Adhoc Charge3";
                string ChrDesc7 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Appraisal Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE ATTORNEY BUYER INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN ATTORNEY BUYER SCREEN";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc1, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc2, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc3, loanEstimate: 9764.88);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc4, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc5, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc6, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc7, loanEstimate: 780890.58);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Verify the Charges and Amounts in CD Screen Page 2 Section";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc4, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, ChrDesc5, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc6, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc6, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, ChrDesc1, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, ChrDesc2, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc6, true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc4, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc1, false, 523423423.67, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + ChrDesc2;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, ChrDesc2, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN ATTORNEY BUYER SCREEN";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc6) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc4) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc1) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Reports.TestStep = "MODIFY THE VALUES IN ATTORNEY BUYER SCREEN";
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc, editDescription: SourceChargeDesc);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc1, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc3, buyerCharge: 8564.78);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc4, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc5, editDescription: SourceChargeDesc1);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc7, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc4, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc7, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ChrDesc1, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, ChrDesc3, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Navigate to Attorney Buyer Screen";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AttorneyDetail.GABcode.FASetText("BOA");
                FastDriver.AttorneyDetail.Find.FAClick();

                payeeLabel1 = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName.Text.Clean();

                if (FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName1.Displayed)
                    payeeLabel2 = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName1.Text.Clean();
                
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "VERIFY THE UPDATED PAYEENAME IN CD SCREEN";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc4, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc7, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc3, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Attorney Buyer.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD.")]
        public void Senario2_Attorney_Buyer_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string ChrDesc = "Attorney Fee";
                string ChrDesc1 = "Credit Report";
                string ChrDesc2 = "Flood Certification";
                string ChrDesc3 = "Adhoc Charge1";
                string ChrDesc4 = "Adhoc Charge2";
                string ChrDesc5 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "acg_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE  ATTORNEY BUYER INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "CREATE THE ADHOC CHARGES IN ATTORNEY BUYER SCREEN";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc1, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc2, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc3, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc4);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc4, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc5);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER THE VALUES FOR ADHOC CHARGES IN OUTSIDE ESCROW COMPANY SCREEN";
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = ChrDesc;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj1 = new PDD();
                obj1.NewLoanTableId = TableID;
                obj1.ChargeDescription = ChrDesc1;
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = ChrDesc2;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = ChrDesc3;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = ChrDesc4;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = ChrDesc5;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc3, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, ChrDesc4, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc5, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, ChrDesc1, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, ChrDesc2, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc3, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc1, false, 76534.67, 5);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc4, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, ChrDesc2, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Buyer").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc3) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc1) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc4) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc1, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = ChrDesc5;
                obj6.PDDDescription = pddChargeDesc;
                obj6.UseDefaultModify = false;
                obj6.PayeeName = PDDPayeeName;
                obj6.BuyerAtClosing = 44.00;
                obj6.BuyerBeforeClosing = 88.00;
                obj6.BuyerPaidbyOther = 66.7;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 23.00;
                obj6.SellerPaidBeforeClosing = 53.00;
                obj6.SellerPaidbyOthers = 66.00;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = ChrDesc;
                obj7.BuyerAtClosing = 243123876.22;
                obj7.BuyerBeforeClosing = 765423456.333;
                obj7.BuyerPaidbyOther = 1111111111.11;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.BuyerDoubleAsteriskChecked = true;
                obj7.SellerPaidAtClosing = 237654234.00;
                obj7.SellerPaidBeforeClosing = 134987353.99;
                obj7.SellerPaidbyOthers = 765432123.98;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = EditChargeDesc;
                obj8.SectionCDidShopFor = true;
                obj8.LoanEstimateUnrounded = 11.49;
                obj8.BuyerAtClosing = 6.68;
                obj8.BuyerBeforeClosing = 87.69;
                obj8.BuyerPaidbyOther = 1.89;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.SellerPaidAtClosing = 66.87;
                obj8.SellerPaidBeforeClosing = 6.44;
                obj8.SellerPaidbyOthers = 888.11;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj9 = new PDD();
                obj9.NewLoanTableId = TableID;
                obj9.ChargeDescription = ChrDesc4;
                obj9.SectionBdidnotShopFor = true;
                obj9.LoanEstimateRounded = 67.49;
                obj9.BuyerAtClosing = 62.87;
                obj9.BuyerBeforeClosing = 87.66;
                obj9.BuyerPaidbyOther = 44.77;
                obj9.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj9);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. ALSO VERIFY IF (L) IS NOT DISPLAYED FOR PAID BY OTHERS AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(ChrDesc, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.C, true, EditChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, ChrDesc4, true, PayeeName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Attorney Seller

        #region Verify charges in Section H without entering values in PDD for Attorney Seller.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR ATTORNEY SELLER.")]
        public void Senario1_Attorney_Seller_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR ATTORNEY SELLER.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string ChrDesc = "Attorney Fee";
                string ChrDesc1 = "Credit Report";
                string ChrDesc2 = "Flood Certification";
                string ChrDesc3 = "Tax Service";
                string ChrDesc4 = "Adhoc Charge1";
                string ChrDesc5 = "Adhoc Charge2";
                string ChrDesc6 = "Adhoc Charge3";
                string ChrDesc7 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Appraisal Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE ATTORNEY SELLER INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN ATTORNEY SELLER SCREEN";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc1, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc1, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc2, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc2, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc3, loanEstimate: 9764.88);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc3, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc4, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc4, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc5, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc5, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc6, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc6, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc7, loanEstimate: 780890.58);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Verify the Charges and Amounts in CD Screen Page 2 Section";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc4, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, ChrDesc5, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc6, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc6, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, ChrDesc1, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChrDesc2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, ChrDesc2, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc6, true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc4, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc1, false, 523423423.67, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + ChrDesc2;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, ChrDesc2, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN ATTORNEY BUYER SCREEN";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc6) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc4) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc1) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN ATTORNEY SELLER SCREEN";
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc, editDescription: SourceChargeDesc);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc1, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc3, buyerCharge: 8564.78);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc4, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc5, editDescription: SourceChargeDesc1);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc7, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc4, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc7, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ChrDesc1, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, ChrDesc3, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Navigate to Attorney Buyer Screen";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AttorneyDetail.GABcode.FASetText("BOA");
                FastDriver.AttorneyDetail.Find.FAClick();

                payeeLabel1 = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName.Text.Clean();

                if (FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName1.Displayed)
                    payeeLabel2 = FastDriver.AttorneyDetail.AttorneyBuyerSeller_LenderName1.Text.Clean();

                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "VERIFY THE UPDATED PAYEENAME IN CD SCREEN";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc4, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc7, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc3, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Attorney Seller .

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR ATTORNEY SELLER.")]
        public void Senario2_Attorney_Seller_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR ATTORNEY SELLER.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string ChrDesc = "Attorney Fee";
                string ChrDesc1 = "Credit Report";
                string ChrDesc2 = "Flood Certification";
                string ChrDesc3 = "Adhoc Charge1";
                string ChrDesc4 = "Adhoc Charge2";
                string ChrDesc5 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "acg_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE  ATTORNEY SELLER INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AttorneyDetail.GABcode.FASetText("247");
                FastDriver.AttorneyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "CREATE THE ADHOC CHARGES IN ATTORNEY SELLER SCREEN";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc1, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc2, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc3, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc4);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(ChrDesc4, FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                FastDriver.AttorneyDetail.AddCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, chargeDescription: ChrDesc5);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER THE VALUES FOR ADHOC CHARGES IN ATTORNEY SELLER SCREEN";
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = ChrDesc;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj1 = new PDD();
                obj1.NewLoanTableId = TableID;
                obj1.ChargeDescription = ChrDesc1;
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = ChrDesc2;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = ChrDesc3;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = ChrDesc4;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = ChrDesc5;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChrDesc3, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, ChrDesc4, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc5, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, ChrDesc1, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ChrDesc2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, ChrDesc2, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc3, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc1, false, 76534.67, 5);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ChrDesc4, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, ChrDesc2, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc3) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc1) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.SellerAttorneyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ChrDesc4) && i.Displayed).FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.UpdateCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, ChrDesc1, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = ChrDesc5;
                obj6.PDDDescription = pddChargeDesc;
                obj6.UseDefaultModify = false;
                obj6.PayeeName = PDDPayeeName;
                obj6.BuyerAtClosing = 44.00;
                obj6.BuyerBeforeClosing = 88.00;
                obj6.BuyerPaidbyOther = 66.7;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 23.00;
                obj6.SellerPaidBeforeClosing = 53.00;
                obj6.SellerPaidbyOthers = 66.00;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = ChrDesc;
                obj7.BuyerAtClosing = 243123876.22;
                obj7.BuyerBeforeClosing = 765423456.333;
                obj7.BuyerPaidbyOther = 1111111111.11;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.BuyerDoubleAsteriskChecked = true;
                obj7.SellerPaidAtClosing = 237654234.00;
                obj7.SellerPaidBeforeClosing = 134987353.99;
                obj7.SellerPaidbyOthers = 765432123.98;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. ALSO VERIFY IF (L) IS NOT DISPLAYED FOR PAID BY OTHERS AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, ChrDesc, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(ChrDesc, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Outside Title Company

        #region Verify charges in Sections C  without entering values in PDD.

        [TestMethod, Description("VERIFY CHARGES IN SECTION C WITHOUT ENTERING VALUES IN PDD.")]
        public void Scenario1_OTC_TitleServices_CD_C()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION C WITHOUT ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string TTEOTCChar = "Title - Title Examination";
                string TATSOTCChar = "Title - Abstract or Title Search";
                string TDPOTCChar = "Title - Document preparation";
                string TSAFOTCChar = "Title - Settlement Charge";
                string OTCTSAdhoc1 = "Adhoc Charge1";
                string OTCTSAdhoc2 = "Adhoc Charge2";
                string OTCTSAdhoc3 = "Adhoc Charge3";
                string OTCTSAdhoc4 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Update Charge in OTC Screen for TS";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE OUTSIDE TITLE COMPNAY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("247");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN ATTORNEY SELLER SCREEN";
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();

                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: TTEOTCChar, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: TATSOTCChar, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: TDPOTCChar, buyerCharge: 66643.55, sellerCharge: 7854.54);
                if (chargeAvailability("agc_dcs", TSAFOTCChar))
                {
                    FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: TSAFOTCChar, loanEstimate: 9764.88);
                }
                else
                {
                    FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: TSAFOTCChar, loanEstimate: 9764.88);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    verifyEmptyLine(TSAFOTCChar, FastDriver.OutsideTitleCompanyDetail.TitleServicesTable);
                }
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: OTCTSAdhoc1, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(OTCTSAdhoc1, FastDriver.OutsideTitleCompanyDetail.TitleServicesTable);
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: OTCTSAdhoc2, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(OTCTSAdhoc2, FastDriver.OutsideTitleCompanyDetail.TitleServicesTable);
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: OTCTSAdhoc3, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(OTCTSAdhoc3, FastDriver.OutsideTitleCompanyDetail.TitleServicesTable);
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: OTCTSAdhoc4, loanEstimate: 780890.58);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Verify the Charges and Amounts in CD Screen Page 2 Section";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, OTCTSAdhoc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, OTCTSAdhoc1, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, OTCTSAdhoc2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, OTCTSAdhoc2, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, OTCTSAdhoc3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, OTCTSAdhoc3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, TATSOTCChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.B, TATSOTCChar, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, TDPOTCChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, TDPOTCChar, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, TTEOTCChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.B, TTEOTCChar, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, OTCTSAdhoc3, true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, OTCTSAdhoc1, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, TATSOTCChar, false, 523423423.67, 4);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.B, TDPOTCChar, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(OTCTSAdhoc3) && i.Displayed).FAClick();
                FastDriver.OutsideTitleCompanyDetail.TitleServicePaymentDetail.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();

                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(OTCTSAdhoc1) && i.Displayed).FAClick();
                FastDriver.OutsideTitleCompanyDetail.TitleServicePaymentDetail.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();

                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(TATSOTCChar) && i.Displayed).FAClick();
                FastDriver.OutsideTitleCompanyDetail.TitleServicePaymentDetail.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN ATTORNEY SELLER SCREEN";
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, TTEOTCChar, editDescription: SourceChargeDesc);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, TATSOTCChar, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, TSAFOTCChar, buyerCharge: 8564.78);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, OTCTSAdhoc1, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, OTCTSAdhoc2, editDescription: SourceChargeDesc1);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, OTCTSAdhoc4, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, OTCTSAdhoc1, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, OTCTSAdhoc3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 76544.00);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, OTCTSAdhoc4, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.B, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.B, TATSOTCChar, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.B, TSAFOTCChar, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.B, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section C with entering values in PDD.

        [TestMethod, Description("VERIFY CHARGES IN SECTION C ENTERING VALUES IN PDD.")]
        public void Scenario2_OTC_TitleServices_CD_C()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION C ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string TTEOTCChar = "Title - Title Examination";
                string TATSOTCChar = "Title - Abstract or Title Search";
                string TDPOTCChar = "Title - Document preparation";
                string OTCTSAdhoc1 = "Adhoc Charge1";
                string OTCTSAdhoc2 = "Adhoc Charge2";
                string OTCTSAdhoc3 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "agc_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE OUTSIDE TITLE COMPNAY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("247");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = TTEOTCChar;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj1 = new PDD();
                obj1.NewLoanTableId = TableID;
                obj1.ChargeDescription = TATSOTCChar;
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = TDPOTCChar;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: OTCTSAdhoc1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(OTCTSAdhoc1, FastDriver.OutsideTitleCompanyDetail.TitleServicesTable);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: OTCTSAdhoc2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(OTCTSAdhoc2, FastDriver.OutsideTitleCompanyDetail.TitleServicesTable);
                FastDriver.OutsideEscrowCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, chargeDescription: OTCTSAdhoc3);
                
                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = OTCTSAdhoc1;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = OTCTSAdhoc2;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = OTCTSAdhoc3;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, OTCTSAdhoc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, OTCTSAdhoc1, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, OTCTSAdhoc2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, OTCTSAdhoc2, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, OTCTSAdhoc3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, OTCTSAdhoc3, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, TATSOTCChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.B, TATSOTCChar, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, TDPOTCChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, TDPOTCChar, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, TTEOTCChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.B, TTEOTCChar, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, OTCTSAdhoc1, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, TATSOTCChar, false, 76534.67, 4);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.B, OTCTSAdhoc2, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.B, TDPOTCChar, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(OTCTSAdhoc1) && i.Displayed).FAClick();
                FastDriver.OutsideTitleCompanyDetail.TitleServicePaymentDetail.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();

                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(TATSOTCChar) && i.Displayed).FAClick();
                FastDriver.OutsideTitleCompanyDetail.TitleServicePaymentDetail.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();

                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(OTCTSAdhoc2) && i.Displayed).FAClick();
                FastDriver.OutsideTitleCompanyDetail.TitleServicePaymentDetail.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OutsideTitleCompanyDetail.SwitchToContentFrame();

                FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, TATSOTCChar, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = OTCTSAdhoc3;
                obj6.PDDDescription = pddChargeDesc;
                obj6.UseDefaultModify = false;
                obj6.PayeeName = PDDPayeeName;
                obj6.BuyerAtClosing = 44.00;
                obj6.BuyerBeforeClosing = 88.00;
                obj6.BuyerPaidbyOther = 66.7;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 23.00;
                obj6.SellerPaidBeforeClosing = 53.00;
                obj6.SellerPaidbyOthers = 66.00;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = TTEOTCChar;
                obj7.BuyerAtClosing = 243123876.22;
                obj7.BuyerBeforeClosing = 765423456.333;
                obj7.BuyerPaidbyOther = 1111111111.11;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.BuyerDoubleAsteriskChecked = true;
                obj7.SellerPaidAtClosing = 237654234.00;
                obj7.SellerPaidBeforeClosing = 134987353.99;
                obj7.SellerPaidbyOthers = 765432123.98;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = EditChargeDesc;
                obj8.SectionHOtherCosts = true;
                obj8.LoanEstimateUnrounded = 11.49;
                obj8.BuyerAtClosing = 6.68;
                obj8.BuyerBeforeClosing = 87.69;
                obj8.BuyerPaidbyOther = 1.89;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.SellerPaidAtClosing = 66.87;
                obj8.SellerPaidBeforeClosing = 6.44;
                obj8.SellerPaidbyOthers = 888.11;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj9 = new PDD();
                obj9.NewLoanTableId = TableID;
                obj9.ChargeDescription = OTCTSAdhoc2;
                obj9.SectionBdidnotShopFor = true;
                obj9.LoanEstimateRounded = 67.49;
                obj9.BuyerAtClosing = 62.87;
                obj9.BuyerBeforeClosing = 87.66;
                obj9.BuyerPaidbyOther = 44.77;
                obj9.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj9);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.B, TTEOTCChar, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(TTEOTCChar, "tblLoanCostSubSection_B", true);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.B, true, OTCTSAdhoc2, true, PayeeName);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = @"Verify the Charge some other Section.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, PayeeName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region HomeOwner Association

        #region Verify charges in Section H without entering values in PDD for HomeOwner Association.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD.")]
        public void Senario1_HOA_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string TFHOAACChar = "Transfer Fee";
                string ADHOAACChar = "Association Dues";
                string DFHOAACChar = "Document Fee";
                string CLHOAACChar = "Certification Letter";
                string HOAACAHOC1 = "Adhoc Charge1";
                string HOAACAHOC2 = "Adhoc Charge2";
                string HOAACAHOC3 = "Adhoc Charge3";
                string HOAACAHOC4 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Transfer Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE HOME OWNER ASSOCIATION INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeownerAssociation.GABcode.FASetText("247");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN HOME OWNER ASSOCIATION SCREEN";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: TFHOAACChar, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: ADHOAACChar, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: DFHOAACChar, buyerCharge: 66643.55, sellerCharge: 7854.54);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: CLHOAACChar, loanEstimate: 9764.88);

                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: HOAACAHOC1, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(HOAACAHOC1, FastDriver.HomeownerAssociation.AssociationChargesTable);
                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: HOAACAHOC2, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(HOAACAHOC2, FastDriver.HomeownerAssociation.AssociationChargesTable);
                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: HOAACAHOC3, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(HOAACAHOC3, FastDriver.HomeownerAssociation.AssociationChargesTable);
                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, chargeDescription: HOAACAHOC4, loanEstimate: 780890.58);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, HOAACAHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, HOAACAHOC1, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, HOAACAHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, HOAACAHOC2, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, HOAACAHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, HOAACAHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ADHOAACChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ADHOAACChar, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, DFHOAACChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, DFHOAACChar, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, TFHOAACChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, TFHOAACChar, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, HOAACAHOC3, true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, HOAACAHOC1, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, ADHOAACChar, false, 523423423.67, 4);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + DFHOAACChar;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, DFHOAACChar, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN HOMEOWNER ASSOCIATION";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeownerAssociation.AssociationChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(HOAACAHOC3) && i.Displayed).FAClick();
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.AssociationChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(HOAACAHOC1) && i.Displayed).FAClick();
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.AssociationChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(ADHOAACChar) && i.Displayed).FAClick();
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN HOME OWNER ASSOCIATION SCREEN";
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, TFHOAACChar, editDescription: SourceChargeDesc);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, ADHOAACChar, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, CLHOAACChar, buyerCharge: 8564.78);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, HOAACAHOC1, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, HOAACAHOC2, editDescription: SourceChargeDesc1);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, HOAACAHOC4, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();

                //FastDriver.TopFrame.SearchFileByFileNumber("5902");

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, HOAACAHOC1, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, HOAACAHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 76544.00);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, HOAACAHOC4, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, ADHOAACChar, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, CLHOAACChar, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Navigate to HOME OWNER ASSOCIATION Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeownerAssociation.GABcode.FASetText("BOA");
                FastDriver.HomeownerAssociation.Find.FAClick();
                payeeLabel1 = FastDriver.HomeownerAssociation.HOA_LenderName.Text.Clean();

                if (FastDriver.HomeownerAssociation.HOA_LenderName1.Displayed)
                    payeeLabel2 = FastDriver.HomeownerAssociation.HOA_LenderName1.Text.Clean();
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, HOAACAHOC1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, HOAACAHOC4, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, ADHOAACChar, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, CLHOAACChar, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for HomeOwner Association.

        [TestMethod]
        public void Senario2_HOA_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION C ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDTFHOAACChar = "Transfer Fee";
                string PDDADHOAACChar = "Adhoc Charge4";
                string PDDDFHOAACChar = "Document Fee";
                string PDDHOAACAHOC1 = "Adhoc Charge1";
                string PDDHOAACAHOC2 = "Adhoc Charge2";
                string PDDHOAACAHOC3 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "cgm_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE HOMEOWNER ASSOCIATION INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeownerAssociation.GABcode.FASetText("247");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = PDDTFHOAACChar;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = PDDDFHOAACChar;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, chargeDescription: PDDHOAACAHOC1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDHOAACAHOC1, FastDriver.HomeownerAssociation.ManagementCompanyChargesTable);
                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, chargeDescription: PDDHOAACAHOC2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDHOAACAHOC2, FastDriver.HomeownerAssociation.ManagementCompanyChargesTable);
                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, chargeDescription: PDDHOAACAHOC3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDHOAACAHOC3, FastDriver.HomeownerAssociation.ManagementCompanyChargesTable);
                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, chargeDescription: PDDADHOAACChar);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = PDDHOAACAHOC1;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = PDDHOAACAHOC2;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = PDDHOAACAHOC3;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = PDDADHOAACChar;
                obj6.LoanEstimateUnrounded = 4342342.56;
                obj6.BuyerAtClosing = 2114.76;
                obj6.BuyerBeforeClosing = 624230.35;
                obj6.BuyerPaidbyOther = 143452.96;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 1342.36;
                obj6.SellerPaidBeforeClosing = 42423.77;
                obj6.SellerPaidbyOthers = 23423.45;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDHOAACAHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDHOAACAHOC1, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDHOAACAHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PDDHOAACAHOC2, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDHOAACAHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDHOAACAHOC3, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDADHOAACChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDADHOAACChar, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDDFHOAACChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PDDDFHOAACChar, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDTFHOAACChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDDTFHOAACChar, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDHOAACAHOC1, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDADHOAACChar, false, 76534.67, 4);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDHOAACAHOC2, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PDDDFHOAACChar, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.HomeownerAssociation.ManagementCompanyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDHOAACAHOC1) && i.Displayed).FAClick();
                FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.ManagementCompanyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDADHOAACChar) && i.Displayed).FAClick();
                FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.ManagementCompanyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDHOAACAHOC2) && i.Displayed).FAClick();
                FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, PDDADHOAACChar, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = PDDHOAACAHOC3;
                obj7.PDDDescription = pddChargeDesc;
                obj7.UseDefaultModify = false;
                obj7.PayeeName = PDDPayeeName;
                obj7.BuyerAtClosing = 44.00;
                obj7.BuyerBeforeClosing = 88.00;
                obj7.BuyerPaidbyOther = 66.7;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.SellerPaidAtClosing = 23.00;
                obj7.SellerPaidBeforeClosing = 53.00;
                obj7.SellerPaidbyOthers = 66.00;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = PDDTFHOAACChar;
                obj8.BuyerAtClosing = 243123876.22;
                obj8.BuyerBeforeClosing = 765423456.333;
                obj8.BuyerPaidbyOther = 1111111111.11;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.BuyerDoubleAsteriskChecked = true;
                obj8.SellerPaidAtClosing = 237654234.00;
                obj8.SellerPaidBeforeClosing = 134987353.99;
                obj8.SellerPaidbyOthers = 765432123.98;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj9 = new PDD();
                obj9.NewLoanTableId = TableID;
                obj9.ChargeDescription = EditChargeDesc;
                obj9.SectionCDidShopFor = true;
                obj9.LoanEstimateUnrounded = 11.49;
                obj9.BuyerAtClosing = 6.68;
                obj9.BuyerBeforeClosing = 87.69;
                obj9.BuyerPaidbyOther = 1.89;
                obj9.BuyerPaidbyOtherPaymentMethod = "POC";
                obj9.SellerPaidAtClosing = 66.87;
                obj9.SellerPaidBeforeClosing = 6.44;
                obj9.SellerPaidbyOthers = 888.11;
                obj9.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj9);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj10 = new PDD();
                obj10.NewLoanTableId = TableID;
                obj10.ChargeDescription = PDDHOAACAHOC2;
                obj10.SectionBdidnotShopFor = true;
                obj10.LoanEstimateRounded = 67.49;
                obj10.BuyerAtClosing = 62.87;
                obj10.BuyerBeforeClosing = 87.66;
                obj10.BuyerPaidbyOther = 44.77;
                obj10.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj10);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDTFHOAACChar, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(PDDTFHOAACChar, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = @"Verify the Charge some other Section.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, PDDHOAACAHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, EditChargeDesc, true, PayeeName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Home Warranty

        #region Verify charges in Section H without entering values in PDD for Home Warranty.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD.")]
        public void Senario1_Home_Warranty_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string HWDesc = "Home Warranty";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string HMTableID = "CG1_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE HOME WARRANTY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("247");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN HOME OWNER ASSOCIATION SCREEN";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, chargeDescription: HWDesc, buyerCharge: 9234656189.99, sellerCharge: 7654322765.32, loanEstimate: 654312345.49);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H.";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, HWDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, HWDesc, BuyerAtClosing: 234656189.99, SellerAtClosing: 654322765.32, LoanEstimteUnroundedAmt: 654312345.49, LoanEstimateRoundedAmt: 654312345.00);
                
                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, HWDesc, true, 86543.89, 1);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, HWDesc, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN HOME WARRANTY SCREEN";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(EditChargeDesc) && i.Displayed).FAClick();
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$86,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$654,312,345.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual(EditChargeDesc, FastDriver.PaymentDetailsDlg.DESCRPTION.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN HOME WARRANTY SCREEN";
                FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, EditChargeDesc, editDescription: SourceChargeDesc);
                FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 0.00, loanEstimate: 53434.87);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);

                Reports.TestStep = "Navigate Home Warranty Screen Change GAb Name and Verify in CD";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("BOA");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                Payeename1 = FastDriver.HomeWarrantyDetail.GABname.Text.Clean();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Home Warranty.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR HOME WARRANTY SCREEN")]
        public void Senario2_Home_Warranty_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR HOME WARRANTY SCREEN";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDHMDesc = "Home Warranty";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD", PayeeNameinPDD;
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "CG1_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE HOME WARRANTY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("247");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = PDDHMDesc;
                obj.LoanEstimateUnrounded = 4342342.56;
                obj.BuyerAtClosing = 2114.76;
                obj.BuyerBeforeClosing = 624230.35;
                obj.BuyerPaidbyOther = 143452.96;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 1342.36;
                obj.SellerPaidBeforeClosing = 42423.77;
                obj.SellerPaidbyOthers = 23423.45;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDHMDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDHMDesc, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                
                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDHMDesc, true, 67654.49, 1);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PDDHMDesc, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN HOME WARRANTY SCREEN";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(EditChargeDesc) && i.Displayed).FAClick();
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$67,654.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$4,342,342.56", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, EditChargeDesc, loanEstimate: 4342342.56);

                Reports.TestStep = "MODIFY THE PAYEENAME  IN PDD AND VERIFY IN CD SCREEN ";
                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = EditChargeDesc;
                obj2.PDDDescription = pddChargeDesc;
                obj2.UseDefaultModify = false;
                obj2.PayeeName = PDDPayeeName;
                obj2.LoanEstimateUnrounded = 65432.51;
                obj2.BuyerAtClosing = 123876.22;
                obj2.BuyerBeforeClosing = 5423456.333;
                obj2.BuyerPaidbyOther = 3244566.49;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 7654234.55;
                obj2.SellerPaidBeforeClosing = 987353.99;
                obj2.SellerPaidbyOthers = 5432123.98;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR CHARGE IN CD. ALSO VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 123876.22, BuyerBeforeClosing: 5423456.33, SellerAtClosing: 7654234.55, SellerBeforeClosing: 987353.99, BuyerPaidbyOther: 3244566.49, LoanEstimteUnroundedAmt: 65432.51, LoanEstimateRoundedAmt: 65433.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE ROUNDED AND VERIFY THE BROKEN LINK FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, pddChargeDesc, true, 87654.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, pddChargeDesc, false, 276.49, 1);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN HOME WARRANTY  SCREEN AND CHANGE THE GAB CODE";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("BOA");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(pddChargeDesc) && i.Displayed).FAClick();
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$276.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$276.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$6543.99");
                Keyboard.SendKeys(FAKeys.TabAway);
                PayeeNameinPDD = FastDriver.PaymentDetailsDlg.PayeeName.GetAttribute("value").Clean();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PayeeNameinPDD);
                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.H, pddChargeDesc, "Verify", true, 6544.00M, false);
                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.H, pddChargeDesc, "Verify", false, 276.49M, false);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion 

        #endregion

        #region Inspection Repair

        #region Verify charges in Section H without entering values in PDD for Inspection Repair-Pest.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-PEST SCREEN.")]
        public void Senario1_IR_PEST_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-PEST SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PIPESTChar = "Pest Inspection";
                string PPPESTChar = "Pest Repair";
                string PESTADHOC5 = "Adhoc Charge5";
                string PESTADHOC6 = "Adhoc Charge6";
                string PESTADHOC1 = "Adhoc Charge1";
                string PESTADHOC2 = "Adhoc Charge2";
                string PESTADHOC3 = "Adhoc Charge3";
                string PESTADHOC4 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Transfer Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string PestTableID = "CG_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE INSPECTION REPAIR-PEST INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.InspectionRepairPest.GABcode.FASetText("247");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN INSPECTION REPAI-PEST SCREEN";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PIPESTChar, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PPPESTChar, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);

                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PESTADHOC1, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PESTADHOC1, FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PESTADHOC2, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PESTADHOC2, FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PESTADHOC3, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PESTADHOC3, FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PESTADHOC4, loanEstimate: 780890.58);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PESTADHOC4, FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PESTADHOC5, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PESTADHOC5, FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PESTADHOC6, loanEstimate: 9764.88);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PESTADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PESTADHOC1, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PESTADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PESTADHOC2, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PESTADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PESTADHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PPPESTChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PPPESTChar, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PESTADHOC5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PESTADHOC5, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PIPESTChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PIPESTChar, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PESTADHOC3, true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PESTADHOC1, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PPPESTChar, false, 523423423.67, 6);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + PESTADHOC5;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PESTADHOC5, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN HOMEOWNER ASSOCIATION";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PESTADHOC3) && i.Displayed).FAClick();
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PESTADHOC1) && i.Displayed).FAClick();
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PPPESTChar) && i.Displayed).FAClick();
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN INSPECTION REPAIR-PEST SCREEN";
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, PIPESTChar, editDescription: SourceChargeDesc);
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, PPPESTChar, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, PESTADHOC6, buyerCharge: 8564.78);
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, PESTADHOC1, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, PESTADHOC2, editDescription: SourceChargeDesc1);
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, PESTADHOC4, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();
/*
                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PESTADHOC1, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PESTADHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 76544.00);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PESTADHOC4, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PPPESTChar, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PESTADHOC6, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Navigate to HOME OWNER ASSOCIATION Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.InspectionRepairPest.GABcode.FASetText("BOA");
                FastDriver.InspectionRepairPest.Find.FAClick();
                payeeLabel1 = FastDriver.InspectionRepairPest.INSP_Pest_LenderName.Text.Clean();
                payeeLabel2 = FastDriver.InspectionRepairPest.INSP_Pest_LenderName1.Displayed ? FastDriver.InspectionRepairPest.INSP_Pest_LenderName1.Text.Clean() : string.Empty;
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PESTADHOC1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PESTADHOC4, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PPPESTChar, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PESTADHOC6, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);
*/
                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Inspection Repair-Pest.

        [TestMethod]
        public void Senario2_IR_PEST_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION C ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDPIPESTChar = "Pest Inspection";
                string PDDPRPESTChar = "Pest Repair";
                string PDDPESTADHOC4 = "Adhoc Charge4";
                string PDDPESTADHOC1 = "Adhoc Charge1";
                string PDDPESTADHOC2 = "Adhoc Charge2";
                string PDDPESTADHOC3 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "CG_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE INSPECTION REPAIR-PEST INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.InspectionRepairPest.GABcode.FASetText("247");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = PDDPIPESTChar;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj1 = new PDD();
                obj1.NewLoanTableId = TableID;
                obj1.ChargeDescription = PDDPRPESTChar;
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PDDPESTADHOC1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDPESTADHOC1, FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PDDPESTADHOC2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDPESTADHOC2, FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PDDPESTADHOC3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDPESTADHOC3, FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                FastDriver.InspectionRepairPest.AddCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, chargeDescription: PDDPESTADHOC4);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = PDDPESTADHOC1;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = PDDPESTADHOC2;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = PDDPESTADHOC3;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = PDDPESTADHOC4;
                obj6.LoanEstimateUnrounded = 11.49;
                obj6.BuyerAtClosing = 6.68;
                obj6.BuyerBeforeClosing = 87.69;
                obj6.BuyerPaidbyOther = 1.89;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 66.87;
                obj6.SellerPaidBeforeClosing = 6.44;
                obj6.SellerPaidbyOthers = 888.11;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDPESTADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDPESTADHOC1, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDPESTADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PDDPESTADHOC2, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDPESTADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDPESTADHOC3, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDPRPESTChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDDPRPESTChar, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDPESTADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDPESTADHOC4, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDPIPESTChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PDDPIPESTChar, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDPESTADHOC1, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDPRPESTChar, false, 76534.67, 6);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDPESTADHOC2, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PDDPESTADHOC4, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDPESTADHOC1) && i.Displayed).FAClick();
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDPRPESTChar) && i.Displayed).FAClick();
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDPESTADHOC2) && i.Displayed).FAClick();
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                FastDriver.InspectionRepairPest.UpdateCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, PDDPRPESTChar, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = PDDPESTADHOC3;
                obj7.PDDDescription = pddChargeDesc;
                obj7.UseDefaultModify = false;
                obj7.PayeeName = PDDPayeeName;
                obj7.BuyerAtClosing = 44.00;
                obj7.BuyerBeforeClosing = 88.00;
                obj7.BuyerPaidbyOther = 66.7;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.SellerPaidAtClosing = 23.00;
                obj7.SellerPaidBeforeClosing = 53.00;
                obj7.SellerPaidbyOthers = 66.00;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = PDDPIPESTChar;
                obj8.BuyerAtClosing = 243123876.22;
                obj8.BuyerBeforeClosing = 765423456.333;
                obj8.BuyerPaidbyOther = 1111111111.11;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.BuyerDoubleAsteriskChecked = true;
                obj8.SellerPaidAtClosing = 237654234.00;
                obj8.SellerPaidBeforeClosing = 134987353.99;
                obj8.SellerPaidbyOthers = 765432123.98;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj9 = new PDD();
                obj9.NewLoanTableId = TableID;
                obj9.ChargeDescription = EditChargeDesc;
                obj9.SectionCDidShopFor = true;
                obj9.LoanEstimateUnrounded = 11.49;
                obj9.BuyerAtClosing = 6.68;
                obj9.BuyerBeforeClosing = 87.69;
                obj9.BuyerPaidbyOther = 1.89;
                obj9.BuyerPaidbyOtherPaymentMethod = "POC";
                obj9.SellerPaidAtClosing = 66.87;
                obj9.SellerPaidBeforeClosing = 6.44;
                obj9.SellerPaidbyOthers = 888.11;
                obj9.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj9);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj10 = new PDD();
                obj10.NewLoanTableId = TableID;
                obj10.ChargeDescription = PDDPESTADHOC2;
                obj10.SectionBdidnotShopFor = true;
                obj10.LoanEstimateRounded = 67.49;
                obj10.BuyerAtClosing = 62.87;
                obj10.BuyerBeforeClosing = 87.66;
                obj10.BuyerPaidbyOther = 44.77;
                obj10.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj10);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDPIPESTChar, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(PDDPIPESTChar, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = @"Verify the Charge some other Section.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, PDDPESTADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, EditChargeDesc, true, PayeeName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H without entering values in PDD for Inspection Repair-Septic.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-SEPTIC SCREEN.")]
        public void Senario1_IR_SEPTIC_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-SEPTIC SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string SISEPTICChar = "Septic Inspection";
                string SPSEPTICChar = "Septic Repair";
                string SEPTICADHOC5 = "Adhoc Charge5";
                string SEPTICADHOC6 = "Adhoc Charge6";
                string SEPTICADHOC1 = "Adhoc Charge1";
                string SEPTICADHOC2 = "Adhoc Charge2";
                string SEPTICADHOC3 = "Adhoc Charge3";
                string SEPTICADHOC4 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Transfer Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string PestTableID = "CG_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE INSPECTION REPAIR-SEPTIC INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.InspectionRepairSeptic.GABcode.FASetText("247");
                FastDriver.InspectionRepairSeptic.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN INSPECTION REPAI-PEST SCREEN";
                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: SISEPTICChar, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: SPSEPTICChar, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);

                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: SEPTICADHOC1, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SEPTICADHOC1, FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable);
                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: SEPTICADHOC2, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SEPTICADHOC2, FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable);
                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: SEPTICADHOC3, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SEPTICADHOC3, FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable);
                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: SEPTICADHOC4, loanEstimate: 780890.58);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SEPTICADHOC4, FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable);
                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: SEPTICADHOC5, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SEPTICADHOC5, FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable);
                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: SEPTICADHOC6, loanEstimate: 9764.88);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SEPTICADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, SEPTICADHOC1, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SEPTICADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, SEPTICADHOC2, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SEPTICADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, SEPTICADHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SPSEPTICChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, SPSEPTICChar, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SEPTICADHOC5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, SEPTICADHOC5, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SISEPTICChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SISEPTICChar, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, SEPTICADHOC3, true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, SEPTICADHOC1, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, SPSEPTICChar, false, 523423423.67, 6);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + SEPTICADHOC5;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, SEPTICADHOC5, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN REPAIR SEPTIC";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(SEPTICADHOC3) && i.Displayed).FAClick();
                FastDriver.InspectionRepairSeptic.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();

                FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(SEPTICADHOC1) && i.Displayed).FAClick();
                FastDriver.InspectionRepairSeptic.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();

                FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(SPSEPTICChar) && i.Displayed).FAClick();
                FastDriver.InspectionRepairSeptic.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN INSPECTION REPAIR-SEPTIC SCREEN";
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, SISEPTICChar, editDescription: SourceChargeDesc);
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, SPSEPTICChar, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, SEPTICADHOC6, buyerCharge: 8564.78);
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, SEPTICADHOC1, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, SEPTICADHOC2, editDescription: SourceChargeDesc1);
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, SEPTICADHOC4, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, SEPTICADHOC1, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, SEPTICADHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 76544.00);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, SEPTICADHOC4, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, SPSEPTICChar, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, SEPTICADHOC6, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Navigate to HOME OWNER ASSOCIATION Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.InspectionRepairSeptic.GABcode.FASetText("BOA");
                FastDriver.InspectionRepairSeptic.Find.FAClick();
                payeeLabel1 = FastDriver.InspectionRepairSeptic.INSP_Septic_LenderName.Text.Clean();
                payeeLabel2 = FastDriver.InspectionRepairSeptic.INSP_Septic_LenderName1.Displayed ? FastDriver.InspectionRepairPest.INSP_Pest_LenderName1.Text.Clean() : string.Empty;
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SEPTICADHOC1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SEPTICADHOC4, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SPSEPTICChar, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SEPTICADHOC6, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);
                
                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Inspection Repair-Septic.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-SEPTIC SCREEN")]
        public void Senario2_IR_SEPTIC_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-SEPTIC SCREEN";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDSISEPTICChar = "Septic Inspection";
                string PDDSRSEPTICChar = "Septic Repair";
                string PDDSEPTICADHOC4 = "Adhoc Charge4";
                string PDDSEPTICADHOC1 = "Adhoc Charge1";
                string PDDSEPTICADHOC2 = "Adhoc Charge2";
                string PDDSEPTICADHOC3 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "CG_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE INSPECTION REPAIR-SEPTIC INSTANCE AND VERIFY THE SAME";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.InspectionRepairSeptic.GABcode.FASetText("247");
                FastDriver.InspectionRepairSeptic.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = PDDSISEPTICChar;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj1 = new PDD();
                obj1.NewLoanTableId = TableID;
                obj1.ChargeDescription = PDDSRSEPTICChar;
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();
                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: PDDSEPTICADHOC1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDSEPTICADHOC1, FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable);
                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: PDDSEPTICADHOC2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDSEPTICADHOC2, FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable);
                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: PDDSEPTICADHOC3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDSEPTICADHOC3, FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable);
                FastDriver.InspectionRepairSeptic.AddCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, chargeDescription: PDDSEPTICADHOC4);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = PDDSEPTICADHOC1;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = PDDSEPTICADHOC2;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = PDDSEPTICADHOC3;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = PDDSEPTICADHOC4;
                obj6.LoanEstimateUnrounded = 11.49;
                obj6.BuyerAtClosing = 6.68;
                obj6.BuyerBeforeClosing = 87.69;
                obj6.BuyerPaidbyOther = 1.89;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 66.87;
                obj6.SellerPaidBeforeClosing = 6.44;
                obj6.SellerPaidbyOthers = 888.11;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDSEPTICADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDSEPTICADHOC1, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDSEPTICADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PDDSEPTICADHOC2, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDSEPTICADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDSEPTICADHOC3, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDSRSEPTICChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDDSRSEPTICChar, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDSEPTICADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDSEPTICADHOC4, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDSISEPTICChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PDDSISEPTICChar, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDSEPTICADHOC1, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDSRSEPTICChar, false, 76534.67, 6);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDSEPTICADHOC2, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PDDSEPTICADHOC4, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDSEPTICADHOC1) && i.Displayed).FAClick();
                FastDriver.InspectionRepairSeptic.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();

                FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDSRSEPTICChar) && i.Displayed).FAClick();
                FastDriver.InspectionRepairSeptic.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();

                FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDSEPTICADHOC2) && i.Displayed).FAClick();
                FastDriver.InspectionRepairSeptic.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairSeptic.SwitchToContentFrame();

                FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, PDDSRSEPTICChar, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = PDDSEPTICADHOC3;
                obj7.PDDDescription = pddChargeDesc;
                obj7.UseDefaultModify = false;
                obj7.PayeeName = PDDPayeeName;
                obj7.BuyerAtClosing = 44.00;
                obj7.BuyerBeforeClosing = 88.00;
                obj7.BuyerPaidbyOther = 66.7;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.SellerPaidAtClosing = 23.00;
                obj7.SellerPaidBeforeClosing = 53.00;
                obj7.SellerPaidbyOthers = 66.00;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = PDDSISEPTICChar;
                obj8.BuyerAtClosing = 243123876.22;
                obj8.BuyerBeforeClosing = 765423456.333;
                obj8.BuyerPaidbyOther = 1111111111.11;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.BuyerDoubleAsteriskChecked = true;
                obj8.SellerPaidAtClosing = 237654234.00;
                obj8.SellerPaidBeforeClosing = 134987353.99;
                obj8.SellerPaidbyOthers = 765432123.98;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj9 = new PDD();
                obj9.NewLoanTableId = TableID;
                obj9.ChargeDescription = EditChargeDesc;
                obj9.SectionCDidShopFor = true;
                obj9.LoanEstimateUnrounded = 11.49;
                obj9.BuyerAtClosing = 6.68;
                obj9.BuyerBeforeClosing = 87.69;
                obj9.BuyerPaidbyOther = 1.89;
                obj9.BuyerPaidbyOtherPaymentMethod = "POC";
                obj9.SellerPaidAtClosing = 66.87;
                obj9.SellerPaidBeforeClosing = 6.44;
                obj9.SellerPaidbyOthers = 888.11;
                obj9.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj9);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj10 = new PDD();
                obj10.NewLoanTableId = TableID;
                obj10.ChargeDescription = PDDSEPTICADHOC2;
                obj10.SectionBdidnotShopFor = true;
                obj10.LoanEstimateRounded = 67.49;
                obj10.BuyerAtClosing = 62.87;
                obj10.BuyerBeforeClosing = 87.66;
                obj10.BuyerPaidbyOther = 44.77;
                obj10.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj10);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDSISEPTICChar, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(PDDSISEPTICChar, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = @"Verify the Charge some other Section.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, PDDSEPTICADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, EditChargeDesc, true, PayeeName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H without entering values in PDD for Inspection Repair-Other.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-OTHER SCREEN.")]
        public void Scenario1_IR_OTHER_CD_H()
        {
            Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-OTHER SCREEN.";

            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            string OIOTHERChar = "Other Inspection";
            string OROTHERChar = "Other Repair";
            string OTHERADHOC5 = "Adhoc Charge5";
            string OTHERADHOC6 = "Adhoc Charge6";
            string OTHERADHOC1 = "Adhoc Charge1";
            string OTHERADHOC2 = "Adhoc Charge2";
            string OTHERADHOC3 = "Adhoc Charge3";
            string OTHERADHOC4 = "Adhoc Charge4";
            string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
            string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
            string EditChargeDesc = "Modified Charge Description in CD";
            string SourceChargeDesc = "Verify source Transfer Fee";
            string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
            string PestTableID = "CG_dcs";
            #endregion

            #region GUI interaction

            Reports.TestStep = "Login to file side";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            Playback.Wait(5000);

            Reports.TestStep = "Create a basic file";
            string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

            Reports.TestStep = "CREATE INSPECTION REPAIR-OTHER INSTANCE AND VERIFY THE SAME.";
            FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.InspectionRepairOther.GABcode.FASetText("247");
            FastDriver.InspectionRepairOther.Find.FAClick();
            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);

            Reports.TestStep = "ENTER THE VALUES IN INSPECTION REPAI-PEST SCREEN";
            FastDriver.InspectionRepairOther.SwitchToContentFrame();
            if (chargeAvailability(PestTableID, OIOTHERChar))
            {
                FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OIOTHERChar, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
            }
            else
            {
                FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OIOTHERChar, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(OIOTHERChar, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
            }

            if (chargeAvailability(PestTableID, OROTHERChar))
            {
                FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OROTHERChar, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
            }
            else
            {
                FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OROTHERChar, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(OROTHERChar, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
            }

            FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OTHERADHOC1, buyerCharge: 42342.87);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            verifyEmptyLine(OTHERADHOC1, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
            FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OTHERADHOC2, sellerCharge: 978888.57);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            verifyEmptyLine(OTHERADHOC2, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
            FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OTHERADHOC3, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
            Keyboard.SendKeys(FAKeys.TabAway);
            verifyEmptyLine(OTHERADHOC3, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
            FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OTHERADHOC4, loanEstimate: 780890.58);
            Keyboard.SendKeys(FAKeys.TabAway);
            verifyEmptyLine(OTHERADHOC4, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
            FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OTHERADHOC5, buyerCharge: 66643.55, sellerCharge: 7854.54);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            verifyEmptyLine(OTHERADHOC5, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
            FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: OTHERADHOC6, loanEstimate: 9764.88);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(1500);
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            Playback.Wait(250);

            Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
            FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

            Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
            FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, OTHERADHOC1, true, PayeeName);
            FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, OTHERADHOC1, BuyerAtClosing: 42342.87);
            FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, OTHERADHOC2, true, PayeeName);
            FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, OTHERADHOC2, SellerAtClosing: 978888.57);
            FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, OTHERADHOC3, true, PayeeName);
            FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, OTHERADHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
            FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, OROTHERChar, true, PayeeName);
            FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, OROTHERChar, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
            FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, OTHERADHOC5, true, PayeeName);
            FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, OTHERADHOC5, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);
            FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, OIOTHERChar, true, PayeeName);
            FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, OIOTHERChar, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);

            Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
            FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, OTHERADHOC3, true, 76543.89, 3);
            FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, OTHERADHOC1, false, 85432.34, 1);
            FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, OROTHERChar, false, 523423423.67, 6);

            Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + OTHERADHOC5;
            FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, OTHERADHOC5, EditChargeDesc);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "VERIFY THE MODIFIED VALUES IN HOMEOWNER ASSOCIATION";
            FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.InspectionRepairOther.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                .FirstOrDefault(i => i.GetAttribute("value").Contains(OTHERADHOC3) && i.Displayed).FAClick();
            FastDriver.InspectionRepairOther.PaymentDetails.FAClick();
            Playback.Wait(250);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
            FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
            FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
            Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
            Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(250);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.InspectionRepairOther.SwitchToContentFrame();

            FastDriver.InspectionRepairOther.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                .FirstOrDefault(i => i.GetAttribute("value").Contains(OTHERADHOC1) && i.Displayed).FAClick();
            FastDriver.InspectionRepairOther.PaymentDetails.FAClick();
            Playback.Wait(250);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
            FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
            FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
            Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
            Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
            Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(250);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.InspectionRepairOther.SwitchToContentFrame();

            FastDriver.InspectionRepairOther.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                .FirstOrDefault(i => i.GetAttribute("value").Contains(OROTHERChar) && i.Displayed).FAClick();
            FastDriver.InspectionRepairOther.PaymentDetails.FAClick();
            Playback.Wait(250);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
            FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
            FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
            Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
            Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
            Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(250);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.InspectionRepairOther.SwitchToContentFrame();

            //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

            Reports.TestStep = "MODIFY THE VALUES IN INSPECTION REPAIR-PEST SCREEN";
            FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, OIOTHERChar, editDescription: SourceChargeDesc);
            FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
            FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, OROTHERChar, buyerCharge: 68598.00, sellerCharge: 0.00);
            FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
            FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, OTHERADHOC6, buyerCharge: 8564.78);
            FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, OTHERADHOC1, buyerCharge: 93653.76, sellerCharge: 24734.56);
            FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, OTHERADHOC2, editDescription: SourceChargeDesc1);
            FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
            FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, OTHERADHOC4, buyerCharge: 5233.54);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(1500);
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            Playback.Wait(250);

            Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
            FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

            FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, OTHERADHOC1, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
            FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, OTHERADHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 76544.00);
            FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, OTHERADHOC4, BuyerAtClosing: 5233.54);
            FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, OROTHERChar, BuyerAtClosing: 68598.00);
            FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, OTHERADHOC6, BuyerAtClosing: 8564.78);
            FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
            FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
            FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
            FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
            FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

            Reports.TestStep = "Navigate to HOME OWNER ASSOCIATION Screen";
            FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.InspectionRepairOther.GABcode.FASetText("BOA");
            FastDriver.InspectionRepairOther.Find.FAClick();
            payeeLabel1 = FastDriver.InspectionRepairOther.INSP_Others_LenderName.Text.Clean();
            payeeLabel2 = FastDriver.InspectionRepairOther.INSP_Others_LenderName1.Displayed ? FastDriver.InspectionRepairOther.INSP_Others_LenderName1.Text.Clean() : string.Empty;
            Payeename1 = payeeLabel1 + " " + payeeLabel2;
            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);

            Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(1500);
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            Playback.Wait(250);

            FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, OTHERADHOC1, true, Payeename1);
            FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, OTHERADHOC4, true, Payeename1);
            FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, OROTHERChar, true, Payeename1);
            FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
            FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
            FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, OTHERADHOC6, true, Payeename1);
            FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

            #endregion GUI interaction

        }
        
        #endregion 

        #region Verify charges in Section H with entering values in PDD for Inspection Repair-Other.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-OTHER SCREEN ")]
        public void Senario2_IR_OTHER_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR INSPECTION REPAIR-OTHER SCREEN ";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDOIOTHERChar = "Other Inspection";
                string PDD0ROTHERChar = "Other Repair";
                string PDDOTHERADHOC4 = "Adhoc Charge4";
                string PDDOTHERADHOC1 = "Adhoc Charge1";
                string PDDOTHERADHOC2 = "Adhoc Charge2";
                string PDDOTHERADHOC3 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "CG_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE INSPECTION REPAIR-OTHER INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.InspectionRepairOther.GABcode.FASetText("247");
                FastDriver.InspectionRepairOther.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.InspectionRepairOther.SwitchToContentFrame();
                if (!chargeAvailability(TableID, PDDOIOTHERChar))
                {
                    FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: PDDOIOTHERChar);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                } 
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = PDDOIOTHERChar;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InspectionRepairOther.SwitchToContentFrame();
                if (!chargeAvailability(TableID, PDD0ROTHERChar))
                {
                    FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: PDD0ROTHERChar);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }
                PDD obj1 = new PDD();
                obj1.NewLoanTableId = TableID;
                obj1.ChargeDescription = PDD0ROTHERChar;
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InspectionRepairOther.SwitchToContentFrame();
                FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: PDDOTHERADHOC1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDOTHERADHOC1, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
                FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: PDDOTHERADHOC2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDOTHERADHOC2, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
                FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: PDDOTHERADHOC3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDOTHERADHOC3, FastDriver.InspectionRepairOther.InspectionRepairChargesTable);
                FastDriver.InspectionRepairOther.AddCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, chargeDescription: PDDOTHERADHOC4);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = PDDOTHERADHOC1;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = PDDOTHERADHOC2;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = PDDOTHERADHOC3;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = PDDOTHERADHOC4;
                obj6.LoanEstimateUnrounded = 11.49;
                obj6.BuyerAtClosing = 6.68;
                obj6.BuyerBeforeClosing = 87.69;
                obj6.BuyerPaidbyOther = 1.89;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 66.87;
                obj6.SellerPaidBeforeClosing = 6.44;
                obj6.SellerPaidbyOthers = 888.11;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDOTHERADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDOTHERADHOC1, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDOTHERADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PDDOTHERADHOC2, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDOTHERADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDOTHERADHOC3, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDD0ROTHERChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDD0ROTHERChar, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDOTHERADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDOTHERADHOC4, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDOIOTHERChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PDDOIOTHERChar, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDOTHERADHOC1, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDD0ROTHERChar, false, 76534.67, 6);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDOTHERADHOC2, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PDDOTHERADHOC4, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDOTHERADHOC1) && i.Displayed).FAClick();
                FastDriver.InspectionRepairOther.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairOther.SwitchToContentFrame();

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDD0ROTHERChar) && i.Displayed).FAClick();
                FastDriver.InspectionRepairOther.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairOther.SwitchToContentFrame();

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDOTHERADHOC2) && i.Displayed).FAClick();
                FastDriver.InspectionRepairOther.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairOther.SwitchToContentFrame();

                FastDriver.InspectionRepairOther.UpdateCharge(FastDriver.InspectionRepairOther.InspectionRepairChargesTable, PDD0ROTHERChar, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = PDDOTHERADHOC3;
                obj7.PDDDescription = pddChargeDesc;
                obj7.UseDefaultModify = false;
                obj7.PayeeName = PDDPayeeName;
                obj7.BuyerAtClosing = 44.00;
                obj7.BuyerBeforeClosing = 88.00;
                obj7.BuyerPaidbyOther = 66.7;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.SellerPaidAtClosing = 23.00;
                obj7.SellerPaidBeforeClosing = 53.00;
                obj7.SellerPaidbyOthers = 66.00;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = PDDOIOTHERChar;
                obj8.BuyerAtClosing = 243123876.22;
                obj8.BuyerBeforeClosing = 765423456.333;
                obj8.BuyerPaidbyOther = 1111111111.11;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.BuyerDoubleAsteriskChecked = true;
                obj8.SellerPaidAtClosing = 237654234.00;
                obj8.SellerPaidBeforeClosing = 134987353.99;
                obj8.SellerPaidbyOthers = 765432123.98;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj9 = new PDD();
                obj9.NewLoanTableId = TableID;
                obj9.ChargeDescription = EditChargeDesc;
                obj9.SectionCDidShopFor = true;
                obj9.LoanEstimateUnrounded = 11.49;
                obj9.BuyerAtClosing = 6.68;
                obj9.BuyerBeforeClosing = 87.69;
                obj9.BuyerPaidbyOther = 1.89;
                obj9.BuyerPaidbyOtherPaymentMethod = "POC";
                obj9.SellerPaidAtClosing = 66.87;
                obj9.SellerPaidBeforeClosing = 6.44;
                obj9.SellerPaidbyOthers = 888.11;
                obj9.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj9);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj10 = new PDD();
                obj10.NewLoanTableId = TableID;
                obj10.ChargeDescription = PDDOTHERADHOC2;
                obj10.SectionBdidnotShopFor = true;
                obj10.LoanEstimateRounded = 67.49;
                obj10.BuyerAtClosing = 62.87;
                obj10.BuyerBeforeClosing = 87.66;
                obj10.BuyerPaidbyOther = 44.77;
                obj10.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj10);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDOIOTHERChar, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(PDDOIOTHERChar, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = @"Verify the Charge some other Section.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, PDDOTHERADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, EditChargeDesc, true, PayeeName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Lease

        #region Verify charges in Section H without entering values in PDD for Lease.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR LEASE SCREEN.")]
        public void Senario1_Lease_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR LEASE SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string RLPDLEASEChar = "Rent/Lease Payment Due";
                string LEASEADHOC1 = "Adhoc Charge1";
                string LEASEADHOC2 = "Adhoc Charge2";
                string LEASEADHOC3 = "Adhoc Charge3";
                string LEASEADHOC4 = "Adhoc Charge4";
                string LEASEADHOC5 = "Adhoc Charge5";
                string LEASEADHOC6 = "Adhoc Charge6";
                string LEASEADHOC7 = "Adhoc Charge7";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Appraisal Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string LEASETABLEID = "cg_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE LEASE INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.LeaseDetail.GABcode.FASetText("247");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN LEASE SCREEN";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: RLPDLEASEChar, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);

                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: LEASEADHOC1, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(LEASEADHOC1, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: LEASEADHOC2, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(LEASEADHOC2, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: LEASEADHOC3, loanEstimate: 9764.88);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(LEASEADHOC3, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: LEASEADHOC4, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(LEASEADHOC4, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: LEASEADHOC5, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(LEASEADHOC5, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: LEASEADHOC6, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(LEASEADHOC6, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: LEASEADHOC7, loanEstimate: 780890.58);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, LEASEADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, LEASEADHOC4, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, LEASEADHOC5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, LEASEADHOC5, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, LEASEADHOC6, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, LEASEADHOC6, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, RLPDLEASEChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, RLPDLEASEChar, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, LEASEADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, LEASEADHOC1, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, LEASEADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, LEASEADHOC2, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, LEASEADHOC6, true, 76543.89, 5);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, LEASEADHOC4, false, 85432.34, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, LEASEADHOC1, false, 523423423.67, 1);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + LEASEADHOC2;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, LEASEADHOC2, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN HOMEOWNER ASSOCIATION";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.LeaseDetail.LeaseChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(LEASEADHOC6) && i.Displayed).FAClick();
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.LeaseChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(LEASEADHOC4) && i.Displayed).FAClick();
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.LeaseChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(LEASEADHOC1) && i.Displayed).FAClick();
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN INSPECTION REPAIR-PEST SCREEN";
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, RLPDLEASEChar, editDescription: SourceChargeDesc);
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, LEASEADHOC1, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, LEASEADHOC3, buyerCharge: 8564.78);
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, LEASEADHOC4, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, LEASEADHOC5, editDescription: SourceChargeDesc1);
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, LEASEADHOC7, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();
 
                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, LEASEADHOC4, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, LEASEADHOC7, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, LEASEADHOC1, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, LEASEADHOC3, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Navigate to HOME OWNER ASSOCIATION Screen";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.LeaseDetail.GABcode.FASetText("BOA");
                FastDriver.LeaseDetail.Find.FAClick();
                payeeLabel1 = FastDriver.LeaseDetail.LeaseInformationName.Text.Clean();
                payeeLabel2 = FastDriver.LeaseDetail.LeaseInformationName1.Displayed ? FastDriver.InspectionRepairPest.INSP_Pest_LenderName1.Text.Clean() : string.Empty;
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, LEASEADHOC4, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, LEASEADHOC7, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, LEASEADHOC1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, LEASEADHOC3, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);
               
                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Lease.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR LEASE SCREEN")]
        public void Senario2_Lease_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR LEASE SCREEN";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDLERLPDChar = "Rent/Lease Payment Due";
                string PDDLEADHOC1 = "Adhoc Charge1";
                string PDDLEADHOC2 = "Adhoc Charge2";
                string PDDLEADHOC3 = "Adhoc Charge3";
                string PDDLEADHOC4 = "Adhoc Charge4";
                string PDDLEADHOC5 = "Adhoc Charge5";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "cg_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE LEASE INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.LeaseDetail.GABcode.FASetText("247");
                FastDriver.LeaseDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: PDDLEADHOC1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDLEADHOC1, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: PDDLEADHOC2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDLEADHOC2, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: PDDLEADHOC3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDLEADHOC3, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: PDDLEADHOC4);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDLEADHOC4, FastDriver.LeaseDetail.LeaseChargesTable);
                FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, chargeDescription: PDDLEADHOC5);

                Reports.TestStep = "ENTER THE VALUES FOR ADHOC CHARGES IN  LEASE SCREEN";
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = PDDLERLPDChar;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                obj = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj1 = new PDD();
                obj1.NewLoanTableId = TableID;
                obj1.ChargeDescription = PDDLEADHOC1;
                obj1.LoanEstimateUnrounded = 4342342.56;
                obj1.BuyerAtClosing = 2114.76;
                obj1.BuyerBeforeClosing = 624230.35;
                obj1.BuyerPaidbyOther = 143452.96;
                obj1.BuyerPaidbyOtherPaymentMethod = "POC";
                obj1.SellerPaidAtClosing = 1342.36;
                obj1.SellerPaidBeforeClosing = 42423.77;
                obj1.SellerPaidbyOthers = 23423.45;
                obj1.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj1);
                obj1 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = PDDLEADHOC2;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                obj2 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = PDDLEADHOC3;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                obj3 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = PDDLEADHOC4;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                obj4 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = PDDLEADHOC5;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                obj5 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDLEADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDLEADHOC3, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDLEADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDLEADHOC4, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDLEADHOC5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PDDLEADHOC5, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDLEADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDLEADHOC1, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDLEADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PDDLEADHOC2, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, PDDLERLPDChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDDLERLPDChar, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDLEADHOC3, true, 2786.51, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDLEADHOC1, false, 76534.67, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDLEADHOC4, false, 456.99, 4);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PDDLEADHOC2, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.LeaseDetail.LeaseChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDLEADHOC3) && i.Displayed).FAClick();
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.LeaseChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDLEADHOC1) && i.Displayed).FAClick();
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.LeaseChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDLEADHOC4) && i.Displayed).FAClick();
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, PDDLEADHOC1, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = PDDLEADHOC5;
                obj6.PDDDescription = pddChargeDesc;
                obj6.UseDefaultModify = false;
                obj6.PayeeName = PDDPayeeName;
                obj6.BuyerAtClosing = 44.00;
                obj6.BuyerBeforeClosing = 88.00;
                obj6.BuyerPaidbyOther = 66.7;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 23.00;
                obj6.SellerPaidBeforeClosing = 53.00;
                obj6.SellerPaidbyOthers = 66.00;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                obj6 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = PDDLERLPDChar;
                obj7.BuyerAtClosing = 243123876.22;
                obj7.BuyerBeforeClosing = 765423456.333;
                obj7.BuyerPaidbyOther = 1111111111.11;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.BuyerDoubleAsteriskChecked = true;
                obj7.SellerPaidAtClosing = 237654234.00;
                obj7.SellerPaidBeforeClosing = 134987353.99;
                obj7.SellerPaidbyOthers = 765432123.98;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                obj7 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDDLERLPDChar, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(PDDLERLPDChar, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.SectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Miscellaneous_Disbursement

        #region Verify charges in Section H without entering values in PDD for Miscellaneous Disbursement.

        [TestMethod, Description("VERIFY CHARGES IN SECTION C WITHOUT ENTERING VALUES IN PDD.")]
        public void Senario1_Miscellaneous_Disbursement_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION C WITHOUT ENTERING VALUES IN PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string MDADHOCCHAR1 = "Appraisal Fee";
                string MDADHOCCHAR2 = "Credit Report";
                string MDADHOCCHAR3 = "Flood Certification";
                string MDADHOCCHAR4 = "Tax Service";
                string MDADHOCCHAR5 = "Adhoc Charge1";
                string MDADHOCCHAR6 = "Adhoc Charge2";
                string MDADHOCCHAR7 = "Adhoc Charge3";
                string MDADHOCCHAR8 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Appraisal Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string MDTABLEID = "cgm_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE OUTSIDE TITLE COMPNAY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.MiscDisbursementDetail.GABcode.FASetText("247");
                FastDriver.MiscDisbursementDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN ATTORNEY SELLER SCREEN";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: MDADHOCCHAR1, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(MDADHOCCHAR1, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: MDADHOCCHAR2, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(MDADHOCCHAR2, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: MDADHOCCHAR3, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(MDADHOCCHAR3, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: MDADHOCCHAR4, loanEstimate: 9764.88);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(MDADHOCCHAR4, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: MDADHOCCHAR5, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(MDADHOCCHAR5, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: MDADHOCCHAR6, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(MDADHOCCHAR6, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: MDADHOCCHAR7, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(MDADHOCCHAR7, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: MDADHOCCHAR8, loanEstimate: 780890.58);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Verify the Charges and Amounts in CD Screen Page 2 Section";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, MDADHOCCHAR5, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR6, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, MDADHOCCHAR6, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR7, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, MDADHOCCHAR7, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, MDADHOCCHAR1, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, MDADHOCCHAR2, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, MDADHOCCHAR3, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, MDADHOCCHAR7, true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, MDADHOCCHAR5, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, MDADHOCCHAR2, false, 523423423.67, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + MDADHOCCHAR3;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, MDADHOCCHAR3, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.MiscDisbursementDetail.MiscChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(MDADHOCCHAR7) && i.Displayed).FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                FastDriver.MiscDisbursementDetail.MiscChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(MDADHOCCHAR5) && i.Displayed).FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                FastDriver.MiscDisbursementDetail.MiscChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(MDADHOCCHAR2) && i.Displayed).FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN ATTORNEY SELLER SCREEN";
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, MDADHOCCHAR1, editDescription: SourceChargeDesc);
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, MDADHOCCHAR2, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, MDADHOCCHAR4, buyerCharge: 8564.78);
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, MDADHOCCHAR5, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, MDADHOCCHAR6, editDescription: SourceChargeDesc1);
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, MDADHOCCHAR8, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, MDADHOCCHAR5, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, MDADHOCCHAR8, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, MDADHOCCHAR2, BuyerAtClosing: 68598.00);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, MDADHOCCHAR4, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Navigate to MISCELLANEOUS DISBURSEMENT Screen";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.MiscDisbursementDetail.GABcode.FASetText("BOA");
                FastDriver.MiscDisbursementDetail.Find.FAClick();
                payeeLabel1 = FastDriver.MiscDisbursementDetail.MISCDispursement_LenderName.Text.Clean();

                if (FastDriver.MiscDisbursementDetail.MISCDispursement_LenderName1.Displayed)
                    payeeLabel2 = FastDriver.MiscDisbursementDetail.MISCDispursement_LenderName1.Text.Clean();
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR5, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR8, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR2, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, MDADHOCCHAR4, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Miscellaneous Disbursement.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR MISCELLANEOUS DISBURSEMENT .")]
        public void Senario2_Miscellaneous_Disbursement_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR MISCELLANEOUS DISBURSEMENT .";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDMDADHOC1 = "Adhoc Charge1";
                string PDDMDADHOC2 = "Adhoc Charge2";
                string PDDMDADHOC3 = "Adhoc Charge3";
                string PDDMDADHOC4 = "Adhoc Charge4";
                string PDDMDADHOC5 = "Adhoc Charge5";
                string PDDMDADHOC6 = "Adhoc Charge6";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "cgm_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE MISCELLANEOUS DISBURSEMENT INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.MiscDisbursementDetail.GABcode.FASetText("247");
                FastDriver.MiscDisbursementDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "CREATE THE ADHOC CHARGES IN MISCELLANEOUS DISBURSEMENT SCREEN";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: PDDMDADHOC1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDMDADHOC1, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: PDDMDADHOC2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDMDADHOC2, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: PDDMDADHOC3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDMDADHOC3, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: PDDMDADHOC4);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDMDADHOC4, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: PDDMDADHOC5);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDMDADHOC5, FastDriver.MiscDisbursementDetail.MiscChargesTable);
                FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, chargeDescription: PDDMDADHOC6);

                Reports.TestStep = "ENTER THE VALUES FOR ADHOC CHARGES IN MISCELLANEOUS DISBURSEMENT SCREEN";
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = PDDMDADHOC1;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                obj = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = PDDMDADHOC2;
                obj6.LoanEstimateUnrounded = 4342342.56;
                obj6.BuyerAtClosing = 2114.76;
                obj6.BuyerBeforeClosing = 624230.35;
                obj6.BuyerPaidbyOther = 143452.96;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 1342.36;
                obj6.SellerPaidBeforeClosing = 42423.77;
                obj6.SellerPaidbyOthers = 23423.45;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                obj6 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = PDDMDADHOC3;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                obj2 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = PDDMDADHOC4;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                obj3 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = PDDMDADHOC5;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                obj4 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = PDDMDADHOC6;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                obj5 = null;
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);               
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDMDADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDMDADHOC4, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDMDADHOC5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PDDMDADHOC5, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDMDADHOC6, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDDMDADHOC6, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDMDADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PDDMDADHOC2, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDMDADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDMDADHOC3, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDMDADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDMDADHOC1, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDMDADHOC4, true, 2786.51, 4);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDMDADHOC2, false, 76534.67, 2);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDMDADHOC5, false, 456.99, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PDDMDADHOC3, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.MiscDisbursementDetail.MiscChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDMDADHOC4) && i.Displayed).FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                FastDriver.MiscDisbursementDetail.MiscChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDMDADHOC2) && i.Displayed).FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                FastDriver.MiscDisbursementDetail.MiscChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDMDADHOC5) && i.Displayed).FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                FastDriver.MiscDisbursementDetail.UpdateCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, PDDMDADHOC2, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = PDDMDADHOC6;
                obj7.PDDDescription = pddChargeDesc;
                obj7.UseDefaultModify = false;
                obj7.PayeeName = PDDPayeeName;
                obj7.BuyerAtClosing = 44.00;
                obj7.BuyerBeforeClosing = 88.00;
                obj7.BuyerPaidbyOther = 66.7;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.SellerPaidAtClosing = 23.00;
                obj7.SellerPaidBeforeClosing = 53.00;
                obj7.SellerPaidbyOthers = 66.00;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = PDDMDADHOC1;
                obj8.BuyerAtClosing = 243123876.22;
                obj8.BuyerBeforeClosing = 765423456.333;
                obj8.BuyerPaidbyOther = 1111111111.11;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.BuyerDoubleAsteriskChecked = true;
                obj8.SellerPaidAtClosing = 237654234.00;
                obj8.SellerPaidBeforeClosing = 134987353.99;
                obj8.SellerPaidbyOthers = 765432123.98;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDMDADHOC1, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(PDDMDADHOC1, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Survey

        #region Verify charges in Section H without entering values in PDD for Survey.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR SURVEY SCREEN.")]
        public void Senario1_Survey_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR SURVEY SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string SURVEYChar = "Survey";
                string SURVEYADHOC7 = "Adhoc Charge7";
                string SURVEYADHOC5 = "Adhoc Charge5";
                string SURVEYADHOC6 = "Adhoc Charge6";
                string SURVEYADHOC1 = "Adhoc Charge1";
                string SURVEYADHOC2 = "Adhoc Charge2";
                string SURVEYADHOC3 = "Adhoc Charge3";
                string SURVEYADHOC4 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Transfer Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string SurveyTableID = "cg_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE SURVEY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.SurveyDetail.GABcode.FASetText("247");
                FastDriver.SurveyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN SURVEY SCREEN";
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: SURVEYChar, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: SURVEYADHOC1, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SURVEYADHOC1, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: SURVEYADHOC2, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SURVEYADHOC2, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: SURVEYADHOC3, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SURVEYADHOC3, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: SURVEYADHOC4, loanEstimate: 780890.58);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SURVEYADHOC4, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: SURVEYADHOC5, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SURVEYADHOC5, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: SURVEYADHOC6, loanEstimate: 9764.88);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(SURVEYADHOC6, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: SURVEYADHOC7, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SURVEYADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, SURVEYADHOC1, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SURVEYADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, SURVEYADHOC2, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SURVEYADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, SURVEYADHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SURVEYADHOC7, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SURVEYADHOC7, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SURVEYADHOC5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, SURVEYADHOC5, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SURVEYChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, SURVEYChar, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, SURVEYADHOC3, true, 76543.89, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, SURVEYADHOC1, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, SURVEYADHOC7, false, 523423423.67, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + SURVEYADHOC5;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, SURVEYADHOC5, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SURVEY";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.SurveyDetail.SurveyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(SURVEYADHOC3) && i.Displayed).FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.SurveyDetail.SurveyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(SURVEYADHOC1) && i.Displayed).FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.SurveyDetail.SurveyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(SURVEYADHOC7) && i.Displayed).FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                //FastDriver.OutsideEscrowCompanyDetail.UpdateCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, EditChargeDesc, editDescription: EditChargeDesc);

                Reports.TestStep = "MODIFY THE VALUES IN INSPECTION REPAIR-PEST SCREEN";
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, SURVEYChar, editDescription: SourceChargeDesc);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, SURVEYADHOC7, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, SURVEYADHOC6, buyerCharge: 8564.78);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, SURVEYADHOC1, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, SURVEYADHOC2, editDescription: SourceChargeDesc1);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, SURVEYADHOC4, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, SURVEYADHOC1, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, SURVEYADHOC3, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 76544.00);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, SURVEYADHOC4, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, SURVEYADHOC6, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SURVEYADHOC7, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "CHANGE SURVEY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.SurveyDetail.GABcode.FASetText("BOA");
                FastDriver.SurveyDetail.Find.FAClick();
                payeeLabel1 = FastDriver.SurveyDetail.Survey_LenderName.Text.Clean();

                if (FastDriver.SurveyDetail.Survey_LenderName1.Displayed)
                    payeeLabel2 = FastDriver.SurveyDetail.Survey_LenderName1.Text.Clean();
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SURVEYADHOC1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SURVEYADHOC4, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SURVEYADHOC7, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SURVEYADHOC6, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Survey.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR SURVEY SCREEN")]
        public void Senario2_Survey_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR SURVEY SCREEN";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDSURVEYChar = "Survey";
                string PDDSURVEYADHOC5 = "Adhoc Charge5";
                string PDDSURVEYADHOC4 = "Adhoc Charge4";
                string PDDSURVEYADHOC1 = "Adhoc Charge1";
                string PDDSURVEYADHOC2 = "Adhoc Charge2";
                string PDDSURVEYADHOC3 = "Adhoc Charge3";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "cg_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE SURVEY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.SurveyDetail.GABcode.FASetText("247");
                FastDriver.SurveyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.SurveyDetail.SwitchToContentFrame();
                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = PDDSURVEYChar;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.SurveyDetail.SwitchToContentFrame();
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: PDDSURVEYADHOC1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDSURVEYADHOC1, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: PDDSURVEYADHOC2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDSURVEYADHOC2, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: PDDSURVEYADHOC3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDSURVEYADHOC3, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: PDDSURVEYADHOC5);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDSURVEYADHOC5, FastDriver.SurveyDetail.SurveyChargesTable);
                FastDriver.SurveyDetail.AddCharge(FastDriver.SurveyDetail.SurveyChargesTable, chargeDescription: PDDSURVEYADHOC4);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = PDDSURVEYADHOC1;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = PDDSURVEYADHOC2;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = PDDSURVEYADHOC3;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = PDDSURVEYADHOC4;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = PDDSURVEYADHOC5;
                obj6.LoanEstimateUnrounded = 4342342.56;
                obj6.BuyerAtClosing = 2114.76;
                obj6.BuyerBeforeClosing = 624230.35;
                obj6.BuyerPaidbyOther = 143452.96;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 1342.36;
                obj6.SellerPaidBeforeClosing = 42423.77;
                obj6.SellerPaidbyOthers = 23423.45;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDSURVEYADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDSURVEYADHOC1, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDSURVEYADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PDDSURVEYADHOC2, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDSURVEYADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDSURVEYADHOC3, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDSURVEYADHOC5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PDDSURVEYADHOC5, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDSURVEYADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDSURVEYADHOC4, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDSURVEYChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDDSURVEYChar, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDSURVEYADHOC1, true, 2786.51, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDSURVEYADHOC5, false, 76534.67, 5);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDSURVEYADHOC2, false, 456.99, 2);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PDDSURVEYADHOC4, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.SurveyDetail.SurveyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDSURVEYADHOC1) && i.Displayed).FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.SurveyDetail.SurveyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDSURVEYADHOC5) && i.Displayed).FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.SurveyDetail.SurveyChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDSURVEYADHOC2) && i.Displayed).FAClick();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.SurveyDetail.UpdateCharge(FastDriver.SurveyDetail.SurveyChargesTable, PDDSURVEYADHOC5, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = PDDSURVEYADHOC3;
                obj7.PDDDescription = pddChargeDesc;
                obj7.UseDefaultModify = false;
                obj7.PayeeName = PDDPayeeName;
                obj7.BuyerAtClosing = 44.00;
                obj7.BuyerBeforeClosing = 88.00;
                obj7.BuyerPaidbyOther = 66.7;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.SellerPaidAtClosing = 23.00;
                obj7.SellerPaidBeforeClosing = 53.00;
                obj7.SellerPaidbyOthers = 66.00;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = PDDSURVEYChar;
                obj8.BuyerAtClosing = 243123876.22;
                obj8.BuyerBeforeClosing = 765423456.333;
                obj8.BuyerPaidbyOther = 1111111111.11;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.BuyerDoubleAsteriskChecked = true;
                obj8.SellerPaidAtClosing = 237654234.00;
                obj8.SellerPaidBeforeClosing = 134987353.99;
                obj8.SellerPaidbyOthers = 765432123.98;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj9 = new PDD();
                obj9.NewLoanTableId = TableID;
                obj9.ChargeDescription = EditChargeDesc;
                obj9.SectionCDidShopFor = true;
                obj9.LoanEstimateUnrounded = 11.49;
                obj9.BuyerAtClosing = 6.68;
                obj9.BuyerBeforeClosing = 87.69;
                obj9.BuyerPaidbyOther = 1.89;
                obj9.BuyerPaidbyOtherPaymentMethod = "POC";
                obj9.SellerPaidAtClosing = 66.87;
                obj9.SellerPaidBeforeClosing = 6.44;
                obj9.SellerPaidbyOthers = 888.11;
                obj9.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj9);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj10 = new PDD();
                obj10.NewLoanTableId = TableID;
                obj10.ChargeDescription = PDDSURVEYADHOC2;
                obj10.SectionBdidnotShopFor = true;
                obj10.LoanEstimateRounded = 67.49;
                obj10.BuyerAtClosing = 62.87;
                obj10.BuyerBeforeClosing = 87.66;
                obj10.BuyerPaidbyOther = 44.77;
                obj10.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj10);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDSURVEYChar, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(PDDSURVEYChar, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = @"Verify the Charge some other Section.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, PDDSURVEYADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, EditChargeDesc, true, PayeeName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Utility

        #region Verify charges in Section H without entering values in PDD for Utility.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR UTILITY SCREEN.")]
        public void Senario1_Utility_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR UTILITY SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string UCUtilityChar = "Utilities";
                string UTILITYADHOC1 = "Adhoc Charge1";
                string UTILITYADHOC2 = "Adhoc Charge2";
                string UTILITYADHOC3 = "Adhoc Charge3";
                string UTILITYADHOC4 = "Adhoc Charge4";
                string UTILITYADHOC5 = "Adhoc Charge5";
                string UTILITYADHOC6 = "Adhoc Charge6";
                string UTILITYADHOC7 = "Adhoc Charge7";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc = "Verify source Appraisal Fee";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string UTILITYTABLEID = "cg_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE UTILITY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.UtilityDetail.GABcode.FASetText("247");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "ENTER THE VALUES IN LEASE SCREEN";
                FastDriver.UtilityDetail.SwitchToContentFrame();

                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: UCUtilityChar, buyerCharge: 9234656189.99, loanEstimate: 8623623423.49);


                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: UTILITYADHOC1, sellerCharge: 6234356689.78, loanEstimate: 12123523.56);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(UTILITYADHOC1, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: UTILITYADHOC2, buyerCharge: 66643.55, sellerCharge: 7854.54);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(UTILITYADHOC2, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: UTILITYADHOC3, loanEstimate: 9764.88);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(UTILITYADHOC3, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: UTILITYADHOC4, buyerCharge: 42342.87);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(UTILITYADHOC4, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: UTILITYADHOC5, sellerCharge: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(UTILITYADHOC5, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: UTILITYADHOC6, buyerCharge: 8678678.98, sellerCharge: 9589698.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(UTILITYADHOC6, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: UTILITYADHOC7, loanEstimate: 780890.58);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, UTILITYADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, UTILITYADHOC4, BuyerAtClosing: 42342.87);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, UTILITYADHOC5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, UTILITYADHOC5, SellerAtClosing: 978888.57);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, UTILITYADHOC6, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, UTILITYADHOC6, BuyerAtClosing: 8678678.98, SellerAtClosing: 9589698.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, UCUtilityChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, UCUtilityChar, BuyerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, UTILITYADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, UTILITYADHOC1, SellerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, UTILITYADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, UTILITYADHOC2, BuyerAtClosing: 66643.55, SellerAtClosing: 7854.54);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, UTILITYADHOC6, true, 76543.89, 5);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, UTILITYADHOC4, false, 85432.34, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, UTILITYADHOC1, false, 523423423.67, 1);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + UTILITYADHOC2;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, UTILITYADHOC2, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.UtilityDetail.UtilityChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(UTILITYADHOC6) && i.Displayed).FAClick();
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();

                FastDriver.UtilityDetail.UtilityChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(UTILITYADHOC4) && i.Displayed).FAClick();
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$85,432.34", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();

                FastDriver.UtilityDetail.UtilityChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(UTILITYADHOC1) && i.Displayed).FAClick();
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$523,423,423.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "MODIFY THE VALUES IN HOME OWNER ASSOCIATION SCREEN";
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, UCUtilityChar, editDescription: SourceChargeDesc);
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, SourceChargeDesc, buyerCharge: 876574.43, sellerCharge: 766544.43);
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, UTILITYADHOC1, buyerCharge: 68598.00, sellerCharge: 0.00);
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, EditChargeDesc, buyerCharge: 8767559.42, loanEstimate: 53434.87);
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, UTILITYADHOC3, buyerCharge: 8564.78);
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, UTILITYADHOC4, buyerCharge: 93653.76, sellerCharge: 24734.56);
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, UTILITYADHOC5, editDescription: SourceChargeDesc1);
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, SourceChargeDesc1, buyerCharge: 4545345.00, sellerCharge: 678988.87);
                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, UTILITYADHOC7, buyerCharge: 5233.54);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, UTILITYADHOC4, BuyerAtClosing: 93653.76, SellerAtClosing: 24734.56);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, UTILITYADHOC7, BuyerAtClosing: 5233.54);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, UTILITYADHOC1, BuyerAtClosing: 68598.00);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, UTILITYADHOC3, BuyerAtClosing: 8564.78);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, SourceChargeDesc1, BuyerAtClosing: 4545345.00, SellerAtClosing: 678988.87);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.H, EditChargeDesc, BuyerAtClosing: 8767559.42, SellerAtClosing: 7854.54, LoanEstimteUnroundedAmt: 53434.87, LoanEstimateRoundedAmt: 53435.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.H, SourceChargeDesc, BuyerAtClosing: 876574.43, SellerAtClosing: 766544.43);

                Reports.TestStep = "Navigate to HOME OWNER ASSOCIATION Screen";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.UtilityDetail.GABcode.FASetText("BOA");
                FastDriver.UtilityDetail.Find.FAClick();
                payeeLabel1 = FastDriver.UtilityDetail.Utility_LenderName.Text.Clean();

                if (FastDriver.UtilityDetail.Utility_LenderName1.Displayed)
                    payeeLabel2 = FastDriver.UtilityDetail.Utility_LenderName1.Text.Clean();
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, UTILITYADHOC4, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, UTILITYADHOC7, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, UTILITYADHOC1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, UTILITYADHOC3, true, Payeename1);
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in PDD for Utility.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR UTILITY SCREEN")]
        public void Senario2_Utility_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITHOUT ENTERING VALUES IN PDD FOR UTILITY SCREEN";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string PDDUCChar = "Utilities";
                string PDDUYADHOC1 = "Adhoc Charge1";
                string PDDUYADHOC2 = "Adhoc Charge2";
                string PDDUYADHOC3 = "Adhoc Charge3";
                string PDDUYADHOC4 = "Adhoc Charge4";
                string PDDUYADHOC5 = "Adhoc Charge5";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string PDDPayeeName = "Modified Payee Name in PDD";
                string EditChargeDesc = "Modified Charge Description in CD";
                string pddChargeDesc = "M0d!f!3d @dh0c CHARGE";
                string TableID = "cg_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE UTILITY INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.UtilityDetail.GABcode.FASetText("247");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "CREATE THE ADHOC CHARGES IN LEASE SCREEN";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: PDDUYADHOC1);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDUYADHOC1, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: PDDUYADHOC2);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDUYADHOC2, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: PDDUYADHOC3);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDUYADHOC3, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: PDDUYADHOC4);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(PDDUYADHOC4, FastDriver.UtilityDetail.UtilityChargesTable);
                FastDriver.UtilityDetail.AddCharge(FastDriver.UtilityDetail.UtilityChargesTable, chargeDescription: PDDUYADHOC5);

                PDD obj = new PDD();
                obj.NewLoanTableId = TableID;
                obj.ChargeDescription = PDDUCChar;
                obj.LoanEstimateUnrounded = 900.00;
                obj.BuyerAtClosing = 170.00;
                obj.BuyerBeforeClosing = 880.00;
                obj.BuyerPaidbyOther = 970.55;
                obj.BuyerPaidbyOtherPaymentMethod = "POC";
                obj.SellerPaidAtClosing = 460.00;
                obj.SellerPaidBeforeClosing = 380.00;
                obj.SellerPaidbyOthers = 650.49;
                obj.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj2 = new PDD();
                obj2.NewLoanTableId = TableID;
                obj2.ChargeDescription = PDDUYADHOC2;
                obj2.LoanEstimateUnrounded = 11.49;
                obj2.BuyerAtClosing = 6.68;
                obj2.BuyerBeforeClosing = 87.69;
                obj2.BuyerPaidbyOther = 1.89;
                obj2.BuyerPaidbyOtherPaymentMethod = "POC";
                obj2.SellerPaidAtClosing = 66.87;
                obj2.SellerPaidBeforeClosing = 6.44;
                obj2.SellerPaidbyOthers = 888.11;
                obj2.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj2);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj3 = new PDD();
                obj3.NewLoanTableId = TableID;
                obj3.ChargeDescription = PDDUYADHOC3;
                obj3.SellerPaidAtClosing = 2.99;
                obj3.SellerPaidBeforeClosing = 18.22;
                obj3.SellerPaidbyOthers = 58.44;
                obj3.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj3);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj4 = new PDD();
                obj4.NewLoanTableId = TableID;
                obj4.ChargeDescription = PDDUYADHOC4;
                obj4.LoanEstimateUnrounded = 67.49;
                obj4.BuyerAtClosing = 62.87;
                obj4.BuyerBeforeClosing = 87.66;
                obj4.BuyerPaidbyOther = 44.77;
                obj4.BuyerPaidbyOtherPaymentMethod = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj4);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj5 = new PDD();
                obj5.NewLoanTableId = TableID;
                obj5.ChargeDescription = PDDUYADHOC5;
                obj5.LoanEstimateUnrounded = 3452.499;
                obj5.BuyerAtClosing = 1232.87;
                obj5.BuyerBeforeClosing = 765441.26;
                obj5.BuyerPaidbyOther = 6654.77;
                obj5.BuyerPaidbyOtherPaymentMethod = "POC";
                obj5.SellerPaidAtClosing = 7654.22;
                obj5.SellerPaidBeforeClosing = 543317.22;
                obj5.SellerPaidbyOthers = 23332.50;
                obj5.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj5);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj6 = new PDD();
                obj6.NewLoanTableId = TableID;
                obj6.ChargeDescription = PDDUYADHOC1;
                obj6.LoanEstimateUnrounded = 4342342.56;
                obj6.BuyerAtClosing = 2114.76;
                obj6.BuyerBeforeClosing = 624230.35;
                obj6.BuyerPaidbyOther = 143452.96;
                obj6.BuyerPaidbyOtherPaymentMethod = "POC";
                obj6.SellerPaidAtClosing = 1342.36;
                obj6.SellerPaidBeforeClosing = 42423.77;
                obj6.SellerPaidbyOthers = 23423.45;
                obj6.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj6);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE CHARGE DESCRIPTION AND PAYEE NAME AND CHARGES AMOUNTS";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDUYADHOC3, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, PDDUYADHOC3, SellerAtClosing: 2.99, SellerBeforeClosing: 18.22);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDUYADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, PDDUYADHOC4, BuyerAtClosing: 62.87, BuyerBeforeClosing: 87.66, BuyerPaidbyOther: 44.77, LoanEstimateRoundedAmt: 67.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDUYADHOC5, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, PDDUYADHOC5, BuyerAtClosing: 1232.87, BuyerBeforeClosing: 765441.26, SellerAtClosing: 7654.22, SellerBeforeClosing: 543317.22, BuyerPaidbyOther: 6654.77, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDUYADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, PDDUYADHOC1, BuyerAtClosing: 2114.76, BuyerBeforeClosing: 624230.35, SellerAtClosing: 1342.36, SellerBeforeClosing: 42423.77, BuyerPaidbyOther: 143452.96, LoanEstimteUnroundedAmt: 4342342.56, LoanEstimateRoundedAmt: 4342343.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDUYADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, PDDUYADHOC2, BuyerAtClosing: 6.68, BuyerBeforeClosing: 87.69, SellerAtClosing: 66.87, SellerBeforeClosing: 6.44, BuyerPaidbyOther: 1.89, LoanEstimteUnroundedAmt: 11.49, LoanEstimateRoundedAmt: 11.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, PDDUCChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDDUCChar, BuyerAtClosing: 170.00, BuyerBeforeClosing: 880.00, SellerAtClosing: 460.00, SellerBeforeClosing: 380.00, BuyerPaidbyOther: 970.55, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDUYADHOC3, true, 2786.51, 3);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDUYADHOC1, false, 76534.67, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, PDDUYADHOC4, false, 456.99, 4);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, PDDUYADHOC2, EditChargeDesc);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
                Playback.Wait(250);

                FastDriver.UtilityDetail.UtilityChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDUYADHOC3) && i.Displayed).FAClick();
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$2,787.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();

                FastDriver.UtilityDetail.UtilityChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDUYADHOC1) && i.Displayed).FAClick();
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$76,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$76,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();

                FastDriver.UtilityDetail.UtilityChargesTable.FindElements(OpenQA.Selenium.By.TagName("input"))
                    .FirstOrDefault(i => i.GetAttribute("value").Contains(PDDUYADHOC4) && i.Displayed).FAClick();
                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.LoadEstimateRounded, 5);
                Support.AreEqual("$456.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("$457.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.GetAttribute("value").ToString().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();

                FastDriver.UtilityDetail.UpdateCharge(FastDriver.UtilityDetail.UtilityChargesTable, PDDUYADHOC1, loanEstimate: 76534.67);

                Reports.TestStep = "MODIFY THE PAYEMENT METHODS AND SELECT THE DOUBLE ASTERISK CHECK BOX AND CHANGE THE PAYEENAME  IN PDD";
                PDD obj7 = new PDD();
                obj7.NewLoanTableId = TableID;
                obj7.ChargeDescription = PDDUYADHOC5;
                obj7.PDDDescription = pddChargeDesc;
                obj7.UseDefaultModify = false;
                obj7.PayeeName = PDDPayeeName;
                obj7.BuyerAtClosing = 44.00;
                obj7.BuyerBeforeClosing = 88.00;
                obj7.BuyerPaidbyOther = 66.7;
                obj7.BuyerPaidbyOtherPaymentMethod = "POC";
                obj7.SellerPaidAtClosing = 23.00;
                obj7.SellerPaidBeforeClosing = 53.00;
                obj7.SellerPaidbyOthers = 66.00;
                obj7.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj7);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                PDD obj8 = new PDD();
                obj8.NewLoanTableId = TableID;
                obj8.ChargeDescription = PDDUCChar;
                obj8.BuyerAtClosing = 243123876.22;
                obj8.BuyerBeforeClosing = 765423456.333;
                obj8.BuyerPaidbyOther = 1111111111.11;
                obj8.BuyerPaidbyOtherPaymentMethod = "POC";
                obj8.BuyerDoubleAsteriskChecked = true;
                obj8.SellerPaidAtClosing = 237654234.00;
                obj8.SellerPaidBeforeClosing = 134987353.99;
                obj8.SellerPaidbyOthers = 765432123.98;
                obj8.SellerPaidbyOtherPaymentMthd = "POC";
                FastDriver.NewLoan.EnterValuesInPDD(obj8);
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY BUYER & SELLER AMOUNTS FOR ADHOC3 CHARGE IN CD. AND VERIFY * SHOULD DISPLAY BEFORE CHARGE AND VERIFY THE PAYEENAME ";
                FastDriver.ClosingDisclosure.CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection.H, true, pddChargeDesc, true, PDDPayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, pddChargeDesc, BuyerAtClosing: 44.00, BuyerBeforeClosing: 88.00, SellerAtClosing: 23.00, SellerBeforeClosing: 53.00, BuyerPaidbyOther: 66.7, LoanEstimteUnroundedAmt: 3452.49, LoanEstimateRoundedAmt: 3452.00);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.H, PDDUCChar, BuyerAtClosing: 243123876.22, BuyerBeforeClosing: 765423456.33, SellerAtClosing: 237654234.00, SellerBeforeClosing: 134987353.99, BuyerPaidbyOther: 1111111111.11, LoanEstimteUnroundedAmt: 900.00, LoanEstimateRoundedAmt: 900.00);
                FastDriver.ClosingDisclosure.CheckDoubleAsterisk_CD(PDDUCChar, "tblOtherCostSubSection_H", true);

                Reports.TestStep = @"Remove Description for Credit Report and verify the error message.";
                var element = FastDriver.ClosingDisclosure.OtherCostsOtherSectionHTable.FindElements(By.TagName("tr"))[4].FindElements(By.TagName("td"))[0]
                    .FindElements(By.CssSelector("span[contenteditable]")).First(i => i.Displayed);
                element.Click();
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                Support.AreEqual("Charge Description is required.", FastDriver.WebDriver.HandleDialogMessage(true, true));

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Real Estate Broker/Agent

        #region Verify charges in Section H with entering values in  REB-Seller.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITH ENTERING VALUES IN REB-SELLER SCREEN.")]
        public void Senario1_REB_Seller_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITH ENTERING VALUES IN REB-SELLER SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string REBORCCAChar = "Commission Paid at Settlement";
                string REBORREBCCHAR = "General Excise Tax";
                string REBORREBCADHOC1 = "Adhoc Charge1";
                string REBORREBCADHOC2 = "Adhoc Charge2";
                string REBORREBCADHOC3 = "Adhoc Charge3";
                string REBORPOCBADHOC4 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string REBCCATABLEID = "cgCC_dcs";
                string REBREBCTABLEID = "cgBC_dcs";
                string REBPOCBTABLEID = "cgPOC_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE HOME OWNER ASSOCIATION INSTANCE AND VERIFY THE SAME.";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SellerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                Reports.TestStep = "ENTER THE VALUES IN REB SELLER SCREEN";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("9234656189.99");
                if (chargeAvailability(REBCCATABLEID, REBORCCAChar))
                {
                    FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, chargeDescription: REBORCCAChar, loanEstimate: 8623623423.49);
                }
                else
                {
                    addNewLine(FastDriver.RealEstateBrokerAgent.CommisionChargeTable);
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, chargeDescription: REBORCCAChar, loanEstimate: 8623623423.49);
                    Keyboard.SendKeys(FAKeys.TabAway);                    
                }

                if (chargeAvailability(REBREBCTABLEID, REBORREBCCHAR))
                {
                    FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCCHAR, buyerCharge: 6234356689.78, loanEstimate: 12123523.56);
                }
                else
                {
                    addNewLine(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable);
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCCHAR, buyerCharge: 6234356689.78, loanEstimate: 12123523.56);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }
                
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCADHOC1, buyerCharge: 66643.55);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(REBORREBCADHOC1, FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable);
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCADHOC2, buyerCharge: 9764.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(REBORREBCADHOC2, FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable);
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCADHOC3, loanEstimate: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.POCbyBrokerTable, chargeDescription: REBORPOCBADHOC4);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("780890.58");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORREBCADHOC1, BuyerAtClosing: 66643.55);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, REBORREBCADHOC2, BuyerAtClosing: 9764.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORPOCBADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, REBORPOCBADHOC4, BuyerPaidbyOther: 780890.58);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORCCAChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, REBORCCAChar, SellerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCCHAR, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, REBORREBCCHAR, BuyerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, REBORREBCADHOC1, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, REBORREBCCHAR, false, 523423423.67, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + REBORREBCADHOC1;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, REBORREBCADHOC1, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SellerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();

                if (chargeAvailability(REBREBCTABLEID, EditChargeDesc))
                    Reports.StatusUpdate("Charge available!", true);
                else
                    Reports.StatusUpdate("Charge not found in table!", false);
                VerifyChargeAmount(REBREBCTABLEID, loanEstimate: 85432.34);
                VerifyChargeAmount(REBREBCTABLEID, loanEstimate: 523423423.67);
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, REBORCCAChar, editDescription: SourceChargeDesc1);
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, REBORREBCCHAR, buyerCharge: 876543.98);
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, REBORREBCADHOC3, buyerCharge: 6543298.49);

                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("BOA");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("656189.88");
                payeeLabel1 = FastDriver.RealEstateBrokerAgent.GabNameLabel1.Text.Clean();
                payeeLabel2 = FastDriver.RealEstateBrokerAgent.GabNameLabel2.Text.Clean() == string.Empty ? FastDriver.RealEstateBrokerAgent.GabNameLabel2.Text.Clean(): string.Empty;
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SourceChargeDesc1, SellerAtClosing: 656189.88);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, REBORREBCCHAR, BuyerAtClosing: 876543.98);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, REBORREBCADHOC3, BuyerAtClosing: 6543298.49);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCCHAR, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC2, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC3, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORPOCBADHOC4, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in  REB-Buyer.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITH ENTERING VALUES IN REB-BUYER SCREEN.")]
        public void Senario2_REB_Buyer_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITH ENTERING VALUES IN REB-BUYER SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string REBORCCAChar = "Commission Paid at Settlement";
                string REBORREBCCHAR = "General Excise Tax";
                string REBORREBCADHOC1 = "Adhoc Charge1";
                string REBORREBCADHOC2 = "Adhoc Charge2";
                string REBORREBCADHOC3 = "Adhoc Charge3";
                string REBORPOCBADHOC4 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string REBCCATABLEID = "cgCC_dcs";
                string REBREBCTABLEID = "cgBC_dcs";
                string REBPOCBTABLEID = "cgPOC_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE A OTHER INSTANCE IN REB SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                Reports.TestStep = "ENTER THE VALUES IN REB BUYER SCREEN";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("9234656189.99");
                if (chargeAvailability(REBCCATABLEID, REBORCCAChar))
                {
                    FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, chargeDescription: REBORCCAChar, loanEstimate: 8623623423.49);
                }
                else
                {
                    addNewLine(FastDriver.RealEstateBrokerAgent.CommisionChargeTable);
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, chargeDescription: REBORCCAChar, loanEstimate: 8623623423.49);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                if (chargeAvailability(REBREBCTABLEID, REBORREBCCHAR))
                {
                    FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCCHAR, buyerCharge: 6234356689.78, loanEstimate: 12123523.56);
                }
                else
                {
                    addNewLine(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable);
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCCHAR, buyerCharge: 6234356689.78, loanEstimate: 12123523.56);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCADHOC1, buyerCharge: 66643.55);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(REBORREBCADHOC1, FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable);
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCADHOC2, buyerCharge: 9764.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(REBORREBCADHOC2, FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable);
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCADHOC3, loanEstimate: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.POCbyBrokerTable, chargeDescription: REBORPOCBADHOC4);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("780890.58");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORREBCADHOC1, BuyerAtClosing: 66643.55);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, REBORREBCADHOC2, BuyerAtClosing: 9764.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORPOCBADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, REBORPOCBADHOC4, BuyerPaidbyOther: 780890.58);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORCCAChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, REBORCCAChar, SellerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCCHAR, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, REBORREBCCHAR, BuyerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, REBORREBCADHOC1, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, REBORREBCCHAR, false, 523423423.67, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + REBORREBCADHOC1;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, REBORREBCADHOC1, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();

                if (chargeAvailability(REBREBCTABLEID, EditChargeDesc))
                    Reports.StatusUpdate("Charge available!", true);
                else
                    Reports.StatusUpdate("Charge not found in table!", false);
                VerifyChargeAmount(REBREBCTABLEID, loanEstimate: 85432.34);
                VerifyChargeAmount(REBREBCTABLEID, loanEstimate: 523423423.67);
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, REBORCCAChar, editDescription: SourceChargeDesc1);
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, REBORREBCCHAR, buyerCharge: 876543.98);
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, REBORREBCADHOC3, buyerCharge: 6543298.49);

                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("BOA");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("656189.88");
                payeeLabel1 = FastDriver.RealEstateBrokerAgent.GabNameLabel1.Text.Clean();
                payeeLabel2 = FastDriver.RealEstateBrokerAgent.GabNameLabel2.Text.Clean() == string.Empty ? FastDriver.RealEstateBrokerAgent.GabNameLabel2.Text.Clean() : string.Empty;
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SourceChargeDesc1, SellerAtClosing: 656189.88);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, REBORREBCCHAR, BuyerAtClosing: 876543.98);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, REBORREBCADHOC3, BuyerAtClosing: 6543298.49);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCCHAR, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC2, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC3, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORPOCBADHOC4, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify charges in Section H with entering values in REB-Other Screen.

        [TestMethod, Description("VERIFY CHARGES IN SECTION H WITH ENTERING VALUES IN REB-OTHER SCREEN.")]
        public void Senario3_REB_Other_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY CHARGES IN SECTION H WITH ENTERING VALUES IN REB-OTHER SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string REBORCCAChar = "Commission Paid at Settlement";
                string REBORREBCCHAR = "General Excise Tax";
                string REBORREBCADHOC1 = "Adhoc Charge1";
                string REBORREBCADHOC2 = "Adhoc Charge2";
                string REBORREBCADHOC3 = "Adhoc Charge3";
                string REBORPOCBADHOC4 = "Adhoc Charge4";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                string Payeename1, payeeLabel1, payeeLabel2 = string.Empty;
                string EditChargeDesc = "Modified Charge Description in CD";
                string SourceChargeDesc1 = "M0d!f!3d @dh0c CHARGE";
                string REBCCATABLEID = "cgCC_dcs";
                string REBREBCTABLEID = "cgBC_dcs";
                string REBPOCBTABLEID = "cgPOC_dcs";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE A OTHER INSTANCE IN REB SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                Reports.TestStep = "ENTER THE VALUES IN REB BUYER SCREEN";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("9234656189.99");
                if (chargeAvailability(REBCCATABLEID, REBORCCAChar))
                {
                    FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, chargeDescription: REBORCCAChar, loanEstimate: 8623623423.49);
                }
                else
                {
                    addNewLine(FastDriver.RealEstateBrokerAgent.CommisionChargeTable);
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, chargeDescription: REBORCCAChar, loanEstimate: 8623623423.49);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                if (chargeAvailability(REBREBCTABLEID, REBORREBCCHAR))
                {
                    FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCCHAR, buyerCharge: 6234356689.78, loanEstimate: 12123523.56);
                }
                else
                {
                    addNewLine(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable);
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCCHAR, buyerCharge: 6234356689.78, loanEstimate: 12123523.56);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCADHOC1, buyerCharge: 66643.55);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(REBORREBCADHOC1, FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable);
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCADHOC2, buyerCharge: 9764.88, loanEstimate: 88434634.50);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                verifyEmptyLine(REBORREBCADHOC2, FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable);
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, chargeDescription: REBORREBCADHOC3, loanEstimate: 978888.57);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAClick();
                FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.POCbyBrokerTable, chargeDescription: REBORPOCBADHOC4);
                FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("780890.58");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Select the Display Loan Estimate Column Check Box";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "VERIFY THE VALUES IN CD SCREEN SECTION H FOR ATTORNEY BUYER SCREEN";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC1, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORREBCADHOC1, BuyerAtClosing: 66643.55);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC2, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, REBORREBCADHOC2, BuyerAtClosing: 9764.88, LoanEstimteUnroundedAmt: 88434634.50, LoanEstimateRoundedAmt: 88434635.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORPOCBADHOC4, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.H, REBORPOCBADHOC4, BuyerPaidbyOther: 780890.58);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORCCAChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, REBORCCAChar, SellerAtClosing: 234656189.99, LoanEstimteUnroundedAmt: 623623423.49, LoanEstimateRoundedAmt: 623623423.00);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCCHAR, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, REBORREBCCHAR, BuyerAtClosing: 234356689.78, LoanEstimteUnroundedAmt: 12123523.56, LoanEstimateRoundedAmt: 12123524.00);

                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, REBORREBCADHOC1, false, 85432.34, 1);
                FastDriver.ClosingDisclosure.editLoanEstimateColumn(ClosingDisclosureSection.H, REBORREBCCHAR, false, 523423423.67, 5);

                Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN CD SCREEN" + REBORREBCADHOC1;
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, REBORREBCADHOC1, EditChargeDesc);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.OtherbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                if (chargeAvailability(REBREBCTABLEID, EditChargeDesc))
                    Reports.StatusUpdate("Charge available!", true);
                else
                    Reports.StatusUpdate("Charge not found in table!", false);
                VerifyChargeAmount(REBREBCTABLEID, loanEstimate: 85432.34);
                VerifyChargeAmount(REBREBCTABLEID, loanEstimate: 523423423.67);
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, REBORCCAChar, editDescription: SourceChargeDesc1);
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, REBORREBCCHAR, buyerCharge: 876543.98);
                FastDriver.RealEstateBrokerAgent.UpdateCharge(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable, REBORREBCADHOC3, buyerCharge: 6543298.49);

                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("BOA");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("656189.88");
                payeeLabel1 = FastDriver.RealEstateBrokerAgent.GabNameLabel1.Text.Clean();
                payeeLabel2 = FastDriver.RealEstateBrokerAgent.GabNameLabel2.Text.Clean() == string.Empty ? FastDriver.RealEstateBrokerAgent.GabNameLabel2.Text.Clean() : string.Empty;
                Payeename1 = payeeLabel1 + " " + payeeLabel2;
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, SourceChargeDesc1, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.H, SourceChargeDesc1, SellerAtClosing: 656189.88);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.H, REBORREBCCHAR, BuyerAtClosing: 876543.98);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.H, REBORREBCADHOC3, BuyerAtClosing: 6543298.49);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCCHAR, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC2, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, EditChargeDesc, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORREBCADHOC3, true, Payeename1);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORPOCBADHOC4, true, Payeename1);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify REB Functionality from deposits Outside Escrow for Seller

        [TestMethod, Description("VERIFY REB FUNCTIONALITY FROM DEPOSITS OUTSIDE ESCROW FOR REB-SELLER SCREEN.")]
        public void Senario4_REB_Seller_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY REB FUNCTIONALITY FROM DEPOSITS OUTSIDE ESCROW FOR REB-SELLER SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string REBORCCAChar = "Commission Paid at Settlement";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE A OTHER INSTANCE IN REB SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SellerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                Reports.TestStep = "ENTER THE VALUES IN REB BUYER SCREEN";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5000");
                if (!chargeAvailability("cgCC_dcs", REBORCCAChar))
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, REBORCCAChar);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Seller's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("8000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("8000");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORCCAChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORCCAChar, SellerAtClosing: 5000.00);

                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("5000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("5000");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SellerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5,000.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORCCAChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORCCAChar, SellerAtClosing: 5000.00);

                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("3000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("3000");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SellerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5,000.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORCCAChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORCCAChar, SellerAtClosing: 5000.00);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SellerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgent.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5,000.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("2,000.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("7000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?", 
                    FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORCCAChar, BuyerAtClosing: 7000.00, SellerAtClosing: 5000.00);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Verify REB Functionality from deposits Outside Escrow for Buyer

        [TestMethod, Description("VERIFY REB FUNCTIONALITY FROM DEPOSITS OUTSIDE ESCROW FOR REB-BUYER SCREEN.")]
        public void Senario4_REB_Buyer_CD_H()
        {
            try
            {
                Reports.TestDescription = "VERIFY REB FUNCTIONALITY FROM DEPOSITS OUTSIDE ESCROW FOR REB-BUYER SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string REBORCCAChar = "Commission Paid at Settlement";
                string PayeeName = "Lenders Advantage A Division Of First American Title Ins.";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "CREATE A OTHER INSTANCE IN REB SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("247");

                Reports.TestStep = "ENTER THE VALUES IN REB BUYER SCREEN";
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5000");
                if (!chargeAvailability("cgCC_dcs", REBORCCAChar))
                    FastDriver.RealEstateBrokerAgent.AddCharge(FastDriver.RealEstateBrokerAgent.CommisionChargeTable, REBORCCAChar);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Buyer's Broker");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("8000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("8000");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORCCAChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORCCAChar, SellerAtClosing: 5000.00);

                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("5000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("5000");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5,000.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORCCAChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORCCAChar, SellerAtClosing: 5000.00);

                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("3000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("3000");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5,000.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE LOAN COSTS - Sections";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, REBORCCAChar, true, PayeeName);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORCCAChar, SellerAtClosing: 5000.00);

                Reports.TestStep = "VERIFY THE MODIFIED VALUES IN SOURCE SCREEN";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5,000.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("2,000.00");
                FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("7000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("Commission Paid at Settlement has changed. Do you wish to override Commission Amount and remove Commission %?",
                    FastDriver.WebDriver.HandleDialogMessage(true, true));

                Reports.TestStep = "Navigate to Closing Disclosure screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, REBORCCAChar, BuyerAtClosing: 7000.00, SellerAtClosing: 5000.00);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region J-Lender Credits

        #region Verify the Lender Credits Funnctionality form Newloan and Mortgage broker Screen

        [TestMethod, Description("VERIFY THE LENDER CREDITS FUNCTIONALITY  IN THE CD SCREEN SECTION J")]
        public void Scenario1_NewLoan_Lender_Credits_J()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE LENDER CREDITS FUNCTIONALITY  IN THE CD SCREEN SECTION J";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                //both charges have 'Variance' instead of 'Violation', I changed it for now for test purposes
                string ChargeDescription1 = "Good Faith Variance Cure", ChargeDescription2 = "Good Faith Variance Cure POC";
                string ExpectedText = "Lender Credits(Includes$67,647.47and excludes$3,401.32credit for)", ActualText = string.Empty, Text = string.Empty;
                string ModifyDescription1 = "Good faith Cure", ModifyDescription2 = "Good faith POC", ModifyDescription3 = "Modified in Closing Disclosure";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create New Loan.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                Reports.TestStep = "NAVIGATE TO LOAN CHARGE TAB,FETCH AND ENTER AMOUNT FOR THE CHARGE.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanCharges_ExpandLenderCredits.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_LenderCreditTable, ChargeDescription1, buyerCredit: 33400.98);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_LenderCreditTable, ChargeDescription2, buyerCredit: 3100.43);

                Reports.TestStep = "NAVIGATE TO MORTGAGE BROKER TAB,FETCH AND ENTER AMOUNT FOR THE CHARGE.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_LenderCreditTable, ChargeDescription1, buyerCredit: 33900.90);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_LenderCreditTable, ChargeDescription2, buyerCredit: 300.89);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO DEPOSIT IN ESCROW .";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositInEscrow.Amount.FASetText("345.59");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Good Faith Variance Cure");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("PayerTestName");
                FastDriver.BottomFrame.Save();
                Support.AreEqual("Deposit Receipt is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage(true, false));

                Reports.TestStep = "NAVIGATE TO CLOSING DISCLOSURE SCREEN AND EXPAND THE OTHER COSTS - SECTION J";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "VERIFY THE LENDER CREDIT CHARGE IN SECTION J OF CD SCREEN";
                verifyChargeSectionJ(ExpectedText, 2);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.J, ExpectedText, BuyerAtClosing: -67647.47);

                Reports.TestStep = "EDIT THE LENDER CREDITS DESCRIPTION";

                EditLenderCreditDescription(ModifyDescription1, ModifyDescription2, ModifyDescription3);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion

        #endregion

        #region HelpMethods

        public void verifyEmptyLine(string chargeDesc, IWebElement table)
        {
            IWebElement charge, lastCharge;
            charge = table.PerformTableAction(table.GetRowCount(), 1, TableAction.GetCell).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
            if (charge.GetAttribute("value").Contains(chargeDesc))
            {
                lastCharge = table.PerformTableAction(table.GetRowCount(), table.GetColumnCount(), TableAction.GetCell).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                lastCharge.Click();
                Keyboard.SendKeys(FAKeys.TabAway);
                
            }
        }

        public bool chargeAvailability(string tableId, string chargeDesc)
        {
            IWebElement table = FastDriver.WebDriver.FindElement(By.Id(tableId));
            int filterrowcount = table.GetRowCount();
            bool isPresent = false;

            for (int i = 1; i < filterrowcount; i++)
            {
                string chargeid;
                int l = i - 1;
                
                chargeid = tableId + "_" + l + "_tdsc";
                var NewLoantbledit = FastDriver.WebDriver.FindElement(By.Id(chargeid));
                string desc = NewLoantbledit.GetAttribute("value").ToString().Trim();
                if (desc == chargeDesc)
                {
                    isPresent = true;
                    break;
                }
                
            }

            return isPresent;
        }

        public void addNewLine(IWebElement table)
        {
            IWebElement element = table.PerformTableAction(table.GetRowCount(), table.GetColumnCount(), TableAction.GetCell).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
            element.Click();
            Playback.Wait(750);
            Keyboard.SendKeys(FAKeys.TabAway);
        }

        public void VerifyChargeAmount(string tableId, double? buyerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            IWebElement table = FastDriver.WebDriver.FindElement(By.Id(tableId));
            int filterrowcount = table.GetRowCount();
            bool isPresent = false;

            if (buyerCharge.HasValue)
            {
                for (int i = 1; i < filterrowcount; i++)
                {
                    string chargeid;
                    int l = i - 1;

                    chargeid = tableId + "_" + l + "_tbd";
                    var NewLoantbledit = FastDriver.WebDriver.FindElement(By.Id(chargeid));
                    string buyercredit = NewLoantbledit.GetAttribute("value").ToString().Trim();
                    if (buyercredit.Replace(",", "") == buyerCharge.ToString())
                    {
                        Reports.StatusUpdate("Buyer Charge is present on Table!", true);
                        isPresent = true;
                        break;
                    }

                }
            }

            if (buyerCharge.HasValue && !isPresent)
                Reports.StatusUpdate("Buyer Charge not present on Table!", false);
            else
                isPresent = false;

            if (sellerCredit.HasValue)
            {
                for (int i = 1; i < filterrowcount; i++)
                {
                    string chargeid;
                    int l = i - 1;

                    chargeid = tableId + "_" + l + "_tsr";
                    var NewLoantbledit = FastDriver.WebDriver.FindElement(By.Id(chargeid));
                    string sellercredit = NewLoantbledit.GetAttribute("value").ToString().Trim();
                    if (sellercredit.Replace(",", "") == sellerCredit.ToString())
                    {
                        Reports.StatusUpdate("Seller Charge is present on Table!", true);
                        isPresent = true;
                        break;
                    }

                }
            }

            if (sellerCredit.HasValue && !isPresent)
                Reports.StatusUpdate("Seller Charge not present on Table!", false);
            else
                isPresent = false;

            if (loanEstimate.HasValue)
            {
                for (int i = 1; i < filterrowcount; i++)
                {
                    string chargeid;
                    int l = i - 1;

                    chargeid = tableId + "_" + l + "_tga";
                    var NewLoantbledit = FastDriver.WebDriver.FindElement(By.Id(chargeid));
                    string sellercredit = NewLoantbledit.GetAttribute("value").ToString().Trim();
                    if (sellercredit.Replace(",", "") == loanEstimate.ToString())
                    {
                        Reports.StatusUpdate("Loan Estimate Charge is present on Table!", true);
                        isPresent = true;
                        break;
                    }

                }
            }

            if (loanEstimate.HasValue && !isPresent)
                Reports.StatusUpdate("Loan Estimate Charge not present on Table!", false);

        }

        public void verifyChargeSectionJ(string expectedValue, int lineNo)
        {
            string actualValue = string.Empty;
            var elements = FastDriver.ClosingDisclosure.TotalClosingCostsTable.FindElements(By.TagName("tr"))[lineNo]
                .FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"));
            
            foreach (var element in elements)
            {
                actualValue += element.Text;
            }

            Support.AreEqual(expectedValue.Clean(), actualValue.Clean());

        }

        public void EditLenderCreditDescription(string ModifyDescription1, string ModifyDescription2, string ModifyDescription3 = "")
        {
            string ActualText = string.Empty;
            var elements = FastDriver.ClosingDisclosure.TableOtherCostSectionJ.FindElements(By.CssSelector("span[contenteditable]"));

            try
            {
                elements[0].Clear();
                elements[0].FASetText(ModifyDescription1);
                Keyboard.SendKeys(FAKeys.TabAway);

                elements[1].Clear();
                elements[1].FASetText(ModifyDescription2);
                Keyboard.SendKeys(FAKeys.TabAway);

                if (ModifyDescription3 != "")
                {
                    elements[2].Clear();
                    elements[2].FASetText(ModifyDescription3);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                Reports.StatusUpdate("The Description Field value is Modified.", true);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("One or more Description Field value are not Editable.", false);
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(500);
            FastDriver.ClosingDisclosure.WaitForScreenToLoad();
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            Playback.Wait(250);
            elements = FastDriver.ClosingDisclosure.TableOtherCostSectionJ.FindElements(By.CssSelector("span[contenteditable]"));

            for (int i = 0; i < elements.Count; i++ )
            {
                ActualText += elements[i].Text;
            }

            Reports.StatusUpdate("The Description:" + ActualText.Trim(), true);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
