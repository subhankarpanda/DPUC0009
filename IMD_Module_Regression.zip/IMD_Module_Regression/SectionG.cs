﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Diagnostics;

namespace IMD_Module_Regression
{
    [CodedUITest]
    public class SectionG : MasterTestClass
    {
        [TestMethod]
        public void SectionG_Scenario1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "Verify charges in Section G – Line 1 with/without entering values in PDD.";

                Reports.TestStep = "Login to IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with New Lender";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                Support.DataSave("fileNumber_SectionG_Scenario1", fileNumber);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = @"i) Enter values under Impounds section: Homeowner's Insurance – Months = 99, Monthly Charges = 5600 and Buyer Charge = Auto Calculated.";
                FastDriver.NewLoan.UpdateImpoundCharge("Homeowner's Insurance", null, null, null, null, null, 99, 5600);

                Reports.TestStep = @"ii) Enter values under Impounds section: Mortgage Insurance – Months = 10, Buyer Charge = 6700, Loan Estimate = 56700.";
                FastDriver.NewLoan.UpdateImpoundCharge("Mortgage Insurance", 6700, null, null, null, 56700, 10);

                Reports.TestStep = @"iii) Enter values under Impounds section: City Property Taxes – Monthly Charges = 45756, Seller Charge = 34645.";
                FastDriver.NewLoan.UpdateImpoundCharge("City Property Taxes", null, null, 34645, null, null, null, 45756);

                Reports.TestStep = @"iv) Enter values under Impounds section: County Property Taxes – Months – 45, Buyer Charge = 5600";
                FastDriver.NewLoan.UpdateImpoundCharge("County Property Taxes", 5600, null, null, null, null, 45);

                Reports.TestStep = @"v) Enter values under Impounds section: Annual Assessment – Monthly Charges = 45,343.50, Seller Charge = 3400";
                FastDriver.NewLoan.UpdateImpoundCharge("Annual Assessments", null, null, 3400, null, null, null, 45343.50);

                Reports.TestStep = @"vi) Enter values under Impounds section: Adhoc Charge1 – Months = 56, Monthly Charges = 4560, Buyer Charge = 3400.50, Seller Charge = 5675.67, Loan Estimate Amount = 45566.78";
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge1", 3400.50, null, 5675.67, null, 45566.78, 56, 4560);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"vii) Enter values under Impounds section: Adhoc Charge2 – Buyer Charge = 5689.89";
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge2", 5689.89);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"viii) Enter values under Impounds section: Adhoc Charge3 – Months = 34, Monthly Charges = 2345, Buyer Charge = 0";
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge3", 0, null, null, null, null, 34, 2345);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"ix) Enter values under Impounds section: Adhoc Charge4 – Seller Charge = 324234345.56, Loan Estimate = 43234.56";
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge4", null, null, 324234345.56, null, 43234.56);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"x) Enter values under Impounds section: Adhoc Charge5 – Loan Estimate = 453453454.56";
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge5", null, null, null, null, 453453454.56);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"xi) Enter values under Impounds section: Adhoc Charge6 – Months = 0, Monthly Charges = 6700";
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge6", null, null, null, null, null, 0, 6700);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"xii) Enter values under Impounds section: Aggregate Adjustment – Credit,  Buyer = 56.50, Seller = 34.44";
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCredit.FAClick();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("56.50");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("34.44");
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = @"d)	Navigate to CD Screen. Expand Other Cost and verify the values displayed in CD Screen.
                                                                i)	System should display the charges which has months and Monthly charges.
                                                                ii)	For first three charges system should displays “per month for” and “mo.” even if months and monthly charges do not exist. 
                                                                    From 3+ system should display only description if both months and monthly charges do not exist.
                                                                iii)If months/monthly charges does not exist system should not display months and monthly charges. 
                                                                iv)	Charge should be should when 
                                                                (1)	Month and Monthly Charge exist or
                                                                (2)	Buyer/ Seller charge exist.
                                                                v)	Aggregate Adjustment should be displayed in last line.
                                                                vi)	Verify if only Adhoc Charges are editable and if they are displayed in alphabetical order.
                                                                vii)Total sum should be displayed, it should include sum of Aggregate Adjustment.";

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Othercosts, 10);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.tblOtherCostSubSection_G, 10);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader, 5);
                FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader.FAClick();

                Reports.TestStep = "i) System should display the charges which has months and Monthly charges.";
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(1, "Homeowner's Insurance", true, true, 99, 5600);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 1, "Homeowner's Insurance", (99 * 5600));
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(2, "Mortgage Insurance", true, true, 10);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.G, "Mortgage Insurance", 6700, null, null, null, null, null, false, 56700, 56700.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(3, "Property Taxes", true, true, null, 45756);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 3, "Property Taxes", null, null, null, 34645);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(4, "Property Taxes", true, false, 45);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 4, "Property Taxes", 5600);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(5, "Property Taxes", true, false, null, 45343.50);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 5, "Property Taxes", null, null, null, 3400);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(6, "Adhoc Charge1", true, false, 56, 4560);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.G, "Adhoc Charge1", 3400.50, null, null, 5675.67, null, null, false, 45566.78, 45567.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(7, "Adhoc Charge2", true, false, null, null);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 7, "Adhoc Charge2", 5689.89);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(8, "Adhoc Charge3", true, false, 34, 2345);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 8, "Adhoc Charge3", null);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(9, "Adhoc Charge4", true, false, null, null);
                FastDriver.ClosingDisclosure.VerifyAmount(9, ClosingDisclosureSection.G, "Adhoc Charge4", null, null, null, 324234345.56, null, null, false, 43234.56, 43235.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(10, "Adhoc Charge6", true, false, 0, 6700);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 10, "Adhoc Charge6", null);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(11, "Aggregate Adjustment", true, false, null, null);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 11, "Aggregate Adjustment", -56.50, null, null, -34.44);

                Reports.TestStep = @"Navigate to Good Faith Variance Screen and verify if values are displayed under 0% and 10%
                                                                        i)	System should not display the charges under 0% and 10% ";
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.LenderCreditAnalysis, 10);
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(1, "Non-Specific Lender Credits", 0);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(2, "Specific Lender Credits", 0);
                FastDriver.ClosingDisclosure.VerifyLenderCreditAnalysis(3, "Lender Credits Total (J) Excluding Good Faith Violation", 0);

                Reports.TestStep = @"Select Closing Disclosure tab.
                                                    i) Add Loan Estimate unrounded for Homeowner's Insurance.(E.g. 1243.45)
                                                    ii)	Modify Loan Estimate unrounded for Mortgage Insurance. (E.g. 67890.78)
                                                    iii) Add Loan Estimate rounded amount for Property Taxes in Line G.05. (E.g. 342333.56)
                                                    iv)	Modify Loan Estimate Rounded amount for Adhoc Charge1. (E.g. 23433)
                                                    (1)	Verify if pencil icon is displayed for Property Taxes G.05 and Adhoc charge1.
                                                    v) Add Loan Estimate unrounded for Adhoc Charge2. (E.g. 34534.56)
                                                    vi)	Modify charge description for Adhoc Charge4. (E.g. CD Updated Description)";
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Othercosts, 10);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.tblOtherCostSubSection_G, 10);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader, 5);
                FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader.FAClick();

                Reports.TestStep = "i) Add Loan Estimate unrounded for Homeowner's Insurance.(E.g. 1243.45)";
                FastDriver.ClosingDisclosure.EditLoanEstimateSectionG(1, "Homeowner's Insurance", 1243.45);

                Reports.TestStep = "ii) Modify Loan Estimate unrounded for Mortgage Insurance. (E.g. 67890.78)";
                FastDriver.ClosingDisclosure.EditLoanEstimateSectionG(2, "Mortgage Insurance", 67890.78);

                Reports.TestStep = "iii) Add Loan Estimate rounded amount for Property Taxes in Line G.05. (E.g. 342333.56)";
                FastDriver.ClosingDisclosure.EditLoanEstimateSectionG(5, "Property Taxes", null, 342333.56, false);
                FastDriver.ClosingDisclosure.EditLoanEstimateSectionG(5, "Property Taxes", null, null, true);

                Reports.TestStep = "iv) Modify Loan Estimate Rounded amount for Adhoc Charge1. (E.g. 23433)";
                //Reload the table because it's redrawn when click on it.
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.tblOtherCostSubSection_G.PerformTableAction(1, "Adhoc Charge1", 8, TableAction.SetText, "23433.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                bool isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.tblOtherCostSubSection_G.PerformTableAction(1, "Adhoc Charge1", 8, TableAction.GetCell).Element);
                Support.AreEqual("True", isDisplayed.ToString(), true);
                //FastDriver.ClosingDisclosure.EditLoanEstimateSectionG(6, "Adhoc Charge1", null, 23433, true);

                Reports.TestStep = "v) Add Loan Estimate unrounded for Adhoc Charge2. (E.g. 34534.56)";
                FastDriver.ClosingDisclosure.EditLoanEstimateSectionG(7, "Adhoc Charge2", 34534.56);

                Reports.TestStep = "vi)	Modify charge description for Adhoc Charge4. (E.g. CD Updated Description)";
                //Reload the table because it's redrawn when click on it.
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.tblOtherCostSubSection_G.PerformTableAction(1, "Adhoc Charge4", 1, TableAction.SetText, "CD Updated Description");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "g) Navigate to New Loan | Loan Charge and verify the values in impounds section.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = @"i.1) Verify if Loan Estimate unrounded amount is updated for Homeowner's Insurance (E.g. 1243.45)";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's Insurance", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                Support.AreEqual("$1,243.45", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue());
                Support.AreEqual("$1,243.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = @"i.2) Verify if Loan Estimate unrounded amount is updated for Mortgage Insurance (E.g. 67890.78).";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(1, "Mortgage Insurance", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesmpountPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                Support.AreEqual("$67,890.78", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue());
                Support.AreEqual("$67,891.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = @"i.3) Verify if Loan Estimate unrounded amount is updated for and Adhoc Charge2. (E.g. 34534.56).";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Adhoc Charge2", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                Support.AreEqual("$34,534.56", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue());
                Support.AreEqual("$34,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "ii.1) Verify if PDD if system displays broken icon and loan estimate rounded amount is updated for Annual Assessment (E.g. 342333.56)";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Annual Assessments", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "ii.1) Verify if PDD if system displays broken icon and loan estimate rounded amount is updated for Adhoc Charge1 (E.g. 342333.56)";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Adhoc Charge1", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "iii) Charge description should be modified for Adhoc Charge 4. (E.g. CD Updated Description)";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "CD Updated Description", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                Support.AreEqual("CD Updated Description", FastDriver.PaymentDetailsDlg.Description.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = @"i) City Property Taxes- Months – 78 (1) System should calculate and display Buyer Charge.";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanChargesImpoundsTable, 5);
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.SetText, "78" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = @"ii) County Property Taxes- Months – 50, Monthly Charges -500 (1) System should calculate and display Buyer Charge.";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                //Hack: The modal dialog appear randomly
                try
                {
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.Click);
                    Keyboard.SendKeys("50" + FAKeys.Tab); //Hack: SetText doesn't work
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.SwitchToContentFrame();
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "500" + FAKeys.Tab);
                }
                catch (Exception)
                {
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "50" + FAKeys.Tab);
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "500" + FAKeys.Tab);
                }
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = @"iii) Annual Assessments, Months – 88, Monthly Charges -780. (1) System should display “Do you wish to recalculate the impound charge?” OK/ Cancel. (a) Click “Ok” system should calculate and display Buyer Charge.";
                //FastDriver.NewLoan.UpdateImpoundCharge("Annual Assessments", null, null, null, null, null, 88, 780);
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", "Annual Assessments", "Months", TableAction.SetText, "88" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", "Annual Assessments", "Monthly Charge", TableAction.SetText, "780" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                //string dialogText = FastDriver.WebDriver.HandleDialogMessage();
                //Support.AreEqual("Do you wish to recalculate the impound charge?", dialogText);

                Reports.TestStep = @"iv) Modify “Adhoc Charge1” to “Source Modified Adhoc screen";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateImpoundCharge("Adhoc Charge1", null, null, null, null, null, null, null, "Source Modified Adhoc screen");

                Reports.TestStep = @"v) Modified Buyer Charge (E.g. 4589.56) and Seller Charge (3423.45) for Adhoc Charge2.";
                FastDriver.NewLoan.UpdateImpoundCharge("Adhoc Charge2", 4589.56, null, 3423.45);

                Reports.TestStep = @"vi) Enter Monthly Charges for Adhoc Charge 3(E.g. 7,889.00) and months (E.g. 78) (1) System should display “Do you wish to recalculate the impound charge?” OK/ Cancel. (a) Click “Cancel” system should not change the Buyer Charge.";
                //FastDriver.NewLoan.UpdateImpoundCharge("Adhoc Charge3", null, null, null, null, null, 78, 7889);
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", "Adhoc Charge3", "Months", TableAction.SetText, "78" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", "Adhoc Charge3", "Monthly Charge", TableAction.SetText, "7889" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                //dialogText = FastDriver.WebDriver.HandleDialogMessage(true, false);
                //Support.AreEqual("Do you wish to recalculate the impound charge?", dialogText);

                Reports.TestStep = @"vii) Select Charge for Aggregate Adjustment.";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();

                Reports.TestStep = @"viii) Open PDD for Mortgage Insurance and enter Addition Description (E.g. Addition Description) and check Double Asterisk.";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage Insurance", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("Addition Description");
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true);

                Reports.TestStep = @"ix) Open PDD for Adhoc Charge6 and check Double Asterisk.";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Adhoc Charge6", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true);

                FastDriver.BottomFrame.Done();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void SectionG_Scenario2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var paymentDetailsHomeownersInsurance = new PaymentDetailsParameters()
                {
                    ChargeDescription = "Homeowner's Insurance",
                    LoanEstimateRounded = 34234.45,
                    BuyerAtClosing = 56780.50,
                    BuyerBeforeClosing = 3456.49,
                    BuyerPaidbyOther = 5000.51,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 4950.34,
                    SellerPaidBeforeClosing = 6756.56,
                    SellerPaidbyOthers = 4233.45,
                    SellerPaidbyOtherPaymentMthd = "POC"
                };

                var paymentDetailsCountyPropertyTaxes = new PaymentDetailsParameters()
                {
                    ChargeDescription = "County Property Taxes",
                    LoanEstimateUnrounded = 56777.50,
                    LoanEstimateRounded = 45455.67,
                    BuyerBeforeClosing = 2343.45,
                    BuyerPaidbyOther = 5675.56,
                    BuyerPaidbyOtherPaymentMethod = "POC-L",
                    BuyerDoubleAsteriskChecked = false,
                    SellerPaidBeforeClosing = 6756.56,
                    SellerPaidbyOthers = 3433.34,
                    SellerPaidbyOtherPaymentMthd = "POC-L"
                };

                var paymentDetailsAdhocCharge2 = new PaymentDetailsParameters()
                {
                    ChargeDescription = "Adhoc Charge2",
                    BuyerAtClosing = 100.45,
                    BuyerBeforeClosing = 2345.60,
                    BuyerPaidbyOther = 3478.56,
                    BuyerPaidbyOtherPaymentMethod = "POC-MB",
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 2356.45,
                    SellerPaidBeforeClosing = 2345.56,
                };
                #endregion

                Reports.TestDescription = "Continuation of Test Case 527785: Verify charges in Section G – Line 1 with/without entering values in PDD. - For Automation Purpose";

                Reports.TestStep = "Login to IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with New Lender";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetDetailedCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                #region data setup from scenario 1
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Setup data from previous test case";
                FastDriver.NewLoan.UpdateImpoundCharge("Homeowner's Insurance", months: 99, monthlyCharges: 5600.00, buyerCharge: 554400.00, loanEstimate: 1243.45);
                FastDriver.NewLoan.UpdateImpoundCharge("Mortgage Insurance", months: 10, buyerCharge: 6700.00, sellerCharge: 0, loanEstimate: 67890.78);
                FastDriver.NewLoan.UpdateImpoundCharge("City Property Taxes", months: 78, monthlyCharges: 45756.00, buyerCharge: 3568968, sellerCharge: 34645.00);
                FastDriver.NewLoan.UpdateImpoundCharge("County Property Taxes", months: 50, monthlyCharges: 500.00, buyerCharge: 25000.00);
                FastDriver.NewLoan.UpdateImpoundCharge("Annual Assessments", months: 88, monthlyCharges: 780.00, buyerCharge: 68640.00, sellerCharge: 3400.00);
                FastDriver.NewLoan.AddImpoundCharge("Source Modified Adhoc screen", months: 56, monthlyCharges: 4560, buyerCharge: 3400.50, sellerCharge: 5675.67, loanEstimate: 45566.78);
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge2", buyerCharge: 4589.56, sellerCharge: 3423.45, loanEstimate: 34534.56);
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge3", months: 78, monthlyCharges: 7889.00, buyerCharge: 0);
                FastDriver.NewLoan.AddImpoundCharge("CD Updated Description", sellerCharge: 324234345.56, loanEstimate: 43234.56);
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge5", loanEstimate: 453453454.56);
                FastDriver.NewLoan.AddImpoundCharge("Adhoc Charge6", months: 0, monthlyCharges: 6700.00);

                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCredit.FAClick();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("56.50");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("34.44");

                //Reports.TestStep = @"vii) Select Charge for Aggregate Adjustment.";
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();

                //Reports.TestStep = @"viii) Open PDD for Mortgage Insurance and enter Addition Description (E.g. Addition Description) and check Double Asterisk.";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage Insurance", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("Addition Description");
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true);

                //Reports.TestStep = @"ix) Open PDD for Adhoc Charge6 and check Double Asterisk.";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Adhoc Charge6", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true);

                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "CD Updated Description", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("23433.00");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true);

                FastDriver.BottomFrame.Done();
                Playback.Wait(500);

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                Reports.TestStep = @"Navigate to CD screen and verify the values displayed in Section G.
                i)	System should display Double Asterisk if it is checked in PDD.
                ii)	Aggregate Adjustment should be displayed as positive amount.
                iii)	Other values should be displayed as below screen shot.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Othercosts, 10);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.tblOtherCostSubSection_G, 10);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader, 5);
                FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader.FAClick();
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(1, "Homeowner's Insurance", true, true, 99, 5600);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.G, "Homeowner's Insurance", (99 * 5600));
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(2, "Mortgage Insurance Addition Description", true, true, 10, null, true);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.G, "Mortgage Insurance Addition Description", 6700, null, null, null, null, null, false, 67890.78, 67891);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(3, "Property Taxes", true, true, 78, 45756);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.G, "Property Taxes", 3568968, null, null, 34645);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(4, "Property Taxes", true, false, 50, 500);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.G, "Property Taxes", 25000);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(5, "Property Taxes", true, false, 88, 780);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.G, "Property Taxes", 68640, null, null, 3400);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(6, "Adhoc Charge2", true, false, null, null);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.G, "Adhoc Charge2", 4589.56, null, null, 3423.45, null, null, false, 34534.56, 34535.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(7, "Adhoc Charge3", true, false, 78, 7889);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.G, "Adhoc Charge3", null);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(8, "Adhoc Charge6", true, false, 0, 6700, true);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.G, "Adhoc Charge6", null);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(9, "CD Updated Description", true, false, null, null);
                FastDriver.ClosingDisclosure.VerifyAmount(9, ClosingDisclosureSection.G, "CD Updated Description", null, null, null, 324234345.56, null, null, false, 43234.56, 23433);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(10, "Source Modified Adhoc screen", true, false, 56, 4560);
                FastDriver.ClosingDisclosure.VerifyAmount(10, ClosingDisclosureSection.G, "Source Modified Adhoc screen", 3400.50, null, null, 5675.67, null, null, false, 45566.78, 45567);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(11, "Aggregate Adjustment", true, false, null, null);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 11, "Aggregate Adjustment", 56.50, null, null, 34.44);

                Reports.TestStep = @"Navigate to New Loan Screen and enter values as below.
                    Homeowner's Insurance:
                    i)	Remove Months and Monthly Charges.
                    ii)	Open PDD and enter values as below:
                    (1)	Buyer At Closing = $56,780.50
                    (2)	Buyer Before Closing = $3,456.49
                    (3)	Buyer Paid by Others = $5000.51 (POC)
                    (4)	Seller At Closing = $4950.34
                    (5)	Seller Before Closing = $6756.56
                    (6)	Seller Paid by Others = $4233.45 (POC)
                    (7)	Loan Estimate Unrounded = $34234.45
                    (8)	Loan Estimate Rounded = Auto calculated
                    (9)	Check Double Asterisk checkbox and click on “Done” in PDD. 
                    (a)	Pencil icon should be displayed in source screen.";

                Reports.TestStep = "g) Navigate to New Loan | Loan Charge and verify the values in impounds section.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NewLoan.UpdateImpoundCharge("Homeowner's Insurance", months: 0, monthlyCharges: 0);
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's Insurance", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad(); ;
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(paymentDetailsHomeownersInsurance, false);
                string alertText = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", alertText);

                Reports.TestStep = @"Navigate to New Loan Screen and enter values as below.
                    Mortgage Insurance:
                    iii) Open PDD and remove double asterisk checkbox.
                    (1)	Buyer At Closing = $4500
                    (2)	Buyer Before Closing = $4600
                    (3)	Buyer Paid by Others = $4700 (POC-L) Display (L) checkbox unchecked
                    (4)	Remove Additional Description.";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage Insurance Addition Description", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad(); ;
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("4500");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("4600");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("4700");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLBorrower.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.AdditionalDescription.FASetText("");
                FastDriver.DialogBottomFrame.ClickDone();
                alertText = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", alertText);

                Reports.TestStep = @"City Property Taxes:
                (1)	Remove Months, Monthly Charges, Buyer and Seller Charges.";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", "City Property Taxes", "Months", TableAction.Click);
                FastDriver.NewLoan.UpdateImpoundCharge("City Property Taxes", months: 0, monthlyCharges: 0, buyerCharge: 0, sellerCharge: 0);

                Reports.TestStep = @"County Property Taxes:
                i)	Open PDD and enter values as below:
                (1)	Buyer Before Closing = $2344.45
                (2)	Buyer Paid by Others = $5675.56 (POC-L)
                (3)	Seller Before Closing = $2343.45
                (4)	Seller Paid by Others = $3433.34 (POC-L)
                (5)	Loan Estimate Unrounded = $56777.50
                (6)	Loan Estimate Rounded = $45455.67
                (a)	Broken icon should be displayed near rounded textbox.
                (7)	Click on “Done” in PDD. 
                (a)	Pencil icon should be displayed in source screen.";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "County Property Taxes", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad(); ;
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(paymentDetailsCountyPropertyTaxes, false);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = @"Annual Assessment:
                i)	Remove Months, Monthly Charges, Buyer and Seller Charges.";
                FastDriver.NewLoan.UpdateImpoundCharge("Annual Assessments", months: 0, monthlyCharges: 0, buyerCharge: 0, sellerCharge: 0);

                Reports.TestStep = @"Adhoc Charge2:
                i)	Add Months = 45 and Monthly Charges = 560.
                ii)	Open PDD and enter values as below:
                (1)	Buyer At Closing = $100.45
                (2)	Buyer Before Closing = $2345.60
                (3)	Buyer Paid by Others = $3478.56 (POC-MB)
                (4)	Seller At Closing = $2356.45
                (5)	Seller Before Closing = $2345.56
                (6)	Check Double Asterisk checkbox and click on “Done” in PDD. 
                (a)	Pencil icon should be displayed in source screen.";
                FastDriver.NewLoan.UpdateImpoundCharge("Adhoc Charge2", months: 45, monthlyCharges: 560);
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Adhoc Charge2", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad(); ;
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(paymentDetailsAdhocCharge2, false);
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = @"Adhoc Charge6:
                i)	Open PDD and remove double asterisk checkbox.";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Adhoc Charge6", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad(); ;
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(false);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true);

                Reports.TestStep = @"Aggregate Adjustment: ii)	Select Zero radio button.";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentZero.FAClick();

                Reports.TestStep = @"Navigate to CD screen and verify the values displayed in Section G.
                i)	Since user has only County Property Taxes the same should be displayed in Line 03.
                ii)	Aggregate Adjustment should be blank.
                iii)	Sum of G, I and J should be updated.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Othercosts, 10);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.tblOtherCostSubSection_G, 10);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader, 5);
                FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader.FAClick();
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(1, "Homeowner's Insurance", true, true, null, null, true);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.G, "Homeowner's Insurance", 56780.50, 3456.49, 5000.51, 4950.34, 6756.56, 4233.45);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(2, "Mortgage Insurance", true, true, 10, null);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.G, "Mortgage Insurance", 4500, 4600, 4700, null, null, null, false, 67890.78, 67891.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(3, "Property Taxes", true, true, 50, 500);
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.G, "Property Taxes", 25000, 2343.45, 5675.56, null, 6756.56, 3433.34, false, 56777.50, 45456, true);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(4, "Adhoc Charge2", true, false, 45, 560, true);
                FastDriver.ClosingDisclosure.VerifyAmount(4, ClosingDisclosureSection.G, "Adhoc Charge2", 100.45, 2345.60, 3478.56, 2356.45, 2345.56, null, false);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(5, "Adhoc Charge3", true, false, 78, 7889);
                FastDriver.ClosingDisclosure.VerifyAmount(5, ClosingDisclosureSection.G, "Adhoc Charge3", null);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(6, "Adhoc Charge6", true, false, 0, 6700);
                FastDriver.ClosingDisclosure.VerifyAmount(6, ClosingDisclosureSection.G, "Adhoc Charge6", null);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(7, "CD Updated Description", true, false, null, null);
                FastDriver.ClosingDisclosure.VerifyAmount(7, ClosingDisclosureSection.G, "CD Updated Description", null, null, null, 324234345.56, null, null, false, 43234.56, 23433.00);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(8, "Source Modified Adhoc screen", true, false, 56, 4560);
                FastDriver.ClosingDisclosure.VerifyAmount(8, ClosingDisclosureSection.G, "Source Modified Adhoc screen", 3400.50, null, null, 5675.67, null, null, false, 45566.78, 45567, false);
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(9, "Aggregate Adjustment", true, false, null, null);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 9, "Aggregate Adjustment", 0, null, null, 0);

                Reports.TestStep = @"Remove Description for Adhoc Charge 2 and verify the error message.";
                FastDriver.ClosingDisclosure.EditDescriptionSectionG("Adhoc Charge2", "");
                alertText = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual("Charge Description is required.", alertText);

                Reports.TestStep = @"m)	Navigate to New Loan Screen and modify values as below.
                i)	Open PDD and enter values as below:
                Homeowner's Insurance:
                (1)	Buyer Paid by Others = Payment Method (POC-L) Display (L) checkbox checked
                (2)	Seller Paid by Others = Payment Method (POC-L) Display (L) checkbox checked";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's Insurance", FastDriver.NewLoan.LoanChargesmpountPaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLBorrower.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLSeller.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", "Homeowner's Insurance", "Months", TableAction.SetText, "67");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", "Homeowner's Insurance", "Monthly Charge", TableAction.SetText, "780.00" + Keys.Delete + Keys.Delete + Keys.Delete);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", "Homeowner's Insurance", "Buyer Charge", TableAction.SetText, "65,237.50");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"n)	Verify the values in CD screen. It should be displayed as below:
                i)	(L) Should be displayed for Homeowner's Insurance.
                ii)	PDD values should be displayed for Homeowner's Insurance.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Othercosts, 10);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.tblOtherCostSubSection_G, 10);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader, 5);
                FastDriver.ClosingDisclosure.CalculatingCashToCloseHeader.FAClick();
                FastDriver.ClosingDisclosure.VerifyChargeDecriptionSectionG(1, "Homeowner's Insurance", true, true, 67, 780, true);
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.G, 1, "Homeowner's Insurance", 56780.50, 3456.49, 5000.51, 4950.34, 6756.56, 4233.45, true);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
