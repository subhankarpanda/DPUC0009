﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using FASTWCFHelpers.FastFileService;
using System.Globalization;
using OpenQA.Selenium;
using System.IO;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using iTextSharp.text.pdf;
using System.Text;
using iTextSharp.text.pdf.parser;
using System.Runtime.InteropServices;


namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]
    public class CD_Sanity_PDF_Comparision : MasterTestClass
    {
        public CD_Sanity_PDF_Comparision()
        {
        }

        #region CD_Workflow01
        [TestMethod]
        public void CD_Workflow01()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow01";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[1] = null;
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01"); // 182156438; // BusinessSourceGABcode IDCode = CDSETT01
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)180000;
                fileRequest.File.FirstNewLoanAmount = null;
                fileRequest.File.FirstNewLoanLiabilityAmount = null;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                                                                {
                                                                    BuyerSellerAddressTypeCdID = 80,
                                                                    AddrLine1 = "123 Anywhere Street",
                                                                    City = "Fort Gaines",
                                                                    State = "GA",
                                                                    Zip = "39851",
                                                                    Country = "USA"
                                                                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 444, // Cal Vet
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)162000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"), //181752801, //ID Code = CDLEND01
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 7, TableAction.SetText, "162,000.00" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.44" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "261.60" + FAKeys.Tab);
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.25" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "300.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "7486.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "1097.00" + FAKeys.Tab);

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20);

                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("29.80");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("29.80");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information, Inc.");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("2" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("164.70" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("164.70" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("80.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("80.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("31.75" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("31.75" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                rowCount = FastDriver.NewLoan.NewLoanChargesTable.GetRowCount();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Tax Monitoring Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.SaveAndReloadLoanChargesScreen();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Tax Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("75.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("75.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Cain, Joseph");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5700" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Green, Samuel");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5700" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.Attention.FASelectItem("Arnold, Sarah");
                //These charges are not exact match with codedUI, create adhoc charges

                if (FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FeeExistOnTable("Title - Settlement Agent Fee"))
                {
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                }
                else
                {
                    rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Agent Fee");
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                    //Create new row
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 7, TableAction.Click);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                if (FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FeeExistOnTable("Title - Lender's Coverage Premium"))
                {
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                }
                else
                {
                    rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium");
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                    //Create new row
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 7, TableAction.Click);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                if (FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FeeExistOnTable("Title - Owner's Title Insurance"))
                {
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Owner's Title Insurance", 3, TableAction.SetText, "1000.00" + FAKeys.Tab);
                }
                else
                {
                    rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Owner's Title Insurance" + FAKeys.Tab);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Owner's Title Insurance", 3, TableAction.SetText, "1000.00" + FAKeys.Tab);
                    //Create new row
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Owner's Title Insurance", 7, TableAction.Click);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                if (FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FeeExistOnTable("Title - Title Search"))
                {
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Search", 3, TableAction.SetText, "800.00" + FAKeys.Tab);
                }
                else
                {
                    rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Title Search");
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Search", 3, TableAction.SetText, "800.00" + FAKeys.Tab);
                    //Create new row
                    FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Search", 7, TableAction.Click);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                if (FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.FeeExistOnTable("Title - Title Insurance Binder"))
                {
                    FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(1, "Title - Title Insurance Binder", 3, TableAction.SetText, "650.00" + FAKeys.Tab);
                }
                else
                {
                    rowCount = FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.GetRowCount();
                    FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Title Insurance Binder");
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                    FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(1, "Title - Title Insurance Binder", 3, TableAction.SetText, "650.00" + FAKeys.Tab);
                }

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.RecordingandTax.FAClick();

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("City Documentary Transfer Tax");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "City Documentary Transfer Tax", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "City Documentary Transfer Tax", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "City Documentary Transfer Tax", 4, TableAction.SetText, "0" + FAKeys.Tab);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "City Documentary Transfer Tax", 5, TableAction.SetText, "950" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(@"Record Additional Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record Additional Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Deed of Trust/Mortgage", 4, TableAction.SetText, "45" + FAKeys.Tab);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Deed of Trust/Mortgage", 5, TableAction.SetText, "0" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(@"Record Additional Grant/Warranty Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 4, TableAction.SetText, "40" + FAKeys.Tab);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 5, TableAction.SetText, "0" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("CDSETT01");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AmountDues.FASetText("72.26");
                FastDriver.HomeownerAssociation.FromDate.FASetText("08-17-2015");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2015");
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Capital Contribution", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("HOA Acre Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("500.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("500.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Servicing Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("HOA Acre Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Home Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                try
                {
                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Engineers Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                catch (Exception) // Sometimes the charges are disabled, try again
                {
                    FastDriver.DialogBottomFrame.ClickDone();

                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                    FastDriver.HomeownerAssociation.WaitForScreenToLoad();

                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Engineers Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                //Create new row
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Home Warranty Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                try
                {
                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Warranty Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("XYZ Warranty Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("450.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("450.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                catch (Exception) // Sometimes the charges are disabled, try again
                {
                    FastDriver.DialogBottomFrame.ClickDone();

                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                    FastDriver.HomeownerAssociation.WaitForScreenToLoad();

                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Warranty Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("XYZ Warranty Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("450.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("450.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("CDSETT01");
                FastDriver.InspectionRepairPest.Find.FAClick();

                rowCount = FastDriver.InspectionRepairPest.InspectionRepairChargesTable.GetRowCount();
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Pest Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.InspectionRepairPest.SaveAndReloadScreen();
                try
                {
                    FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Inspection Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Pest Co." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("120.50" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("120.50" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                catch (Exception) // Sometimes the buyer charge textbox is disabled
                {
                    FastDriver.DialogBottomFrame.ClickDone();

                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                    FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                    FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Inspection Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Pest Co." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("120.50" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("120.50" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }



                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1209.96");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("1209.96");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("30561A65");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.Attention.FASelectItem("LIGHTFOOT, CYNTHIA");
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Prorotion | Tax
                Reports.TestStep = "Navigate to Prorotion | Tax Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.FromDate.FASetText("01-01-2015");
                FastDriver.ProrationDetail.ToDate.FASetText("08-17-2015");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("758.62" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCharge.FASetText("758.62" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("8828737");
                FastDriver.SurveyDetail.Find.FAClick();

                rowCount = FastDriver.SurveyDetail.SurveyChargesTable.GetRowCount();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Survey Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SurveyDetail.SaveAndReloadScreen();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Surveys Co" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("85.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("85.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("");
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText("");
                FastDriver.ClosingDisclosure.Done.FAClick();
                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("3.875");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("{DEL}");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.LoanTerm_PP_plusIcon.FAClick();
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_check.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PP_MaxAmmount.FAClick();
                Keyboard.SendKeys("3240");
                FastDriver.ClosingDisclosure.LoanTerm_PP_Expiration_Year.FASetText("2");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();
                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("2");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("7");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.OnlyInterestRadioButton1.FAClick();
                FastDriver.MinMaxDialog.OnlyInterestTextBox1.FASetText("761.78");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.WaitCreation(FastDriver.CD.PrincipalInterestSecondColumnplusIcon, 5);
                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.WaitCreation(FastDriver.MinMaxDialog.PrincipalandInterestTextbox, 5);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("761.78");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("82.35");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("361.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true); 
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.NonEscrowedPropertyCostsOverYear1SpanR2C2.FASetText("1920");
                FastDriver.CD.LoanCalculationHeader.FAClick();

                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow01Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_01_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow01Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow01Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_01_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_01_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow01Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow02
        [TestMethod]
        public void CD_Workflow02()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow02";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[1] = null;
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.SalesPriceAmount = (decimal)180000;
                fileRequest.File.FirstNewLoanAmount = (decimal)150000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanAmount = null;
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)180000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 444, // Cal Vet
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)162000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                //FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                //FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("");
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("180000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                //FastDriver.TermsDatesStatus.SettlementDate.FASetText("");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                //FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "162,000.00" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.71" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "261.60" + FAKeys.Tab);
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.5" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "250.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 5, TableAction.SetText, "4531.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 3, TableAction.SetText, "450.00" + FAKeys.Tab);

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.HandleDialogMessage(true, true, 20);


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information, Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("30.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("30.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("45.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("45.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                rowCount = FastDriver.NewLoan.NewLoanChargesTable.GetRowCount();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Tax Monitoring Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.SaveAndReloadLoanChargesScreen();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Tax Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("65.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("65.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                //FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 6, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "164.70" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 6, TableAction.SetText, "164.70" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 5, TableAction.SetText, "201.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 6, TableAction.SetText, "201.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("CDLEND01");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("115000");
                FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FASetText("115000");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Outside Escrow Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT02");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT02");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Agent Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 3, TableAction.SetText, "350.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Title Search");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Search", 3, TableAction.SetText, "200.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Search", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "250.50" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.RecordingandTax.FAClick();

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Modification of Deed of Trust");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 4, TableAction.SetText, "60" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("8336475");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AmountDues.FASetText("72.26");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("9006575");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1209.96");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();
                FastDriver.InsuranceFire.FireBuyerCharge.FASetText("1209.96");
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("30561A65");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("8828737");
                FastDriver.SurveyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("");
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText("");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.25");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("737.91");

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("2");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("7");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.OnlyInterestRadioButton1.FAClick();
                FastDriver.MinMaxDialog.OnlyInterestTextBox1.FASetText("761.78");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("761.78");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("82.35");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("201.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow02Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_02_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow02Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow02Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_02_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_02_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow02Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow03
        [TestMethod]
        public void CD_Workflow03()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow03";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[1] = null;
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.SalesPriceAmount = null;
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)180000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 444, // Cal Vet
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)162000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("240000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "211,000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Adjustable Interest Rate"); //Intest Type
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("23.44" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "351.60" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.0" + FAKeys.Tab);

                //Credit/Charge Points Table
                FastDriver.NewLoan.CreditChargePointsTable.PerformTableAction(1, "% of Loan Amount (Points)", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("5488.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("5488.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("2110.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("2110.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Origination Charges Table

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "750.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 5, TableAction.SetText, "750.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Field Review", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information, Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("161.77" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("162.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("1" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("161.77" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("161.77" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Escrow Waiver Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("0.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("CDLEND01");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("183000");
                FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FASetText("135000");

                rowCount = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.GetRowCount();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Pay down credit card balance");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PayoffLoanCharges.SaveAndReloadScreen();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Pay down credit card balance", 3, TableAction.SetText, "5000.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Cain, Joseph");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5700" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Green, Samuel");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5700" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Agent Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 3, TableAction.SetText, "350.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "800.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Title Search");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Search", 3, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.RecordingandTax.FAClick();

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Modification of Deed of Trust");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 4, TableAction.SetText, "145" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("8336475");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AmountDues.FASetText("72.26");

                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Pay off mechanic's lien");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Pay off mechanic's lien", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Bob's Home Improvement" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("12000.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("12000.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("12000.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("12000.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("9006575");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1800.00");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Insurance Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("30561A65");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.Attention.FASelectItem("LIGHTFOOT, CYNTHIA");

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Clay County" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("706.86" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("706.86" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("8828737");
                FastDriver.SurveyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad(); ;
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("");
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"5/3");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("1007.35");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"1870");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                FastDriver.CD.YearRangeFourthUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("1007.35");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1029.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1451.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1870.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("161.77");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("161.77");
                FastDriver.CD.MortgageInsThirdColumnAmount.FASetText("161.77");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("284.00");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.AllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.NoPartialPayments.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.WillNotHaveEscrowAccountChkBox.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.YouDeclinedChkBox.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow03Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_03_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow03Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow03Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_03_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_03_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow03Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow04
        [TestMethod]
        public void CD_Workflow04()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow04";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1] = null; // No Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)240000;
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanAmount = null;
                fileRequest.File.FirstNewLoanLiabilityAmount = null;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to Other
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to Other
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 444, // Cal Vet
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)162000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"), //181752801, //ID Code = CDLEND01
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("240000.00");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 7, TableAction.SetText, "211,000.00" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Adjustable Interest Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("23.44" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "351.60" + FAKeys.Tab); //Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1" + FAKeys.Tab);

                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "12952.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "300.00" + FAKeys.Tab);

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information, Inc.");
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("1" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("135.39" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("135.39" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-360.39" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "150.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "300.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 7, TableAction.SetText, "300.00" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "135.39" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "270.78" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 7, TableAction.SetText, "270.78" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "117.81" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 5, TableAction.SetText, "235.62" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 7, TableAction.SetText, "235.62" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("CDLEND01");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText("1000000");

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("17200" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("7200" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Examination Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Examination Fee", 3, TableAction.SetText, "800.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Examination Fee", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Agent Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.RecordingandTax.FAClick();

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Modification of Deed of Trust");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 4, TableAction.SetText, "40.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(@"Record Additional Grant/Warranty Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 4, TableAction.SetText, "145.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(@"Transfer Taxes"); // Can't find "Transfer Tax - Miscellaneous"
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Transfer Taxes", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Transfer Taxes", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Transfer Taxes", 5, TableAction.SetText, "1440.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("8336475");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AmountDues.FASetText("72.26");
                FastDriver.HomeownerAssociation.FromDate.FASetText("08-24-2015");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-31-2015");
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Home Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                try
                {
                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("HOA Acre Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("850.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("850.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                catch (Exception)
                {
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                    FastDriver.HomeownerAssociation.WaitForScreenToLoad();

                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("HOA Acre Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("850.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("850.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                //Create new row
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Home Warranty Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                try
                {
                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Warranty Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("XYZ Warranty Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                catch (Exception)
                {
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                    FastDriver.HomeownerAssociation.WaitForScreenToLoad();

                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Warranty Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("XYZ Warranty Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Special Assessment", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("HOA Acre Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("500.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("500.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                //Create new row
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Warranty Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Mold Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                try
                {
                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Mold Inspection Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("to Engineers Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("450.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("450.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                catch (Exception)
                {
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                    FastDriver.HomeownerAssociation.WaitForScreenToLoad();

                    FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Mold Inspection Fee", 1, TableAction.DoubleClick);
                    FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                    FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                    FastDriver.PaymentDetailsDlg.PayeeName.FASetText("to Engineers Inc." + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("450.00" + FAKeys.Tab);
                    FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("450.00" + FAKeys.Tab);
                    FastDriver.DialogBottomFrame.ClickDone();
                }

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText("67.75" + FAKeys.Tab);
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText("67.75" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("9006575");
                FastDriver.InspectionRepairPest.Find.FAClick();

                rowCount = FastDriver.InspectionRepairPest.InspectionRepairChargesTable.GetRowCount();
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Pest Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.InspectionRepairPest.SaveAndReloadScreen();
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Pest Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("200.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("200.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1209.96");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Insurance Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("30561A65");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Clay County" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("706.86" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("706.86" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("8828737");
                FastDriver.SurveyDetail.Find.FAClick();

                rowCount = FastDriver.SurveyDetail.SurveyChargesTable.GetRowCount();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Survey Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SurveyDetail.SaveAndReloadScreen();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Surveys Co" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("385.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("385.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("");
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"5/3");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("1007.35");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"1870");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                FastDriver.CD.YearRangeFourthUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("1007.35");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1229.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1451.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1870.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("135.39");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("135.39");
                FastDriver.CD.MortgageInsThirdColumnAmount.FASetText("135.39");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("267.81");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("267.81");
                FastDriver.CD.EstEscrowThirdColumnAmount.FASetText("267.81");
                FastDriver.CD.EstEscrowFourthColumnAmount.FASetText("267.81");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("417.81");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.PropertyTaxesDropDown.FASelectItem("YES");
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeOwnerassociationDropDown.FASelectItem("YES");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.NonEscrowedPropertyCostsOverYear1SpanR2C2.FASetText("1800");
                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow04Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_04_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow04Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow04Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_04_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_04_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow04Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow05
        [TestMethod]
        public void CD_Workflow05()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow05";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.SalesPriceAmount = (decimal)180000;
                fileRequest.File.FirstNewLoanAmount = (decimal)150000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)150000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "123 Anywhere Street";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 441, // FHA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)150000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("150000");
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("180000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-25-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "150,000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.71" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "265.65" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.5" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information, Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("30.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("30.00");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                rowCount = FastDriver.NewLoan.NewLoanChargesTable.GetRowCount();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Tax Monitoring Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.SaveAndReloadLoanChargesScreen();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Tax Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("65.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("65.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("45.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Lender Credits Section
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LenderCreditsIcon.FAClick(); // Expand Lender Credits section
                FastDriver.NewLoan.LenderCreditsTable.PerformTableAction(1, "Non-Specific Lender Credits", 4, TableAction.SetText, "500.00" + FAKeys.Tab);

                //Impounds section
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "164.70" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 5, TableAction.SetText, "201.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                rowCount = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.GetRowCount();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Pay off existing loan");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PayoffLoanCharges.SaveAndReloadScreen();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Pay off existing loan", 3, TableAction.SetText, "115,000.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "50" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "250" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Settlement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 4, TableAction.SetText, "350" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.FileFees.SwitchToContentFrame();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Title Search Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 4, TableAction.SetText, "200" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "60" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("8336475");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AmountDues.FASetText("72.26");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("9006575");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();

                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("8692935");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1209.96");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Insurance Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("8828737");
                FastDriver.SurveyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("");
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.25");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("737.91");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("NO");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("NO");

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("1");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("737.91");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("82.35");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("201.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.PropertyTaxesDropDown.FASelectItem("YES");
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeOwnerassociationDropDown.FASelectItem("YES");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText("08-18-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-25-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-25-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow05Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_05_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow05Generated);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Playback.Wait(5000);

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow05Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_05_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_05_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow05Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow06
        [TestMethod]
        public void CD_Workflow06()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow06";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)180000;
                fileRequest.File.FirstNewLoanAmount = (decimal)162000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)162000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to Other
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to Other
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 441, // FHA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)162000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"), //181752801, //ID Code = CDLEND01
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("162000.00");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 7, TableAction.SetText, "211,000.00" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.44" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "261.60" + FAKeys.Tab); //Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.25" + FAKeys.Tab);

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information, Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("29.80" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("29.80" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("1" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("270.78" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("270.78" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "164.70" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 5, TableAction.SetText, "201.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesTable.PerformTableAction(1, "Principal Balance", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payoff of First Mortgage Loan" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("100000.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("100000.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5700" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("7200" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "650" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "500" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Owner's Coverage Premium (optional)");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 4, TableAction.SetText, "1000" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Settlement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 4, TableAction.SetText, "500" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Title Search Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 4, TableAction.SetText, "800" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 4, TableAction.SetText, "40" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "45" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Transfer Taxes");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Transfer Taxes", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Transfer Taxes", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Transfer Taxes", 4, TableAction.SetText, "950" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOAACRE");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Capital Contribution", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("500.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("500.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Servicing Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("PESTCO");
                FastDriver.InspectionRepairPest.Find.FAClick();

                rowCount = FastDriver.InspectionRepairPest.InspectionRepairChargesTable.GetRowCount();
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Pest Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.InspectionRepairPest.SaveAndReloadScreen();
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("120.50" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("120.50" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();

                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("8692935");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("SURVCO");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("85.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("85.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("3.875");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("761.78");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("NO");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("NO");

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("1");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("761.78");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("82.35");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("201.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.PropertyTaxesDropDown.FASelectItem("YES");
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeOwnerassociationDropDown.FASelectItem("YES");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.AllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.NonEscrowedPropertyCostsOverYear1SpanR2C2.FASetText("1800");
                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow06Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_06_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow06Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow06Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_06_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_06_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow06Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow07
        [TestMethod]
        public void CD_Workflow07()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow07";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1] = null; // No Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                //fileRequest.File.SalesPriceAmount = (decimal)180000;
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)211000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers = null; //No sellers
                //fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                //fileRequest.File.Sellers[0].Type = "Husband and Wife";
                //fileRequest.File.Sellers[0].FirstName = "Steve";
                //fileRequest.File.Sellers[0].LastName = "Cole";
                //fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                //fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                //fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                //{
                //    BuyerSellerAddressTypeCdID = 80,
                //    AddrLine1 = "123 Anywhere Street",
                //    City = "Fort Gaines",
                //    State = "GA",
                //    Zip = "39851",
                //    Country = "USA"
                //};
                //fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 441, // FHA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)150000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("211000");
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("240000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "211000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Adjustable Interest Rate"); //Intest Type
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("23.44" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-21-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "257.84" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "750.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 5, TableAction.SetText, "6400.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information, Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Escrow Waiver Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("1");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("161.77" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("161.77" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Field Review", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Lender Credits Section
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LenderCreditsIcon.FAClick(); // Expand Lender Credits section
                FastDriver.NewLoan.LenderCreditsTable.PerformTableAction(1, "Non-Specific Lender Credits", 4, TableAction.SetText, "500.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                rowCount = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.GetRowCount();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Pay off existing loan");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PayoffLoanCharges.SaveAndReloadScreen();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Pay off existing loan", 3, TableAction.SetText, "183000.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.Attention.FASelectItem("Arnold, Sarah");
                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Document Preparation Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Document Preparation Fee", 3, TableAction.SetText, "350.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Document Preparation Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "800.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Agent Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Agent Fee", 3, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Modification of Deed of Trust");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 4, TableAction.SetText, "145" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("9006575");
                FastDriver.InspectionRepairPest.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();

                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1800.00");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Insurance Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CDLEND01");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.Attention.FASelectItem("Smith, Joe");

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Clay County");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("804.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("804.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("8828737");
                FastDriver.SurveyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("");
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"5/3");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("1007.35");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"1870");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                FastDriver.CD.YearRangeFourthUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("1007.35");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1229.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1451.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1870.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("161.77");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("161.77");
                FastDriver.CD.MortgageInsThirdColumnAmount.FASetText("161.77");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("284.00");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.PropertyTaxesDropDown.FASelectItem("NO");
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeOwnerassociationDropDown.FASelectItem("NO");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.AllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.NoPartialPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WillNotHaveEscrowAccountChkBox.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.YouDeclinedChkBox.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-25-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow07Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_07_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow07Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow07Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_07_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_07_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow07Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow08
        [TestMethod]
        public void CD_Workflow08()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow08";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1] = null; // no Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE";
                fileRequest.File.SalesPriceAmount = (decimal)240000;
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)211000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to Other
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to Other
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 441, // FHA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)162000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"), //181752801, //ID Code = CDLEND01
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("240000.00");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 7, TableAction.SetText, "211000.00" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Adjustable Interest Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("23.44" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "351.6" + FAKeys.Tab); //Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "13070.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "300.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information, Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("1" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("161.77" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("161.77" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-360.39" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "150.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "300.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 7, TableAction.SetText, "150.00" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "135.39" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "270.78" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 7, TableAction.SetText, "270.78" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 4, TableAction.SetText, "134.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 5, TableAction.SetText, "268.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 7, TableAction.SetText, "268.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("CDLEND01");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesTable.PerformTableAction(1, "Principal Balance", 5, TableAction.SetText, "100000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Cain, Joseph");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("7200" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Green, Samuel");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("7200" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Charge" + FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Charge", 3, TableAction.SetText, "800.00" + FAKeys.Tab);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "800.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Closing Protection Letter Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Closing Protection Letter Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.RecordingandTax.FAClick();

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Modification of Deed of Trust");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 4, TableAction.SetText, "145" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record Additional Grant/Warranty Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Additional Grant/Warranty Deed", 4, TableAction.SetText, "40" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("8336475");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AmountDues.FASetText("67.75");
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();

                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Home Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("HOA Acre Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("850.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("850.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                //Create new row
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Home Warranty Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Warranty Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Engineers Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("500.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("500.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                //Create new row
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Warranty Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Homeowners Assoc. Special Assessment");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Homeowners Assoc. Special Assessment", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("HOA Acre Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("500.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("500.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                //Create new row
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Homeowners Assoc. Special Assessment", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Mold Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Mold Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Inspector Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("450.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("450.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText("67.75" + FAKeys.Tab);
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText("67.75" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("9006575");
                FastDriver.InspectionRepairPest.Find.FAClick();

                rowCount = FastDriver.InspectionRepairPest.InspectionRepairChargesTable.GetRowCount();
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Pest Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.InspectionRepairPest.SaveAndReloadScreen();
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Pest Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("200.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("200.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();

                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1209.96");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 3, TableAction.SetText, "1800.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("30561A65");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Clay County" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("804.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("804.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("8828737");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Surveys Co" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("385.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("385.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"5/3");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.000");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("737.91");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"1870");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                FastDriver.CD.YearRangeFourthUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("1007.35");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1229.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1451.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1870.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("135.39");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("135.39");
                FastDriver.CD.MortgageInsThirdColumnAmount.FASetText("135.39");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("284");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("284");
                FastDriver.CD.EstEscrowThirdColumnAmount.FASetText("284");
                FastDriver.CD.EstEscrowFourthColumnAmount.FASetText("284");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("434");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.NonEscrowedPropertyCostsOverYear1SpanR2C2.FASetText("1800");
                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow08Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_08_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow08Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow08Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_08_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_08_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow08Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow09
        [TestMethod]
        public void CD_Workflow09()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow09";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALECONSLN"; // Sale w/Constuction Loan
                fileRequest.File.SalesPriceAmount = (decimal)180000;
                fileRequest.File.FirstNewLoanAmount = (decimal)162000; //TermsDatesNewLoanAmnt
                //fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)150000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "456 Somewhere Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 51, Type = "Business Entity", Name = "Steve Cole Builder" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 441, // FHA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)150000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("180000");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.TermsDatesStatus.SettlementDate.FASetText("08-17-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Conv-Insured");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "162,000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("360");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.44" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "261.6" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.25" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "300.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "8054.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "1097.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("164.70" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("164.70" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Examination Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 4, TableAction.SetText, "800" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "650" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "500" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Owner's Coverage Premium (optional)");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 4, TableAction.SetText, "1000" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "45" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOAACRE");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.FromDate.FASetText("08-17-2015");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-31-2015");
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Capital Contribution", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("500.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("500.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Servicing Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Home Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Engineers Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                //Create new row
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Inspection Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Home Warranty Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Warranty Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("XYZ Warranty Inc." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("450.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("450.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("PESTCO");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Repair", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("120.50" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("120.50" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair | Other
                Reports.TestStep = "Navigate to Other Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.GABcode.FASetText("ENGINC");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("750.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 3, TableAction.SetText, "1209.96" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("542.70" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("542.70" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Proration | Tax
                Reports.TestStep = "Navigate to Proration | Tax Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.FromDate.FASetText("01-01-2015");
                FastDriver.ProrationDetail.ToDate.FASetText("08-17-2015");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("758.62");
                FastDriver.ProrationDetail.SellerCharge.FASetText("758.62");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Proration | Miscellaneous
                Reports.TestStep = "Navigate to Proration | Miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<ProrationMisc>(@"Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").WaitForScreenToLoad();
                FastDriver.ProrationMisc.Miscellaneous1.FAClick();
                FastDriver.ProrationMisc.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.FromDate.FASetText("08-17-2015");
                FastDriver.ProrationDetail.ToDate.FASetText("08-31-2015");
                FastDriver.ProrationDetail.BuyerCharge.FASetText("72.26");
                FastDriver.ProrationDetail.SellerCredit.FASetText("72.26");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("SURVCO");
                FastDriver.SurveyDetail.Find.FAClick();

                rowCount = FastDriver.SurveyDetail.SurveyChargesTable.GetRowCount();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Survey Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SurveyDetail.SaveAndReloadScreen();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("85.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("85.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("31");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("3.875");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("261.57");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("NO");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_InterestOnly_Year.FASetText(@"2");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("1");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("31");
                Playback.Wait(1000);

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("361.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.OthersChkBox.FASetCheckbox(false);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow09Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_09_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow09Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow09Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_09_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_09_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow09Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow10
        [TestMethod]
        public void CD_Workflow10()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow10";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "LOAN"; // Equity Loan
                fileRequest.File.FirstNewLoanAmount = (decimal)150000; //TermsDatesNewLoanAmnt
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "123 Anywhere Street";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "123 Anywhere Street";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Clay";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "92701";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers = null; // No sellers
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 441, // FHA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)150000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("180000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Conv-Insured");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("009874513");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "150,000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.71" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "265.65" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.50" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "250.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 3, TableAction.SetText, "450.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("30.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("30.00");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00");
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 6, TableAction.SetText, "5099.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("115000");
                FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FASetText("120000");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Document Preparation Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Document Preparation Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Document Preparation Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Document Preparation Fee", 4, TableAction.SetText, "350" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "50" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "250.50" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Settlement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 4, TableAction.SetText, "200" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "60" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 3, TableAction.SetText, "1209.96" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("30");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.25");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("737.91");

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("2");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("4");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("737.91");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("737.91");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("82.35");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("201.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow10Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_10_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow10Generated);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Playback.Wait(5000);

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow10Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");


                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_10_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_10_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow10Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow11
        [TestMethod]
        public void CD_Workflow11()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow11";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI"; // Refinance
                fileRequest.File.FirstNewLoanAmount = (decimal)150000; //TermsDatesNewLoanAmnt
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "123 Anywhere Street";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "123 Anywhere Street";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };

                //Sellers
                fileRequest.File.Sellers = null;
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 441, // FHA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)150000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("180000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Conv-Insured");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("009874513");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "150,000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.71" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "265.65" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.5" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "250.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 3, TableAction.SetText, "450.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("30.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("30.00");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Tax Service", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("65.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("65.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("45.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("45.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Lender Credits Section
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LenderCreditsIcon.FAClick(); // Expand Lender Credits section
                FastDriver.NewLoan.LenderCreditsTable.PerformTableAction(1, "Non-Specific Lender Credits", 5, TableAction.SetText, "500.00" + FAKeys.Tab);

                //Impounds section
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("115000.00");
                FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FASetText("120000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Settlement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 4, TableAction.SetText, "350" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Title Search Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 4, TableAction.SetText, "200" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "250.50" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "60" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 3, TableAction.SetText, "1209.96" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("5");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"Year 5 Balloon");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.25");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("737.91");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown.FASelectItemBySendingKeys("YES");
                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("2");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("4");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("737.91");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("136949.41");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("135.39");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("351.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.NonEscrowedPropertyCostsOverYear1SpanR2C2.FASetText("1800");
                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow11Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_11_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow11Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow11Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_11_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_11_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow11Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow12
        [TestMethod]
        public void CD_Workflow12()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow12";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE"; // Sale w/Mortgage
                fileRequest.File.SalesPriceAmount = (decimal)180000;
                fileRequest.File.FirstNewLoanAmount = (decimal)162000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)162000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "213 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "213 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 51, Type = "Business Entity", Name = "Steve Cole Builder" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 442, // VA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)162000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("162000");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "162000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.440000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "261.60" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.250" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "3,645.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Lender Fee", 3, TableAction.SetText, "2,025.00" + FAKeys.Tab);
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "VA Funding Fee" + FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.SaveAndReloadLoanChargesScreen();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "VA Funding Fee", 3, TableAction.SetText, "2,025.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("29.80");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("29.80");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Tax Service", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("75.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("75.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("80.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("80.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("31.75" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("31.75" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 5, TableAction.SetText, "201.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("Principal Balance");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText("100000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Cain, Joseph");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5700" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Green, Samuel");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5700" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "650" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Owner's Coverage Premium (optional)");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 4, TableAction.SetText, "1000.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "500.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Title Search Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 4, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "45.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 4, TableAction.SetText, "40.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("State Documentary Transfer Tax");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "State Documentary Transfer Tax", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "State Documentary Transfer Tax", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "State Documentary Transfer Tax", 5, TableAction.SetText, "950.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOAACRE");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Capital Contribution", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("500.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("500.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Servicing Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Warranty
                Reports.TestStep = "Navigate to Home Warranty Screen";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("XYZHOME");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();

                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(1, "Home Warranty", 4, TableAction.SetText, "450.00" + FAKeys.Tab);
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(1, "Home Warranty", 5, TableAction.SetText, "8054.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("PESTCO");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Repair", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Pest Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("120.50" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("120.50" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair | Other
                Reports.TestStep = "Navigate to Other Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.GABcode.FASetText("ENGINC");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 3, TableAction.SetText, "1209.96" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("SURVCO");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("85.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("85.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("30");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("3.875");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("761.78");

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("1");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("761.78");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("361.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true); // This has been disabled for 9.8 release
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.NonEscrowedPropertyCostsOverYear1SpanR2C2.FASetText("1800");
                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow12Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_12_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow12Generated);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Playback.Wait(5000);

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow12Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_12_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_12_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow12Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow13
        [TestMethod]
        public void CD_Workflow13()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow13";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE"; // Sale w/Mortgage
                fileRequest.File.SalesPriceAmount = (decimal)240000;
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)211000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "213 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "213 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 51, Type = "Business Entity", Name = "Steve Cole Builder" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 442, // VA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)162000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("211000");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-20-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "211000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("23.440000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "351.60" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.000" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "4,747.50" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Lender Fee", 3, TableAction.SetText, "2,110.00" + FAKeys.Tab);
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "VA Funding Fee" + FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.SaveAndReloadLoanChargesScreen();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "VA Funding Fee", 3, TableAction.SetText, "2,637.50" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("705.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("705.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-360.39" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "150.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "300.00" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 4, TableAction.SetText, "134.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 5, TableAction.SetText, "268.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Cain, Joseph");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("7200" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Green, Samuel");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("7200" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Examination Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 4, TableAction.SetText, "800" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "900" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Owner's Coverage Premium (optional)");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 4, TableAction.SetText, "1500.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Title Search Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Title Search Fee", 4, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "145.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 4, TableAction.SetText, "40.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("State Documentary Transfer Tax");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "State Documentary Transfer Tax", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "State Documentary Transfer Tax", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "State Documentary Transfer Tax", 5, TableAction.SetText, "1,440.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOAACRE");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.BottomFrame.Done();

                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Servicing Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("500.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("500.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText("67.75" + FAKeys.Tab);
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText("67.75" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Warranty
                Reports.TestStep = "Navigate to Home Warranty Screen";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("XYZHOME");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();

                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(1, "Home Warranty", 5, TableAction.SetText, "750.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("PESTCO");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Repair", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("200.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("200.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair | Other
                Reports.TestStep = "Navigate to Other Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.GABcode.FASetText("ENGINC");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("850.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("850.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairOther.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.InspectionRepairOther.WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.GABcode.FASetText("ENGINC");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.PerformTableAction(1, "Mold Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("450.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("450.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairOther.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("804.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("804.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("SURVCO");
                FastDriver.SurveyDetail.Find.FAClick();

                var temp = FastDriver.SurveyDetail.SurveyChargesTable.Text;

                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("385.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("385.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("30");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"5/3");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("1007.35");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"1870");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown.FASelectItemBySendingKeys("YES");
                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("1007.35");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1229.61" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1451.21" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1870.15" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("284.00");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("284.00");
                FastDriver.CD.EstEscrowThirdColumnAmount.FASetText("284.00");
                FastDriver.CD.EstEscrowFourthColumnAmount.FASetText("284.00");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("434.00");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow13Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_13_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow13Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow13Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_13_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_13_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow13Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow14
        [TestMethod]
        public void CD_Workflow14()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow14";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI"; // Refinance
                //fileRequest.File.SalesPriceAmount = (decimal)240000;
                fileRequest.File.FirstNewLoanAmount = (decimal)150000; //TermsDatesNewLoanAmnt
                //fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)211000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "123 Anywhere Street";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "123 Anywhere Street";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers = null;
                //fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                //fileRequest.File.Sellers[0].Type = "Husband and Wife";
                //fileRequest.File.Sellers[0].FirstName = "Steve";
                //fileRequest.File.Sellers[0].LastName = "Cole";
                //fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                //fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                //fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                //{
                //    BuyerSellerAddressTypeCdID = 80,
                //    AddrLine1 = "321 Somewhere Drive",
                //    City = "Fort Gaines",
                //    State = "GA",
                //    Zip = "39851",
                //    Country = "USA"
                //};
                //fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 51, Type = "Business Entity", Name = "Steve Cole Builder" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 442, // VA
                        MortgageInsuranceCaseNumber = "009874513",
                        LoanAmount = (decimal)150000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                //FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                //FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("211000");
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("180000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                //FastDriver.TermsDatesStatus.SettlementDate.FASetText("08-17-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("009874513");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "150000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.71" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "265.65" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.5" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "3,375.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Lender Fee", 3, TableAction.SetText, "1,500.00" + FAKeys.Tab);
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "VA Funding Fee" + FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.SaveAndReloadLoanChargesScreen();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "VA Funding Fee", 3, TableAction.SetText, "1,875.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("5,099.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("5,099.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("30.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("30.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Tax Service", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("65.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("65.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("45.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("45.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 5, TableAction.SetText, "201.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("Existing Loan Payoff");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("115000.00");
                FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FASetText("120000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Examination Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 4, TableAction.SetText, "200" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "50" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "250.50" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "60.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);
                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 3, TableAction.SetText, "1209.96");

                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("631.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("631.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("30");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.25");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("737.91");

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("1");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("737.91");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("201.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.PropertyTaxesDropDown.FASelectItem("YES");
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeOwnerassociationDropDown.FASelectItem("YES");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.AllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.NonEscrowedPropertyCostsOverYear1SpanR2C2.FASetText("1");
                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow14Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_14_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow14Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow14Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_14_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_14_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow14Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow15
        [TestMethod]
        public void CD_Workflow15()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow15";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI"; // Refinance
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 1184, //Set to property
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };

                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers = null;
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 442, // VA
                        MortgageInsuranceCaseNumber = "009874513",
                        LoanAmount = (decimal)150000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("240000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("VA");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "211000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("23.440000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "351.60" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.000" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "4,747.50" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Lender Fee", 3, TableAction.SetText, "2,110.00" + FAKeys.Tab);
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "VA Funding Fee" + FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.SaveAndReloadLoanChargesScreen();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "VA Funding Fee", 3, TableAction.SetText, "2,637.50" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "VA Funding Fee", 5, TableAction.SetText, "6,400.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Examination Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 4, TableAction.SetText, "450.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "900.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "145.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);
                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 3, TableAction.SetText, "1800.00");

                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("30");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"5/3");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("1007.35");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"4");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"1870");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"14");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                FastDriver.CD.YearRangeFourthUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("1007.35");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1230.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1451.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1870.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("250.5");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.AllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.NoPartialPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WillNotHaveEscrowAccountChkBox.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.YouDeclinedChkBox.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow15Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_15_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow15Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow15Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_15_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_15_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow15Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow16
        [TestMethod]
        public void CD_Workflow16()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow16";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI"; // Refinance
                fileRequest.File.FirstNewLoanAmount = (decimal)150000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)150000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 1184, //Set to property
                    AddrLine1 = "456 Somewhere Ave.",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };

                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers = null;
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 977, // Conventional
                        MortgageInsuranceCaseNumber = "009874513",
                        LoanAmount = (decimal)150000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("150000");
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("180000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Conventional");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "150000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.710000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "265.65" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.500" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "250.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 3, TableAction.SetText, "450.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Mortgage Broker Fee", 3, TableAction.SetText, "750.00" + FAKeys.Tab);

                //New Loan Charges Table

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("30.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("30.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Field Review", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "164.70" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 5, TableAction.SetText, "201.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("Pay Off Existing Loan");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("115000");
                FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FASetText("120000");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Examination Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 4, TableAction.SetText, "50.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Settlement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 4, TableAction.SetText, "200.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "25.50" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "350.00" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "60.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);
                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 3, TableAction.SetText, "1209.96");

                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("30");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.25");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("737.91");

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("2");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("4");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("737.91");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("737.91");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("82.35");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("201.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.NoPartialPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow16Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_16_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow16Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow16Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_16_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_16_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow16Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow17
        [TestMethod]
        public void CD_Workflow17()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow17";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE"; // Sale w/Mortgage
                fileRequest.File.SalesPriceAmount = (decimal)240000;
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)211000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 1184, //Set to property
                    AddrLine1 = "456 Somewhere Ave.",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 977, // Conventional
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)211000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("240000");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Conv-Insured");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "211000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("15.500000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "232.50" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.250" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "300.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Manual Underwriting Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Mortgage Broker Fee", 3, TableAction.SetText, "750.00" + FAKeys.Tab);

                //New Loan Charges Table

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co.");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("2");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("270.80" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("270.80" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Field Review", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-135.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "135.39" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "270.78" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "134.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 5, TableAction.SetText, "268.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("Payoff of First Mortgage Loan");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText("100000");

                FastDriver.BottomFrame.New();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("Payoff of Second Mortgage Loan");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText("25000");

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Cain, Joseph");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5400" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Green, Samuel");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5400" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Examination Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 4, TableAction.SetText, "650.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Settlement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 4, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "500.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "500.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Owner's Coverage Premium (optional)");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 4, TableAction.SetText, "700.00" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "90.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 4, TableAction.SetText, "40.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCharge.FASetText("5000" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCredit.FASetText("5000" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("2500" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOAACRE");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Special Assessment", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("650.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("650.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText("67.75" + FAKeys.Tab);
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText("67.75" + FAKeys.Tab);


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Warranty
                Reports.TestStep = "Navigate to Home Warranty Screen";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("XYZHOME");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();

                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(1, "Home Warranty", 5, TableAction.SetText, "450.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("PESTCO");
                FastDriver.InspectionRepairPest.Find.FAClick();

                rowCount = FastDriver.InspectionRepairPest.InspectionRepairChargesTable.GetRowCount();
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Pest Inspection Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.InspectionRepairPest.SaveAndReloadScreen();
                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair | Other
                Reports.TestStep = "Navigate to Other Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.GABcode.FASetText("ENGINC");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("8692935");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1209.96");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1,209.96" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1,209.96" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("5" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("670.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("670.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("SURVCO");
                FastDriver.SurveyDetail.Find.FAClick();

                rowCount = FastDriver.SurveyDetail.SurveyChargesTable.GetRowCount();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Survey Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SurveyDetail.SaveAndReloadScreen();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Surveys Co" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("285.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("285.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"5/3");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("1007.35");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"14");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"1870");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"14");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                FastDriver.CD.YearRangeFourthUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("1007.35");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("737.91");
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1229.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1451.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1870.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("135.39");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("135.39");
                FastDriver.CD.MortgageInsThirdColumnAmount.FASetText("135.39");
                FastDriver.CD.MortgageInsFourthColumnAmount.FASetText("135.39");

                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowThirdColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowFourthColumnAmount.FASetText("234.83");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("384.83");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow17Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_17_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow17Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow17Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_17_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_17_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow17Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow18
        [TestMethod]
        public void CD_Workflow18()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow18";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI"; // Refinance
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)211000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 1184, //Set to property
                    AddrLine1 = "456 Somewhere Ave.",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers = null;
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 977, // Conventional
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)211000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("211000");
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("240000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Conv-Insured");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "211000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("23.440000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "351.60" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("1.000" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "750.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Mortgage Broker Fee", 3, TableAction.SetText, "750.00" + FAKeys.Tab);

                //New Loan Charges Table

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co.");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("1");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("161.77" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("161.77" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Escrow Waiver Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Field Review", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("existing loan");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("183000");

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Examination Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 4, TableAction.SetText, "350.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Settlement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 4, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "900.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "145.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1800.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("4" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("804.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("804.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction(1, "Tax Lien", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("10000.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("10000.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("SURVCO");
                FastDriver.SurveyDetail.Find.FAClick();

                rowCount = FastDriver.SurveyDetail.SurveyChargesTable.GetRowCount();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Survey Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SurveyDetail.SaveAndReloadScreen();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("285.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("285.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("30");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"Interest Only");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("703.33");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_InterestOnly_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("2");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("703.33");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("1113.74");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("161.77");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("161.77");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("284.00");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.NoPartialPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WillNotHaveEscrowAccountChkBox.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.YouDeclinedChkBox.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow18Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_18_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow18Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow18Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_18_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_18_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow18Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow19
        [TestMethod]
        public void CD_Workflow19()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow19";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE"; // Sale w/Mortgage
                fileRequest.File.SalesPriceAmount = (decimal)240000;
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)211000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 1184, //Set to property
                    AddrLine1 = "456 Somewhere Ave.",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 977, // Conventional
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)211000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("211000");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Conv-Insured");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "211000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate"); //Intest Type
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("23.120000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "346.80" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.250" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "300.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Manual Underwriting Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                Playback.Wait(1000);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Field Review", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "134.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 5, TableAction.SetText, "268.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Cain, Joseph");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5400" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Green, Samuel");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5400" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.Attention.FASelectItem("Arnold, Sarah");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Examination Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 4, TableAction.SetText, "650.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Settlement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 4, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "500.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Owner's Coverage Premium (optional)");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 4, TableAction.SetText, "700.00" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "90.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record Deed");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Deed", 4, TableAction.SetText, "40.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("2500" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOAACRE");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Special Assessment", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("650.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("650.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText("82.26" + FAKeys.Tab);
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText("82.26" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Warranty
                Reports.TestStep = "Navigate to Home Warranty Screen";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("XYZHOME");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();

                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(1, "Home Warranty", 5, TableAction.SetText, "450.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("PESTCO");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Inspection", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair | Other
                Reports.TestStep = "Navigate to Other Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.GABcode.FASetText("ENGINC");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("5" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("670.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("670.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("SURVCO");
                FastDriver.SurveyDetail.Find.FAClick();

                rowCount = FastDriver.SurveyDetail.SurveyChargesTable.GetRowCount();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Survey Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SurveyDetail.SaveAndReloadScreen();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("285.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("285.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"Interest Only 5/3");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("703.33");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"14");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"2073");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"14");
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_InterestOnly_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox4.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                FastDriver.CD.YearRangeFourthUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("703.33");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1113.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1384.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1134.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1624.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1134.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("2073.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("135.39");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("135.39");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowThirdColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowFourthColumnAmount.FASetText("234.83");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("234.83");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();

                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow19Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_19_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow19Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow19Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_19_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_19_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow19Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow20
        [TestMethod]
        public void CD_Workflow20()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow20";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1].ServiceTypeObjectCD = "EO"; // Escrow Service
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI"; // Refinance
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)211000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 1184, //Set to property
                    AddrLine1 = "456 Somewhere Ave.",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers = null;
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 977, // Conventional
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)211000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("211000");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Conv-Insured");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "211000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("15.500000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "232.50" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.250" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "300.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Manual Underwriting Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Manual Underwriting Fee", 5, TableAction.SetText, "8,054.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Field Review", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "134.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 5, TableAction.SetText, "268.00" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "135.39" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "270.78" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("Existing Loan Payoff");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("115000");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.Attention.FASelectItem("Arnold, Sarah");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Examination Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Examination Fee", 4, TableAction.SetText, "650.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Settlement Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Settlement Fee", 4, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Insurance Binder Fee");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Insurance Binder Fee", 4, TableAction.SetText, "500.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Lender's Coverage Premium");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Lender's Coverage Premium", 4, TableAction.SetText, "500.00" + FAKeys.Tab);

                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Title - Owner's Coverage Premium (optional)");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Title - Owner's Coverage Premium (optional)", 4, TableAction.SetText, "700.00" + FAKeys.Tab);

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Record First Deed of Trust/Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record First Deed of Trust/Mortgage", 4, TableAction.SetText, "90.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("HOAACRE");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Special Assessment", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("650.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("650.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();

                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Warranty
                Reports.TestStep = "Navigate to Home Warranty Screen";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText("XYZHOME");
                FastDriver.HomeWarrantyDetail.Find.FAClick();
                FastDriver.BottomFrame.Done();

                FastDriver.HomeWarrantyDetail.WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable.PerformTableAction(1, "Home Warranty", 4, TableAction.SetText, "450.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("8692935");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CLAYTAX");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("5" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("670.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("670.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("SURVCO");
                FastDriver.SurveyDetail.Find.FAClick();

                rowCount = FastDriver.SurveyDetail.SurveyChargesTable.GetRowCount();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Survey Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SurveyDetail.SaveAndReloadScreen();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("285.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("285.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"Interest Only 5/3 Adjustable Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("703.33");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"14");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"2073");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"14");
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_InterestOnly_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox4.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                FastDriver.CD.YearRangeFourthUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("703.33");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1113.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1384.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1134.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1624.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1134.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("2073.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("135.39");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("135.39");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowThirdColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowFourthColumnAmount.FASetText("234.83");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("234.83");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow20Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_20_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow20Generated);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Playback.Wait(5000);

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow20Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");


                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_20_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_20_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow20Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow21
        [TestMethod]
        public void CD_Workflow21()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow21";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1] = null;
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI"; // Refinance
                fileRequest.File.FirstNewLoanAmount = (decimal)160000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)160000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 1184, //Set to property
                    AddrLine1 = "456 Somewhere Ave.",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 444, // Cal Vet
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)160000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("160000");
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("200000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "160000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate"); //Intest Type
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.710000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-21-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("08-31-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "177.10" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.250" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "350.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "350.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 5, TableAction.SetText, "3,849.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("475.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("475.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("35.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("35.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("45.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("45.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "200.00" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 4, TableAction.SetText, "400.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 5, TableAction.SetText, "800.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 6, TableAction.SetText, "201.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("RHO");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("Existing Loan Payoff");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("110000");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.Attention.FASelectItem("Arnold, Sarah");

                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Examination", 3, TableAction.SetText, "50.00" + FAKeys.Tab);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Charge");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Charge", 3, TableAction.SetText, "800.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Charge", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - T42 Endorsement");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - T42 Endorsement", 3, TableAction.SetText, "150.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - T42 Endorsement", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - T42.1 Endorsement" + FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - T42.1 Endorsement", 3, TableAction.SetText, "75.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - T42.1 Endorsement", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "350.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - T2 Endorsement");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(1, "Title - T2 Endorsement", 3, TableAction.SetText, "100.00" + FAKeys.Tab);

                rowCount = FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Insurance Binder");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(1, "Title - Insurance Binder", 3, TableAction.SetText, "250.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Modification of Deed of Trust");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 4, TableAction.SetText, "60.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("8336475");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AmountDues.FASetText("72.26");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1200.00");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("3.75");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("740.98");

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("1");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("740.98");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("500.00");
                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("500.00");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.NoPartialPayments.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow21Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_21_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow21Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow21Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_21_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_21_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow21Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow22
        [TestMethod]
        public void CD_Workflow22()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow22";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1] = null;
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI"; // Refinance
                fileRequest.File.FirstNewLoanAmount = (decimal)150000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)150000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 1184, //Set to property
                    AddrLine1 = "456 Somewhere Ave.",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80, //Set to property
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 444, // Cal Vet
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)150000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("160000");
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("180000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "150000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate"); //Intest Type
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.710000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-21-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "194.81" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.500" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "250.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 5, TableAction.SetText, "4,531.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 3, TableAction.SetText, "450.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("475.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("475.00");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("30.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("30.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 6, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 5, TableAction.SetText, "201.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 6, TableAction.SetText, "201.00" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "164.70" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 6, TableAction.SetText, "164.70" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("CDSETT01");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("To pay off existing loan");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("115000");
                //FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText(""); 
                //FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FASetText("115000");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.Attention.FASelectItem("Arnold, Sarah");

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Document Preparation Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Document Preparation Fee", 3, TableAction.SetText, "350.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Document Preparation Fee", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Charge");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Charge", 3, TableAction.SetText, "200.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Charge", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium" + FAKeys.Tab);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "250.00" + FAKeys.Tab);

                rowCount = FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Insurance Binder");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(1, "Title - Insurance Binder", 3, TableAction.SetText, "50.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Modification of Deed of Trust");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 4, TableAction.SetText, "60.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("8336475");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AmountDues.FASetText("72.26");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireIssuecheck1.FASetCheckbox(true);
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1209.96");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FAClick();
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("30561A65");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"Interest Only");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.25");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("531.25");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_InterestOnly_Year.FASetText("5");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("3");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("4");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("11");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("637.50");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("954.14");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("954.14");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("82.35");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("82.35");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("201.33");
                FastDriver.CD.EstEscrowThirdColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("201.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.NoPartialPayments.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow22Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_22_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow22Generated);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Playback.Wait(5000);

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow22Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_22_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_22_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow22Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow23
        [TestMethod]
        public void CD_Workflow23()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow23";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1] = null;
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "SALE"; // Sale w/Mortgage
                fileRequest.File.SalesPriceAmount = (decimal)180000;
                fileRequest.File.FirstNewLoanAmount = (decimal)162000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)162000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "39851";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "213 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "213 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Sellers[0].Type = "Husband and Wife";
                fileRequest.File.Sellers[0].FirstName = "Steve";
                fileRequest.File.Sellers[0].LastName = "Cole";
                fileRequest.File.Sellers[0].SpouseFirstName = "Amy";
                fileRequest.File.Sellers[0].SpouseLastName = "Doe";
                fileRequest.File.Sellers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "321 Somewhere Drive",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Sellers[1] = new BuyerSeller { EntityTypeID = 51, Type = "Business Entity", Name = "Steve Cole Builder" };
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 442, // VA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)162000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("180000");
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "162000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate"); //Intest Type
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("17.440000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-17-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "261.60" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.250" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "300.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "7,486.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "1,097.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("John Smith Appraisers Inc");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("29.80");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("29.80");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("20.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("20.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("MI Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("164.70" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("164.70" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("80.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("80.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("31.75" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("31.75" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                rowCount = FastDriver.NewLoan.NewLoanChargesTable.GetRowCount();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Tax Monitoring Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.SaveAndReloadLoanChargesScreen();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Tax Monitoring Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("75.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("75.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 7, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "82.35" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "164.70" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 7, TableAction.SetText, "164.70" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 4, TableAction.SetText, "100.50" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 5, TableAction.SetText, "201.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "County Property Taxes", 7, TableAction.SetText, "201.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("CDSETT01");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("Payoff of First Mortgage Loan");
                FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FASetText("100000.00");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Real Estate Broker Agent
                //No web service for this
                Reports.TestStep = "Navigate to Real Estate Broker/Agent Screen";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBS01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Cain, Joseph");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5700" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("CDREBB01");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.BrokerInformationAttention.FASelectItem("Green, Samuel");
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("5700" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.Attention.FASelectItem("Arnold, Sarah");
                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Owner’s Title Insurance (optional)");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Owner’s Title Insurance (optional)", 3, TableAction.SetText, "1000.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Owner’s Title Insurance (optional)", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Charge");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Charge", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Charge", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Title Search");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Search", 3, TableAction.SetText, "800.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Search", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "500.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Modification of Deed of Trust");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 4, TableAction.SetText, "60.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Off-Set
                Reports.TestStep = "Navigate to Off-Set Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.BuyerCredit3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("2500.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Home Owner Association
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.GABcode.FASetText("8336475");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.AmountDues.FASetText("72.26");
                FastDriver.HomeownerAssociation.FromDate.FASetText("08-17-2015");
                FastDriver.HomeownerAssociation.ToDate.FASetText("08-17-2015");
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Capital Contribution", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("HOA Acre Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("500.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("500.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "HOA Servicing Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("HOA Acre Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("150.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                rowCount = FastDriver.HomeownerAssociation.AssociationChargesTable.GetRowCount();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Home Warranty Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.HomeownerAssociation.SaveAndReloadScreen();
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, "Home Warranty Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("XYZ Warranty Inc.");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("450.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("450.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pest
                Reports.TestStep = "Navigate to Pest Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.GABcode.FASetText("9006575");
                FastDriver.InspectionRepairPest.Find.FAClick();

                FastDriver.InspectionRepairPest.InspectionRepairChargesTable.PerformTableAction(1, "Pest Inspection", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("120.50" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("120.50" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Inspection Repair | Other
                Reports.TestStep = "Navigate to Other Screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairOther>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Other").WaitForScreenToLoad();
                FastDriver.InspectionRepairOther.GABcode.FASetText("ENGINC");
                FastDriver.InspectionRepairOther.Find.FAClick();

                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.PerformTableAction(1, "Home Inspection Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("750.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("750.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1209.96");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FASetCheckbox(true);
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Insurance Co." + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Tax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("30561A65");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("603.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("603.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Prorotion | Tax
                Reports.TestStep = "Navigate to Prorotion | Tax Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.Tax1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.FromDate.FASetText("01-01-2015");
                FastDriver.ProrationDetail.ToDate.FASetText("08-17-2015");
                FastDriver.ProrationDetail.BuyerCredit.FASetText("758.62" + FAKeys.Tab);
                FastDriver.ProrationDetail.SellerCharge.FASetText("758.62" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("8828737");
                FastDriver.SurveyDetail.Find.FAClick();

                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("85.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("85.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"4 Year Interest Only Fixed Rate");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("3.875");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("581.25");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_InterestOnly_Year.FASetText("5");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("3");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("4");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("11");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("581.25");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("916.40");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("916.40");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("82.35");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("82.35");
                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("201.33");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("201.33");
                FastDriver.CD.EstEscrowThirdColumnAmount.FASetText("201.33");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("361.33");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.NonEscrowedPropertyCostsOverYear1SpanR2C2.FASetText("1800");
                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow23Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_23_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow23Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow23Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_23_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_23_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow23Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        #region CD_Workflow24
        [TestMethod]
        public void CD_Workflow24()
        {
            try
            {
                Reports.TestDescription = "CD_Workflow24";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest2BuyersSellers();
                fileRequest.File.Services[0].ServiceTypeObjectCD = "TO"; // Title service
                fileRequest.File.Services[1] = null;
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDSETT01");
                fileRequest.File.BusinessParties[0].BusOrgContact = new BusOrgContact() { ContactName = @"Arnold, Sarah", ContactID = 3229 };
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "LOAN"; // Equity Loan
                fileRequest.File.FirstNewLoanAmount = (decimal)211000; //TermsDatesNewLoanAmnt
                fileRequest.File.FirstNewLoanLiabilityAmount = (decimal)211000;
                fileRequest.File.EstimatedDateToClose = Convert.ToDateTime("11-30-2012");

                //Properties
                fileRequest.File.Properties[0].Name = "TBD";
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "456 Somewhere Ave.";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Fort Gaines";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "GA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Clay";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "92701";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";

                //Buyers
                fileRequest.File.Buyers[0].EntityTypeID = 49; //Husband/Wife
                fileRequest.File.Buyers[0].Type = "Husband and Wife";
                fileRequest.File.Buyers[0].FirstName = "Michael";
                fileRequest.File.Buyers[0].LastName = "Jones";
                fileRequest.File.Buyers[0].SpouseFirstName = "Mary";
                fileRequest.File.Buyers[0].SpouseLastName = "Stone";
                fileRequest.File.Buyers[0].CurrentAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "123 Anywhere Street",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[0].ForwardingAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 119, //Forwarding Address
                    AddrLine1 = "456 Somewhere Ave",
                    City = "Fort Gaines",
                    State = "GA",
                    Zip = "39851",
                    Country = "USA"
                };
                fileRequest.File.Buyers[1] = new BuyerSeller { EntityTypeID = 48, Type = "Individual", LastName = "Available" };

                //Sellers
                fileRequest.File.Sellers = null; // No sellers
                fileRequest.File.NewLoan = null;

                //Create the file
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);

                //Add new loan to file
                NewLoanRequest loanRequest = new NewLoanRequest
                {
                    FileID = File.FileID,
                    SeqNum = 1,
                    EmployeeID = 1,
                    Source = "FAMOS",
                    LoanDetails = new NewLoanDetail()
                    {
                        eFormType = FormType.CD,
                        LoanTypeID = 441, // FHA
                        MortgageInsuranceCaseNumber = "000654321",
                        LoanAmount = (decimal)211000,
                        LoanNumber = "123456789",
                        LenderInformation = new PayChargeFileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("CDLEND01"),
                            Name = "Smith, Joe"
                        }
                    },
                };

                var loanResponse = FileService.UpdateNewLoan(loanRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                #endregion

                #region Terms Dates Status screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to Term Date Status screen";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                DateTime PSTDateTime = DateTime.UtcNow;
                PSTDateTime = TimeZoneInfo.ConvertTimeFromUtc(PSTDateTime, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));
                string CurrentPSTDate = PSTDateTime.ToDateString();
                FastDriver.TermsDatesStatus.StatusDate.FASetText(CurrentPSTDate);
                FastDriver.TermsDatesStatus.LoanEstimateUnroundedSalePrice.FASetText("211000");
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("240000"); //Only enabled for refiance file
                FastDriver.TermsDatesStatus.DisbursementDate.FASetText("08-24-2015");
                FastDriver.BottomFrame.Done();
                #endregion

                #region New Loan screen
                //TODO: Need to convert this into web service
                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItem("Cal Vet");
                FastDriver.NewLoan.LoanDetailsMortgageInsCase.FASetText("000654321");
                FastDriver.NewLoan.LoanDetailsLoanNumber.FASetText("123456789" + FAKeys.Tab);
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItemBySendingKeys("Smith, Joe" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.PrincipalBalanceChargesTable.PerformTableAction(1, "Loan Amount", 5, TableAction.SetText, "211000.00" + FAKeys.Tab); // Loan Estimate Unrounded
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Adjustable Interest Rate"); //Intest Type
                FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
                FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("15.500000" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("08-21-2015" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("09-01-2015" + FAKeys.Tab);
                FastDriver.NewLoan.InterestCalculationTable.PerformTableAction(1, "Prepaid Interest", 3, TableAction.SetText, "170.50" + FAKeys.Tab); //Prepaid Interest Buyer Charge
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("0.250" + FAKeys.Tab);

                //Loan Charges Origination Charges Table
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "300.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Manual Underwriting Fee", 3, TableAction.SetText, "500.00" + FAKeys.Tab);

                //New Loan Charges Table
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Appraisal Field Review", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("405.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("405.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Credit Report", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Information Inc.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("40.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("40.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Flood Certification", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("90.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("90.00");
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Property Tax Status Research Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Info Co.");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("150.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("150.00");
                FastDriver.DialogBottomFrame.ClickDone();

                //Impounds section

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("-0.01" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 4, TableAction.SetText, "100.83" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Homeowner's Insurance", 5, TableAction.SetText, "201.66" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 4, TableAction.SetText, "161.77" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "Mortgage Insurance", 5, TableAction.SetText, "323.54" + FAKeys.Tab);

                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.SetText, "2" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 4, TableAction.SetText, "134.00" + FAKeys.Tab);
                FastDriver.NewLoan.AggregateAccountingAdjustmentTable.PerformTableAction(1, "City Property Taxes", 5, TableAction.SetText, "268.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region PayOffLoan
                Reports.TestStep = "Navigate to Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("CDLEND01");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FASetText("existing loan");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("115000");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Outside Title Company
                //Need to convert this to web service
                Reports.TestStep = "Navigate to Outside Title Company Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("CDSETT01");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.Attention.FASelectItem("Arnold, Sarah");

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Owner’s Title Insurance (optional)");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Owner’s Title Insurance (optional)", 3, TableAction.SetText, "1000.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Owner’s Title Insurance (optional)", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Settlement Charge");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Charge", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Settlement Charge", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Lender's Coverage Premium");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 3, TableAction.SetText, "500.00" + FAKeys.Tab);
                //Create new row
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Lender's Coverage Premium", 5, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                rowCount = FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.GetRowCount();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Title - Title Search");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OutsideTitleCompanyDetail.SaveAndReloadScreen();
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(1, "Title - Title Search", 3, TableAction.SetText, "800.00" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Fee Entry
                Reports.TestStep = "Navigate to Fee Entry Screen";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("Modification of Deed of Trust");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.AddFeeTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 1, TableAction.On);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Modification of Deed of Trust", 4, TableAction.SetText, "60" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion

                #region Insurance Fire
                Reports.TestStep = "Navigate to Insurance Screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();

                FastDriver.InsuranceFire.FireGABcodeunderwriter.FASetText("9056171");
                FastDriver.InsuranceFire.FireFindunderwriter.FAClick();
                FastDriver.InsuranceFire.FirePremium.FASetText("1209.00");
                FastDriver.InsuranceFire.FiretextTerm.FASetText("12");
                FastDriver.InsuranceFire.FireoptMonths.FASetCheckbox(true);
                FastDriver.InsuranceFire.FireIssuecheck2.FASetCheckbox(true);

                FastDriver.InsuranceFire.InsuranceChargesTable.PerformTableAction(1, "Homeowner's Insurance Premium", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("12" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("1209.96" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Property Fax Check
                Reports.TestStep = "Navigate to Property Fax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("CITY");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Property Taxes", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText("6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("670.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("670.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Survey
                Reports.TestStep = "Navigate to Survey Screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.GABcode.FASetText("8828737");
                FastDriver.SurveyDetail.Find.FAClick();

                rowCount = FastDriver.SurveyDetail.SurveyChargesTable.GetRowCount();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Survey Fee");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.SurveyDetail.SaveAndReloadScreen();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(1, "Survey Fee", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("285.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("285.00" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.SurveyDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Closing Disclosure
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("360");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItemBySendingKeys("Adjustable Rate");
                FastDriver.ClosingDisclosure.LoanProducttxt.FASetText(@"5/3");
                FastDriver.ClosingDisclosure.Done.FAClick();

                // Expand Loan Terms section
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAClick();
                Keyboard.SendKeys("4.00");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAClick();
                Keyboard.SendKeys("1007.35");

                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText(@"6");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText(@"12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText(@"14");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CheckBox3.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText(@"3");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText(@"6");

                FastDriver.ClosingDisclosure.LoanTerm_PI_CheckBox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText(@"1870");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText(@"14");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

                FastDriver.CD.ProjectedPaymentHeader.FAClick();
                FastDriver.CD.ProjectedPaymentPlusIcon.FAClick();
                FastDriver.YearRangeDialog.YearRangeDropDown.FASelectItemBySendingKeys("4");
                FastDriver.YearRangeDialog.Done.FAClick();

                FastDriver.CD.YearRangeFirstUpperBound.FASetText("5");
                FastDriver.CD.YearRangeSecondUpperBound.FASetText("8");
                FastDriver.CD.YearRangeThirdUpperBound.FASetText("11");
                FastDriver.CD.YearRangeFourthUpperBound.FASetText("30");
                Playback.Wait(1000);

                FastDriver.CD.PrincipalInterestFirstColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.PrincipalandInterestRadioButton1.FASetCheckbox(true);
                FastDriver.MinMaxDialog.PrincipalandInterestTextbox.FASetText("1007.35");
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestSecondColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1229.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestThirdColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1451.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.PrincipalInterestFourthColumnplusIcon.FAClick();
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.MinMaxRadioButton.FASetCheckbox(true);
                FastDriver.MinMaxDialog.MinimumAmount.FASetText("1007.00" + FAKeys.Tab);
                FastDriver.MinMaxDialog.MaximumAmount.FASetText("1870.00" + FAKeys.Tab);
                Playback.Wait(1000);
                FastDriver.MinMaxDialog.Done.FAClick();

                FastDriver.CD.MortgageInsFirstColumnAmount.FASetText("161.77");
                FastDriver.CD.MortgageInsSecondColumnAmount.FASetText("161.77");
                FastDriver.CD.MortgageInsThirdColumnAmount.FASetText("161.77");

                FastDriver.CD.EstEscrowFirstColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowSecondColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowThirdColumnAmount.FASetText("234.83");
                FastDriver.CD.EstEscrowFourthColumnAmount.FASetText("234.83");

                FastDriver.CD.EstTaxesInsuranceAssessmentAmount.FASetText("384.83");
                FastDriver.CD.PropertyTaxesChkBox.FASetCheckbox(true);
                FastDriver.CD.HomeownerChkBox.FASetCheckbox(true);
                //FastDriver.CD.OthersChkBox.FASetCheckbox(true);
                FastDriver.CD.InEsrwProTaxDropdownEmpty.FASelectItem("YES");
                FastDriver.CD.HomeOwnerInsInErwDropdwnEmpty.FASelectItem("YES");

                //New for 9.8
                FastDriver.CD.Otherplusicon.FAClick();
                Playback.Wait(1000);
                FastDriver.CD.EstimateIncludesOther.FASetCheckbox(true);
                FastDriver.CD.txtPOPupEstimateOther.FASetText("Homeowners Association Dues");
                Playback.Wait(1000);
                FastDriver.CD.DoneinOtherpopup.FAClick();

                FastDriver.ClosingDisclosure.LoanDisclosures.FAClick();
                FastDriver.ClosingDisclosure.DontAllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasNoDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.AcceptPayments.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);

                FastDriver.CD.NonEscrowedPropertyCostsOverYear1SpanR2C2.FASetText("1800");
                FastDriver.CD.LoanCalculationHeader.FAClick();
                FastDriver.CD.TotalofPayments.FASetText("1");
                FastDriver.CD.FinanceCharge.FASetText("1");
                FastDriver.CD.AmountFinanced.FASetText("1");
                FastDriver.CD.AnnualPercentageRate.FASetText("1");
                FastDriver.CD.TotalInterestPercentage.FASetText("1");

                #endregion

                #region Delivery Options
                Reports.TestStep = "Navigate to Delivery Options Screen";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(2000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD, 5);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString() + FAKeys.Tab);
                FastDriver.ClosingDisclosure.AlertYesBtn.FAClick();
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("08-24-2015" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.BorrowerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItemBySendingKeys("Preview");
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                #endregion

                string CreateFolder = DateTime.Today.ToString("MMddyyyy");
                string strIMDCDDeliveryPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFFiles");
                CreateDirectory(strIMDCDDeliveryPDFFiles + CreateFolder);
                string strWorkFlow24Generated = strIMDCDDeliveryPDFFiles + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_24_Generated" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", true, 30); // wait for delivery window to appear
                FastDriver.WebDriver.WaitForWindowAndSwitch("Print Preview", false, 200); // wait for delivery window to disappear

                //Save PDF File
                Reports.TestStep = "Save PDF file";
                SavePDFFile(strWorkFlow24Generated);
                Playback.Wait(5000);
                Reports.UpdateDebugLog("Done with save PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Clean PDF File
                Reports.TestStep = "Clean PDF file";
                CleanPDFFile(strWorkFlow24Generated, strIMDCDDeliveryPDFFiles + CreateFolder);
                Reports.UpdateDebugLog("Done with Clean PDF file", "", "", "", "", "Continuing test execution", Reports.Result(true), "");

                //Compare PDF Files
                Reports.TestStep = "Compare PDFs files";
                string strIMDCDDeliveryActualPDFFiles = Support.ReadAppSettings("appSettings", "IMDCDDeliveryActualPDFFiles");
                string strIMDCDDeliveryPDFCompareReport = Support.ReadAppSettings("appSettings", "IMDCDDeliveryPDFCompareReport");
                strIMDCDDeliveryActualPDFFiles = strIMDCDDeliveryActualPDFFiles + @"CDDeliveryPDFFile_WorkFlow_24_Expected.pdf";
                CreateDirectory(strIMDCDDeliveryPDFCompareReport + CreateFolder);
                strIMDCDDeliveryPDFCompareReport = strIMDCDDeliveryPDFCompareReport + CreateFolder + @"\CDDeliveryPDFFile_WorkFlow_24_CompareReport" + DateTime.Now.ToString("ddMMyyyyHHmmssFFF") + ".pdf";
                PDFComparison(strIMDCDDeliveryActualPDFFiles, strWorkFlow24Generated, strIMDCDDeliveryPDFCompareReport);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #endregion

        [TestMethod]
        public void Test()
        {
            string pdffile = @"C:\Test\CDDeliveryPDFFile_WorkFlow_12_Expected.pdf";
            string workingdir = @"C:\Test";

            CleanPDFFile(pdffile, workingdir);
        }

        #region Supporting Functions
        public void CreateDirectory(string DirectoryName)
        {
            if (!Directory.Exists(DirectoryName))
            {
                Directory.CreateDirectory(DirectoryName);
            }
        }


        #region Save PDF File
        public void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Playback.Wait(5000);

                //CloseReadingUntaggedDialog();


                //Keyboard.SendKeys("+{S}", ModifierKeys.Control);
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", ModifierKeys.Shift);
                Playback.Wait(2000);

                Keyboard.SendKeys("{N}", ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(10000);

                Keyboard.SendKeys("{F4}", ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }
        #endregion



        #region Clean PDF File

        public void CleanPDFFile(string PDFFilePath, string workingDir)
        {
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            proc.StartInfo.FileName = @"C:\Program Files\gs\gs9.16\bin\gswin64c.exe";
            proc.StartInfo.RedirectStandardError = false;
            proc.StartInfo.RedirectStandardOutput = false;
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.Verb = "runas";
            proc.StartInfo.WorkingDirectory = workingDir;
            string currentPath = proc.StartInfo.EnvironmentVariables["Path"];
            string newPath = currentPath + @";C:\Program Files\gs\gs9.16\lib;C:\Program Files\gs\gs9.16\bin";
            proc.StartInfo.EnvironmentVariables.Remove("Path");
            proc.StartInfo.EnvironmentVariables.Add("Path", newPath);

            // Convert PDF to PS
            Reports.UpdateDebugLog("Convert PDF to PS", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
            proc.StartInfo.Arguments = "-q -dNOPAUSE -dBATCH -sDEVICE#ps2write -sOutputFile=temp.ps " + PDFFilePath;
            proc.Start();
            proc.WaitForExit();

            // Convert PS back to PDF
            Reports.UpdateDebugLog("Convert PS back to PDF", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
            proc.StartInfo.Arguments = "-q -dNOPAUSE -dBATCH -sDEVICE#pdfwrite -sOutputFile=" + PDFFilePath + " temp.ps";
            proc.Start();
            proc.WaitForExit();

            Reports.UpdateDebugLog("Clean up", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
            proc.Close();
            Support.CloseAllProcessStartingWith("conhost");
        }
        #endregion

        #region PDf Comparison
        public void PDFComparison(string FirstPDFPath, string SecondPDFPath, string CompareReport)
        {
            try
            {
                //Clean up any previous Acrobat instance
                Support.CloseAllProcessStartingWith("Acrobat");

                //Launch Adobe Acrobat 
                Reports.UpdateDebugLog("Launch Adobe Acrobat", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Process AdobeAcrobatExeProcess = Process.Start(@"C:\Program Files (x86)\Adobe\Acrobat 11.0\Acrobat\Acrobat.exe");
                Playback.Wait(10000);

                //open View->Compare Documents
                Reports.UpdateDebugLog("open View->Compare Documents", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("{V}" + "{C}", ModifierKeys.Alt);
                Playback.Wait(5000);
                WinWindow CompareDocsWindow = new WinWindow();
                CompareDocsWindow.SearchProperties.Add("ClassName", "#32770");

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(3000);

                //Attach the first PDF
                Reports.UpdateDebugLog("Attach the first PDF", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                WinWindow OpenPDF = new WinWindow();
                OpenPDF.SearchProperties.Add("Name", "Open");
                OpenPDF.SearchProperties["ClassName"] = "#32770";
                OpenPDF.WindowTitles.Add("Open");
                Playback.Wait(1000);

                UITestControl FileName = new UITestControl(OpenPDF);
                FileName.SearchProperties.Add("Name", "File name:");
                FileName.SearchProperties.Add("ControlType", "Edit");
                FileName.SetProperty("Text", FirstPDFPath);

                Keyboard.SendKeys("{O}", ModifierKeys.Alt);
                Playback.Wait(2000);

                Keyboard.SendKeys("{E}", ModifierKeys.Alt);
                Playback.Wait(5000);

                //Attach the second PDF
                Reports.UpdateDebugLog("Attach the second PDF", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                FileName.SearchProperties.Add("Name", "File name:");
                FileName.SearchProperties.Add("ControlType", "Edit");
                FileName.WindowTitles.Add("Open");
                FileName.SetProperty("Text", SecondPDFPath);

                Keyboard.SendKeys("{O}", ModifierKeys.Alt);
                Playback.Wait(3000);

                //UITestControl radiobtnctrl = new UITestControl(CompareDocsWindow);
                //radiobtnctrl.SearchProperties.Add("Name", "Reports, spreadsheets, magazine layouts");
                //radiobtnctrl.SearchProperties.Add("ControlType", "RadioButton");
                //Mouse.Click(radiobtnctrl);
                //Playback.Wait(5000);

                Keyboard.SendKeys("{O}", ModifierKeys.Alt);
                Playback.Wait(120000);

                // Save the final compared PDF Report
                Reports.UpdateDebugLog("Save Comparision Report", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("{S}", ModifierKeys.Control);
                Playback.Wait(10000);

                //string ResultantComparedFileName = @"D:\Test\Compare" + DateTime.Now.ToString("ddmmyyhmmff") + ".pdf";    
                Reports.UpdateDebugLog("Enter report name", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                FileName = new UITestControl(CompareDocsWindow);
                FileName.SearchProperties.Add("Name", "File name:");
                FileName.SearchProperties.Add("ControlType", "Edit");
                FileName.SetProperty("Text", CompareReport);
                Playback.Wait(10000);

                Reports.UpdateDebugLog("Click Save button", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(30000);

                // close the PDF
                Reports.UpdateDebugLog("close the PDF", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("{W}", ModifierKeys.Control);
                Playback.Wait(7000);

                //Close the process window
                AdobeAcrobatExeProcess.CloseMainWindow();
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception) // Try again if PDF crashes
            {
                Support.CloseAllProcessStartingWith("Acrobat");

                //Launch Adobe Acrobat 
                Reports.UpdateDebugLog("Second Try: Launch Adobe Acrobat", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Process AdobeAcrobatExeProcess = Process.Start(@"C:\Program Files (x86)\Adobe\Acrobat 11.0\Acrobat\Acrobat.exe");
                Playback.Wait(10000);

                //open View->Compare Documents
                Reports.UpdateDebugLog("Second Try: open View->Compare Documents", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("{V}" + "{C}", ModifierKeys.Alt);
                Playback.Wait(5000);
                WinWindow CompareDocsWindow = new WinWindow();
                CompareDocsWindow.SearchProperties.Add("ClassName", "#32770");

                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(3000);

                //Attach the first PDF
                Reports.UpdateDebugLog("Second Try: Attach the first PDF", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                WinWindow OpenPDF = new WinWindow();
                OpenPDF.SearchProperties.Add("Name", "Open");
                OpenPDF.SearchProperties["ClassName"] = "#32770";
                OpenPDF.WindowTitles.Add("Open");
                Playback.Wait(1000);

                UITestControl FileName = new UITestControl(OpenPDF);
                FileName.SearchProperties.Add("Name", "File name:");
                FileName.SearchProperties.Add("ControlType", "Edit");
                FileName.SetProperty("Text", FirstPDFPath);

                Keyboard.SendKeys("{O}", ModifierKeys.Alt);
                Playback.Wait(2000);

                Keyboard.SendKeys("{E}", ModifierKeys.Alt);
                Playback.Wait(5000);

                //Attach the second PDF
                Reports.UpdateDebugLog("Second Try: Attach the second PDF", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                FileName.SearchProperties.Add("Name", "File name:");
                FileName.SearchProperties.Add("ControlType", "Edit");
                FileName.WindowTitles.Add("Open");
                FileName.SetProperty("Text", SecondPDFPath);

                Keyboard.SendKeys("{O}", ModifierKeys.Alt);
                Playback.Wait(3000);

                //UITestControl radiobtnctrl = new UITestControl(CompareDocsWindow);
                //radiobtnctrl.SearchProperties.Add("Name", "Reports, spreadsheets, magazine layouts");
                //radiobtnctrl.SearchProperties.Add("ControlType", "RadioButton");
                //Mouse.Click(radiobtnctrl);
                //Playback.Wait(5000);

                Keyboard.SendKeys("{O}", ModifierKeys.Alt);
                Playback.Wait(120000);

                // Save the final compared PDF Report
                Reports.UpdateDebugLog("Second Try: Save Comparision Report", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("{S}", ModifierKeys.Control);
                Playback.Wait(10000);

                //string ResultantComparedFileName = @"D:\Test\Compare" + DateTime.Now.ToString("ddmmyyhmmff") + ".pdf";    
                Reports.UpdateDebugLog("Second Try: Enter report name", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                FileName = new UITestControl(CompareDocsWindow);
                FileName.SearchProperties.Add("Name", "File name:");
                FileName.SearchProperties.Add("ControlType", "Edit");
                FileName.SetProperty("Text", CompareReport);
                Playback.Wait(10000);

                Reports.UpdateDebugLog("Second Try: Click Save button", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("{S}", ModifierKeys.Alt);
                Playback.Wait(30000);

                // close the PDF
                Reports.UpdateDebugLog("Second Try: close the PDF", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("{W}", ModifierKeys.Control);
                Playback.Wait(7000);

                //Close the process window
                AdobeAcrobatExeProcess.CloseMainWindow();
                Support.CloseAllProcessStartingWith("Acrobat");

            }

            // Read the contents from the final resultant PDF
            Reports.UpdateDebugLog("Read the contents from the final resultant PDF", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
            using (PdfReader reader = new PdfReader(CompareReport))
            {
                StringBuilder text = new StringBuilder();
                text.Append(PdfTextExtractor.GetTextFromPage(reader, 1));

                if (text.ToString().Contains("No differences were found between documents"))
                {
                    this.TestContext.WriteLine("Test Passed: Both PDF files are similar");
                }
                else
                {
                    //Assert.Fail("Test Failed: Both the PDFs are not similar");
                    Assert.Inconclusive("Both the PDFs are not similar, please check the report.");
                }
            }

        }
        #endregion

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
