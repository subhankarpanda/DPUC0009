﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using AutoIt;
using FASTSelenium.DataObjects.IIS;
using OpenQA.Selenium;
using System.Collections.Generic;
using System.Text.RegularExpressions;


namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest, DeploymentItem(@"Common/Utilities/AutoItX3.dll")]
    public class File_balance_Summary_Regression : FASTHelpers
    {
        #region Data Input Tests
        private string[] receipts = new string[10];

        private void FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER()
        {
            Reports.TestDescription = "Create a Basic Order,New Loan Instance and Buyer instances.";
            Reports.TestStep = "Login to App and Create a Basic file.";

            #region Login and create Order
            Reports.TestStep = "Login FAST application.";
            FAST_Login_IIS();

            Reports.TestStep = "Create File";
            FAST_WCF_File_IIS();
            #endregion

            #region Enter new Loan Amount
            Reports.TestStep = "Create a New Loan instance in File.";
            //FAST_WCF_CreateNewLoan();
            FAST_WCF_UpdateNewLoan();
            #endregion

            #region create Buyer
            Reports.TestStep = "Create a Buyer instance in File.";
            FAST_WCF_AddBuyerSeller();
            #endregion
        }

        private void FBS_ENTER_CHARGES_OEC_OTC_ATTORNEY_ASSUMPTION_LOAN_SCREENS()
        {
            Reports.TestDescription = "Create Instances and Enter charges on Outside Escrow , Outside Title company, Seller Attorney and Assumption loan screens";

            FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER();

            #region Enter Charges in Outside Escrow Company Screen screen.
            Reports.TestStep = "Enter Charge on OEC";
            FAST_WCF_CreateOutsideEscrowCompany();
            FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company").SwitchToContentFrame();
            Support.AreEqual(FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetAttribute("value"), "UAT Entry");
            #endregion

            #region Enter Charges in Outside Title Company Screen screen.
            Reports.TestStep = "Enter Charge on OTC";
            FAST_WCF_CreateOutsideTitleCompany();
            FastDriver.OTCDetail.Open();
            Support.AreEqual(FastDriver.OTCDetail.OTCTitleServicesDescription.FAGetAttribute("value"), "UAT Entry");
            #endregion

            #region Enter Charges in Attorney Seller screen.
            Reports.TestStep = "Enter Charges in Attorney Seller screen.";
            FAST_WCF_CreateBuyerSellerAttorney();
            FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - Buyer").SwitchToContentFrame();
            Support.AreEqual(FastDriver.AttorneyDetail.ChargeDescription.FAGetAttribute("value"), "UAT Entry");
            #endregion

            //Assumption Loan Charges
            #region Enter Charges in Assumption Loan screen.
            Reports.TestDescription = "Enter Charges in Assumption Loan screen. - K L M N and H Section";
            FAST_AddAssumptionLoan();
            #endregion
        }

        private void FBS_ENTER_BUYER_SELLER_AMOUNT_FEE_SCREEN()
        {
            Reports.TestDescription = "Select a Fee with Paid at closing method as FEE and enter Buyer seller Charge Amount.";

            FBS_ENTER_CHARGES_OEC_OTC_ATTORNEY_ASSUMPTION_LOAN_SCREENS();

            #region FileFees
            Reports.TestStep = "Enter Fee Amount for Fee Payment method as FEE";
            FAST_AddFileFees(new PDD[]{
                new PDD() { ChargeDescription = "New Home Rate (Title Only)", BuyerAtClosing = 12.99, SellerPaidAtClosing = 11.99}
            });
            #endregion
        }

        private void FBS_UPLOAD_DOCUMENT_IN_DOCREP()
        {
            Reports.TestDescription = "Uploading the Document in Document repository and verify the same.";

            FBS_ENTER_BUYER_SELLER_AMOUNT_FEE_SCREEN();

            #region Upload Document to add wire instructions
            Reports.TestStep = "Click on Upload button.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
            Playback.Wait(3000);
            FastDriver.DocumentRepository.SwitchToContentFrame();
            FastDriver.DocumentRepository.Upload.Click();
            //  Upload some pdf
            string filePath = Reports.DEPLOYDIR + @"\Hello.pdf";
            FastDriver.UploadDocumentDlg.UploadFile(filePath);
            FastDriver.SaveDocumentDlg.SaveDocument("Escrow: Misc", "SEC-WireInstOut", "test");
            Playback.Wait(10000);
            //  Verify uploaded doc
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentRepository.SwitchToContentFrame();
            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);
            FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
            FastDriver.DocumentRepository.SwitchToContentFrame();
            Support.AreEqual("Imaged", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, "SEC-WireInstOut test", 9, TableAction.GetText).Message.Trim());
            #endregion
        }

        private void FBS_ACTIVE_DISB_SUMMARY_VERIFY_CHECKS_CREATED_AND_DISBURSE()
        {
            Reports.TestDescription = "Verify all the charges in active disbursement screen and issue a check, create a wire and create a fee transfer.";

            FBS_UPLOAD_DOCUMENT_IN_DOCREP();

            #region verify charges are present
            Reports.TestStep = "Verify all the charges in active disbursement screen and issue a check, create a wire and create a fee transfer.";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
            FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
            Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "24.98", 1, TableAction.GetText).Message.Trim());
            Support.AreEqual("Created", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "48,480.92", 1, TableAction.GetText).Message.Trim());
            Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "800.03", 1, TableAction.GetText).Message.Trim());
            Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "400.03", 1, TableAction.GetText).Message.Trim());
            Support.AreEqual("Pending", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "14.98", 1, TableAction.GetText).Message.Trim());
            #endregion

            #region disburse checks
            Reports.TestStep = "Disburse OEC and OTC checks";
            FAST_DisburseCheck("800.03");
            FAST_DisburseCheck("400.03");
            #endregion

            #region disburse wires
            Reports.TestStep = "Disburse Assumption Loan Charge as Wire";
            FAST_DisburseWire("14.98");
            #endregion

            #region disburse fee
            Reports.TestStep = "Disburse Fee";
            FAST_DisburseFee("24.98");
            #endregion
        }

        private void FBS_TDS_STLMNT_DATE_CREATE_BUYER()
        {
            Reports.TestDescription = "Enter settlement date on TDS";

            FBS_ENTER_BUYER_SELLER_AMOUNT_FEE_SCREEN();

            #region Update Settlement Date in TDS
            Reports.TestStep = "Update Settlement Date in TDS";
            FAST_WCF_UpdateTermsDatesStatus();
            #endregion

            #region Add Seller
            Reports.TestStep = "Adding a Seller instance";
            FAST_WCF_AddBuyerSeller("Seller");
            #endregion
        }

        private void FBS_HOLD_A_CHECK()
        {
            Reports.TestDescription = "Change the status of check to held.";

            FBS_ENTER_BUYER_SELLER_AMOUNT_FEE_SCREEN();

            #region Hold a check
            Reports.TestStep = "Change the status of check to held.";
            FAST_HoldDisbursement("48,480.92", "7", "Security");
            #endregion
        }

        private void FBS_ADD_A_FEE_FOR_HOLD()
        {
            Reports.TestDescription = "Add a Fee with At Closing Method as FEE and Assigned charges to Lender paid by other";

            FBS_ENTER_CHARGES_OEC_OTC_ATTORNEY_ASSUMPTION_LOAN_SCREENS();

            #region FileFees
            Reports.TestStep = "Enter Fee Amount for Fee Payment method as FEE";
            FAST_AddFileFees(new PDD[]{
                new PDD() { ChargeDescription = "Closing Service Coordination", BuyerPaidbyOther = 11.99, BuyerPaidbyOtherPaymentMethod = "Lender", SellerPaidbyOthers = 10.99, SellerPaidbyOtherPaymentMthd = "Lender" }
            });
            #endregion

            #region Hold a fee
            Reports.TestStep = "Change the status of check to held.";
            FAST_HoldDisbursement("22.98", "7", "Security");
            #endregion
        }

        private void FBS_ADJUST_CANCEL_DEPOSITS_CREATED_ON_DEPOSIT_IN_ESCROW()
        {
            Reports.TestDescription = "Adjust some amount for Buyer, Seller and Other.";

            FBS_TDS_STLMNT_DATE_CREATE_BUYER();

            #region Add Deposit in Escrow
            Reports.TestStep = "Add Deposit in Escrow";
            FAST_DepositInEscrow("11.10", "Buyer", "Cash", "Additional Closing Costs");
            FAST_DepositInEscrow("12.10", "Buyer", "Cash", "Initial Deposit");
            FAST_DepositInEscrow("13.10", "Buyer", "Cash", "Additional Closing Costs");
            FAST_DepositInEscrow("14.10", "Seller", "Cash", "Additional Closing Costs");
            FAST_DepositInEscrow("15.10", "Seller", "Cash", "Initial Deposit");
            FAST_DepositInEscrow("16.10", "Seller", "Cash", "Additional Closing Costs");
            FAST_DepositInEscrow("17.10", "New Lender", "Cash", "Additional Closing Costs");
            FAST_DepositInEscrow("18.10", "New Lender", "Cash", "Initial Deposit");
            FAST_DepositInEscrow("19.10", "New Lender", "Cash", "Additional Closing Costs");
            #endregion

            #region Adjust deposits
            FAST_AdjustDeposit("12.10", 0, "CancelFirst");
            FAST_AdjustDeposit("15.10", 0, "CancelSecond");
            FAST_AdjustDeposit("18.10", 0, "CancelThird", mustScroll: true);
            #endregion
        }

        private void FBS_DEPOSIT_OUTSIDE_ESCROW_TO_REBs_OTC_AND_ATTORNEY()
        {
            Reports.TestDescription = "Create the Seller and Buyer Broker , OTC and Attoney instances and assign charges from outside escrow company screen.";

            FBS_ENTER_CHARGES_OEC_OTC_ATTORNEY_ASSUMPTION_LOAN_SCREENS();

            #region Create Real State Seller & Broker instance
            Reports.TestStep = "Create the Seller and Buyer Broker instance.";
            FAST_AddRealStateBroker("408", "Buyer");
            FAST_AddRealStateBroker("488", "Seller");
            #endregion

            #region Assign charges from outside escrow company screen
            Reports.TestStep = "Assign charges from outside escrow company screen.";
            FastDriver.DepositOutsideEscrow.SetDeposit(new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit[]
                {
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.BuyersAttorney,
                         Amount = (decimal)9,
                         Comment = "FASTQA07"
                    },
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.BuyersBroker,
                         Amount = (decimal)9,
                         Comment = "FASTQA07"
                    },
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.OutsideTitleCompany,
                         Amount = (decimal)9,
                         Comment = "FASTQA07"
                    },
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.SellersBroker,
                         Amount = (decimal)9,
                         Comment = "FASTQA07"
                    }
                });
            #endregion
        }

        #endregion

        #region Verification Tests
        [TestMethod]
        [Description("Verify the Loan Amount and Sales Price in View Settlement Statement screen.")]
        public void FBS_VERIFY_SS_For_Lender()
        {
            try
            {
                Reports.TestStep = "Verify the Loan Amount and Sales Price in View Settlement Statement screen.";

                FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER();

                #region Verify view Settlement Stmt.
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").SwitchToContentFrame();

                var salePrice = FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(4, "100,000.00", 4, TableAction.GetText);
                Support.AreEqual(salePrice.Message, "100,000.00");

                var loanAmount = FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(5, "199.88", 5, TableAction.GetText);
                Support.AreEqual(loanAmount.Message, "199.88");

                var totalValue = FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(5, "99,800.12", 5, TableAction.GetText);
                Support.AreEqual(totalValue.Message, "99,800.12");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Buyer's, Seller's POC and At closing amounts from OEC, OTC , Attroney and assumption loan screens in View Settlement Statement screen.")]
        public void FBS_VERIFY_SS_For_CHARGES_FROM_OEC_OTC_ATTORNEY_ASSUMPTION_LOAN_SCREENS()
        {
            try
            {
                Reports.TestDescription = "Verify the Buyer's, Seller's POC and At closing amounts from OEC, OTC , Attroney and assumption loan screens in View Settlement Statement screen.";

                FBS_ENTER_CHARGES_OEC_OTC_ATTORNEY_ASSUMPTION_LOAN_SCREENS();

                #region Verify view Settlement Stmt.
                Reports.TestStep = "Verify view Settlement Stmt.";
                FastDriver.ViewSettlementStatement.Open();
                //  TitleEscrowTable
                Support.AreEqual("200.01", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(4, "200.01", 4, TableAction.GetText).Message, "OECBuyerCharge");
                Support.AreEqual("200.02", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(1, "200.02", 1, TableAction.GetText).Message, "OECSellerCharge");
                Support.AreEqual("300.01", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(4, "300.01", 4, TableAction.GetText).Message, "OTCBuyerCharge");
                Support.AreEqual("300.02", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(1, "300.02", 1, TableAction.GetText).Message, "OTCSellerCharge");
                //  MiscTable
                Support.AreEqual("400.01", FastDriver.ViewSettlementStatement.MiscTable.PerformTableAction(4, "400.01", 4, TableAction.GetText).Message, "ABBuyerCharge");
                Support.AreEqual("400.02", FastDriver.ViewSettlementStatement.MiscTable.PerformTableAction(1, "400.02", 1, TableAction.GetText).Message, "ABSellerCharge");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Buyer's, Seller's POC and At closing amounts from OEC, OTC , Attroney and assumption loan screens in View Settlement Statement screen.")]
        public void FBS_VERIFY_SS_For_FEES_FROM_FEE_ENTRY_SCREEN()
        {
            try
            {
                Reports.TestDescription = "Verify the Buyer's, Seller's POC and At closing amounts from OEC, OTC , Attroney and assumption loan screens in View Settlement Statement screen.";

                FBS_ENTER_BUYER_SELLER_AMOUNT_FEE_SCREEN();

                #region Verify view Settlement Stmt.
                Reports.TestStep = "Verify view Settlement Stmt.";
                FastDriver.ViewSettlementStatement.Open();
                //  TitleEscrowTable
                Support.AreEqual("12.99", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(4, "12.99", 4, TableAction.GetText).Message, "FeeBuyerCharge");
                Support.AreEqual("11.99", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(1, "11.99", 1, TableAction.GetText).Message, "FeeSellerCharge");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen (CHARGES FROM OTC, OEC, ATTORNEY, ASSUMTPION LOAN AND FEE ENTRY SCREEN) - Before issuing the charges.")]
        public void FBS_VERIFY_FBS_BEFORE_DISBURSEMENT()
        {
            try
            {
                Reports.TestDescription = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen (CHARGES FROM OTC, OEC, ATTORNEY, ASSUMTPION LOAN AND FEE ENTRY SCREEN) - Before issuing the charges.";

                FBS_ENTER_BUYER_SELLER_AMOUNT_FEE_SCREEN();

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen .";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual(FastDriver.EscrowFileBalanceSummary.DisbSummaryNetTotal.Text, "49,720.94");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen (ISSUED CHECK , CREATED  WIRE AND CREATED FEE TRANSFER) - After issuing the charges.")]
        [DeploymentItem(@"Common\Support\Hello.pdf")]
        public void FBS_VERIFY_FBS_AFTER_DISBURSEMENT()
        {
            try
            {
                Reports.TestDescription = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen (ISSUED CHECK , CREATED  WIRE AND CREATED FEE TRANSFER) - After issuing the charges.";

                FBS_ACTIVE_DISB_SUMMARY_VERIFY_CHECKS_CREATED_AND_DISBURSE();

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("(2)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Issued Checks:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("1,200.06", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Issued Checks:", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("(1)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Issued Wires:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("14.98", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Issued Wires:", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("(1)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Issued Fee Transfer:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("24.98", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Issued Fee Transfer:", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("(4)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Total Issued:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("1,240.02", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Total Issued:", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("(1)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Created Disbursement:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("48,480.92", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Created Disbursement:", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("49,720.94", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Net Total Disbursements:", 4, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Buyer's, Seller's charges from deposit in escrow screens in View Settlement Statementy screen.")]
        public void FBS_VERIFY_SS_For_CHARGES_FROM_DEPOSIT_IN_ESCROW_SCREEN()
        {
            try
            {
                Reports.TestDescription = "Verify the Buyer's, Seller's charges from deposit in escrow screens in View Settlement Statement screen.";

                FBS_TDS_STLMNT_DATE_CREATE_BUYER();

                #region Add Deposit in Escrow
                Reports.TestStep = "Add Deposit in Escrow";
                var receiptNo1 = FAST_DepositInEscrow("11.10", "Buyer", "Cash", "Additional Closing Costs");
                var receiptNo2 = FAST_DepositInEscrow("12.10", "Buyer", "Cash", "Initial Deposit");
                var receiptNo3 = FAST_DepositInEscrow("13.10", "Buyer", "Cash", "Additional Closing Costs");
                var receiptNo4 = FAST_DepositInEscrow("14.10", "Seller", "Cash", "Additional Closing Costs");
                var receiptNo5 = FAST_DepositInEscrow("15.10", "Seller", "Cash", "Initial Deposit");
                var receiptNo6 = FAST_DepositInEscrow("16.10", "Seller", "Cash", "Additional Closing Costs");
                var receiptNo7 = FAST_DepositInEscrow("17.10", "New Lender", "Cash", "Additional Closing Costs");
                var receiptNo8 = FAST_DepositInEscrow("18.10", "New Lender", "Cash", "Initial Deposit");
                var receiptNo9 = FAST_DepositInEscrow("19.10", "New Lender", "Cash", "Additional Closing Costs");
                #endregion

                #region Verify view Settlement Stmt.
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").SwitchToContentFrame();
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();
                var expectedFormat = "Deposit: Receipt No. {0} on " + DateTime.Now.ToString("MM/dd/yyyy") + " by Mr. Burns";
                Support.AreEqual(string.Format(expectedFormat, receiptNo1), FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(5, "11.10", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Format(expectedFormat, receiptNo2), FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(5, "12.10", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Format(expectedFormat, receiptNo3), FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(5, "13.10", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Format(expectedFormat, receiptNo4), FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(2, "14.10", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Format(expectedFormat, receiptNo5), FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(2, "15.10", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Format(expectedFormat, receiptNo6), FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(2, "16.10", 3, TableAction.GetText).Message.Trim());
                //  New Lender Deposits in Escrow are not listed.
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen - After Entering charges in Deposit in Escrow.")]
        public void FBS_VERIFY_FBS_AFTER_DEPOSIT_IN_ESCROW()
        {
            try
            {
                Reports.TestDescription = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen - After Entering charges in Deposit in Escrow.";

                FBS_TDS_STLMNT_DATE_CREATE_BUYER();

                #region Add Deposit in Escrow
                Reports.TestStep = "Add Deposit in Escrow";
                FAST_DepositInEscrow("11.10", "Buyer", "Cash", "Additional Closing Costs");
                FAST_DepositInEscrow("12.10", "Buyer", "Cash", "Initial Deposit");
                FAST_DepositInEscrow("13.10", "Buyer", "Cash", "Additional Closing Costs");
                FAST_DepositInEscrow("14.10", "Seller", "Cash", "Additional Closing Costs");
                FAST_DepositInEscrow("15.10", "Seller", "Cash", "Initial Deposit");
                FAST_DepositInEscrow("16.10", "Seller", "Cash", "Additional Closing Costs");
                FAST_DepositInEscrow("17.10", "New Lender", "Cash", "Additional Closing Costs");
                FAST_DepositInEscrow("18.10", "New Lender", "Cash", "Initial Deposit");
                FAST_DepositInEscrow("19.10", "New Lender", "Cash", "Additional Closing Costs");
                #endregion

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen .";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("Issued:", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(9)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("36.30", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(9)", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("45.30", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(9)", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("54.30", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(9)", 8, TableAction.GetText).Message.Trim());
                Support.AreEqual("135.90", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(9)", 10, TableAction.GetText).Message.Trim());
                //  New Lender Deposits in Escrow are not listed.
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Create IBA transaction and verify issued IBA amount in active disbursements screen.")]
        public void FBS_VERIFY_DISBURSEMENT_AFTER_IBA_CREATED()
        {
            try
            {
                Reports.TestDescription = "Create IBA transaction and verify issued IBA amount in active disbursements screen.";

                FBS_TDS_STLMNT_DATE_CREATE_BUYER();

                #region Add Deposit in Escrow
                Reports.TestStep = "Add Deposit in Escrow";
                FAST_DepositInEscrow("19.99", "Buyer", "Cash", "Additional Closing Costs", "Bart Simpson");
                #endregion

                #region Enter Charges in Interests Bearing Accounts
                Reports.TestStep = "Enter Charges in Interests Bearing Accounts";
                FAST_AddIBATransaction("19.99");
                #endregion

                #region Verify in Active Disbursement Summary
                Reports.TestStep = "Verified the issued IBA in Active Disbursment screen.";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "19.99", 1, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Issued IBA Disbursements Amount in Deposit/Disbursement Summary Section in File Balance Summary screen - After issuing IBA.")]
        public void FBS_VERIFY_FBS_AFTER_IBA_ISSUED()
        {
            try
            {
                Reports.TestDescription = "Verify the Issued IBA Disbursements Amount in Deposit/Disbursement Summary Section in File Balance Summary screen - After issuing IBA.";

                FBS_TDS_STLMNT_DATE_CREATE_BUYER();

                #region Add Deposit in Escrow
                Reports.TestStep = "Add Deposit in Escrow";
                FAST_DepositInEscrow("19.99", "Buyer", "Cash", "Additional Closing Costs", "Bart Simpson");
                #endregion

                #region Enter Charges in Interests Bearing Accounts
                Reports.TestStep = "Enter Charges in Interests Bearing Accounts";
                FAST_AddIBATransaction("19.99");
                #endregion

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen .";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("Issued:", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(1)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("19.99", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(1)", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(1)", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(1)", 8, TableAction.GetText).Message.Trim());
                Support.AreEqual("19.99", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(1, "(1)", 10, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Held Check Status in Deposit/Disbursement Summary Section in File Balance Summary screen.")]
        public void FBS_VERIFY_FBS_CHECK_STATUS_AS_HELD()
        {
            try
            {
                Reports.TestDescription = "Verify the Held Check Status in Deposit/Disbursement Summary Section in File Balance Summary screen.";

                FBS_ENTER_BUYER_SELLER_AMOUNT_FEE_SCREEN();

                #region Hold a check
                Reports.TestStep = "Change the status of check to held.";
                FAST_HoldDisbursement("48,480.92", "7", "Security");
                #endregion

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("(1)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Held Checks:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("48,480.92", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Held Checks:", 4, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Add a Fee with At Closing Method as FEE and Assigned charges to Lender paid by other")]
        public void FBS_VERIFY_SS_For_CHARGES_FROM_FEE_POL_L_SCREEN()
        {
            try
            {
                Reports.TestDescription = "Add a Fee with At Closing Method as FEE and Assigned charges to Lender paid by other";

                FBS_ADD_A_FEE_FOR_HOLD();
                
                #region Verify view Settlement Stmt.
                Reports.TestStep = "Verify the Fee assigned to Lender in File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();
                var tableContent = FastDriver.ViewSettlementStatement.TitleEscrowTable.FAGetText();
                var expectedText = "Closing Service Coordination to QA Automation Office - DO NOT TOUCH POC-L $22.98";
                Support.IsTrue(tableContent.Contains(expectedText), "Verify Title/Escrow Charges holder in View Settlement Stmt.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Held Fee Status in Deposit/Disbursement Summary Section in File Balance Summary screen.")]
        public void FBS_VERIFY_FBS_FEE_STATUS_AS_HELD()
        {
            try
            {
                Reports.TestDescription = "Verify the Held Fee Status in Deposit/Disbursement Summary Section in File Balance Summary screen.";

                FBS_ADD_A_FEE_FOR_HOLD();

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("(1)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Held Fee Transfer:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("22.98", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Held Fee Transfer:", 4, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Buyer's, Seller's charges from deposit in escrow screens AFTER ADJUSTMENT in View Settlement Statement screen.")]
        public void FBS_VERIFY_SS_AFTER_ADJUSTING_DEPOSITS()
        {
            try
            {
                Reports.TestDescription = "Verify the Buyer's, Seller's charges from deposit in escrow screens AFTER ADJUSTMENT in View Settlement Statement screen.";

                FBS_ADJUST_CANCEL_DEPOSITS_CREATED_ON_DEPOSIT_IN_ESCROW();
                
                #region Verify view Settlement Stmt.
                Reports.TestStep = "Verify the Fee assigned to Lender in File Balance Summary screen.";
                FastDriver.ViewSettlementStatement.Open();
                List<string> rowTextList = new List<string>(FastDriver.ViewSettlementStatement.SummaryTable.Text.Split(new string[] { Environment.NewLine }, StringSplitOptions.None));
                Support.IsTrue(!rowTextList.Exists(x => x.Contains("12.10")), "Adjusted deposit 12.10 is removed from view Settlement Stmt.");
                Support.IsTrue(!rowTextList.Exists(x => x.Contains("15.10")), "Adjusted deposit 15.10 is removed from view Settlement Stmt");
                Support.IsTrue(!rowTextList.Exists(x => x.Contains("18.10")), "Adjusted deposit 18.10 is removed from view Settlement Stmt");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Cancelled adjustment Status in Deposit/Disbursement Summary Section in File Balance Summary screen.")]
        public void FBS_VERIFY_ADJUSTMENT_CANCELLED()
        {
            try
            {
                Reports.TestDescription = "Verify the Cancelled adjustment Status in Deposit/Disbursement Summary Section in File Balance Summary screen.";

                FBS_ADJUST_CANCEL_DEPOSITS_CREATED_ON_DEPOSIT_IN_ESCROW();

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the the Cancelled adjustment in Deposit/Disbursement Summary Section in File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("12.10-", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Adjustments:", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("15.10-", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Adjustments:", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("18.10-", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Adjustments:", 8, TableAction.GetText).Message.Trim());
                Support.AreEqual("45.30-", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Net Adjustments:", 10, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Adjust the issued check and verify in file balance summary screen.")]
        public void FBS_VERIFY_ADJUST_AN_ISSUED_CHECK()
        {
            try
            {
                Reports.TestDescription = "Adjust the issued check and verify in file balance summary screen.";

                FBS_ENTER_BUYER_SELLER_AMOUNT_FEE_SCREEN();

                #region disburse checks
                Reports.TestStep = "Disburse OEC and OTC checks";
                var docNo1 = FAST_DisburseCheck("800.03");
                var docNo2 = FAST_DisburseCheck("400.03");
                #endregion

                #region Adjust Issued checks
                Reports.TestStep = "Adjust Issued checks";
                FAST_AdjustDisbursement("800.03", 0, "CancelFirst", docNo: docNo1);
                FAST_AdjustDisbursement("400.03", 0, "CancelFirst", docNo: docNo2);
                #endregion

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the issued adjustment in File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("(2)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Issued Checks:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("1,200.06", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Issued Checks:", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("1,200.06-", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Net Adjustments:", 4, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Earnest Money Held in View Settlement Statement screen.")]
        public void FBS_VERIFY_SS_Earnest_Money_held_Deposit_Outside_Escrow()
        {
            try
            {
                Reports.TestDescription = "Verify the Earnest Money Held in View Settlement Statement screen.";

                FBS_DEPOSIT_OUTSIDE_ESCROW_TO_REBs_OTC_AND_ATTORNEY();

                #region Verify view Settlement Stmt.
                Reports.TestStep = "Verify the Fee assigned to Lender in View Settlement Statement screen.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").SwitchToContentFrame();
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();
                Support.AreEqual("Total Deposit/Earnest Money", FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(5, "36.00", 3, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Deposit Outside Escrow Amount in Deposit/Disbursement Summary Section in File Balance Summary screen.")]
        public void FBS_VERIFY_DEPOSIT_OUTSIDE_ESCROW_AMOUNT()
        {
            try
            {
                Reports.TestDescription = "Verify the Deposit Outside Escrow Amount in Deposit/Disbursement Summary Section in File Balance Summary screen.";

                FBS_DEPOSIT_OUTSIDE_ESCROW_TO_REBs_OTC_AND_ATTORNEY();

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen .";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Issued:", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Issued:", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Issued:", 8, TableAction.GetText).Message.Trim());
                Support.AreEqual("0.00", FastDriver.EscrowFileBalanceSummary.DepositToEscrowSummaryTotals.PerformTableAction(2, "Issued:", 10, TableAction.GetText).Message.Trim());
                //  Deposits Outside Escrow are not listed.
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Loan Amount,Net Charges, Net Fees and Projected Loan Funding Amount in Loan_Proceeds_Summary Table in File Balance Summary screen.")]
        public void FBS_VERIFY_LOAN_PROCEEDS_SUMMARY()
        {
            try
            {
                Reports.TestDescription = "Verify Loan Amount,Net Charges, Net Fees and Projected Loan Funding Amount in Loan_Proceeds_Summary Table in File Balance Summary screen.";

                FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER();

                #region Adding loan charges
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.Click();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("10.99");
                FastDriver.NewLoan.LoanChargesOriginationChargebuyercharge.FASetText("16.99");
                FastDriver.NewLoan.LoanChargesOriginationChargeSellercharge.FASetText("17.99");
                FastDriver.NewLoan.LoanChargesNewLoanChargesBuyerCharge1.FASetText("16.99");
                FastDriver.NewLoan.LoanChargesNewLoanChargesSellerCharge1.FASetText("17.99");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("10.99");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("10.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the Amount in Deposit/Disbursement Summary Section in File Balance Summary screen .";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("Exchange Development Company, L.L.C.", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(2, "199.88", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("-58.97", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(2, "199.88", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("140.91", FastDriver.EscrowFileBalanceSummary.LoanProceedsSummaryTable.PerformTableAction(2, "199.88", 5, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Origination ,Impound,new Loan charges and interest calculation charges on SS screen.")]
        public void FBS_VERIFY_SS_For_New_loan_Charges()
        {
            try
            {
                Reports.TestDescription = "Verify the Origination ,Impound,new Loan charges and interest calculation charges on SS screen.";

                FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER();

                #region Adding loan charges
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.Click();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("10.99");
                FastDriver.NewLoan.LoanChargesOriginationChargebuyercharge.FASetText("16.99");
                FastDriver.NewLoan.LoanChargesOriginationChargeSellercharge.FASetText("17.99");
                FastDriver.NewLoan.LoanChargesNewLoanChargesBuyerCharge1.FASetText("16.99");
                FastDriver.NewLoan.LoanChargesNewLoanChargesSellerCharge1.FASetText("17.99");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("10.99");
                FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("10.99");
                FastDriver.BottomFrame.Done();
                #endregion
                
                #region Verify view Settlement Stmt.
                Reports.TestStep = "Verify the Origination ,Impound,new Loan charges and interest calculation charges on SS screen.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").SwitchToContentFrame();
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();
                Support.stringHelper.CR = false;
                Support.stringHelper.LF = false;
                Support.AreEqual("Loan Amount- Exchange Development Company, L.L.C.", FastDriver.ViewSettlementStatement.SummaryTable.PerformTableAction(5, "199.88", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("Prepaid Interest", FastDriver.ViewSettlementStatement.LoanCharges.PerformTableAction(4, "10.99", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("Application Fee", FastDriver.ViewSettlementStatement.LoanCharges.PerformTableAction(4, "16.99", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("Application Fee", FastDriver.ViewSettlementStatement.LoanCharges.PerformTableAction(1, "17.99", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("Aggregate Adjustment", FastDriver.ViewSettlementStatement.ImpoundsTable.PerformTableAction(2, "10.99", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("Aggregate Adjustment", FastDriver.ViewSettlementStatement.ImpoundsTable.PerformTableAction(5, "10.99", 3, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Hold Fund For Buyer and Seller..")]
        public void FBS_VERIFY_HELD_FUNDS_FOR_BUYER_AND_SELLER()
        {
            try
            {
                Reports.TestDescription = "Hold Fund For Buyer and Seller..";

                FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER();

                #region Hold Funds for Buyer & Seller
                Reports.TestStep = "Hold Fund For Seller.";
                FAST_AddHoldFunds(isBuyer: true, reason: "Hold funds for Seller", releaseDays: "7", charge: "999.99", gabCode: "246", hfCharge: "777.77");
                FAST_AddHoldFunds(isBuyer: false, reason: "Hold funds for Seller", releaseDays: "7", charge: "999.99", gabCode: "246", hfCharge: "777.77");
                #endregion

                #region Verify File Balance Summary
                Reports.TestStep = "Verify Hold Fund For Buyer and Selle in File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("222.22", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Buyer", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("222.22", FastDriver.EscrowFileBalanceSummary.BuyerSellerAmountsTable.PerformTableAction(1, "Seller", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("(2)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Pending Issue:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("1,555.54", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Pending Issue:", 4, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the HOLD FUND charges on SS screen.")]
        public void FBS_VERIFY_SS_For_Held_Fund_Charges()
        {
            try
            {
                Reports.TestDescription = "Verify the HOLD FUND charges on SS screen.";

                FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER();

                #region Hold Funds for Buyer & Seller
                Reports.TestStep = "Hold Fund For Seller.";
                FAST_AddHoldFunds(isBuyer: true, reason: "Hold funds for Seller", releaseDays: "7", charge: "999.99", gabCode: "246", hfCharge: "777.77");
                FAST_AddHoldFunds(isBuyer: false, reason: "Hold funds for Seller", releaseDays: "7", charge: "999.99", gabCode: "246", hfCharge: "777.77");
                #endregion
                
                #region Verify view Settlement Stmt.
                Reports.TestStep = "Verify the HOLD FUND charges on SS screen.";
                FastDriver.ViewSettlementStatement.Open();
                List<string> rowTextList = new List<string>(FastDriver.ViewSettlementStatement.FundsHeldTable.Text.Split(new char[] { (char)13, (char)10 }, StringSplitOptions.None));
                Support.AreEqual("222.22", rowTextList.Find(x => x.Contains("222.22")).ToString());
                Support.AreEqual("222.22", rowTextList.FindLast(x => x.Contains("222.22")).ToString());
                Support.AreEqual("777.77", rowTextList.Find(x => x.Contains("777.77")).ToString());
                Support.AreEqual("777.77", rowTextList.FindLast(x => x.Contains("777.77")).ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Enter Fee Amount for Fee Payment method as FEE and assign to Mortgage Broker")]
        public void FBS_VERIFY_ASSIGNED_FEE_TO_MORTGAGE_BROKER()
        {
            try
            {
                Reports.TestDescription = "Enter Fee Amount for Fee Payment method as FEE and assign to Mortgage Broker";

                FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER();

                #region Assign fee to mortgage broker
                Reports.TestStep = "Enter Fee Amount for Fee Payment method as FEE and assign to Mortgage Broker";
                FAST_AddFileFees(new PDD[]{ 
                new PDD() { ChargeDescription = "ALTA Extended Loan - 115% liability", BuyerPaidbyOther = 2443.99, BuyerPaidbyOtherPaymentMethod = "Mortgage Broker", SellerPaidbyOthers = 2443.99, SellerPaidbyOtherPaymentMthd = "Mortgage Broker" }
            });
                #endregion

                #region Verify File Balance Summary
                Reports.TestStep = "Verify the Deposit Outside Escrow Amount in Deposit/Disbursement Summary Section in File Balance Summary screen.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("(1)", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Pending Issue:", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("4,887.98", FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotals.PerformTableAction(2, "Pending Issue:", 4, TableAction.GetText).Message.Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the Fee Assigned to MB in settlement statement.")]
        public void FBS_VERIFY_SS_FEE_ASSIGNEDTO_MB()
        {
            try
            {
                Reports.TestDescription = "Verify the Fee Assigned to MB in settlement statement.";

                FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER();

                #region Assign fee to mortgage broker
                Reports.TestStep = "Enter Fee Amount for Fee Payment method as FEE and assign to Mortgage Broker";
                FAST_AddFileFees(new PDD[] {
                    new PDD() { ChargeDescription = "ALTA Extended Loan - 115% liability", BuyerPaidbyOther = 2443.99, BuyerPaidbyOtherPaymentMethod = "Mortgage Broker", SellerPaidbyOthers = 2443.99, SellerPaidbyOtherPaymentMthd = "Mortgage Broker" }
                });
                #endregion
                
                #region Verify view Settlement Stmt.
                Reports.TestStep = "Verify the HOLD FUND charges on SS screen.";
                FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.").SwitchToContentFrame();
                FastDriver.ViewSettlementStatement.SwitchToContentFrame();
                Support.AreEqual("ALTA Extended Loan - 115% liability to QA Automation Office - DO NOT TOUCH POC-MB $4887.98", FastDriver.ViewSettlementStatement.TitleEscrowTable_ChargeDesc.FAGetText(), "Verify Title/Escrow Charges holder in View Settlement Statement");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Deposit Fund on OTC and verify on FBS screen.")]
        public void FBS_VERIFY_FUNDS_DEPOSITED_WITH_OTC()
        {
            try
            {
                Reports.TestDescription = "Deposit Fund on OTC and verify on FBS screen.";

                FBS_LOGIN_CREATE_ORDER_NEW_LOAN_INSTANCE_BUYER();

                #region Enter Charges in Outside Title Company Screen screen.
                Reports.TestStep = "Enter Charge on OTC";
                FAST_WCF_CreateOutsideTitleCompany();
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>("Home>Order Entry>Outside Title Company");
                FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.OutsideTitleCompanyDetail.TitleServiceDescription1.FAGetAttribute("value"), "UAT Entry");
                FastDriver.OutsideTitleCompanyDetail.FundsDepositedEdit.FASetText("233.33");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify File Balance Summary
                Reports.TestStep = "Verify File Balance summary Table in FBS.";
                FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
                FastDriver.EscrowFileBalanceSummary.SwitchToContentFrame();
                Support.AreEqual("233.33-", FastDriver.EscrowFileBalanceSummary.FBSProjectedTable.PerformTableAction(1, "Funds Deposited with OTC:", 3, TableAction.GetText).Message.Trim());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the total amount from various source screen on settlement statement.")]
        [DeploymentItem(@"Common\Support\Hello.pdf")]
        public void FBS_VERIFY_SS_TOTAL_CHARGES()
        {
            try
            {
                Reports.TestDescription = "Verify the total amount from various source screen on settlement statement.";

                FBS_ACTIVE_DISB_SUMMARY_VERIFY_CHECKS_CREATED_AND_DISBURSE();

                #region Update Settlement Date in TDS
                Reports.TestStep = "Update Settlement Date in TDS";
                FAST_WCF_UpdateTermsDatesStatus();
                #endregion

                #region Add Seller
                Reports.TestStep = "Adding a Seller instance";
                FAST_WCF_AddBuyerSeller("Seller");
                #endregion

                #region Hold a check
                Reports.TestStep = "Change the status of check to held.";
                FAST_HoldDisbursement("48,480.92", "7", "Security");
                #endregion

                #region FileFees
                Reports.TestStep = "Enter Fee Amount for Fee Payment method as FEE";
                FAST_AddFileFees(new PDD[]{
                    new PDD() { ChargeDescription = "Closing Service Coordination", BuyerPaidbyOther = 11.99, BuyerPaidbyOtherPaymentMethod = "Lender", BuyerLenderCheckbox = true, SellerPaidbyOthers = 10.99, SellerPaidbyOtherPaymentMthd = "Lender", SellerLenderCheckbox = true }
                });
                #endregion

                #region Hold a fee
                Reports.TestStep = "Change the status of check to held.";
                FAST_HoldDisbursement("22.98", "7", "Security");
                #endregion

                #region Add Deposit in Escrow
                Reports.TestStep = "Add Deposit in Escrow";
                receipts[0] = FAST_DepositInEscrow("11.10", "Buyer", "Cash", "Additional Closing Costs");
                receipts[1] = FAST_DepositInEscrow("12.10", "Buyer", "Cash", "Initial Deposit");
                receipts[2] = FAST_DepositInEscrow("13.10", "Buyer", "Cash", "Additional Closing Costs");
                receipts[3] = FAST_DepositInEscrow("14.10", "Seller", "Cash", "Additional Closing Costs");
                receipts[4] = FAST_DepositInEscrow("15.10", "Seller", "Cash", "Initial Deposit");
                receipts[5] = FAST_DepositInEscrow("16.10", "Seller", "Cash", "Additional Closing Costs");
                receipts[6] = FAST_DepositInEscrow("17.10", "New Lender", "Cash", "Additional Closing Costs");
                receipts[7] = FAST_DepositInEscrow("18.10", "New Lender", "Cash", "Initial Deposit");
                receipts[8] = FAST_DepositInEscrow("19.10", "New Lender", "Cash", "Additional Closing Costs");
                #endregion

                #region Adjust deposits
                FAST_AdjustDeposit("12.10", 0, "CancelFirst");
                FAST_AdjustDeposit("15.10", 0, "CancelSecond");
                FAST_AdjustDeposit("18.10", 0, "CancelThird", mustScroll: true);
                #endregion

                #region Create Real State Seller & Broker instance
                Reports.TestStep = "Create the Seller and Buyer Broker instance.";
                FAST_AddRealStateBroker("408", "Buyer");
                FAST_AddRealStateBroker("488", "Seller");
                #endregion

                #region Assign charges from outside escrow company screen
                Reports.TestStep = "Assign charges from outside escrow company screen.";
                FastDriver.DepositOutsideEscrow.SetDeposit(new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit[]
                {
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.BuyersAttorney,
                         Amount = (decimal)9,
                         Comment = "FASTQA07"
                    },
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.BuyersBroker,
                         Amount = (decimal)9,
                         Comment = "FASTQA07"
                    },
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.OutsideTitleCompany,
                         Amount = (decimal)9,
                         Comment = "FASTQA07"
                    },
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.SellersBroker,
                         Amount = (decimal)9,
                         Comment = "FASTQA07"
                    }
                });
                #endregion

                #region Verify Deposit/Receipt History
                Reports.TestStep = "Verify Deposit/Receipt History";
                FastDriver.DepositSummary.Open();
                //  Issued:     Buyer   Seller  Other   Totals
                Support.AreEqual("36.30", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Issued:", 3, TableAction.GetText, startOffRow: 2).Message.Trim());
                Support.AreEqual("45.30", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Issued:", 5, TableAction.GetText, startOffRow: 2).Message.Trim());
                Support.AreEqual("54.30", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Issued:", 7, TableAction.GetText, startOffRow: 2).Message.Trim());
                Support.AreEqual("135.90", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Issued:", 9, TableAction.GetText, startOffRow: 2).Message.Trim());
                //  Net Adjustments:    Buyer   Seller  Other   Totals
                Support.AreEqual("12.10-", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Net Adjustments:", 3, TableAction.GetText, startOffRow: 3).Message.Trim());
                Support.AreEqual("15.10-", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Net Adjustments:", 5, TableAction.GetText, startOffRow: 3).Message.Trim());
                Support.AreEqual("18.10-", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Net Adjustments:", 7, TableAction.GetText, startOffRow: 3).Message.Trim());
                Support.AreEqual("45.30-", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Net Adjustments:", 9, TableAction.GetText, startOffRow: 3).Message.Trim());
                //  Net Deposits:    Buyer   Seller  Other   Totals
                Support.AreEqual("24.20", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Net Deposits:", 3, TableAction.GetText, startOffRow: 4).Message.Trim());
                Support.AreEqual("30.20", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Net Deposits:", 5, TableAction.GetText, startOffRow: 4).Message.Trim());
                Support.AreEqual("36.20", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Net Deposits:", 7, TableAction.GetText, startOffRow: 4).Message.Trim());
                Support.AreEqual("90.60", FastDriver.DepositSummary.DepositReceiptHistoryTable.PerformTableAction(1, "Net Deposits:", 9, TableAction.GetText, startOffRow: 4).Message.Trim());
                #endregion

                #region Verify Active Disbursement Summary
                Reports.TestStep = " Verify Active Disbursement Summary";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("1,240.02", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(1, "Issued: $", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("0.00", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(3, "Net Adj: $", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("1,240.02", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(5, "Net Issued: $", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("0.00", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(1, "Created: $", 2, TableAction.GetText, startOffRow: 2).Message.Trim());
                Support.AreEqual("19,982.00", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(1, "Pending: $", 2, TableAction.GetText, startOffRow: 3).Message.Trim());
                //Support.AreEqual("28,534.10", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(1, "Held: $", 2, TableAction.GetText, startOffRow: 3).Message.Trim());
                Support.AreEqual("49,756.12", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(1, "Net Disb.: $", 2, TableAction.GetText, startOffRow: 5).Message.Trim());
                Support.AreEqual("90.60", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(1, "Deposits: $", 2, TableAction.GetText, startOffRow: 6).Message.Trim());
                Support.AreEqual("1,240.02", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(3, "Net Issued: $", 4, TableAction.GetText, startOffRow: 6).Message.Trim());
                Support.AreEqual("1,149.42-", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(5, "Available: $", 6, TableAction.GetText, startOffRow: 6).Message.Trim());
                Support.AreEqual("49,665.52-", FastDriver.ActiveDisbursementSummary.ActiveDisbSummaryTable.PerformTableAction(1, "Excess/Short: $", 2, TableAction.GetText, startOffRow: 7).Message.Trim());
                Support.AreEqual("0", FastDriver.ActiveDisbursementSummary.ActiveDisbSumQuantityTable.PerformTableAction(1, "Created:", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("2", FastDriver.ActiveDisbursementSummary.ActiveDisbSumQuantityTable.PerformTableAction(3, "Pending:", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("2", FastDriver.ActiveDisbursementSummary.ActiveDisbSumQuantityTable.PerformTableAction(5, "Held:", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("4", FastDriver.ActiveDisbursementSummary.ActiveDisbSumQuantityTable.PerformTableAction(7, "Issued:", 8, TableAction.GetText).Message.Trim());
                #endregion
                
                #region Verify view Settlement Stmt.
                Reports.TestStep = "Verify the HOLD FUND charges on SS screen.";
                FastDriver.ViewSettlementStatement.Open();
                var subtotalTableText = FastDriver.ViewSettlementStatement.SubTotalsTable.FAGetText().Trim();
                List<string> rowTextList = new List<string>(subtotalTableText.Split(new char[] { (char)13, (char)10 }, StringSplitOptions.RemoveEmptyEntries));
                Support.AreEqual("Due From Buyer 51,260.95", rowTextList.Find(x => x.Contains("51,260.95")).ToString());
                Support.AreEqual("28,493.12 Due To Seller", rowTextList.Find(x => x.Contains("28,493.12")).ToString());
                Support.AreEqual("100,030.20 100,030.20 Totals 101,521.03 101,521.03", rowTextList.Find(x => x.Contains("100,030.20")).ToString());
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the charges entered are saved and present on View Settlement Stmt. screen.")]
        [DeploymentItem(@"Common\Support\Hello.pdf")]
        public void FBS_VERIFY_SS_CHARGES_ENTERED()
        {
            try
            {
                Reports.TestDescription = "Verify the charges entered are saved and present on View Settlement Stmt. screen.";

                FBS_VERIFY_SS_TOTAL_CHARGES();

                #region Continue: Verify view Settlement Stmt.
                Reports.TestStep = "Verify the HOLD FUND charges on SS screen.";
                FastDriver.ViewSettlementStatement.Open();
                //  Financial
                Support.AreEqual("100,000.00", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(2, "100,000.00", 2, TableAction.GetText).Message, "Sale Price");
                Support.AreEqual("199.88", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(5, "199.88", 5, TableAction.GetText).Message, "Loan Amount");
                Support.AreEqual("50,000.00", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(1, "50,000.00", 1, TableAction.GetText).Message, "Unpaid Principal Balance");
                Support.AreEqual("6.99 ", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(1, "6.99", 1, TableAction.GetText).Message, "UAT Charge-updated");
                Support.AreEqual("Deposit: Receipt No. " + receipts[0] + " on " + DateTime.Today.ToString("MM/dd/yyyy") + " by Mr. Burns", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(5, "11.10", 3, TableAction.GetText).Message, "Receipt No. 1");
                Support.AreEqual("Deposit: Receipt No. " + receipts[2] + " on " + DateTime.Today.ToString("MM/dd/yyyy") + " by Mr. Burns", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(5, "13.10", 3, TableAction.GetText).Message, "Receipt No. 2");
                Support.AreEqual("Deposit: Receipt No. " + receipts[3] + " on " + DateTime.Today.ToString("MM/dd/yyyy") + " by Mr. Burns", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(2, "14.10", 3, TableAction.GetText).Message, "Receipt No. 3");
                Support.AreEqual("Deposit: Receipt No. " + receipts[5] + " on " + DateTime.Today.ToString("MM/dd/yyyy") + " by Mr. Burns", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(2, "16.10", 3, TableAction.GetText).Message, "Receipt No. 4");
                Support.AreEqual("36.00", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(5, "36.00", 5, TableAction.GetText).Message, "Total Deposit/Earnest Money");
                Support.AreEqual("9.00", FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(1, "9.00", 1, TableAction.GetText).Message, "Earnest Money Held By: Flannery, Hoover & Boyd");
                //  Title Escrow Charges
                Support.AreEqual("11.99", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(1, "11.99", 1, TableAction.GetText).Message, "New Home Rate (Title Only) to QA Automation Office - DO NOT TOUCH | Buyer Debit");
                Support.AreEqual("12.99", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(4, "12.99", 4, TableAction.GetText).Message, "New Home Rate (Title Only) to QA Automation Office - DO NOT TOUCH | Seller Debit");
                Support.AreEqual("200.02", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(1, "200.02", 1, TableAction.GetText).Message, "UAT Entry to Flannery, Hoover & Boyd | Buyer Debit");
                Support.AreEqual("200.01", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(4, "200.01", 4, TableAction.GetText).Message, "UAT Entry to Flannery, Hoover & Boyd | Seller Debit");
                Support.AreEqual("300.02", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(1, "300.02", 1, TableAction.GetText).Message, "UAT Entry to Flannery, Hoover & Boyd | Buyer Debit");
                Support.AreEqual("300.01", FastDriver.ViewSettlementStatement.TitleEscrowTable.PerformTableAction(4, "300.01", 4, TableAction.GetText).Message, "UAT Entry to Flannery, Hoover & Boyd | Seller Debit");
                //  Commission
                Support.AreEqual("9,991.00", FastDriver.ViewSettlementStatement.CommissionTable.PerformTableAction(1, "9,991.00", 1, TableAction.GetText).Message, "Real Estate Commission to Exchange Development Company, L.L.C.");
                //  Miscellaneous
                Support.AreEqual("400.02", FastDriver.ViewSettlementStatement.MiscTable.PerformTableAction(1, "400.02", 1, TableAction.GetText).Message, "UAT Entry to Flannery, Hoover & Boyd | Buyer Debit");
                Support.AreEqual("400.01", FastDriver.ViewSettlementStatement.MiscTable.PerformTableAction(4, "400.01", 4, TableAction.GetText).Message, "UAT Entry to Flannery, Hoover & Boyd | Seller Debit");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
