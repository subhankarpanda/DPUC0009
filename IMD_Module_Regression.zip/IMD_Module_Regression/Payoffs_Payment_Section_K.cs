﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using AutoIt;


namespace IMD_Module_Regression
{
    /// <summary>
    /// Payoffs Payment Section K
    /// </summary>
    [CodedUITest]
    public class Payoffs_Payment_Section_K : MasterTestClass
    {

        double[] Charge = new double[20];
        string[] Desc = new string[20];
        string[] Tmp = new string[20];
        string NewDesc;
                

        [TestMethod]
        public void FTR5_ITR45_US_369584_TC_403188_ConstructionDisb()
        {
            try
            { 
                Reports.TestDescription = "USER STORY 369584 : CD SCREEN - SECTION K - PAYOFFS AND PAYMENTS - VERIFY  PAYOFFS AND PAYMENTS TABLE ON THE CD SCREEN WHEN THE FILE PURPOSE IS REFINANCE/CONSTRUCTION/HOME EQUITY.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE WITH PURPOSE AS *****CONSTRUCTION DISBURSEMENT*****";
                CreateFile("CD");

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                
                VerifyPayoffPaymentSection();

                Reports.TestStep = "VERIFY SUMARIES OF TRANSACTION SECTION SHOULD NOT BE DISPLAYED";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.Summary_Of_Trans.Exists().ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR45_US_369584_TC_403188_EquityLoan()
        {
            try
            { 
                Reports.TestDescription = "USER STORY 369584 : CD SCREEN - SECTION K - PAYOFFS AND PAYMENTS - VERIFY  PAYOFFS AND PAYMENTS TABLE ON THE CD SCREEN WHEN THE FILE PURPOSE IS REFINANCE/CONSTRUCTION/HOME EQUITY.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE WITH PURPOSE AS *****EQUITY LOAN*****";
                CreateFile("LOAN");

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                VerifyPayoffPaymentSection();

                Reports.TestStep = "VERIFY SUMARIES OF TRANSACTION SECTION SHOULD NOT BE DISPLAYED";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.Summary_Of_Trans.Exists().ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR45_US_369584_TC_403188_MortgageModification()
        {
            try
            { 
                Reports.TestDescription = "USER STORY 369584 : CD SCREEN - SECTION K - PAYOFFS AND PAYMENTS - VERIFY  PAYOFFS AND PAYMENTS TABLE ON THE CD SCREEN WHEN THE FILE PURPOSE IS REFINANCE/CONSTRUCTION/HOME EQUITY.";
            
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE WITH PURPOSE AS *****MORTGAGE MODIFICATION*****";
                CreateFile("MORTGMODI");

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                VerifyPayoffPaymentSection();

                Reports.TestStep = "VERIFY SUMARIES OF TRANSACTION SECTION SHOULD NOT BE DISPLAYED";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.Summary_Of_Trans.Exists().ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #region USER STORY 369584 : VERIFY  PAYOFFS AND PAYMENTS TABLE ON THE CD SCREEN WHEN THE FILE PURPOSE IS OTHER THAN REFINANCE/CONSTRUCTION/HOME EQUITY/MORTGAGE MODIFICATION

        [TestMethod]
        public void FTR5_ITR45_US_369584_TC_403193()
        {
            try
            { 
                Reports.TestDescription = "USER STORY 369584 : CD SCREEN - SECTION K - PAYOFFS AND PAYMENTS - VERIFY  PAYOFFS AND PAYMENTS TABLE ON THE CD SCREEN WHEN THE FILE PURPOSE IS OTHER THAN REFINANCE/CONSTRUCTION/HOME EQUITY.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE WITH PURPOSE AS *****ACCOMMODATION*****";
                CreateFile("ACCOMODAT");

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "VERIFY PAYOFFS AND PAYMENTS SECTION";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.Section_Payoffs.Exists().ToString());

                Reports.TestStep = "VERIFY SUMARIES OF TRANSACTION SECTION SHOULD BE DISPLAYED";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.Summary_Of_Trans.Exists().ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion



        #region USER STORY 401977: CD SCREEN – SECTION K: AUTO-POPULATE THE PAYOFFS AND PAYMENTS CHARGES DETAILS TO THE SECTION K

        [TestMethod]
        public void FTR5_ITR45_US_401977_TC_464281_AutoPopulate1()
        {
            try
            {
                Reports.TestDescription = "VERIFY PAYOFF LOAN ,PROPERTY CHECK, ADJUSTMENT SECTION K CHARGES DISPLAYED IN THE PAYOFFS AND PAYMENTS SECTION CD SCREEN.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE WITH PURPOSE AS *****REFINANCE*****";
                CreateFile("REFI");
                                
                Reports.TestStep = "NAVIGATE TO PAYOFF LOAN SCREEN";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Payoff Loan");

                //1st Payoff Loan Charges Entry
                string payoffAmount1st = PayoffLoanSetup();

                //2nd Payoff Loan Charges Entry
                FastDriver.BottomFrame.New();
                string payoffAmount2nd = PayoffLoanSetup();
                
                //Property Tax Check Charge Setup
                Reports.TestStep = "Creating Charges in Property Tax Check";

                Reports.TestStep = "NAVIGATE TO PROPERTY TAX CHECK SCREEN";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                
                FastDriver.PropertyTaxCheck.GABcode.FASetText("HUDFLINSR1");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                // Property Taxes Entry(Special Charge)
                Reports.TestStep = "Enter Property Taxes";
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Tax Installment: Interest Due", 3, TableAction.SetText, "12345");
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Tax Installment: Amount", 3, TableAction.SetText, "12345");
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Tax Installment: Penalty Due", 3, TableAction.SetText, "12345");
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(1, "Tax Installment: Partial Payment Amt", 3, TableAction.SetText, "12345");


                //Additional Charges(Standard and miscellaneous Charge)
                Reports.TestStep = "Enter Additional Charges";
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction(1, "City Tax", 3, TableAction.SetText, "12345");
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction(1, "County Tax", 3, TableAction.SetText, "12345");
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction(1, "State Tax", 3, TableAction.SetText, "12345");
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction(1, "Excise Tax", 3, TableAction.SetText, "12345");

                int lastRowIndex = FastDriver.PropertyTaxCheck.AdditionalChargesTable.GetRowCount();
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, "Ad Hoc Entry" + FAKeys.Tab);
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, "123" + FAKeys.Tab);

                Reports.TestStep = "Get Check Amount";
                string propertyTaxCheckAmnt = FastDriver.PropertyTaxCheck.CheckAmount.Text.Substring(14);   // 14 = len of "Check Amount :"
                FastDriver.BottomFrame.Done();

                //Adjustment Offset Charge Setup
                Reports.TestStep = "Creating Charge in Adjustment Offset";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();

                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(1, "Sale Price of Any Personal Property Included in Sale", 3, TableAction.SetText, "100.23");
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(1, "Assign Tenant Lease/Rent", 3, TableAction.SetText, "200.23");
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(1, "Assign Tenant Security Deposit", 3, TableAction.SetText, "300.23");
                
                lastRowIndex = FastDriver.AdjustmentOffset.offsetAdjustmentTable.GetRowCount();
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, "AdjustmentOffset_Adhoc_Entry_1" + FAKeys.Tab);
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, "400.23" + FAKeys.Tab);

                FastDriver.BottomFrame.Done();

                //Adjustment Miscellaneous Cherge Setup
                Reports.TestStep = "Creating Charge in Adjustment Miscellaneous";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();

                lastRowIndex = FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.GetRowCount();
                FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, "AdjustmentMisc_Adhoc_Entry_1" + FAKeys.Tab);
                FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, "100.23" + FAKeys.Tab);


                //Navigate to Payoff and Payments Tab
                Reports.TestStep = "NAVIGATE TO PAYOFF AND PAYMENT CHARGE.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "EXPAND PAYOFF AND PAYMENT SECTION";
                FastDriver.ClosingDisclosure.Section_Payoffs.FAClick();
                
                Reports.TestStep = "VERIFY PAYOFF LOAN CHARGE IN PAYOFFS AND PAYMENT SECTION";
                Reports.TestStep = "VERIFY Payoff Loan 1 Charges";
                Support.AreEqual(payoffAmount1st, FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "*   Payoff Loan 1 charges", 4, TableAction.GetText).Message.Trim());               
                Reports.TestStep = "VERIFY Payoff Loan 1 Charges";
                Support.AreEqual(payoffAmount2nd, FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "*   Payoff Loan 2 charges", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "VERIFY PROPERTY TAX CHARGE IN PAYOFFS AND PAYMENT SECTION";
                Support.AreEqual(propertyTaxCheckAmnt, FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "*   Property Taxes", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "VERIFY ADJUSTMENT LOAN CHARGE IN PAYOFFS AND PAYMENT SECTION";
                Support.AreEqual("$100.23", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "Sale Price of Any Personal Property Included in Sale", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$200.23", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "Assign Tenant Lease/Rent", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$300.23", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "Assign Tenant Security Deposit", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$400.23", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "AdjustmentOffset_Adhoc_Entry_1", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$100.23", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "AdjustmentMisc_Adhoc_Entry_1", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "VERIFY TOTAL PAYOFFS AND PAYMENT SECTION";
                Support.AreEqual("$126,108.15", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "TOTAL PAYOFFS AND PAYMENTS",3, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR45_US_401977_TC_AutoPopulate2()
        {
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN 2 AND MORTGAGE BROKER 2,NEW LOAN 1,HOA, ASSUMPTION  SECTION K CHARGES DISPLAYED IN THE PAYOFFS AND PAYMENTS SECTION CD SCREEN.";
                
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE WITH PURPOSE AS *****REFINANCE*****";
                CreateFile("REFI");

                Reports.TestStep = "NAVIGATE TO NEW LOAN SCREEN";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();             
                
                Reports.TestStep = "*****SETUP NEW LOAN1 CHARGES*****";
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();

                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(1, "Principal Reduction Payment", 3, TableAction.SetText, "700.42");
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(1, "Principal Reduction Payment", 4, TableAction.SetText, "400.12");
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(1, "Construction Holdback", 3, TableAction.SetText, "1200.25");
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(1, "Construction Holdback", 4, TableAction.SetText, "600.50");

                int lastRowIndex = FastDriver.NewLoan.LoanChargesPrincipalReductiontable.GetRowCount();
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, "New Loan Adhoc" + FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, "900.23" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();             

                FastDriver.HomeownerAssociation.FindGABCode("237");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();

                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(1, "Lien Payoff", 3, TableAction.SetText, "500.45");
                lastRowIndex = FastDriver.HomeownerAssociation.HOALienPayOffTable.GetRowCount();
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, "HOA Adhoc" + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, "600.92" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "*****SETUP ASSUMPTION CHARGES*****";
                
                Reports.TestStep = "Navigate to Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FASetText("400.23");
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", buyerCharge: 600.76);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", buyerCharge: 800.43);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Late Charge", buyerCharge: 900.23);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Balance of Impounds/Reserves Acct.", buyerCharge: 200.23);

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "EXPAND PAYOFF AND PAYMENT SECTION";
                FastDriver.ClosingDisclosure.Section_Payoffs.FAClick();

                //VERIFY NEW LOAN 1 CHARGES*****";
                Reports.TestStep = "VERIFY NEW LOAN 1 CHARGE DESCRIPTIOAN AND AMOUNT IN PAYOFFS AND PAYMENT SECTION";
                Support.AreEqual("$900.23", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "New Loan Adhoc  to Midwest Financial Group", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$1,200.25", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "Construction Holdback  to Midwest Financial Group", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.42", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "Principal Reduction Payment  to Midwest Financial Group", 4, TableAction.GetText).Message.Trim());
            
                //VERIFY HOA Lien Payoff Charges*****";
                Reports.TestStep = "VERIFY HOA Lien Payoff Charges DESCRIPTIOAN AND AMOUNT IN PAYOFFS AND PAYMENT SECTION";
                Support.AreEqual("$1,101.37", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "*   HOA Lien Payoff Charges", 4, TableAction.GetText).Message.Trim());

                //"*****VERIFY ASSUMPTION CHARGES*****";
                Reports.TestStep = "VERIFY ASSUMPTION GROUP CHARGE IN PAYOFFS AND PAYMENT SECTION";
                Support.AreEqual("$2,901.88", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "*   Assumption Loan 1 charges", 4, TableAction.GetText).Message.Trim());

                //Verify TOTAL PAYOFF AND PAYMENT
                Reports.TestStep = "VERIFY TOTAL PAYOFFS AND PAYMENT SECTION";
                Support.AreEqual("$6,804.15", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, "TOTAL PAYOFFS AND PAYMENTS", 3, TableAction.GetText).Message.Trim());
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region CD SCREEN – SECTION K: VIEW DETAILS OF THE PAYOFFS AND PAYMENT CHARGES THAT ARE PART OF THE GROUP

        [TestMethod]
        public void FTR5_ITR51_US_464040_TC_DialogDescriptionAmount()
        {
            try
            { 

                Reports.TestDescription = "VERIFY PAYOFF LOAN, HOA, ASSUMPTION  SECTION K CHARGES DISPLAYED IN THE POPUP DIALOG";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE WITH PURPOSE AS *****REFINANCE*****";
                CreateFile("REFI");
                
                Reports.TestStep = "NAVIGATE TO PAYOFF LOAN SCREEN";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Payoff Loan");

                Reports.TestStep = "***** SETUP Payoff Loan Charges*****";
                string payoffAmount1st = PayoffLoanSetup();

                Reports.TestStep = "***** SETUP HOA Lien Payoff Charges*****";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.FindGABCode("237");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();

                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(1, "Lien Payoff", 3, TableAction.SetText, "500.45");
                int lastRowIndex = FastDriver.HomeownerAssociation.HOALienPayOffTable.GetRowCount();
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, "HOA Adhoc" + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, "120.47" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                string amountHOA = "$620.92";    // 500.45 + 120.47
                                
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                
                Reports.TestStep = "*****SETUP ASSUMPTION CHARGES*****";
                FastDriver.AssumptionLoanDetails.FindGABCode("247");
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FASetText("400.23");
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", buyerCharge: 600.76);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", buyerCharge: 800.43);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Late Charge", buyerCharge: 900.23);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Balance of Impounds/Reserves Acct.", buyerCharge: 200.23);
                lastRowIndex = FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.GetRowCount();
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, "Assumption_Adhoc_Entry_1" + FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, "500.47" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                string amountAssum = "$3,402.35"; // 400.23 + 600.76 + 800.43 + 900.23 + 200.23 + 500.47

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "EXPAND PAYOFF AND PAYMENT SECTION";
                FastDriver.ClosingDisclosure.Section_Payoffs.FAClick();

                //VERIFY Payoff Loan Charges*****";
                Reports.TestStep = "VERIFY PAYOFF LOAN CHARGE DESCRIPTION AND AMOUNT IN POPUP DIALOG";
                FastDriver.ClosingDisclosure.GroupChargePlus.FAClick();

                string PayeeName = "Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2";  // HUDFLINSR1
                Support.AreEqual(payoffAmount1st, FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Payoff Loan 1 charges", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$12,345.00", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Principal Balance to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$11,119.80", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Interest on Payoff Loan to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$727.17", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Ad Hoc Entry to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$123.23", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Statement/Forwarding Fee to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$123.23", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Reconveyance Fee to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                FastDriver.ClosingDisclosure.PayoffPopupDone.FAClick();

                //VERIFY HOA Lien Payoff Charges*****";
                Reports.TestStep = "VERIFY HOA Lien Payoff Charges DESCRIPTIOAN AND AMOUNT IN POPUP DIALOG";
                FastDriver.ClosingDisclosure.GroupChargePlus2.FAClick();

                PayeeName = "Associated Great Northern Mortgage Co.";  // GABCode 237
                Support.AreEqual(amountHOA, FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "HOA Lien Payoff Charges", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$500.45", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Lien Payoff to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$120.47", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "HOA Adhoc to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                FastDriver.ClosingDisclosure.PayoffPopupDone.FAClick();

                //"*****VERIFY ASSUMPTION CHARGES*****";
                Reports.TestStep = "VERIFY ASSUMPTION GROUP CHARGE IN PAYOFFS AND PAYMENT SECTION POPUP DIALOG";
                FastDriver.ClosingDisclosure.GroupChargePlus3.FAClick();

                PayeeName = "Lenders Advantage A Division Of First American Title Ins.";  // GABCode 247
                Support.AreEqual(amountAssum, FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, " Assumption Loan 1 charges", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$600.76", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Statement/Forwarding Fee to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$800.43", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Document Fee to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$900.23", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Late Charge to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$200.23", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Balance of Impounds/Reserves Acct. to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$500.47", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Assumption_Adhoc_Entry_1 to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$400.23", FastDriver.ClosingDisclosure.PayoffPopupTable.PerformTableAction(2, "Assumption Loan Interest Proration to " + PayeeName, 5, TableAction.GetText).Message.Trim());
                FastDriver.ClosingDisclosure.PayoffPopupDone.FAClick();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }    
        }

        #endregion

        #region USERSTORY 468348 CD Screen-Section K L M N - Technical User story.

        [TestMethod]
        #region USERSTORY 468348_TESTCASE_493051_Expand and save charges in KLMN Section
        public void FTR5_ITR48_US_468348_TC_493051_SC1()
        {
            try
            {
                Reports.TestDescription = " Expand and save charges in KLMN Section";

                Random random = new Random();
                int randomNumber;
                
                for (int i = 0; i < 9; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("ACCOMODAT", gabCode: "214");
            
                //Create_L_Group_Charges();
                Reports.TestStep = "Entering Section L data";
                Desc[0] = "Tax Installment: Interest Due";
                Desc[1] = "Tax Installment: Amount";
                
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("344");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[0], buyerCredit: Charge[0]);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[1], buyerCredit: Charge[1]);
                FastDriver.BottomFrame.Done();

                //Create_M_Group_Charges();
                Reports.TestStep = "Entering Section M data";
                Desc[2] = "Statement/Forwarding Fee";
                Desc[3] = "Document Fee";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("344");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[2], sellerCredit: Charge[2]);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[3], sellerCredit: Charge[3]);
                FastDriver.BottomFrame.Done();

                //Create_N_Group_Charges();
                Reports.TestStep = "Entering Section N data";
                Desc[4] = "Appraisal Fee";
                Desc[5] = "Credit Report";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, Desc[4], sellerCharge: Charge[4]);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, Desc[5], sellerCharge: Charge[5]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                //Expand_Charges_N_Save("Expand");
                Reports.TestStep = "Expand Charges and Save";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Summaries_of_Transactions);
                FastDriver.ClosingDisclosure.ExpandChargeGroup(FastDriver.ClosingDisclosure.SectionN06_gtr_icon);
                FastDriver.ClosingDisclosure.ExpandChargeGroup(FastDriver.ClosingDisclosure.L06_Expand);
                FastDriver.ClosingDisclosure.ExpandChargeGroup(FastDriver.ClosingDisclosure.M03Expand);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Summaries_of_Transactions);

                //Verify_Expanded_M_Charges();
                Reports.TestStep = "Verifying Expanded charges of Section M";

                Tmp[2] = Desc[2] + " from Brite Mortgage";
                Tmp[3] = Desc[3] + " from Brite Mortgage";

                Reports.TestStep = "Validating individual charges of M Section ";
                Support.AreEqual(Charge[2].ToString("C2"), FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, Tmp[2], 3, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[3].ToString("C2"), FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, Tmp[3], 3, TableAction.GetText).Message.Trim());

                //Verify_Expanded_N_Charges();
                Reports.TestStep = "Verifying Expanded charges of Section N";

                Tmp[4] = Desc[4] + " to Brite Mortgage";
                Tmp[5] = Desc[5] + " to Brite Mortgage";

                Reports.TestStep = "Validating individual charges of M Section ";
                Support.AreEqual(Charge[4].ToString("C2"), FastDriver.ClosingDisclosure.SectionN_DueItemsTable.PerformTableAction(1, Tmp[4], 3, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[5].ToString("C2"), FastDriver.ClosingDisclosure.SectionN_DueItemsTable.PerformTableAction(1, Tmp[5], 3, TableAction.GetText).Message.Trim());

                //Verify_Expanded_L_Charges();
                Reports.TestStep = "Verifying Expanded charges of Section L";

                Tmp[0] = Desc[0] + " from Brite Mortgage";
                Tmp[1] = Desc[1] + " from Brite Mortgage";

                Reports.TestStep = "Validating individual charges of M Section ";
                Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.SectionL_DueItemsTable_OtherCredits.PerformTableAction(1, Tmp[0], 3, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[1].ToString("C2"), FastDriver.ClosingDisclosure.SectionL_DueItemsTable_OtherCredits.PerformTableAction(1, Tmp[1], 3, TableAction.GetText).Message.Trim());
    
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 

        }
        #endregion
        
        [TestMethod]
        #region USERSTORY 468348_TESTCASE_492948_Collapse and save charges in KLMN Section
        public void FTR5_ITR48_US_468348_TC_492948_SC2()
        {
            try
            {
                Reports.TestDescription = "Collapse and save charges in KLMN Section";

                Random random = new Random();
                int randomNumber;
                
                for (int i = 0; i < 9; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("ACCOMODAT", gabCode: "214");

                Reports.TestStep = "Entering Section L data";
                Desc[0] = "Tax Installment: Interest Due";
                Desc[1] = "Tax Installment: Amount";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("344");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[0], buyerCredit: Charge[0]);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[1], buyerCredit: Charge[1]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering Section M data";
                Desc[2] = "Statement/Forwarding Fee";
                Desc[3] = "Document Fee";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("344");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[2], sellerCredit: Charge[2]);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[3], sellerCredit: Charge[3]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering Section N data";
                Desc[4] = "Appraisal Fee";
                Desc[5] = "Credit Report";

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, Desc[4], sellerCharge: Charge[4]);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, Desc[5], sellerCharge: Charge[5]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Collapse Charges and Save";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Summaries_of_Transactions);
                FastDriver.ClosingDisclosure.CollapseChargeGroup(FastDriver.ClosingDisclosure.SectionN06_gtr_icon);
                FastDriver.ClosingDisclosure.CollapseChargeGroup(FastDriver.ClosingDisclosure.L06_Expand);
                FastDriver.ClosingDisclosure.CollapseChargeGroup(FastDriver.ClosingDisclosure.M03Expand);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Summaries_of_Transactions);

                Reports.TestStep = "Validating Collapsed charges of L Section ";
                Support.AreEqual((Charge[0] + Charge[1]).ToString("C2"), FastDriver.ClosingDisclosure.SectionL_DueItemsTable_OtherCredits.PerformTableAction(1, "* Property Taxes", 3, TableAction.GetText).Message.Trim());
             
                Reports.TestStep = "Validating Collapsed charges of M Section ";
                Support.AreEqual((Charge[2] + Charge[3]).ToString("C2"), FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, "* Assumption Loan 1 Credits", 3, TableAction.GetText).Message.Trim());
                
                Reports.TestStep = "Validating Collapsed charges of N Section ";
                Support.AreEqual((Charge[4] + Charge[5]).ToString("C2"), FastDriver.ClosingDisclosure.SectionN_DueItemsTable.PerformTableAction(1, "* New Loan 2 Charges", 3, TableAction.GetText).Message.Trim());
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion


        #endregion

        #region USERSTORY 401975 CD Screen – Section K:  Edit Payoffs and Payment Charge Description

        [TestMethod]
        #region USERSTORY 401975_TESTCASE_471174_ Edit Payoffs and Payment Charge Description for Assumption Loan
        public void FTR5_ITR48_US_401975_TC_471174_SC6()
        {
            try
            {
                Reports.TestDescription = "Edit Payoffs and Payment Charge Description of a Assumption Loan";

                Desc[0] = "Statement/Forwarding Fee";
                Desc[1] = "Document Fee";
                Desc[2] = "Late Charge";
                NewDesc = "New Description";
                Charge[0] = 1500;
                Charge[1] = 0;
                Charge[2] = 0;
                Tmp[0] = NewDesc + "  to Brite Mortgage";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //Assumption_Loan_Group();
                Reports.TestStep = "Navigate to Assumption Loan";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("344");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[0], buyerCharge: Charge[0]);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[1], buyerCharge: Charge[1]);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[2], buyerCharge: Charge[2]);
                FastDriver.BottomFrame.Done();
                        
                //Edit_K_Charges(NewDesc, "Assumption Loan");
                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Editing charges of Section K in Refinance file";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.SetText, NewDesc);

                Reports.TestStep = "Saving Edited charges of Section K in Refiance file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Verifying The Edited charges of Section K in Refinance file after saving the Description name";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                Support.AreEqual(Tmp[0], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());

                //Verify_Assumption_Loan_Desc();
                Reports.TestStep = "Navigate to Assumption Loan";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();

                Reports.TestStep = "Verifying updated Description in  Assumption Loan Source Screen";
                Support.AreEqual(NewDesc, FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction(2, 1, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 401975_TESTCASE_471168_ Edit Payoffs and Payment Charge Description for Payoff loan
        public void FTR5_ITR48_US_401975_TC_471168_SC1()
        {
            try 
            {
                Reports.TestDescription = " Edit Payoffs and Payment Charge Description of a Payoff loan";
           
                Desc[0] = "Statement/Forwarding Fee";
                Desc[1] = "Reconveyance Fee";
                Desc[2] = "Prepayment Penalty";
                NewDesc = "New Description";
                Charge[0] = 1500;
                Charge[1] = 0;
                Charge[2] = 0;
                Tmp[0] = NewDesc + "  to Brite Mortgage";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //Payoff_Loan_Group();
                Reports.TestStep = "Navigate to Assumption Loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Escrow Charge Processes>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("344");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, Desc[0], 3, TableAction.SetText, Charge[0].ToString());
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, Desc[1], 3, TableAction.SetText, Charge[1].ToString());
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, Desc[2], 3, TableAction.SetText, Charge[2].ToString());
                FastDriver.BottomFrame.Done();

                //Edit_K_Charges_Of_Payoffs(NewDesc);
                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Editing charges of Section K in Refinance file";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                FastDriver.ClosingDisclosure.ExpandChargeGroup(FastDriver.ClosingDisclosure.SectionK_Expand);
                FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.SetText, NewDesc);

                Reports.TestStep = "Saving Edited charges of Section K in Refiance file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Verifying The Edited charges of Section K in Refinance file after saving the Description name";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                Support.AreEqual(Tmp[0], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());

                //Verify_Payoff_Loan_Desc();
                Reports.TestStep = "Navigate to Assumption Loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Escrow Charge Processes>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();

                Reports.TestStep = "Verifying updated Description in Assumption Loan Source Screen";
                Support.AreEqual(NewDesc, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 1, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 

        }
        #endregion

        [TestMethod]
        #region USERSTORY 401975_TESTCASE_471169_ Edit Payoffs and Payment Charge Description for property Tax
        public void FTR5_ITR48_US_401975_TC_471169_SC2()
        {
            try
            {
                Reports.TestDescription = " Edit Payoffs and Payment Charge Description of a property Tax";

                Desc[0] = "Tax Installment: Interest Due";
                Desc[1] = "Tax Installment: Amount";
                Desc[2] = "Tax Installment: Penalty Due";
                NewDesc = "New Description";
                Charge[0] = 1500;
                Charge[1] = 0;
                Charge[2] = 0;
                Tmp[0] = NewDesc + "  to Brite Mortgage";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //PropertyTax_Group();
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("344");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[0], buyerCharge: Charge[0]);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[1], buyerCharge: Charge[1]);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[2], buyerCharge: Charge[1]);
                FastDriver.BottomFrame.Done();

                //Edit_K_Charges(NewDesc, "prop Tax");
                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Editing charges of Section K in Refinance file";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.SetText, NewDesc);

                Reports.TestStep = "Saving Edited charges of Section K in Refiance file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Verifying The Edited charges of Section K in Refinance file after saving the Description name";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                Support.AreEqual(Tmp[0], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());

                //Verify_PropertyTax_Desc();
                Reports.TestStep = "Navigate to Property Tax";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                
                Reports.TestStep = "Verifying updated Description in Assumption Loan Source Screen";
                Support.AreEqual(NewDesc, FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction(3, 1, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 401975_TESTCASE_471170_ Edit Payoffs and Payment Charge Description for Adjustment
        public void FTR5_ITR48_US_401975_TC_471170_SC3()
        {
            try
            {
                Reports.TestDescription = " Edit Payoffs and Payment Charge Description of a Adjustment";

                NewDesc = "New Description";
                Charge[0] = 1500;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //Adjustments();
                Reports.TestStep = "Creating Charge in Adjustment Offset";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();

                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 3, TableAction.SetText, Charge[0].ToString());
                
                FastDriver.BottomFrame.Done();

                //Edit_K_Charges(NewDesc, "Adjustment");
                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Editing charges of Section K in Refinance file";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.SetText, NewDesc);

                Reports.TestStep = "Saving Edited charges of Section K in Refiance file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Verifying The Edited charges of Section K in Refinance file after saving the Description name";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                Support.AreEqual(NewDesc, FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());

                //Verify_Adjustments_Desc();
                Reports.TestStep = "Creating Charge in Adjustment Offset";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();

                Reports.TestStep = "Verifying updated Description in Adjustment Offset";
                Support.AreEqual(NewDesc, FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 1, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 401975_TESTCASE_511542_ Edit Payoffs and Payment Charge Description for Homeowner Association
        public void FTR5_ITR48_US_401975_TC_511542_SC6()
        {
            try
            {
                Reports.TestDescription = " Edit Payoffs and Payment Charge Description of a Homeowner Association";

                Desc[0] = "Lien Payoff";
                Desc[1] = "Description1";
                Desc[2] = "Description2";
                NewDesc = "New Description";
                Charge[0] = 1500;
                Charge[1] = 0;
                Charge[2] = 0;
                Tmp[0] = NewDesc + "  to Brite Mortgage";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //HomeOwner_Association_Group();;
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.FindGABCode("344");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();

                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(1, Desc[0], 3, TableAction.SetText, Charge[0] + FAKeys.Tab);
                int lastRowIndex = FastDriver.HomeownerAssociation.HOALienPayOffTable.GetRowCount();
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, Desc[1] + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, Charge[1] + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 4, TableAction.SetText, FAKeys.Tab);  // to create a new row
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(++lastRowIndex, 1, TableAction.SetText, Desc[2] + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, Charge[2] + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                //Edit_K_Charges(NewDesc, "homeowner");
                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Editing charges of Section K in Refinance file";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.SetText, NewDesc);

                Reports.TestStep = "Saving Edited charges of Section K in Refinance file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Verifying The Edited charges of Section K in Refinance file after saving the Description name";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                Support.AreEqual(Tmp[0], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());

                //Verify_HomeOwner_Association_Desc();
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                Reports.TestStep = "Verifying updated Description in Homeowner Association Screen";
                Support.AreEqual(NewDesc, FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(2, 1, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 401975_TESTCASE_512410_ Edit Payoffs and Payment Charge Description for FEES
        public void FTR5_ITR48_US_401975_TC_512410_SC7()
        {
            try
            {
                Reports.TestDescription = " Edit Payoffs and Payment Charge Description of a FEES";

                Desc[0] = "s1";
                Desc[1] = "s2";
                Desc[2] = "s3";
                NewDesc = "New Description";
                Charge[0] = 1500;
                Charge[1] = 0;
                Charge[2] = 0;
                Tmp[0] = NewDesc + "  to First American Title, Insurance Co.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                Fee_Group();
                
                //Edit_K_Charges(NewDesc, "Fee");
                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Editing charges of Section K in Refinance file";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.SetText, NewDesc);

                Reports.TestStep = "Saving Edited charges of Section K in Refinance file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Verifying The Edited charges of Section K in Refinance file after saving the Description name";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                Support.AreEqual(Tmp[0], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());

                //Verify_Fee_Desc();
                Reports.TestStep = "Navigate to File Fee screen";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                Reports.TestStep = "Verifying updated Description in File Fees Screen";
                Support.AreEqual(NewDesc, FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, NewDesc, 2, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 401975_TESTCASE_471171_ Edit Payoffs and Payment Charge Description for New Loan
        public void FTR5_ITR48_US_401975_TC_471171_SC4()
        {
            try
            {
                Reports.TestDescription = " Edit Payoffs and Payment Charge Description of a Adjustment";

                NewDesc = "New Description";
                Charge[0] = 1500;
                Tmp[0] = NewDesc + "  to Brite Mortgage";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //NewLoan_Individual();
                Reports.TestStep = "Entering New Loan data";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ExpandChargeSection(FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand);

                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(1, "Principal Reduction Payment", 3, TableAction.SetText, Charge[0].ToString());
                FastDriver.BottomFrame.Done();

                //Edit_K_Charges(NewDesc, "NewLoan");
                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Editing charges of Section K in Refinance file";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.SetText, NewDesc);

                Reports.TestStep = "Saving Edited charges of Section K in Refiance file";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                Reports.TestStep = "Verifying The Edited charges of Section K in Refinance file after saving the Description name";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                Support.AreEqual(Tmp[0], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());

                //Verify_NewLoan_Desc();
                Reports.TestStep = "Navigate to New Loan screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ExpandChargeSection(FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand);

                Reports.TestStep = "Verifying updated Description in  NEWLOAN  Source Screen";
                // temporary solution 
                string value = FastDriver.NewLoan.Description1.GetAttribute("value");
                string description = value.Split(',')[0].Split(':')[1].Replace("\"","");
                Support.AreEqual(NewDesc, description);
                // ideal solution, but PerformTableAction does not work with this type off table/cell at the moment
                //Support.AreEqual(NewDesc, FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(2, 1, TableAction.GetText).Message.Trim());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion


        #endregion
        
        #region USERSTORY 464247 CD Screen – Section K: Ability to display Payoffs and Payment Charges that are part of a Group as Individual charge

        [TestMethod]
        #region USERSTORY 464247_TESTCASE_493345_ Display Payoffs and Payment Charges that are part of a Assumption Group as Individual charge
        public void FTR5_ITR48_US_464247_TC_493345_SC4()
        {
            try
            {
                Reports.TestDescription = " Display Payoffs and Payment Charges  of a Assumption Loan Group as Individual charge";

                Desc[0] = "Statement/Forwarding Fee";
                Desc[1] = "Document Fee";
                Desc[2] = "Late Charge";
                Tmp[0] = Desc[0] + "  to Brite Mortgage";   // from CodedUI, it says " from Brite Mortgage"
                Tmp[1] = Desc[1] + "  to Brite Mortgage";
                Tmp[2] = Desc[2] + "  to Brite Mortgage";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 3; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //Assumption_Loan_Group();
                Reports.TestStep = "Navigate to Assumption Loan";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("344");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[0], buyerCharge: Charge[0]);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[1], buyerCharge: Charge[1]);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[2], buyerCharge: Charge[2]);
                FastDriver.BottomFrame.Done();

                Verify_Expanded_K_Charges();
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464247_TESTCASE_493348_ Display Payoffs and Payment Charges that are part of a NewLoan Group as Individual charge
        public void FTR5_ITR48_US_464247_TC_493348_SC5()
        {
            try
            { 
                Reports.TestDescription = "Display Payoffs and Payment Charges  of a New Loan Group as Individual charge";

                Desc[0] = "test N 2 plus";
                Desc[1] = "test new 2 b";
                Desc[2] = "Interest on Loan";

                Tmp[0] = Desc[0] + "  from Brite Mortgage";
                Tmp[1] = Desc[1] + "  from Brite Mortgage";
                Tmp[2] = Desc[2] + "  from Brite Mortgage";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 3; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //New_Loan_Group();
                Reports.TestStep = "Entering New  Loan data";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(2, 3, TableAction.SetText, Charge[0].ToString());
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(3, 3, TableAction.SetText, Charge[1].ToString());
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText(Charge[2].ToString());
                FastDriver.BottomFrame.Done();
            
                Verify_Expanded_K_Charges();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464247_TESTCASE_512424_ Display Payoffs and Payment Charges that are part of a Fee Group as Individual charge
        public void FTR5_ITR48_US_464247_TC_512424_SC6()
        {
            try
            { 

                Reports.TestDescription = " Display Payoffs and Payment Charges  of a Fee Group as Individual charge";

                Desc[0] = "s1";
                Desc[1] = "s2";
                Desc[2] = "s3";

                Tmp[0] = Desc[0] + "  to First American Title, Insurance Co.";
                Tmp[1] = Desc[1] + "  to First American Title, Insurance Co.";
                Tmp[2] = Desc[2] + "  to First American Title, Insurance Co.";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 3; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                Fee_Group();

                Reports.TestStep = "NAVIGATE TO CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

                //Verify_Expanded_K_Charges();  // Can't find another charge (total of 3) to use this method
                Reports.TestStep = "Verifying Expanded charges of Section K in Refiance file";
                FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
                FastDriver.ClosingDisclosure.ExpandChargeGroup(FastDriver.ClosingDisclosure.SectionK_Expand);

                Reports.TestStep = "Validating individual charges of K Section ";

                Support.AreEqual(Tmp[0], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());

                Support.AreEqual(Tmp[1], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(3, 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(Charge[1].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(3, 4, TableAction.GetText).Message.Trim());

                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464247_TESTCASE_493332_ Display Payoffs and Payment Charges that are part of a HomeOwnerAssociation  Group as Individual charge
        public void FTR5_ITR48_US_464247_TC_493332_SC2()
        {
            try
            { 
                Reports.TestDescription = " Display Payoffs and Payment Charges  of a  HomeOwnerAssociation Group as Individual charge";

                Desc[0] = "Lien Payoff";
                Desc[1] = "Description1";
                Desc[2] = "Description2";

                Tmp[0] = Desc[0] + "  to Brite Mortgage";
                Tmp[1] = Desc[1] + "  to Brite Mortgage";
                Tmp[2] = Desc[2] + "  to Brite Mortgage";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 9; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //HomeOwner_Association_Group();;
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.FindGABCode("344");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();

                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(1, Desc[0], 3, TableAction.SetText, Charge[0] + FAKeys.Tab);
                int lastRowIndex = FastDriver.HomeownerAssociation.HOALienPayOffTable.GetRowCount();
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, Desc[1] + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, Charge[1] + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 4, TableAction.SetText, FAKeys.Tab);  // to create a new row
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(++lastRowIndex, 1, TableAction.SetText, Desc[2] + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, Charge[2] + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
            
                Verify_Expanded_K_Charges();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464247_TESTCASE_493325_ Display Payoffs and Payment Charges that are part of a PropertyTax  Group as Individual charge
        public void FTR5_ITR48_US_464247_TC_493325_SC1()
        {
            try
            { 

                Reports.TestDescription = " Display Payoffs and Payment Charges  of a  PropertyTax  Group as Individual charge";

                Desc[0] = "Tax Installment: Interest Due";
                Desc[1] = "Tax Installment: Amount";
                Desc[2] = "Tax Installment: Penalty Due";

                Tmp[0] = Desc[0] + "  to Brite Mortgage";
                Tmp[1] = Desc[1] + "  to Brite Mortgage";
                Tmp[2] = Desc[2] + "  to Brite Mortgage";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 9; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //PropertyTax_Group();
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("344");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[0], buyerCharge: Charge[0]);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[1], buyerCharge: Charge[1]);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[2], buyerCharge: Charge[2]);
                FastDriver.BottomFrame.Done();

                Verify_Expanded_K_Charges();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464247_TESTCASE_493334_ Display Payoffs and Payment Charges that are part of a Payoff Loan  Group as Individual charge
        public void FTR5_ITR48_US_464247_TC_493334_SC3()
        {
            try
            { 
                Reports.TestDescription = " Display Payoffs and Payment Charges  of a  Payoff Loan Group as Individual charge";

                Desc[0] = "Statement/Forwarding Fee";
                Desc[1] = "Reconveyance Fee";
                Desc[2] = "Prepayment Penalty";

                Tmp[0] = Desc[0] + "  to Brite Mortgage";
                Tmp[1] = Desc[1] + "  to Brite Mortgage";
                Tmp[2] = Desc[2] + "  to Brite Mortgage";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 3; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //Payoff_Loan_Group();
                Reports.TestStep = "Navigate to Assumption Loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Escrow Charge Processes>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("344");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, Desc[0], 3, TableAction.SetText, Charge[0].ToString());
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, Desc[1], 3, TableAction.SetText, Charge[1].ToString());
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, Desc[2], 3, TableAction.SetText, Charge[2].ToString());
                FastDriver.BottomFrame.Done();

                Verify_Expanded_K_Charges();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        #endregion
        
        #region USERSTORY 464069 CD Screen – Section K: Ability to display Payoffs and Payment charges as a Group

        [TestMethod]
        #region USERSTORY 464069_TESTCASE_493138_ Display Payoffs and Payment charges of Assumption Loan as a Group
        public void FTR5_ITR48_US_464069_TC_493138_SC2()
        {
            try
            { 
                Reports.TestDescription = " Display Payoffs and Payment charges of Assumption Loan as a Group";

                Desc[0] = "Statement/Forwarding Fee";
                Desc[1] = "Document Fee";
                Desc[2] = "Late Charge";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 3; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }
                
                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //Assumption_Loan_Group();
                Reports.TestStep = "Navigate to Assumption Loan";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.FindGABCode("344");
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[0], buyerCharge: Charge[0]);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[1], buyerCharge: Charge[1]);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(Desc[2], buyerCharge: Charge[2]);
                FastDriver.BottomFrame.Done();

                Verify_Collapsed_K_Charges("*   Assumption Loan 1 charges");
           

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464069_TESTCASE_493131_ Display Payoffs and Payment charges of NewLoan as a Group
        public void FTR5_ITR48_US_464069_TC_493131_SC1()
        {
            try
            { 
                Reports.TestDescription = "Display Payoffs and Payment charges of NewLoan as a Group";

                Desc[0] = "test N 2 plus";
                Desc[1] = "test new 2 b";
                Desc[2] = "Interest on Loan";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 3; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //New_Loan_Group();
                Reports.TestStep = "Entering New  Loan data";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("344");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(2, 3, TableAction.SetText, Charge[0].ToString());
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(3, 3, TableAction.SetText, Charge[1].ToString());
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText(Charge[2].ToString());
                FastDriver.BottomFrame.Done();

                Verify_Collapsed_K_Charges("*   New Loan 2 charges");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464069_TESTCASE_512421_ Display Payoffs and Payment charges of FEE ENTRY as a Group
        public void FTR5_ITR48_US_464069_TC_512421_SC6()
        {
            try
            { 
                Reports.TestDescription = "Display Payoffs and Payment charges of FEE ENTRY  as a Group";

                Desc[0] = "s1";
                Desc[1] = "s2";
                Desc[2] = "s3";

                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 3; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //Fee_Group();
                Charge[2] = 0;  // b/c we use only the first 2 charges - Charge[0] and Charge[1]

                Verify_Collapsed_K_Charges("*   Property Taxes");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464069_TESTCASE_493159_ Display Payoffs and Payment charges of HomeownerAssociation as a Group
        public void FTR5_ITR48_US_464069_TC_493159_SC5()
        {
            try
            { 
                Reports.TestDescription = "Display Payoffs and Payment charges of HomeownerAssociation  as a Group";

                Desc[0] = "Lien Payoff";
                Desc[1] = "Description1";
                Desc[2] = "Description2";

                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 9; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //HomeOwner_Association_Group();
                Reports.TestStep = "Navigate to Homeowner Association Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.FindGABCode("344");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();

                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(1, Desc[0], 3, TableAction.SetText, Charge[0] + FAKeys.Tab);
                int lastRowIndex = FastDriver.HomeownerAssociation.HOALienPayOffTable.GetRowCount();
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, Desc[1] + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, Charge[1] + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 4, TableAction.SetText, FAKeys.Tab);  // to create a new row
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(++lastRowIndex, 1, TableAction.SetText, Desc[2] + FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, FAKeys.Tab);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, Charge[2] + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Verify_Collapsed_K_Charges("*   HOA Lien Payoff Charges");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464069_TESTCASE_493151_ Display Payoffs and Payment charges of PropertyTax as a Group
        public void FTR5_ITR48_US_464069_TC_493151_SC4()
        {
            try
            { 
                Reports.TestDescription = "Display Payoffs and Payment charges of PropertyTax  as a Group";

                Desc[0] = "Tax Installment: Interest Due";
                Desc[1] = "Tax Installment: Amount";
                Desc[2] = "Tax Installment: Penalty Due";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 3; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //PropertyTax_Group();
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("344");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[0], buyerCharge: Charge[0]);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[1], buyerCharge: Charge[1]);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc[2], buyerCharge: Charge[2]);
                FastDriver.BottomFrame.Done();

                Verify_Collapsed_K_Charges("*   Property Taxes");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion

        [TestMethod]
        #region USERSTORY 464069_TESTCASE_493145_ Display Payoffs and Payment charges of Payoff Loan as a Group
        public void FTR5_ITR48_US_464069_TC_493145_SC3()
        {
            try
            { 
                Reports.TestDescription = "Display Payoffs and Payment charges of Payoff Loan  as a Group";

                Desc[0] = "Statement/Forwarding Fee";
                Desc[1] = "Reconveyance Fee";
                Desc[2] = "Prepayment Penalty";
                Random random = new Random();
                int randomNumber;

                for (int i = 0; i < 3; i++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[i] = i + randomNumber;
                }

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                CreateFile("REFI", gabCode: "214");

                //Payoff_Loan_Group();
                Reports.TestStep = "Navigate to Assumption Loan";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Escrow Charge Processes>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("344");
                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, Desc[0], 3, TableAction.SetText, Charge[0].ToString());
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, Desc[1], 3, TableAction.SetText, Charge[1].ToString());
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, Desc[2], 3, TableAction.SetText, Charge[2].ToString());
                FastDriver.BottomFrame.Done();

                Verify_Collapsed_K_Charges("*   Payoff Loan 1 charges");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }
        #endregion


        #endregion


        #region USER STORY 773954 : VERIFY  PAYOFFS AND PAYMENTS TABLE ON THE CD SCREEN WHEN WE DO COLLAPSE THE SECTION ON THE CD FORM, THE SYSTEM SHOULD ONLY SHOW PAYEE
        [TestMethod]
        #region USER STORY 773954_TESTCASE_798355_ Display Payoffs and Payment charges of Assumption Loan as a Group
        public void ITR07_US_773954_TC_798355()
        {
            try
            {
                Reports.TestDescription = " Display Payee name of Payoff Loan as a Group";


                Reports.TestStep = "Log into FAST application.";               

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);


                Reports.TestStep = "CREATE BASIC FILE";
                var req = RequestFactory.GetDetailedCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                req.File.BusinessSegmentObjectCD = "RESIDENTAL";
                req.File.TransactionTypeObjectCD = "REFI";
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //Payoff_Loan_Group();
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200").ClickChargesTab();
                string lendername = FastDriver.PayoffLoanDetails.GabLabelPayee.FAGetValue();
                //.FAGetText();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                #region Enter Loan Charges Buyer charge
                Reports.TestStep = "Enter Loan Charges Buyer charge.";
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"10.11");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText(@"20.11");
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD screen";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.CD.PayoffsAndPaymentsExpnd.IsVisible();
                Playback.Wait(2000);
                FastDriver.CD.PayoffsAndPaymentsExpnd.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                string c1 = FastDriver.ClosingDisclosure.PayoffTable.FAGetText();
                Support.AreEqual(lendername, c1, "Verifies the Payee Name", true);
                Support.AreEqual("True", c1.Contains(lendername).ToString());
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.SectionK_Expand.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                c1 = FastDriver.ClosingDisclosure.PayoffTable.FAGetText();
                Support.AreEqual("True", c1.Contains(lendername).ToString());
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.GroupChargePlus.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                c1 = FastDriver.ClosingDisclosure.PayoffSubChargePopUpTable.FAGetText();
                Support.AreEqual("True", c1.Contains(lendername).ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion




        #endregion

        #region USER STORY 773954 : VERIFY  PAYOFFS AND PAYMENTS TABLE ON THE CD SCREEN WHEN WE DO COLLAPSE THE SECTION ON THE CD FORM, THE SYSTEM SHOULD ONLY SHOW PAYEE
        [TestMethod]
        #region USER STORY 773954_TESTCASE_798358_ Display Payoffs and Payment charges of Assumption Loan as a Groups for mulitple instances
        public void ITR07_US_773954_TC_798358()
        {
            try
            {
                Reports.TestDescription = " Display Payee name of Payoff Loan as a Group";


                Reports.TestStep = "Log into FAST application.";               

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "CREATE BASIC FILE";
                var req = RequestFactory.GetDetailedCreateFileDefaultRequest();
                req.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248");
                req.File.BusinessSegmentObjectCD = "RESIDENTAL";
                req.File.TransactionTypeObjectCD = "REFI";
                var fileNumber = FastDriver.FACreateFileFromWCF(req);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //Payoff_Loan_Group();
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "HUDASLNDR1", principalBalance: "200");
                string lendername = FastDriver.PayoffLoanDetails.GabLabelPayee.FAGetValue();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                //.FAGetText();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                #region Enter Loan Charges Buyer charge
                Reports.TestStep = "Enter Loan Charges Buyer charge.";
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"10.11");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText(@"20.11");
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                #region Clicking on New button in payoffloan screen
                Reports.TestStep = "Clicking on New button in payoffloan screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                #endregion
                //Payoff_Loan_Group() for mulitple instances;
                #region Create second instance of payoffloan
                FastDriver.PayoffLoanDetails.FillDetailsForm(lenderGABCode: "218", principalBalance: "100").ClickChargesTab();
                string lendername1 = FastDriver.PayoffLoanDetails.GabLabelPayee.FAGetValue();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText(@"10.11");
                FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.SendKeys(FAKeys.Tab);
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText(@"20.11");
                FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.SendKeys(FAKeys.Tab);
                #endregion

                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true, switchBackToFastWindow: true, timeout: 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                // Naivate to CD screen
                Reports.TestStep = "Navigate to CD screen";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.CD.PayoffsAndPaymentsExpnd.IsVisible();
                Playback.Wait(2000);
                FastDriver.CD.PayoffsAndPaymentsExpnd.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                string c1 = FastDriver.ClosingDisclosure.PayoffTable.FAGetText();
                Support.AreEqual(lendername, c1, "Verifies the Payee Name", true);
                //To verified the payee name on K Section
                Support.AreEqual("True", c1.Contains(lendername).ToString());
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.SectionK_Expand.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                c1 = FastDriver.ClosingDisclosure.PayoffTable.FAGetText();
                //To verified the payee name on '+'
                Support.AreEqual("True", c1.Contains(lendername).ToString());
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.GroupChargePlus.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                c1 = FastDriver.ClosingDisclosure.PayoffSubChargePopUpTable.FAGetText();
                Support.AreEqual("True", c1.Contains(lendername).ToString());

                // To verify second payee on K section

                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                string c2 = FastDriver.ClosingDisclosure.PayoffTable.FAGetText();
                Support.AreEqual(lendername1, c2, "Verifies the Payee Name", true);
                //To verified the payee name on K Section
                Support.AreEqual("True", c2.Contains(lendername1).ToString());
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.SectionK_Expand_2.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                c2 = FastDriver.ClosingDisclosure.PayoffTable.FAGetText();
                //To verified the payee name on '+'
                Support.AreEqual("True", c2.Contains(lendername1).ToString());
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.GroupChargePlus4.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                c2 = FastDriver.ClosingDisclosure.PayoffSubChargePopUpTable.FAGetText();
                Support.AreEqual("True", c2.Contains(lendername1).ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion
             
        #endregion

        #region private methods

        private static void CreateFile(string TransactionType = "REFI", string BusinessSegment = "RESIDENTAL", string gabCode = "HUDFLINSR1")
        {
            FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
            fileRequest = RequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode);   // HUDFLINSR1
            fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
            fileRequest.File.BusinessSegmentObjectCD = BusinessSegment; // RESIDENTIAL
            fileRequest.File.TransactionTypeObjectCD = TransactionType; // REFI
            fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
            fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
            fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
            fileRequest.File.FirstNewLoanAmount = (decimal)998764334.45; //TermsDatesNewLoanAmnt
            fileRequest.File.NewLoan = null;
            fileRequest.File.Buyers = null;
            fileRequest.File.Sellers = null;
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        private void VerifyPayoffPaymentSection()
        {

            Reports.TestStep = "EXPAND PAYOFF AND PAYMENT SECTION";
            FastDriver.ClosingDisclosure.Section_Payoffs.FAClick();
                        
            
            //Verify Payoffs and Payments table Column heading
            Reports.TestStep = "VERIFY DESCRIPTION HEADING LABEL";
            Support.AreEqual("TO", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(1, 1, TableAction.GetText).Message.Trim());

            Reports.TestStep = "VERIFY AMOUNT HEADING LABEL";
            Support.AreEqual("AMOUNT", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(1, 3, TableAction.GetText).Message.Trim());

            //Verify total sum section "K. TOTAL PAYOFFS AND PAYMENTS " Heading at the last line of the table
            Reports.TestStep = "VERIFY TOTAL PAYOFFS AND PAYMENTS HEADING AT THE LAST LINE OF THE TABLE";
            Support.AreEqual("K.", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 1, TableAction.GetText).Message.Trim());
            Support.AreEqual("TOTAL PAYOFFS AND PAYMENTS", FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());

        }

        private string PayoffLoanSetup()
        {
            FastDriver.PayoffLoanDetails.SearchGAB("HUDFLINSR1").WaitForGABCode("HUDFLINSR1");
            FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
            FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
            FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FASetText("12345");

            FastDriver.PayoffLoanCharges.InterestCalculationChargeDesc.FASetText("Interest on Payoff Loan");
            FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText("1235");
            FastDriver.PayoffLoanCharges.InterestCalculationBuyerCredit.FASetText("500");
            //FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText("1235");

            FastDriver.PayoffLoanCharges.InterestCalculationSummaryTable.PerformTableAction(3, 2, TableAction.Click); 
            FastDriver.PayoffLoanCharges.InterestCalculationChargeDesc.FASetText("Ad Hoc Entry" + FAKeys.Tab);
            FastDriver.PayoffLoanCharges.InterestCalculationBuyerCredit.FASetText("130");
            FastDriver.PayoffLoanCharges.InterestCalculationBuyerCharge.FASetText("123");

            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Statement/Forwarding Fee", 3, TableAction.SetText, "123.23");
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Statement/Forwarding Fee", 4, TableAction.SetText, "124.23");
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Reconveyance Fee", 3, TableAction.SetText, "123.23");
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Reconveyance Fee", 4, TableAction.SetText, "124.23");
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Prepayment Penalty", 3, TableAction.SetText, "123.23");
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Prepayment Penalty", 4, TableAction.SetText, "124.23");
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Late Charge", 3, TableAction.SetText, "123.23");
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(1, "Late Charge", 4, TableAction.SetText, "124.23");

            int lastRowIndex = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.GetRowCount();
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(lastRowIndex, 1, TableAction.SetText, "Payoff Loan Ad Hoc Entry" + FAKeys.Tab);
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(lastRowIndex, 4, TableAction.SetText, "130");
            FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(lastRowIndex, 3, TableAction.SetText, "123" + FAKeys.Tab);

            string payOffAmt = FastDriver.PayoffLoanCharges.PayoffAmount.Text;
            FastDriver.BottomFrame.Done();

            return payOffAmt;

        }

        private void Fee_Group()
        {
            Reports.TestStep = "Navigate to File Fee screen";
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

            Reports.TestStep = "Entering FEE  data";
            //FastDriver.FileFees.SelectCheckbox1.FASetCheckbox(true);
            FastDriver.FileFees.SelectCheckbox2.FASetCheckbox(true);
            FastDriver.FileFees.SelectCheckbox3.FASetCheckbox(true);

            //FastDriver.FileFees.FeeDescription1.FASetText(Desc[0]);   //field is disabled
            FastDriver.FileFees.FeeDescription2.FASetText(Desc[0]);
            FastDriver.FileFees.FeeDescription3.FASetText(Desc[1]);

            //FastDriver.FileFees.buyercharge1.FASetText(Charge[0].ToString());
            FastDriver.FileFees.buyercharge2.FASetText(Charge[0].ToString());
            FastDriver.FileFees.buyercharge3.FASetText(Charge[1].ToString());

            FastDriver.FileFees.buyercharge1.FAClick();
            //FastDriver.FileFees.OwnerAdjAmnt.FASetText("50"); //field is disabled

            FastDriver.BottomFrame.Done();

        }

        private void Verify_Expanded_K_Charges()
        {
            Reports.TestStep = "NAVIGATE TO CD screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

            Reports.TestStep = "Verifying Expanded charges of Section K in Refinance file";
            FastDriver.ClosingDisclosure.ExpandSection(FastDriver.ClosingDisclosure.Payoffs_and_Payments);
            FastDriver.ClosingDisclosure.ExpandChargeGroup(FastDriver.ClosingDisclosure.SectionK_Expand);

            Reports.TestStep = "Validating individual charges of K Section ";

            Support.AreEqual(Tmp[0], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
            Support.AreEqual(Charge[0].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());

            Support.AreEqual(Tmp[1], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(3, 2, TableAction.GetText).Message.Trim());
            Support.AreEqual(Charge[1].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(3, 4, TableAction.GetText).Message.Trim());

            Support.AreEqual(Tmp[2], FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(4, 2, TableAction.GetText).Message.Trim());
            Support.AreEqual(Charge[2].ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(4, 4, TableAction.GetText).Message.Trim());

        }

        private void Verify_Collapsed_K_Charges(string desc)
        {
            Reports.TestStep = "NAVIGATE TO Closing Disclosure screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();

            Reports.TestStep = "EXPAND PAYOFF AND PAYMENT SECTION";
            FastDriver.ClosingDisclosure.Section_Payoffs.FAClick();

            Reports.TestStep = "Collapse Charge Group";
            FastDriver.ClosingDisclosure.CollapseChargeGroup(FastDriver.ClosingDisclosure.SectionK_Expand);

            Reports.TestStep = "Validating Collapsed charges of K Section";
            Support.AreEqual(desc, FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 2, TableAction.GetText).Message.Trim());
            Support.AreEqual((Charge[0] + Charge[1] + Charge[2]).ToString("C2"), FastDriver.ClosingDisclosure.PayoffTable.PerformTableAction(2, 4, TableAction.GetText).Message.Trim());
                               
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}


   