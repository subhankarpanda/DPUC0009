﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using OpenQA.Selenium;
using AutoIt;
using System.Linq;
using SeleniumInternalHelpers;

namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class SOT_Section_N : MasterTestClass
    {
        #region variables

        double[] SellerCharge = new double[20];
        double[] Charge = new double[20];
        string[] Desc = new String[20];
        String[] GetCharge = new String[30];
        string ret_Amt;
        String[] MAmt = new String[50];
        string MAmtTab2SupTotal;
        string Descr;
        string EditDescinCD = string.Empty;
        String[] DescEditinCDTab1 = new String[25];
        //String[] GetCharge = new String[30]; 

        string Get_BuyerCharge, Get_BuyerCredit;
        string Get_SellerCredit, Get_SellerCharge;
        String[] Seller_Credit = new String[20];
        String[] Seller_Charge = new String[20];
        String[] Buyer_Credit = new String[20];

        String[] Fdate = new String[20];
        String[] Tdate = new String[20];
        String[] FinalAmt = new String[20];
        String[] Amt = new String[20];
        String[] GetAmt = new String[20];
        double sum = 0.0;
        int asc = 96;
        string sct1;

        #endregion

        #region 362693- CD Screen – Section N: Display Excess Deposit on line N01


        [TestMethod]
        public void US_362693_TC_367059_NO_01()
        {//Green
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            try
            {
                Reports.TestDescription = "VERIFY  THE EXCESS DEPOSIT LEVEL AND AMOUNT IS CD SCREEN";
                //
                //
                Reports.TestStep = "Login to FAST";

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Provide Excess Deposit amount";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("9000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("9000");
                //FastDriver.BottomFrame.btnSave.FAClick();
                //Keyboard.SendKeys("^S");
                FastDriver.BottomFrame.Save();
                //
                //
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                //
                //
                Reports.TestStep = "Validating Section N Line 01";
                FastDriver.ClosingDisclosure.SectionN01_Seqno.FAClick();
                //Playback.Wait(100000000);
                string secN = FastDriver.ClosingDisclosure.SectionN_Label.Text;
                // FastDriver.ClosingDisclosure.SectionN_Label.Click();

                secN = secN.Trim();
                Support.AreEqual("True", secN.Equals("N. Due from Seller at Closing", StringComparison.OrdinalIgnoreCase).ToString());

                string secN01 = FastDriver.ClosingDisclosure.SectionN01_Seqno.Text;
                secN01 = secN01.Trim();
                Support.AreEqual("True", secN01.Equals("01", StringComparison.OrdinalIgnoreCase).ToString());
                //Debug.Print("El valor de secN01 es: " + secN01);
                string secN01desc = FastDriver.ClosingDisclosure.SectionN01_Label.Text.Trim();
                Support.AreEqual("True", secN01desc.Equals("Excess Deposit".Trim(), StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("$9,000.00", FastDriver.ClosingDisclosure.SectionN01_Amt.Text.Trim());

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Edit Excess Deposit amount";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                //Playback.Wait(100000000);
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("10000.99");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("10000.99");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();

                //
                //
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                //
                //
                Reports.TestStep = "Validating the edited value of Section N Line 01";
                FastDriver.ClosingDisclosure.SectionN01_Seqno.FAClick();
                string secN1 = FastDriver.ClosingDisclosure.SectionN_Label.Text;
                secN1 = secN1.Trim();
                Support.AreEqual("True", secN1.Equals("N. Due from Seller at Closing", StringComparison.OrdinalIgnoreCase).ToString());

                string secN011 = FastDriver.ClosingDisclosure.SectionN01_Seqno.Text;
                secN011 = secN011.Trim();
                Support.AreEqual("True", secN011.Equals("01", StringComparison.OrdinalIgnoreCase).ToString());

                string secN011desc = FastDriver.ClosingDisclosure.SectionN01_Label.Text;
                secN011desc = secN011desc.Trim();
                Debug.Print("El valor de secN011 es: " + secN011);
                Support.AreEqual("True", secN011desc.Equals("Excess Deposit", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("$10,000.99", FastDriver.ClosingDisclosure.SectionN01_Amt.Text.Trim());

            }
            catch (Exception e)
            {
                FailTest(e.Message);

            }


        }
        [TestMethod]
        public void US_362693_TC_367061_NO_03()
        {//Green
            Reports.TestDescription = "VERIFY  THE MAXIMUM EXCESS DEPOSIT AMOUNT IS CD SCREEN";
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            try
            {
                Reports.TestDescription = "VERIFY  THE EXCESS DEPOSIT LEVEL AND AMOUNT IS CD SCREEN";
                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Provide Excess Deposit amount";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("12345678901.23");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("12345678901.23");
                FastDriver.BottomFrame.Save();
                //
                //
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                //
                //
                Reports.TestStep = "Validating Section N Line 01";
                FastDriver.ClosingDisclosure.SectionN01_Seqno.FAClick();
                string secN01 = FastDriver.ClosingDisclosure.SectionN01_Seqno.Text;
                secN01 = secN01.Trim();
                Support.AreEqual("True", secN01.Equals("01", StringComparison.OrdinalIgnoreCase).ToString());
                string secN01desc = FastDriver.ClosingDisclosure.SectionN01_Label.Text;
                Support.AreEqual("True", secN01desc.Equals("Excess Deposit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionN01_Amt.Text.Trim());

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {
                FailTest(e.Message);


            }
        }

        #endregion

        #region 362772: CD Screen – Section N: Display “Existing Loan(s) Assumed or Taken Subject to” on line N03

        [TestMethod]
        public void US_362772_TC_367063_NO_01()
        {
            Reports.TestDescription = "VERIFY  THE EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO LEVEL AND AMOUNT IS CD SCREEN";
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            try
            {
                //
                //
                Reports.TestStep = "Login to file side";
                Reports.TestStep = "Login to FAST";

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                // FastDriver.AssumptionLoanCharges.SwitchToBottomFrame();
                Playback.Wait(10000);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("12345678901.23");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("12345678901.23");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();


                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N03";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                //
                //
                Reports.TestStep = "Validating the value of Section N Line 03";

                string secN03 = FastDriver.ClosingDisclosure.SectionN03_Seqno.Text.Trim();
                Support.AreEqual("True", secN03.Equals("03", StringComparison.OrdinalIgnoreCase).ToString());

                string secN03Desc = FastDriver.ClosingDisclosure.SectionN03_Label.Text.Trim();
                Support.AreEqual("True", secN03Desc.Equals("*  Existing Loan(s) Assumed or Taken Subject to", StringComparison.OrdinalIgnoreCase).ToString());


                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionN03_Amt.Text.Trim());

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();



            }

            catch (Exception e)
            {
                FailTest(e.Message);

            }

        }

        [TestMethod]
        public void US_362772_TC_367065_NO_03()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO AMOUNT FROM MULTIPLE CHARGES IN DIFFERENT SECTION";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanCharges>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("3000");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing, 10);
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("2000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("1000");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                Playback.Wait(4000);
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                // FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                // FastDriver.BottomFrame.SwitchToContentFrame();
                //FastDriver.BottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                Playback.Wait(10000);
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FASetText("5000");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-1000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("6000");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.SwitchToBottomFrame();
                //FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N03";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                //
                //
                Reports.TestStep = "Validating the value of Section N Line 03";
                string secN03 = FastDriver.ClosingDisclosure.SectionN03_Seqno.Text;
                secN03 = secN03.Trim();
                Support.AreEqual("True", secN03.Equals("03", StringComparison.OrdinalIgnoreCase).ToString());

                string secN03Desc = FastDriver.ClosingDisclosure.SectionN03_Label.Text;
                secN03Desc = secN03Desc.Trim();
                Support.AreEqual("True", secN03Desc.Equals("*  Existing Loan(s) Assumed or Taken Subject to", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("$1,000.00", FastDriver.ClosingDisclosure.SectionN03_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();


            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_362772_TC_367068_NO_05()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO AMOUNT FROM MULTIPLE CHARGES IN DIFFERENT SECTION AND DIFFERENT INSTANCES";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanCharges>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("500");
                Keyboard.SendKeys("TAB");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing, 10);
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("300");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("200");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                Playback.Wait(4000);
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(10000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FASetText("1000");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesPaymentDetails.Click();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing, 10);
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("1500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
                Playback.Wait(5000);
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.FAClick();
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("248");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("1000");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"700",PaidbySellerBeforeClosing:"300");
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FASetText("2000");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-1300", PaidbySellerOthers: "3300",SellerPaidbyOthersPaymentMethod:"POC");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N03";
                this.ClickOnSummaryOftrans();
                //
                //
                Reports.TestStep = "Validating the value of Section N Line 03";

                string secN03 = FastDriver.ClosingDisclosure.SectionN03_Seqno.Text;
                secN03 = secN03.Trim();
                Support.AreEqual("True", secN03.Equals("03", StringComparison.OrdinalIgnoreCase).ToString());

                string secN03desc = FastDriver.ClosingDisclosure.SectionN03_Label.Text;
                secN03desc = secN03desc.Trim();
                Support.AreEqual("True", secN03desc.Equals("*  Existing Loan(s) Assumed or Taken Subject to", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("-$800.00", FastDriver.ClosingDisclosure.SectionN03_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion

        #region 363417: CD Screen - Section N: Display Seller Credit on Line N08
        [TestMethod]
        public void US_363417_TC_367642_NO_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE SELLER CREDIT LEVEL AND AMOUNT IS CD SCREEN";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                //string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").SwitchToContentFrame();
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.CreateStandardFile();


                //
                //
                Reports.TestStep = "Setting Seller Charge in Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("5000");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();

                //
                //
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                //
                //
                Reports.TestStep = "Validating Section N Line 08";
                string secN08 = FastDriver.ClosingDisclosure.SectionN08_Seqno.Text;
                secN08 = secN08.Trim();
                Support.AreEqual("True", secN08.Equals("08", StringComparison.OrdinalIgnoreCase).ToString());

                string secN08Desc = FastDriver.ClosingDisclosure.SectionN08_Label.Text;
                secN08Desc = secN08Desc.Trim();
                Support.AreEqual("True", secN08Desc.Equals("Seller Credit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionN08_Amt.Text.Equals("$5,000.00").ToString());

                //
                //
                Reports.TestStep = "Saving the CD screen";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();

                //
                //
                Reports.TestStep = "Edit Seller Charge in Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("100000.55");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();

                //
                //
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Validate the editated value for Section N Line 08";
                string secN08a = FastDriver.ClosingDisclosure.SectionN08_Seqno.Text;
                secN08a = secN08a.Trim();
                Support.AreEqual("True", secN08a.Equals("08", StringComparison.OrdinalIgnoreCase).ToString());

                string secN08Desca = FastDriver.ClosingDisclosure.SectionN08_Label.Text;
                secN08Desca = secN08Desca.Trim();
                Support.AreEqual("True", secN08Desca.Equals("Seller Credit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionN08_Amt.Text.Equals("$100,000.55").ToString());
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();

            }
            catch (Exception eplote)
            {

                FailTest(eplote.Message);
            }
        }

        [TestMethod]
        public void US_363417_TC_367644_NO_03()
        {//green
            try
            {
                Reports.TestDescription = "VERIFY THE SELLER CREDIT AMOUNT HAVING MAXIMUM DIGITS IN CD SCREEN";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                //string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Setting Seller Charge in Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                FastDriver.AdjustmentOffset.SellerCharge3.FASetText("12345678901.23");
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();

                Reports.TestStep = "Validating Section N Line 08";
                this.ClickOnSummaryOftrans();
                string secN08 = FastDriver.ClosingDisclosure.SectionN08_Seqno.Text;
                secN08 = secN08.Trim();
                Support.AreEqual("True", secN08.Equals("08", StringComparison.OrdinalIgnoreCase).ToString());

                string secN08Desc = FastDriver.ClosingDisclosure.SectionN08_Label.Text;
                secN08Desc = secN08Desc.Trim();
                Support.AreEqual("True", secN08Desc.Equals("Seller Credit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionN08_Amt.Text.Equals("$345,678,901.23").ToString());
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region 362784: CD Screen – Section N: Display “Payoff of First Mortgage Loan” on line N04
        [TestMethod]
        public void US_362784_TC_367605_NO_01()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY THE SELLER CREDIT AMOUNT HAVING MAXIMUM DIGITS IN CD SCREEN";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();
         
                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FASetText("12345678901.23");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("12345678901.23");
                FastDriver.PaymentDetailsNewLoanDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N04";
                this.ClickOnSummaryOftrans();

                string seq = FastDriver.ClosingDisclosure.SectionN04_Seqno.Text;
                seq.Trim();
                Support.AreEqual("True", seq.Equals("04", StringComparison.OrdinalIgnoreCase).ToString());

                string label = FastDriver.ClosingDisclosure.SectionN04_Label.Text;
                label.Trim();
                Support.AreEqual("*  Payoff of First Mortgage Loan",FastDriver.ClosingDisclosure.SectionN04_Label.Text.Trim());

                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionN04_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_362784_TC_367607_NO_03()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF FIRST MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES IN DIFFERENT SECTION";

                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 5000, chargeDescription: "Statement/Forwarding Fee");

                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"-2500",PaidbySellerBeforeClosing:"7500",sellerCredit:"1000",SellerCreditPaymentMethod:"At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 10000, chargeDescription: "Reconveyance Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-5000", PaidbySellerOthers:"15000",sellerCredit: "2000",SellerPaidbyOthersPaymentMethod:"POC", SellerCreditPaymentMethod: "At Closing");
                
                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N04";
                this.ClickOnSummaryOftrans();

                string seq = FastDriver.ClosingDisclosure.SectionN04_Seqno.Text;
                seq.Trim();
                Support.AreEqual("True", seq.Equals("04", StringComparison.OrdinalIgnoreCase).ToString());

                
                Support.AreEqual("*  Payoff of First Mortgage Loan", FastDriver.ClosingDisclosure.SectionN04_Label.Text.Trim());

                Support.AreEqual("-$10,500.00", FastDriver.ClosingDisclosure.SectionN04_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();

            }
            catch (Exception e)
            {
                FailTest(e.Message);

            }
        }

        [TestMethod]
        public void US_362784_TC_373706_NO_04()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF FIRST MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES HAVING ONLY Seller Credits";

                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
              
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 0, chargeDescription: "Statement/Forwarding Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 0, chargeDescription: "Reconveyance Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");

                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N04";
                this.ClickOnSummaryOftrans();

                string seq = FastDriver.ClosingDisclosure.SectionN04_Seqno.Text;
                seq.Trim();
                Support.AreEqual("True", seq.Equals("04", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("*  Payoff of First Mortgage Loan", FastDriver.ClosingDisclosure.SectionN04_Label.Text.Trim());

                Support.AreEqual("-$2,000.00", FastDriver.ClosingDisclosure.SectionN04_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }

        }

        [TestMethod]
        public void US_362784_TC_374600_NO_05()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE LINE N04 AMOUNT AFTER DELETING SELLER CHARGE";

                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home/Order Entry/Payoff Loan");
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 5000, chargeDescription: "Statement/Forwarding Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"5000", sellerCredit: "1500", SellerCreditPaymentMethod: "At Closing");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //
                //
                Reports.TestStep = "Deleting Charges from Payoff Loan Screen";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 0, chargeDescription: "Statement/Forwarding Fee");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N04";
                this.ClickOnSummaryOftrans();

                string seq = FastDriver.ClosingDisclosure.SectionN04_Seqno.Text;
                seq.Trim();
                Support.AreEqual("True", seq.Equals("04", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("*  Payoff of First Mortgage Loan", FastDriver.ClosingDisclosure.SectionN04_Label.Text.Trim());

                Support.AreEqual("-$1,500.00", FastDriver.ClosingDisclosure.SectionN04_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
            }

            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_362784_TC_382134_NO_07()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF FIRST MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES IN DIFFERENT SECTION WITH Seller Credits PAYMENT METHOD AS POC";

                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home/Order Entry/Payoff Loan");


                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 5000, chargeDescription: "Statement/Forwarding Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"-2500",PaidbySellerBeforeClosing:"7500", sellerCredit: "1000", SellerCreditPaymentMethod: "POC");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 10000, chargeDescription: "Reconveyance Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-5000",PaidbySellerOthers:"15000", sellerCredit: "2000",SellerPaidbyOthersPaymentMethod:"POC" ,SellerCreditPaymentMethod: "POC");

                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N04";
                this.ClickOnSummaryOftrans();

                string seq = FastDriver.ClosingDisclosure.SectionN04_Seqno.Text;
                seq.Trim();
                Support.AreEqual("True", seq.Equals("04", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("*  Payoff of First Mortgage Loan", FastDriver.ClosingDisclosure.SectionN04_Label.Text.Trim());

                Support.AreEqual("-$7,500.00", FastDriver.ClosingDisclosure.SectionN04_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        #endregion

        #region 362785: CD Screen – Section N: Display “Payoff of Second Mortgage Loan” on line N05

        [TestMethod]
        public void US_362785_TC_367608_NO_01()
        {//GReen
            try
            {
                Reports.TestDescription = "VERIFY THE SELLER CREDIT AMOUNT HAVING MAXIMUM DIGITS IN CD SCREEN";
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 12345678901.23, chargeDescription: "Statement/Forwarding Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "12345678901.23");
                FastDriver.BottomFrame.Done();
               
                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N05";
                this.ClickOnSummaryOftrans();
                string seq = FastDriver.ClosingDisclosure.SectionN05_Seqno.Text;
                seq.Trim();
                Support.AreEqual("True", seq.Equals("05", StringComparison.OrdinalIgnoreCase).ToString());

                string label = FastDriver.ClosingDisclosure.SectionN04_Label.Text;
                label.Trim();
                Support.AreEqual("*  Payoff of Second Mortgage Loan", FastDriver.ClosingDisclosure.SectionN05_Label.Text.Trim());

                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionN05_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_362785_TC_367610_NO_03()
        {//Green

            Reports.TestDescription = "VERIFY  THE PAYOFF OF SECOND MORTGAGE LOAN LEVEL AND AMOUNT IS CD SCREEN";
            try
            {

                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                //string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home/Order Entry/Payoff Loan");
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 5000, chargeDescription: "Statement/Forwarding Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500",PaidbySellerBeforeClosing:"7500",sellerCredit:"1000",SellerCreditPaymentMethod:"At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, sellerCharge: 10000, chargeDescription: "Reconveyance Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-5000",PaidbySellerOthers:"15000", sellerCredit: "2000", SellerPaidbyOthersPaymentMethod: "POC",SellerCreditPaymentMethod:"At Closing");
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N05";
                this.ClickOnSummaryOftrans();

                string seq = FastDriver.ClosingDisclosure.SectionN05_Seqno.Text;
                seq.Trim();
                Support.AreEqual("True", seq.Equals("05", StringComparison.OrdinalIgnoreCase).ToString());

                string label = FastDriver.ClosingDisclosure.SectionN05_Label.Text;
                label.Trim();
                Support.AreEqual("*  Payoff of Second Mortgage Loan", FastDriver.ClosingDisclosure.SectionN05_Label.Text.Trim());

                Support.AreEqual("-$10,500.00", FastDriver.ClosingDisclosure.SectionN05_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();


            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }


        }
        [TestMethod]
        public void US_362785_TC_373708_NO_04()
        {//Green

            Reports.TestDescription = "VERIFY  THE PAYOFF OF SECOND MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES HAVING ONLY Seller Credits";
            try
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home/Order Entry/Payoff Loan");
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee",sellerCharge: 0);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(sellerCredit:"1000",SellerCreditPaymentMethod:"At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 0);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");

                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N05";
                this.ClickOnSummaryOftrans();

                string seq = FastDriver.ClosingDisclosure.SectionN05_Seqno.Text;
                seq.Trim();
                Support.AreEqual("True", seq.Equals("05", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("*  Payoff of Second Mortgage Loan", FastDriver.ClosingDisclosure.SectionN05_Label.Text.Trim());

                Support.AreEqual("-$2,000.00", FastDriver.ClosingDisclosure.SectionN05_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void US_362785_TC_374601_NO_05()
        {//Green
            Reports.TestDescription = "VERIFY  THE LINE N05 AMOUNT AFTER DELETING SELLER CHARGE";
            try
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"5000",sellerCredit:"1500",SellerCreditPaymentMethod:"At Closing");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.SwitchToContentFrame();

                Reports.TestStep = "Deleting Seller Charge from second Payoff Loan Screen";
                //FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Lenders Advantage", "Name", TableAction.Click);
                FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("grdLoanSumry_1_lblName")).FAClick();
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.ChargesTab, 10);
                FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 0);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N05";
                this.ClickOnSummaryOftrans();

                FastDriver.ClosingDisclosure.SectionN05_Seqno.FAClick();
                string seq = FastDriver.ClosingDisclosure.SectionN05_Seqno.Text;
                seq.Trim();
                
                Support.AreEqual("True", seq.Equals("05", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("*  Payoff of Second Mortgage Loan", FastDriver.ClosingDisclosure.SectionN05_Label.Text.Trim());
                
                Support.AreEqual("-$1,500.00", FastDriver.ClosingDisclosure.SectionN05_Amt.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_362785_TC_382144_NO_07()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF FIRST SECOND LOAN AMOUNT FROM MULTIPLE CHARGES IN DIFFERENT SECTION WITH Seller Credits PAYMENT METHOD AS POC";

                //
                //
                Reports.TestStep = "Login to FAST";
                this.Login();

                //
                //
                Reports.TestStep = "Create a basic file";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"-2500",PaidbySellerBeforeClosing:"7500",sellerCredit:"1000",SellerCreditPaymentMethod:"POC");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 10000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-5000", PaidbySellerOthers: "15000", sellerCredit: "2000",SellerPaidbyOthersPaymentMethod:"POC", SellerCreditPaymentMethod: "POC");
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N05";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN05_Seqno.FAClick();
                Support.AreEqual( "05",FastDriver.ClosingDisclosure.SectionN05_Seqno.Text.Clean());
                Support.AreEqual( "* Payoff of Second Mortgage Loan",FastDriver.ClosingDisclosure.SectionN05_Label.Text.Clean());
                Support.AreEqual("-$7,500.00",FastDriver.ClosingDisclosure.SectionN05_Amt.Text.Clean());
                this.Done();


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }


        }

        #endregion

        #region 363803: CD Screen - Section N: Display details of Assumptions Loan Seller Charges
        [TestMethod]
        public void US_363803_TC_382400_NO_01()
        {//Green
            try
            {
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //
                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Create a basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home/Order Entry/Payoff Loan");
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                //Playback.Wait(5000);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.BottomFrame.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.FAClick();
                Playback.Wait(5000);
                //
                //
                Reports.TestStep = "Validating the + icon in Line N03";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN03_Seqno.FAClick();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                //Playback.Wait(5000);
                bool N03PlusExist = false;
                try
                {
                    FastDriver.ClosingDisclosure.N03Plus.Click();
                    N03PlusExist = true;
                }
                catch (Exception e)
                {
                    
                    
                }
                Support.AreEqual("False", N03PlusExist.ToString());

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_363803_TC_382402_NO_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE PRESENCE OF 1ST INSTANCE ASSUMPTION LOAN CHARGES IN LINE N03 POPUP";
                //var credentials = new Credentials()
                //{
                //    UserName = AutoConfig.UserName,
                //    Password = AutoConfig.UserPassword
                //};

                ////
                ////
                //Reports.TestStep = "Login to file side";
                //FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Creating basic flie with WCF";
                this.CreateFileWithWCF();


                //
                //
                Reports.TestStep = "Create a basic File";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home/Order Entry/Payoff Loan");
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                //Playback.Wait(5000);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(500);
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);
                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.ChargesTab, 10);
                Playback.Wait(500);

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                Playback.Wait(3000);
                //here lies the source of knowledge;
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("90000");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("90000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");

                FastDriver.PaymentDetailsNewLoanDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);


                //
                //
                Reports.TestStep = "Validating the N03 popup";
                FastDriver.ClosingDisclosure.SectionN03_Seqno.FAClick();
                //N03Plus
                FastDriver.WebDriver.FindElement(By.Id("divImgGroupChargeN3")).FAClick();
                //N03Label
                Support.AreEqual("Seller Charges", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3Heading1")).Text.Trim());

                //Support.AreEqual("Seller Charges", FastDriver.ClosingDisclosure.N   SectionN03_Label.Text.Trim());
                //N03SeqNo
                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionN03_Seqno.Text.Trim());
                //N03Description
                Support.AreEqual("Existing Loan(s) Assumed or Taken Subject to", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3Desc")).Text.Trim());
                //N03Amt
                Support.Equals("$90,000.00", FastDriver.ClosingDisclosure.SectionN03_Amt.Text);
                //N03SeqNo1
                Support.AreEqual("a", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_SubSeqNo1")).Text);
                //N03ChargeDesc1
                Support.AreEqual("Assumption Loan 1 Charges", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Desc1")).Text);
                //N03TotalChargeAmt1
                Support.AreEqual("$90,000.00", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_SubTotalAmt1")).Text);
                //N03ChargeDesc2
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Desc2")).Text.Trim());
                //N03ChargeAmt2
                Support.AreEqual("$90,000.00", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Amt12")).Text);
                FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("btnSummaryChargePopUpDone")).FAClick();

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Editing the assumption Loan Charges";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanCharges>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("12345678901.23");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 10);
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("12345678901.23");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                Playback.Wait(7000);
                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                //
                //
                Reports.TestStep = "Validating the N03 popup after editing";
                FastDriver.ClosingDisclosure.SectionN03_Seqno.FAClick();
                FastDriver.WebDriver.FindElement(By.Id("divImgGroupChargeN3")).FAClick();
                //N03Label
                Support.AreEqual("Seller Charges", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3Heading1")).Text.Trim());
                //N03SeqNo
                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionN03_Seqno.Text.Trim());
                //N03Description
                Support.AreEqual("Existing Loan(s) Assumed or Taken Subject to", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3Desc")).Text.Trim());
                //N03Amt
                Support.Equals("$345,678,901.23", FastDriver.ClosingDisclosure.SectionN03_Amt.Text);
                //N03SeqNo1
                Support.AreEqual("a", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_SubSeqNo1")).Text);
                //N03ChargeDesc1
                Support.AreEqual("Assumption Loan 1 Charges", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Desc1")).Text.Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_SubTotalAmt1")).Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Desc2")).Text.Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Amt12")).Text.Trim());

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }

        }
        [TestMethod]
        public void US_363803_TC_382409_NO_04()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE ASSUMPTION LOAN CHARGES IN DIFFERENT SECTION WITH MULTIPLE PAYMENT METHOD IN LINE N03 POPUP";
                //
                //

                Reports.TestStep = "Login to file side";
                this.Login();


                //
                //
                Reports.TestStep = "Create a basic file";
                this.CreateFileWithWCF();


                //
                //
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                this.AssumpLoanDtlsFindGABCode("247");
                this.LoadAssumLoanChgChargesTab();
                this.ALchPaymentDetailsDlgFill("5000", "-2500", "7500", "0", "", "");
                this.ALchUNPaymentDetailsDlgFill("1000", "-500", "0", "1500", "", "POC");
                this.ClickOnSummaryOftrans();

                //
                //
                Reports.TestStep = "Validating the N03 popup";
                string N03Label = "Seller Charges";
                string N03SeqNo = "03";
                string N03Description = "Existing Loan(s) Assumed or Taken Subject to";
                string N03Amt = "-$3,000.00";
                string N03SeqNo1 = "a";
                string N03ChargeDesc1 = "Assumption Loan 1 Charges";
                string N03TotalChargeAmt1 = "-$3,000.00";
                string N03ChargeDesc2 = "Unpaid Principal Balance to Lenders Advantage A Division Of First American Title Ins. $1,500.00 P.O.C.";
                string N03ChargeAmt2 = "-$500.00";
                string N03ChargeDesc3 = "Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller";
                string N03ChargeAmt3 = "-$2,500.00";
                string N03SeqNo3 = "";
                this.CLickToValidateN03PopUp();
                this.ValidateN03PopUpFull(N03Label, N03SeqNo, N03Description, N03Amt, N03SeqNo1, N03ChargeDesc1, N03TotalChargeAmt1, N03ChargeDesc2, N03ChargeAmt2, N03ChargeDesc3, N03ChargeAmt3, N03SeqNo3);
                FastDriver.LeftNavigation.Navigate<HomePage>("Home");
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                Playback.Wait(1000);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }


        }
        [TestMethod]
        public void US_363803_TC_382410_NO_05()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE PRESENCE OF 2ND INSTANCE ASSUMPTION LOAN CHARGES IN LINE N03 POPUP";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create a standard file";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                this.AssumpLoanDtlsFindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();

                //this.AssumpLoanDtlsFindGABCode("248");
                FastDriver.AssumptionLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                this.LoadAssumLoanChgChargesTab();
                this.ALchPaymentDetailsDlgFill("50000.25", "50000.25", "0", "0", "", "");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                this.ClickOnSummaryOftrans();

                //
                //
                Reports.TestStep = "Validating the N03 popup";
                string N03Label = "Seller Charges";
                string N03SeqNo = "03";
                string N03Description = "Existing Loan(s) Assumed or Taken Subject to";
                string N03Amt = "$50,000.25";
                string N03SeqNo1 = "a";
                string N03ChargeDesc1 = "Assumption Loan 2 Charges";
                string N03TotalChargeAmt1 = "$50,000.25";
                string N03ChargeDesc2 = "Statement/Forwarding Fee to Midwest Financial Group";
                string N03ChargeAmt2 = "$50,000.25";
                string N03ChargeDesc3 = "";
                string N03ChargeAmt3 = "";
                string N03SeqNo3 = "";
                this.CLickToValidateN03PopUp();
                this.ValidateN03PopUpFull(N03Label, N03SeqNo, N03Description, N03Amt, N03SeqNo1, N03ChargeDesc1, N03TotalChargeAmt1, N03ChargeDesc2, N03ChargeAmt2, N03ChargeDesc3, N03ChargeAmt3, N03SeqNo3);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Editing the assumption Loan Charges for 2nd Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanSummary>("Home>Order Entry>Assumption Loan");
                //Playback.Wait(100000000);
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "2", 2, TableAction.Click);
                //FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Lenders Advantage", "Name", TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();
                this.LoadAssumLoanChgChargesTab();

                string sellerCharges = "12345678901.23";
                string PaidbySellerAtClosing = "12345678901.23";
                string PaidbySellerBeforeClosing = "0";
                string PaidbySellerOthers = "0";
                this.ALchPaymentDetailsDlgFill(sellerCharges, PaidbySellerAtClosing, PaidbySellerBeforeClosing, PaidbySellerOthers, "", "");
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.ClickOnSummaryOftrans();

                //
                //
                Reports.TestStep = "Validating the N03 popup after editing";
                string N03Labeld = "Seller Charges";
                string N03SeqNod = "03";
                string N03Descriptiond = "Existing Loan(s) Assumed or Taken Subject to";
                string N03Amtd = "$345,678,901.23";
                string N03SeqNo1d = "a";
                string N03ChargeDesc1d = "Assumption Loan 2 Charges";
                string N03TotalChargeAmt1d = "$345,678,901.23";
                string N03ChargeDesc2d = "Statement/Forwarding Fee to Midwest Financial Group";
                string N03ChargeAmt2d = "$345,678,901.23";
                string N03ChargeDesc3d = "";
                string N03ChargeAmt3d = "";
                string N03SeqNo3d = "";
                this.CLickToValidateN03PopUp();
                this.ValidateN03PopUpFull(N03Labeld, N03SeqNod, N03Descriptiond, N03Amtd, N03SeqNo1d, N03ChargeDesc1d, N03TotalChargeAmt1d, N03ChargeDesc2d, N03ChargeAmt2d, N03ChargeDesc3d, N03ChargeAmt3d, N03SeqNo3d);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_363803_TC_382416_NO_06()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE ASSUMPTION LOAN CHARGES WITH EDITED PAYEE NAME AND DESCRIPTION FROM MULTIPLE INSTANCES IN LINE N03 POPUP";


                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create a standard file";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                this.AssumpLoanDtlsFindGABCode("247");
                this.LoadAssumLoanChgChargesTab();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("5000.50");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Instance1 Description1", useDefault: "False", payeeName: "Instance1 Payee Name1",PaidbySellerAtClosing:"5000.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.AssumptionLoanDetails.FindGABCode("248");
                //this.AssumpLoanDtlsFindGABCode("248");
                this.LoadAssumLoanChgChargesTab();


                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("7000.70");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Instance2 Description2", useDefault: "False", payeeName: "Instance2 Payee Name2", PaidbySellerAtClosing: "7000.70");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                this.ClickOnSummaryOftrans();

                //
                //
                Reports.TestStep = "Validating the N03 popup";
                string N03Labeld = "Seller Charges";
                string N03SeqNod = "03";
                string N03Descriptiond = "Existing Loan(s) Assumed or Taken Subject to";
                string N03Amtd = "$12,001.20";
                string N03SeqNo1d = "a";
                string N03ChargeDesc1d = "Assumption Loan 1 Charges";
                string N03TotalChargeAmt1d = "$5,000.50";
                string N03ChargeDesc2d = "Instance1 Description1 to Instance1 Payee Name1";
                string N03ChargeAmt2d = "$5,000.50";
                string N03ChargeDesc3d = "Assumption Loan 2 Charges";
                string N03ChargeAmt3d = "";
                string N03SeqNo3 = "b";
                this.CLickToValidateN03PopUp();
                Support.AreEqual("Instance2 Description2 to Instance2 Payee Name2", FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Desc4")).Text.Trim());
                Support.AreEqual("$7,000.70", FastDriver.CDN03Popup.N03ChargeAmt4.Text.Trim());
                Support.AreEqual("$7,000.70", FastDriver.CDN03Popup.N03TotalChargeAmt3.Text.Trim());
                
                
                this.ValidateN03PopUpFull(N03Labeld, N03SeqNod, N03Descriptiond, N03Amtd, N03SeqNo1d, N03ChargeDesc1d, N03TotalChargeAmt1d, N03ChargeDesc2d, N03ChargeAmt2d, N03ChargeDesc3d, N03ChargeAmt3d, N03SeqNo3);
                //FastDriver.WebDriver.FindElements(OpenQA.Selenium.By.Id("btnSummaryChargePopUpDone")).GetAllVisible().First().FAClick();
                
//                FastDriver.CDN03Popup.Done.FAClick();

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }


        [TestMethod]
        public void US_363803_TC_382420_NO_07()
        {//Green
            try
            {

                Reports.TestDescription = "VERIFY MULTIPLE ASSUMPTION LOAN CHARGES IN DIFFERENT SECTION WITH MULTIPLE PAYMENT METHOD FROM MULTIPLE INSTANCES IN LINE N03 POPUP";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Creating basic flie with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                this.AssumpLoanDtlsFindGABCode("247");
                Playback.Wait(5000);
                this.LoadAssumLoanChgChargesTab();
                
                this.UpdateCharge(FastDriver.AssumptionLoanCharges, FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, sellerCharge: 5000, chargeDescription: "Statement/Forwarding Fee");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"-2500",PaidbySellerBeforeClosing:"7500");

                this.UpdateCharge(FastDriver.AssumptionLoanCharges, FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesTable, sellerCharge: 1000, chargeDescription: "Unpaid Principal Balance");
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-500", PaidbySellerOthers: "1500",SellerPaidbyOthersPaymentMethod:"POC");
                
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                //
                // --issue detected
                Reports.TestStep = "Adding Charges for Assumption Loan Second Instance";
                FastDriver.BottomFrame.New();
               // Keyboard.SendKeys("^N");
                Playback.Wait(5000);
                FastDriver.AssumptionLoanDetails.FindGABCode("248");
                //this.AssumpLoanDtlsFindGABCode("248");
                Playback.Wait(4000);
                this.LoadAssumLoanChgChargesTab();
                this.UpdateCharge(FastDriver.AssumptionLoanCharges, FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, chargeDescription: "Document Fee",sellerCharge: 3000);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"-1000",PaidbySellerBeforeClosing:"3000",PaidbySellerOthers:"1000",SellerPaidbyOthersPaymentMethod:"POC-L");

                this.UpdateCharge(FastDriver.AssumptionLoanCharges, FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesTable, chargeDescription: "Unpaid Principal Balance", sellerCharge: 2000);
                FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-7000",PaidbySellerOthers: "9000", SellerPaidbyOthersPaymentMethod: "POC-L");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                this.ClickOnSummaryOftrans();

                //
                //TODO:Confirm the accuracy of these values
                Reports.TestStep = "Validating the N03 popup";
                /*string N03Label = "Seller Charges";
                string N03SeqNo = "03";
                string N03Description = "Existing Loan(s) Assumed or Taken Subject to";
                string N03Amt = "-$18,000.00";
                string N03SeqNo1 = "a";
                string N03ChargeDesc1 = "Assumption Loan 1 Charges";
                string N03TotalChargeAmt1 = "$5,000.00";
                string N03ChargeDesc2 = "Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.";
                string N03ChargeAmt2 = "$5,000.00";
                string N03ChargeDesc3 = "Assumption Loan 2 Charges";
                string N03ChargeAmt3 = "$6,000.00";
                string N03SeqNo3 = "b";
                this.CLickToValidateN03PopUp();
                Support.AreEqual("b", FastDriver.CDN03Popup.N03SeqNo4.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Midwest Financial Group", FastDriver.CDN03Popup.N03ChargeDesc4.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.CDN03Popup.N03TotalChargeAmt4.Text.Trim());
                Support.AreEqual("c", FastDriver.CDN03Popup.N03SeqNo5.Text.Trim());
                Support.AreEqual("Assumption Loan 3 Charges", FastDriver.CDN03Popup.N03ChargeDesc5.Text.Trim());
                Support.AreEqual("$7,000.00", FastDriver.CDN03Popup.N03ChargeAmt5.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.CDN03Popup.N03ChargeDesc6.Text.Trim());
                Support.AreEqual("$7,000.00", FastDriver.CDN03Popup.N03ChargeAmt6.Text.Trim());
                this.ValidateN03PopUpFull(N03Label, N03SeqNo, N03Description, N03Amt, N03SeqNo1, N03ChargeDesc1, N03TotalChargeAmt1, N03ChargeDesc2, N03ChargeAmt2, N03ChargeDesc3, N03ChargeAmt3, N03SeqNo3);
                */
                FastDriver.ClosingDisclosure.SectionN03_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N03Plus.FAClick();
                Playback.Wait(500);

                Support.AreEqual("Seller Charges", FastDriver.CDN03Popup.N03Label.Text.Trim());
                Support.AreEqual("03", FastDriver.CDN03Popup.N03SeqNo.Text.Trim());
                Support.AreEqual("Existing Loan(s) Assumed or Taken Subject to", FastDriver.CDN03Popup.N03Description.Text.Trim());
                Support.AreEqual("-$11,000.00", FastDriver.CDN03Popup.N03Amt.Text.Trim());
                Support.AreEqual("a", FastDriver.CDN03Popup.N03SeqNo1.Text.Trim());
                Support.AreEqual("Assumption Loan 1 Charges", FastDriver.CDN03Popup.N03ChargeDesc1.Text.Trim());
                Support.AreEqual("-$3,000.00", FastDriver.CDN03Popup.N03TotalChargeAmt1.Text.Trim());
                Support.AreEqual("Unpaid Principal Balance to Lenders Advantage A Division Of First American Title Ins. $1,500.00 P.O.C.", FastDriver.CDN03Popup.N03ChargeDesc2.Text.Trim());
                Support.AreEqual("-$500.00", FastDriver.CDN03Popup.N03ChargeAmt2.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller", FastDriver.CDN03Popup.N03ChargeDesc3.Text.Trim());
                Support.AreEqual("-$2,500.00", FastDriver.CDN03Popup.N03ChargeAmt3.Text.Trim());
                Support.AreEqual("b", FastDriver.CDN03Popup.N03SeqNo4.Text.Trim());
                Support.AreEqual("Assumption Loan 2 Charges", FastDriver.CDN03Popup.N03ChargeDesc4.Text.Trim());
                Support.AreEqual("-$8,000.00", FastDriver.CDN03Popup.N03TotalChargeAmt4.Text.Trim());
                Support.AreEqual("Unpaid Principal Balance to Midwest Financial Group $9,000.00 P.O.C. Lender", FastDriver.CDN03Popup.N03ChargeDesc5.Text.Trim());
                Support.AreEqual("-$7,000.00", FastDriver.CDN03Popup.N03ChargeAmt5.Text.Trim());
                Support.AreEqual("Document Fee to Midwest Financial Group $4,000.00 P.O.C.", FastDriver.CDN03Popup.N03ChargeDesc6.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.CDN03Popup.N03ChargeAmt6.Text.Trim());



                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_363803_TC_388294_NO_08()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE PRESENCE OF MULTIPLE INSTANCES ASSUMPTION LOAN CHARGES IN LINE N03 POPUP";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Creating basic flie with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                this.AssumpLoanDtlsFindGABCode("247");
                this.LoadAssumLoanChgChargesTab();
                this.ALchPaymentDetailsDlgFill("5000", "-2500", "7500", "0", "", "");
                this.ALchUNPaymentDetailsDlgFill("1000", "-500", "0", "1500", "", "POC");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Adding Charges for Assumption Loan Second Instance";
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                //this.AssumpLoanDtlsFindGABCode("248");
                FastDriver.BottomFrame.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("248");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(500);
                //FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.SwitchToContentFrame();
                Playback.Wait(5000);

                this.LoadAssumLoanChgChargesTab();
                this.ALchPaymentDetailsDlgFill("6000", "6000", "0", "0", "", "");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Adding Charges for Assumption Loan Third Instance";
                FastDriver.AssumptionLoanSummary.SwitchToContentFrame();
                FastDriver.AssumptionLoanSummary.New.FAClick();
                Playback.Wait(3000);
                //this.AssumpLoanDtlsFindGABCode("HUDFLINSR1");
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("HUDFLINSR1");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                this.LoadAssumLoanChgChargesTab();
                this.ALchPaymentDetailsDlgFill("7000", "7000", "0", "0", "", "");
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                this.ClickOnSummaryOftrans();

                //
                //
                Reports.TestStep = "Validating the N03 popup";
                this.CLickToValidateN03PopUp();
                string N03Label = "Seller Charges";
                string N03SeqNo = "03";
                string N03Description = "Existing Loan(s) Assumed or Taken Subject to";
                string N03Amt = "$10,000.00";
                string N03SeqNo1 = "a";
                string N03ChargeDesc1 = "Assumption Loan 1 Charges";
                string N03TotalChargeAmt1 = "-$3,000.00";
                string N03ChargeDesc2 = "Unpaid Principal Balance to Lenders Advantage A Division Of First American Title Ins. $1,500.00 P.O.C.";
                string N03ChargeAmt2 = "-$500.00";
                string N03ChargeDesc3 = "Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller";
                string N03ChargeAmt3 = "-$2,500.00";
                string N03SeqNo3 = "";
                this.CLickToValidateN03PopUp();
                Support.AreEqual("b", FastDriver.WebDriver.FindElement(By.Id("N3SubCharge_SubSeqNo4")).Text);
                Support.AreEqual("b", FastDriver.CDN03Popup.N03SeqNo4.Text.Trim());
                Support.AreEqual("Assumption Loan 2 Charges", FastDriver.CDN03Popup.N03ChargeDesc4.Text.Trim());
                Support.AreEqual("$6,000.00", FastDriver.CDN03Popup.N03TotalChargeAmt4.Text.Trim());
                Support.AreEqual("c", FastDriver.CDN03Popup.N03ChargeSubDesc6.Text.Trim());
                Support.AreEqual("Assumption Loan 3 Charges", FastDriver.CDN03Popup.N03ChargeDesc6.Text.Trim());
                Support.AreEqual("$7,000.00", FastDriver.CDN03Popup.N03ChargeSubAmt6.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Flood Insurance 1 for HUD Testing Name 1 Flood Insurance 1 for HUD Testing Name 2", FastDriver.CDN03Popup.N03ChargeDesc7.Text.Trim());
                Support.AreEqual("$7,000.00", FastDriver.CDN03Popup.N03ChargeAmt17.Text.Trim());
                this.ValidateN03PopUpFull(N03Label, N03SeqNo, N03Description, N03Amt, N03SeqNo1, N03ChargeDesc1, N03TotalChargeAmt1, N03ChargeDesc2, N03ChargeAmt2, N03ChargeDesc3, N03ChargeAmt3, N03SeqNo3);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }


        }
        #endregion

        #region 379157: CD Screen - Section N: View details of the charges that are part of Payoff of First Mortgage Loan
        [TestMethod]
        public void US_379157_TC_383371_NO_01()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE EXISTANCE OF + ICON IN LINE N04";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create a basic file";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.AssumpLoanDtlsFindGABCode("247");

                //
                //
                Reports.TestStep = "Validating the + icon in CD Screen line N04";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN04_Seqno.FAClick();
                Support.AreEqual("False", FastDriver.ClosingDisclosure.N04Plus.Exists().ToString());

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_379157_TC_383375_NO_03()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE PAYOFF OF FIRST MORTGAGE LOAN CHARGES WITH EDITED PAYEE NAME AND DESCRIPTION IN LINE N04 POPUP";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee",sellerCharge: 5000.50);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1",PaidbySellerAtClosing:"5000.50",sellerCredit:"1000.25",SellerCreditPaymentMethod:"At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 5000.50);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description2", useDefault: "False", payeeName: "EMPTY", PaidbySellerAtClosing: "5000.50", sellerCredit: "1000.25", SellerCreditPaymentMethod: "At Closing");

                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                //
                //
                Reports.TestStep = "Validating the charges in CD Screen line N04 popup";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N04Plus.FAClick();
                Support.AreEqual("Seller Charges", FastDriver.CDN04Popup.N04SellerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.CDN04Popup.N04SeqNo.Text.Trim());
                Support.AreEqual("Payoff of First Mortgage Loan", FastDriver.CDN04Popup.N04Description.Text.Trim());
                Support.AreEqual("$8,000.50", FastDriver.CDN04Popup.N04Amt.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1", FastDriver.CDN04Popup.N04ChargeDesc1.Text.Trim());
                Support.AreEqual("$4,000.25", FastDriver.CDN04Popup.N04SellerCharge1.Text.Trim());
                Support.AreEqual("$4,000.25", FastDriver.CDN04Popup.N04SellerCharge2.Text.Trim());
                FastDriver.CDN04Popup.Done.FAClick();


                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {

                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_379157_TC_383376_NO_04()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE PAYOFF OF FIRST MORTGAGE LOAN CHARGES IN DIFFERENT SECTION WITH MULTIPLE PAYMENT METHOD IN LINE N04 POPUP";

                //
                //
                Reports.TestStep = "Login to file side";
                //this.Login();
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                //
                //

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //
                //
                Reports.TestStep = "Creating Basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                this.PayOfflFindGABCode("247");
                Playback.Wait(1000);
                // FastDriver.BottomFrame.Done();
                this.LoadPayoffLoanChargesTab();
                //FastDriver.PayoffLoanDetails.WaitCreation(FastDriver.PayoffLoanDetails.ChargesTab,4);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                var element = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.FindElements(By.TagName("input")).FirstOrDefault(i => i.GetAttribute("id").Contains("1_tsc") && i.Displayed);
                element.Clear();
                element.FASetText("5000");
                //tDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Seller Charge", TableAction.SetText, "5000");
                FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"-2500",PaidbySellerBeforeClosing:"7500",sellerCredit:"1000",SellerCreditPaymentMethod:"At Closing");

                
                
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("7500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASetText("At Closing");
                FastDriver.PaymentDetailsDlg.SwitchToBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "10000");
                FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("New Loan Payment Details");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-5000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("15000");
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("2000");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASetText("POC");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASetText("At Closing");
                FastDriver.PaymentDetailsDlg.SwitchToBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                //
                //
                Reports.TestStep = "Validating the charges in CD Screen line N04 popup";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N04Plus.FAClick();

                Support.AreEqual("Seller Charges", FastDriver.CDN04Popup.N04SellerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.CDN04Popup.N04SeqNo.Text.Trim());
                Support.AreEqual("Payoff of First Mortgage Loan", FastDriver.CDN04Popup.N04Description.Text.Trim());
                Support.AreEqual("-$10,500.00", FastDriver.CDN04Popup.N04Amt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $15,000.00 P.O.C.", FastDriver.CDN04Popup.N04ChargeDesc1.Text.Trim());
                Support.AreEqual("-$7,000.00", FastDriver.CDN04Popup.N04SellerCharge1.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller", FastDriver.CDN04Popup.N04ChargeDesc2.Text.Trim());
                Support.AreEqual("-$3,500.00", FastDriver.CDN04Popup.N04SellerCharge2.Text.Trim());
                FastDriver.CDN04Popup.Done.FAClick();

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379157_TC_383377_NO_05()
        {  //Green
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE PAYOFF OF FIRST MORTGAGE LOAN CHARGES IN DIFFERENT SECTION WITH MULTIPLE PAYMENT METHOD IN LINE N04 POPUP";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create a basic file";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.PayOfflFindGABCode("247");
                Playback.Wait(1000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                this.LoadPayoffLoanChargesTab();
                Playback.Wait(1000);
                //FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.ChargesTab, 5);
                //FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Seller Charge", TableAction.SetText, "4000");
                //FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Reconveyance Fee", "Seller Charge", TableAction.Click);
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee",sellerCharge: 4000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"-2500",PaidbySellerBeforeClosing:"3500",PaidbySellerOthers:"3000",sellerCredit:"1000",SellerPaidbyOthersPaymentMethod:"POC-L",SellerCreditPaymentMethod:"At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 10000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-5000", PaidbySellerOthers: "15000", sellerCredit: "2000", SellerPaidbyOthersPaymentMethod: "POC-L", SellerCreditPaymentMethod: "At Closing");
                
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                //
                //
                Reports.TestStep = "Validating the charges in CD Screen line N04 popup";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N04Plus.FAClick();

                Support.AreEqual("Seller Charges", FastDriver.CDN04Popup.N04SellerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.CDN04Popup.N04SeqNo.Text.Trim());
                Support.AreEqual("Payoff of First Mortgage Loan", FastDriver.CDN04Popup.N04Description.Text.Trim());
                Support.AreEqual("-$10,500.00", FastDriver.CDN04Popup.N04Amt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $15,000.00 P.O.C. Lender", FastDriver.CDN04Popup.N04ChargeDesc1.Text.Trim());
                Support.AreEqual("-$7,000.00", FastDriver.CDN04Popup.N04SellerCharge1.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Lenders Advantage A Division Of First American Title Ins. $6,500.00 P.O.C.", FastDriver.CDN04Popup.N04ChargeDesc2.Text.Trim());
                Support.AreEqual("-$3,500.00", FastDriver.CDN04Popup.N04SellerCharge2.Text.Trim());

                FastDriver.CDN04Popup.Done.FAClick();

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379157_TC_383380_NO_06()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF FIRST MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES HAVING ONLY Seller Credits IN N04 POPUP";

                //
                //
                this.Login();

                //
                //
                Reports.TestStep = "Create File with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                this.PayOfflFindGABCode("247");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                this.LoadPayoffLoanChargesTab();
                //FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, 3);

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 0);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 0);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(sellerCredit: "2000", SellerCreditPaymentMethod: "At Closing");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N04";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N04Plus.FAClick();
                Support.AreEqual("Seller Charges", FastDriver.CDN04Popup.N04SellerCharge.Text);
                Support.AreEqual("04", FastDriver.CDN04Popup.N04SeqNo.Text);
                Support.AreEqual("Payoff of First Mortgage Loan", FastDriver.CDN04Popup.N04Description.Text);
                Support.AreEqual("-$3,000.00", FastDriver.CDN04Popup.N04Amt.Text);
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDN04Popup.N04ChargeDesc1.Text);
                Support.AreEqual("-$1,000.00", FastDriver.CDN04Popup.N04SellerCharge1.Text);
                Support.AreEqual("Reconveyance Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDN04Popup.N04ChargeDesc2.Text);
                Support.AreEqual("-$2,000.00", FastDriver.CDN04Popup.N04SellerCharge2.Text);

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379157_TC_390726_NO_08()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE LINE N04 POPUP AMOUNT AFTER DELETING SELLER CHARGE";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.PayOfflFindGABCode("247");
                this.LoadPayoffLoanChargesTab();
                //FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, 3);
                Playback.Wait(3000);

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"5000",sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");
                
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 0);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);

                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N04 popup";
                this.ClickOnSummaryOftrans();

                FastDriver.ClosingDisclosure.SectionN04_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N04Plus.FAClick();
                Support.AreEqual("Seller Charges", FastDriver.CDN04Popup.N04SellerCharge.Text.Trim());
                Support.AreEqual("04", FastDriver.CDN04Popup.N04SeqNo.Text);
                Support.AreEqual("Payoff of First Mortgage Loan", FastDriver.CDN04Popup.N04Description.Text);
                Support.AreEqual("-$1,000.00", FastDriver.CDN04Popup.N04Amt.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.CDN04Popup.N04SellerCharge1.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDN04Popup.N04ChargeDesc1.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.CDN04Popup.N04SellerCharge1.Text.Trim());

                //
                //
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();



            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        #endregion
        #region 379158: CD Screen – Section N: View details of the charges that are part of Payoff of Second Mortgage Loan

        [TestMethod]
        public void US_379158_TC_383545_NO_01()
        {//Green
            Reports.TestDescription = "VERIFY  THE EXISTANCE OF + ICON IN LINE N05";

            //
            //
            Reports.TestStep = "Login to file side";
            this.Login();

            //
            //
            Reports.TestStep = "Create basic file with WCF";
            this.CreateFileWithWCF();
            //
            //
            Reports.TestStep = "Creating Charges in Payoff Loan Screen";
            this.PayOfflFindGABCode("237");
            FastDriver.BottomFrame.New();
            this.PayOfflFindGABCode("247");

            //
            //
            Reports.TestStep = "Validating the + icon in CD Screen line N05";
            this.ClickOnSummaryOftrans();
            FastDriver.ClosingDisclosure.SectionN05_Seqno.FAClick();
            Support.AreEqual("False", FastDriver.ClosingDisclosure.N05Plus.Exists().ToString());

            //
            //
            Reports.TestStep = "Saving the CD Screen";
            FastDriver.BottomFrame.Done();


        }

        [TestMethod]
        public void US_379158_TC_383548_NO_03()
        {//GREEN
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE PAYOFF OF SECOND MORTGAGE LOAN CHARGES WITH EDITED PAYEE NAME AND DESCRIPTION IN LINE N05 POPUP";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                Playback.Wait(2000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                this.PayOfflFindGABCode("237");
                Playback.Wait(2000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.BottomFrame.New();
                Playback.Wait(4000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(3000);
                this.LoadPayoffLoanChargesTab();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee",sellerCharge: 5000.50);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1",PaidbySellerAtClosing:"5000.50",sellerCredit:"1000.25",SellerCreditPaymentMethod:"At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 5000.50);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description2", useDefault: "False", payeeName: "EMPTY", PaidbySellerAtClosing: "5000.50", sellerCredit: "1000.25", SellerCreditPaymentMethod: "At Closing");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in CD Screen line N05 popup";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN05_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N05Plus.FAClick();
                Support.AreEqual("Seller Charges", FastDriver.CDN05Popup.N05SellerCharge.Text.Trim());
                Support.AreEqual("05", FastDriver.CDN05Popup.N05SeqNo.Text);
                Support.AreEqual("Payoff of Second Mortgage Loan", FastDriver.CDN05Popup.N05Description.Text.Trim());
                Support.AreEqual("$8,000.50", FastDriver.CDN05Popup.N05Amt.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1", FastDriver.CDN05Popup.N05ChargeDesc1.Text.Trim());
                Support.AreEqual("$4,000.25", FastDriver.CDN05Popup.N05SellerCharge1.Text.Trim());
                Support.AreEqual("Description2", FastDriver.CDN05Popup.N05ChargeDesc2.Text.Trim());
                Support.AreEqual("$4,000.25", FastDriver.CDN05Popup.N05SellerCharge2.Text.Trim());
                FastDriver.CDN05Popup.Done.FAClick();

                this.Done();


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }

        }

        [TestMethod]
        public void US_379158_TC_383549_NO_04()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE PAYOFF OF SECOND MORTGAGE LOAN CHARGES IN DIFFERENT SECTION WITH MULTIPLE PAYMENT METHOD IN LINE N05 POPUP";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                Playback.Wait(2000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                this.PayOfflFindGABCode("237");
                Playback.Wait(2000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.BottomFrame.New();
                Playback.Wait(4000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(3000);
                this.LoadPayoffLoanChargesTab();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500",PaidbySellerBeforeClosing:"7500" , sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 10000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-5000",PaidbySellerOthers:"15000"  ,sellerCredit: "2000", SellerPaidbyOthersPaymentMethod:"POC",SellerCreditPaymentMethod: "At Closing");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in CD Screen line N05 popup";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN05_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N05Plus.FAClick();
                Support.AreEqual("Seller Charges", FastDriver.CDN05Popup.N05SellerCharge.Text.Trim());
                Support.AreEqual("05", FastDriver.CDN05Popup.N05SeqNo.Text);
                Support.AreEqual("Payoff of Second Mortgage Loan", FastDriver.CDN05Popup.N05Description.Text.Trim());
                Support.AreEqual("-$10,500.00", FastDriver.CDN05Popup.N05Amt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $15,000.00 P.O.C.", FastDriver.CDN05Popup.N05ChargeDesc1.Text.Trim());
                Support.AreEqual("-$7,000.00", FastDriver.CDN05Popup.N05SellerCharge1.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller", FastDriver.CDN05Popup.N05ChargeDesc2.Text.Trim());
                Support.AreEqual("-$3,500.00", FastDriver.CDN05Popup.N05SellerCharge2.Text.Trim());
                FastDriver.CDN05Popup.Done.FAClick();

                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379158_TC_383550_NO_05()
        {//Green
            try
            {
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                Playback.Wait(2000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                this.PayOfflFindGABCode("237");
                Playback.Wait(2000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.BottomFrame.New();
                Playback.Wait(4000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(3000);
                this.LoadPayoffLoanChargesTab();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 4000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"-2500", PaidbySellerBeforeClosing:"3500",PaidbySellerOthers:"3000",sellerCredit:"1000",SellerPaidbyOthersPaymentMethod:"POC-L",SellerCreditPaymentMethod:"At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 10000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-5000", PaidbySellerOthers: "15000", sellerCredit: "2000", SellerPaidbyOthersPaymentMethod: "POC-L", SellerCreditPaymentMethod: "At Closing");
                FastDriver.BottomFrame.Done();
                
                //
                //
                Reports.TestStep = "Validating the charges in CD Screen line N05 popup";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN05_Seqno.FAClick();
                Playback.Wait(4000);
                FastDriver.ClosingDisclosure.N05Plus.FAClick();
                Support.AreEqual("Seller Charges", FastDriver.CDN05Popup.N05SellerCharge.Text.Trim());
                Support.AreEqual("05", FastDriver.CDN05Popup.N05SeqNo.Text);
                Support.AreEqual("Payoff of Second Mortgage Loan", FastDriver.CDN05Popup.N05Description.Text.Trim());
                Support.AreEqual("-$10,500.00", FastDriver.CDN05Popup.N05Amt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $15,000.00 P.O.C. Lender", FastDriver.CDN05Popup.N05ChargeDesc1.Text.Trim());
                Support.AreEqual("-$7,000.00", FastDriver.CDN05Popup.N05SellerCharge1.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Lenders Advantage A Division Of First American Title Ins. $6,500.00 P.O.C.", FastDriver.CDN05Popup.N05ChargeDesc2.Text.Trim());
                Support.AreEqual("-$3,500.00", FastDriver.CDN05Popup.N05SellerCharge2.Text.Trim());
                //FastDriver.CDN05Popup.Done.FAClick();
                FastDriver.WebDriver.FindElements(OpenQA.Selenium.By.Id("btnSummaryChargePopUpDone")).GetAllVisible().First().FAClick();

                this.Done();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }


        }

        [TestMethod]
        public void US_379158_TC_383551_NO_06()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF SECOND MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES HAVING ONLY Seller Credits IN N05 POPUP";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.PayOfflFindGABCode("237");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                //this.PayOfflFindGABCode("247");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("247");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                Playback.Wait(2000);
                //FastDriver.BottomFrame.Done();
                Playback.Wait(800);
                FastDriver.BottomFrame.SwitchToContentFrame();
                Playback.Wait(1000);
                this.LoadPayoffLoanChargesTab();
                
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 0);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(sellerCredit:"1000",SellerCreditPaymentMethod:"At Closing");


                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 0);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(sellerCredit: "2000", SellerCreditPaymentMethod: "At Closing");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N05";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN05_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N05Plus.FAClick();
                Support.AreEqual("Seller Charges", FastDriver.CDN05Popup.N05SellerCharge.Text.Trim());
                Support.AreEqual("05", FastDriver.CDN05Popup.N05SeqNo.Text);
                Support.AreEqual("Payoff of Second Mortgage Loan", FastDriver.CDN05Popup.N05Description.Text.Trim());
                Support.AreEqual("-$3,000.00", FastDriver.CDN05Popup.N05Amt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDN05Popup.N05ChargeDesc1.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.CDN05Popup.N05SellerCharge1.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDN05Popup.N05ChargeDesc2.Text.Trim());
                Support.AreEqual("-$2,000.00", FastDriver.CDN05Popup.N05SellerCharge2.Text.Trim());
                FastDriver.WebDriver.FindElements(OpenQA.Selenium.By.Id("btnSummaryChargePopUpDone")).GetAllVisible().First().FAClick();
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379158_TC_390729_NO_08()
        {//Green
            try
            {
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.PayOfflFindGABCode("237");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("247");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                Playback.Wait(1000);
                //FastDriver.BottomFrame.Done();
                Playback.Wait(800);
                FastDriver.BottomFrame.SwitchToContentFrame();
                Playback.Wait(1000);
                this.LoadPayoffLoanChargesTab();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"5000",sellerCredit:"1000",SellerCreditPaymentMethod:"At Closing");
               
                Playback.Wait(1000);
                
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                //
                Reports.TestStep = "Deleting Seller Charge from second Payoff Loan Screen";
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("#1", "2", "#2", TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.ChargesTab, 10);
                FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                IWebElement inputElement1 = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "0").Element
                   .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                inputElement1.Click();
                Playback.Wait(250);
                Keyboard.SendKeys("^D");

                //
                //
                Reports.TestStep = "Validating the amount in CD Screen line N05 popup";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN05_Seqno.FAClick();
                FastDriver.ClosingDisclosure.N05Plus.FAClick();
                Support.AreEqual("Seller Charges", FastDriver.CDN05Popup.N05SellerCharge.Text.Trim());
                Support.AreEqual("05", FastDriver.CDN05Popup.N05SeqNo.Text);
                Support.AreEqual("Payoff of Second Mortgage Loan", FastDriver.CDN05Popup.N05Description.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.CDN05Popup.N05Amt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDN05Popup.N05ChargeDesc1.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.CDN05Popup.N05SellerCharge1.Text.Trim());
                FastDriver.CDN05Popup.Done.FAClick();
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        #endregion

        #region 379148: CD Screen - Section N: Display Seller Charges on lines N06, 07, 09 to 13
        [TestMethod]
        public void US_379148_TC_394645_NO_02()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY DISBURSED AS PROCEEDS AMOUNT IN LINE N06";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("10000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("10000");
                FastDriver.BottomFrame.Save();
                Playback.Wait(3000);
                
                //
                //
                Reports.TestStep = "Validating Earnest Money Held in Section N";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Disbursed as Proceeds ($10,000.00)", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }

        }

        [TestMethod]
        public void US_379148_TC_394653_NO_03()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THIRD, FOURTH AND FIFTH PAYOFF LOAN INSTANCE CHARGES IN SECTION N";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.PayOfflFindGABCode("237");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.WaitCreation(FastDriver.NewLoanSummary.New, 10);
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(1000);
                this.LoadPayoffLoanChargesTab();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee",sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000", sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.LoanChargesTable, chargeDescription: "Principal Balance", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                //FastDriver.NewLoanSummary.WaitCreation(FastDriver.NewLoanSummary.New, 10);
                //FastDriver.NewLoanSummary.SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoanSummary.WaitCreation(FastDriver.NewLoanSummary.New, 10);
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("BOA");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                this.LoadPayoffLoanChargesTab();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 6000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "6000", sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.LoanChargesTable, chargeDescription: "Principal Balance", sellerCharge: 6000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "6000");
              
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoanSummary.WaitCreation(FastDriver.NewLoanSummary.New, 10);
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("HUDFLINSR1");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                this.LoadPayoffLoanChargesTab();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 7000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "7000", sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.LoanChargesTable, chargeDescription: "Principal Balance", sellerCharge: 7000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "7000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Payoff Loan 3 Charges", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim());//.Clean().Replace("*", ""));
                Support.AreEqual("$9,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                //SectionN07_Seqno
                FastDriver.ClosingDisclosure.SectionN07_Seqno.FAClick();
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Payoff Loan 4 Charges", FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Trim());//.Clean().Replace("*", ""));
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                //SectionN09_Seqno
                FastDriver.ClosingDisclosure.SectionN07_Seqno.FAClick();
                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionN09_Seqno.Text.Trim());
                Support.AreEqual("Payoff Loan 5 Charges", FastDriver.ClosingDisclosure.SectionN09_Label.GetAttribute("title").Trim());//.Clean().Replace("*", ""));
                Support.AreEqual("$13,000.00", FastDriver.ClosingDisclosure.SectionN09_Amt.Text.Trim());
                this.Done();


            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394655_NO_05()
        {//green
            try
            {
                Reports.TestDescription = "VERIFY  THIRD, PAYOFF LOAN INSTANCE CHARGE IN SECTION N HAVING SELLER BEFORE CLOSING AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.PayOfflFindGABCode("237");
                Keyboard.SendKeys("^D");
                Playback.Wait(5000);
                Keyboard.SendKeys("^N");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("247");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                Keyboard.SendKeys("^D");
                Playback.Wait(2000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.WaitCreation(FastDriver.NewLoanSummary.New, 10);
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("248");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                this.LoadPayoffLoanChargesTab();
                this.SetPayoffCharge("Statement/Forwarding Fee", "Seller Charge", "5000");
                FastDriver.PayoffLoanCharges.POLCPaymentDetails.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("7500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                Keyboard.SendKeys("^D");

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Payee Name1 $7,500.00 P.O.C. Seller", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim().Clean().Replace("*", ""));
                Support.AreEqual("-$3,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());

                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }

        }
        [TestMethod]
        public void US_379148_TC_394656_NO_06()
        {//green
            try
            {
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.PayOfflFindGABCode("237");
                Keyboard.SendKeys("^D");
                Playback.Wait(5000);
                Keyboard.SendKeys("^N");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("247");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                Keyboard.SendKeys("^D");
                Playback.Wait(2000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.WaitCreation(FastDriver.NewLoanSummary.New, 10);
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("248");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                this.LoadPayoffLoanChargesTab();
                this.SetPayoffCharge("Statement/Forwarding Fee", "Seller Charge", "5000");
                FastDriver.PayoffLoanCharges.POLCPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-3500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("8500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                Keyboard.SendKeys("^D");

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee $8,500.00 P.O.C. Lender", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim().Clean().Replace("*", ""));
                Support.AreEqual("-$4,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394658_NO_08()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY THIRD, PAYOFF LOAN INSTANCE CHARGE IN SECTION N HAVING  AMOUNT IN MULTIPLE METHOD";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.PayOfflFindGABCode("237");
                Keyboard.SendKeys("^D");
                Playback.Wait(5000);
                Keyboard.SendKeys("^N");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("247");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                Keyboard.SendKeys("^D");
                Playback.Wait(2000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.WaitCreation(FastDriver.NewLoanSummary.New, 10);
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("248");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                this.LoadPayoffLoanChargesTab();
                this.SetPayoffCharge("Reconveyance Fee", "Seller Charge", "5000");
                FastDriver.PayoffLoanCharges.POLCPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7000");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                Keyboard.SendKeys("^D");

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Midwest Financial Group $7,500.00 P.O.C.", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim().Clean().Replace("*", ""));
                Support.AreEqual("-$3,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394659_NO_09()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY THIRD, PAYOFF LOAN INSTANCE CHARGE IN SECTION N HAVING SELLER CREDIT AS POC";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                this.PayOfflFindGABCode("237");
                Keyboard.SendKeys("^D");
                Playback.Wait(5000);
                Keyboard.SendKeys("^N");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("247");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                Keyboard.SendKeys("^D");
                Playback.Wait(2000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.WaitCreation(FastDriver.NewLoanSummary.New, 10);
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText("248");
                FastDriver.PayoffLoanDetails.LenderFind.FAClick();
                this.LoadPayoffLoanChargesTab();
                this.SetPayoffCharge("Statement/Forwarding Fee", "Seller Charge", "5000");
                FastDriver.PayoffLoanCharges.POLCPaymentDetails.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                Keyboard.SendKeys("^D");
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Midwest Financial Group $1,000.00 P.O.C.", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim().Clean().Replace("*", ""));
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394660_NO_10()
        {//Green

            try
            {
                Reports.TestDescription = "VERIFY FIRST, SECOND AND THIRD HOMEOWNER ASSOCIATION INSTANCE CHARGES IN SECTION N";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in HOA Screen";
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("237");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //Keyboard.SendKeys("D");
                FastDriver.BottomFrame.Done();
                Playback.Wait(250);
                //Keyboard.SendKeys("N");
                FastDriver.BottomFrame.New();
                Playback.Wait(250);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("247");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociationSummary.SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.WaitForScreenToLoad();
                FastDriver.HomeownerAssociationSummary.New.FAClick();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.GABcode.FASetText("248");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(500);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2500);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim().Clean().Replace("*", ""));
                Support.AreEqual("$15,001.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }

        }
        [TestMethod]
        public void US_379148_TC_394662_NO_12()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY FIRST HOMEOWNER ASSOCIATION INSTANCE CHARGE IN SECTION N HAVING SELLER BEFORE CLOSING AMOUNT";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in HOA Screen";
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("247");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "5000");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("7500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1 $7,500.00 P.O.C. Seller", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim().Clean().Replace("*", ""));
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379148_TC_394663_NO_13()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY FIRST HOMEOWNER ASSOCIATION INSTANCE CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS BUYER BROKER AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in HOA Screen";
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("247");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "5000");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("7500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Description1 $7,500.00 P.O.C. Seller", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim().Clean().Replace("*", ""));
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394664_NO_14()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  FIRST HOMEOWNER ASSOCIATION INSTANCE CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS SELLER BROKER AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in HOA Screen";
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("247");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "5000");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Seller Broker");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller Broker", FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim().Clean().Replace("*", ""));
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394666_NO_16()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  FIRST HOMEOWNER ASSOCIATION INSTANCE CHARGE IN SECTION N HAVING  AMOUNT IN MULTIPLE METHOD";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in HOA Screen";
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("247");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "5000");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7000");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394667_NO_17()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  ADJUSTMENTS AMOUNTS IN SECTION N";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
                FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", "Buyer Deposit Directly to Seller", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Buyer Deposit Directly to Seller".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394668_NO_18()
        {// Green
            try
            {
                Reports.TestDescription = "VERIFY  FIRST, SECOND AND  THIRD PROPERTY TAX CHECK INSTANCE CHARGES IN SECTION N";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("237");
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_3.FASetText("5000.50");
                //Playback.Wait(2500000);
                //FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction("Description", "Tax Installment: Amount", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad().SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("247");
                // FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction("Description", "County Tax", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad().SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.FindGABCode("248");
                //Playback.Wait(1000000);
                //FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction("Description", "Tax Installment: Interest Due", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("5000.50");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Property Taxes".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("$15,001.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394670_NO_20()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  FIRST PROPERTY TAX CHECK INSTANCE CHARGE IN SECTION N HAVING SELLER BEFORE CLOSING AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();
                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("247");
               
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, chargeDescription: "Tax Installment: Amount", sellerCharge: 5000);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1",PaidbySellerAtClosing:"-2500",PaidbySellerBeforeClosing:"7500");
                
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1 $7,500.00 P.O.C. Seller".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394672_NO_22()
        {//Green
            try
            {
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                Playback.Wait(250);
                //Tax Installment: Interest Due
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("5000");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Interest Due to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                //Playback.Wait(10000000);
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394673_NO_23()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  FIRST PROPERTY TAX CHECK INSTANCE CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS SELLER BROKER AMOUNT";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                Playback.Wait(300);
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.AdditionalChargesTable, chargeDescription: "State Tax", sellerCharge: 5000);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod:"Seller Broker");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("State Tax to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller Broker".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394674_NO_24()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY FIRST PROPERTY TAX CHECK INSTANCE CHARGE IN SECTION N HAVING AMOUNT IN MULTIPLE METHOD";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //Playback.Wait(10000000);
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                Playback.Wait(250);
                //Tax Installment: Interest Due
                //state tax
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction("Description", "State Tax", "Seller Charge", TableAction.SetText, "5000");
                //FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_2.FASetText("5000");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7000");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Buyer Broker");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual(" State Tax to Lenders Advantage A Division Of First American Title Ins. ".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                //Playback.Wait(10000000);
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394675_NO_25()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  PRINCIPAL REDUCTION/CONSTRUCTION HOLD BACK  CHARGES IN SECTION N06";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("237");
                //FastDriver.NewLoan.ClickChargesTab();
                this.ClickOnNewLoanChargeTab();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", "Principal Reduction Payment", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                // FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", "Principal Reduction Payment", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                // FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment to Associated Great Northern Mortgage Co.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                //Playback.Wait(10000000);
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394678_NO_27()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  PRINCIPAL REDUCTION/CONSTRUCTION HOLDBACK  CHARGE IN SECTION N HAVING SELLER BEFORE CLOSING AMOUNT";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                //FastDriver.NewLoan.ClickChargesTab();
                this.ClickOnNewLoanChargeTab();
                Playback.Wait(250);
                
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable,chargeDescription:"Construction Holdback", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1",PaidbySellerAtClosing:"-2500",PaidbySellerBeforeClosing:"7500");
               
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1 $7,500.00 P.O.C. Seller".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379148_TC_394679_NO_28()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY PRINCIPAL REDUCTION/CONSTRUCTION HOLDBACK  CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS POC AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                //FastDriver.NewLoan.ClickChargesTab();
                this.ClickOnNewLoanChargeTab();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "Principal Reduction Payment", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"-2500",PaidbySellerOthers:"7500", SellerPaidbyOthersPaymentMethod:"POC");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group $7,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394681_NO_30()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY PRINCIPAL REDUCTION/CONSTRUCTION HOLDBACK  CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS POC-MB AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                //FastDriver.NewLoan.ClickChargesTab();
                this.ClickOnNewLoanChargeTab();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "Principal Reduction Payment", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(useDefault:"False",payeeName:"EMPTY",PaidbySellerAtClosing: "-2500", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "POC-MB");
                FastDriver.BottomFrame.Done();
                Playback.Wait(2500);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment $7,500.00 P.O.C. MB".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }

        }
        [TestMethod]
        public void US_379148_TC_394682_NO_31()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY PRINCIPAL REDUCTION/CONSTRUCTION HOLDBACK CHARGE IN SECTION N  HAVING  AMOUNT IN MULTIPLE METHOD";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                //FastDriver.NewLoan.ClickChargesTab();
                this.ClickOnNewLoanChargeTab();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "Construction Holdback", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500",PaidbySellerBeforeClosing:"500", PaidbySellerOthers: "7000", SellerPaidbyOthersPaymentMethod: "POC-MB");
                FastDriver.BottomFrame.Done();
                Playback.Wait(2500);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Construction Holdback to Midwest Financial Group $7,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394690_NO_32()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  NEW LOAN AND MORTGAGE BROKER SECOND, THIRD AND FOURTH INSTANCE  CHARGES IN SECTION N06";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                //added more waiting time;
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                this.ClickOnNewLoanChargeTab();
                Playback.Wait(250);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Document Preparation Fee", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Tax Service Contract", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", sellerCharge: 6000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "6000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                //
                //
                Reports.TestStep = "Creating Charges in New Loan 3 and Mortgage Broker 3 Screen";
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.NewLoan.FindGABCode("248");
                Playback.Wait(200);
                this.ClickOnNewLoanChargeTab();
                Playback.Wait(250);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: "Tax Service Contract", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Flood Certification", "Seller Charge", TableAction.SetText, "5000");
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000");
                Playback.Wait(250);
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageGABcode.FASetText("248");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "7000");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "7000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                //
                //
                Reports.TestStep = "Creating Charges in New Loan 4 and Mortgage Broker 4 Screen";
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: "Flood Certification", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000");

                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Document Preparation Fee", "Seller Charge", TableAction.SetText, "5000");
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000");
                Playback.Wait(3000);
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageGABcode.FASetText("237");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "8000");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "8000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("New Loan 2 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("$16,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("New Loan 3 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("$17,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionN09_Seqno.Text.Trim());
                Support.AreEqual("New Loan 4 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN09_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("$18,000.00", FastDriver.ClosingDisclosure.SectionN09_Amt.Text.Trim());

                this.Done();

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394693_NO_34()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  NEW LOAN CHARGE IN SECTION N HAVING SELLER BEFORE CLOSING AMOUNT";
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                //added more waiting time;
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                this.ClickOnNewLoanChargeTab();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Document Preparation Fee", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("7500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Document Preparation Fee to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());//.Replace("*", "")
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394694_NO_35()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS POC AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                //added more waiting time;
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                this.ClickOnNewLoanChargeTab();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Tax Service Contract", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Tax Service Contract to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Playback.Wait(5000);
                this.Done();


            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394697_NO_36()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS POC-L AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                //added more waiting time;
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                this.ClickOnNewLoanChargeTab();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Tax Service Contract", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Tax Service Contract to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Lender".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394700_NO_38()
        {//Label Fixed use as a guide
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN CHARGE IN SECTION N  HAVING  AMOUNT IN MULTIPLE METHOD";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                //added more waiting time;
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                this.ClickOnNewLoanChargeTab();
                FastDriver.NewLoan.SwitchToContentFrame();
                //this methods fires the needed JS events to make sure the seller charge shows up on the paymentdetails dialog;
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Flood Certification", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7000");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Flood Certification to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394702_NO_40()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  MORTGAGE BROKER CHARGE IN SECTION N HAVING SELLER BEFORE CLOSING AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");

                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("248");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(4000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                Playback.Wait(2000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Charge", TableAction.SetText, "5000");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("7500");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Appraisal Fee to Midwest Financial Group $7,500.00 P.O.C. Seller".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379148_TC_394703_NO_41()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MORTGAGE BROKER CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS POC AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Mortgage Broker 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(3000);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("248");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(4000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Credit Report", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Credit Report to Midwest Financial Group $7,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394704_NO_42()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MORTGAGE BROKER CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS POC-L AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Mortgage Broker 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(4000);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("248");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(4000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Appraisal Fee", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Appraisal Fee to Midwest Financial Group $7,500.00 P.O.C. Lender".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394705_NO_43()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MORTGAGE BROKER CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS POC-MB AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Mortgage Broker 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("248");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(4000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Credit Report", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Credit Report to Midwest Financial Group $7,500.00 P.O.C. MB".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394706_NO_44()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MORTGAGE BROKER CHARGE IN SECTION N  HAVING  AMOUNT IN MULTIPLE METHOD";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Charges in Mortgage Broker 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("237");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("248");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(4000);
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Credit Report", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("-2500");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("7500");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Credit Report to Midwest Financial Group $7,500.00 P.O.C. MB".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379148_TC_394707_NO_45()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY THE CHARGES IS PRESENT MAINTAINING SEQUENCE IN LINE NUMBERS N06,07,09 TO 13";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                CreateBuyerSellerBroker();
                //
                //
                Reports.TestStep = "Creating Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.SwitchToContentFrame();
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("10000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("10000");
                Keyboard.SendKeys("^S");
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                Playback.Wait(5000);
                this.PayOfflFindGABCode("237");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(6000);
                FastDriver.BottomFrame.New();
                Playback.Wait(6000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                Keyboard.SendKeys("^D");
                //FastDriver.PayoffLoanDetails.SwitchToBottomFrame();
                //FastDriver.BottomFrame.Done();
                Playback.Wait(7000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                //this.PayOfflFindGABCode("248");
                Playback.Wait(4000);
                this.LoadPayoffLoanChargesTab();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                //FastDriver.NewLoan.UpdateCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                //FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Charge", TableAction.SetText, "5000");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000", sellerCredit: "1000", SellerCreditPaymentMethod: "At Closing");
                //FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                //FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                ////  FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000");
                //FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000");
                //FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                //FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                //FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("1000");
                //FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("At Closing");
                //FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                //FastDriver.DialogBottomFrame.btnDone.FAClick();
                //Playback.Wait(250);
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Creating Charges in HOA Screen";
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("248");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, chargeDescription: "Lien Payoff",sellerCharge: 6000);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("6000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //Keyboard.SendKeys("D");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous");
                FastDriver.AdjustmentMisc.SwitchToContentFrame();
                this.UpdateCharge(FastDriver.AdjustmentMisc, FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, chargeDescription: "Buyer Deposit Directly to Seller", sellerCharge: 7000);
                //FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", "Buyer Deposit Directly to Seller", "Seller Charge", TableAction.SetText, "7000");
                // FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Done();
                Playback.Wait(2500);
                
                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                //FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("248");
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, chargeDescription: "Tax Installment: Amount",sellerCharge: 5000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                //FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", "Tax Installment: Amount", "Seller Charge", TableAction.SetText, "5000.50");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                // FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //Keyboard.SendKeys("D");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                Playback.Wait(250);
                FastDriver.NewLoan.SwitchToContentFrame();
                //FastDriver.NewLoan.WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "Principal Reduction Payment", sellerCharge: 8000);
                //FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", "Principal Reduction Payment", "Seller Charge", TableAction.SetText, "8000");
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("8000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //Keyboard.SendKeys("D");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //
                //(DONE)TODO:Use Yeury's method to add a new charge (Document Fee). This step can be found on line 6085 of the original FATAF Script.



                Reports.TestStep = "Creating Charges in 2nd New Loan and Mortgage Broker Charges";
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                //if (!this.chargeAvailability("tNL_tLC_NLC_cgLC_dcs", "Adhoc charge"))
                //{
                //    IWebElement table = FastDriver.WebDriver.FindElement(By.Id("tNL_tLC_NLC_cgLC_dcs"));
                //    this.AddCharge(FastDriver.NewLoan, table, "Document Preparation Fee", null, null, 5000, null, null);
                //}
                //else
                //{
                    this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: "Document Preparation Fee", sellerCharge: 5000);
                    //FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Document Preparation Fee", "Seller Charge", TableAction.SetText, "5000");
                //}
                //FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Document Preparation Fee", "Seller Charge",TableAction.SetText,"5000");
                Playback.Wait(500);
                FastDriver.NewLoan.SwitchToContentFrame();
                //FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.FAClick();
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Playback.Wait(250);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(250);
                //FastDriver.NewLoan.WaitForScreenToLoad();
                //Playback.Wait(4000);  
                FastDriver.NewLoan.SwitchToContentFrame();
                Playback.Wait(200);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription:"Credit Report",sellerCharge: 6000);
               
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                // FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("6000");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("6000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the records in Section N";
                Playback.Wait(250);
                this.ClickOnSummaryOftrans();
                //06
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Disbursed as Proceeds ($10,000.00)".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionN06_Amt.Exists().ToString());
                //07
                FastDriver.ClosingDisclosure.SectionN07_Seqno.FAClick();
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                //fix labels
                //Playback.Wait(110000000);
                Support.AreEqual("Statement/Forwarding Fee to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$4,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                //09
                FastDriver.ClosingDisclosure.SectionN09_Seqno.FAClick();
                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionN09_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Lien Payoff to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN09_Label.GetAttribute("title").Clean());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionN09_Amt.Text.Trim());
                //10
                FastDriver.ClosingDisclosure.SectionN10_Seqno.FAClick();
                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionN10_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Buyer Deposit Directly to Seller".Clean(), FastDriver.ClosingDisclosure.SectionN10_Label.GetAttribute("title").Clean());
                Support.AreEqual("$7,000.00", FastDriver.ClosingDisclosure.SectionN10_Amt.Text.Trim());
                //11
                FastDriver.ClosingDisclosure.SectionN11_Seqno.FAClick();
                Support.AreEqual("11", FastDriver.ClosingDisclosure.SectionN11_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Tax Installment: Amount to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN11_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN11_Amt.Text.Trim());
                //12
                FastDriver.ClosingDisclosure.SectionN12_Seqno.FAClick();
                Support.AreEqual("12", FastDriver.ClosingDisclosure.SectionN12_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("New Loan 2 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN12_Label.GetAttribute("title").Clean());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.SectionN12_Amt.Text.Trim());
                //13
                FastDriver.ClosingDisclosure.SectionN13_Seqno.FAClick();
                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("title").Clean());
                Support.AreEqual("$8,000.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Trim());

                this.Done();

            }
            catch (Exception e)
            {
                FailTest(e.Message);

            }
        }
        #endregion

        #region 379150: CD SCREEN – SECTION N: DISPLAY ASTERISK FOR CHARGE GROUPS.

        [TestMethod]
        public void FEA_5_US_379150_TC_393969_01()
        {//Green
            try
            {
                Reports.TestDescription = "DISPLAY ASTERISK FOR CHARGE GROUPS DESCRIPTION HOA LIEN PAYOFF IN LINE N06";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in HomeownerAssociation Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText("248");
                FastDriver.HomeownerAssociation.Find.FAClick();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 12345678910.12);
                //FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "12345678910.12");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("12345678910.12");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                //Keyboard.SendKeys("D");
                Playback.Wait(250);
                //Keyboard.SendKeys("N");
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Playback.Wait(250);

               // if (!this.chargeAvailability("cgHOA_dcs", "Adhoc charge"))
                //{
                    //IWebElement table = FastDriver.WebDriver.FindElement(By.Id("cgHOA_dcs"));
                this.AddCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Adhoc charge", null, null, 1000.50, null, null);
                //}
                //else
                //{
                //    this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Adhoc charge", sellerCharge: 1000.50);
                //    //FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Adhoc charge", "Seller Charge", TableAction.SetText, "1000.50");
                //}

                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("1000.50");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                //DONE fix labels
                Support.AreEqual("HOA Lien Payoff Charges".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Trim());
                Support.AreEqual("$345,679,910.62", FastDriver.ClosingDisclosure.SectionN06_Amt.Text);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Creating Charges in HomeownerAssociation Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "0");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();


                this.ClickOnSummaryOftrans();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Adhoc charge to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$1,000.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FEA_5_US_379150_TC_393995_02()
        {//Green
            try
            {
                Reports.TestDescription = "DISPLAY ASTERISK FOR CHARGE GROUP DESCRIPTION PROPERTY TAXS IN LINE N06  ";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("248");
                Playback.Wait(1000);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, chargeDescription: "Tax Installment: Interest Due",sellerCharge: 125);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("125");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("125");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.AdditionalChargesTable, chargeDescription: "County Tax", sellerCharge: 125);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"125");
                FastDriver.BottomFrame.Done();

                // 
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.ClickOnSummaryOftrans();
                //fix labels
                Support.AreEqual("* Property Taxes", FastDriver.ClosingDisclosure.SectionN06_Label.Text.Clean());
                Support.AreEqual("$250.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("248");

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.AdditionalChargesTable.PerformTableAction("Description", "County Tax", "Seller Charge", TableAction.SetText, "0");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                this.ClickOnSummaryOftrans();
                //fix labels
                Support.AreEqual("Tax Installment: Interest Due to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$125.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FEA_5_US_379150_TC_394002_03()
        {//Green
            try
            {
                Reports.TestDescription = "DISPLAY ASTERISK FOR CHARGE GROUP DESCRIPTION NEW LOAN 1 CHARGES IN LINE N06";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 1 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("248");
                Playback.Wait(1000);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "Principal Reduction Payment",sellerCharge: 125);
               // FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", "Principal Reduction Payment", "Seller Charge", TableAction.SetText, "125");
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("125");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "Construction Holdback", sellerCharge: 12345678910.12);
                //FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", "Construction Holdback", "Seller Charge", TableAction.SetText, "12345678910.12");
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("12345678910.12");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                this.ClickOnSummaryOftrans();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("New Loan 1 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$345,679,035.12", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "Principal Reduction Payment", sellerCharge: 0);

                //FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", "Principal Reduction Payment", "Seller Charge", TableAction.SetText, "0");
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //
                // 
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                this.ClickOnSummaryOftrans();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                //fix labels
                Support.AreEqual("Construction Holdback to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FEA_5_US_379150_TC_394004_04()
        {
            try
            {
                Reports.TestDescription = "DISPLAY ASTERISK FOR CHARGE GROUP DESCRIPTION NEW LOAN 2 CHARGES IN LINE N06";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Set charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.NewLoan.FindGABCode("248");
                Playback.Wait(1000);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: "Document Preparation Fee",sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("5000");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                //To be continued in Line 6578
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                this.ClickOnMortageTab();
                this.MortgageGABCodeFind("248");
                Playback.Wait(250);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Credit Report", sellerCharge: 6000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "6000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                this.ClickOnSummaryOftrans();
                //this.ValidateN06("06", "*  New Loan 2 Charges", "$11,000.00");
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("*  New Loan 2 Charges", FastDriver.ClosingDisclosure.SectionN06_Label.Text.Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());

                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad().SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Midwest Financial Group", "Name", TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Credit Report", sellerCharge: 0);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(SellerCharge: "0", PaidbySellerAtClosing: "0", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                this.ClickOnSummaryOftrans();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Document Preparation Fee to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionN06_Label.Text.Clean());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                
                //this.ValidateN06("","06", "Document Preparation Fee to Midwest Financial Group", "$5,000.00");
                this.Done();

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }

        #endregion

        #region 379155 : CD SCREEN – SECTION N: DISPLAY SUPPLEMENTAL SUMMARY LINE IN SECTION N.

        [TestMethod]
        public void FEA_5_US_379155_TC_393633_NO_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE DESCRIPTION SUPPLEMENTAL SUMMARY IN LINE NO.13 CD SCREEN N SECTION.";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Navigate to Closing Disclosure Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Order Entry>Escrow Closing>Closing Disclosure");

                //
                //
                Reports.TestStep = "Creating four Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                FastDriver.BottomFrame.Save();

                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad().SwitchToContentFrame();
                //IWebElement table = FastDriver.WebDriver.FindElement(By.Id("CG_dcs"));
                this.AddCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, "EFGH", sellerCredit: 100);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                //Playback.Wait(10000000);
                this.AddCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, "ABCD", sellerCredit: 200);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                this.AddCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, "123Bcharge 2", sellerCredit: 300);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                this.AddCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, "*@##$adhoc Charge 3", sellerCredit: 400);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                this.AddCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, "acbcd", sellerCredit: 500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                Playback.Wait(7000);

                //
                //
                Reports.TestStep = "NAVIGATE TO MISCELLANEOUS SCREEN AND ENTER SELLER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad().SwitchToContentFrame();
                // IWebElement table2 = FastDriver.WebDriver.FindElement(By.Id("CG_dcs"));

                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Adhoc charge", sellerCredit: 600);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway); 
                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.AdjustmentOffset.offsetAdjustmentTable, "ABCD", sellerCredit: 200);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                this.ClickOnSummaryOftrans();

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionN13_Seqno.Exists().ToString());

                //fix labels
                Support.AreEqual("See attached page for additional information".Clean(), FastDriver.ClosingDisclosure.SectionN13_Label.Text.Clean());
                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("$800.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Trim());

                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion

        #region 379151 : CD SCREEN – SECTION N: VIEW DETAILS OF THE CHARGES THAT ARE PART OF THE CHARGE GROUP.
        [TestMethod]
        public void FEA_5_US_379151_TC_391371_NO_01()
        {
            try
            {
                Reports.TestDescription = "VIEW DETAILS OF THE CHARGES THAT ARE PART OF THE CHARGE GROUP IN HOA LIEN PAYOFF CHARGES LINE.";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                this.CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "CREATING CHARGES IN HOA INSTANCE 1 SCREEN.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association");
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 250.50);
                //FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "250.50");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "250.50", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0");

                //
                //
                Reports.TestStep = "Choosing Before closing amount in PDD";
                //IWebElement table = FastDriver.WebDriver.FindElement(By.Id("cgHOA_dcs"));
                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Adhoc Charge");
                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Adhoc Charge", sellerCharge: 5000);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2500", PaidbySellerBeforeClosing: "2500", PaidbySellerOthers: "0");

                //
                //
                Reports.TestStep = "Choosing Buyer Broker as payment method  in PDD";
               
                //FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Adhoc Charge", "Seller Charge", TableAction.SetText, "5000");
                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Adhoc Charge", sellerCharge: 5000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.HomeownerAssociation.HOALienPayOffTable, "ABCD");
                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.HomeownerAssociation.HOALienPayOffTable, "ABCD",sellerCharge: 5000);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2500", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "2500", SellerPaidbyOthersPaymentMethod: "Buyer Broker");
                FastDriver.BottomFrame.Done();
                
                //
                //
                Reports.TestStep = "CREATING CHARGES IN HOA INSTANCE 2 SCREEN.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                //FastDriver.HomeownerAssociation.
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("314");
                Playback.Wait(2000);

                //
                //
                Reports.TestStep = "Editing charge description and Payee Name along with Choosing POC as payment method  in PDD";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                //Playback.Wait(10000);
                FastDriver.HomeownerAssociation.WaitCreation(FastDriver.HomeownerAssociation.HOALienPayOffTable, 10);
                //FastDriver.HomeownerAssociation.WaitElementDisplayed("cgHOA_dcs", 10);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable,"Lien Payoff",sellerCharge: 2000);
                //FastDriver.HomeownerAssociation.HOALienPayOffTable.PerformTableAction("Description", "Lien Payoff", "Seller Charge", TableAction.SetText, "2000");
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                //FastDriver.PaymentDetailsDlg.DESCRPTION.FASetText("XYZA");
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-1000", PaidbySellerBeforeClosing: "1000", PaidbySellerOthers: "2000", SellerPaidbyOthersPaymentMethod: "POC", description: "XYZA", useDefault: "False", payeeName: "FAI");

                //
                //
                Reports.TestStep = " Choosing Seller Broker as payment method  in PDD";//line 6882
                //IWebElement table2 = FastDriver.WebDriver.FindElement(By.Id("cgHOA_dcs"));
                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Adhoc charge", sellerCharge: 1000);
                //FastDriver.TableCharges.Enter(FastDriver.HomeownerAssociation.HOALienPayOffTable, "", sellerCharge: 1000.00, addNewRow: true);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "500", PaidbySellerBeforeClosing: "", PaidbySellerOthers: "500", SellerPaidbyOthersPaymentMethod: "Seller Broker");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                this.ClickOnSummaryOftrans();
                Support.AreEqual("HOA Lien Payoff Charges".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$4,750.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.ClosingDisclosure.N06Plus.FAClick();
                //
                //
                Reports.TestStep = "Verify the popup values.";
                Support.AreEqual("Seller Charges", FastDriver.CDN06Popup.N06Label.Text.Trim());
                Support.AreEqual("06", FastDriver.CDN06Popup.N06SeqNo.Text.Trim());
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.CDN06Popup.N06Description.Text.Trim());
                Support.AreEqual("$4,750.50", FastDriver.CDN06Popup.N06Amt.Text.Trim());
                Support.AreEqual("Lien Payoff to Associated Great Northern Mortgage Co.", FastDriver.CDN06Popup.N06ChargeDesc1.Text.Trim());
                Support.AreEqual("$250.50", FastDriver.CDN06Popup.N06ChargeAmt1.Text.Trim());
                Support.AreEqual("Adhoc Charge to Associated Great Northern Mortgage Co. $2,500.00 P.O.C. Seller", FastDriver.CDN06Popup.N06ChargeDesc2.Text.Trim());
                Support.AreEqual("$2,500.00", FastDriver.CDN06Popup.N06ChargeAmt2.Text.Trim());
                Support.AreEqual("ABCD to Associated Great Northern Mortgage Co. $2,500.00 P.O.C. Buyer Broker", FastDriver.CDN06Popup.N06ChargeDesc3.Text.Trim());
                Support.AreEqual("$2,500.00", FastDriver.CDN06Popup.N06ChargeAmt3.Text.Trim());
                Support.AreEqual("XYZA to FAI $3,000.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc4.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.CDN06Popup.N06ChargeAmt4.Text.Trim());
                Support.AreEqual("Adhoc charge to Smythe & Lee Jerome E. Lee $500.00 P.O.C. Seller Broker", FastDriver.CDN06Popup.N06ChargeDesc5.Text.Trim());
                Support.AreEqual("$500.00", FastDriver.CDN06Popup.N06ChargeAmt5.Text.Trim());

                FastDriver.CDN06Popup.Done.FAClick();
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FEA_5_US_379151_TC_393217_NO_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY  FIRST AND SECOND PROPERTY TAX CHECK INSTANCE CHARGES IN SECTION N LINE N06 POPUP";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                this.CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("314");
                Playback.Wait(4000);
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", sellerCharge: 250.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(SellerCharge: "250.50", PaidbySellerAtClosing: "250.50");

                //
                //
                Reports.TestStep = "Choosing Before closing amount in PDD";
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", sellerCharge: 12345678910.12);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(SellerCharge: "12345678910.12", PaidbySellerAtClosing: "0", PaidbySellerBeforeClosing: "12345678910.12", PaidbySellerOthers: "0");

                //
                //
                Reports.TestStep = "Editing charge description and Payee Name along with Choosing BUYER BROKER as payment method  in PDD";
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Penalty Due", sellerCharge: 5000);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(SellerCharge: "5000", description: "Description1", useDefault: "False", payeeName: "Payee Name1", PaidbySellerAtClosing: "-2500", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "Buyer Broker");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "CREATING CHARGES IN Property Tax Check INSTANCE 2 SCREEN.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.BottomFrame.New();
                Playback.Wait(4000);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("237");
                Playback.Wait(4000);
                this.UpdateCharge(FastDriver.PropertyTaxCheck,FastDriver.PropertyTaxCheck.AdditionalChargesTable,"City Tax", sellerCharge: 300);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "100", PaidbySellerBeforeClosing: "100", PaidbySellerOthers: "100", SellerPaidbyOthersPaymentMethod: "Seller Broker");

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", sellerCharge: 200);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "100", PaidbySellerOthers: "100", SellerPaidbyOthersPaymentMethod: "Seller Broker");

                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                this.ClickOnSummaryOftrans();
                Support.AreEqual("*  Property Taxes".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.Text.Clean());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.N06Plus.Exists().ToString());
                Support.AreEqual("-$2,049.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.ClosingDisclosure.N06Plus.FAClick();
                //
                //
                Reports.TestStep = "Verify the popup values.";
                Support.AreEqual("Seller Charges", FastDriver.CDN06Popup.N06Label.Text.Trim());
                Support.AreEqual("06", FastDriver.CDN06Popup.N06SeqNo.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.CDN06Popup.N06Description.Text.Trim());
                Support.AreEqual("-$2,049.50", FastDriver.CDN06Popup.N06Amt.Text.Trim());
                Support.AreEqual("a", FastDriver.CDN06Popup.N06SeqNo1.Text.Trim());
                Support.AreEqual("Property Taxes 1", FastDriver.CDN06Popup.N06ChargeDesc1.Text.Trim());
                Support.AreEqual("-$2,249.50", FastDriver.CDN06Popup.N06TotalChargeAmt1.Text.Trim());
                Support.AreEqual("Tax Installment: Interest Due to Smythe & Lee Jerome E. Lee", FastDriver.CDN06Popup.N06ChargeDesc2.Text.Trim());
                Support.AreEqual("$250.50", FastDriver.CDN06Popup.N06ChargeAmt2.Text.Trim());
                Support.AreEqual("Tax Installment: Amount to Smythe & Lee Jerome E. Lee $345,678,910.12 P.O.C. Seller", FastDriver.CDN06Popup.N06ChargeDesc3.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1 $7,500.00 P.O.C. Buyer Broker", FastDriver.CDN06Popup.N06ChargeDesc4.Text.Trim());
                Support.AreEqual("-$2,500.00", FastDriver.CDN06Popup.N06ChargeAmt4.Text.Trim());
                Support.AreEqual("b", FastDriver.CDN06Popup.N06SeqNo5.Text.Trim());
                Support.AreEqual("Property Taxes 2", FastDriver.CDN06Popup.N06ChargeDesc5.Text.Trim());
                Support.AreEqual("$200.00", FastDriver.CDN06Popup.N06TotalChargeAmt5.Text.Trim());
                Support.AreEqual("City Tax to Associated Great Northern Mortgage Co. $200.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc6.Text.Trim());
                Support.AreEqual("$100.00", FastDriver.CDN06Popup.N06ChargeAmt6.Text.Trim());
                Support.AreEqual("County Tax to Associated Great Northern Mortgage Co. $100.00 P.O.C. Seller Broker", FastDriver.CDN06Popup.N06ChargeDesc7.Text.Trim());
                Support.AreEqual("$100.00", FastDriver.CDN06Popup.N06ChargeAmt7.Text.Trim());

                FastDriver.CDN06Popup.Done.FAClick();
                this.Done();



            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FEA_5_US_379151_TC_393239_NO_03()
        {
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN 1 INSTANCE(PRINCIPAL REDUCTION/CONSTRUCTION HOLDBACK) CHARGES IN SECTION N LINE N06 POP UP .";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 1 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("314");
                Playback.Wait(1000);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                //Principal Reduction Payment"
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable,"Principal Reduction Payment", sellerCharge: 3000);

                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
               // FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "0", description: "ABCD", useDefault: "False", payeeName: "FIRST AMERICA", PaidbySellerBeforeClosing: "2000", PaidbySellerOthers: "1000", SellerPaidbyOthersPaymentMethod: "POC-MB");

                //Construction holdback"
                //FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCharge: 12345678910.12);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing:"0",PaidbySellerBeforeClosing: "12345678910.12",PaidbySellerOthers:"0");

                //BCDE"
                this.AddCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "BCDE", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2500",  PaidbySellerOthers: "2500", PaidbySellerBeforeClosing:"0",SellerPaidbyOthersPaymentMethod: "POC");
                //Playback.Wait(100000000);
                //Keyboard.SendKeys(FAKeys.TabAway);
                //Keyboard.SendKeys(FAKeys.TabAway);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "BCDE", sellerCharge: 5000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                //XYZA"
                this.AddCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "XYZA", sellerCharge: 1000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "500", PaidbySellerOthers: "500", SellerPaidbyOthersPaymentMethod: "POC-L");
               // this.AddCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "XYZA", sellerCharge: 1000);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable,"XYZA",sellerCharge:1000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);

                ////Keyboard.SendKeys(FAKeys.TabAway);
                ////Keyboard.SendKeys(FAKeys.TabAway);
                //Description 1"
                this.AddCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "Description 1", sellerCharge: 2500);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "1500", PaidbySellerBeforeClosing:"0",PaidbySellerOthers: "1000", SellerPaidbyOthersPaymentMethod: "POC-MB");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                this.ClickOnSummaryOftrans();
                Support.AreEqual("*  New Loan 1 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.Text.Clean());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.N06Plus.Exists().ToString());
                Support.AreEqual("$4,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.ClosingDisclosure.N06Plus.FAClick();
                //
                //
                Reports.TestStep = "Verify the popup values.";
                Support.AreEqual("Seller Charges", FastDriver.CDN06Popup.N06Label.Text.Trim());
                Support.AreEqual("06", FastDriver.CDN06Popup.N06SeqNo.Text.Trim());
                Support.AreEqual("New Loan 1 Charges", FastDriver.CDN06Popup.N06Description.Text.Trim());
                Support.AreEqual("$4,500.00", FastDriver.CDN06Popup.N06Amt.Text.Trim());
                Support.AreEqual("ABCD to FIRST AMERICA $3,000.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc1.Text.Trim());
                Support.AreEqual("Construction Holdback to Smythe & Lee Jerome E. Lee $345,678,910.12 P.O.C. Seller", FastDriver.CDN06Popup.N06ChargeDesc2.Text.Trim());
                //Support.AreEqual("$250.50", FastDriver.CDN06Popup.N06ChargeAmt2.Text.Trim());
                Support.AreEqual("BCDE to Smythe & Lee Jerome E. Lee $2,500.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc3.Text.Trim());
                Support.AreEqual("$2,500.00", FastDriver.CDN06Popup.N06ChargeAmt3.Text.Trim());
                Support.AreEqual("XYZA to Smythe & Lee Jerome E. Lee $500.00 P.O.C. Lender", FastDriver.CDN06Popup.N06ChargeDesc4.Text.Trim());
                Support.AreEqual("$500.00", FastDriver.CDN06Popup.N06ChargeAmt4.Text.Trim());
                //Support.AreEqual("b", FastDriver.CDN06Popup.N06SeqNo5.Text.Trim());
                Support.AreEqual("Description 1 to Smythe & Lee Jerome E. Lee $1,000.00 P.O.C. MB", FastDriver.CDN06Popup.N06ChargeDesc5.Text.Trim());
                Support.AreEqual("$1,500.00", FastDriver.CDN06Popup.N06ChargeAmt5.Text.Trim());


                FastDriver.CDN06Popup.Done.FAClick();
                this.Done();



            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void FEA_5_US_379151_TC_393243_NO_04()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN 2 INSTANCE (NEW LOAN 2 AND MORTGAGE BROKER 2 SCREEN) CHARGES IN SECTION N LINE N06 POP UP.";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 and Mortgage Broker 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("247");
                //Keyboard.SendKeys("^D");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.BottomFrame.New();
                //Keyboard.SendKeys("^N");
                Playback.Wait(4000);
                FastDriver.NewLoan.FindGABCode("314");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                //Lender's Inspection Fee"
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Lender's Inspection Fee", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "ABCD", useDefault: "False", payeeName: "FIRST AMERICA", PaidbySellerAtClosing: "-1000", PaidbySellerBeforeClosing: "3000", PaidbySellerOthers: "3000", SellerPaidbyOthersPaymentMethod: "POC-MB");

                //Tax Service Contract""
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Tax Service Contract", sellerCharge: 12345678910.12);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "12345678910.12", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0");

                //Document Preparation Fee
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Document Preparation Fee", sellerCharge: 5250.50);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000", PaidbySellerBeforeClosing: "250.50", PaidbySellerOthers: "0");

                //*****Mortgage Tab****
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                this.MortgageGABCodeFind("248");

                //Credit Report
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", sellerCharge: 4000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "2000", SellerPaidbyOthersPaymentMethod: "POC");

                //Appraisal Fee
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", sellerCharge: 1000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "500", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "500", SellerPaidbyOthersPaymentMethod: "POC-L");

                //BCDE (Added Charge)
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "BCDE", sellerCharge: 2500);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "1000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "1500", SellerPaidbyOthersPaymentMethod: "POC-MB");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = " Navigate to ClosingDisclosure screen and verify.";

                this.ClickOnSummaryOftrans();
                Support.AreEqual("*  New Loan 2 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.Text.Clean());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.N06Plus.Exists().ToString());
                Support.AreEqual("$345,686,410.12", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.ClosingDisclosure.N06Plus.FAClick();

                //
                //
                Reports.TestStep = "Verify the popup values.";

                Support.AreEqual("Seller Charges", FastDriver.CDN06Popup.N06Label.Text.Trim());
                Support.AreEqual("06", FastDriver.CDN06Popup.N06SeqNo.Text.Trim());
                Support.AreEqual("New Loan 2 Charges", FastDriver.CDN06Popup.N06Description.Text.Trim());
                Support.AreEqual("$345,686,410.12", FastDriver.CDN06Popup.N06Amt.Text.Trim());
                //The original test(CodedUI based) had this: "ABCD to Smythe & Lee Jerome E. Lee $6,000.00 P.O.C." instead of the string used below, seemed like a mistake on the test itself. 
                Support.AreEqual("ABCD to FIRST AMERICA $6,000.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc1.Text.Trim());
                Support.AreEqual("-$1,000.00", FastDriver.CDN06Popup.N06ChargeAmt1.Text.Trim());
                Support.AreEqual("Document Preparation Fee to Smythe & Lee Jerome E. Lee $250.50 P.O.C. Seller", FastDriver.CDN06Popup.N06ChargeDesc2.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.CDN06Popup.N06ChargeAmt2.Text.Trim());
                Support.AreEqual("Tax Service Contract to Smythe & Lee Jerome E. Lee", FastDriver.CDN06Popup.N06ChargeDesc3.Text.Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.CDN06Popup.N06ChargeAmt3.Text.Trim());
                Support.AreEqual("Appraisal Fee to Midwest Financial Group $500.00 P.O.C. Lender", FastDriver.CDN06Popup.N06ChargeDesc4.Text.Trim());
                Support.AreEqual("$500.00", FastDriver.CDN06Popup.N06ChargeAmt4.Text.Trim());
                Support.AreEqual("Credit Report to Midwest Financial Group $2,000.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc5.Text.Trim());
                Support.AreEqual("$2,000.00", FastDriver.CDN06Popup.N06ChargeAmt5.Text.Trim());
                Support.AreEqual("BCDE to Midwest Financial Group $1,500.00 P.O.C. MB", FastDriver.CDN06Popup.N06ChargeDesc6.Text.Trim());
                Support.AreEqual("$1,000.00", FastDriver.CDN06Popup.N06ChargeAmt6.Text.Trim());
                FastDriver.CDN06Popup.Done.FAClick();
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FEA_5_US_379151_TC_538445_NO_05()
        {
            try
            {
                Reports.TestDescription = "VERIFY PAY-OFF LOAN 3 INSTANCE CHARGES IN SECTION N LINE N06 POP UP.";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan 3 Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                Playback.Wait(4000);
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("314");
                Playback.Wait(3000);

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                // FastDriver.PayoffLoanDetails.WaitCreation(FastDriver.PayoffLoanCharges.ChargesTab,10);
                Playback.Wait(2000);

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 500);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "300", PaidbySellerBeforeClosing: "100", PaidbySellerOthers: "100", SellerPaidbyOthersPaymentMethod: "POC-L", sellerCredit: "100", SellerCreditPaymentMethod: "At Closing");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 200);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1", PaidbySellerAtClosing: "0", PaidbySellerBeforeClosing: "200", PaidbySellerOthers: "0", sellerCredit: "100", SellerCreditPaymentMethod: "At Closing");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Prepayment Penalty", sellerCharge: 300);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "0", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "300", sellerCredit: "100", SellerPaidbyOthersPaymentMethod: "POC", SellerCreditPaymentMethod: "At Closing");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Late Charges", sellerCharge: 400);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "200", PaidbySellerBeforeClosing: "100", PaidbySellerOthers: "100", sellerCredit: "300", SellerPaidbyOthersPaymentMethod: "POC", SellerCreditPaymentMethod: "At Closing");
                FastDriver.BottomFrame.Done();
                Reports.TestStep = " Navigate to ClosingDisclosure screen and verify.";

                this.ClickOnSummaryOftrans();
                Support.AreEqual("*  Payoff Loan 3 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.Text.Clean());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.ClosingDisclosure.N06Plus.FAClick();

                //
                //
                Reports.TestStep = "Verify the popup values.";

                Support.AreEqual("Seller Charges", FastDriver.CDN06Popup.N06Label.Text.Trim());
                Support.AreEqual("06", FastDriver.CDN06Popup.N06SeqNo.Text.Trim());
                Support.AreEqual("Payoff Loan 3 Charges", FastDriver.CDN06Popup.N06Description.Text.Trim());
                Support.AreEqual("$100.00", FastDriver.CDN06Popup.N06Amt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Smythe & Lee Jerome E. Lee $200.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc1.Text.Trim());
                Support.AreEqual("$200.00", FastDriver.CDN06Popup.N06ChargeAmt1.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1 $200.00 P.O.C. Seller", FastDriver.CDN06Popup.N06ChargeDesc2.Text.Trim());
                Support.AreEqual("Prepayment Penalty to Smythe & Lee Jerome E. Lee $300.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc3.Text.Trim());
                Support.AreEqual("-$100.00", FastDriver.CDN06Popup.N06ChargeAmt3.Text.Trim());
                Support.AreEqual("Late Charges to Smythe & Lee Jerome E. Lee $200.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc4.Text.Trim());
                Support.AreEqual("$100.00", FastDriver.CDN06Popup.N06ChargeAmt4.Text.Trim());
                FastDriver.CDN06Popup.Done.FAClick();
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void FEA_5_US_379151_TC_538447_NO_06()
        {
            try
            {
                Reports.TestDescription = "VERIFY PAY-OFF LOAN 3 INSTANCE CHARGES IN SECTION N LINE N06 POP UP.";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan 3 Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                Playback.Wait(4000);
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("314");
                Playback.Wait(3000);

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                // FastDriver.PayoffLoanDetails.WaitCreation(FastDriver.PayoffLoanCharges.ChargesTab,10);
                Playback.Wait(2000);

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 500);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "300", PaidbySellerBeforeClosing: "100", PaidbySellerOthers: "100", SellerPaidbyOthersPaymentMethod: "POC-L", sellerCredit: "100", SellerCreditPaymentMethod: "POC");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 200);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "200", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0", sellerCredit: "100", SellerCreditPaymentMethod: "POC");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Prepayment Penalty", sellerCharge: 300);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "0", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "300", sellerCredit: "100", SellerPaidbyOthersPaymentMethod: "POC-L", SellerCreditPaymentMethod: "POC");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Late Charges", sellerCharge: 100);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "50", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "50", sellerCredit: "300", SellerPaidbyOthersPaymentMethod: "POC-L", SellerCreditPaymentMethod: "POC");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = " Navigate to ClosingDisclosure screen and verify.";

                this.ClickOnSummaryOftrans();
                Support.AreEqual("*  Payoff Loan 3 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.Text.Clean());
                Support.AreEqual("$550.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                FastDriver.ClosingDisclosure.N06Plus.FAClick();

                //
                //
                Reports.TestStep = "Verify the popup values.";

                Support.AreEqual("Seller Charges", FastDriver.CDN06Popup.N06Label.Text.Trim());
                Support.AreEqual("06", FastDriver.CDN06Popup.N06SeqNo.Text.Trim());
                Support.AreEqual("Payoff Loan 3 Charges", FastDriver.CDN06Popup.N06Description.Text.Trim());
                Support.AreEqual("$550.00", FastDriver.CDN06Popup.N06Amt.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Smythe & Lee Jerome E. Lee $200.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc1.Text.Trim());
                Support.AreEqual("$300.00", FastDriver.CDN06Popup.N06ChargeAmt1.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Smythe & Lee Jerome E. Lee $100.00 P.O.C.", FastDriver.CDN06Popup.N06ChargeDesc2.Text.Trim());
                Support.AreEqual("$200.00", FastDriver.CDN06Popup.N06ChargeAmt2.Text.Trim());
                Support.AreEqual("Prepayment Penalty to Smythe & Lee Jerome E. Lee $300.00 P.O.C. Lender", FastDriver.CDN06Popup.N06ChargeDesc3.Text.Trim());
                Support.AreEqual("Late Charges to Smythe & Lee Jerome E. Lee $50.00 P.O.C. Lender", FastDriver.CDN06Popup.N06ChargeDesc4.Text.Trim());
                Support.AreEqual("$50.00", FastDriver.CDN06Popup.N06ChargeAmt4.Text.Trim());
                FastDriver.CDN06Popup.Done.FAClick();
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }


        }

        #endregion

        #region 379152- CD Screen – Section N: Ability to display charges that are part of a Charge group as Individual charges

        [TestMethod]
        public void US_379152_TC_406991_NO_01()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THIRD PAYOFF LOAN INSTANCE CHARGES IN SECTION N";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(2000);

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0", sellerCredit: "1000", SellerCreditPaymentMethod: "AT Closing");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0", sellerCredit: "1000", SellerCreditPaymentMethod: "AT Closing");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$4,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$4,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379152_TC_406993_NO_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THIRD, PAYOFF LOAN INSTANCE CHARGE WITH EDITED DESCRIPTION AND PAYEE NAME IN SECTION N";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(2000);

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 5000.50);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description2", useDefault: "False", payeeName: "EMPTY", PaidbySellerAtClosing: "5000.50", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0", sellerCredit: "1000", SellerCreditPaymentMethod: "AT Closing");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000.50);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1", PaidbySellerAtClosing: "5000.50", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0", sellerCredit: "1000", SellerCreditPaymentMethod: "AT Closing");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$4,000.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Description2".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$4,000.50", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379152_TC_406994_NO_03()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THIRD, PAYOFF LOAN INSTANCE CHARGE IN SECTION N HAVING SELLER BEFORE CLOSING AND SELLER PAID BY OTHERS POC-L AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(2000);

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "POC-L", sellerCredit: "1000", SellerCreditPaymentMethod: "AT Closing");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerBeforeClosing: "7500", PaidbySellerOthers: "0", sellerCredit: "1000", SellerCreditPaymentMethod: "AT Closing");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Midwest Financial Group $7,500.00 P.O.C. Seller".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$3,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Midwest Financial Group $7,500.00 P.O.C. Lender".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$3,500.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }

        }

        [TestMethod]
        public void US_379152_TC_406997_NO_06()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE PAYOFF OF THIRD MORTGAGE LOAN AMOUNT FROM MULTIPLE CHARGES IN DIFFERENT SECTION WITH SELLER CREDIT PAYMENT METHOD AS POC AND AT CLOSING IN SECTION N";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(2000);

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 3000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "3000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0", sellerCredit: "2000", SellerCreditPaymentMethod: "POC");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0", sellerCredit: "1000", SellerCreditPaymentMethod: "AT Closing");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$4,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Midwest Financial Group $2,000.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$3,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379152_TC_406998_NO_07()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  THIRD PAYOFF LOAN IN SECTION N AFTER DELETING SELLER CHARGE";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame(); ;
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(2000);

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0", sellerCredit: "1000", SellerCreditPaymentMethod: "AT Closing");

                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 5000);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000", PaidbySellerBeforeClosing: "0", PaidbySellerOthers: "0", sellerCredit: "1000", SellerCreditPaymentMethod: "AT Closing");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //
                //
                Reports.TestStep = "Deleting Seller Charges in Payoff Loan Screen";
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction(1, "3", 2, TableAction.Click);
                FastDriver.NewLoanSummary.Edit.FAClick();
                FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
                Playback.Wait(2000);
                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 0);
                this.UpdateCharge(pageObject: FastDriver.PayoffLoanCharges, chargesTable: FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 0);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$1,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Reconveyance Fee to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$1,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379152_TC_406999_NO_08()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  FIRST, SECOND AND  THIRD HOMEOWNER ASSOCIATION INSTANCE CHARGES IN SECTION N";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                this.CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in HOA Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 5000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //FastDriver.BottomFrame.New();
                Keyboard.SendKeys("^N");
                Playback.Wait(5000);

                FastDriver.HomeownerAssociation.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(2000);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 5000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.HomeownerAssociationSummary.SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.FindGABCode("248");
                Playback.Wait(4000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 5000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(2000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff to Associated Great Northern Mortgage Co.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionN09_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN09_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN09_Amt.Text.Trim());
                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379152_TC_407000_NO_09()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY HOMEOWNER ASSOCIATION INSTANCE CHARGES WITH EDITED PAYEE DESCRIPTION AND PAYEE NAME IN SECTION N";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                this.CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in HOA Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 5000);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1", PaidbySellerAtClosing: "5000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //FastDriver.BottomFrame.New();
                Keyboard.SendKeys("^N");
                Playback.Wait(5000);

                FastDriver.HomeownerAssociation.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(2000);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 6000);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description2", useDefault: "False", payeeName: "EMPTY", PaidbySellerAtClosing: "6000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Description2".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());

                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379152_TC_407002_NO_10()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY HOMEOWNER ASSOCIATION INSTANCE CHARGE IN SECTION N HAVING SELLER BEFORE CLOSING AMOUNT AND PAID BY OTHERS- BUYER BROKER AMOUNT";
                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                this.CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in HOA Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(1000);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 5000);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerBeforeClosing: "7500");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //FastDriver.BottomFrame.New();
                Keyboard.SendKeys("^N");
                Playback.Wait(5000);

                FastDriver.HomeownerAssociation.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(2000);
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 5000);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "Buyer Broker");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff to Midwest Financial Group $7,500.00 P.O.C. Buyer Broker".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());

                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379152_TC_407004_NO_12()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  FIRST, SECOND AND  THIRD PROPERTY TAX CHECK INSTANCE CHARGES IN SECTION N";

                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                this.CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("237");
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", sellerCharge: 5000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //FastDriver.BottomFrame.New();
                Keyboard.SendKeys("^N");
                Playback.Wait(5000);

                FastDriver.PropertyTaxCheck.FindGABCode("247");
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", sellerCharge: 5000.50);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.New.FAClick();
                Playback.Wait(2000);
                FastDriver.PropertyTaxCheck.FindGABCode("248");

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", sellerCharge: 5000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Amount to Associated Great Northern Mortgage Co.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("County Tax to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionN09_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Interest Due to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN09_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN09_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379152_TC_407005_NO_13()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MULTIPLE FIRST PROPERTY TAX CHECK INSTANCE CHARGE WITH EDITED DESCRIPTION AND PAYEE NAME  IN SECTION N";

                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                this.CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", sellerCharge: 5000);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1", PaidbySellerAtClosing: "5000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //FastDriver.BottomFrame.New();
                Keyboard.SendKeys("^N");
                Playback.Wait(5000);

                FastDriver.PropertyTaxCheck.FindGABCode("248");
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", sellerCharge: 6000);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description2", useDefault: "False", payeeName: "EMPTY", PaidbySellerAtClosing: "6000");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Description2".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());

                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379152_TC_407007_NO_15()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  FIRST PROPERTY TAX CHECK INSTANCE CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS SELLER BROKER AND POC AND MULTIPLE METHOD AMOUNT";
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                this.CreateBuyerSellerBroker();

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("247");
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", sellerCharge: 5000);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "POC");
                //FastDriver.BottomFrame.New();

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.AdditionalChargesTable, "City Tax", sellerCharge: 5000);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "Seller Broker");
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", sellerCharge: 6000);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerBeforeClosing: "500", PaidbySellerOthers: "8000", SellerPaidbyOthersPaymentMethod: "Buyer Broker");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Interest Due to Lenders Advantage A Division Of First American Title Ins. $8,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Amount to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionN09_Seqno.Text.Trim());
                Support.AreEqual("City Tax to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller Broker".Clean(), FastDriver.ClosingDisclosure.SectionN09_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN09_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379152_TC_407008_NO_16()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  PRINCIPAL REDUCTION/CONSTRUCTION HOLD BACK  CHARGES IN SECTION N06";
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";

                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCharge: 5000.50);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000.50");
                //FastDriver.BottomFrame.New();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCharge: 5000.50);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000.50");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Construction Holdback to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379152_TC_407009_NO_17()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  PRINCIPAL REDUCTION/Construction Holdback  CHARGE WITH EDITED DESCRIPTION AND PAYEE NAME IN SECTION N06";
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";

                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCharge: 5000.50);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1", PaidbySellerAtClosing: "5000.50");
                //FastDriver.BottomFrame.New();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCharge: 5000.50);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description2", useDefault: "False", payeeName: "EMPTY", PaidbySellerAtClosing: "5000.50");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Description2".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.50", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception)
            {

                throw;
            }
        }

        [TestMethod]
        public void US_379152_TC_407011_NO_19()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY PRINCIPAL REDUCTION/Construction Holdback CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS -LENDER AND MB AMOUNT";
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";

                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "POC-L");

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "POC-MB");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group $7,500.00 P.O.C. Lender".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Construction Holdback to Midwest Financial Group $7,500.00 P.O.C. MB".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379152_TC_407013_NO_21()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  NEW LOAN AND MORTGAGE BROKER SECOND INSTANCE  CHARGES IN SECTION N";
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan Screen";

                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, "Document Preparation Fee", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000");

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, "Tax Service Contract", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000");

                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(4000);

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", sellerCharge: 6000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "6000");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Document Preparation Fee to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Tax Service Contract to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionN09_Seqno.Text.Trim());
                Support.AreEqual("Credit Report to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionN09_Label.GetAttribute("title").Clean());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionN09_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379152_TC_407014_NO_22()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY SECOND NEW LOAN AND MORTGAGE CHARGES WITH EDITED DESCRIPTION AND PAYEE NAME IN SECTION N";
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 and Mortgage Broker 2 Screen";


                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, "Document Preparation Fee", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description1", useDefault: "False", payeeName: "Payee Name1", PaidbySellerAtClosing: "5000");


                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(4000);

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", sellerCharge: 6000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "Description2", useDefault: "False", payeeName: "EMPTY", PaidbySellerAtClosing: "6000");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Description1 to Payee Name1".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Description2".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception)
            {

                throw;
            }
        }

        [TestMethod]
        public void US_379152_TC_407015_NO_23()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY  NEW LOAN CHARGE IN SECTION N HAVING SELLER BEFORE CLOSING  AND PAID BY OTHERS- POC AMOUNT";
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 Screen";


                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, "Tax Service Contract", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerBeforeClosing: "7500");

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, "Flood Certification", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerBeforeClosing: "7500", SellerPaidbyOthersPaymentMethod: "POC");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Tax Service Contract to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Flood Certification to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C. Seller".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379152_TC_407018_NO_26()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY MORTGAGE BROKER CHARGE IN SECTION N HAVING SELLER PAID BY OTHERS POC-L AND POC-MB AMOUNT";
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in Mortgage Broker 2 Screen";

                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(5000);

                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("248");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(4000);

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", sellerCharge: 5000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "POC-L");

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", sellerCharge: 5000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerOthers: "7500", SellerPaidbyOthersPaymentMethod: "POC-MB");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Appraisal Fee to Midwest Financial Group $7,500.00 P.O.C. MB".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Credit Report to Midwest Financial Group $7,500.00 P.O.C. Lender".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379152_TC_407019_NO_27()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFY NEW LOAN AND MORTGAGE BROKER CHARGE IN SECTION N  HAVING  AMOUNT IN MULTIPLE METHOD";
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 Screen";


                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("237");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, "Flood Certification", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerBeforeClosing: "500", PaidbySellerOthers: "7000", SellerPaidbyOthersPaymentMethod: "POC-MB");

                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("248");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(4000);

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", sellerCharge: 6000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "-2500", PaidbySellerBeforeClosing: "500", PaidbySellerOthers: "8000", SellerPaidbyOthersPaymentMethod: "POC-MB");

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.SectionN06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.SectionN06_gtr_icon.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
                Support.AreEqual("Flood Certification to Lenders Advantage A Division Of First American Title Ins. $7,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionN07_Seqno.Text.Trim());
                Support.AreEqual("Appraisal Fee to Midwest Financial Group $8,500.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionN07_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$2,500.00", FastDriver.ClosingDisclosure.SectionN07_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion

        #region 379156 CD SCREEN - SECTION N: SUPPLEMENTAL CHARGES FOR SECTION N.

        [TestMethod]
        public void US_379156_TC_404527_NO_01()
        {
            try
            {
                Reports.TestDescription = "SHARED STEPS - LOGIN,CREATE BASIC FILE";

                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();

                //
                //
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                Keyboard.SendKeys("^S");
                Playback.Wait(3000);

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.BottomFrame.New();
                Playback.Wait(4000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(4000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();


                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "50", PaidbySellerOthers: "75", SellerPaidbyOthersPaymentMethod: "POC-L", sellerCredit: "100", SellerCreditPaymentMethod: "At Closing");
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 250);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "100", PaidbySellerBeforeClosing: "50", PaidbySellerOthers: "100", SellerPaidbyOthersPaymentMethod: "POC-L", sellerCredit: "50", SellerCreditPaymentMethod: "At Closing");
                Playback.Wait(3000);

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Reconveyance Fee", sellerCharge: 200);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "200");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                Playback.Wait(3000);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information".Clean(), FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("title").Clean());
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Trim());
                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Trim());
                Support.AreEqual("Statement/Forwarding Fee to Lenders Advantage A Division Of First American Title Ins. $75.00 P.O.C. Lender".Clean(), FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("title").Clean());
                Support.AreEqual("-$50.00", FastDriver.ClosingDisclosure.SectionN13a_Amt.Text.Trim());

                Support.AreEqual("Payoff Loan 9 Charges".Clean(), FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("title").Clean());
                Support.AreEqual("$250.00", FastDriver.ClosingDisclosure.SectionNSupSubN02_Amt.Text.Trim());

                Support.AreEqual("Statement/Forwarding Fee to Midwest Financial Group $150.00 P.O.C.".Clean(), FastDriver.ClosingDisclosure.SectionNSupN03_Label.GetAttribute("title").Clean());
                Support.AreEqual("$50.00", FastDriver.ClosingDisclosure.SectionNSupN03_Amt.Text.Trim());

                Support.AreEqual("Reconveyance Fee to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionNSupN04_Label.GetAttribute("title").Clean());
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.SectionNSupN04_Amt.Text.Trim());

                this.Done();

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379156_TC_404582_NO_02()
        {//Red Label
            try
            {
                Reports.TestStep = "Login to file side";
                this.Login();
                //
                //
                Reports.TestStep = "Create basic file with WCF";
                this.CreateFileWithWCF();
                //this.CreateQuickFileEntry("214", "", true, true, "Residential", "Accommodation", string.Empty, string.Empty, string.Empty, "CA", "Orange", string.Empty, false);
                //Playback.Wait(100000000);
                //
                //
                Reports.TestStep = "Creating four Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                Keyboard.SendKeys("^S");
                // FastDriver.BottomFrame.Save();
                Playback.Wait(3000);

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.BottomFrame.New();
                Playback.Wait(4000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(4000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();


                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                //
                //
                Reports.TestStep = "Creating Charges in HomeownerAssociation Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();

                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 12345678901.23);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "12345678901.23");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in HomeownerAssociation Screen";
                //FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association");
                Playback.Wait(5000);
                Keyboard.SendKeys("^N");
                Playback.Wait(5000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();

                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 1000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "1000.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                Playback.Wait(3000);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information".Clean(), FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("title").Clean());
                Support.AreEqual("$345,679,901.73", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Trim());
                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Trim());
                Support.AreEqual("HOA Lien Payoff Charges".Clean(), FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("title").Clean());
                Support.AreEqual("$345,679,901.73", FastDriver.ClosingDisclosure.SectionNsub13a_Amt.Text.Trim());

                Support.AreEqual("Lien Payoff to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("title").Clean());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionNSupSubN02_Amt.Text.Trim());

                Support.AreEqual("Lien Payoff to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionNSupN03_Label.GetAttribute("title").Clean());
                Support.AreEqual("$1,000.50", FastDriver.ClosingDisclosure.SectionNSupN03_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379156_TC_404583_NO_03()
        {//Green
            try
            {
                Reports.TestDescription = "SHARED STEPS - LOGIN,CREATE BASIC FILE";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();
                this.CreateQuickFileEntry("214", "", true, true, "Residential", "Accommodation", string.Empty, string.Empty, string.Empty, "CA", "Orange", string.Empty, false);
                this.CreateBuyerSellerBroker();
                //
                //
                Reports.TestStep = "Creating four Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(300);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(1000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(3000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(3000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(3000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(3000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                //here
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(3000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("248");

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", sellerCharge: 2000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2000.50");
                Playback.Wait(1000);

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", sellerCharge: 12345678910.12);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "12345677910.12", PaidbySellerOthers: "1000", SellerPaidbyOthersPaymentMethod: "Buyer Broker");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in HomeownerAssociation Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();

                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 1200.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "1200.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                Playback.Wait(3000);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information".Clean(), FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("title").Clean());
                Support.AreEqual("$345,681,111.12", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Trim());
                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("title").Clean());
                Support.AreEqual("$1,200.50", FastDriver.ClosingDisclosure.SectionN13a_Amt.Text.Trim());
                Support.AreEqual("13b", FastDriver.ClosingDisclosure.SectionNSupN02_Seqno.Text.Trim());

                Support.AreEqual("Property Taxes".Clean(), FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("title").Clean());
                Support.AreEqual("$345,679,910.62", FastDriver.ClosingDisclosure.SectionNSupSubN02_Amt.Text.Trim());
                Support.AreEqual("Property Taxes 1".Clean(), FastDriver.ClosingDisclosure.SectionNSupN03_Label.GetAttribute("title").Clean());
                Support.AreEqual("Tax Installment: Interest Due  to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN04_Label.Text.Trim());
                Support.AreEqual("$2,000.50", FastDriver.ClosingDisclosure.SectionNSupN04_Amt.Text.Trim());
                Support.AreEqual("County Tax to Midwest Financial Group $1,000.00 P.O.C. Buyer Broker".Replace(" ", ""), FastDriver.ClosingDisclosure.SectionNSupN05_Label.Text.Trim().Replace(" ", ""));
                Support.AreEqual("$345,677,910.12", FastDriver.ClosingDisclosure.SectionNSupN05_Amt.Text.Trim());
                this.Done();


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379156_TC_404585_NO_04()
        {//Green
            try
            {
                Reports.TestDescription = "SHARED STEPS - LOGIN,CREATE BASIC FILE";
                Reports.TestStep = "Login to file side";
                this.Login();
                this.CreateQuickFileEntry("214", "", true, true, "Residential", "Accommodation", string.Empty, string.Empty, string.Empty, "CA", "Orange", string.Empty, false);
                //this.CreateBuyerSellerBroker();
                //
                //
                Reports.TestStep = "Creating four Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                //Keyboard.SendKeys("^S");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(3000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                //here
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.NewLoan.ClickChargesTab();
                Playback.Wait(5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                Playback.Wait(5000);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2500", PaidbySellerOthers: "2500", SellerPaidbyOthersPaymentMethod: "POC");

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2500", PaidbySellerOthers: "2500", SellerPaidbyOthersPaymentMethod: "POC");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in 2nd New Loan and Mortgage Broker Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                Playback.Wait(5000);
                FastDriver.NewLoan.ClickChargesTab();
                Playback.Wait(6000);

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000");

                FastDriver.NewLoan.ClickMortgageBrokerTab();
                Playback.Wait(3000);
                this.MortgageGABCodeFind("247");

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", sellerCharge: 6000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "6000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                Playback.Wait(3000);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information".Clean(), FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("title").Clean());
                Support.AreEqual("$16,000.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Trim());

                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Trim());
                Support.AreEqual("New Loan 2 Charges".Clean(), FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("title").Clean());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.SectionNsub13a_Amt.Text.Trim());
                Support.AreEqual("Appraisal Fee to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("title").Clean());
                Playback.Wait(1000);
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionNSupN02_Amt.Text.Trim());
                Support.AreEqual("Credit Report to Lenders Advantage A Division Of First American Title Ins.".Clean(), FastDriver.ClosingDisclosure.SectionNSupN03_Label.GetAttribute("title").Clean());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionNSupN03_Amt.Text.Trim());
                Support.AreEqual("13b", FastDriver.ClosingDisclosure.SectionNSupN04_Seqno.Text.Trim());
                Support.AreEqual("New Loan 1 Charges", FastDriver.ClosingDisclosure.SectionNSupN04_Label.Text.Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionNSupSubN04_Amt.Text.Trim());
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group $2,500.00 P.O.C.".Replace(" ", ""), FastDriver.ClosingDisclosure.SectionNSupN05_Label.Text.Trim().Replace(" ", ""));
                Support.AreEqual("$2,500.00", FastDriver.ClosingDisclosure.SectionNSupN05_Amt.Text.Trim());
                Support.AreEqual("Construction Holdback to Midwest Financial Group $2,500.00 P.O.C.".Replace(" ", ""), FastDriver.ClosingDisclosure.SectionNSupN06_Label.Text.Trim().Replace(" ", ""));
                Support.AreEqual("$2,500.00", FastDriver.ClosingDisclosure.SectionNSupN06_Amt.Text.Trim());
                this.Done();


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void US_379156_TC_404586_NO_05()
        {//Green
            try
            {
                Reports.TestDescription = "SHARED STEPS - LOGIN,CREATE BASIC FILE";

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                this.CreateQuickFileEntry("214", "", true, true, "Residential", "Accommodation", string.Empty, string.Empty, string.Empty, "CA", "Orange", string.Empty, false);

                //
                //
                Reports.TestStep = "Creating four Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);


                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("248");

                Playback.Wait(5000);
                FastDriver.NewLoan.ClickChargesTab();
                Playback.Wait(5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                Playback.Wait(5000);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCharge: 5000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2500", PaidbySellerBeforeClosing: "2500");

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCharge: 12345678910.12);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2500", PaidbySellerOthers: "12345676410.12", SellerPaidbyOthersPaymentMethod: "POC");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in HomeownerAssociation Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                Playback.Wait(5000);
                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                Playback.Wait(3000);

                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 1200);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "1200");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Validating the charges in Section N in CD Screen";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                this.ClickOnSummaryOftrans();
                Playback.Wait(3000);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information".Clean(), FastDriver.ClosingDisclosure.SectionN13_Label.Text.Clean());
                Support.AreEqual("$6,200.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Trim());

                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Trim());
                Support.AreEqual("Lien Payoff to Midwest Financial Group".Clean(), FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("title").Clean());
                Support.AreEqual("$1,200.00", FastDriver.ClosingDisclosure.SectionN13a_Amt.Text.Trim());
                Support.AreEqual("13b".Clean(), FastDriver.ClosingDisclosure.SectionNSupN02_Seqno.Text.Clean());
                Playback.Wait(1000);
                Support.AreEqual("New Loan 1 Charges", FastDriver.ClosingDisclosure.SectionNSupN02_Label.Text.Clean());
                Support.AreEqual("$5,000.00".Clean(), FastDriver.ClosingDisclosure.SectionNSupSubN02_Amt.Text.Clean());
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group $2,500.00 P.O.C. Seller".Replace(" ", ""), FastDriver.ClosingDisclosure.SectionNSupN03_Label.Text.Replace(" ", ""));
                Support.AreEqual("$2,500.00", FastDriver.ClosingDisclosure.SectionNSupN03_Amt.Text.Trim());

                Support.AreEqual("Construction Holdback to Midwest Financial Group $345,676,410.12 P.O.C.".Replace(" ", ""), FastDriver.ClosingDisclosure.SectionNSupN04_Label.Text.Replace(" ", ""));
                //Playback.Wait(100000000);
                Support.AreEqual("$2,500.00", FastDriver.ClosingDisclosure.SectionNSupN04_Amt.Text.Clean());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void US_379156_TC_409195_NO_06()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE DISPLAY FORMAT AND LINE NUMBERS FOR CHARGES WHICH IS PRESENT IN   THE SUPPLEMENTAL PAGE IN N SECTION.";
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create a file with WCF";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating four Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);



                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                //1
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.ClickChargesTab().WaitForScreenToLoad();

                //2 
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(4000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                //3 
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();


                //4  
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                FastDriver.NewLoanSummary.SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);

                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                //5  
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan 8 Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                //6  
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "125");

                //7  
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Reconveyance Fee", sellerCharge: 125);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "125");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "CREATING CHARGES IN HOA INSTANCE 1 SCREEN.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();

                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 12345678910.12);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "12345678910.12");

                this.AddCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Adhoc charge", sellerCharge: 1000.50);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "1000.50");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);


                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check").SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.FindGABCode("248");

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", sellerCharge: 2000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2000.50");

                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", sellerCharge: 12345678910.12);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "12345678910.12");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //
                //            
                Reports.TestStep = "Creating Charges in New Loan 1 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCharge: 8000);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "8000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                //
                //
                Reports.TestStep = "Creating Charges in New Loan 2 and Mortgage Broker 2 Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, "Document Preparation Fee", sellerCharge: 5000);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "5000");

                FastDriver.NewLoan.ClickMortgageBrokerTab().WaitForMortgageBrokerTabToLoad();

                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(5000);

                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", sellerCharge: 6000);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "6000");
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);

                //
                //
                Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Adhoc charge", sellerCharge: 7000);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Validating the records in Section N";
                this.ClickOnSummaryOftrans();
                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("title").Trim());
                Support.AreEqual("$691,387,071.24", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Trim());

                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Trim());
                Support.AreEqual("Payoff Loan 8 Charges", FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("title").Trim());
                Support.AreEqual("$250.00", FastDriver.ClosingDisclosure.SectionNsub13a_Amt.Text.Trim());

                Support.AreEqual("13b", FastDriver.ClosingDisclosure.SectionNSupN04_Seqno.Text.Trim());
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.SectionNSupN04_Label.GetAttribute("title").Trim());
                Support.AreEqual("$345,679,910.62", FastDriver.ClosingDisclosure.SectionNSupSubN04_Amt.Text.Trim());

                Support.AreEqual("13c", FastDriver.ClosingDisclosure.SectionNSupN07_Seqno.Text.Trim());
                Support.AreEqual("Adhoc charge", FastDriver.ClosingDisclosure.SectionNSupN07_Label.GetAttribute("title").Trim());
                Support.AreEqual("$7,000.00", FastDriver.ClosingDisclosure.SectionNSupN07_Amt.Text.Trim());

                Support.AreEqual("13d", FastDriver.ClosingDisclosure.SectionNSupN08_Seqno.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.SectionNSupN08_Label.GetAttribute("title").Trim());
                Support.AreEqual("$345,680,910.62", FastDriver.ClosingDisclosure.SectionNSupSubN08_Amt.Text.Trim());

                Support.AreEqual("13e", FastDriver.ClosingDisclosure.SectionNSupN12_Seqno.Text.Trim());
                Support.AreEqual("New Loan 2 Charges", FastDriver.ClosingDisclosure.SectionNSupN12_Label.GetAttribute("title").Trim());
                Support.AreEqual("$11,000.00", FastDriver.ClosingDisclosure.SectionNSupSubN12_Amt.Text.Trim());

                Support.AreEqual("13f", FastDriver.ClosingDisclosure.SectionNSupN15_Seqno.Text.Trim());
                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN15_Label.GetAttribute("title").Trim());
                Support.AreEqual("$8,000.00", FastDriver.ClosingDisclosure.SectionNSupN15_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }



        #endregion

        #region 343587:CD Screen-Subsection N: Display Seller Title Premium Adjustment

        [TestMethod]
        public void ITE52_US_343587_TC_519265_NO_01()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFICATION OF 'TITLE PREMIUM ADJUSTMENT' ON CD SCREEN CREATED FROM 'OUTSIDE TITLE COMPANY' SCREEN (SINGLE INSTANCE)";

                //
                //
                Reports.TestStep = "Login To File Site";
                this.Login();

                //
                //
                Reports.TestStep = "Create Basic Order through WCF";
                this.CreateFileWithWCF();

                //   Order Entry/Escrow Closing/Closing Disclosure"
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>("Home>Order Entry>Outside Title Company");
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("314");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();

                this.UpdateCharge(FastDriver.OutsideTitleCompanyDetail, FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, "Title Premium Adjustment", sellerCharge: 250.50);
                FastDriver.OutsideTitleCompanyDetail.LenderPEDisplayTPA.FASetCheckbox(true);
                FastDriver.OutsideTitleCompanyDetail.LenderPEPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "250.50");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.ClickOnSummaryOftrans();

                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionN10_Seqno.Text.Trim());
                Support.AreEqual("Title Premium Adjustment  to Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.SectionN10_Label.Text.Trim());
                Support.AreEqual("$250.50", FastDriver.ClosingDisclosure.SectionN10_Amt.Text.Trim());
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>("Home>Order Entry>Outside Title Company");
                this.UpdateCharge(FastDriver.OutsideTitleCompanyDetail, FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, "Title Premium Adjustment", sellerCharge: 0.99);
                FastDriver.OutsideTitleCompanyDetail.LenderPEDisplayTPA.FASetCheckbox(true);

                //
                //
                Reports.TestDescription = " EDIT CHARGE DESCRIPTION,PAYEE NAME, AMOUNT AND SPLIT AMOUNT AS AT CLOSING,BEFOR CLOSING  AND PAID BY OTHERS WITH METHOD AS POC ";
                FastDriver.OutsideTitleCompanyDetail.LenderPEPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(description: "OTC SCREEN TPA", useDefault: "False", payeeName: "FAI", SellerCharge: "1000", PaidbySellerAtClosing: "500", PaidbySellerBeforeClosing: "250", PaidbySellerOthers: "250", SellerPaidbyOthersPaymentMethod: "POC");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.ClickOnSummaryOftrans();
                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionN10_Seqno.Text.Trim());
                Support.AreEqual("OTC SCREEN TPA to FAI $500.00 P.O.C.".Replace(" ", ""), FastDriver.ClosingDisclosure.SectionN10_Label.Text.Replace(" ", ""));
                Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.SectionN10_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void ITE52_US_343587_TC_519268_NO_02()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFICATION OF 'TITLE PREMIUM ADJUSTMENT' ON CD SCREEN BY SELECTING/DESELECTING 'DISPLAY TITLE PREMIUM ADJUSTMENT' CHECKBOX";
                //
                //
                Reports.TestStep = "Login To File Site";
                this.Login();

                //
                //
                Reports.TestStep = "Create Basic Order through WCF";
                this.CreateFileWithWCF();

                //   Order Entry/Escrow Closing/Closing Disclosure"
                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>("Home>Order Entry>Outside Title Company");
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("314");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();

                this.UpdateCharge(FastDriver.OutsideTitleCompanyDetail, FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, "Title Premium Adjustment", sellerCharge: 12345678910.12);
                FastDriver.OutsideTitleCompanyDetail.LenderPEDisplayTPA.FASetCheckbox(false);
                FastDriver.OutsideTitleCompanyDetail.LenderPEPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "12345678910.12", SellerPaidbyOthersPaymentMethod: "POC");
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.ClickOnSummaryOftrans();
                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionN10_Seqno.Text.Trim());
                Support.AreEqual(String.Empty, FastDriver.ClosingDisclosure.SectionN10_Label.GetAttribute("title").Replace(" ", ""));
                Support.AreEqual(String.Empty, FastDriver.ClosingDisclosure.SectionN10_Amt.GetAttribute("title").Replace(" ", ""));
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>("Home>Order Entry>Outside Title Company");
                FastDriver.OutsideTitleCompanyDetail.LenderPEDisplayTPA.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();


                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.ClickOnSummaryOftrans();
                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionN10_Seqno.Text.Trim());
                Support.AreEqual("Title Premium Adjustment to Smythe & Lee Jerome E. Lee".Replace(" ", ""), FastDriver.ClosingDisclosure.SectionN10_Label.Text.Replace(" ", ""));
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionN10_Amt.Text.Trim());
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        [TestMethod]
        public void ITE52_US_343587_TC_519271_NO_03()
        {//Green
            try
            {
                Reports.TestDescription = "VERIFICATION  OF  'TITLE  PREMIUM  ADJUSTMENT'  ON  CD  SCREEN  BY  SELECTING/DESELECTING 'SHOW  ON  CD  PAGE 3?' CHECKBOX";

                //
                //
                Reports.TestStep = "Login To File Site";
                this.Login();

                //
                //
                Reports.TestStep = "Create Order";
                this.CreateQuickFileEntry("214", "", true, true, "Residential", "Accommodation", string.Empty, string.Empty, "Oldtown", "MD", "Allegany", string.Empty, false);

                Reports.TestStep = "Fee Entry";
                //Playback.Wait(20000);
                //FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                //Playback.Wait(2000);
                //FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees, 50);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("%Lenders%");
                FastDriver.FileFees.FindNow.FAClick();
                //Playback.Wait(2000);
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("%Owners%");
                FastDriver.FileFees.FindNow.FAClick();
                //Playback.Wait(2000);
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                //Playback.Wait(2000);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.buyercharge.FASetText("300.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.buyercharge1.FASetText("400.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.sellercharge1.FAClick();
                FastDriver.FileFees.sellercharge1.FASetText("20.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.lenderAdjAmnt.FASetText("500.00");
                FastDriver.FileFees.ShowOnCD.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.ClickOnSummaryOftrans();

                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionN10_Seqno.Text.Trim());
                Support.AreEqual("Title Premium Adjustment", FastDriver.ClosingDisclosure.SectionN10_Label.Text);
                Support.AreEqual("$80.00", FastDriver.ClosingDisclosure.SectionN10_Amt.Text.Replace(" ", ""));
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //
                //
                Reports.TestDescription = " Navigate to 'Fee Entry' screen and DESELECT 'Show on CD Page 3?' checkbox";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.ShowOnCD.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();


                //
                //
                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.ClickOnSummaryOftrans();
                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionN10_Seqno.Text.Trim());
                Support.AreEqual(String.Empty, FastDriver.ClosingDisclosure.SectionN10_Label.GetAttribute("title").Replace(" ", ""));
                Support.AreEqual(String.Empty, FastDriver.ClosingDisclosure.SectionN10_Amt.GetAttribute("title").Replace(" ", ""));
                this.Done();
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion

        #region 379153 CD SCREEN  – SECTION N: ABILITY TO DISPLAY INDIVIDUAL CHARGES AS A CHARGE GROUP.

        [TestMethod]
        public void US_379153_TC_391038_NO_01() //need to be investigated
        {
            try
            {
                Reports.TestDescription = "COLLAPSE AND VERIFY THE DESCRIPTION AND AMOUNT IN SECTION N FOR PAYOFF LOAN AND HOA LIEN PAYOFF LOAN CHARGES IN CD SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating four Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 500);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FillPaymentDetailsDialog(PaidbySellerAtClosing: "500", PaidbySellerBeforeClosing: "", PaidbySellerOthers: "");
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Reconveyance Fee", sellerCharge: 125.50);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "100.50", PaidbySellerBeforeClosing: "25.00", PaidbySellerOthers: "");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in HomeownerAssociation Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 100);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "100", PaidbySellerBeforeClosing: "", PaidbySellerOthers: "");
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.HOALienPayOffTable, "Adhoc charge", sellerCharge: 100);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "100", PaidbySellerBeforeClosing: "", PaidbySellerOthers: "");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("12", FastDriver.ClosingDisclosure.SectionN12_Seqno.Text.Clean());
                Support.AreEqual("*  Payoff Loan 7 Charges", FastDriver.ClosingDisclosure.SectionN12_Label.Text.Clean());
                Support.AreEqual("$600.50", FastDriver.ClosingDisclosure.SectionN12_Amt.Text.Clean());

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("*  HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                FastDriver.ClosingDisclosure.SectionN13_ExpndButton.FAClick();
                Playback.Wait(1000);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Clean());
                Support.AreEqual("Lien Payoff to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionN13a_Amt.Text.Clean());

                Support.AreEqual("13b", FastDriver.ClosingDisclosure.SectionNSupN02_Seqno.Text.Clean());
                Support.AreEqual("Adhoc charge to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionNSupN02_Amt.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Clean());
                Support.AreEqual("Lien Payoff to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionN13a_Amt.Text.Clean());

                Support.AreEqual("13b", FastDriver.ClosingDisclosure.SectionNSupN02_Seqno.Text.Clean());
                Support.AreEqual("Adhoc charge to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$300.50", FastDriver.ClosingDisclosure.SectionNSupN02_Amt.Text.Clean());

                FastDriver.ClosingDisclosure.SectionN12_ExpndButton.FAClick();

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Clean());
                Support.AreEqual("Reconveyance Fee to Midwest Financial Group $25.00 P.O.C. Seller", FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$100.50", FastDriver.ClosingDisclosure.SectionN13a_Amt.Text.Clean());

                Support.AreEqual("13b", FastDriver.ClosingDisclosure.SectionNSupN02_Seqno.Text.Clean());
                Support.AreEqual("HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.SectionNSupN02_Amt.Text.Clean());

                Support.AreEqual("Lien Payoff to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN03_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionNSupN03_Amt.Text.Clean());

                Support.AreEqual("Adhoc charge to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN04_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionNSupN04_Amt.Text.Clean());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionN12_ExpndButton.FAClick();

                Support.AreEqual("12", FastDriver.ClosingDisclosure.SectionN12_Seqno.Text.Clean());
                Support.AreEqual("*  Payoff Loan 7 Charges", FastDriver.ClosingDisclosure.SectionN12_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$600.50", FastDriver.ClosingDisclosure.SectionN12_Amt.Text.Clean());

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("*  HOA Lien Payoff Charges", FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                Reports.TestStep = "Saving the ClosingDisclosure Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_379153_TC_391040_NO_02()
        {
            try
            {
                Reports.TestDescription = "COLLAPSE AND VERIFY THE DESCRIPTION AND AMOUNT IN SECTION N FOR ADJUSTMENTS AND PROPERTY TAX CHARGES   IN CD SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating four Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                this.AddCharge(FastDriver.AdjustmentMisc, FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Adhoc charge", sellerCharge: 12345678910.12);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("248");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", sellerCharge: 2000.50);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "2000.50");
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.AdditionalChargesTable, "County Tax", sellerCharge: 2000);
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "1000", PaidbySellerOthers: "1000", SellerPaidbyOthersPaymentMethod: "POC");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("12", FastDriver.ClosingDisclosure.SectionN12_Seqno.Text.Clean());
                Support.AreEqual("Adhoc charge", FastDriver.ClosingDisclosure.SectionN12_Label.Text.Clean());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionN12_Amt.Text.Clean());

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("* Property Taxes", FastDriver.ClosingDisclosure.SectionN13_Label.Text.Clean());
                Support.AreEqual("$3,000.50", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                FastDriver.ClosingDisclosure.SectionN13_ExpndButton.FAClick();
                Playback.Wait(1000);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$3,000.50", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Clean());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$3,000.50", FastDriver.ClosingDisclosure.SectionNsub13a_Amt.Text.Clean());

                Support.AreEqual("Property Taxes 1", FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("Title").Clean());

                Support.AreEqual("Tax Installment: Interest Due to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN03_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$2,000.50", FastDriver.ClosingDisclosure.SectionNSupN03_Amt.Text.Clean());

                Support.AreEqual("County Tax to Midwest Financial Group $1,000.00 P.O.C.", FastDriver.ClosingDisclosure.SectionNSupN04_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$1,000.00", FastDriver.ClosingDisclosure.SectionNSupN04_Amt.Text.Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_379153_TC_391043_NO_03()
        {
            try
            {
                Reports.TestDescription = "COLLAPSE AND VERIFY THE DESCRIPTION AND AMOUNT IN SECTION N FOR NEW LOAN 1   AND NEW LOAN 2 CHARGES   IN CD SCREEN.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating four Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").WaitForScreenToLoad();
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("500");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("500");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanDetails, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 125);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCharge: 12345678910.12);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "12345678910.12");
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCharge: 1000.50);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "1000.50.12");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in 2nd New Loan and Mprtgage Broker Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                if (chargeAvailability("tNL_tLC_NLC_cgLC_dcs", "Document Preparation Fee"))
                {
                    FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: "Document Preparation Fee", sellerCharge: 12345678910.12);
                }
                else
                {
                    FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: "Document Preparation Fee", sellerCharge: 12345678910.12);
                }
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "12345678910.12");
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("247");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Credit Report", sellerCharge: 0.750);
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "0.750");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section N";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("12", FastDriver.ClosingDisclosure.SectionN12_Seqno.Text.Clean());
                Support.AreEqual("* New Loan 2 Charges", FastDriver.ClosingDisclosure.SectionN12_Label.Text.Clean());
                Support.AreEqual("$345,678,910.87", FastDriver.ClosingDisclosure.SectionN12_Amt.Text.Clean());

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("* New Loan 1 Charges", FastDriver.ClosingDisclosure.SectionN13_Label.Text.Clean());
                Support.AreEqual("$345,679,910.62", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                FastDriver.ClosingDisclosure.SectionN13_ExpndButton.FAClick();
                Playback.Wait(1000);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$345,679,910.62", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Clean());
                Support.AreEqual("New Loan 1 Charges", FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$345,679,910.62", FastDriver.ClosingDisclosure.SectionNsub13a_Amt.Text.Clean());

                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionNSupN02_Amt.Text.Clean());

                Support.AreEqual("Construction Holdback to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN03_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$1,000.50", FastDriver.ClosingDisclosure.SectionNSupN03_Amt.Text.Clean());

                FastDriver.ClosingDisclosure.SectionN12_ExpndButton.FAClick();
                Playback.Wait(1000);

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionN13_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$345,679,911.37", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());

                Support.AreEqual("13a", FastDriver.ClosingDisclosure.SectionN13a_Seqno.Text.Clean());
                Support.AreEqual("Credit Report to Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionN13a_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$0.75", FastDriver.ClosingDisclosure.SectionN13a_Amt.Text.Clean());

                Support.AreEqual("13b", FastDriver.ClosingDisclosure.SectionNSupN02_Seqno.Text.Clean());
                Support.AreEqual("New Loan 1 Charges", FastDriver.ClosingDisclosure.SectionNSupN02_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$345,679,910.62", FastDriver.ClosingDisclosure.SectionNSupSubN02_Amt.Text.Clean());

                Support.AreEqual("Principal Reduction Payment to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN03_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionNSupN03_Amt.Text.Clean());

                Support.AreEqual("Construction Holdback to Midwest Financial Group", FastDriver.ClosingDisclosure.SectionNSupN04_Label.GetAttribute("Title").Clean());
                Support.AreEqual("$1,000.50", FastDriver.ClosingDisclosure.SectionNSupN04_Amt.Text.Clean());

                FastDriver.ClosingDisclosure.SectionN12_ExpndButton.FAClick();
                Playback.Wait(1000);

                Support.AreEqual("12", FastDriver.ClosingDisclosure.SectionN12_Seqno.Text.Clean());
                Support.AreEqual("* New Loan 2 Charges", FastDriver.ClosingDisclosure.SectionN12_Label.Text.Clean());
                Support.AreEqual("$345,678,910.87", FastDriver.ClosingDisclosure.SectionN12_Amt.Text.Clean());

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionN13_Seqno.Text.Clean());
                Support.AreEqual("* New Loan 1 Charges", FastDriver.ClosingDisclosure.SectionN13_Label.Text.Clean());
                Support.AreEqual("$345,679,910.62", FastDriver.ClosingDisclosure.SectionN13_Amt.Text.Clean());
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        //Srinivas - Edit Group description

        #region USERSTORY 362711 CD Screen – Section N: Display “Closing Costs Paid at Closing (J)” on line N02

        #region USERSTORY 362711_TESTCASE_460912_Edit and Verify Closing Cost at Line N02

        [TestMethod]
        public void FTR5_ITR41_US_362711_TC_460912_SC2()
        {
            try
            {
                Reports.TestDescription = "Edit and Verify Closing Cost at Line N02";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                double[] Charges = new double[20];
                Random random = new Random();
                int randomNumber;
                random.Next(0, 1000);
                for (int ii = 0; ii < 4; ii++)
                {
                    randomNumber = random.Next(1000, 2000);

                    Charges[ii] = ii + randomNumber;
                }
                Desc[0] = "Application Fee";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                New_Loan_Individual(Desc[0], Charges[0], Charges[1]);
                this.Verify_Section_N02();

                Reports.TestStep = "Editing new loan value and verifying line N02";
                New_Loan_Individual(Desc[0], Charges[2], Charges[3]);
                this.Verify_Section_N02();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region USERSTORY 393849 CD Screen - Section N - Ability to edit Charge Group Description

        #region USERSTORY 393849_TESTCASE_460858_Edit Property Tax Group DescriptionIn Section N

        [TestMethod]
        public void FTR5_ITR41_US_393849_TC_460858_SC2()
        {
            try
            {
                Reports.TestDescription = "Edit and Verify Closing Cost at Line N02";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string[] Desc = new String[20];
                double[] Charge = new double[20];
                Desc[0] = "Tax Installment: Interest Due";
                Desc[1] = "Tax Installment: Amount";
                Desc[2] = "Tax Installment: Penalty Due";
                Descr = "Property Taxes new group description";
                Random random = new Random();
                int randomNumber;
                random.Next(0, 1000);
                for (int ii = 0; ii < 3; ii++)
                {
                    randomNumber = random.Next(1000, 2000);
                    Charge[ii] = ii + randomNumber;
                }
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to IIS Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Entering Proerty Tax data  ";
                PropertyTax_Group(Desc[0], Desc[1], Charge[0], Charge[1], true);
                Reports.TestStep = "Update and Verify Property Tax data  ";
                Verify_GroupCharge_Desc_N();
                FastDriver.ClosingDisclosure.PopUpDone.FAClick();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 393849_TESTCASE_460855_Edit  New Loan Description and verify in Section N

        [TestMethod]
        public void FTR5_ITR41_US_393849_TC_460855_SC1()
        {
            try
            {
                Reports.TestDescription = "Edit and Verify Closing Cost at Line N02";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                Desc[0] = "Appraisal Fee";
                Desc[1] = "Credit Report";
                Descr = "New Loan 2 Charges new group description";
                Random random = new Random();
                int randomNumber;
                random.Next(0, 1000);
                for (int ii = 0; ii < 3; ii++)
                {
                    randomNumber = random.Next(1000, 2000);
                    SellerCharge[ii] = ii + randomNumber;
                }
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to IIS Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Entering new loan data  ";
                New_Loan_Group(Desc[0], Desc[1], SellerCharge[0], SellerCharge[1], true);
                Reports.TestStep = "update and verify group Description ";
                Verify_GroupCharge_Desc_N();
                FastDriver.ClosingDisclosure.PopUpDone.FAClick();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        //Sirinivas - Dynamic lines - table 2

        #region USERSTORY 370076 CD Screen - Section N: CD Screen - Section N: Adjustments for Items Unpaid by Seller -SUpplementary lines
        #region USERSTORY 370076_TESTCASE_380275_SCENARIO2: Section N: add/EDIT charges and verify supp line charges
        [TestMethod]
        public void FTR5_ITR20_US_370076_TC_380280_SC2()
        {
            try
            {
                #region Section N Add  and edit supplementary charges and verify supplementary line charges
                BrowserWindow objBrowser = new BrowserWindow();
                objBrowser.SearchProperties["ClassName"] = "IEFrame";
                objBrowser.SearchProperties["ControlType"] = "Window";

                int i = 0, j = 0;
                String[] Get_Amt = new String[20];
                int ind = 6;//index of BuyerCredit array

                String[] Desc = new String[20];
                String[] Fdate = new String[20];
                String[] Tdate = new String[20];
                String[] FinalAmt = new String[20];
                String[] Amt = new String[20];


                Random rnd = new Random();

                Random random = new Random();
                int randomNumber;
                random.Next(0, 1000);
                for (int ii = 0; ii < 9; ii++)
                {
                    Desc[ii] = ii + "DescriptionDetails " + ii;
                    Fdate[ii] = 1 + "/" + (ii + 1) + "/" + "14";
                    Tdate[ii] = 1 + "/" + (ii + 1) + "/" + "15";
                    randomNumber = random.Next(0, 860);
                    Amt[ii] = "1000" + randomNumber.ToString().Trim();
                }
                //
                //
                Reports.TestStep = "lOGIN TO File Site";
                this.Login();

                //
                //
                Reports.TestStep = "Create basic order";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                FastDriver.LeftNavigation.Navigate<ProrationDetail>("Home>Order Entry>Escrow Charge Processes>Proration>Rent").SwitchToContentFrame();
                Keyboard.SendKeys("%N");
                Playback.Wait(5000);
                this.other_Proration_data(Desc[0], Fdate[0], Tdate[0], Amt[0], "Section N", 0);
                //
                //
                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").SwitchToContentFrame();
                Keyboard.SendKeys("%N");
                Playback.Wait(5000);
                this.other_Proration_data(Desc[1], Fdate[1], Tdate[1], Amt[1], "Section N", 0);

                //
                //
                Reports.TestStep = "Creating Proration charges in Escrow charge->Utility ";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                this.Utility_Data(Desc[2], Fdate[2], Tdate[2], Amt[2], ind++, "Section N");
                Playback.Wait(500);
                Keyboard.SendKeys("^N");
                Playback.Wait(3000);
                this.Utility_Data(Desc[3], Fdate[3], Tdate[3], Amt[3], ind++, "Section N");

                //
                //
                Reports.TestStep = "Creating Proration charges in Escrow charge->Homeowner Association ";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                this.homeowner_Data(Desc[4], Fdate[4], Tdate[4], Amt[4], ind++, "Section N");
                Keyboard.SendKeys("^N");
                Playback.Wait(3000);
                homeowner_Data(Desc[5], Fdate[5], Tdate[5], Amt[5], ind++, "Section N");

                //
                //
                Reports.TestStep = "VERIFYING SUPPLEMENTARY IINE CHARGES ";
                this.Supp_Line_Verification("Section N");

                //
                //
                Reports.TestStep = "EDITING one of the supplementar line charges";
                sum = sum - double.Parse(Seller_Charge[--ind]);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.TableRow.FAClick();
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();
                FastDriver.HomeownerAssociation.ProrationSellerCharge.FASetText("5555.25");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                Seller_Charge[ind] = 5555.25.ToString();
                sum = sum + double.Parse(Seller_Charge[ind]);

                //
                //
                Reports.TestStep = "VERIFYING SUPPLEMENTARY IINE CHARGES AFTER EDITING ONE OF THE CHARGES ";
                Supp_Line_Verification("Section N");
                #endregion
            }

        #endregion

            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }



        #endregion

        #region USERSTORY 370081 CD Screen - Section N: CD Screen - Section N: Adjustments for Items Unpaid by Seller - Supplementary charges

        #region USERSTORY 370081_TESTCASE_380272_SCENARIO2: Section N: add and edit supplementary charges

        [TestMethod]
        public void FTR5_ITR20_US_370081_TC_380272_SC2()
        {//Green
            try
            {
                Reports.TestDescription = "Section N ADD EDIT supplementary CHARGES ";

                #region Section N  Supplementary charges
                BrowserWindow objBrowser = new BrowserWindow();
                objBrowser.SearchProperties["ClassName"] = "IEFrame";
                objBrowser.SearchProperties["ControlType"] = "Window";
                String[] Get_Amt = new String[20];
                int ind = 4;
                Random rnd = new Random();
                Random random = new Random();
                int randomNumber; random.Next(0, 1000);
                for (int ii = 0; ii < 9; ii++)
                {
                    Desc[ii] = ii + "DescriptionDetails";
                    Fdate[ii] = 1 + "/" + (ii + 1) + "/" + "14";
                    Tdate[ii] = 1 + "/" + (ii + 1) + "/" + "15";
                    randomNumber = random.Next(0, 860);
                    Amt[ii] = "1000" + randomNumber;
                }

                //
                //
                Reports.TestStep = "Login";
                this.Login();

                //FastDriver.TopFrame.SearchFileByFileNumber("10121");

                //
                //
                Reports.TestStep = "Create basic file";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.LeftNavigation.Navigate<ProrationDetail>("Home>Order Entry>Escrow Charge Processes>Proration>Rent").SwitchToContentFrame();
                FastDriver.ProrationTax.New.FAClick();
                Playback.Wait(5000);
                this.other_Proration_data(Desc[0], Fdate[0], Tdate[0], Amt[0], "Section N", ind++);

                //
                //
                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<ProrationMisc>("Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").WaitForScreenToLoad();
                FastDriver.ProrationTax.New.FAClick();
                this.other_Proration_data(Desc[1], Fdate[1], Tdate[1], Amt[1], "Section N", ind++);

                //
                //
                Reports.TestStep = "Creating Proration charges in Escrow charge->Utility ";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
                this.Utility_Data(Desc[2], Fdate[2], Tdate[2], Amt[2], ind++, "Section N");
                FastDriver.BottomFrame.New();
                Playback.Wait(4000);
                this.Utility_Data(Desc[3], Fdate[3], Tdate[3], Amt[3], ind++, "Section N");

                //
                //
                Reports.TestStep = "Creating Proration charges in Escrow charge->hoeowner association ";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                this.homeowner_Data(Desc[4], Fdate[4], Tdate[4], Amt[4], ind++, "Section N");
                FastDriver.BottomFrame.New();
                Playback.Wait(4000);
                homeowner_Data(Desc[5], Fdate[5], Tdate[5], Amt[5], ind++, "Section N");

                //
                //
                Reports.TestStep = "VERIFYING SUPPLEMENTARY CHARGES ";
                this.ClickOnSummaryOftrans();
                this.Supp_Charge_Verification(16, true);

                //
                //
                Reports.TestStep = "EDITING one of the supplementar line charges";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                FastDriver.HomeownerAssociationSummary.TableRow.FAClick();
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();
                FastDriver.HomeownerAssociation.ProrationSellerCharge.FASetText("555.25");
                GetAmt[--ind] = 555.25.ToString();
                FastDriver.BottomFrame.Done();

                //
                //
                Reports.TestStep = "VERIFYING SUPPLEMENTARY IINE CHARGES AFTER EDITING ONE OF THE CHARGES ";
                this.ClickOnSummaryOftrans();
                this.Supp_Charge_Verification(16, true);


            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
                #endregion
        }
        #endregion
        #endregion

        #region USERSTORY 370068 CD Screen - Section N: CD Screen - Section N: Adjustments for Items Unpaid by Seller - other proration charges

        #region USERSTORY 370068_TESTCASE_380265_SCENARIO1: Section N: add and edit other proration charges
        [TestMethod]
        public void FTR5_ITR20_US_370068_TC_380265_SC1()
        {//Green
            Reports.TestDescription = "Section N , Add/Edit Other proration Charges and verify";


            #region Section N other proration charges
            BrowserWindow objBrowser = new BrowserWindow();
            objBrowser.SearchProperties["ClassName"] = "IEFrame";
            objBrowser.SearchProperties["ControlType"] = "Window";
            int ind = 4;
            int i = 0;
            int j = 0;
            Random rnd = new Random();
            Random random = new Random();
            int randomNumber; random.Next(0, 1000);
            for (int ii = 0; ii < 9; ii++)
            {
                Desc[ii] = ii + "DescriptionDetails ";
                Fdate[ii] = 1 + "/" + (ii + 1) + "/" + "14";
                Tdate[ii] = 1 + "/" + (ii + 1) + "/" + "15";
                Amt[ii] = "1000" + ii.ToString();
                randomNumber = random.Next(0, 860);

            }

            //
            //
            Reports.TestStep = "Login to Fast";
            this.Login();

            //
            //
            Reports.TestStep = "Create a file using quick file entry";
            this.CreateFileWithWCF();
            //0DescriptionDetails    0DescriptionDetails     0DescriptionDetails     0DescriptionDetails F();

            Reports.TestStep = "Creating Wind insurance charges ";
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
            Wind_Insurance(Desc[0], Fdate[0], Tdate[0], Amt[0], ind++, ClosingDisclosureSection.N);

            Reports.TestStep = "Creating Flood insurance charges ";
            Flood_Insurance(Desc[1], Fdate[1], Tdate[1], Amt[1], ind++, ClosingDisclosureSection.N);

            Reports.TestStep = "Creating Fireinsurance charges ";
            Fire_Insurance(Desc[2], Fdate[2], Tdate[2], Amt[2], ind++, ClosingDisclosureSection.N);

            Reports.TestStep = "Creating EarthQuake insurance charges ";
            EarthQuake_Insurance(Desc[3], Fdate[3], Tdate[3], Amt[3], ind, ClosingDisclosureSection.N);

            Reports.TestStep = "Verifying charges entered in CD Screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);
            this.Supp_Charge_Verification(16, true);

            Reports.TestStep = "Editing one of the insurance charges ";
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
            FastDriver.InsuranceSummary.EarthQuake.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceEarth.WaitForScreenToLoad();
            FastDriver.InsuranceEarth.EarthSellerCharge1.FASetText("555.55");
            Keyboard.SendKeys(FAKeys.TabAway);
            GetAmt[ind] = FastDriver.InsuranceEarth.EarthSellerCharge1.GetAttribute("value").Clean();
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Verifying charges after editing charges in CD Screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);
            this.Supp_Charge_Verification(16, true);

            #endregion

        }
        #endregion
        #endregion

        //Hima - sec N - Fixed lines - table 2

        #region USERSTORY 370053 CD Screen - Section N: City/Town Taxes

        #region USERSTORY 370053_TESTCASE_374184_SCENARIO1: - CD Screen - Sec N: Verify display of Line 14 when no data entered for City/Town Taxes in Proration Tax screen.

        [TestMethod]
        public void FTR5_ITR20_US_370053_TC_374184_SC1()
        {
            try
            {
                Reports.TestDescription = @"USERSTORY – 370053_TESTCASE_374184_SCENARIO_1- Verify display of Line 14 when no data entered for City/Town Taxes in Proration Tax screen.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to IIS Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Expand Summary of Transaction";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.N, 14, "City/Town Taxes", "", "", ""); //City/Town Taxes should have given as the charge description at admin and Proration Tax screen.

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370053_TESTCASE_374185_SCENARIO2: CD Screen - Sec N: Verify display of Line 14 when valid required data is entered for City/Town Taxes in Proration Tax screen.

        [TestMethod]
        public void FTR5_ITR20_US_370053_TC_374185_SC2()
        {
            try
            {
                Reports.TestDescription = @"USERSTORY – 370053_TESTCASE_374185_SCENARIO_2- Sec N: Verify display of Line 14 when valid required data is entered for City/Town Taxes in Proration Tax screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to IIS Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "10/21/2014", "10/21/2015", "200.00", false);

                Reports.TestStep = "Expand Summary of Transaction";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.N, 14, "City/Town Taxes", "10/21/14", "10/21/15", GetCharge);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370053_TESTCASE_374194_SCENARIO10: CD Screen - Sec N: Verify display format of charge amount in Line 14.

        [TestMethod]
        public void FTR5_ITR20_US_370053_TC_374194_SC10()
        {
            try
            {
                Reports.TestDescription = @"USERSTORY 370053_TESTCASE_374194_SCENARIO10: CD Screen - Sec N: Verify display format of charge amount in Line 14.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to IIS Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Tax", "10/21/2014", "10/21/2015", "99,999,999,999.00", false);
                GetCharge = GetCharge.Substring(3);

                Reports.TestStep = "Expand Summary of Transaction";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.N, 14, "City/Town Taxes", "10/21/14", "10/21/15", GetCharge);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370053_TESTCASE_374195_SCENARIO11: CD Screen - Sec N: Verify display of Line 14 When Proration City/Town Taxes added is removed.

        [TestMethod]
        public void FTR5_ITR20_US_370053_TC_374195_SC11()
        {
            try
            {
                Reports.TestDescription = @"USERSTORY – 374195_TESTCASE_370851_SCENARIO_11 - Sec N: Verify display of Line 14 When Proration City/Town Taxes added is removed.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to IIS Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Tax", "10/21/2014", "10/21/2015", "200.00", false);

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.CityCell.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Expand Summary of Transaction";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.N, 14, "City/Town Taxes", "", "", ""); //City/Town Taxes should have given as the charge description at admin and Proration Tax screen.   

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region USERSTORY 370054 CD Screen - Section N: County Taxes

        #region USERSTORY 374198_TESTCASE_374198_SCENARIO1: - CD Screen - Sec N:  Verify display of when no data entered for County Taxes in Proration Tax screen.

        [TestMethod]
        public void FTR5_ITR20_US_370054_TC_374198_SC1()
        {
            try
            {
                Reports.TestDescription = @"USERSTORY – 370054_TESTCASE_374198_SCENARIO_1- Verify display of Line 15 when no data entered for County Taxes in Proration Tax screen.";
                
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to IIS Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Expand Summary of Transaction";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.N, 15, "County Taxes", "", "", ""); //County Taxes should have given as the charge description at admin and Proration Tax screen.  

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370054_TESTCASE_374199_SCENARIO2: CD Screen - Sec N:  Verify display of Line 15 when valid required data is entered for County Taxes in Proration Tax screen.

        [TestMethod]
        public void FTR5_ITR20_US_370054_TC_374199_SC2()
        {//Green
            try
            {
                Reports.TestDescription = @"USERSTORY – 370054_TESTCASE_374199_SCENARIO_2- Sec N:  Verify display of Line 15 when valid required data is entered for County Taxes in Proration Tax screen";

                #region data setup

                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                //
                //
                Reports.TestStep = "Login to file side";
                this.Login();

                //
                //
                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //
                //
                Reports.TestStep = "ENTER PRORATION DATA";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/21/2014", "10/21/2015", "200.00", false);

                //
                //
                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                //
                //
                Reports.TestStep = "Verify data Charge available";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.N, 15, "County Taxes", "10/21/14", "10/21/15", GetCharge);

                #endregion GUI interaction

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }


        }


        #endregion

        [TestMethod]
        #region USERSTORY 370054_TESTCASE_374207_SCENARIO10: CD Screen - Sec N:  Verify display format of charge amount in Line 15.
        public void FTR5_ITR20_US_370054_TC_374207_SC10()
        {//Green
            try
            {
                string GetCharge = string.Empty;
                Reports.TestDescription = @"USERSTORY – 370054_TESTCASE_374207_SCENARIO_10 - Sec N:  Verify display format of charge amount in Line 09.";

                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Navigate to Proration Tax";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Tax", "10/21/2014", "10/21/2015", "99,999,999,999.00", false);
                GetCharge = GetCharge.Substring(3);
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.N, 15, "County Taxes", "10/21/14", "10/21/15", GetCharge);

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        #endregion

        #region USERSTORY 370054_TESTCASE_374208_SCENARIO11: CD Screen - Sec N:  Verify display of Line 15 When Proration County Taxes added is removed.
        [TestMethod]
        public void FTR5_ITR20_US_370054_TC_374208_SC11()
        {//Green
            try
            {
                Reports.TestDescription = @"USERSTORY – 370054_TESTCASE_374208_SCENARIO_11 - Sec N:  Verify display of Line 15 When Proration County Taxes added is removed.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create a Basic File";
                this.CreateFileWithWCF();
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
                FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/21/2014", "10/21/2015", "200.00", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").SwitchToContentFrame();
                FastDriver.ProrationTax.CountyCell.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.N, 15, "County Taxes", "", "", "");

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion

        #endregion

        #region USERSTORY 370060 CD Screen - Section N: Assessments

        #region USERSTORY 370060_TESTCASE_374210_SCENARIO1: - CD Screen - Sec N: Verify display of Line 16 when no data entered for Assessments in Proration Tax screen.
        [TestMethod]
        public void FTR5_ITR20_US_370060_TC_374210_SC1()
        {//Green
            try
            {
                Reports.TestDescription = @"USERSTORY – 370060_TESTCASE_374210_SCENARIO_1- Verify display of Line 16 when no data entered for Assessments in Proration Tax screen.";
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Validate data";
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.N, 16, "Assessments", "", "", "");

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion

        #region USERSTORY 370060_TESTCASE_374211_SCENARIO2: CD Screen - Sec N: Verify display of Line 16 when valid required data is entered for Assessments in Proration Tax screen.
        [TestMethod]
        public void FTR5_ITR20_US_370060_TC_374211_SC2()
        {//Green
            try
            {
                string GetCharge = string.Empty;
                Reports.TestDescription = @"USERSTORY – 370060_TESTCASE_374211_SCENARIO_2- Sec N: Verify display of Line 16 when valid required data is entered for Assessments in Proration Tax screen";
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Validate data";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").SwitchToContentFrame();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "10/21/2014", "10/21/2015", "200", false);
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.N, 16, "Assessments", "10/21/14", "10/21/15", GetCharge);
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion

        #region USERSTORY 370060_TESTCASE_374219_SCENARIO10: CD Screen - Sec N: Verify display format of charge amount in Line 09.
        [TestMethod]
        public void FTR5_ITR20_US_370060_TC_374219_SC10()
        {//Green
            string GetCharge = string.Empty;
            try
            {
                Reports.TestDescription = @"USERSTORY – 370060_TESTCASE_374219_SCENARIO_10 - Sec N: Verify display format of charge amount in Line 09.";
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create a File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Validate data";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").SwitchToContentFrame();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "10/21/2014", "10/21/2015", "99,999,999,999.00", false);
                GetCharge = GetCharge.Substring(3);
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.N, 16, "Assessments", "10/21/14", "10/21/15", GetCharge);

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion

        #region USERSTORY 370060_TESTCASE_374220_SCENARIO11: CD Screen - Sec N: Verify display of Line 16 When Proration Assessments added is removed.

        [TestMethod]
        public void FTR5_ITR20_US_370060_TC_374220_SC11()
        {//Green
            try
            {
                Reports.TestDescription = @"USERSTORY – 370060_TESTCASE_374220_SCENARIO_11 - Sec N: Verify display of Line 16 When Proration Assessments added is removed.";

                //
                //
                Reports.TestStep = "Login To Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create a Basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Validate Data";
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").SwitchToContentFrame();
                FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "10/21/2014", "10/21/2015", "200.00", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax").SwitchToContentFrame();
                FastDriver.ProrationTax.AssesmentCell.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                this.ClickOnSummaryOftrans();
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.N, 16, "Assessments", "", "", "");

            }
            catch (Exception e)
            {
                FailTest(e.Message);
            }
        }
        #endregion

        #endregion

        //Hima - Sec N - Total Amount
        #region USERSTORY 213054 CD Screen - Section N: Due from Seller at Closing.
        #region USERSTORY 213054_TESTCASE_432080_SCENARIO1 - Section N : To verify total amount when Charges are available from N1 to N19.

        [TestMethod]
        public void FTR5_ITR34_US_213054_TC_432080_SC1()
        {
            double Table1ChargeSum = 0.0;
            double Table2ChargeSum = 0.0;
            string[] Charge = new String[20];
            string SuppChargeTable1 = "", SuppChargeTable2 = " ";

            try
            {
                Reports.TestDescription = "USERSTORY 213054_TESTCASE_432080_SCENARIO1: To verify total amount when Charges are available from N1 to N19.";

                //
                //
                Reports.TestStep = "Login to Fast";
                this.Login();

                //
                //
                Reports.TestStep = "Create a Basic File";
                this.CreateFileWithWCF();

                //
                //
                Reports.TestStep = "Navigate to New Loan 1 and add New Loan Lender 1 information and Loan amount";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.FindGABCode("314");
                Playback.Wait(2000);
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("200.00");

                //
                //
                Reports.TestStep = "Setting Seller Charge in Assumptions Loan 1 screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan");
                FastDriver.AssumptionLoanDetails.FindGABCode("234");
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitCreation(FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription, 10);
                this.UpdateCharge(FastDriver.AssumptionLoanCharges, FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 1000);
                this.UpdateCharge(FastDriver.AssumptionLoanCharges, FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, chargeDescription: "Document Fee", sellerCharge: 2000);

                //
                //
                Reports.TestStep = "Setting Seller Charge in Assumptions Loan 2 screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan"); ;
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.FindGABCode("314");
                Playback.Wait(1000);
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitCreation(FastDriver.AssumptionLoanCharges.UnpaidPrincLoanChargesDescription, 10);
                this.UpdateCharge(FastDriver.AssumptionLoanCharges, FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCredit: 0.02);
                this.UpdateCharge(FastDriver.AssumptionLoanCharges, FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, chargeDescription: "Document Fee", sellerCredit: 0.03);

                //
                //
                Reports.TestDescription = "VERIFY THE PRESENCE OF EARNEST MONEY HELD IN LINE N0 06,07, 09, 10";
                Reports.TestStep = "Creating Charges in Deposit Outside Escrow Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FASelectItem("Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FASetText("10.11");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FASelectItem("Seller's Attorney");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FASetText("20.22");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FASetText("Deposit1");
                FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FASetText("Deposit2");
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("40.44");
                FastDriver.DepositOutsideEscrow.DisbursedasProceeds.FASetText("30.33");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("101.1");
                FastDriver.BottomFrame.Save();
                Playback.Wait(4000);
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                //FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Adjustments/Off-Set");
                this.UpdateCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, chargeDescription: "Seller Credit", sellerCharge: 3000);
                this.UpdateCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, chargeDescription: "Assign Tenant Lease/Rent", sellerCharge: 4000);

                //
                //
                Reports.TestStep = "Setting Seller Charge in Adjustment Miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous");
                this.AddCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, chargeDescription: "Adjustment MISC Adhoc 1", buyerCharge: 5.05);

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                Playback.Wait(2000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 30.42);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "15.21", PaidbySellerOthers: "15.21", SellerPaidbyOthersPaymentMethod: "POC-L");

                //
                //
                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
                FastDriver.BottomFrame.New();
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Statement/Forwarding Fee", sellerCharge: 50.06);
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", sellerCharge: 50.06);
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                this.FillPaymentDetailsDialog(PaidbySellerAtClosing: "25.03", PaidbySellerBeforeClosing: "25.03", SellerPaidbyOthersPaymentMethod: "POC-L", SellerCreditPaymentMethod: "POC");

                //
                //
                Reports.TestStep = "Navigate to New Loan 1";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                //FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.NewLoan.FindGABCode("248");
                Playback.Wait(3000);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, chargeDescription: "Principal Reduction Payment", sellerCharge: 5000);
                
                //
                //
                Reports.TestStep = "Create New Loan 2 Charge";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan");
                FastDriver.BottomFrame.New();
                Playback.Wait(4000);
                FastDriver.NewLoan.FindGABCode("314");
                Playback.Wait(1500);
                FastDriver.NewLoan.ClickChargesTab();
                //FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: "Credit Report", sellerCharge: 20);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: "Credit Report", sellerCharge: 40);
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("188");
                FastDriver.NewLoan.MortgageFind.FAClick();
                Playback.Wait(2000);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Appraisal Fee", sellerCharge: 60);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Appraisal Fee", sellerCharge: 80);

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check");
                FastDriver.PropertyTaxCheck.FindGABCode("BOA");
                Playback.Wait(1500);
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, chargeDescription: "Tax Installment: Interest Due", sellerCharge: 2020);

                //
                //
                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>("Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check");
                FastDriver.BottomFrame.New();
                Playback.Wait(5000);
                FastDriver.PropertyTaxCheck.FindGABCode("188");
                Playback.Wait(1500);
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, chargeDescription: "Tax Installment: Interest Due", sellerCharge: 4040);
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, chargeDescription: "Tax Installment: Partial Payment Amt", sellerCharge: 8000);

                //
                //
                Reports.TestStep = "Create New Loan 3 credit";
                FastDriver.LeftNavigation.Navigate<NewLoan>("Home>Order Entry>New Loan").SwitchToContentFrame();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(5000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.FindGABCode("314");
                Playback.Wait(4000);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                //Playback.Wait(10000000);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.AggregateAccountingAdjustmentTable, chargeDescription: "Homeowner's Insurance", sellerCharge: 20);
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.AggregateAccountingAdjustmentTable, chargeDescription: "Mortgage Insurance", sellerCharge: 40);
                this.FixedLinesData_Adj_dataentry(ClosingDisclosureSection.N);
                this.DynamicLines_Adj_dataentry(ClosingDisclosureSection.N);

                //
                //
                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                this.ClickOnSummaryOftrans();

                /*SecNTable1*/
                HtmlTable secNDueItemsTable = (HtmlTable)FastDriver.ClosingDisclosure.SectionN_DueItemsTable;
                /*SecNTable2*/
                HtmlTable secNAdjustItemTable = (HtmlTable)FastDriver.ClosingDisclosure.SectionN_AdjustmentforItemsSubTable;

                bool flagHLine = secNDueItemsTable.GetRow(0).GetChildren()[0].GetProperty("InnerText").ToString().Contains("N. Due from Seller at Closing ");
                string HCharge = secNDueItemsTable.GetRow(0).GetChildren()[2].GetProperty("InnerText").ToString().Trim();
                string SupplinenumberTab1 = secNDueItemsTable.GetRow(13).GetChildren()[0].GetChildren()[1].GetProperty("InnerText").ToString();
                string SuppDescTab1 = secNDueItemsTable.GetRow(13).GetChildren()[0].GetChildren()[2].GetProperty("InnerText").ToString();
                string SupplinenumberTab2 = secNAdjustItemTable.GetRow(6).GetChildren()[0].GetChildren()[1].GetProperty("InnerText").ToString();
                string SuppDescTab2 = secNAdjustItemTable.GetRow(6).GetChildren()[1].GetProperty("InnerText").ToString();                            //MessageBox.Show("" + SuppDescTab2);  

                for (int i = 1; i < 13; i++)
                {
                    int k = 0;
                    string s1 = "0";
                    if (secNDueItemsTable.GetRow(i).GetChildren()[2].GetProperty("FriendlyName").Equals(secNDueItemsTable.GetRow(i).GetChildren()[2].GetProperty("Id")))
                        s1 = "0";

                    else
                    {
                        Charge[k] = secNDueItemsTable.GetRow(i).GetChildren()[2].GetProperty("InnerText").ToString().Trim();
                        s1 = Charge[k].Substring(1);
                    }
                    Table1ChargeSum = Table1ChargeSum + double.Parse(s1);
                    k++;
                }

                string SuppChargeTable1value = SuppChargeTable1.Substring(1);
                Table1ChargeSum = Table1ChargeSum + double.Parse(SuppChargeTable1value);

                for (int i = 1; i < 6; i++)
                {
                    int j = 0;
                    string s1 = "0";
                    if (secNAdjustItemTable.GetRow(i).GetChildren()[6].GetProperty("FriendlyName").Equals(secNAdjustItemTable.GetRow(i).GetChildren()[6].GetProperty("Id")))
                    {
                        s1 = "0";

                    }
                    else
                    {
                        Charge[j] = secNAdjustItemTable.GetRow(i).GetChildren()[6].GetProperty("InnerText").ToString().Trim();
                        s1 = Charge[j].Substring(1);
                    }
                    Table2ChargeSum = Table2ChargeSum + double.Parse(s1);
                    j++;
                }

                string SuppChargeTable2value = SuppChargeTable2.Substring(1);
                Table2ChargeSum = Table2ChargeSum + double.Parse(SuppChargeTable2value);

                double TableChargeSum = Table1ChargeSum + Table2ChargeSum;

                //string FormatTableChargeSum = Feature5.SharedSteps.FormattedAmount(Convert.ToDecimal(TableChargeSum));
                string FormatTableChargeSum = Convert.ToString(Convert.ToDecimal(TableChargeSum));


                if (HCharge == FormatTableChargeSum)
                    Support.AreEqual(FormatTableChargeSum, HCharge, "Sec N Total Charges Verified");
                else
                    Support.AreEqual(FormatTableChargeSum, HCharge, "Sec N Total Charges Verified");
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }
        #endregion
        #endregion

        //Hima - Sec N - Edit Description 
        #region USERSTORY 393788 CD Screen – Section N: Provide ability to edit the Charge Description on lines N 06 to N 13

        #region USERSTORY 39388_TESTCASE_457896_SCENARIO1 - CD Section N: Verify the Charge description in lines N06 to N13 is editable when a 'Edit Description' is enabled at ADM

        [TestMethod]
        public void FTR5_ITR41_US_393788_TC_457896_SC1()
        {
            try
            {
                Reports.TestDescription = "Verify the Charge description in lines N06 to N13 is editable when a 'Edit Description' is enabled at ADM";
                
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to IIS Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(500);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 5000);

                // N07
                Reports.TestStep = "Creating Charges in HOA Screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("248");
                FastDriver.HomeownerAssociation.HOALienCollapse.FAClick();
                this.UpdateCharge(FastDriver.HomeownerAssociation, FastDriver.HomeownerAssociation.HOALienPayOffTable, "Lien Payoff", sellerCharge: 6000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Adjustment Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Lease/Rent", sellerCharge: 23);
                this.UpdateCharge(FastDriver.AdjustmentOffset, FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Assign Tenant Security Deposit", sellerCharge: 23);

                Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.AdjustmentMisc, FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, "Buyer Deposit Directly to Seller", sellerCharge: 7000);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.FindGABCode("248");
                this.UpdateCharge(FastDriver.PropertyTaxCheck, FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Amount", sellerCharge: 5000.50);

                Reports.TestStep = "Creating Charges in New Loan 1 screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("247");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCharge: 8000);

                Reports.TestStep = "Creating Charges in New Loan2 screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("248");
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                this.UpdateCharge(FastDriver.NewLoan, FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", sellerCharge: 5000);

                FixedLinesData_Adj_dataentry(ClosingDisclosureSection.N);

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                DynamicLines_Adj_dataentry(ClosingDisclosureSection.N);

                Reports.TestStep = "Expand Summaries of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                editDescVerificationFromN06toN13();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 393788_TESTCASE_457905_SCENARIO2 - CD Section N: Verify the system behavior when Charge Description is edited with a blank value.

        [TestMethod]
        public void FTR5_ITR41_US_393788_TC_457905_SC8()
        {
            try
            {
                Reports.TestDescription = "Section N: Verify the system behavior when Charge Description is edited with a blank value";
                
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to IIS Side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Payoff Loan Screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("237");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.BottomFrame.New();
                Playback.Wait(2000);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("247");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                FastDriver.NewLoanSummary.New.FAClick();
                Playback.Wait(500);
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.FindGABCode("248");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                Playback.Wait(250);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                this.UpdateCharge(FastDriver.PayoffLoanCharges, FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", sellerCharge: 5000);

                Reports.TestStep = "Validating the charges in Section N in CD Screen";
                this.ClickOnSummaryOftrans();

                validateChargesInSectionN();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion

        #region Custom class methods
        
        public void validateChargesInSectionN()
        {
            IWebElement SecNTable1 = FastDriver.ClosingDisclosure.SectionN_DueItemsTable;
            string SCreditline = string.Empty;
            string SCreditdesc = string.Empty;

            if (SecNTable1.FindElements(By.TagName("tr"))[6].FindElements(By.TagName("td"))[0].Text.Length != 0)
            {
                if (SecNTable1.FindElements(By.TagName("tr"))[6].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[1].Text.Length != 0)
                {
                    SCreditline = SecNTable1.FindElements(By.TagName("tr"))[6].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[1].Text.Clean(); //line number
                    Support.AreEqual("06", SCreditline, true);
                }
                if (SecNTable1.FindElements(By.TagName("tr"))[6].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].FindElements(By.TagName("span"))[0].Text.Length != 0)
                {
                    IWebElement span = SecNTable1.FindElements(By.TagName("tr"))[6].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].FindElements(By.TagName("span"))[0];
                    SCreditdesc = SecNTable1.FindElements(By.TagName("tr"))[6].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].FindElements(By.TagName("span"))[0].Text.Clean();  // Charge description for indv credit, * in case of group credits, 

                    if (isEditable(span))
                    {
                        Support.AreEqual("Statement/Forwarding Fee", SCreditdesc.Trim(), true);
                        Reports.TestStep = "When edited description is blank, Verify message shown with Ok button";
                        span.Clear();
                        span.Clear();
                        Keyboard.SendKeys(FAKeys.TabAway);
                        FastDriver.WebDriver.HandleDialogMessage(true, true);
                        Playback.Wait(1000);
                        FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                        Support.AreEqual("Statement/Forwarding Fee", SecNTable1.FindElements(By.TagName("tr"))[6].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].FindElements(By.TagName("span"))[0].Text.Clean(), true);
                    }
                }
            }
        }

        public void editDescVerificationFromN06toN13()
        {
            IWebElement SecNTable1 = FastDriver.ClosingDisclosure.SectionN_DueItemsTable;
            IWebElement SecNTable1Cell;
            string SCreditline = string.Empty;
            string SCreditdesc = string.Empty;
            string SCreditAmt = string.Empty;

            for (int i = 6; i < SecNTable1.GetRowCount(); ++i)
            {
                int curline = i - 1;
                bool isgrp = false;
                string slno = "0" + curline;
                string SCreditdesc1 = string.Empty;

                SecNTable1Cell = SecNTable1.PerformTableAction((i + 1), 1, TableAction.GetCell).Element;
                IWebElement EditdescMspan1 = SecNTable1Cell.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(j => j.Displayed);
                EditDescinCD = string.Empty;

                if (SecNTable1.FindElements(By.TagName("tr"))[i].Text.Length != 0)
                {
                    if (SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[1].Text.Length != 0)
                        if (!SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[1].Text.Clean()
                            .Equals(SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[1].GetAttribute("Id").Clean()))
                            SCreditline = SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[1].Text.Clean(); //line number
                        else
                            Reports.StatusUpdate("No Line number shown after line" + curline, true);

                    if (SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].Text.Length != 0)
                    {
                        string SCreditdesc2 = SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].Text.Clean(); //Full description including payee Name 

                        if (SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].Text.Length != 0)
                            SCreditdesc1 = SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].Text.Clean();

                        if (SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].Text.Length != 0)
                        {
                            IWebElement span = SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].FindElements(By.TagName("span"))[0];

                            SCreditdesc = SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].FindElements(By.TagName("span"))[0].Text.Clean();  // Charge description for indv credit, * in case of group credits, 

                            if (SCreditdesc == "See attached page for additional information")
                            {
                                SCreditAmt = SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[2].Text.Clean();
                                Support.AreEqual("$13,000.00", SCreditAmt, true);
                            }

                            if (isEditable(span) && !isgrp) 
                            {
                                Reports.StatusUpdate("" + SCreditdesc + "in" + slno + " is Editable in the CD Screen", true);
                                EditDescinCD = SCreditdesc.Substring(0, 4) + "12345678901234567890123456789012345678901";
                                span.Clear();
                                span.FASetText(EditDescinCD);
                                Debug.Print(EditDescinCD);
                                Keyboard.SendKeys(FAKeys.TabAway);
                                FastDriver.BottomFrame.Done();

                                this.ClickOnSummaryOftrans();
                                DescEditinCDTab1[curline] = SecNTable1.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].FindElements(By.TagName("span"))[2].FindElements(By.TagName("span"))[0].Text.Clean();
                                Support.AreEqual(EditDescinCD.Trim(), DescEditinCDTab1[curline].Clean());

                                if (i == 6)
                                {
                                    Reports.TestStep = "Verify edited description is shown in source screen - payoffloan";
                                    FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                                    FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Midwest Financial Group", "Name", TableAction.Click);
                                    FastDriver.NewLoanSummary.Edit.FAClick();
                                    Playback.Wait(250);
                                    FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                                    FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
                                    Playback.Wait(3000);
                                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                                    FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                                    Reports.StatusUpdate("Is Charge " + DescEditinCDTab1[curline].Clean() + " Available?", 
                                        verifyCharIsAvailable("tPL_tLC_PLC_cgLnCgSet_dcs", DescEditinCDTab1[curline].Clean()));
                                    this.ClickOnSummaryOftrans();
                                }

                                if (i == 7)
                                {
                                    Reports.TestStep = "Verify edited description is shown in source screen - HOA";
                                    FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                                    Reports.StatusUpdate("Is Charge " + DescEditinCDTab1[curline].Clean() + " Available?", 
                                        verifyCharIsAvailable("cgHOA_dcs", DescEditinCDTab1[curline].Clean()));
                                    this.ClickOnSummaryOftrans();
                                }
                                if (i == 9)
                                {
                                    Reports.TestStep = "Verify edited description is shown in source screen - Adjustment Miscellaneous Screen";
                                    FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                                    Reports.StatusUpdate("Is Charge " + DescEditinCDTab1[curline].Clean() + " Available?", 
                                        verifyCharIsAvailable("CG_dcs", DescEditinCDTab1[curline].Clean()));
                                    this.ClickOnSummaryOftrans();
                                }
                                if (i == 10)
                                {
                                    Reports.TestStep = "Verify edited description is shown in source screen - Adjustment Miscellaneous Screen";
                                    FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                                    Reports.StatusUpdate("Is Charge " + DescEditinCDTab1[curline].Clean() + " Available?", 
                                        verifyCharIsAvailable("CG_dcs", DescEditinCDTab1[curline].Clean()));
                                    this.ClickOnSummaryOftrans();
                                }
                                if (i == 11)
                                {
                                    Reports.TestStep = "Verify edited description is shown in source screen - Adjustment Miscellaneous Screen";
                                    FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                                    Reports.StatusUpdate("Is Charge " + DescEditinCDTab1[curline].Clean() + " Available?", 
                                        verifyCharIsAvailable("CG_dcs", DescEditinCDTab1[curline].Clean()));
                                    this.ClickOnSummaryOftrans();
                                }
                                if (i == 12)
                                {
                                    Reports.TestStep = "Verify edited description is shown in source screen - Property Tax Check Screen";
                                    FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                                    Reports.StatusUpdate("Is Charge " + DescEditinCDTab1[curline].Clean() + " Available?", 
                                        verifyCharIsAvailable("CGSt_dcs", DescEditinCDTab1[curline].Clean()));
                                    this.ClickOnSummaryOftrans();
                                }
                                if (i == 14)
                                {
                                    Reports.TestStep = "Verify edited description is shown in source screen - New Loan 2 Screen";
                                    FastDriver.LeftNavigation.Navigate<NewLoanSummary>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                                    FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Midwest Financial Group", "Name", TableAction.Click);
                                    FastDriver.NewLoanSummary.Edit.FAClick();
                                    Playback.Wait(250);
                                    FastDriver.NewLoan.WaitForScreenToLoad();
                                    FastDriver.NewLoan.ClickChargesTab();
                                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                                    Reports.StatusUpdate("Is Charge " + DescEditinCDTab1[curline].Clean() + " Available?",
                                        verifyCharIsAvailable("tNL_tLC_NLC_cgLC_dcs", DescEditinCDTab1[curline].Clean()));
                                    this.ClickOnSummaryOftrans();
                                }
                                if (i == 15)
                                {
                                    Reports.TestStep = "Verify edited description is shown in source screen - New Loan 2 Screen";
                                    FastDriver.LeftNavigation.Navigate<NewLoanSummary>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                                    FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Lenders Advantage A Division Of First American Title Ins.", "Name", TableAction.Click);
                                    FastDriver.NewLoanSummary.Edit.FAClick();
                                    Playback.Wait(250);
                                    FastDriver.NewLoan.WaitForScreenToLoad();
                                    FastDriver.NewLoan.ClickChargesTab();
                                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                                    Reports.StatusUpdate("Is Charge " + DescEditinCDTab1[curline].Clean() + " Available?",
                                        verifyCharIsAvailable("tNL_tLC_NLC_cgPRH_dcs", DescEditinCDTab1[curline].Clean()));
                                    this.ClickOnSummaryOftrans();
                                }
                            }
                        }
                    }
                }
            }
        }

        public bool isEditable(IWebElement element)
        {
            try
            {
                var attribute = element.GetAttribute("contenteditable");
                if (attribute != null)
                    return true;
                else
                    return false;
            }
            catch (NullReferenceException)
            {
                return false;
            }

        }

        public bool verifyCharIsAvailable(string tableId, string chargeDesc)
        {
            IWebElement table = FastDriver.WebDriver.FindElement(By.Id(tableId));
            int filterrowcount = table.GetRowCount();
            bool isPresent = false;

            for (int i = 1; i < filterrowcount; i++)
            {
                string chargeid;
                int l = i - 1;

                chargeid = tableId + "_" + l + "_tdsc";
                var NewLoantbledit = FastDriver.WebDriver.FindElement(By.Id(chargeid));
                string desc = NewLoantbledit.GetAttribute("value").ToString().Clean();
                if (desc == chargeDesc)
                {
                    Reports.StatusUpdate("Compare this -> " + desc + " with this ->" + chargeDesc, true);
                    isPresent = true;
                    break;
                }

            }

            return isPresent;
        }

        private void SlowSetText(string textToSet)
        {
            char[] arrayOfChar = textToSet.ToCharArray();
            foreach (char c in arrayOfChar)
            {
                Keyboard.SendKeys(c.ToString());
                Playback.Wait(250);
            }

        }

        public void FixedLinesData_Adj_dataentry(ClosingDisclosureSection section)
        {
            if (section == ClosingDisclosureSection.N || section == ClosingDisclosureSection.L)
            {
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[1] = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "09/21/2012", "09/21/2013", "200.00", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[2] = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/22/2013", "10/22/2014", "600.00", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[3] = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "11/23/2014", "11/23/2015", "800", false);
            }
            else if (section == ClosingDisclosureSection.K || section == ClosingDisclosureSection.M)
            {
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[4] = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "09/21/2012", "09/21/2013", "200.00", true);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[5] = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/22/2013", "10/22/2014", "600.00", true);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[6] = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "11/23/2014", "11/23/2015", "800", true);
            }
        }

        public void DynamicLines_Adj_dataentry(ClosingDisclosureSection section)
        {
            if (section == ClosingDisclosureSection.N || section == ClosingDisclosureSection.L)
            {
                GetCharge[7] = Wind_Insurance("1Wind Insurance description", "02/22/2014", "02/22/2015", "400.00", false, section);
                
                GetCharge[8] = Flood_Insurance("2Flood Insurance description", "03/23/2014", "03/23/2015", "600.00", false, section);
                
                GetCharge[9] = Fire_Insurance("3Fire Insurance description", "04/24/2014", "04/24/2015", "800.00", false, section);
                
                GetCharge[10] = EarthQuake_Insurance("4EarthQuake description", "05/25/2014", "05/25/2015", "1600.00", false, section);

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                GetCharge[11] = homeowner_Data("HOA description", "06/26/2014", "06/26/2015", "3200.00", false, section);

                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                GetCharge[12] = Utility_Data("Utility description", "07/27/2014", "07/27/2015", "6400.00", false, section);

                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                GetCharge[5] = other_Proration_Rdata("Rents", "08/28/2014", "08/28/2015", "12600.00", false, section);

                MAmt[16] = "$" + string.Format("{0:#,##0.00}", GetCharge[6]);
                MAmt[17] = "$" + string.Format("{0:#,##0.00}", GetCharge[7]);
                MAmt[18] = "$" + string.Format("{0:#,##0.00}", GetCharge[8]);
                MAmt[19] = "$" + string.Format("{0:#,##0.00}", GetCharge[9]);
                MAmt[20] = "$" + string.Format("{0:#,##0.00}", GetCharge[10]);
                MAmt[21] = "$" + string.Format("{0:#,##0.00}", GetCharge[11]);
                MAmt[22] = "$" + string.Format("{0:#,##0.00}", GetCharge[5]);
                MAmt[23] = "$" + string.Format("{0:#,##0.00}", GetCharge[12]);

                MAmtTab2SupTotal = "$" + "$" + string.Format("{0:#,##0.00}", GetCharge[10] + GetCharge[11] + GetCharge[12] + GetCharge[5]);
            }

            else if (section == ClosingDisclosureSection.M || section == ClosingDisclosureSection.K)
            {

                GetCharge[7] = Wind_Insurance("1Wind Insurance description", "02/22/2014", "02/22/2015", "400.00", true, section);
                
                GetCharge[8] = Flood_Insurance("2Flood Insurance description", "03/23/2014", "03/23/2015", "600.00", true, section);
                
                GetCharge[9] = Fire_Insurance("3Fire Insurance description", "04/24/2014", "04/24/2015", "800.00", true, section);
                
                GetCharge[10] = EarthQuake_Insurance("4EarthQuake description", "05/25/2014", "05/25/2015", "1600.00", true, section);
                
                GetCharge[11] = homeowner_Data("HOA description", "06/26/2014", "06/26/2015", "3200.00", true, section);
                
                GetCharge[12] = Utility_Data("Utility description", "07/27/2014", "07/27/2015", "6400.00", true, section);
                
                GetCharge[5] = other_Proration_Rdata("Rents", "08/28/2014", "08/28/2015", "12600.00", true, section);

                MAmt[16] = "$" + string.Format("{0:#,##0.00}", GetCharge[6]);
                MAmt[17] = "$" + string.Format("{0:#,##0.00}", GetCharge[7]);
                MAmt[18] = "$" + string.Format("{0:#,##0.00}", GetCharge[8]);
                MAmt[19] = "$" + string.Format("{0:#,##0.00}", GetCharge[9]);
                MAmt[20] = "$" + string.Format("{0:#,##0.00}", GetCharge[10]);
                MAmt[21] = "$" + string.Format("{0:#,##0.00}", GetCharge[11]);
                MAmt[22] = "$" + string.Format("{0:#,##0.00}", GetCharge[5]);
                MAmt[23] = "$" + string.Format("{0:#,##0.00}", GetCharge[12]);

                MAmtTab2SupTotal = "$" + "$" + string.Format("{0:#,##0.00}", GetCharge[10] + GetCharge[11] + GetCharge[12] + GetCharge[5]);
            }
        }

        public void Wind_Insurance(string Desc, string Fdate, string Tdate, string Amt, int ind, ClosingDisclosureSection section)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->WindInsurance";
            FastDriver.InsuranceSummary.WaitForScreenToLoad();
            FastDriver.InsuranceSummary.Wind.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceWind.WaitForScreenToLoad();
            FastDriver.InsuranceWind.WindGABcode.FASetText("344");
            FastDriver.InsuranceWind.WindFind.FAClick();

            if (section == ClosingDisclosureSection.M)
            {
                FastDriver.InsuranceWind.WindCreditSeller.FASetCheckbox(true);
            }

            FastDriver.InsuranceWind.WindAmount.FASetText(Amt);
            FastDriver.InsuranceWind.WindFromDate.FASetText(Fdate);
            FastDriver.InsuranceWind.WindToDate.FASetText(Tdate);
            FastDriver.InsuranceWind.WindPer.FASelectItem("MONTH");

            while (true)
            {
                FastDriver.InsuranceWind.WindDescription.Click();
                Playback.Wait(500);
                FastDriver.InsuranceWind.WindDescription.FireEvent("onfocus");
                Playback.Wait(500);
                Keyboard.SendKeys("");
                Playback.Wait(500);
                //Keyboard.sendkeys(Desc);
                this.SlowSetText(Desc.Clean());
                Playback.Wait(5000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);

                if (FastDriver.InsuranceWind.WindDescription.GetAttribute("value").Clean() == Desc.Clean())
                    break;
            }

            if (section == ClosingDisclosureSection.K)
            {
                GetAmt[ind] = FastDriver.InsuranceWind.WindBuyercharge1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.M)
            {
                GetAmt[ind] = FastDriver.InsuranceWind.WindSellerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                GetAmt[ind] = FastDriver.InsuranceWind.Windbuyercredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                GetAmt[ind] = FastDriver.InsuranceWind.WindSellerCharge1.GetAttribute("value").Clean();
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);

        }

        public void EarthQuake_Insurance(string Desc, string Fdate, string Tdate, string Amt, int ind, ClosingDisclosureSection section)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->EarthQuake Insurance";
            FastDriver.InsuranceSummary.WaitForScreenToLoad();
            FastDriver.InsuranceSummary.EarthQuake.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceEarth.WaitForScreenToLoad();
            FastDriver.InsuranceEarth.EarthGABcode.FASetText("344");
            FastDriver.InsuranceEarth.EarthFind.FAClick();

            if (section == ClosingDisclosureSection.M)
            {
                FastDriver.InsuranceEarth.EarthCreditSeller.FASetCheckbox(true);
            }

            FastDriver.InsuranceEarth.EarthCalculateAmount.FASetText(Amt);
            FastDriver.InsuranceEarth.EarthCalculateFromDate.FASetText(Fdate);
            FastDriver.InsuranceEarth.EarthCalculateToDate.FASetText(Tdate);
            FastDriver.InsuranceEarth.EarthCalculatePer.FASelectItem("MONTH");

            while (true)
            {
                FastDriver.InsuranceEarth.EarthCalculateDescription.Click();
                Playback.Wait(500);
                FastDriver.InsuranceEarth.EarthCalculateDescription.FireEvent("onfocus");
                Playback.Wait(500);
                Keyboard.SendKeys("");
                Playback.Wait(500);
                this.SlowSetText(Desc.Clean());
                //                Keyboard.SendKeys(Desc);
                Playback.Wait(5000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);

                if (FastDriver.InsuranceEarth.EarthCalculateDescription.GetAttribute("value").Clean() == Desc.Clean())
                    break;
            }

            if (section == ClosingDisclosureSection.M)
            {
                GetAmt[ind] = FastDriver.InsuranceEarth.EarthSellerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                GetAmt[ind] = FastDriver.InsuranceEarth.EarthBuyerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                GetAmt[ind] = FastDriver.InsuranceEarth.EarthSellerCharge1.GetAttribute("value").Clean();
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);
        }

        public void Flood_Insurance(string Desc, string Fdate, string Tdate, string Amt, int ind, ClosingDisclosureSection section)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->flood Insurance";
            FastDriver.InsuranceSummary.WaitForScreenToLoad();
            FastDriver.InsuranceSummary.Flood.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.Insuranceflood.WaitForScreenToLoad();
            FastDriver.Insuranceflood.FloodGABcode.FASetText("344");
            FastDriver.Insuranceflood.FloodFind.FAClick();

            if (section == ClosingDisclosureSection.M)
            {
                FastDriver.Insuranceflood.FloodCreditSeller.FASetCheckbox(true);
            }

            FastDriver.Insuranceflood.FloodAmount.FASetText(Amt);
            FastDriver.Insuranceflood.FloodFromDate.FASetText(Fdate);
            FastDriver.Insuranceflood.FloodToDate.FASetText(Tdate);
            FastDriver.Insuranceflood.FloodPer.FASelectItem("MONTH");

            while (true)
            {
                FastDriver.Insuranceflood.FloodDescription.Click();
                Playback.Wait(500);
                FastDriver.Insuranceflood.FloodDescription.FireEvent("onfocus");
                Playback.Wait(500);
                Keyboard.SendKeys("");
                Playback.Wait(500);
                this.SlowSetText(Desc.Clean());
                //                Keyboard.SendKeys(Desc);
                Playback.Wait(5000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);

                if (FastDriver.Insuranceflood.FloodDescription.GetAttribute("value").Clean() == Desc.Clean())
                    break;
            }

            if (section == ClosingDisclosureSection.M)
            {
                GetAmt[ind] = FastDriver.Insuranceflood.FloodSellerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                GetAmt[ind] = FastDriver.Insuranceflood.FloodBuyercredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                GetAmt[ind] = FastDriver.Insuranceflood.FloodSellerCharge1.GetAttribute("value").Clean();
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);
        }

        public void Fire_Insurance(string Desc, string Fdate, string Tdate, string Amt, int ind, ClosingDisclosureSection section)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->fire Insurance";
            FastDriver.InsuranceSummary.WaitForScreenToLoad();
            FastDriver.InsuranceSummary.Fire.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceFire.WaitForScreenToLoad();
            FastDriver.InsuranceFire.FireGABcode.FASetText("344");
            FastDriver.InsuranceFire.FireFind.FAClick();

            if (section == ClosingDisclosureSection.M)
            {
                FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(true);
            }

            FastDriver.InsuranceFire.FireAmount.FASetText(Amt);
            FastDriver.InsuranceFire.FireFromDate.FASetText(Fdate);
            FastDriver.InsuranceFire.FireToDate.FASetText(Tdate);
            FastDriver.InsuranceFire.FirePer.FASelectItem("MONTH");

            while (true)
            {
                FastDriver.InsuranceFire.FireDescription.Click();
                Playback.Wait(500);
                FastDriver.InsuranceFire.FireDescription.FireEvent("onfocus");
                Playback.Wait(500);
                Keyboard.SendKeys("");
                Playback.Wait(500);
                this.SlowSetText(Desc.Clean());
                //           Keyboard.SendKeys(Desc);
                Playback.Wait(5000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);

                if (FastDriver.InsuranceFire.FireDescription.GetAttribute("value").Clean() == Desc.Clean())
                    break;
            }

            if (section == ClosingDisclosureSection.M)
            {
                GetAmt[ind] = FastDriver.InsuranceFire.FireSellerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                GetAmt[ind] = FastDriver.InsuranceFire.FireBuyerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                GetAmt[ind] = FastDriver.InsuranceFire.FireSellerCharge1.GetAttribute("value").Clean();
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);
        }

        public String Wind_Insurance(string Desc, string Fdate, string Tdate, string Amt, bool CreditSellerChk, ClosingDisclosureSection section)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->WindInsurance";
            FastDriver.InsuranceSummary.WaitForScreenToLoad();
            FastDriver.InsuranceSummary.Wind.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceWind.WaitForScreenToLoad();
            FastDriver.InsuranceWind.WindGABcode.FASetText("344");
            FastDriver.InsuranceWind.WindFind.FAClick();

            if (CreditSellerChk && (section == ClosingDisclosureSection.K || section == ClosingDisclosureSection.M))
            {
                FastDriver.InsuranceWind.WindCreditSeller.FASetCheckbox(true);
            }
            else if (!CreditSellerChk && (section == ClosingDisclosureSection.L || section == ClosingDisclosureSection.N))
            {
                string getAmt = FastDriver.InsuranceWind.WindAmount.GetAttribute("value").Clean();

                if (FastDriver.InsuranceWind.WindCreditSeller.Selected)
                {
                    FastDriver.InsuranceWind.WindCreditSeller.FASetCheckbox(false);
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
            }
            FastDriver.InsuranceWind.WindAmount.FASetText(Amt);
            FastDriver.InsuranceWind.WindFromDate.FASetText(Fdate);
            FastDriver.InsuranceWind.WindToDate.FASetText(Tdate);
            FastDriver.InsuranceWind.WindPer.FASelectItem("MONTH");

            while (true)
            {
                FastDriver.InsuranceWind.WindDescription.Click();
                Playback.Wait(500);
                FastDriver.InsuranceWind.WindDescription.FireEvent("onfocus");
                Playback.Wait(500);
                Keyboard.SendKeys("");
                Playback.Wait(500);
                this.SlowSetText(Desc.Clean());
                Playback.Wait(5000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);

                if (FastDriver.InsuranceWind.WindDescription.GetAttribute("value").Clean() == Desc.Clean())
                    break;
            }

            if (section == ClosingDisclosureSection.K)
            {
                ret_Amt = FastDriver.InsuranceWind.WindBuyercharge1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.M)
            {
                ret_Amt = FastDriver.InsuranceWind.WindSellerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                ret_Amt = FastDriver.InsuranceWind.Windbuyercredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                ret_Amt = FastDriver.InsuranceWind.WindSellerCharge1.GetAttribute("value").Clean();
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);

            return (ret_Amt);
        }

        public String Flood_Insurance(string Desc, string Fdate, string Tdate, string Amt, bool CreditSellerChk, ClosingDisclosureSection section)
        {
            Reports.TestStep = "Creating Proration charges in Escrow charge->flood Insurance";
            FastDriver.InsuranceSummary.WaitForScreenToLoad();
            FastDriver.InsuranceSummary.Flood.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.Insuranceflood.WaitForScreenToLoad();
            FastDriver.Insuranceflood.FloodGABcode.FASetText("344");
            FastDriver.Insuranceflood.FloodFind.FAClick();

            if (section == ClosingDisclosureSection.M)
            {
                FastDriver.Insuranceflood.FloodCreditSeller.FASetCheckbox(true);
            }
            else if (!CreditSellerChk && (section == ClosingDisclosureSection.L || section == ClosingDisclosureSection.N))
            {
                string getAmt = FastDriver.Insuranceflood.FloodAmount.GetAttribute("value").Clean();

                if (FastDriver.Insuranceflood.FloodCreditSeller.Selected)
                {
                    FastDriver.Insuranceflood.FloodCreditSeller.FASetCheckbox(false);
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
            }

            FastDriver.Insuranceflood.FloodAmount.FASetText(Amt);
            FastDriver.Insuranceflood.FloodFromDate.FASetText(Fdate);
            FastDriver.Insuranceflood.FloodToDate.FASetText(Tdate);
            FastDriver.Insuranceflood.FloodPer.FASelectItem("MONTH");

            while (true)
            {
                FastDriver.Insuranceflood.FloodDescription.Click();
                Playback.Wait(500);
                FastDriver.Insuranceflood.FloodDescription.FireEvent("onfocus");
                Playback.Wait(500);
                Keyboard.SendKeys("");
                Playback.Wait(500);
                this.SlowSetText(Desc.Clean());
                Playback.Wait(1000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);

                if (FastDriver.Insuranceflood.FloodDescription.GetAttribute("value").Clean() == Desc.Clean())
                    break;
            }

            if (section == ClosingDisclosureSection.K)
            {
                ret_Amt = FastDriver.Insuranceflood.FloodBuyercharge1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.M)
            {
                ret_Amt = FastDriver.Insuranceflood.FloodSellerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                ret_Amt = FastDriver.Insuranceflood.FloodBuyercredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                ret_Amt = FastDriver.Insuranceflood.FloodSellerCharge1.GetAttribute("value").Clean();
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);

            return (ret_Amt);
        }

        public String Fire_Insurance(string Desc, string Fdate, string Tdate, string Amt, bool CreditSellerChk, ClosingDisclosureSection section)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->fire Insurance";
            FastDriver.InsuranceSummary.WaitForScreenToLoad();
            FastDriver.InsuranceSummary.Fire.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceFire.WaitForScreenToLoad();
            FastDriver.InsuranceFire.FireGABcode.FASetText("344");
            FastDriver.InsuranceFire.FireFind.FAClick();

            if (section == ClosingDisclosureSection.M || section == ClosingDisclosureSection.K)
            {
                FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(true);
            }
            else if (!CreditSellerChk && (section == ClosingDisclosureSection.L || section == ClosingDisclosureSection.N))
            {
                string getAmt = FastDriver.InsuranceFire.FireAmount.GetAttribute("value").Clean();

                if (FastDriver.InsuranceFire.FireCreditSeller.Selected)
                {
                    FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(false);
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
            }

            FastDriver.InsuranceFire.FireAmount.FASetText(Amt);
            FastDriver.InsuranceFire.FireFromDate.FASetText(Fdate);
            FastDriver.InsuranceFire.FireToDate.FASetText(Tdate);
            FastDriver.InsuranceFire.FirePer.FASelectItem("MONTH");

            while (true)
            {
                FastDriver.InsuranceFire.FireDescription.Click();
                Playback.Wait(500);
                FastDriver.InsuranceFire.FireDescription.FireEvent("onfocus");
                Playback.Wait(500);
                Keyboard.SendKeys("");
                Playback.Wait(500);
                this.SlowSetText(Desc.Clean());
                Playback.Wait(1000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);

                if (FastDriver.InsuranceFire.FireDescription.GetAttribute("value").Clean() == Desc.Clean())
                    break;
            }

            if (section == ClosingDisclosureSection.K)
            {
                ret_Amt = FastDriver.InsuranceFire.FireBuyerCharge1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.M)
            {
                ret_Amt = FastDriver.InsuranceFire.FireSellerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                ret_Amt = FastDriver.InsuranceFire.FireBuyerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                ret_Amt = FastDriver.InsuranceFire.FireSellerCharge1.GetAttribute("value").Clean();
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);

            return (ret_Amt);
        }

        public String EarthQuake_Insurance(string Desc, string Fdate, string Tdate, string Amt, bool CreditSellerChk, ClosingDisclosureSection section)
        {
            Reports.TestStep = "Creating Proration charges in Escrow charge->EarthQuake Insurance";
            FastDriver.InsuranceSummary.WaitForScreenToLoad();
            FastDriver.InsuranceSummary.EarthQuake.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceEarth.WaitForScreenToLoad();
            FastDriver.InsuranceEarth.EarthGABcode.FASetText("344");
            FastDriver.InsuranceEarth.EarthFind.FAClick();

            if (section == ClosingDisclosureSection.M)
            {
                FastDriver.InsuranceEarth.EarthCreditSeller.FASetCheckbox(true);
            }
            else if (!CreditSellerChk && (section == ClosingDisclosureSection.L || section == ClosingDisclosureSection.N))
            {
                string getAmt = FastDriver.InsuranceEarth.EarthCalculateAmount.GetAttribute("value").Clean();

                if (FastDriver.InsuranceEarth.EarthCreditSeller.Selected)
                {
                    FastDriver.InsuranceEarth.EarthCreditSeller.FASetCheckbox(false);
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                }
            }

            FastDriver.InsuranceEarth.EarthCalculateAmount.FASetText(Amt);
            FastDriver.InsuranceEarth.EarthCalculateFromDate.FASetText(Fdate);
            FastDriver.InsuranceEarth.EarthCalculateToDate.FASetText(Tdate);
            FastDriver.InsuranceEarth.EarthCalculatePer.FASelectItem("MONTH");

            while (true)
            {
                FastDriver.InsuranceEarth.EarthCalculateDescription.Click();
                Playback.Wait(500);
                FastDriver.InsuranceEarth.EarthCalculateDescription.FireEvent("onfocus");
                Playback.Wait(500);
                Keyboard.SendKeys("");
                Playback.Wait(500);
                this.SlowSetText(Desc.Clean());
                Playback.Wait(1000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(2000);

                if (FastDriver.InsuranceEarth.EarthCalculateDescription.GetAttribute("value").Clean() == Desc.Clean())
                    break;
            }

            if (section == ClosingDisclosureSection.K)
            {
                ret_Amt = FastDriver.InsuranceEarth.EarthBuyerCharge1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.M)
            {
                ret_Amt = FastDriver.InsuranceEarth.EarthSellerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                ret_Amt = FastDriver.InsuranceEarth.EarthBuyerCredit1.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                ret_Amt = FastDriver.InsuranceEarth.EarthSellerCharge1.GetAttribute("value").Clean();
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);

            return (ret_Amt);
        }

        private String homeowner_Data(string Desc, string Fdate, string Tdate, string Amt, bool CreditSellerChk, ClosingDisclosureSection section)
        {
            FastDriver.HomeownerAssociation.FindGABCode("344");
            Playback.Wait(2000);

            if (CreditSellerChk && (section == ClosingDisclosureSection.K || section == ClosingDisclosureSection.M))
            {
                FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(true);
            }
            FastDriver.HomeownerAssociation.Per.FASelectItem("MONTH");
            FastDriver.HomeownerAssociation.ProrationAmount.FASetText(Amt);
            FastDriver.HomeownerAssociation.FromDate.FASetText(Fdate);
            FastDriver.HomeownerAssociation.ToDate.FASetText(Tdate);
            FastDriver.HomeownerAssociation.ProrationDescription.FAClick();
            FastDriver.HomeownerAssociation.ProrationDescription.SendKeys(Desc);

            if (section == ClosingDisclosureSection.K)
            {
                ret_Amt = FastDriver.HomeownerAssociation.ProrationBuyerCharge.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.M)
            {
                ret_Amt = FastDriver.HomeownerAssociation.ProrationSellerCredit.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                ret_Amt = FastDriver.HomeownerAssociation.ProrationBuyerCredit.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                ret_Amt = FastDriver.HomeownerAssociation.ProrationSellerCharge.GetAttribute("value").Clean();
            }

            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);

            return (ret_Amt);
        }

        private String Utility_Data(string Desc, string Fdate, string Tdate, string Amt, bool CreditSellerChk, ClosingDisclosureSection section)
        {
            FastDriver.UtilityDetail.SwitchToContentFrame();
            FastDriver.UtilityDetail.FindGABcode("344");

            if (CreditSellerChk && (section == ClosingDisclosureSection.K || section == ClosingDisclosureSection.M))
            {
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
            }
            FastDriver.UtilityDetail.Per.FASelectItem("MONTH");
            FastDriver.UtilityDetail.ProrationAmount.FASetText(Amt.Trim());
            FastDriver.UtilityDetail.FromDate.FASetText(Fdate);
            FastDriver.UtilityDetail.ToDate.FASetText(Tdate);
            FastDriver.UtilityDetail.ProrationDescription.FAClick();
            FastDriver.UtilityDetail.ProrationDescription.SendKeys(Desc);
            Playback.Wait(2000);

            if (section == ClosingDisclosureSection.K)
            {
                ret_Amt = FastDriver.UtilityDetail.ProrationBuyerCharge.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.M)
            {
                ret_Amt = FastDriver.UtilityDetail.ProrationSellerCredit.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                ret_Amt = FastDriver.UtilityDetail.ProrationBuyerCredit.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                ret_Amt = FastDriver.UtilityDetail.ProrationSellerCharge.GetAttribute("value").Clean();
            }

            Keyboard.SendKeys("^D");
            Playback.Wait(3000);

            return (ret_Amt);
        }

        private String other_Proration_Rdata(string Desc, string Fdate, string Tdate, string Amt, bool CreditSellerChk, ClosingDisclosureSection section)
        {
            FastDriver.ProrationTax.WaitForScreenToLoad();
            FastDriver.ProrationTax.New.FAClick();
            Playback.Wait(250);
            FastDriver.ProrationDetail.WaitForScreenToLoad();
            if (CreditSellerChk && (section == ClosingDisclosureSection.K || section == ClosingDisclosureSection.M))
                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
            FastDriver.ProrationDetail.Per.FASelectItem("MONTH");
            FastDriver.ProrationDetail.Amount.FASetText(Amt);
            FastDriver.ProrationDetail.FromDate.FASetText(Fdate);
            FastDriver.ProrationDetail.ToDate.FASetText(Tdate);
            FastDriver.ProrationDetail.Description.FASetText(Desc);

            if (section == ClosingDisclosureSection.K)
            {
                ret_Amt = FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.M)
            {
                ret_Amt = FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.L)
            {
                ret_Amt = FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").Clean();
            }
            if (section == ClosingDisclosureSection.N)
            {
                ret_Amt = FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean();
            }

            Keyboard.SendKeys("^D");

            return (ret_Amt);
        }

        public void Supp_Charge_Verification(int ct1, bool isSectionN)
        {
            int asc = 96;
            IWebElement CdCell;
            IWebElement table;
            if (isSectionN)
                table = FastDriver.ClosingDisclosure.SectionN_AdjustmentforItemsSubTable;
            else
                table = FastDriver.ClosingDisclosure.SectionL_DueItemsTable_AdjustmentsForItems;

            if (isSectionN)
            {
                int rows = table.GetRowCount();
                int cols = 7;
                for (int i = 4; i < rows; i++)
                {
                    ct1 = ct1 + 1;

                    if (ct1 < 19)
                        Reports.TestStep = "verifying line " + ct1 + " of section N";
                    if (ct1 > 19)
                    {
                        int ct2 = 19;
                        asc = asc + 1;
                        char c = (char)asc;
                        sct1 = ct2.ToString() + c;
                        Reports.TestStep = "verifying supplementary charge for line " + sct1 + " of section N";
                    }

                    if ((ct1 < 19) || (ct1 > 19))
                    {
                        for (int j = 0; j < cols; j++)
                        {
                            switch (j)
                            {
                                case 0: CdCell = table.PerformTableAction((i + 1), (j + 1), TableAction.GetCell).Element;
                                  //  Debug.Print("La celda caso 0: " + CdCell.Text);
                                    string val = CdCell.Text;
                                    string[] val1 = val.Split();
                                    string val2 = val1[0];

                                    if (ct1 < 19)
                                    {
                                        if (val2 == ct1.ToString())
                                            Reports.StatusUpdate("the value line no is verifed." + "Actual=" + val2 + " Expected=" + (ct1.ToString()) + " ", true);
                                        else
                                            Reports.StatusUpdate("the value not matching." + "Actual=" + val2 + " Expected=" + (ct1.ToString()) + " ", false);
                                    }
                                    if (ct1 > 19)
                                    {
                                        if (sct1 == val2)
                                            Reports.StatusUpdate("the value line no is verifed." + "Actual=" + val2 + " Expected=" + sct1 + " ", true);
                                        else
                                            Reports.StatusUpdate("the value not matching." + "Actual=" + val2 + " Expected=" + sct1 + " ", false);
                                    }
                                    break;

                                case 1: CdCell = table.PerformTableAction((i + 1), (j + 1), TableAction.GetCell).Element.FindElements(By.CssSelector("span[contenteditable]"))
                                    .FirstOrDefault(z => z.Displayed);
                                    //Debug.Print("El Span caso 1: " + CdCell.Text);
                                    //string s1 = CdCell.GetAttribute("value").Clean();
                                    string s1 = CdCell.Text.Clean();
                                    if (ct1 == 19)
                                        break;
                                    if (ct1 > 19)
                                    {
                                        if (s1.Trim() == Desc[i - 5].Clean())
                                            Reports.StatusUpdate("the value desc is verifed." + "Actual=" + s1 + " Expected=" + Desc[i - 5], true);
                                        else
                                            Reports.StatusUpdate("the value Description not matching." + "Actual=" + s1 + " Expected=" + Desc[i - 5], false);
                                    }
                                    if (ct1 < 19)
                                    {
                                        if (s1.Trim() == Desc[i - 4].Clean())
                                            Reports.StatusUpdate("the value desc is verifed." + "Actual=" + s1 + " Expected=" + Desc[i - 4], true);
                                        else
                                            Reports.StatusUpdate("the value Description not matching." + "Actual=" + s1 + " Expected=" + Desc[i - 4], false);
                                    }
                                    break;

                                case 2: CdCell = table.PerformTableAction((i + 1), (j + 1), TableAction.GetCell).Element;
                                   // Debug.Print("La celda caso 2: " + CdCell.Text);
                                    if (ct1 == 19)
                                        break;
                                    else if (ct1 > 19)
                                    {
                                        if (CdCell.Text.Clean() == Fdate[i - 5])
                                            Reports.StatusUpdate("the value from date  is verifed." + "Actual=" + CdCell.Text.Clean() + " Expected=" + Fdate[i - 5] + " ", true);
                                        else
                                            Reports.StatusUpdate("the value from date not matching ." + "Actual=" + CdCell.Text.Clean() + " Expected=" + Fdate[i - 5] + " ", false);
                                    }
                                    else
                                    {
                                        if (CdCell.Text.Clean() == Fdate[i - 4])
                                            Reports.StatusUpdate("the value from date  is verifed." + "Actual=" + CdCell.Text.Clean() + " Expected=" + Fdate[i - 4] + " ", true);
                                        else
                                            Reports.StatusUpdate("the value from date not matching ." + "Actual=" + CdCell.Text.Clean() + " Expected=" + Fdate[i - 4] + " ", false);
                                    }
                                    break;

                                case 4: CdCell = table.PerformTableAction((i + 1), (j + 1), TableAction.GetCell).Element;
                                    //Debug.Print("La celda caso 4: " + CdCell.Text);
                                    if (ct1 == 19)
                                        break;
                                    else if (ct1 > 19)
                                    {
                                        if (CdCell.Text.Clean() == Tdate[i - 5])
                                            Reports.StatusUpdate("the value To date  is verifed." + "Actual=" + CdCell.Text.Clean() + " Expected=" + Tdate[i - 5] + " ", true);
                                        else
                                            Reports.StatusUpdate("the value To date not matching ." + "Actual=" + CdCell.Text.Clean() + " Expected=" + Tdate[i - 5] + " ", false);
                                    }
                                    else
                                    {
                                        if (CdCell.Text.Clean() == Tdate[i - 4])
                                            Reports.StatusUpdate("the value To date  is verifed." + "Actual=" + CdCell.Text.Clean() + " Expected=" + Tdate[i - 4] + " ", true);
                                        else
                                            Reports.StatusUpdate("the value To date not matching ." + "Actual=" + CdCell.Text.Clean() + " Expected=" + Tdate[i - 4] + " ", false);
                                    }
                                    break;
                                case 6: CdCell = table.PerformTableAction((i + 1), (j + 1), TableAction.GetCell).Element;
                                   // Debug.Print("La celda caso 6: " + CdCell.Text);
                                    if (ct1 == 19)
                                        break;
                                    if (ct1 > 19)
                                    {
                                        FinalAmt[i - 1] = "$" + GetAmt[i - 1];
                                        if (CdCell.Text.Clean() == FinalAmt[i - 1])
                                            Reports.StatusUpdate("the value amt is verifed." + "Actual=" + CdCell.Text.Clean() + " Expected=" + FinalAmt[i - 1] + " ", true);
                                        else
                                            Reports.StatusUpdate("the value amt not matching ." + "Actual=" + CdCell.Text.Clean() + " Expected=" + FinalAmt[i - 1] + " ", false);
                                    }
                                    if (ct1 < 19)
                                    {
                                        FinalAmt[i] = "$" + GetAmt[i];
                                        if (CdCell.Text.Clean() == FinalAmt[i].Trim())
                                            Reports.StatusUpdate("the value amt is verifed." + "Actual=" + CdCell.Text.Clean() + " Expected=" + FinalAmt[i] + " ", true);
                                        else
                                            Reports.StatusUpdate("the value amt not matching ." + "Actual=" + CdCell.Text.Clean() + " Expected=" + FinalAmt[i] + " ", false);
                                    }
                                    break;
                            }

                        }
                    }
                    Reports.StatusUpdate(" ", true);
                }
            }


        }

        private void homeowner_Data(string Desc, string Fdate, string Tdate, string Amt, int ind, String SectionName)
        {
            FastDriver.HomeownerAssociation.FindGABCode("344");
            Playback.Wait(2000);

            if (SectionName == "Section M")
            {
                FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(true);
            }
            FastDriver.HomeownerAssociation.Per.FASelectItem("MONTH");
            FastDriver.HomeownerAssociation.ProrationAmount.FASetText(Amt);
            FastDriver.HomeownerAssociation.FromDate.FASetText(Fdate);
            FastDriver.HomeownerAssociation.ToDate.FASetText(Tdate);
            FastDriver.HomeownerAssociation.ProrationDescription.FAClick();
            FastDriver.HomeownerAssociation.ProrationDescription.SendKeys(Desc);

            if (SectionName == "Section M")
            {
                Seller_Credit[ind] = FastDriver.HomeownerAssociation.ProrationSellerCredit.Text;
                GetAmt[ind] = FastDriver.HomeownerAssociation.ProrationSellerCredit.Text;
                sum = sum + double.Parse(Seller_Credit[ind]);

            }

            if (SectionName == "Section L")
            {
                Buyer_Credit[ind] = FastDriver.HomeownerAssociation.ProrationBuyerCredit.GetAttribute("value").Clean();
                GetAmt[ind] = FastDriver.HomeownerAssociation.ProrationBuyerCredit.GetAttribute("value").Clean();
                sum = sum + double.Parse(Buyer_Credit[ind]);
            }

            if (SectionName == "Section N")
            {
                Seller_Charge[ind] = FastDriver.HomeownerAssociation.ProrationSellerCharge.FAGetValue();
                GetAmt[ind] = Seller_Charge[ind] = FastDriver.HomeownerAssociation.ProrationSellerCharge.FAGetValue();
                sum = sum + double.Parse(Seller_Charge[ind].Trim());
            }
            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);
        }


        private void Utility_Data(string Desc, string Fdate, string Tdate, string Amt, int ind, String SectionName)
        {
            FastDriver.UtilityDetail.SwitchToContentFrame();
            FastDriver.UtilityDetail.FindGABcode("344");
            //FastDriver.UtilityDetail.WaitForValue(FastDriver.UtilityDetail.GabCodeLabel, "344");
            Playback.Wait(2000);
            //FastDriver.UtilityDetail.SwitchToContentFrame();
            if (SectionName == "Section M")
            {
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
            }
            FastDriver.UtilityDetail.Per.FASelectItem("MONTH");
            FastDriver.UtilityDetail.ProrationAmount.FASetText(Amt.Trim());
            FastDriver.UtilityDetail.FromDate.FASetText(Fdate);
            FastDriver.UtilityDetail.ToDate.FASetText(Tdate);
            FastDriver.UtilityDetail.ProrationDescription.FAClick();
            FastDriver.UtilityDetail.ProrationDescription.SendKeys(Desc);
            Playback.Wait(2000);

            if (SectionName == "Section M")
            {
                Seller_Credit[ind] = FastDriver.UtilityDetail.ProrationSellerCredit.Text;
                GetAmt[ind] = FastDriver.UtilityDetail.ProrationSellerCredit.Text;
                sum = sum + double.Parse(Seller_Credit[ind]);
            }

            if (SectionName == "Section L")
            {
                Buyer_Credit[ind] = FastDriver.UtilityDetail.ProrationSellerCharge.Text;
                GetAmt[ind] = FastDriver.UtilityDetail.ProrationBuyerCredit.Text;
            }

            if (SectionName == "Section N")
            {
                Seller_Charge[ind] = FastDriver.UtilityDetail.ProrationSellerCharge.FAGetValue();
                GetAmt[ind] = FastDriver.UtilityDetail.ProrationSellerCharge.GetAttribute("value").Clean();
                Debug.Print("THe Value of Seller_Charge[ind] is:   " + Seller_Charge[ind].Trim());
                sum = sum + double.Parse(Seller_Charge[ind].Trim());
            }
            Keyboard.SendKeys("^D");
            Playback.Wait(4000);
        }


        private void other_Proration_data(string Desc, string Fdate, string Tdate, string Amt, String SectionName, int pos)
        {
            FastDriver.ProrationDetail.SwitchToContentFrame();
            if (SectionName == "Section M")
                FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);
            FastDriver.ProrationDetail.Per.FASelectItem("MONTH");
            FastDriver.ProrationDetail.Amount.FASetText(Amt);
            FastDriver.ProrationDetail.FromDate.FASetText(Fdate);
            FastDriver.ProrationDetail.ToDate.FASetText(Tdate);
            FastDriver.ProrationDetail.Description.FASetText(Desc);

            if (SectionName == "Section L")
            {
                GetAmt[pos] = FastDriver.ProrationDetail.BuyerCredit.Text;
            }

            if (SectionName == "Section N")
            {
                GetAmt[pos] = FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").Clean();
            }

            if (SectionName == "Section M")
            {
                GetAmt[pos] = FastDriver.ProrationDetail.SellerCredit.Text;
            }
            Keyboard.SendKeys("^D");

        }


        private void Login()
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            //
            //

            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
        }
        private void CreateFileWithWCF()
        {
            string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
        }
        private void AssumpLoanDtlsFindGABCode(string gabCode)
        {
            //Navigates to Assumption Loan screen, switches to content frame and finds a given GAB Code; 
            FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Assumption Loan").SwitchToContentFrame();
            Playback.Wait(500);
            FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText(gabCode);
            FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
            Playback.Wait(500);
            FastDriver.BottomFrame.Done();
            FastDriver.BottomFrame.SwitchToContentFrame();
        }
        private void PayOfflFindGABCode(string gabCode)
        {
            FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan").SwitchToContentFrame();
            FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(gabCode);
            FastDriver.PayoffLoanDetails.LenderFind.FAClick();
            Playback.Wait(1000);
            //FastDriver.BottomFrame.Done();
            //Playback.Wait(800);
            //FastDriver.BottomFrame.SwitchToContentFrame();


        }
        private void LoadAssumLoanChgChargesTab()
        {
            //Clicks on AssumptionLoanCharges.chargesTab,waits for dialog to disappear and switches back to the Content Frame;
            FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
            FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
            Playback.Wait(500);
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
            Playback.Wait(3000);
            FastDriver.PayoffLoanCharges.SwitchToContentFrame();
        }

        private void LoadPayoffLoanChargesTab()
        {

            FastDriver.PayoffLoanDetails.SwitchToContentFrame();
            FastDriver.PayoffLoanCharges.ChargesTab.FAClick();
            Playback.Wait(1000);
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
            Playback.Wait(1000);
            FastDriver.PayoffLoanCharges.SwitchToContentFrame();
        }

        private void ALchPaymentDetailsDlgFill(string sellerCharge, string sellerAtClosing, string sellerBeforeClosing, string paidBySellerOthers, string sellerCredit, string SellerPaidByOthersPaymentMethod)
        {
            if (!sellerCharge.Equals(""))
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText(sellerCharge);
            Playback.Wait(500);

            FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");

            FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

            if (!sellerAtClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(sellerAtClosing);

            if (!sellerBeforeClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(sellerBeforeClosing);

            if (!paidBySellerOthers.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(paidBySellerOthers);

            if (!sellerCredit.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText(sellerCredit);

            if (!SellerPaidByOthersPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(SellerPaidByOthersPaymentMethod);
            //closes the dialog window and switches back to the Fast window;
            FastDriver.PaymentDetailsNewLoanDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.btnDone.FAClick();
            Playback.Wait(500);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.PaymentDetailsDlg.SwitchToContentFrame();
        }
        private void ALchUNPaymentDetailsDlgFill(string sellerCharge, string sellerAtClosing, string sellerBeforeClosing, string paidBySellerOthers, string sellerCredit, string SellerPaidByOthersPaymentMethod)
        {
            FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FASetText(sellerCharge);
            FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesPaymentDetails.FAClick();

            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");

            FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

            if (!sellerAtClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(sellerAtClosing);

            if (!sellerBeforeClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(sellerBeforeClosing);

            if (!paidBySellerOthers.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(paidBySellerOthers);

            if (!sellerCredit.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText(sellerCredit);

            if (!SellerPaidByOthersPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(SellerPaidByOthersPaymentMethod);
            //closes the dialog window and switches back to the Fast window;
            FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.btnDone.FAClick();
            Playback.Wait(5000);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            // FastDriver.PaymentDetailsDlg.SwitchToContentFrame();
        }

        private void ClickOnSummaryOftrans()
        {
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(500);
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(5000);
            FastDriver.ClosingDisclosure.SwitchToContentFrame();
        }
        private void ValidateN03PopUpFull(string N03Label, string N03SeqNo, string N03Description, string N03Amt, string N03SeqNo1, string N03ChargeDesc1, string N03TotalChargeAmt1, string N03ChargeDesc2, string N03ChargeAmt2, string N03ChargeDesc3, string N03ChargeAmt3, string N03SeqNo3)
        {
            //    FastDriver.ClosingDisclosure.SectionN03_Seqno.FAClick();
            //    //N03Plus
            //    FastDriver.WebDriver.FindElement(By.Id("divImgGroupChargeN3")).FAClick();

            //N03Label
            if (!N03Label.Equals(""))
                Support.AreEqual(N03Label, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3Heading1")).Text.Trim());

            //N03SeqNo
            if (!N03SeqNo.Equals(""))
                Support.AreEqual(N03SeqNo, FastDriver.ClosingDisclosure.SectionN03_Seqno.Text.Trim());

            //N03Description
            if (!N03Description.Equals(""))
                Support.AreEqual(N03Description, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3Desc")).Text.Trim());

            //N03Amt
            if (!N03Amt.Equals(""))
                Support.AreEqual(N03Amt, FastDriver.ClosingDisclosure.SectionN03_Amt.Text.Trim());

            //N03SeqNo1
            if (!N03SeqNo1.Equals(""))
                Support.AreEqual(N03SeqNo1, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_SubSeqNo1")).Text.Trim());

            //N03ChargeDesc1
            if (!N03ChargeDesc1.Equals(""))
                Support.AreEqual(N03ChargeDesc1, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Desc1")).Text.Trim());

            if (!N03TotalChargeAmt1.Equals(""))
                //N03TotalChargeAmt1
                Support.AreEqual(N03TotalChargeAmt1, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_SubTotalAmt1")).Text.Trim());

            //N03ChargeDesc2
            if (!N03ChargeDesc2.Equals(""))
                Support.AreEqual(N03ChargeDesc2, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Desc2")).Text.Trim());

            //N03ChargeAmt2
            if (!N03ChargeAmt2.Equals(""))
                Support.AreEqual(N03ChargeAmt2, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Amt12")).Text.Trim());

            //N03ChargeDesc3
            if (!N03ChargeDesc3.Equals(""))
                Support.AreEqual(N03ChargeDesc3, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Desc3")).Text.Trim());

            //N03ChargeAmt3
            if (!N03ChargeAmt3.Equals(""))
                Support.AreEqual(N03ChargeAmt3, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_Amt13")).Text.Trim());

            //N03SeqNo3
            if (!N03SeqNo3.Equals(""))
                Support.AreEqual(N03SeqNo3, FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("N3SubCharge_SubSeqNo3")).Text.Trim());

            FastDriver.WebDriver.FindElements(OpenQA.Selenium.By.Id("btnSummaryChargePopUpDone")).GetAllVisible().First().FAClick();
           // FastDriver.ClosingDisclosure.SwitchToDialogContentFrame();
            //FastDriver.CDL04Popup.Done.FAClick();
                 //FastDriver.ClosingDisclosure.PopUpDone.FAClick();
            //FastDriver.ClosingDisclosure.SwitchToContentFrame();

        }
        private void Done()
        {
            Reports.TestStep = "Saving the CD Screen";
            FastDriver.BottomFrame.Done();
        }
        private void CLickToValidateN03PopUp()
        {
            FastDriver.ClosingDisclosure.SwitchToContentFrame();
            FastDriver.ClosingDisclosure.SectionN03_Seqno.FAClick();
            FastDriver.WebDriver.FindElement(By.Id("divImgGroupChargeN3")).FAClick();
        }

        private void SetPayoffCharge(string chargeRow, string chargeColumn, string chargeToSet)
        {
            IWebElement inputElement1 = FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction("Description", chargeRow, chargeColumn, TableAction.SetText, chargeToSet).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
            Playback.Wait(250);
            Keyboard.SendKeys(FAKeys.TabAway);
            Playback.Wait(250);
            inputElement1.Click();
            Playback.Wait(250);

        }
        private void CreateBuyerSellerBroker()
        {

            Reports.TestStep = "Creating Buyer and seller Broker Instance";
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            FastDriver.RealEstateBrokerAgentSummary.Name.FAClick();
            FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            FastDriver.RealEstateBrokerAgent.FindGAB("247");
            FastDriver.BottomFrame.Done();
            FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
            FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
            FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            FastDriver.RealEstateBrokerAgent.FindGAB("248");
            FastDriver.BottomFrame.Done();

        }
        private void ClickOnNewLoanChargeTab()
        {
            FastDriver.NewLoan.SwitchToContentFrame();
            FastDriver.NewLoan.LoanChargesTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            FastDriver.NewLoan.SwitchToContentFrame();
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
        }

        private bool chargeAvailability(string tableId, string chargeDesc)
        {
            IWebElement table = FastDriver.WebDriver.FindElement(By.Id(tableId));
            int filterrowcount = table.GetRowCount();
            bool isPresent = false;

            for (int i = 1; i < filterrowcount; i++)
            {
                string chargeid;
                int l = i - 1;

                chargeid = tableId + "_" + l + "_tdsc";
                var NewLoantbledit = FastDriver.WebDriver.FindElement(By.Id(chargeid));
                string desc = NewLoantbledit.GetAttribute("value").ToString().Trim();
                if (desc == chargeDesc)
                {
                    isPresent = true;
                    break;
                }

            }

            return isPresent;
        }
        private void AddCharge(PageObject pageObject, IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            pageObject.SwitchToContentFrame();
            pageObject.WaitCreation(chargesTable, 10);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

        }

        private void ClickOnMortageTab()
        {
            Playback.Wait(250);
            FastDriver.NewLoan.SwitchToContentFrame();
            FastDriver.NewLoan.MortgageBrokerTab.FAClick();
            FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
            FastDriver.NewLoan.SwitchToContentFrame();
        }

        private void MortgageGABCodeFind(string gabCode)
        {
            FastDriver.NewLoan.SwitchToContentFrame();
            FastDriver.NewLoan.MortgageGABcode.FASetText(gabCode);
            FastDriver.NewLoan.MortgageFind.FAClick();
            Playback.Wait(250);
            FastDriver.NewLoan.SwitchToContentFrame();
        }

        private void FillPaymentDetailsDialog(string SellerCharge = "", string PaidbySellerAtClosing = "", string PaidbySellerBeforeClosing = "", string PaidbySellerOthers = "", string sellerCredit = "", string SellerPaidbyOthersPaymentMethod = "", string description = "", string useDefault = "", string payeeName = "", string SellerCreditPaymentMethod = "")
        {

            Playback.Wait(250);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
            FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

            if (!SellerCharge.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(SellerCharge);

            if (!PaidbySellerAtClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(PaidbySellerAtClosing);

            if (!PaidbySellerBeforeClosing.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(PaidbySellerBeforeClosing);

            if (!PaidbySellerOthers.Equals(""))
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(PaidbySellerOthers);

            if (!sellerCredit.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText(sellerCredit);

            if (!SellerPaidbyOthersPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(SellerPaidbyOthersPaymentMethod);

            if (!SellerCreditPaymentMethod.Equals(""))
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem(SellerCreditPaymentMethod);


            if (!description.Equals(""))
                FastDriver.PaymentDetailsDlg.Description.FASetText(description);

            if (!useDefault.Equals("") && useDefault == true.ToString())
            {
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(true);
            }

            else if (!useDefault.Equals("") && useDefault == false.ToString())
            {
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
            }

            if (payeeName.Equals("EMPTY"))
            { FastDriver.PaymentDetailsDlg.PayeeName.FASetText(""); }

            else if (!payeeName.Equals(""))
            { FastDriver.PaymentDetailsDlg.PayeeName.FASetText(payeeName); }

            //closes the dialog window and switches back to the Fast window;
            FastDriver.PaymentDetailsNewLoanDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.btnDone.FAClick();
            Playback.Wait(500);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.PaymentDetailsDlg.SwitchToContentFrame();


        }

        private void ValidateN06(string SectionN06_Label, string SectionN06_Amt_title, string SectionN06_Amt_text)
        {

            Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionN06_Seqno.Text.Trim());
            Support.AreEqual(SectionN06_Label.Clean(), FastDriver.ClosingDisclosure.SectionN06_Label.GetAttribute("title").Clean());
            Support.AreEqual(SectionN06_Amt_title, FastDriver.ClosingDisclosure.SectionN06_Amt.GetAttribute("title").Trim());
            Support.AreEqual(SectionN06_Amt_text, FastDriver.ClosingDisclosure.SectionN06_Amt.Text.Trim());

        }

        private PageObject UpdateCharge(PageObject pageObject, IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            pageObject.SwitchToContentFrame();
            pageObject.WaitCreation(chargesTable, 10);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return pageObject;
        }

        private void CreateQuickFileEntry(string BusinessSourceGABcode, string BusinessSourceAddtionalRole, bool TitleChecked, bool EscrowChecked, string BusinessSegment, string TransactionType, string TermsDatesSalesPrice, string TermsDatesNewLoanAmnt, string PropertyCity, string PropertyState, string PropertyCounty, string NewLenderInformationGABcode, bool AddDefaultBuyerSellerInfo)
        {

            //
            //
            Reports.TestStep = "Create a basic order";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry").SwitchToContentFrame();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            // FastDriver.QuickFileEntry.WaitCreation(FastDriver.QuickFileEntry.btnBusinessSourceGABFind,10);
            //FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.SwitchToContentFrame();
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText(BusinessSourceGABcode);
            FastDriver.QuickFileEntry.btnBusinessSourceGABFind.FAClick();

            if (BusinessSourceAddtionalRole != string.Empty)
            {
                FastDriver.QuickFileEntry.BusinessSourceAddtionalRole.FASelectItem(BusinessSourceAddtionalRole);
            }

            FastDriver.QuickFileEntry.Title.FASetCheckbox(TitleChecked);
            FastDriver.QuickFileEntry.Escrow.FASetCheckbox(EscrowChecked);
            FastDriver.QuickFileEntry.BusinessSegment.FASelectItem(BusinessSegment);
            FastDriver.QuickFileEntry.TransactionType.FASelectItem(TransactionType);
            FastDriver.QuickFileEntry.FormType_CD.FASetCheckbox(true);
            FastDriver.QuickFileEntry.AutoNumber.FASetCheckbox(true);

            if (TitleChecked == true)
            {
                FastDriver.QuickFileEntry.TitleOwningOfficeUndrwriter.FASelectItem("First American Title Insurance Company");
            }

            if (TermsDatesSalesPrice != string.Empty)
            {
                FastDriver.QuickFileEntry.TermsDatesSalesPrice.FASetText(TermsDatesSalesPrice);
            }

            if (TermsDatesNewLoanAmnt != string.Empty)
            {
                FastDriver.QuickFileEntry.TermsDatesNewLoanAmnt.FASetText(TermsDatesNewLoanAmnt);
            }

            FastDriver.QuickFileEntry.PropertyBookAddrLin1.FASetText("#2600 South Red Hill Avenue");

            if (PropertyCity != string.Empty)
            {
                FastDriver.QuickFileEntry.PropertyCity.FASetText(PropertyCity);
            }
            FastDriver.QuickFileEntry.PropertyState.FASelectItem(PropertyState);

            if (PropertyCounty != string.Empty)
            {
                FastDriver.QuickFileEntry.PropertyCounty.FASetText(PropertyCounty);
            }

            if (AddDefaultBuyerSellerInfo == true)
            {
                FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Buyer1Firstname");
                FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Buyer1Lastname");
                FastDriver.QuickFileEntry.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Buyer2FirstName.FASetText("Buyer2Firstname");
                FastDriver.QuickFileEntry.Buyer2LastName.FASetText("Buyer2Lastname");
                FastDriver.QuickFileEntry.Buyer2SpouseName.FASetText("Buyer2Spousename");
                FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
                FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Seller1Firstname");
                FastDriver.QuickFileEntry.Seller1LastName.FASetText("Seller1Lastname");
                FastDriver.QuickFileEntry.Seller2Type.FASelectItem("Husband/Wife");
                FastDriver.QuickFileEntry.Seller2FirstName.FASetText("Seller2Firstname");
                FastDriver.QuickFileEntry.Seller2LastName.FASetText("Seller2Lastname");
                FastDriver.QuickFileEntry.Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            }

            if (NewLenderInformationGABcode != string.Empty)
            {
                FastDriver.QuickFileEntry.NewLenderInformationGABcode.FASetText(NewLenderInformationGABcode);
                FastDriver.QuickFileEntry.NewLenderInformationFind.FAClick();
                Playback.Wait(1000);
            }

            FastDriver.QuickFileEntry.NoteType.FASelectItem("EPIC");
            FastDriver.QuickFileEntry.Notes.FASetText("Notes Data including - * # Specialcharacter :) !");
            FastDriver.BottomFrame.Done();
        }

        private void New_Loan_Individual(string Desc1, double Charge1, double Charge2)
        {
            FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
            FastDriver.NewLoan.FindGABCode("344");
            FastDriver.NewLoan.ClickChargesTab();
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

            Reports.TestStep = "Entering section J values in New Loan Screen ";
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.OriginationChargesTable, Desc1, buyerCharge: Charge1);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.OriginationChargesTable, Desc1, sellerCharge: Charge2);
            FastDriver.BottomFrame.Done();

        }

        private void Verify_Section_N02()
        {
            IWebElement CdCell1;
            IWebElement CdCell;

            Reports.TestStep = "Navigated to Section j of Closing Cost Section and fetching j section value";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            Playback.Wait(250);

            CdCell1 = FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(1, 3, TableAction.GetCell).Element;
            string Value1 = CdCell1.Text.Clean();
            Reports.StatusUpdate(" Closing Cost subtotal(D+I)Value found in j section  " + Value1, true);

            Reports.TestStep = "Navigated to Summaries of Transaction  Section and verifying line N02 value ";
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);

            CdCell = FastDriver.ClosingDisclosure.SectionN_DueItemsTable.PerformTableAction(2, 2, TableAction.GetCell).Element;
            string Value2 = CdCell.Text.Clean();
            if (Value2 == Value1)
                Reports.StatusUpdate(" Closing Cost section J value found in Line N02 " + "Actual= " + Value2 + "Exprected= " + Value1, true);
            else
                Reports.StatusUpdate(" Closing Cost section J value not found in Line N02" + "Actual= " + Value2 + "Exprected= " + Value1, false);

        }

        public void PropertyTax_Group(String Desc1, String Desc2, Double Charge1, Double Charge2, bool isSectionN)
        {
            Reports.TestStep = "Entering property tax data";
            FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
            FastDriver.PropertyTaxCheck.FindGABCode("344");

            if (!isSectionN)
            {
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc1, sellerCredit: Charge1);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc2, sellerCredit: Charge2);
            }
            if (isSectionN)
            {
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc1, sellerCharge: Charge1);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(Desc2, sellerCharge: Charge2);
            }
            FastDriver.BottomFrame.Done();

        }

        private void Verify_GroupCharge_Desc_N()
        {
            IWebElement CdCell;
            IWebElement CdCell1;
            IWebElement element;

            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);

            Reports.TestStep = "Verifying Group Description after update";
            element = FastDriver.ClosingDisclosure.SectionN_DueItemsTable.PerformTableAction(7, 1, TableAction.GetCell).Element.
                FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
            element.Clear();
            element.SendKeys(" new group description");

            CdCell = FastDriver.ClosingDisclosure.SectionN_DueItemsTable.PerformTableAction(7, 1, TableAction.GetCell).Element;

            string Values = CdCell.Text.Clean();
            if (Values.Contains(Descr))
                Reports.StatusUpdate(" Group Description successfully updated " + Descr + " found", true);
            else
                Reports.StatusUpdate(" group Description not got updated." + "Expected=" + Descr, false);
            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);

            FastDriver.ClosingDisclosure.WaitForScreenToLoad();
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);
            FastDriver.ClosingDisclosure.N06Plus.FAClick();

            Reports.TestStep = "Verifying Group Description in pop up window";
            CdCell1 = FastDriver.ClosingDisclosure.LPopupTable.PerformTableAction(2, 2, TableAction.GetCell).Element;
            string Value = CdCell1.Text.Clean();
            if (Value == Descr.Trim())
                Reports.StatusUpdate(" Group Description successfully updated in pop up window " + "Actual=" + Value + "Expected=" + Descr, true);
            else
                Reports.StatusUpdate(" group Description not got updated in pop up" + "Actual=" + Value + "Expected=" + Descr, false);

        }

        public void New_Loan_Group(string Desc1, string Desc2, double Charge1, double Charge2, bool isSectionN)
        {
            Reports.TestStep = "Entering New  Loan data";
            FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
            FastDriver.NewLoan.FindGABCode("344");
            FastDriver.BottomFrame.New();
            Playback.Wait(3000);
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.FindGABCode("344");
            FastDriver.NewLoan.ClickChargesTab();
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

            if (!isSectionN)
            {
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: Desc1, sellerCredit: Charge1);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: Desc2, sellerCredit: Charge2);
            }
            if (isSectionN)
            {
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: Desc1, sellerCharge: Charge1);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: Desc2, sellerCharge: Charge2);
            }
            FastDriver.BottomFrame.Done();

        }

        public void Supp_Line_Verification(String SectionName)
        {

            BrowserWindow objBrowser = new BrowserWindow();
            objBrowser.SearchProperties["ClassName"] = "IEFrame";
            objBrowser.SearchProperties["ControlType"] = "Window";
            //FATAF.HtmlSupport Closing_Disclosure = new HtmlSupport();
            Playback.Wait(4000);
            this.ClickOnSummaryOftrans();
            //Playback.PlaybackSettings.WaitForReadyLevel = WaitForReadyLevel.AllThreads;
            Playback.Wait(4000);
            HtmlTable CdTable = new HtmlTable(objBrowser);
            HtmlCell CdCell = new HtmlCell(CdTable);

            Reports.TestStep = "verifying Supplementary line serial no";
            if (SectionName == "Section M")
            {
                CdTable.SearchProperties[HtmlTable.PropertyNames.Id] = "tbl-transSummary-AdjforItems_M";
                CdCell.SearchProperties.Add(HtmlCell.PropertyNames.RowIndex, 8.ToString(), HtmlCell.PropertyNames.ColumnIndex, 0.ToString());
                string val = CdCell.InnerText;
                string[] val1 = val.Split();
                string val2 = val1[0];
                if (val2 == 16.ToString())
                    Reports.StatusUpdate("the value Supplementary line no  is verifed." + "Actual=" + val2 + " Expected=" + 16.ToString() + " ", true);
                else
                    Reports.StatusUpdate("the value Supplementary line no not matching ." + "Actual=" + val2 + " Expected=" + 16.ToString() + " ", false);
                Reports.TestStep = "verifying  Supplementary line description";
                CdTable.SearchProperties[HtmlTable.PropertyNames.Id] = "tbl-transSummary-AdjforItems_M";
                CdCell.SearchProperties.Add(HtmlCell.PropertyNames.RowIndex, 8.ToString(), HtmlCell.PropertyNames.ColumnIndex, 1.ToString());
                string s2 = "See attached page for additional information ";
                if (CdCell.InnerText.Trim() == s2.Trim())
                    Reports.StatusUpdate("The value Description is verifed." + "Actual=" + CdCell.InnerText.Trim() + " Expected=" + "See attached page for additional information ", true);
                else
                    Reports.StatusUpdate("The value Description not matching." + "Actual=" + CdCell.InnerText.Trim() + " Expected=" + "See attached page for additional information ", false);
                Reports.TestStep = "verifying Supplementary line sum charges";
                CdTable.SearchProperties[HtmlTable.PropertyNames.Id] = "tbl-transSummary-AdjforItems_M";
                CdCell.SearchProperties.Add(HtmlCell.PropertyNames.RowIndex, 8.ToString(), HtmlCell.PropertyNames.ColumnIndex, 3.ToString());
                string tmp = (CdCell.InnerText.ToString().Replace(",", "")).Replace("$", "").Trim();

                double amt1 = double.Parse(tmp);
                if (amt1 == sum)
                    Reports.StatusUpdate("the value amt is verifed." + "Actual=" + amt1 + " Expected=" + sum + " ", true);
                else
                    Reports.StatusUpdate("the value amt not matching ." + "Actual=" + amt1 + " Expected=" + sum + " ", false);
            }
            if (SectionName == "Section L")
            {
                CdTable.SearchProperties[HtmlTable.PropertyNames.Id] = "tbl-transSummary-AdjforItems_L";
                CdCell.SearchProperties.Add(HtmlCell.PropertyNames.RowIndex, 6.ToString(), HtmlCell.PropertyNames.ColumnIndex, 0.ToString());
                string val = CdCell.InnerText;
                string[] val1 = val.Split();
                string val2 = val1[0];
                if (val2 == 17.ToString())
                    Reports.StatusUpdate("the value Supplementary line no  is verifed." + "Actual=" + val2 + " Expected=" + 17.ToString() + " ", true);
                else
                    Reports.StatusUpdate("the value Supplementary line no not matching ." + "Actual=" + val2 + " Expected=" + 17.ToString() + " ", false);
                Reports.TestStep = "verifying  Supplementary line description";
                CdTable.SearchProperties[HtmlTable.PropertyNames.Id] = "tbl-transSummary-AdjforItems_L";
                CdCell.SearchProperties.Add(HtmlCell.PropertyNames.RowIndex, 6.ToString(), HtmlCell.PropertyNames.ColumnIndex, 1.ToString());
                string s2 = "See attached page for additional information ";
                if (CdCell.InnerText.Trim() == s2.Trim())
                    Reports.StatusUpdate("The value Description is verifed." + "Actual=" + CdCell.InnerText.Trim() + " Expected=" + "See attached page for additional information ", true);
                else
                    Reports.StatusUpdate("The value Description not matching." + "Actual=" + CdCell.InnerText.Trim() + " Expected=" + "See attached page for additional information ", false);
                Reports.TestStep = "verifying Supplementary line sum charges";
                CdTable.SearchProperties[HtmlTable.PropertyNames.Id] = "tbl-transSummary-AdjforItems_L";
                CdCell.SearchProperties.Add(HtmlCell.PropertyNames.RowIndex, 6.ToString(), HtmlCell.PropertyNames.ColumnIndex, 3.ToString());

                String tmp = (CdCell.InnerText.ToString().Replace(",", "")).Replace("$", "").Trim();

                double amt1 = double.Parse(tmp);
                if (amt1 == sum)
                    Reports.StatusUpdate("the value amt is verifed." + "Actual=" + amt1 + " Expected=" + sum + " ", true);
                else
                    Reports.StatusUpdate("the value amt not matching ." + "Actual=" + amt1 + " Expected=" + sum + " ", false);
            }
            if (SectionName == "Section N")
            {
                CdTable.SearchProperties[HtmlTable.PropertyNames.Id] = "tbl-transSummary-AdjforItems_N";
                CdCell.SearchProperties.Add(HtmlCell.PropertyNames.RowIndex, 6.ToString(), HtmlCell.PropertyNames.ColumnIndex, 0.ToString());
                string val = CdCell.InnerText;
                string[] val1 = val.Split();
                string val2 = val1[0];
                if (val2 == 19.ToString())
                    Reports.StatusUpdate("the value Supplementary line no  is verifed." + "Actual=" + val2 + " Expected=" + 19.ToString() + " ", true);
                else
                    Reports.StatusUpdate("the value Supplementary line no not matching ." + "Actual=" + val2 + " Expected=" + 19.ToString() + " ", false);
                Reports.TestStep = "verifying  Supplementary line description";
                CdTable.SearchProperties[HtmlTable.PropertyNames.Id] = "tbl-transSummary-AdjforItems_N";
                CdCell.SearchProperties.Add(HtmlCell.PropertyNames.RowIndex, 6.ToString(), HtmlCell.PropertyNames.ColumnIndex, 1.ToString());
                string s2 = "See attached page for additional information ";
                if (CdCell.InnerText.Trim() == s2.Trim())
                    Reports.StatusUpdate("The value Description is verifed." + "Actual=" + CdCell.InnerText.Trim() + " Expected=" + "See attached page for additional information ", true);
                else
                    Reports.StatusUpdate("The value Description not matching." + "Actual=" + CdCell.InnerText.Trim() + " Expected=" + "See attached page for additional information ", false);
                Reports.TestStep = "verifying Supplementary line sum charges";
                CdTable.SearchProperties[HtmlTable.PropertyNames.Id] = "tbl-transSummary-AdjforItems_N";
                CdCell.SearchProperties.Add(HtmlCell.PropertyNames.RowIndex, 6.ToString(), HtmlCell.PropertyNames.ColumnIndex, 3.ToString());
                string tmp = (CdCell.InnerText.ToString().Replace(",", "")).Replace("$", "").Trim();

                double amt1 = double.Parse(tmp);
                if (amt1 == sum)
                    Reports.StatusUpdate("the value amt is verifed." + "Actual=" + amt1 + " Expected=" + sum + " ", true);
                else
                    Reports.StatusUpdate("the value amt not matching ." + "Actual=" + amt1 + " Expected=" + sum + " ", false);
            }
            Playback.Wait(2000);
        }

        #endregion


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }


    }

}


