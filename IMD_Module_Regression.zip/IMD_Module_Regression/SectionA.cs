﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using FASTWCFHelpers.FastFileService;
using AutoIt;
using OpenQA.Selenium;


namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class SectionA : MasterTestClass
    {
        public SectionA()
        {
        }

        [TestMethod]
        public void SectionA_Scenario1()
        {

            try
            {
                Reports.TestDescription = "Verify charges in Section A – Line 1 without entering values in PDD (With Loan Amount).";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with First New Loan (E.g. 998764334.45) and with New Loan Lender (WF).";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender; 
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL"; 
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT"; 
                fileRequest.File.FirstNewLoanAmount = (decimal)998764334.45; //TermsDatesNewLoanAmnt
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan | Loan Charges.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");

                Reports.TestStep = "Enter % amount under Credit/Charge Points. (E.g. 99.500).";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText(@"99.500");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Buyer Charge will be auto calculated as user has entered Loan Amount and % of Loan Amount. (E.g. 993,770,512.78)";
                Support.AreEqual("993,770,512.78", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetValue());

                Reports.TestStep = @"Navigate to Closing Disclosure. Expand Loan Costs. Verify A01.
                i.	% amount should be displayed as per source screen.
                ii.	Buyer Amount should be displayed as the same is available in source screen.
                iii.	Other fields should be blank.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();

                Reports.TestStep = "Validate Section A, % of Loan Amount";
                Support.AreEqual("99.5", FastDriver.ClosingDisclosure.Percentdisplay.Text);
                Support.AreEqual("% of Loan Amount (Points)", FastDriver.ClosingDisclosure.PercentLoanAmountPoints.Text);

                Reports.TestStep = "Validate Section A, Borrower charge amount";
                Support.AreEqual("$993,770,512.78", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);

                Reports.TestStep = @"Select Good Faith Variance tab and verify the values displayed under 0% and Lender Credit Analysis.
                                i.	Description should be same as displayed in CD Screen.
                                ii.	Loan Estimate (Rounded) 	= $0
                                iii.	Final Amount 		= Buyer Charge(E.g. $993,770,512.78)
                                iv.	Loan Estimate (Rounded) 	= $0.00
                                v.	Amounts Exceeding 0% Good Faith Limit = Buyer Charge(E.g. $993,770,512.78)
                                ";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("A 01 99.5 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim());
                Support.AreEqual("$993,770,512.78", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text);
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text);
                
                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.NonSpecificLenderCreditsAmount.Text);
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.SpecificLenderCreditsAmount.Text);
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.LenderCreditsTotalAmount.Text);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Closing Disclosure tab. Expand Loan Cost. Check Display Loan Estimate columns Checkbox. Modify percentage (E.g. 50.45) and enter Loan estimate unrounded amount (E.g. 789678.78).";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(false);
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText(@"50.45");
                Keyboard.SendKeys(FAKeys.TabAway);

                /***Defect raised TFS# 502689***/
                /*Need to comment after TFS# 502689 is fixed
                ////FASTLibrary.IMDLib.IEStaticMessage("Do you wish to recalculate Percentage Points", "Ok");*/
                /*Need to uncomment after TFS# 502689 is fixed*/
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.FASetText(@"789678.78");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                i.	Description should be same as displayed in CD Screen.
                                ii.	Loan Estimate (Rounded) 	= $789,679
                                iii.	Final Amount 		= Buyer Charge (E.g.  $503,876,606.73)
                                iv.	Loan Estimate (Unrounded) 	= $789,678.78
                                v.	Amounts Exceeding 0% Good Faith Limit = Final Amount – Loan Est. Unrounded amount(E.g. $503,086,927.95)";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("A 01 50.45 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim());
                Support.AreEqual("$503,876,606.73", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text);
                Support.AreEqual("$789,678.78", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text);

                Reports.TestStep = @"Navigate to New Loan | Loan Charges and verify % and Buyer amount.
                                i.	% should be updated as per CD Screen (E.g. 50.450)
                                ii.	Buyer Charge should be updated. (E.g. 503,876,606.73)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("50.450", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetAttribute("value").Trim());
                Support.AreEqual("503,876,606.73", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetAttribute("value").Trim());

                Reports.TestStep = "Modify Buyer Credit under Principal Balance Charges. (E.g. 55600.67)";
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FASetText(@"55600.67");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Click on Ok button in the warning message displayed.";
                /***Defect raised TFS# 502689***/
                /*Need to comment after TFS# 502689 is fixed*/
                /*Issue is fixed hence commented*/
                //FASTLibrary.IMDLib.IEStaticMessage("Ok");/*Need to comment after TFS# 502689 is fixed*/
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Buyer Charge under Credit/Charge Points gets modified. Add Seller (E.g. 6,700.89) and Loan Estimate Amount. (E.g. 6,787.8989)";
                FastDriver.NewLoan.SwitchToContentFrame();
                Support.AreEqual("28,050.54", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetAttribute("value").Trim());
                FastDriver.NewLoan.LoanChargesCredit_ChargeSellerCharge.FASetText("6,700.89");
                FastDriver.NewLoan.LoanChargesCredit_ChargeLoanEstimate.FASetText("6,787.89");

                Reports.TestStep = @"Navigate to CD Screen and verify the amounts displayed
                                i.	% amount should be displayed as per source screen.
                                ii.	Borrower – At Closing should be displayed as the same is available in source screen.
                                iii.	Seller";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("50.45", FastDriver.ClosingDisclosure.Percentdisplay.Text);
                Support.AreEqual("$28,050.54", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual("$6,787.89", FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.Text);

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                i.	Description should be same as displayed in CD Screen.
                                ii.	Loan Estimate (Unrounded) 	= $6,787.90
                                iii.	Final Amount 		= Buyer Charge (E.g.  $28,050.54)
                                iv.	Loan Estimate (Rounded) 	= $6,788
                                v.	Amounts Exceeding 0% Good Faith Limit = Final Amount – Loan Est. Unrounded amount(E.g. $21,262.64)";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("A 01 50.45 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim());
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.LoanEstimateDisclosedRounded.Text);
                Support.AreEqual("$28,050.54", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text);
                Support.AreEqual("$6,787.89", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.NonSpecificLenderCreditsAmount.Text);
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.SpecificLenderCreditsAmount.Text);
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.LenderCreditsTotalAmount.Text);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Closing Disclosure tab. Expand Loan Cost. Check Display Loan Estimate columns Checkbox. Modify Loan Estimate – Unrounded Amount (E.g. 598787.67), modify Loan Estimate Rounded Amount. (E.g. 2342333.56)
                                i.	System should allow user to enter amounts.
                                ii.	System should display pencil icon near rounded amount.";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.FASetText(@"789678.78");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.SectionALoanEstimateRounded.FASetText(@"2342333.56");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanEstimateRoundedBrokenLink.Displayed.ToString(), true);

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                    i.	Description should be same as displayed in CD Screen.
                                    ii.	Loan Estimate (Rounded) 	= $2,342,334
                                    iii.	Final Amount 		= Buyer Charge (E.g.  $28,050.54)
                                    iv.	Loan Estimate (Unrounded) 	= $598,787.67
                                    v.	Amounts Exceeding 0% Good Faith Limit = Final Amount – Loan Est. Unrounded amount. Since it is negative amount system should display $0.00";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("A 01 50.45 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim());
                Support.AreEqual("$2,342,334", FastDriver.ClosingDisclosure.LoanEstimateDisclosedRounded.Text);
                Support.AreEqual("$28,050.54", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text);
                Support.AreEqual("$6,787.89", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.NonSpecificLenderCreditsAmount.Text);
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.SpecificLenderCreditsAmount.Text);
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.LenderCreditsTotalAmount.Text);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to New Loan | Loan Charges section. Verify the Loan estimate (Unrounded) amount.
                                    i.	System should display the Loan Estimate (Rounded) and (Unrounded) amounts as entered in CD Screen.
                                    ii.	 System should display pencil icon near rounded amount.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("50.450", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetAttribute("value").Trim());
                Support.AreEqual("28,050.54", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetAttribute("value").Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void SectionA_Scenario2()
        {

            try
            {
                Reports.TestDescription = "Verify charges in Section A – Line 1 without entering values in PDD (Without Loan Amount).";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file without Sales Price and with New Loan Lender.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214"); // BusinessSourceGABcode IDCode = 214
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan.LiabilityAmount = 0.00M;
                fileRequest.File.NewLoan.NewLoanAmount = 0.00M;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan | Loan Charges.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FASetText(@"56789.90");

                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Cost and verify the Description and Buyer Charge displayed in CD Screen.
                                    i.	“% of Loan Amount (Points)” Should be editable.
                                    ii.	Zero should be displayed as percentage as user has not entered % in New Loan Screen.
                                    iii.	Borrower – At Closing should be $56,789.90 as user has entered the same in Source Screen.
                                    iv.	All Other values including Loan Estimate (Unrounded and Rounded) should be blank.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 0 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$56,789.90", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);

                Reports.TestStep = "Select Good Faith Variance and verify if system displays the line under 0%.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("A 01 0 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim());
                Support.AreEqual("$56,789.90", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text);
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.NonSpecificLenderCreditsAmount.Text);
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.SpecificLenderCreditsAmount.Text);
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.LenderCreditsTotalAmount.Text);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Closing Disclosure tab. Expand Loan Cost. Modify % amount in CD Screen. (E.g. 999.99). Verify if system displays error message “Points percentage cannot be greater than 99.9999”";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("999.99" + FAKeys.Tab);
                string sMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, 30);
                Support.AreEqual("Points percentage cannot be greater than 99.9999", sMessage);

                Reports.TestStep = "Update % amount in CD Screen. (E.g. 99.999). Verify if system displays recalculation message.";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("99.999");
                Keyboard.SendKeys(FAKeys.TabAway);
                /***Defect raised TFS# 502689***/
                /*Need to comment after TFS# 502689 is fixed*/
                ///////FASTLibrary.IMDLib.IEStaticMessage("Do you wish to recalculate Percentage Points", "Ok");
                /*Need to uncomment after TFS# 502689 is fixed*/
                sMessage = FastDriver.WebDriver.HandleDialogMessage(true, true);
                Support.AreEqual("Do you wish to recalculate Credit/Charge Points?", sMessage);

                Reports.TestStep = "Click on Ok button and verify if Borrower – At Closing amount is removed as user has not entered Loan Amount.";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                
                Support.AreEqual("A 01 99.999 % of Loan Amount (Points)", "A 01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text.Trim() + " % of Loan Amount (Points)");

                //Remove this validation step because the table is completely removed
                //Reports.TestStep = "Select Good Faith Variance tab and verify if amount is removed.";
                //FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                //FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();
                //Support.AreEqual("false", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.Displayed.ToString(), true);
                //Support.AreEqual("A 01 0 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim());

                Reports.TestStep = @"Navigate to New Loan | Loan Charges screen and verify % and Buyer Charge.
                                    i.	% should be updated to 99.999
                                    ii.	Buyer Charge should be removed.
                                    iii.	Other values should be blank.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("99.999", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetAttribute("value").Trim());
                Support.AreEqual("", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetAttribute("value").Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void SectionA_Scenario3()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A – Line 1 by entering values in PDD (Without Loan Amount).";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file without Sales Price.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan | Loan Details tab and add GAB Code. (E.g. 214)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("214");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                Reports.TestStep = "Select Loan Charges tab. Open PDD and enter Buyer and Seller – At Closing, Before Closing and Paid by Others. (E.g. 5600.67, 24235.56, 45344.56 (POC – L), Seller – 34534.56, 34534.67, 45233.56 (POC – L))";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();

                Reports.TestStep = "Enter buyer details in PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"5600.67");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText(@"24235.56");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(@"45344.56");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem(@"POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLBorrower.FASetCheckbox(true);

                Reports.TestStep = "Enter seller details in PDD";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"34534.56");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(@"34534.67");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(@"45233.56");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(@"POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLSeller.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Costs and Verify the amount displayed in A01.
                                    i.	Borrower – At Closing = $5,600.67
                                    ii.	Borrower – Before Closing = $24,235.56
                                    iii.	Seller – At Closing = $34,534.56
                                    iv.	Seller – Before Closing = $34,534.67
                                    v.	Paid by Others =(L) $90,578.12";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 0 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$5,600.67", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual("$24,235.56", FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text);
                Support.AreEqual("$34,534.56", FastDriver.ClosingDisclosure.SellerAtClosingAmount.Text);
                Support.AreEqual("$34,534.67", FastDriver.ClosingDisclosure.SellerBeforeClosingAmount.Text);
                Support.AreEqual("(L)$45,344.56", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text);

                Reports.TestStep = "Select Good Faith Variance and verify if system displays the line under 0%.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("A 01 0 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim());
                Support.AreEqual("$29,836.23", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text.Trim());

                Reports.TestStep = "Verify J 00";
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$45,344.56", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$45,344.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$45,344.56", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$45,344.56", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$45,344.56", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 01 0 % of Loan Amount (Points)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$45,344.56", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Closing Disclosure tab and Modify the % amount (E.g. 23). Click on Ok button in recalculate pop up message.";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("23");
                Keyboard.SendKeys(FAKeys.TabAway);

                /***Defect raised TFS# 502689***/
                /*Need to comment after TFS# 502689 is fixed*/
                /////FASTLibrary.IMDLib.IEStaticMessage("Do you wish to recalculate Percentage Points", "Ok");
                /*Need to uncomment after TFS# 502689 is fixed*/
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"System should remove the Borrower – At Closing, Before Closing and Paid by Others.
                                    i.	Borrower – Paid – At Closing = Blank
                                    ii.	Borrower – Paid – Before Closing = Blank
                                    iii.	Seller – At Closing = $34,534.56
                                    iv.	Seller – Before Closing = $34,534.67
                                    v.	Paid by Others = $45,233.56";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                Support.AreEqual("01 23 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$34,534.56", FastDriver.ClosingDisclosure.SellerAtClosingAmount.Text);
                Support.AreEqual("$34,534.67", FastDriver.ClosingDisclosure.SellerBeforeClosingAmount.Text);
                Support.AreEqual("", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text);

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under Good Faith Variance 0% and Lender Credit Analysis.
                                    i.	System should not display any values under 0% as Final Amount is blank for A 01.
                                    ii.	Lender Credit Analysis values should be $0.00";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                // Remove this validation because table is completely removed
                //Support.AreEqual("false", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.Displayed.ToString(), true);

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Navigate to New Loan screen | Loan Charges tab. Open PDD for Credit/Charge points and verify the split values.
                                    i.	Buyer – Paid – At Closing = $0.00
                                    ii.	Buyer – Paid – Before Closing = $0.00
                                    iii.	Buyer – Paid by Others = $0.00
                                    iv.	Seller – Paid – At Closing = $34,534.56
                                    v.	Seller  – Paid – Before Closing = $34,534.67
                                    vi.	Seller – Paid by Others = $45,233.56";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();

                Reports.TestStep = "Verify buyer details in PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Trim());
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("true", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString(), true);

                Reports.TestStep = "Verify seller details in PDD";
                Support.AreEqual("$34,534.56", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$34,534.67", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());
                Support.AreEqual("$45,233.56", FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue().Trim());
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("true", FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString(), true);
                FastDriver.DialogBottomFrame.ClickDone();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void SectionA_Scenario4()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A – Line 1 by entering values in PDD (With Loan Amount).";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan and Add GAB code. (E.g. 526)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("526");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("4566.78");

                Reports.TestStep = "Enter % amount for credit/charge points. (E.g. 3)";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("3");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Open PDD and modify Buyer Charge, Seller Charge and Loan Estimate amount. (E.g. Buyer – At Closing = 178.8, Before Closing = 567.67, Paid by Others = 782.56 (POC), Seller – At Closing = 658.87, Before Closing = 687.34, Paid by Others = 879.45(POC), Loan Est. Unrounded = 879.45)";
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(@"178.8");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText(@"567.67");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(@"782.56");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem(@"POC");
                Support.AreEqual("false", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString(), true);

                Reports.TestStep = "Enter seller details in PDD";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(@"658.87");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(@"687.34");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(@"879.45");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem(@"POC");
                Support.AreEqual("false", FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString(), true);
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("879.45");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"Navigate to Closing Disclosure. Expand Loan Cost.
                                    a.	Borrower – Paid – At Closing = $178.80
                                    b.	Borrower – Paid – Before Closing = $567.67
                                    c.	Seller – At Closing = $658.87
                                    d.	Seller – Before Closing = $687.34
                                    e.	Paid by Others = $1,662.01
                                    f.	Loan Estimate Unrounded = $879.45
                                    g.	Loan Estimate Rounded = $879";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 3 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$178.80", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual("$567.67", FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text);
                Support.AreEqual("$658.87", FastDriver.ClosingDisclosure.SellerAtClosingAmount.Text);
                Support.AreEqual("$687.34", FastDriver.ClosingDisclosure.SellerBeforeClosingAmount.Text);
                Support.AreEqual("$782.56", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text);

                Reports.TestStep = "Select Good Faith Variance tab and verify values displayed under Good Faith Variance 0% and Lender Credit Analysis.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("A 01 3 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 3 % of Loan Amount (Points)", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$879", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 3 % of Loan Amount (Points)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$746.47", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 3 % of Loan Amount (Points)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$879.45", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 3 % of Loan Amount (Points)", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Closing Disclosure tab. Modify % amount. (E.g. 00.688)";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("00.688");
                Keyboard.SendKeys(FAKeys.TabAway);

                /***Defect raised TFS# 502689***/
                /*Need to comment after TFS# 502689 is fixed*/
                ////FASTLibrary.IMDLib.IEStaticMessage("Cancel", "Do you wish to recalculate Percentage Points");
                /*Uncommented after TFS# 502689 is fixed*/
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"Reload CD Screen and expand Loan Cost and verify the values in A01 are not changed.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 0.688 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$31.42", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text);
                Support.AreEqual("$658.87", FastDriver.ClosingDisclosure.SellerAtClosingAmount.Text);
                Support.AreEqual("$687.34", FastDriver.ClosingDisclosure.SellerBeforeClosingAmount.Text);
                Support.AreEqual("", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text);
                
                Reports.TestStep = @"Modify % amount. (E.g. 00.688). Click on Ok button in recalculate pop up.";
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("00.688");
                Keyboard.SendKeys(FAKeys.TabAway);

                /***Defect raised TFS# 502689***/
                /*Need to comment after TFS# 502689 is fixed*/
                ///FASTLibrary.IMDLib.IEStaticMessage("Do you wish to recalculate Percentage Points", "Ok");
                /*Need to uncomment after TFS# 502689 is fixed*/
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"System should remove Buyer at Closing, Buyer before closing and Buyer – Paid by others and calculate % and Loan amount and display Buyer at Closing amount. (E.g. $31.42)
                                    a.	Borrower – Paid – At Closing = $31.42
                                    b.	Borrower – Paid – Before Closing = Blank
                                    c.	Seller – At Closing = $658.87
                                    d.	Seller – Before Closing = $687.34
                                    e.	Paid by Others = $879.45 (Only Seller Paid by Others)
                                    f.	Loan Estimate Unrounded = $879.45
                                    g.	Loan Estimate Rounded = $879";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                Support.AreEqual("01 0.688 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$31.42", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text);
                Support.AreEqual("$658.87", FastDriver.ClosingDisclosure.SellerAtClosingAmount.Text);
                Support.AreEqual("$687.34", FastDriver.ClosingDisclosure.SellerBeforeClosingAmount.Text);
                Support.AreEqual("", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("$879.45", FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.Text);
                Support.AreEqual("$879.00", FastDriver.ClosingDisclosure.SectionALoanEstimateRounded.Text);

                Reports.TestStep = @"Select Good Faith Variance tab and verify values displayed under Good Faith Variance 0% and Lender Credit Analysis.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("A 01 0.688 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$879", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$31.42", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$879.45", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Navigate to New Loan screen | Loan Charges tab. Open PDD and verify the values displayed in PDD.
                                a.	Buyer – At Closing = $31.42, 
                                b.	Before Closing = 0.00, 
                                c.	Paid by Others = 0.00,
                                d.	Seller – At Closing = 658.87, 
                                e.	Seller – Before Closing = 687.34, 
                                f.	Seller – Paid by Others = 879.45(POC)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();

                Reports.TestStep = "Verify buyer details in PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$31.42", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("false", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString(), true);

                Reports.TestStep = "Verify seller details in PDD";
                Support.AreEqual("$658.87", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$687.34", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());
                Support.AreEqual("$879.45", FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("false", FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString(), true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to Mortgage Broker tab and add Mortgage Broker. (E.g. 415)";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("415");                       
                FastDriver.NewLoan.MortgageFind.FAClick();

                Reports.TestStep = @"Select Loan Charges tab and Update values in PDD for % of Loan Amount (Points) under Credit/Charge Points. 
                                    a.	 Buyer – Paid – At Closing = $ 5,678.88
                                    b.	Buyer – Paid – Before Closing = $ 3,455.68
                                    c.	Buyer – Paid by Others = $ 87,689.67(POC – MB)
                                    d.	Seller – At Closing = $4,565.67
                                    e.	Seller – Before Closing = $32,423.56
                                    f.	Seller – Paid by Others = $2,342.56
                                    g.	Loan Estimate Unrounded = $ 9,134.56
                                    h.	Loan Estimate Rounded = $5,879.00 (System should display Broken icon)
                                    i.	Check Double Asterisk checkbox.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();

                Reports.TestStep = "Verify buyer details in PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("5678.88");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("3455.68");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("87689.67");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                Support.AreEqual("false", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString(), true);

                Reports.TestStep = "Verify seller details in PDD";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("4565.67");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("32423.56");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("2342.56");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                Support.AreEqual("false", FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString(), true);
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("9134.56");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("5879.00");
                Support.AreEqual("true", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString(), true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Cost. Check Display Loan Estimate Columns. Verify the values displayed in A01.
                                    a.	Borrower – Paid – At Closing = $5,678.88
                                    b.	Borrower – Paid – Before Closing = $3,455.68
                                    c.	Seller – At Closing = $4,565.67
                                    d.	Seller – Before Closing = $32,423.56
                                    e.	Paid by Others = $90,032.23
                                    f.	Loan Estimate Unrounded = $ 9,134.56
                                    g.	Loan Estimate Rounded = $5,879.00 (System should display Pencil icon)
                                    h.	Double Asterisk should be displayed.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 0.688 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$5,678.88", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual("$3,455.68", FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text);
                Support.AreEqual("$4,565.67", FastDriver.ClosingDisclosure.SellerAtClosingAmount.Text);
                Support.AreEqual("$32,423.56", FastDriver.ClosingDisclosure.SellerBeforeClosingAmount.Text);
                Support.AreEqual("$87,689.67", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("$9,134.56", FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.Text);
                Support.AreEqual("$5,879.00", FastDriver.ClosingDisclosure.SectionALoanEstimateRounded.Text);

                Reports.TestStep = @"Select Good Faith Variance tab and verify values displayed under Good Faith Variance 0% and Lender Credit Analysis.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("A 01 0.688 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,879", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$9,134.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$9,134.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify J 00";
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$87,689.67", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$87,689.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$87,689.67", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$87,689.67", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$87,689.67", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void SectionA_Scenario5_1()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A 2+ without entering values in PDD.";
                int rowCount = 0;

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.FirstNewLoanAmount = (decimal)998764334.45; //TermsDatesNewLoanAmnt
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Enter Buyer Charge and Loan Est. unrounded for any charges under Origination Charges. (E.g. Application Fee – Buyer Charge = $5,434,656,789.99, Loan Est. unrounded = 2,423,423,423.00)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "5434656789.99");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "2,423,423,423.00");

                Reports.TestStep = "Enter Seller Charge and Loan Est. unrounded for any charges under Origination Charges. (E.g. Origination Fee – Seller Charge = $9,434,656,789.78, Loan Est. unrounded = 23,423,423.56)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 5, TableAction.SetText, "9434656789.78");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 7, TableAction.SetText, "2,423,423,423.00");

                Reports.TestStep = "Enter Buyer Charge and Seller Charge for any charges under Origination Charges. (E.g. Underwriting Fee – Buyer Charge = $54634.67, Seller Charge = $6854.67)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "54634.67");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 7, TableAction.SetText, "6854.67");

                Reports.TestStep = "Enter Loan Estimate Unrounded amount for any charges under Origination Charges (E.g. Processing Fee – Loan Est. Unrounded = $6,564.78)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Processing Fee", 7, TableAction.SetText, "6564.78");

                Reports.TestStep = "Enter Buyer Charge for Adhoc charges under Origination Charges. (E.g. Adhoc Charge1 – Buyer Charge = $ 342,342.67)";
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge1");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge1", 3, TableAction.SetText, "342342.67" + FAKeys.Tab);
                //Create new row
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge1", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Enter Seller Charge for Adhoc charges under Origination Charges. (E.g. Adhoc Charge2 – Seller Charge = $878,988.87)";
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge2");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge2", 5, TableAction.SetText, "878988.87" + FAKeys.Tab);
                //Create new row
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge2", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Enter Buyer Charge, Seller Charge and Loan Estimate for adhoc charges under Origination Charges. (E.g. Adhoc Charge3 – Buyer Charge = $7,678,678.98, Seller Charge = $8,789,798.98, Loan Est. unrounded = $34,234,234.00)";
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge3");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 3, TableAction.SetText, "7678678.98");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 5, TableAction.SetText, "8789798.98");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 7, TableAction.SetText, "34234234.00");
                //Create new row
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway);
                
                Reports.TestStep = "Enter Loan Estimate Unrounded amount for adhoc charges under Origination Charges (E.g. Adhoc Charge4 – Loan Est. Unrounded = $980,990.78) ";
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge4");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge4", 7, TableAction.SetText, "980990.78");


                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Cost. Check Display Loan Estimate columns checkbox.
                                                    a.	System should display charges in Alphabetical order.
                                                    b.	Adhoc Charge1 – Borrower – At Closing = $342,342.67
                                                    c.	Adhoc Charge2 – Seller – At Closing = $878,988.87
                                                    d.	Adhoc Charge3 – Borrower  – At Closing = $7,678,678.98, Seller – At Closing = $8,789,798.98, Loan Estimate Unrounded amount = $34,234,234.00, Loan Estimate rounded amount = $34,234,234.00
                                                    e.	Adhoc Charge4 should not be displayed as user has not entered buyer/seller charge.
                                                    f.	Application Fee – Borrower – At Closing = $434,656,789.99 (9.2 Format)
                                                    g.	Origination Fee – Seller – At Closing = $434,656,789.78(9.2 Format)
                                                    h.	Underwriting Fee – Borrower – At Closing = $54,634.67, Seller – At Closing = $6,854.67
                                                    i.	A – Borrower – Paid – Total = $442,732,446.31 (Since 5,442,732,446.31 is not 9.2 format system should display 442,732,446.31)
                                                    j.	D – Should be same as A total.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "System should display charges in Alphabetical order.";
                Reports.TestStep = "Adhoc Charge1 – Borrower – At Closing = $342,342.67";
                Support.AreEqual("02. Adhoc Charge1", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$342,342.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Adhoc Charge2 – Seller – At Closing = $878,988.87";
                Support.AreEqual("03. Adhoc Charge2", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge2", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$878,988.87", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge2", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Adhoc Charge3 – Borrower  – At Closing = $7,678,678.98, Seller – At Closing = $8,789,798.98, Loan Estimate Unrounded amount = $34,234,234.00, Loan Estimate rounded amount = $34,234,234.00";
                Support.AreEqual("04. Adhoc Charge3", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$8,789,798.98", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 4, TableAction.GetText).Message.Trim());
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Application Fee – Borrower – At Closing = $5,434,656,789.99 (9.2 Format)";
                Support.AreEqual("05. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$434,656,789.99", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,423,423.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Origination Fee – Seller – At Closing = $434,656,789.78(9.2 Format)";
                Support.AreEqual("06. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$434,656,789.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Underwriting Fee – Borrower – At Closing = $54,634.67, Seller – At Closing = $6,854.67";
                Support.AreEqual("07. Underwriting Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Underwriting Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$54,634.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Underwriting Fee", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                    a.	All the charges with Buyer Amount should be displayed as displayed below.
 	                                    Loan Estimate	Final	Loan Estimate	Amounts Exceeding
	                                    Disclosed (Rounded)	(Borrower Paid)	(Unrounded)	0% Good Faith Limit
                                      A 02 Adhoc Charge1	$0 	$342,342.67 	$0.00 	$342,342.67 
                                      A 04 Adhoc Charge3	$34,234,234 	$7,678,678.98 	$34,234,234.00 	$0.00 
                                      A 05 Application Fee	$423,423,423 	$434,656,789.99 	$423,423,423.00 	$11,233,366.99 
                                      A 07 Underwriting Fee	$0 	$54,634.67 	$0.00 	$54,634.67 ";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$342,342.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$342,342.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$34,234,234", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge3", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge3", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge3", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$423,423,423", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$434,656,789.99", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Application Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,423,423.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Application Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$11,233,366.99", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Application Fee", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,855", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Underwriting Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$54,634.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Underwriting Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,854.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Underwriting Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$47,780.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Underwriting Fee", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Select Closing Disclosure tab. 
                                    Modify the Loan Estimate amount rounded for Adhoc Charge3. (E.g. 56778.89), 
                                    Add Loan Estimate amount unrounded for Adhoc Charge1 (E.g. 56564.45). 
                                    Modify Loan Est. unrounded amount for Application Fee (E.g. 523,423,423.67), 
                                    Edit charge description for Underwriting Fee (E.g. Modified Charge description).
                                    a.	System should allow user to add/Modify values.
                                    b.	Should display pencil icon for Adhoc Charge 3 as rounded amount was modified.";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 7, TableAction.SetText, "56,564.45");
                Keyboard.SendKeys(FAKeys.TabAway);
                //Hack: Use SendKeys becuase Clear() function doesn't work on this control
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 8, TableAction.Click);
                Keyboard.SendKeys("^A");
                Keyboard.SendKeys("{DELETE}");
                Keyboard.SendKeys("56,778.89");
                Keyboard.SendKeys(FAKeys.TabAway);
                //Hack: Use SendKeys becuase Clear() function doesn't work on this control, need to reload the screen after each row!!! :(
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.Click);
                Keyboard.SendKeys("^A");
                Keyboard.SendKeys("{DELETE}");
                Keyboard.SendKeys("523,423,423.67");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Underwriting Fee", 1, TableAction.SetText, "Modified Charge description" + FAKeys.Tab);
                //FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Underwriting Fee", 1, TableAction.Click);
                //Keyboard.SendKeys("^A");
                //Keyboard.SendKeys("{DELETE}");
                //Keyboard.SendKeys("Modified Charge description");
                //Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                    a.	Values should be displayed as below:
 	                                    Loan Estimate	Final	Loan Estimate	Amounts Exceeding
	                                    Disclosed (Rounded)	(Borrower Paid)	(Unrounded)	0% Good Faith Limit
                                        A 02 Adhoc Charge1 $56,564 	$342,342.67 	$56,564.45 	$285,778.22 
                                      A 04 Adhoc Charge3	$56,779 	$7,678,678.98 	$34,234,234.00 	$0.00 
                                      A 05 Application Fee	$523,423,424 	$434,656,789.99 	$523,423,423.67 	$911,233,366.32 
                                      A 06 Modified Charge description	$0 	$54,634.67 	$0.00 	$54,634.67";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("$56,564", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$342,342.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$56,564.45", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$56,779", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge3", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge3", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$523,423,424", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$434,656,789.99", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Application Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$523,423,423.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Application Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$6,855", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Modified Charge description", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$54,634.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Modified Charge description", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,854.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Modified Charge description", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void SectionA_Scenario5_2()
        {
            try
            {
                Reports.TestDescription = "Continuation (SectionA_Scenario5) - Verify charges in Section A 2+ without entering values in PDD.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file 
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.FirstNewLoanAmount = (decimal)998764334.45; //TermsDatesNewLoanAmnt
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                Reports.TestStep = @"Navigate to New Loan | Loan Charge screen &
                                    verify if modified loan estimate amount is displayed and charge description is modified.
                                    a.	Open PDD for Adhoc Charge3 – Loan Est. rounded amount should be as per CD and broken link should be displayed. (E.g. 56778.89)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Enter Buyer Charge and Loan Est. unrounded for any charges under Origination Charges. (E.g. Application Fee – Buyer Charge = $5,434,656,789.99, Loan Est. unrounded = 2,423,423,423.00)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "5434656789.99");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "2423423423.00");

                Reports.TestStep = "Enter Seller Charge and Loan Est. unrounded for any charges under Origination Charges. (E.g. Origination Fee – Seller Charge = $9,434,656,789.78, Loan Est. unrounded = 23,423,423.56)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 5, TableAction.SetText, "9434656789.78");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 7, TableAction.SetText, "2423423423.00");

                Reports.TestStep = "Enter Buyer Charge and Seller Charge for any charges under Origination Charges. (E.g. Underwriting Fee – Buyer Charge = $54634.67, Seller Charge = $6854.67)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 3, TableAction.SetText, "54634.67");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 7, TableAction.SetText, "6854.67");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 1, TableAction.SetText, "Modified Charge description");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Enter Loan Estimate Unrounded amount for any charges under Origination Charges (E.g. Processing Fee – Loan Est. Unrounded = $6,564.78)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Processing Fee", 7, TableAction.SetText, "6564.78");

                int rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge3");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 3, TableAction.SetText, "7678678.98");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 5, TableAction.SetText, "8789798.98");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$34,234,234.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$56,779.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"b.	Open PDD for Adhoc Charge1 – Loan Est. unrounded amount should be as per CD. (E.g. 56564.45)";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway); // TAB to create a new row
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge1" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge1", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$56,564.45");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$56,564.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"g.	Adhoc Charge 4 – Buyer Charge = 4233.54";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge1", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway); // TAB to create a new row
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge4");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge4", 3, TableAction.SetText, "4233.54"); //Buyer Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge4", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$980,990.78");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$980,991.00");
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge4", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway); // TAB to create a new row

                Reports.TestStep = @"c.	Open PDD for Application Fee – Loan Est. unrounded amount should be as per CD. (E.g. 523,423,423.67)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$523,423,423.67");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$523,423,424.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"d.	Verify if Underwriting Fee is modified to Modified Charge description.";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Modified Charge description", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Modified Charge description", FastDriver.PaymentDetailsDlg.Description.FAGetValue(), true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Modify amounts in new loan screen.
                                    a.	Application Fee –  Charge Description modify to Verify source Application Fee , Buyer Charge = 453434.56, Seller Charge = 34534.56";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "453434.56"); //Buyer Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 5, TableAction.SetText, "34534.56"); // Seller Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.SetText, "Verify source Application Fee"); // Description

                Reports.TestStep = @"b.	Origination Fee – Buyer Charge = 98798, Seller Charge = 0";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 3, TableAction.SetText, "98798"); //Buyer Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 5, TableAction.SetText, "0"); // Seller Charge

                Reports.TestStep = @"c.	Modified Charge description – Buyer Charge = 423322.56, Loan Est. unrounded = 43534.67";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Modified Charge description", 3, TableAction.SetText, "423322.56"); //Buyer Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Modified Charge description", 7, TableAction.SetText, "43534.67"); // Loan Estimate

                Reports.TestStep = @"d.	Processing Fee – Add Buyer Amount = 6,564.78";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Processing Fee", 3, TableAction.SetText, "6564.78"); //Buyer Charge

                Reports.TestStep = @"e.	Adhoc Charge1 - Buyer Charge = 63453.7, Seller Charge = 34534.56";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge1", 3, TableAction.SetText, "63453.70"); //Buyer Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge1", 5, TableAction.SetText, "34534.56"); // Seller Charge

                Reports.TestStep = @"f.	Adhoc Charge2–  Charge Description modify to M0d!f!3d @dh0c CHARGE - Buyer Charge = 3545345, Seller Charge = 878,988.87";
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge2");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge2", 3, TableAction.SetText, "3545345.00"); //Buyer Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge2", 5, TableAction.SetText, "878,988.87"); // Seller Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge2", 1, TableAction.SetText, "M0d!f!3d @dh0c CHARGE"); // Description



                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Cost. Check Display Loan Estimate columns checkbox.
                                    A.  Origination Charges 	$12,273,831.12 	 	 	 	 	 	 
                                    01.   % of Loan Amount (Points)	 	 	 	 	 	 	 
                                    02. Adhoc Charge1 	$63,453.70 	 	$34,534.56 	 	 	$56,564.45 	$56,564.00 
                                    03. Adhoc Charge3 	$7,678,678.98 	 	$8,789,798.98 	 	 	$34,234,234.00 	    $56,779.00 
                                    04. Adhoc Charge4 	$4,233.54 	 	 	 	 	$980,990.78 	$980,991.00 
                                    05. M0d!f!3d @dh0c CHARGE 	$3,545,345.00 	 	$878,988.87 	 	 	Enter unrounded amt 	Enter rounded amt 
                                    06. Modified Charge description 	$423,322.56 	 	$6,854.67 	 	 	$43,534.67 	$43,535.00 
                                    07. Origination Fee 	$98,798.00 	 	 	 	 	$23,423,423.56 	$23,423,424.00 
                                    08. Processing Fee 	$6,564.78 	 	 	 	 	$6,564.78 	$6,565.00 
                                    09. Verify source Application Fee 	$453,434.56 	 	$34,534.56 	 	 	$523,423,423.67 	$523,423,424.00 ";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                //FastDriver.ClosingDisclosure.Othercosts.FAClick();

                Reports.TestStep = @"System should display charges in Alphabetical order.
                                     Adhoc Charge1 - Buyer Charge = 63453.7, Seller Charge = 34534.56";
                Support.AreEqual("02. Adhoc Charge1", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$63,453.70", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,534.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Adhoc Charge3 – Borrower  – At Closing = $7,678,678.98, Seller – At Closing = $8,789,798.98, Loan Estimate Unrounded amount = $34,234,234.00, Loan Estimate rounded amount = $56,779.00 ";
                Support.AreEqual("03. Adhoc Charge3", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$56,779.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Adhoc Charge4 – Borrower  – At Closing = $4,233.54 , Loan Estimate Unrounded amount = $980,990.78 , Loan Estimate rounded amount = $980,991.00 ";
                Support.AreEqual("04. Adhoc Charge4", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,233.54", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$980,990.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$980,991.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Adhoc Charge2–  Charge Description modify to M0d!f!3d @dh0c CHARGE - Buyer Charge = 3545345, Seller Charge = 878,988.87";
                Support.AreEqual("05. M0d!f!3d @dh0c CHARGE", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "M0d!f!3d @dh0c CHARGE", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,545,345.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "M0d!f!3d @dh0c CHARGE", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$878,988.87", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "M0d!f!3d @dh0c CHARGE", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Modified Charge description  – Borrower – At Closing =Buyer Charge =  $423,322.56,Seller Charge =  $6,854.67 , Loan Estimate Unrounded amount = $43,534.67 ";
                Support.AreEqual("06. Modified Charge description", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,322.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$43,534.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$43,535.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Origination Fee – Buyer – At Closing = $98,798.00, Loan Estimate Unrounded amount = $23,423,423.56 ";
                Support.AreEqual("07. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$98,798.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,423,423.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,423,423.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Processing Fee  – Buyer – At Closing = $6,564.78 , Loan Estimate Unrounded amount = $6,564.78 ";
                Support.AreEqual("08. Processing Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,564.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,564.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,565.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify source Application Fee – Borrower – At Closing = $453,434.56 , Seller – At Closing = $34,534.56, Loan Estimate Unrounded amount = $523,423,423.67 ";
                Support.AreEqual("09. Verify source Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verify source Application Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$453,434.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verify source Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,534.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verify source Application Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$523,423,423.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verify source Application Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verify source Application Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Good Faith Variance and verify value under 0% and Lender Credit Analysis.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("$56,564", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$63,453.70", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$56,564.45", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$56,779", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$980,991", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge4", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,233.54", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge4", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$980,990.78", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Adhoc Charge4", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 M0d!f!3d @dh0c CHARGE", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,545,345.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 M0d!f!3d @dh0c CHARGE", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 M0d!f!3d @dh0c CHARGE", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$43,535", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Modified Charge description", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,322.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Modified Charge description", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$43,534.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Modified Charge description", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$423,423,423", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Origination Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$98,798.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Origination Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,423,423.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Origination Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$6,565", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 08 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,564.78", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 08 Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,564.78", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 08 Processing Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$523,423,424", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 09 Verify source Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$453,434.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 09 Verify source Application Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$523,423,423.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 09 Verify source Application Fee", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan | Loan Charges. Click on Pay Charges button. Click on “New” button in New Loan Disbursement Payee Summary screen. Add Payee (E.g. 415). Check “Origination Fee”.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");

                Reports.TestStep = @"Navigate to New Loan | Loan Charges. Click on Pay Charges button. 
                                    Click on “New” button in New Loan Disbursement Payee Summary screen. Add Payee (E.g. 415). 
                                    Check “Origination Fee”.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "CLICK ON NEW BUTTON AND SELECT THE ANY CHARGE AND ENTER THE GAB CODE";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("415");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                FastDriver.NewLoanDisbursements.Charges3.FAClick();

                Reports.TestStep = "Add another Payee (E.g. BOA). Check “Adhoc Charge3” and click on Done.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("BOA");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, "Adhoc Charge3", 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen. Expand Loan Cost and verify the Payee Name.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();

                Reports.TestStep = "Verify Adhoc Charge3  to Bank of America";
                Support.AreEqual("03. Adhoc Charge3 to Bank of America", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 1, TableAction.Click).Element.Text);

                Reports.TestStep = "Origination Fee to Continental Mortgage Corporation ";
                //Hack: when click on a row, the table updated, so we need to reload the screen again
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Support.AreEqual("07. Origination Fee to Continental Mortgage", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.Click).Element.Text);

                Reports.TestStep = @"Navigate to New Loan Screen and modify the payee name. 
                                        Open PDD, deselect “Use Default” checkbox and change the payee name to “Modified Payee Name” for Adhoc Charge3.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "M0d!f!3d @dh0c CHARGE", 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Modified Payee Name");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("F!rst Americ@n Pay33 Name");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to CD Screen. Expand Loan Cost and verify the Payee Name.";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Reports.TestStep = "Verify Adhoc Charge2  to Modified Payee Name";
                Support.AreEqual("05. M0d!f!3d @dh0c CHARGE to Modified Payee Name", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "M0d!f!3d @dh0c CHARGE", 1, TableAction.Click).Element.Text);

                Reports.TestStep = "Verify Adhoc Charge3  to Bank of America";
                //Hack: when click on a row, the table updated, so we need to reload the screen again
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Support.AreEqual("03. Adhoc Charge3 to Bank of America", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 1, TableAction.Click).Element.Text);

                Reports.TestStep = "Origination Fee to Continental Mortgage Corporation ";
                //Hack: when click on a row, the table updated, so we need to reload the screen again
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Support.AreEqual("07. Origination Fee to Continental Mortgage", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.Click).Element.Text);

                Reports.TestStep = "Origination Fee to Continental Mortgage Corporation ";
                //Hack: when click on a row, the table updated, so we need to reload the screen again
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Support.AreEqual("08. Processing Fee to F!rst Americ@n Pay33 Name", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.Click).Element.Text);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionA_Scenario6()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A 2+ without entering values in PDD.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"); // BusinessSourceGABcode IDCode = 415
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion


                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = @"Select Loan Charges and enter values for charges in PDD as below:
                                        a.	Verification Fee – Check Part of Check box in PDD";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Verification Fee", 7, TableAction.SetText, "700");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Verification Fee", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$150.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$550.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$670.50" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$1370.50" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$560.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$780.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$450.49" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$1790.49" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"b.	Rate-Lock Fee";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Rate-Lock Fee", 7, TableAction.SetText, "2342342.56");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Rate-Lock Fee", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad("Payment Details");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$3444.56" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$234230.45" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$342342.56" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$580017.57" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$2342.56" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$32423.45" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$23423.45" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$58189.46" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"c.	Processing Fee";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Processing Fee", 7, TableAction.SetText, "10.34");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$3.67" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$7.89" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$67.78" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$79.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-MB");
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$56.7" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$44.60" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$34.67" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$135.97" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-MB");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"d.	Adhoc 1 Charge";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                int rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc Charge1" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge1", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Adhoc 1 Charge" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$3.67" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$7.89" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$67.78" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$79.34" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-MB");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"d.	Adhoc 2 Charge";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 7, TableAction.Click);
                Keyboard.SendKeys(FAKeys.TabAway); // TAB to create a new row
                rowCount = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(rowCount, 1, TableAction.SetTextByCellIndex, "Adhoc 2 Charge" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                Playback.Wait(5000);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.Description.FASetText("Adhoc 2 Charge" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$56.7" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$44.6" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$34.67" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$135.97" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Cost and verify if system displays values as entered in new loan screen";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = @"Adhoc 1 Charge";
                Support.AreEqual("02. Adhoc 1 Charge", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7.89", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 6, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Adhoc 2 Charge";
                Support.AreEqual("03. ** Adhoc 2 Charge", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$56.70", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$44.60", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$34.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 6, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Processing Fee";
                Support.AreEqual("04. ** Processing Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7.89", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$56.70", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$44.60", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$67.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Rate-Lock Fee";
                Support.AreEqual("05. Rate-Lock Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,444.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,230.45", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$32,423.45", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$342,342.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,342.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,343.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verification Fee";
                Support.AreEqual("06. ** Verification Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$150.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$550.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$560.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$780.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$670.50", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Select Good Faith Variance tab and verify the values displayed under 0% and Lender Credit Analysis.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();

                Reports.TestStep = @"Adhoc 2 Charge";
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$101.30", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$101.30", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Processing Fee";
                Support.AreEqual("$10", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$11.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$1.22", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Rate-Lock Fee";
                Support.AreEqual("$2,342,343", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$237,675.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,342.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verification Fee";
                Support.AreEqual("$700", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Verification Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Verification Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Verification Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Verification Fee", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,445.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,445.01", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$34.67", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 03 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$67.78", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 04 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,342.56", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 05 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"6.	Select Closing disclosure tab. Change sequence, Loan Estimate amount and Charge Description.
                                        a.	Add Loan Estimate rounded amount for Adhoc Charge 1 (E.g. 5604.56)
                                            i.	Pencil icon should be displayed
                                        b.	Modify Loan Estimate unrounded amount for Rate-Lock Fee (E.g. 14534.67)
                                        c.	Modify Description for Verification Fee. (E.g. Modified Charge in CD)";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "Edit Loan Estimate for Adhoc 1 Charge";
                //Hack: Use SendKeys becuase Clear() function doesn't work on this control
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 8, TableAction.Click);
                Keyboard.SendKeys("^A");
                Keyboard.SendKeys("{DELETE}");
                Keyboard.SendKeys("5604.56");
                Keyboard.SendKeys(FAKeys.TabAway);
                //Handle element no longer valid issue
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                bool isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 8, TableAction.GetCell).Element);
                Support.AreEqual("True", isDisplayed.ToString(), true);
                
                Reports.TestStep = "Edit Loan Estimate for Rate Lock Fee";
                //Hack: Use SendKeys becuase Clear() function doesn't work on this control, need to reload the screen after each row!!! :(
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                //Hack: Use SendKeys becuase Clear() function doesn't work on this control
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 7, TableAction.Click);
                Keyboard.SendKeys("^A");
                Keyboard.SendKeys("{DELETE}");
                Keyboard.SendKeys("14534.67");
                Keyboard.SendKeys(FAKeys.TabAway);
                
                Reports.TestStep = "Modify Description for Verification Fee. (E.g. Modified Charge in CD)";
                //Hack: Use SendKeys becuase Clear() function doesn't work on this control, need to reload the screen after each row!!! :(
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 1, TableAction.SetText, "Modified Charge in CD" + FAKeys.Tab);
                //Hack: Use SendKeys becuase Clear() function doesn't work on this control
                //FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 1, TableAction.Click);
                //Keyboard.SendKeys("^A");
                //Keyboard.SendKeys("{DELETE}");
                //Keyboard.SendKeys("Modified Charge in CD");
                //Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = @"Select Good Faith Variance tab and verify the values displayed under 0% and Lender Credit Analysis.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$101.30", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$101.30", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$700", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Modified Charge in CD", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Modified Charge in CD", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Modified Charge in CD", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Modified Charge in CD", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$10", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$11.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Processing Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$1.22", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Processing Fee", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$14,535", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$237,675.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,534.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Rate-Lock Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$223,140.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Rate-Lock Fee", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,445.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$34.67", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 03 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$67.78", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 05 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,342.56", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 06 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,445.01", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());
                
                Reports.TestStep = @"Navigate to New Loan screen and verify below values
                                    a.	Open PDD and verify Loan Estimate rounded amount for Adhoc Charge 1 (E.g. 5604.56)
                                    i.	Broken icon should be displayed";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$5,605.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());
                Support.AreEqual("true", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString(), true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"b.	Verify Loan Estimate unrounded amount for Rate-Lock Fee (E.g. 14534.67)";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Rate-Lock Fee", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$14,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$14,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());
                Support.AreEqual("false", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString(), true);
                FastDriver.DialogBottomFrame.ClickDone();
                
                Reports.TestStep = @"c.	Verify Description is changed for Verification Fee. (E.g. Modified Charge in CD)";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Modified Charge in CD", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Modified Charge in CD", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"9.	Open PDD for Adhoc Charge 2 and modify the Buyer charge and Seller charge.
                                        Buyer At Closing 	$33 	 
                                        Buyer Before Closing  	$67 	 
                                        Buyer Paid by Others  	$54.5 	(POC-L)
                                        Seller At Closing  	$34 	 
                                        Seller Before Closing  	$43 	 
                                        Seller Paid by Others  	$23 	 (POC-L)
                                        Loan Estimate Unrounded  	$60.67 	";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$60.67");
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$154.50" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$33.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$67.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$54.50" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$100.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$34.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$43.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$23.00" + FAKeys.Tab);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Click on Pay Charges add new payee information. (E.g. 214). Check Processing Fee and click on Done.";
                
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "CLICK ON NEW BUTTON AND SELECT THE ANY CHARGE AND ENTER THE GAB CODE";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("214");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                FastDriver.NewLoanDisbursements.Charges1.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to CD Screen and verify the values in CD screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Reports.TestStep = @"Adhoc 1 Charge";
                Support.AreEqual("02. Adhoc 1 Charge", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7.89", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,605.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 8, TableAction.GetText).Message.Trim());
                isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 8, TableAction.GetCell).Element);
                Support.AreEqual("True", isDisplayed.ToString(), true);

                Reports.TestStep = @"Adhoc 2 Charge";
                Support.AreEqual("03. Adhoc 2 Charge", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$33.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$67.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$43.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$54.50", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$61.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 8, TableAction.GetText).Message.Trim());
                isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 8, TableAction.GetCell).Element);
                Support.AreEqual("False", isDisplayed.ToString(), true);

                Support.AreEqual("04. ** Modified Charge in CD", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$150.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$550.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$560.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$780.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$670.50", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Processing Fee";
                Support.AreEqual("05. ** Processing Fee to Pnc Mortgage Corp. Of", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7.89", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$56.70", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$44.60", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("$67.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Rate-Lock Fee";
                Support.AreEqual("06. Rate-Lock Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,444.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,230.45", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$32,423.45", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 5, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$342,342.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,534.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,535.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 8, TableAction.GetText).Message.Trim());
                
                Reports.TestStep = @"Select Good Faith Variance tab and verify the values displayed under 0% and Lender Credit Analysis.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();

                Support.AreEqual("$61", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$60.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$39.33", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc 2 Charge", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$700", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Modified Charge in CD", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Modified Charge in CD", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Modified Charge in CD", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Modified Charge in CD", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$10", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$11.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Processing Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$1.22", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Processing Fee", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$14,535", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$237,675.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,534.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Rate-Lock Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$223,140.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Rate-Lock Fee", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,464.84", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits  (See Lender Credit Analysis)", 5, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionA_Scenario7()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A 2+ without entering values in PDD.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                #region create file
                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.FirstNewLoanAmount = (decimal)998764334.45; //TermsDatesNewLoanAmnt
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = @"Enter Buyer Charge, Seller and Loan Est. unrounded for any charges under Origination Charges. 
                                        (E.g. Application Fee – Buyer Charge = $18956.56, Seller Charge = $4565.56, Loan Est. unrounded = 4543.34)
                                        Enter Seller Charge and Loan Est. unrounded for any charges under Origination Charges. 
                                        (E.g. Origination Fee – Seller Charge = $9,434.78, Loan Est. unrounded = 23,423.56)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "18956.56");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 5, TableAction.SetText, "4565.56");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "4543.34");

                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 5, TableAction.SetText, " 9434.78");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 7, TableAction.SetText, "23423.56");

                Reports.TestStep = "Select Mortgage Broker tab.";
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Enter Broker Fee under Broker Fee section. (E.g. 98344.54)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("98344.54");

                Reports.TestStep = @"Navigate to CD Screen and verify the values in CD screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Support.AreEqual("02. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$18,956.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,565.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,543.34", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,543.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 8, TableAction.GetText).Message.Trim());

                Support.AreEqual("03. Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$98,344.54", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Broker Fee", 6, TableAction.GetText).Message.Trim());

                Support.AreEqual("04. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$9,434.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$23,423.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$23,424.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 8, TableAction.GetText).Message.Trim());
               
                Reports.TestStep = "Modify the Charge Description for Broker Fee. (E.g. Unauthenticated Broker Fee Updated as part of CD Screen)";
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Broker Fee", 1, TableAction.SetText, "Unauthenticated Broker Fee Updated");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Verify if Sequence is changed for the same. ";
                Support.AreEqual("02. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("03. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("04. Unauthenticated Broker Fee Updated", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Unauthenticated Broker Fee Updated", 1, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Verify the Charge Description displayed under Broker Fee section.";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FASetText(@"Unauthenticated Broker Fee Updated");

                Reports.TestStep = "Modify the Amount for Broker Fee. (E.g. 5460.00)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("5460.00");

                Reports.TestStep = "Modify Charge Description in Source Screen for Broker Fee. (E.g. A Updated Broker Fee)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FASetText("A Updated Broker Fee");

                Reports.TestStep = "Navigate to CD Screen and verify Broker Fee.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,460.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("03. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("04. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Good Faith Variance tab and verify if Broker Fee is not displayed in Good Faith Variance Screen.";
                FastDriver.ClosingDisclosure.GoToVarianceTab();
                Support.AreEqual("$4,543", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$18,956.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Application Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,543.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Application Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,413.22", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Application Fee", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual(string.Empty, FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Support.AreEqual("$14,413.22", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - 0% Category", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,413.22", FastDriver.ClosingDisclosure.GoodFaith0and10TotalTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - Total 0% and 10% Category", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Remove Broker Fee Amount.";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("" + FAKeys.Tab);

                Reports.TestStep = "Open PDD. Change the Payment Method as (POC-L), check “Display (L) on CD”. (E.g. 1231233.34)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true);
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsNewLoanDlg.DisplayLOnCD.FASetCheckbox(true);
                FastDriver.PaymentDetailsNewLoanDlg.FileCharge.FASetText("1231233.34" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to CD Screen and verify the amount displayed in A.02.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$1,231,233.34", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("03. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("04. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = @"Open PDD for Broker Fee.
                                    a.	Uncheck Use Default check box and update Pay To value. (E.g. Modified Payee Name)
                                    b.	Modify Amount. (E.g. 4500.56)
                                    c.	Uncheck “Display (L) on CD” check box.";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true);
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsNewLoanDlg.DisplayLOnCD.FASetCheckbox(false);
                FastDriver.PaymentDetailsNewLoanDlg.UseDefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsNewLoanDlg.PayTo.FASetText("Modified Payee Name");
                FastDriver.PaymentDetailsNewLoanDlg.FileCharge.FASetText("4500.56" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to CD Screen and verify the amount displayed in A.02.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,500.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = @"Select any Payment Method from the drop down. (E.g. RBL)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true);
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FASelectItemBySendingKeys("POC-L");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to CD Screen and verify the amount displayed in A.02.";
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,500.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("WF");
                FastDriver.NewLoan.MortgageFind.FAClick();

                Reports.TestStep = "Click on Pay Charges. Check Broker Fee Charge in Mortgage Broker Disbursement screen.";
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.Charges1.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen and verify the amount displayed in A.02.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,500.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
