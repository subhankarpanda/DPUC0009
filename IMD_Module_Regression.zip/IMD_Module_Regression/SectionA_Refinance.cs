﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using Microsoft.Win32;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using AutoIt;


namespace IMD_Module_Regression
{
    /// <summary>
    /// Section A Refinance
    /// </summary>
    [CodedUITest]
    public class SectionA_Refinance : MasterTestClass
    {

        #region Section A: New Loan | Credit/Charge points

        [TestMethod]
        public void SectionA_Refinance_Scenario1()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A – Line 1 without entering values in PDD (With Loan Amount).";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with First New Loan (E.g. 998764334.45) and with New Loan Lender (WF).";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.FirstNewLoanAmount = (decimal)998764334.45; //TermsDatesNewLoanAmnt
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan | Loan Charges.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");

                Reports.TestStep = "Enter % amount under Credit/Charge Points. (E.g. 99.500).";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("99.500");
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Buyer Charge will be auto calculated as user has entered Loan Amount and % of Loan Amount. (E.g. 993,770,512.78)";
                Support.AreEqual("993,770,512.78", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetValue(), "Buyer Charge");

                Reports.TestStep = @"Navigate to Closing Disclosure. Expand Loan Costs. Verify A01.
                                    i.	 % amount should be displayed as per source screen.
                                    ii.	 Buyer Amount should be displayed as the same is available in source screen.
                                    iii. Other fields should be blank.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();

                Reports.TestStep = "Validate Section A, % of Loan Amount";
                Support.AreEqual("99.5", FastDriver.ClosingDisclosure.Percentdisplay.Text, "Percent");
                Support.AreEqual("% of Loan Amount (Points)", FastDriver.ClosingDisclosure.PercentLoanAmountPoints.Text,"Percentage of Loan Amount");

                Reports.TestStep = "Validate Section A, Borrower charge amount";
                Support.AreEqual("$993,770,512.78", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text, "Borrower Paid at Closing");

                //                Reports.TestStep = "Verify Total for Section A,D,J";
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$993,770,512.78");
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$993,770,512.78");
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$993,770,512.78");
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$993,770,512.78");
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$993,770,512.78");

                Reports.TestStep = @"Select Good Faith Variance tab and verify the values displayed under 0% and Lender Credit Analysis.
                                    i.	 Description should be same as displayed in CD Screen.
                                    ii.	 Loan Estimate (Rounded) 	= $0
                                    iii. Final Amount 		= Buyer Charge(E.g. $993,770,512.78)
                                    iv.	 Loan Estimate (Rounded) 	= $0.00
                                    v.	 Amounts Exceeding 0% Good Faith Limit = Buyer Charge(E.g. $993,770,512.78)";

                GoToVarianceTab();
                Support.AreEqual("A 01 99.5 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim(), "Percentage of Loan Amount");
                Support.AreEqual("$993,770,512.78", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text, "Final Borrower Paid");
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text, "Loan Estimate (Unrounded)");

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.NonSpecificLenderCreditsAmount.Text, "NonSpecific Lender Credit");
                //Support.AreEqual("", FastDriver.ClosingDisclosure.SpecificLenderCreditsAmount.Text, "Specific Lender Credit");
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.LenderCreditsTotalAmount.Text, "Lender Credit Total");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Closing Disclosure tab. Expand Loan Cost. Check Display Loan Estimate columns Checkbox. Modify percentage (E.g. 50.45) and enter Loan estimate unrounded amount (E.g. 789678.78).";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(false);
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("50.45");
                FastDriver.ClosingDisclosure.Percentdisplay.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.FASetText("789678.78");
                FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.SendKeys(FAKeys.Tab);
                
                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                    i.	 Description should be same as displayed in CD Screen.
                                    ii.	 Loan Estimate (Rounded) 	= $789,679
                                    iii. Final Amount 		= Buyer Charge (E.g.  $503,876,606.73)
                                    iv.	 Loan Estimate (Unrounded) 	= $789,678.78
                                    v.	 Amounts Exceeding 0% Good Faith Limit = Final Amount – Loan Est. Unrounded amount(E.g. $503,086,927.95)";

                GoToVarianceTab();
                Support.AreEqual("A 01 50.45 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim());
                Support.AreEqual("$503,876,606.73", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text, "Final Borrower Paid");
                Support.AreEqual("$789,678.78", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text, "Loan Estimate (unrounded)");

                Reports.TestStep = @"Navigate to New Loan | Loan Charges and verify % and Buyer amount.
                                    i.	% should be updated as per CD Screen (E.g. 50.450)
                                    ii.	Buyer Charge should be updated. (E.g. 503,876,606.73)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("50.450", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetAttribute("value").Trim(), "Credit Charge");
                Support.AreEqual("503,876,606.73", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetAttribute("value").Trim(), "Buyer Charge");

                Reports.TestStep = "Modify Buyer Credit under Principal Balance Charges. (E.g. 55600.67)";
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FASetText("55600.67");

                // need this. sometimes the dialog doesn't popup after settext
                try { FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.SendKeys(FAKeys.Tab); }
                catch { }

                Reports.TestStep = "Click on Ok button in the warning message displayed.";
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);

                Reports.TestStep = "Buyer Charge under Credit/Charge Points gets modified. Add Seller (E.g. 6,700.89) and Loan Estimate Amount. (E.g. 6,787.8989)";
                FastDriver.NewLoan.SwitchToContentFrame();
                Support.AreEqual("28,050.54", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetAttribute("value").Trim(), "Buyer Charge");
                FastDriver.NewLoan.LoanChargesCredit_ChargeLoanEstimate.FASetText("6,787.89" + FAKeys.Tab);

                Reports.TestStep = @"Navigate to CD Screen and verify the amounts displayed
                                    i.	 % amount should be displayed as per source screen.
                                    ii.	 Borrower – At Closing should be displayed as the same is available in source screen.
                                    iii. Seller";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("50.45", FastDriver.ClosingDisclosure.Percentdisplay.Text, "Percent");
                Support.AreEqual("$28,050.54", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text, "Borrower Paid at Closing");
                Support.AreEqual("$6,787.89", FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.Text, "Loan Estimate (unrounded)");

                //                /******************/
                //                Reports.TestStep = "Verify total of A,D and J";
                //                ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$28,050.54");
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$28,050.54");
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$28,050.54");
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$28,050.54");
                //                FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$28,050.54~2~4~$6,700.89");

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                    i.	 Description should be same as displayed in CD Screen.
                                    ii.	 Loan Estimate (Unrounded) 	= $6,787.90
                                    iii. Final Amount 		= Buyer Charge (E.g.  $28,050.54)
                                    iv.	 Loan Estimate (Rounded) 	= $6,788
                                    v.	 Amounts Exceeding 0% Good Faith Limit = Final Amount – Loan Est. Unrounded amount(E.g. $21,262.64)";

                GoToVarianceTab();
                Support.AreEqual("A 01 50.45 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim(), "Description");
                Support.AreEqual("$6,788", FastDriver.ClosingDisclosure.LoanEstimateDisclosedRounded.Text, "Loan Estimate (rounded)");
                Support.AreEqual("$28,050.54", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text, "Final Borrower Paid");
                Support.AreEqual("$6,787.89", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text, "Loan Estimate (unrounded)");

                //                Feature5.SharedSteps.VerifyAggregateAmountForGFV("tblZeroPerVariance", 21262.65, null, null, null, null, null, null);
                //                Feature5.SharedSteps.VerifyAggregateAmountForGFV("tblCategoryTotal", null, null, null, null, null, null, 21262.65);

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.NonSpecificLenderCreditsAmount.Text, "NonSpecific Lender Credit");
                //Support.AreEqual("", FastDriver.ClosingDisclosure.SpecificLenderCreditsAmount.Text, "Specific Lender Credit"); //not displayed
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.LenderCreditsTotalAmount.Text, "Lender Credit");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Select Closing Disclosure tab. Expand Loan Cost. Check Display Loan Estimate columns Checkbox. Modify Loan Estimate – Unrounded Amount (E.g. 598787.67), modify Loan Estimate Rounded Amount. (E.g. 2342333.56)
                                    i.	System should allow user to enter amounts.
                                    ii.	System should display pencil icon near rounded amount.";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                //                Feature5.SharedSteps.IIS_CD_LoanEstimateColumn("sectiona", "50.45", "Edit", false, 598787.67M, false);
                //                Feature5.SharedSteps.IIS_CD_LoanEstimateColumn("sectiona", "50.45", "Edit", true, 2342333.56M, true);

                FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.SendKeys(Keys.Control + "a");
                FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.FASetText("598787.67 " + FAKeys.Tab);
                FastDriver.ClosingDisclosure.SectionALoanEstimateRounded.SendKeys(Keys.Control + "a");
                FastDriver.ClosingDisclosure.SectionALoanEstimateRounded.FASetText("2342333.56" + FAKeys.Tab);

                bool isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "% of Loan Amount (Points)", 8, TableAction.GetCell).Element);
                Support.AreEqual("True", isDisplayed.ToString(), true);

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                    i.	 Description should be same as displayed in CD Screen.
                                    ii.	 Loan Estimate (Rounded) 	= $2,342,334
                                    iii. Final Amount 		= Buyer Charge (E.g.  $28,050.54)
                                    iv.	 Loan Estimate (Unrounded) 	= $598,787.67
                                    v.	 Amounts Exceeding 0% Good Faith Limit = Final Amount – Loan Est. Unrounded amount. Since it is negative amount system should display $0.00";
                ReloadClosingDisclosureScreen();    // need this. sometimes, it doesn't click the variance tab.
                GoToVarianceTab();
                //                Feature5.SharedSteps.VerifyAmountForCategory("tblZeroPerVariance", 1, "A", 1, ("50.45 % of Loan Amount (Points)").Trim(), 2342334, 28050.54, 598787.67);

                Support.AreEqual("A 01 50.45 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim(), "Description");
                Support.AreEqual("$2,342,334", FastDriver.ClosingDisclosure.LoanEstimateDisclosedRounded.Text, "Loan Estimate Disclosed (rouded)");
                Support.AreEqual("$28,050.54", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text, "Final Borrower Paid");
                Support.AreEqual("$598,787.67", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text, "Loan Estimat (unrounded)");

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.NonSpecificLenderCreditsAmount.Text, "NonSpecific Lender Credit");
                //Support.AreEqual("", FastDriver.ClosingDisclosure.SpecificLenderCreditsAmount.Text, "Specific Lender Credit");
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.LenderCreditsTotalAmount.Text, "Lender Credit");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = @"Navigate to New Loan | Loan Charges section. Verify the Loan estimate (Unrounded) amount.
                                    i.	System should display the Loan Estimate (Rounded) and (Unrounded) amounts as entered in CD Screen.
                                    ii.	System should display pencil icon near rounded amount.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("50.450", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetAttribute("value").Trim(), "Credit Charge");
                Support.AreEqual("28,050.54", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetAttribute("value").Trim(), "Buyer Charge");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionA_Refinance_Scenario2()
        {

            try
            {
                Reports.TestDescription = "Verify charges in Section A – Line 1 without entering values in PDD (Without Loan Amount).";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file without Sales Price and with New Loan Lender.";
                CreateFileRequest fileRequest = new CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.TransactionTypeObjectCD = "MORTGMDEND";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan.LiabilityAmount = 0.00M;
                fileRequest.File.NewLoan.NewLoanAmount = 0.00M;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan | Loan Charges.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FASetText("56789.90");

                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Cost and verify the Description and Buyer Charge displayed in CD Screen.
                                    i.	 “% of Loan Amount (Points)” Should be editable.
                                    ii.	 Zero should be displayed as percentage as user has not entered % in New Loan Screen.
                                    iii. Borrower – At Closing should be $56,789.90 as user has entered the same in Source Screen.
                                    iv.	 All Other values including Loan Estimate (Unrounded and Rounded) should be blank.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 0 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)", "Description");
                Support.AreEqual("$56,789.90", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text, "Borrower at Closing");

                ///*****************/
                //ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //Reports.TestStep = "Verify total of A, D and J";
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$56,789.90");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$56,789.90");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$56,789.90");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$56,789.90");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$56,789.90");

                Reports.TestStep = "Select Good Faith Variance and verify if system displays the line under 0%.";
                GoToVarianceTab();
                Support.AreEqual("A 01 0 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim(), "Description");
                Support.AreEqual("$56,789.90", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text, "Final Borrower Paid");
                FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.SendKeys(""); // to set focus
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.VarianceLoanEstimateUnrounded.Text, "Loan Estimate (unrounded)");

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.NonSpecificLenderCreditsAmount.Text, "NonSpecific Lender Credits");
                Support.AreEqual("", FastDriver.ClosingDisclosure.SpecificLenderCreditsAmount.Text, "Specific Lender Credits");
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.LenderCreditsTotalAmount.Text, "Lender Credits");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Select Closing Disclosure tab. Expand Loan Cost. Modify % amount in CD Screen. (E.g. 999.99). Verify if system displays error message “Points percentage cannot be greater than 99.9999”";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("999.99");
                FastDriver.ClosingDisclosure.Percentdisplay.SendKeys(FAKeys.Tab);

                string sMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                Support.AreEqual("Points percentage cannot be greater than 99.9999", sMessage, "Error message");

                Reports.TestStep = "Update % amount in CD Screen. (E.g. 99.999). Verify if system displays recalculation message.";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("99.999");
                FastDriver.ClosingDisclosure.Percentdisplay.SendKeys(FAKeys.Tab);

                sMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                Support.AreEqual("Do you wish to recalculate Credit/Charge Points?", sMessage, "Error message");

                Reports.TestStep = "Click on Ok button and verify if Borrower – At Closing amount is removed as user has not entered Loan Amount.";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();

                Support.AreEqual("A 01 99.999 % of Loan Amount (Points)", "A 01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text.Trim() + " % of Loan Amount (Points)", "Description");

                Reports.TestStep = "Select Good Faith Variance tab and verify if amount is removed.";
                GoToVarianceTab();
                Support.AreEqual("False", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.Exists().ToString(), "Good faith Analysis data table exists");

                Reports.TestStep = @"Navigate to New Loan | Loan Charges screen and verify % and Buyer Charge.
                                    i.	 % should be updated to 99.999
                                    ii.	 Buyer Charge should be removed.
                                    iii. Other values should be blank.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual("99.999", FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetAttribute("value").Trim());
                Support.AreEqual("", FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetAttribute("value").Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionA_Refinance_Scenario3()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A – Line 1 by entering values in PDD (Without Loan Amount).";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file without Sales Price.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "CD";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan | Loan Details tab and add GAB Code. (E.g. 214)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("214");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                Reports.TestStep = "Select Loan Charges tab. Open PDD and enter Buyer and Seller – At Closing, Before Closing and Paid by Others. (E.g. 5600.67, 24235.56, 45344.56 (POC – L), Seller – 34534.56, 34534.67, 45233.56 (POC – L))";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();

                Reports.TestStep = "Enter buyer details in PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("5600.67");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("24235.56");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("45344.56");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.DisplayLBorrower.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                string sMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                Support.AreEqual("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", sMessage, "Error message");

                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Costs and Verify the amount displayed in A01.
                                    i.	 Borrower – At Closing = $5,600.67
                                    ii.	 Borrower – Before Closing = $24,235.56
                                    iii. Paid by Others =(L) $90,578.12";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 0 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)", "Description");
                Support.AreEqual("$5,600.67", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text, "Borrower at Closing");
                Support.AreEqual("$24,235.56", FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text, "Borrower Before Closing");
                Support.AreEqual("(L)$45,344.56", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text, "Paid by Other");

                ///*****************/
                //Reports.TestStep = "Verify total of A, D and J";
                //ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$29,836.23");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$29,836.23");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$5,600.67~2~3~$24,235.56");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$29,836.23");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$5,600.67~2~3~$24,235.56~2~6~$45,344.56");


                Reports.TestStep = "Select Good Faith Variance and verify if system displays the line under 0%.";
                GoToVarianceTab();

                Support.AreEqual("A 01 0 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithDescription.Text.Trim(), "Description");
                Support.AreEqual("$29,836.23", FastDriver.ClosingDisclosure.FinalBorrowerPaidAmount.Text.Trim(), "Final Borrower Paid");

                Reports.TestStep = "Verify J 00";
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$45,344.56", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$45,344.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$45,344.56", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$45,344.56", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$45,344.56", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 01 0 % of Loan Amount (Points)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$45,344.56", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Closing Disclosure tab and Modify the % amount (E.g. 23). Click on Ok button in recalculate pop up message.";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("23");
                FastDriver.ClosingDisclosure.Percentdisplay.SendKeys(FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

                Reports.TestStep = @"System should remove the Borrower – At Closing, Before Closing and Paid by Others.
                                    i.	Borrower – Paid – At Closing = Blank
                                    ii.	Borrower – Paid – Before Closing = Blank";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                Support.AreEqual("01 23 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under Good Faith Variance 0% and Lender Credit Analysis.
                                    i.	System should not display any values under 0% as Final Amount is blank for A 01.
                                    ii.	Lender Credit Analysis values should be $0.00";

                GoToVarianceTab();
                Support.AreEqual("False", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.Exists().ToString(), "Good Faith Analysis data table");

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Navigate to New Loan screen | Loan Charges tab. Open PDD for Credit/Charge points and verify the split values.
                                    i.	 Buyer – Paid – At Closing = $0.00
                                    ii.	 Buyer – Paid – Before Closing = $0.00
                                    iii. Buyer – Paid by Others = $0.00";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();

                Reports.TestStep = "Verify buyer details in PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Trim());
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("true", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString(), true);

                FastDriver.DialogBottomFrame.ClickDone();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionA_Refinance_Scenario4()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A – Line 1 by entering values in PDD (With Loan Amount).";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "LOAN";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan and Add GAB code. (E.g. 526)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("526");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("4566.78");

                Reports.TestStep = "Enter % amount for credit/charge points. (E.g. 3)";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("3");
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Open PDD and modify Buyer Charge, Seller Charge and Loan Estimate amount. (E.g. Buyer – At Closing = 178.8, Before Closing = 567.67, Paid by Others = 782.56 (POC), Seller – At Closing = 658.87, Before Closing = 687.34, Paid by Others = 879.45(POC), Loan Est. Unrounded = 879.45)";
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("178.8");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("567.67");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("782.56");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.DisplayLBorrower.FASetCheckbox(false);

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("879.45");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = @"Navigate to Closing Disclosure. Expand Loan Cost.
                                    a.	Borrower – Paid – At Closing = $178.80
                                    b.	Borrower – Paid – Before Closing = $567.67
                                    c.	Paid by Others = $1,662.01
                                    d.	Loan Estimate Unrounded = $879.45
                                    e.	Loan Estimate Rounded = $879";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 3 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$178.80", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual("$567.67", FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text);
                Support.AreEqual("$782.56", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text);

                ///******************/
                //Reports.TestStep = "Verify total of A, D and J";
                //ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$746.47");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$746.47");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$178.80~2~3~$567.67");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$746.47");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$178.80~2~3~$567.67~2~6~$782.56");

                Reports.TestStep = "Select Good Faith Variance tab and verify values displayed under Good Faith Variance 0% and Lender Credit Analysis.";
                GoToVarianceTab();
                Support.AreEqual("A 01 3 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 3 % of Loan Amount (Points)", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$879", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 3 % of Loan Amount (Points)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$746.47", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 3 % of Loan Amount (Points)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$879.45", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 3 % of Loan Amount (Points)", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Closing Disclosure tab. Modify % amount. (E.g. 00.688)";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("00.688");
                FastDriver.ClosingDisclosure.Percentdisplay.SendKeys(FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Reload CD Screen and expand Loan Cost and verify the values in A01 are not changed.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 0.688 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$178.80", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual("$567.67", FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text);
                Support.AreEqual("$782.56", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text);

                Reports.TestStep = "Modify % amount. (E.g. 00.688). Click on Ok button in recalculate pop up.";
                FastDriver.ClosingDisclosure.Percentdisplay.Clear();
                FastDriver.ClosingDisclosure.Percentdisplay.FASetText("00.688");
                FastDriver.ClosingDisclosure.Percentdisplay.SendKeys(FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = @"System should remove Buyer at Closing, Buyer before closing and Buyer – Paid by others and calculate % and Loan amount and display Buyer at Closing amount. (E.g. $31.42)
                                    a.	Borrower – Paid – At Closing = $31.42
                                    b.	Borrower – Paid – Before Closing = Blank
                                    c.	Paid by Others = $879.45 (Only Seller Paid by Others)
                                    d.	Loan Estimate Unrounded = $879.45
                                    e.	Loan Estimate Rounded = $879";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                Support.AreEqual("01 0.688 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$31.42", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual("", FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text);
                Support.AreEqual("", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text);

                ///******************/
                //Reports.TestStep = "Verify total of A, D and J";
                //ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$31.42");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$31.42");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$31.42");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$31.42");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$31.42");

                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("$879.45", FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.Text);
                Support.AreEqual("$879.00", FastDriver.ClosingDisclosure.SectionALoanEstimateRounded.Text);

                Reports.TestStep = "Select Good Faith Variance tab and verify values displayed under Good Faith Variance 0% and Lender Credit Analysis.";
                GoToVarianceTab();
                Support.AreEqual("A 01 0.688 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$879", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$31.42", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$879.45", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Navigate to New Loan screen | Loan Charges tab. Open PDD and verify the values displayed in PDD.
                                    a.	Buyer – At Closing = $31.42, 
                                    b.	Before Closing = 0.00, 
                                    c.	Paid by Others = 0.00";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();

                Reports.TestStep = "Verify buyer details in PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$31.42", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem());
                Support.AreEqual("false", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString(), true);

                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to Mortgage Broker tab and add Mortgage Broker. (E.g. 415)";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("415");
                FastDriver.NewLoan.MortgageFind.FAClick();

                Reports.TestStep = @"Select Loan Charges tab and Update values in PDD for % of Loan Amount (Points) under Credit/Charge Points. 
                                    a.	 Buyer – Paid – At Closing = $ 5,678.88
                                    b.	Buyer – Paid – Before Closing = $ 3,455.68
                                    c.	Buyer – Paid by Others = $ 87,689.67(POC – MB)
                                    d.	Loan Estimate Unrounded = $ 9,134.56
                                    e.	Loan Estimate Rounded = $5,879.00 (System should display Broken icon)
                                    f.	Check Double Asterisk checkbox.";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();

                Reports.TestStep = "Verify buyer details in PDD";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("5678.88");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("3455.68");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("87689.67");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.DisplayLBorrower.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);  //not in CodedUI, but needed
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("9134.56");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("5879.00");
                Support.AreEqual("true", FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString(), true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Cost. Check Display Loan Estimate Columns. Verify the values displayed in A01.
                                    a.	Borrower – Paid – At Closing = $5,678.88
                                    b.	Borrower – Paid – Before Closing = $3,455.68
                                    c.	Paid by Others = $90,032.23
                                    d.	Loan Estimate Unrounded = $ 9,134.56
                                    e.	Loan Estimate Rounded = $5,879.00 (System should display Pencil icon)
                                    f.	Double Asterisk should be displayed.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                Support.AreEqual("01 0.688 % of Loan Amount (Points)", "01 " + FastDriver.ClosingDisclosure.Percentdisplay.Text + " % of Loan Amount (Points)");
                Support.AreEqual("$5,678.88", FastDriver.ClosingDisclosure.BorrowerAtClosingAmount.Text);
                Support.AreEqual("$3,455.68", FastDriver.ClosingDisclosure.BorrowerBeforeClosingAmount.Text);
                Support.AreEqual("$87,689.67", FastDriver.ClosingDisclosure.PaidByOthersAmount.Text, false);
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("$9,134.56", FastDriver.ClosingDisclosure.SectionALoanEstimateUnrounded.Text, false);
                Support.AreEqual("$5,879.00", FastDriver.ClosingDisclosure.SectionALoanEstimateRounded.Text, false);
                Support.AreEqual("True", FastDriver.ClosingDisclosure.OriginalChargesDescription.Text.Contains("**").ToString(), false);

                Reports.TestStep = "Select Good Faith Variance tab and verify values displayed under Good Faith Variance 0% and Lender Credit Analysis.";
                GoToVarianceTab();
                Support.AreEqual("A 01 0.688 % of Loan Amount (Points)", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,879", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$9,134.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$9,134.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 01 0.688 % of Loan Amount (Points)", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify J 00";
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$87,689.67", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$87,689.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$87,689.67", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(3, "-$87,689.67", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$87,689.67", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion


        #region Section A: New Loan | Origination Charges

        [TestMethod]
        public void SectionA_Refinance_Scenario5_1()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A 2+ without entering values in PDD.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.FirstNewLoanAmount = (decimal)998764334.45; //TermsDatesNewLoanAmnt
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                int Description = 1;     // TODO: create a method: GetColumnIndex(this IWebElement, string ColumnName) returm ColumnIndex
                int BorrowerCharge = 3;
                int LoanEstimateUnrounded = 5;

                Reports.TestStep = "Enter Buyer Charge and Loan Est. unrounded for any charges under Origination Charges. (E.g. Application Fee – Buyer Charge = $5,434,656,789.99, Loan Est. unrounded = 2,423,423,423.00)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Application Fee", BorrowerCharge, TableAction.SetText, "5434656789.99");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Application Fee", LoanEstimateUnrounded, TableAction.SetText, "2,423,423,423.00");

                Reports.TestStep = "Enter Loan Est. unrounded for any charges under Origination Charges. (E.g. Origination Fee – Loan Est. unrounded = 23,423,423.56)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Origination Fee", LoanEstimateUnrounded, TableAction.SetText, "23,423,423.56");

                Reports.TestStep = "Enter Buyer Charge and Seller Charge for any charges under Origination Charges. (E.g. Underwriting Fee – Buyer Charge = $54634.67)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Underwriting Fee", BorrowerCharge, TableAction.SetText, "54634.67");

                Reports.TestStep = "Enter Loan Estimate Unrounded amount for any charges under Origination Charges (E.g. Processing Fee – Loan Est. Unrounded = $6,564.78)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Processing Fee", LoanEstimateUnrounded, TableAction.SetText, "6564.78");

                Reports.TestStep = "Enter Buyer Charge for Adhoc charges under Origination Charges. (E.g. Adhoc Charge1 – Buyer Charge = $ 342,342.67)";
                int lastRowIndex = FastDriver.NewLoan.OriginationChargesTable.GetRowCount() - 1;
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(lastRowIndex, Description, TableAction.SetTextByCellIndex, "Adhoc Charge1");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Adhoc Charge1", BorrowerCharge, TableAction.SetText, "342342.67" + FAKeys.Tab);

                Reports.TestStep = "Enter Buyer Charge and Loan Estimate for adhoc charges under Origination Charges. (E.g. Adhoc Charge3 – Buyer Charge = $7,678,678.98, Loan Est. unrounded = $34,234,234.00)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(++lastRowIndex, Description, TableAction.SetTextByCellIndex, "Adhoc Charge3" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Adhoc Charge3", BorrowerCharge, TableAction.SetText, "7678678.98" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Adhoc Charge3", LoanEstimateUnrounded, TableAction.SetText, "34234234.00" + FAKeys.Tab);

                Reports.TestStep = "Enter Loan Estimate Unrounded amount for adhoc charges under Origination Charges (E.g. Adhoc Charge4 – Loan Est. Unrounded = $980,990.78) ";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(++lastRowIndex, Description, TableAction.SetTextByCellIndex, "Adhoc Charge4" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Adhoc Charge4", LoanEstimateUnrounded, TableAction.SetText, "980,990.78" + FAKeys.Tab);

                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Cost. Check Display Loan Estimate columns checkbox.
                                    a.	System should display charges in Alphabetical order.
                                    b.	Adhoc Charge1 – Borrower – At Closing = $342,342.67                                  
                                    c.	Adhoc Charge3 – Borrower  – At Closing = $7,678,678.98,Loan Estimate Unrounded amount = $34,234,234.00, Loan Estimate rounded amount = $34,234,234.00
                                    d.	Adhoc Charge4 should not be displayed as user has not entered buyer/seller charge.
                                    e.	Application Fee – Borrower – At Closing = $434,656,789.99 (9.2 Format).                                 
                                    f.	Underwriting Fee – Borrower – At Closing = $54,634.67.
                                    g.	A – Borrower – Paid – Total = $442,732,446.31 (Since 5,442,732,446.31 is not 9.2 format system should display 442,732,446.31)
                                    h.	D – Should be same as A total.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Reports.TestStep = "System should display charges in Alphabetical order.";
                Reports.TestStep = "Adhoc Charge1 – Borrower – At Closing = $342,342.67";
                Support.AreEqual("02. Adhoc Charge1", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$342,342.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Adhoc Charge3 – Borrower  – At Closing = $7,678,678.98, Loan Estimate Unrounded amount = $34,234,234.00, Loan Estimate rounded amount = $34,234,234.00";
                Support.AreEqual("03. Adhoc Charge3", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Application Fee – Borrower – At Closing = $434,656,789.99 (9.2 Format)";    //correct amount per Report.TestStep above
                Support.AreEqual("04. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$434,656,789.99", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,423,423.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Underwriting Fee – Borrower – At Closing = $54,634.67";
                Support.AreEqual("05. Underwriting Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Underwriting Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$54,634.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Underwriting Fee", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                    a.	All the charges with Buyer Amount should be displayed as displayed below.
 	                                    Loan Estimate	Final	Loan Estimate	Amounts Exceeding
	                                    Disclosed (Rounded)	(Borrower Paid)	(Unrounded)	0% Good Faith Limit
                                      A 02 Adhoc Charge1	$0 	$342,342.67 	$0.00 	$342,342.67 
                                      A 04 Adhoc Charge3	$34,234,234 	$7,678,678.98 	$34,234,234.00 	$0.00 
                                      A 05 Application Fee	$423,423,423 	$434,656,789.99 	$423,423,423.00 	$11,233,366.99 
                                      A 07 Underwriting Fee	$0 	$54,634.67 	$0.00 	$54,634.67 ";

                GoToVarianceTab();
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$342,342.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$342,342.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$34,234,234", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$423,423,423", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$434,656,789.99", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Application Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,423,423.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Application Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$11,233,366.99", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Application Fee", 5, TableAction.GetText).Message.Trim());

                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Underwriting Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$54,634.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Underwriting Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Underwriting Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$54,634.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Underwriting Fee", 5, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Select Closing Disclosure tab. 
                                    Modify the Loan Estimate amount rounded for Adhoc Charge3. (E.g. 56778.89), 
                                    Add Loan Estimate amount unrounded for Adhoc Charge1 (E.g. 56564.45). 
                                    Modify Loan Est. unrounded amount for Application Fee (E.g. 523,423,423.67), 
                                    Edit charge description for Underwriting Fee (E.g. Modified Charge description).
                                    a.	System should allow user to add/Modify values.
                                    b.	Should display pencil icon for Adhoc Charge 3 as rounded amount was modified.";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 7, TableAction.SetText, Keys.Control + "a");
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 7, TableAction.SetText, "56564.45");

                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 8, TableAction.SetText, Keys.Control + "a");
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 8, TableAction.SetText, "56778.89");

                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, Keys.Control + "a");
                // for some reasons, it doesn't enter the last digit "7"
                //FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "523423423.67");
                Keyboard.SendKeys("523,423,423.67");

                //FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Underwriting Fee", 1, TableAction.SetText, Keys.Control + "a");
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Underwriting Fee", 1, TableAction.SetText, "Modified Charge description");

                Reports.TestStep = @"Select Good Faith Variance tab and verify values under 0% and Lender Credit Analysis.
                                    a.	Values should be displayed as below:
 	                                    Loan Estimate	Final	Loan Estimate	Amounts Exceeding
	                                    Disclosed (Rounded)	(Borrower Paid)	(Unrounded)	0% Good Faith Limit
                                        A 02 Adhoc Charge1 $56,564 	$342,342.67 	$56,564.45 	$285,778.22 
                                      A 03 Adhoc Charge3	$56,779 	$7,678,678.98 	$34,234,234.00 	$0.00 
                                      A 04 Application Fee	$523,423,424 	$434,656,789.99 	$523,423,423.67 	$911,233,366.32 
                                      A 05 Modified Charge description	$0 	$54,634.67 	$0.00 	$54,634.67";

                GoToVarianceTab();
                Support.AreEqual("$56,564", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$342,342.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$56,564.45", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$56,779", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$523,423,424", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$434,656,789.99", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Application Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$523,423,423.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Application Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Modified Charge description", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$54,634.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Modified Charge description", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Modified Charge description", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void SectionA_Refinance_Scenario5_2()
        {
            try
            {
                Reports.TestDescription = "Continuation (SectionA_Scenario5) - Verify charges in Section A 2+ without entering values in PDD.";

                Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file .";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("WF"); // BusinessSourceGABcode IDCode = WF
                fileRequest.File.BusinessParties[0].AdditionalRole.eAddtionalRole = AdditionalRoleType.NewLender;
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "REFI";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.FirstNewLoanAmount = (decimal)998764334.45; //TermsDatesNewLoanAmnt
                fileRequest.File.NewLoan = null;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = @"Navigate to New Loan | Loan Charge screen &
                                    verify if modified loan estimate amount is displayed and charge description is modified.
                                    a.	Open PDD for Adhoc Charge3 – Loan Est. rounded amount should be as per CD and broken link should be displayed. (E.g. 56778.89)";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                // enter charges as in previous test case: SectionA_Refiance_Scenario5_1
                int Description = 1;     // TODO: create a method: GetColumnIndex(this IWebElement, string ColumnName) returm ColumnIndex
                int BorrowerCharge = 3;
                int LoanEstimateUnrounded = 5;

                Reports.TestStep = "Enter Buyer Charge and Loan Est. unrounded for any charges under Origination Charges. (E.g. Application Fee – Buyer Charge = $5,434,656,789.99, Loan Est. unrounded = 523,423,423.67)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Application Fee", BorrowerCharge, TableAction.SetText, "5,434,656,789.99");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Application Fee", LoanEstimateUnrounded, TableAction.SetText, "523,423,423.67");

                Reports.TestStep = "Enter Loan Est. unrounded for any charges under Origination Charges. (E.g. Origination Fee – Loan Est. unrounded = 23,423,423.56)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Origination Fee", LoanEstimateUnrounded, TableAction.SetText, "23,423,423.56");

                Reports.TestStep = "Enter Buyer Charge and Seller Charge for any charges under Origination Charges. (E.g. Underwriting Fee – Buyer Charge = $54634.67)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Underwriting Fee", BorrowerCharge, TableAction.SetText, "54634.67");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Underwriting Fee", 1, TableAction.SetText, "Modified Charge description" + FAKeys.Tab);

                Reports.TestStep = "Enter Loan Estimate Unrounded amount for any charges under Origination Charges (E.g. Processing Fee – Loan Est. Unrounded = $6,564.78)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Processing Fee", LoanEstimateUnrounded, TableAction.SetText, "6564.78");

                Reports.TestStep = "Enter Buyer Charge for Adhoc charges under Origination Charges. (E.g. Adhoc Charge1 – Buyer Charge = $ 342,342.67)";
                int lastRowIndex = FastDriver.NewLoan.OriginationChargesTable.GetRowCount() - 1;
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(lastRowIndex, Description, TableAction.SetTextByCellIndex, "Adhoc Charge1");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Adhoc Charge1", BorrowerCharge, TableAction.SetText, "342342.67" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Adhoc Charge1", LoanEstimateUnrounded, TableAction.SetText, "56564.45" + FAKeys.Tab);

                Reports.TestStep = "Enter Loan Estimate Unrounded amount for adhoc charges under Origination Charges (E.g. Adhoc Charge4 – Loan Est. Unrounded = $980,990.78) ";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(++lastRowIndex, Description, TableAction.SetTextByCellIndex, "Adhoc Charge4" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Adhoc Charge4", LoanEstimateUnrounded, TableAction.SetText, "980,990.78" + FAKeys.Tab);

                // continue test... 
                // In CodedUI test, it verifies values because it uses old file from test case SectionA_Refinance_Scenario5_1.
                // In Selenium, it sets the values in new file (to make it the same as CodedUI)
                Reports.TestStep = "a.	Open PDD for Adhoc Charge3 – Loan Est. rounded amount should be as per CD and broken link should be displayed. (E.g. 56778.89)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(++lastRowIndex, Description, TableAction.SetTextByCellIndex, "Adhoc Charge3" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Adhoc Charge3", BorrowerCharge, TableAction.SetText, "7678678.98" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(Description, "Adhoc Charge3", LoanEstimateUnrounded, TableAction.SetText, "34234234.00" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$34,234,234.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$56,779.00" + FAKeys.Tab);
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.VerifyBrokenImage().ToString(), false);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "b.	Open PDD for Adhoc Charge1 – Loan Est. unrounded amount should be as per CD. (E.g. 56564.45)";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge1", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$56,564.45");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$56,564.00" + FAKeys.Tab);
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.VerifyBrokenImage().ToString(), false);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "c.	Open PDD for Application Fee – Loan Est. unrounded amount should be as per CD. (E.g. 523,423,423.67)";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$523,423,423.67");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$523,423,424.00" + FAKeys.Tab);
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.VerifyBrokenImage().ToString(), false);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "d.	Verify if Underwriting Fee is modified to Modified Charge description.";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Modified Charge description", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Modified Charge description", FastDriver.PaymentDetailsDlg.Description.FAGetValue(), true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"Modify amounts in new loan screen.
                                    a.	Application Fee –  Charge Description modify to Verify source Application Fee , Buyer Charge = 453434.56";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", BorrowerCharge, TableAction.SetText, "453434.56"); //Buyer Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", Description, TableAction.SetText, "Verify source Application Fee"); // Description

                Reports.TestStep = "b.	Origination Fee – Buyer Charge = 98798";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", BorrowerCharge, TableAction.SetText, "98798"); //Buyer Charge

                Reports.TestStep = "c.	Modified Charge description – Buyer Charge = 423322.56, Loan Est. unrounded = 43534.67";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Modified Charge description", BorrowerCharge, TableAction.SetText, "423322.56"); //Buyer Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Modified Charge description", LoanEstimateUnrounded, TableAction.SetText, "43534.67"); // Loan Estimate

                Reports.TestStep = "d.	Processing Fee – Add Buyer Amount = 6,564.78";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Processing Fee", BorrowerCharge, TableAction.SetText, "6564.78"); //Buyer Charge

                Reports.TestStep = "e.	Adhoc Charge1 - Buyer Charge = 63453.7";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge1", BorrowerCharge, TableAction.SetText, "63453.70"); //Buyer Charge

                Reports.TestStep = "f.	Adhoc Charge2–  Charge Description modify to M0d!f!3d @dh0c CHARGE - Buyer Charge = 3545345, Seller Charge = 878,988.87";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", 3, TableAction.SetText, "3545345.00"); //Buyer Charge
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge3", Description, TableAction.SetText, "M0d!f!3d @dh0c CHARGE"); // Description

                Reports.TestStep = "g.	Adhoc Charge 4 – Buyer Charge = 4233.54";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc Charge4", 3, TableAction.SetText, "4233.54"); //Buyer Charge

                Reports.TestStep = @"Navigate to CD Screen. Expand Loan Cost. Check Display Loan Estimate columns checkbox.
                                     A.  Origination Charges 	$12,273,831.12 	 	 	 	 	 	 
                                    01.   % of Loan Amount (Points)	 	 	 	 	 	 	 
                                    02. Adhoc Charge1 	$63,453.70 	 	$34,534.56 	 	 	$56,564.45 	$56,564.00 
                                    03. Adhoc Charge3 	$7,678,678.98 	 	$8,789,798.98 	 	 	$34,234,234.00 	    $56,779.00 
                                    04. Adhoc Charge4 	$4,233.54 	 	 	 	 	$980,990.78 	$980,991.00 
                                    05. M0d!f!3d @dh0c CHARGE 	$3,545,345.00 	 	$878,988.87 	 	 	Enter unrounded amt 	Enter rounded amt 
                                    06. Modified Charge description 	$423,322.56 	 	$6,854.67 	 	 	$43,534.67 	$43,535.00 
                                    07. Origination Fee 	$98,798.00 	 	 	 	 	$23,423,423.56 	$23,423,424.00 
                                    08. Processing Fee 	$6,564.78 	 	 	 	 	$6,564.78 	$6,565.00 
                                    09. Verify source Application Fee 	$453,434.56 	 	$34,534.56 	 	 	$523,423,423.67 	$523,423,424.00 ";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.Othercosts.FAClick();

                Reports.TestStep = @"System should display charges in Alphabetical order.
                                     Adhoc Charge1 - Buyer Charge = 63453.7, Seller Charge = 34534.56";
                Support.AreEqual("02. Adhoc Charge1", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$63,453.70", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge1", 2, TableAction.GetText).Message.Trim());

                //Reports.TestStep = "Adhoc Charge3 – Borrower  – At Closing = $7,678,678.98, Loan Estimate Unrounded amount = $34,234,234.00, Loan Estimate rounded amount = $56,779.00 ";
                //Support.AreEqual("03. Adhoc Charge3", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 1, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 7, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$56,779.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge3", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Adhoc Charge4 – Borrower  – At Closing = $4,233.54 , Loan Estimate Unrounded amount = $980,990.78 , Loan Estimate rounded amount = $980,991.00 ";
                Support.AreEqual("03. Adhoc Charge4", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,233.54", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$980,990.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$980,991.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Adhoc Charge2–  Charge Description modify to M0d!f!3d @dh0c CHARGE - Buyer Charge = 3545345";
                Support.AreEqual("04. M0d!f!3d @dh0c CHARGE", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "M0d!f!3d @dh0c CHARGE", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,545,345.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "M0d!f!3d @dh0c CHARGE", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Modified Charge description  – Borrower – At Closing =Buyer Charge =  $423,322.56, Loan Estimate Unrounded amount = $43,534.67 ";
                Support.AreEqual("05. Modified Charge description", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,322.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("$43,534.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$43,535.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge description", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Origination Fee – Buyer – At Closing = $98,798.00, Loan Estimate Unrounded amount = $23,423,423.56 ";
                Support.AreEqual("06. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$98,798.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$23,423,423.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$23,423,424.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Processing Fee  – Buyer – At Closing = $6,564.78 , Loan Estimate Unrounded amount = $6,564.78 ";
                Support.AreEqual("07. Processing Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,564.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,564.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,565.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify source Application Fee – Borrower – At Closing = $453,434.56 , Loan Estimate Unrounded amount = $523,423,423.67 ";
                Support.AreEqual("08. Verify source Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verify source Application Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$453,434.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verify source Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$523,423,423.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verify source Application Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$523,423,424.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verify source Application Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Good Faith Variance and verify value under 0% and Lender Credit Analysis.";

                GoToVarianceTab();
                Support.AreEqual("$56,564", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$63,453.70", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$56,564.45", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc Charge1", 4, TableAction.GetText).Message.Trim());

                //Support.AreEqual("$56,779", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 2, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$7,678,678.98", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 3, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge3", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$980,991", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge4", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,233.54", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge4", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$980,990.78", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Adhoc Charge4", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$56,779", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 M0d!f!3d @dh0c CHARGE", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,545,345.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 M0d!f!3d @dh0c CHARGE", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$34,234,234.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 M0d!f!3d @dh0c CHARGE", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$43,535", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Modified Charge description", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$423,322.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Modified Charge description", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$43,534.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Modified Charge description", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$23,423,424", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Origination Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$98,798.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Origination Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$23,423,423.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 06 Origination Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$6,565", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,564.78", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$6,564.78", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 07 Processing Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$523,423,424", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 08 Verify source Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$453,434.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 08 Verify source Application Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$523,423,423.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 08 Verify source Application Fee", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan | Loan Charges. Click on Pay Charges button. Click on “New” button in New Loan Disbursement Payee Summary screen. Add Payee (E.g. 415). Check “Origination Fee”.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");

                Reports.TestStep = @"Navigate to New Loan | Loan Charges. Click on Pay Charges button. 
                                    Click on “New” button in New Loan Disbursement Payee Summary screen. Add Payee (E.g. 415). 
                                    Check “Origination Fee”.";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "CLICK ON NEW BUTTON AND SELECT THE ANY CHARGE AND ENTER THE GAB CODE";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("415");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                //FastDriver.NewLoanDisbursements.Charges3.FAClick();
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, "Origination Fee", 1, TableAction.On);

                Reports.TestStep = "Add another Payee (E.g. BOA). Check “Adhoc Charge3” and click on Done.";
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("BOA");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                //FastDriver.NewLoanDisbursements.Charges5.FAClick();
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, "Adhoc Charge4", 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen. Expand Loan Cost and verify the Payee Name.";
                ReloadClosingDisclosureScreen();

                Reports.TestStep = "Verify Adhoc Charge4  to Bank of America";
                Support.AreEqual("03. Adhoc Charge4 to Bank of America", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 1, TableAction.Click).Element.Text);

                Reports.TestStep = "Origination Fee to Continental Mortgage Corporation ";
                ReloadClosingDisclosureScreen();
                Support.AreEqual("06. Origination Fee to Continental Mortgage", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.Click).Element.Text);

                Reports.TestStep = @"Navigate to New Loan Screen and modify the payee name. 
                                        Open PDD, deselect “Use Default” checkbox and change the payee name to “Modified Payee Name” for Adhoc Charge3.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "M0d!f!3d @dh0c CHARGE", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Modified Payee Name" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("F!rst Americ@n Pay33 Name" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to CD Screen. Expand Loan Cost and verify the Payee Name.";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                ReloadClosingDisclosureScreen();
                Reports.TestStep = "Verify Adhoc Charge2  to Modified Payee Name";
                Support.AreEqual("04. M0d!f!3d @dh0c CHARGE to Modified Payee Name", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "M0d!f!3d @dh0c CHARGE", 1, TableAction.Click).Element.Text);

                Reports.TestStep = "Verify Adhoc Charge4  to Bank of America";
                ReloadClosingDisclosureScreen();
                Support.AreEqual("03. Adhoc Charge4 to Bank of America", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc Charge4", 1, TableAction.Click).Element.Text);

                Reports.TestStep = "Origination Fee to Continental Mortgage Corporation ";
                ReloadClosingDisclosureScreen();
                Support.AreEqual("06. Origination Fee to Continental Mortgage", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.Click).Element.Text);

                Reports.TestStep = "Origination Fee to Continental Mortgage Corporation ";
                ReloadClosingDisclosureScreen();
                Support.AreEqual("07. Processing Fee to F!rst Americ@n Pay33 Name", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.Click).Element.Text);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionA_Refinance_Scenario6()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A 2+ without entering values in PDD.";

                #region data
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var VerificationtFee = new PaymentDetailsParameters()
                {
                    LoanEstimateUnrounded = 700,
                    BuyerAtClosing = 150,
                    BuyerBeforeClosing = 550,
                    BuyerPaidbyOther = 670.50,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    BuyerDoubleAsteriskChecked = true
                };

                var RateLockFee = new PaymentDetailsParameters()
                {
                    LoanEstimateUnrounded = 2342342.56,
                    BuyerAtClosing = 3444.56,
                    BuyerBeforeClosing = 234230.45,
                    BuyerPaidbyOther = 342342.56,
                    BuyerPaidbyOtherPaymentMethod = "POC-L"
                };

                var ProcessingFee = new PaymentDetailsParameters()
                {
                    LoanEstimateUnrounded = 10.34,
                    BuyerAtClosing = 3.67,
                    BuyerBeforeClosing = 7.89,
                    BuyerPaidbyOther = 67.78,
                    BuyerPaidbyOtherPaymentMethod = "POC-MB",
                    BuyerDoubleAsteriskChecked = true
                };

                var Adhoc2Charge = new PaymentDetailsParameters()
                {
                    BuyerAtClosing = 56.7,
                    BuyerBeforeClosing = 44.6,
                    BuyerPaidbyOther = 34.67,
                    BuyerPaidbyOtherPaymentMethod = "POC-L",
                    BuyerDoubleAsteriskChecked = true
                };
                #endregion
                bool isDisplayed = false;

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with New Lender.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"); // BusinessSourceGABcode IDCode = 415
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "MORTGMDEND";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan.LiabilityAmount = 0.00M;
                fileRequest.File.NewLoan.NewLoanAmount = 0.00M;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                //FastDriver.TopFrame.SearchFileByFileNumber("21510");

                Reports.TestStep = "Navigate to New Loan | Loan Charges.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = @"Select Loan Charges and enter values for charges in PDD as below:
                                a.	Verification Fee – Check Part of Check box in PDD";
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.OriginationChargesTable, "Verification Fee", FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(VerificationtFee);

                Reports.TestStep = "b.	Rate-Lock Fee";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.OriginationChargesTable, "Rate-Lock Fee", FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(RateLockFee);

                Reports.TestStep = "c.	Processing Fee";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.OriginationChargesTable, "Processing Fee", FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(ProcessingFee);

                Reports.TestStep = "d.	Adhoc 1 Charge";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                int lastRowIndex = FastDriver.NewLoan.OriginationChargesTable.GetRowCount();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(lastRowIndex, 1, TableAction.SetTextByCellIndex, "Adhoc 1 Charge" + FAKeys.Tab);
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 5, TableAction.SetText, FAKeys.Tab);   // to add a new row

                Reports.TestStep = "e.	Adhoc 2 Charge";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(++lastRowIndex, 1, TableAction.SetTextByCellIndex, "Adhoc 2 Charge" + FAKeys.Tab);
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.OriginationChargesTable, "Adhoc 2 Charge", FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails).WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(Adhoc2Charge);


                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);

                Reports.TestStep = "Navigate to CD Screen. Expand Loan Cost and verify if system displays values as entered in new loan screen";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                Support.AreEqual("$238,487.87", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A.  Origination Charges", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Adhoc 1 Charge Should not be displayed";
                //// Feature5.SharedSteps.IIS_CD_VerifyAmount(2, SharedSteps.Section.A, "Adhoc 1 Charge", null, null, null, 3.67, 7.89, 67.78, false);

                Reports.TestStep = "Adhoc 2 Charge";
                Support.AreEqual("$56.70", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$44.60", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$34.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 1, TableAction.Click).Element.Text.Contains("**").ToString());

                Reports.TestStep = "Processing Fee";
                ReloadClosingDisclosureScreen();
                Support.AreEqual("$3.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7.89", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$67.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 8, TableAction.GetText).Message.Trim());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.Click).Element.Text.Contains("**").ToString());

                Reports.TestStep = "Rate-Lock Fee";
                ReloadClosingDisclosureScreen();
                Support.AreEqual("$3,444.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,230.45", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$342,342.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,342.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,343.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 8, TableAction.GetText).Message.Trim());
                //Support.AreEqual("False", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 1, TableAction.Click).Element.Text.Contains("**").ToString());

                Reports.TestStep = "Verification Fee";
                ReloadClosingDisclosureScreen();
                Support.AreEqual("$150.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$550.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$670.50", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 1, TableAction.Click).Element.Text.Contains("**").ToString());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 8, TableAction.GetText).Message.Trim());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 1, TableAction.Click).Element.Text.Contains("**").ToString());

                Reports.TestStep = "Verify D Total";
                ReloadClosingDisclosureScreen();
                Support.AreEqual("$238,487.87", FastDriver.ClosingDisclosure.TotalLoanCostsTable.PerformTableAction(1, "D.  TOTAL LOAN COSTS (Borrower-Paid)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,654.93", FastDriver.ClosingDisclosure.TotalLoanCostsTable.PerformTableAction(1, "Loan Costs Subtotals (A + B + C)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,832.94", FastDriver.ClosingDisclosure.TotalLoanCostsTable.PerformTableAction(1, "Loan Costs Subtotals (A + B + C)", 3, TableAction.GetText).Message.Trim());

                Support.AreEqual("$238,487.87", FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(1, "J.  TOTAL CLOSING COSTS (Borrower-Paid)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,654.93", FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(1, "Closing Costs Subtotals (D + I)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,832.94", FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(1, "Closing Costs Subtotals (D + I)", 3, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed under 0% and Lender Credit Analysis.";

                GoToVarianceTab();
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$101.30", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc 2 Charge", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Processing Fee";
                Support.AreEqual("$10", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$11.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Processing Fee", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Rate-Lock Fee";
                Support.AreEqual("$2,342,343", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$237,675.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$2,342,342.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Rate-Lock Fee", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verification Fee";
                Support.AreEqual("$700", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Verification Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Verification Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Verification Fee", 4, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,445.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits (See Lender Credit Analysis)", 3, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                FastDriver.ClosingDisclosure.WaitForLenderCreditAnalisTable();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());

                Support.AreEqual("-$34.67", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 02 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$67.78", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 03 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,342.56", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 04 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,445.01", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Support.AreEqual("$102.52", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - 0% Category", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$102.52", FastDriver.ClosingDisclosure.GoodFaith0and10TotalTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - Total 0% and 10% Category", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"6.	Select Closing disclosure tab. Change sequence, Loan Estimate amount and Charge Description.
                                    a.	Add Loan Estimate rounded amount for Adhoc Charge 1 (E.g. 5604.56)
                                        i.	Pencil icon should be displayed
                                    b.	Modify Loan Estimate unrounded amount for Rate-Lock Fee (E.g. 14534.67)
                                    c.	Modify Description for Verification Fee. (E.g. Modified Charge in CD)";

                FastDriver.BottomFrame.Done();
                ReloadClosingDisclosureScreen();

                Reports.TestStep = "Edit Loan Estimate for Adhoc 2 Charge";
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 7, TableAction.SetText, Keys.Control + "a");
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 7, TableAction.SetText, "5604.56" + FAKeys.Tab);
                ReloadClosingDisclosureScreen();
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 8, TableAction.SetText, Keys.Control + "a");
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 8, TableAction.SetText, "560.56" + FAKeys.Tab);
                ReloadClosingDisclosureScreen();
                isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 8, TableAction.GetCell).Element);
                Support.AreEqual("True", isDisplayed.ToString(), true);

                Reports.TestStep = "Edit Loan Estimate for Rate Lock Fee";
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 7, TableAction.SetText, Keys.Control + "a");
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 7, TableAction.SetText, "14534.67" + FAKeys.Tab);

                Reports.TestStep = "Modify Description for Verification Fee. (E.g. Modified Charge in CD)";
                ReloadClosingDisclosureScreen();
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Verification Fee", 1, TableAction.SetText, "Modified Charge in CD" + FAKeys.Tab);

                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed under 0% and Lender Credit Analysis.";
                GoToVarianceTab();

                Support.AreEqual("$561", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$101.30", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,604.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc 2 Charge", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$700", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Modified Charge in CD", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Modified Charge in CD", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Modified Charge in CD", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$10", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$11.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$14,535", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$237,675.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,534.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits (See Lender Credit Analysis)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,445.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits (See Lender Credit Analysis)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits (See Lender Credit Analysis)", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                FastDriver.ClosingDisclosure.WaitForLenderCreditAnalisTable();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$34.67", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 02 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$67.78", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 04 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,342.56", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "A 05 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,445.01", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Support.AreEqual("$223,141.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - 0% Category", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$223,141.56", FastDriver.ClosingDisclosure.GoodFaith0and10TotalTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - Total 0% and 10% Category", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Navigate to New Loan screen and verify below values
                                    a.	Open PDD and verify Loan Estimate rounded amount for Adhoc Charge 2 (E.g. 5604.56)
                                    i.	Broken icon should be displayed";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$5,604.56", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$561.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.VerifyBrokenImage().ToString(), true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "b.	Verify Loan Estimate unrounded amount for Rate-Lock Fee (E.g. 14534.67)";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Rate-Lock Fee", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$14,534.67", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$14,535.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());
                Support.AreEqual("False", FastDriver.PaymentDetailsDlg.VerifyBrokenImage().ToString(), true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "c.	Verify Description is changed for Verification Fee. (E.g. Modified Charge in CD)";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Modified Charge in CD", 1, TableAction.Click);
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("Modified Charge in CD", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = @"9.	Open PDD for Adhoc Charge 2 and modify the Buyer charge .
                                    Buyer At Closing 	$33 	 
                                    Buyer Before Closing  	$67 	 
                                    Buyer Paid by Others  	$54.5 	(POC-L)";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.OpenPaymentDetailsDialog(FastDriver.NewLoan.OriginationChargesTable, "Adhoc 2 Charge", FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails).WaitForScreenToLoad();

                Adhoc2Charge = new PaymentDetailsParameters()
                {
                    BuyerAtClosing = 33,
                    BuyerBeforeClosing = 67,
                    BuyerPaidbyOther = 54.50,
                    BuyerPaidbyOtherPaymentMethod = "POC-L",
                    BuyerDoubleAsteriskChecked = false,
                };
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(Adhoc2Charge);

                Reports.TestStep = "Click on Pay Charges add new payee information. (E.g. 214). Check Processing Fee and click on Done.";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();

                Reports.TestStep = "CLICK ON NEW BUTTON AND SELECT THE ANY CHARGE AND ENTER THE GAB CODE";
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                FastDriver.NewLoanDisbursements.New.FAClick();
                FastDriver.NewLoanDisbursements.GABcode.FASetText("214");
                FastDriver.NewLoanDisbursements.Find.FAClick();
                FastDriver.NewLoanDisbursements.Charges1.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen and verify the values in CD screen.";
                ReloadClosingDisclosureScreen();

                //Reports.TestStep = "Verify total of A, D and J";
                //ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$238,486.57~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$238,486.57~1~3~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$3,631.23~2~3~$234,855.34");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$238,486.57~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$3,631.23~2~3~$234,855.34~2~4~~2~5~~2~6~$343,135.34");

                //Reports.TestStep = @"Adhoc 1 Charge";
                //Support.AreEqual("02. Adhoc 1 Charge", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 1, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$3.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 4, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$7.89", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 5, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$67.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 6, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$5,605.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 8, TableAction.GetText).Message.Trim());
                //isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 1 Charge", 8, TableAction.GetCell).Element);
                //Support.AreEqual("True", isDisplayed.ToString(), true);

                Reports.TestStep = "Adhoc 2 Charge";
                Support.AreEqual("02. Adhoc 2 Charge", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$33.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$67.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$54.50", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,604.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$561.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 8, TableAction.GetText).Message.Trim());
                isDisplayed = FastDriver.ClosingDisclosure.IsBrokenLinkDisplayed(FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Adhoc 2 Charge", 8, TableAction.GetCell).Element);
                Support.AreEqual("True", isDisplayed.ToString(), true);

                Reports.TestStep = "Modified Charge in CD";
                Support.AreEqual("03. ** Modified Charge in CD", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$150.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$550.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$670.50", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Modified Charge in CD", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Processing Fee";
                Support.AreEqual("04. ** Processing Fee to Pnc Mortgage Corp. Of", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$7.89", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$67.78", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Processing Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Rate-Lock Fee";
                Support.AreEqual("05. Rate-Lock Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$3,444.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$234,230.45", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$342,342.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,534.67", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,535.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Rate-Lock Fee", 8, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed under 0% and Lender Credit Analysis.";
                GoToVarianceTab();

                Support.AreEqual("$561", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc 2 Charge", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc 2 Charge", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,604.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 02 Adhoc 2 Charge", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$700", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Modified Charge in CD", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Modified Charge in CD", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Modified Charge in CD", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$10", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$11.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$10.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 04 Processing Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$14,535", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$237,675.01", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,534.67", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 05 Rate-Lock Fee", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$0", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits (See Lender Credit Analysis)", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("-$342,464.84", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits (See Lender Credit Analysis)", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "J 00 Lender Credits (See Lender Credit Analysis)", 4, TableAction.GetText).Message.Trim());

                Support.AreEqual("$223,141.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - 0% Category", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$223,141.56", FastDriver.ClosingDisclosure.GoodFaith0and10TotalTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - Total 0% and 10% Category", 2, TableAction.GetText).Message.Trim());

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void SectionA_Refinance_Scenario7()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section A 2+ without entering values in PDD.";

                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file with New Lender.";
                FASTWCFHelpers.FastFileService.CreateFileRequest fileRequest = new FASTWCFHelpers.FastFileService.CreateFileRequest();
                fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"); // BusinessSourceGABcode IDCode = 415
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Santa Ana";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Orange";
                fileRequest.File.NewLoan.LiabilityAmount = 0.00M;
                fileRequest.File.NewLoan.NewLoanAmount = 0.00M;
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                //FastDriver.TopFrame.SearchFileByFileNumber("21510");

                Reports.TestStep = "Navigate to New Loan Screen | Loan Charges tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = @"Enter Buyer Charge and Loan Est. unrounded for any charges under Origination Charges. 
                                    (E.g. Application Fee – Buyer Charge = $18956.56, Loan Est. unrounded = 4543.34)
                                    EnterLoan Est. unrounded for any charges under Origination Charges. 
                                    (E.g. Origination Fee – Loan Est. unrounded = 23,423.56)";
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 3, TableAction.SetText, "18956.56");
                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.SetText, "4543.34");

                FastDriver.NewLoan.OriginationChargesTable.PerformTableAction(1, "Origination Fee", 7, TableAction.SetText, "23423.56");

                Reports.TestStep = "Select Mortgage Broker tab.";
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Enter Broker Fee under Broker Fee section. (E.g. 98344.54)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("98344.54");

                Reports.TestStep = "Navigate to CD Screen and verify the values in CD screen.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                Support.AreEqual("02. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$18,956.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,543.34", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 7, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,543.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 8, TableAction.GetText).Message.Trim());

                Support.AreEqual("03. Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$98,344.54", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Broker Fee", 6, TableAction.GetText).Message.Trim());

                //Support.AreEqual("04. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$23,423.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 7, TableAction.GetText).Message.Trim());
                //Support.AreEqual("$23,424.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 8, TableAction.GetText).Message.Trim());

                ///******************/
                //Reports.TestStep = "Verify total of A, D and J";
                //ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$18,956.56~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$18,956.56~1~3~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$18,956.56~2~3~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$18,956.56~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$18,956.56~2~3~~2~4~~2~5~~2~6~$98,344.54");

                Reports.TestStep = "Modify the Charge Description for Broker Fee. (E.g. Unauthenticated Broker Fee Updated as part of CD Screen)";
                //ReloadClosingDisclosureScreen();
                FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Broker Fee", 1, TableAction.SetText, "Unauthenticated Broker Fee Updated as part of CD Screen" + FAKeys.Tab);

                Reports.TestStep = "Verify if Sequence is changed for the same. ";
                Support.AreEqual("02. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                //Support.AreEqual("03. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("03. Unauthenticated Broker Fee Updated as part of CD Screen", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Unauthenticated Broker Fee Updated as part of CD Screen", 1, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Verify the Charge Description displayed under Broker Fee section.";
                Support.AreEqual("Unauthenticated Broker Fee Updated as part of CD Screen", FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FAGetAttribute("value"));

                Reports.TestStep = "Modify the Amount for Broker Fee. (E.g. 5460.00)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("5460.00");

                Reports.TestStep = "Modify Charge Description in Source Screen for Broker Fee. (E.g. A Updated Broker Fee)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FASetText("A Updated Broker Fee");

                Reports.TestStep = "Navigate to CD Screen and verify Broker Fee.";
                ReloadClosingDisclosureScreen();

                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$5,460.00", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("03. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                //Support.AreEqual("04. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Select Good Faith Variance tab and verify if Broker Fee is not displayed in Good Faith Variance Screen.";
                GoToVarianceTab();
                Support.AreEqual("$4,543", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Application Fee", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$18,956.56", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Application Fee", 3, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,543.34", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "A 03 Application Fee", 4, TableAction.GetText).Message.Trim());

                Reports.TestStep = @"Verify Lender Credit Analysis";
                FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Non-Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Specific Lender Credits", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$0.00", FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(1, "Lender Credits Total (J) Excluding Good Faith Violation", 2, TableAction.GetText).Message.Trim());

                Support.AreEqual("$14,413.22", FastDriver.ClosingDisclosure.GoodFaithAnalysisDataTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - 0% Category", 2, TableAction.GetText).Message.Trim());
                Support.AreEqual("$14,413.22", FastDriver.ClosingDisclosure.GoodFaith0and10TotalTable.PerformTableAction(1, "Increase in Closing Costs above legal limits - Total 0% and 10% Category", 2, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Remove Broker Fee Amount.";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("" + FAKeys.Tab);

                Reports.TestStep = "Open PDD. Change the Payment Method as (POC-L), check “Display (L) on CD”. (E.g. 1231233.34)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true);
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsNewLoanDlg.DisplayLOnCD.FASetCheckbox(true);
                FastDriver.PaymentDetailsNewLoanDlg.FileCharge.FASetText("1231233.34" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to CD Screen and verify the amount displayed in A.02.";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                ReloadClosingDisclosureScreen();

                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("(L)$1,231,233.34", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());
                Support.AreEqual("03. Application Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Application Fee", 1, TableAction.GetText).Message.Trim());
                //Support.AreEqual("04. Origination Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "Origination Fee", 1, TableAction.GetText).Message.Trim());

                ///******************/
                //Reports.TestStep = "Verify total of A, D and J";
                //ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$18,956.56~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$18,956.56~1~3~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$18,956.56~2~3~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$18,956.56~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$18,956.56~2~3~~2~4~~2~5~~2~6~$1,231,233.34");

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = @"Open PDD for Broker Fee.
                                    a.	Uncheck Use Default check box and update Pay To value. (E.g. Modified Payee Name)
                                    b.	Modify Amount. (E.g. 4500.56)
                                    c.	Uncheck “Display (L) on CD” check box.";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true);
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsNewLoanDlg.DisplayLOnCD.FASetCheckbox(false);
                FastDriver.PaymentDetailsNewLoanDlg.UseDefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsNewLoanDlg.PayTo.FASetText("Modified Payee Name");
                FastDriver.PaymentDetailsNewLoanDlg.FileCharge.FASetText("4500.56" + FAKeys.Tab);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to CD Screen and verify the amount displayed in A.02.";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                ReloadClosingDisclosureScreen();
                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,500.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());

                ///******************/
                //Reports.TestStep = "Verify total of A, D and J";
                //ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$18,956.56~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$18,956.56~1~3~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$18,956.56~2~3~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$18,956.56~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$18,956.56~2~3~~2~4~~2~5~~2~6~$4,500.56");

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Select any Payment Method from the drop down. (E.g. RBL)";
                FastDriver.NewLoan.MortgageYieldSpreadPremiumPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true);
                FastDriver.PaymentDetailsNewLoanDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsNewLoanDlg.PaymentMethod.FASelectItem("POC-L");
                //Keyboard.SendKeys(FAKeys.TabAway); why???
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to CD Screen and verify the amount displayed in A.02.";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
                ReloadClosingDisclosureScreen();
                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,500.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());

                Reports.TestStep = "Navigate to New Loan Screen | Mortgage Broker Tab.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("WF");
                FastDriver.NewLoan.MortgageFind.FAClick();

                Reports.TestStep = "Click on Pay Charges. Check Broker Fee Charge in Mortgage Broker Disbursement screen.";
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                FastDriver.NewLoanDisbursements.SwitchToContentFrame();
                FastDriver.NewLoanDisbursements.Charges1.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen and verify the amount displayed in A.02.";
                ReloadClosingDisclosureScreen();
                Support.AreEqual("02. A Updated Broker Fee", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 1, TableAction.GetText).Message.Trim());
                Support.AreEqual("$4,500.56", FastDriver.ClosingDisclosure.OriginalChargesTable.PerformTableAction(1, "A Updated Broker Fee", 6, TableAction.GetText).Message.Trim());

                ///******************/
                //Reports.TestStep = "Verify total of A, D and J";
                //ClosingDisclosure.SetParent("IIS.ClosingDisclosure", "ClosingDisclosure");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_A", "1~1~A.  Origination Charges~1~2~$18,956.56~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "1~1~D.  TOTAL LOAN COSTS (Borrower-Paid)~1~2~$18,956.56~1~3~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblLoanCostSubSection_D", "2~1~Loan Costs Subtotals (A + B + C)~2~2~$18,956.56~2~3~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "1~1~J.  TOTAL CLOSING COSTS (Borrower-Paid)~1~2~$18,956.56~1~3~~1~4~~1~5~");
                //FASTLibrary.IMDLib.VERIFYVALUESINTABLE("tblOtherCostSubSection_J", "2~1~Closing Costs Subtotals (D + I)~2~2~$18,956.56~2~3~~2~4~~2~5~~2~6~$4,500.56");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion


        #region private methods

        private static void ReloadClosingDisclosureScreen()
        {
            FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>Escrow Closing>Closing Disclosure");
            FastDriver.ClosingDisclosure.WaitForScreenToLoad();
            FastDriver.ClosingDisclosure.LoanCosts.FAClick();
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
        }

        private void GoToVarianceTab()
        {
            // need to click the ClosingDisclosure tab first to solve issue when testing on some resolutions i.e. 1280x768
            FastDriver.ClosingDisclosure.tabClosingDisclosure.FAClick();
            FastDriver.ClosingDisclosure.WaitForScreenToLoad();
            FastDriver.ClosingDisclosure.VarianceTab.FAClick();
            FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();
        }

        #endregion         
        
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
