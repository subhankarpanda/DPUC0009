﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using SeleniumInternalHelpers;
using System.Runtime.Serialization;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium;
using System.Collections.ObjectModel;
using AutoIt;
using System.Globalization;
using System.Collections.Generic;
using System.Windows.Input;


namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class CD_Fee_BCH_Sections : MasterTestClass
    {
        string PayeeName = string.Empty;
        
        public CD_Fee_BCH_Sections()
        {

        }

        [TestMethod]
        public void Fee_BCH_Scenario_1()
        {
            try
            {
                Reports.TestDescription = "Verifying The Fees behaviour on CD screen for Section B,C,H";
                #region INITIALIZE VARIABLES
                string ChargeDescription_1 = "Cancellation Fee-Escrow"; //Escrow Fee
                string ChargeDescription_2 = "General Excise Tax"; //OtherFee
                string ChargeDescription_3 = "ALTA 8.1-Environmental Liens"; //Title Endorsement fee
                string ChargeDescription_4 = "1999 Eagle Manufactured Home Jr. Lien Policy"; //Title Lender Policy
                string ChargeDescription_5 = "Bundle Breakout";
                string PayeeName_1 = "to ";
                string PayeeName_2 = "to ";
                string PayeeName_3 = "to ";
                string PayeeName_4 = "to ";
                string PayeeName_5 = "to ";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
            {
                new FileBusinessParty()
                {
                    //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                    AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                    RoleTypeObjectCD = "BUSSOURCE"
                }
            };
                customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "Santa Ana", 
                            County = "Orange", 
                            Country = "USA" 
                        } 
                    } 
                } 
            };
                #endregion
                #region CreateNewLoan
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region NAVIGATE TO THE FEE ENTRY SCREEN
                Reports.TestStep = "Navigate to the Fee Entry screem";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectAndVerifyParticularFeeOnFeeEntryScreen(ChargeDescription_1);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectAndVerifyParticularFeeOnFeeEntryScreen(ChargeDescription_2);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectAndVerifyParticularFeeOnFeeEntryScreen(ChargeDescription_3);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectAndVerifyParticularFeeOnFeeEntryScreen(ChargeDescription_4);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectAndVerifyParticularFeeOnFeeEntryScreen(ChargeDescription_5);
                #endregion

                #region CHARGE DESCRIPTION 1
                Reports.TestStep = "Provide the Data for " + ChargeDescription_1 + " as per the requirement";
                FastDriver.FileFees.ProvideTheDataOnFeeEntryScreen(ChargeDescription_1, "Loan Estimate Unrounded", "$5,423,723,223.00", "SET");
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
                //CLICK ON THE RESPECTIVE PDD
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", ChargeDescription_1, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                FastDriver.PaymentDetails.BuyerCharge.FASetText("1,166.54");
                FastDriver.PaymentDetails.BuyerAtClosing.FASetText("$98.67");
                FastDriver.PaymentDetails.BuyerBeforeClosing.FASetText("$1,000");
                FastDriver.PaymentDetails.BuyerPaidByOthers.FASetText("$67.87");
                FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItemBySendingKeys("Lender");
                FastDriver.PaymentDetails.BuyerDisplayL.FASetCheckbox(true);//this is necessary for the following verification section
                FastDriver.PaymentDetails.AdditionalDesc.FASetText("Updated_Description");
                FastDriver.PaymentDetails.DoubleAsteriskFlag.FASetCheckbox(false);
                PayeeName_1 = PayeeName_1 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion
                #region CHARGE DESCRIPTION 2
                FastDriver.FileFees.SwitchToContentFrame();
                Reports.TestStep = "Provide the Data for " + ChargeDescription_2 + " as per the requirement";
                //FastDriver.FileFees.ProvideTheDataOnFeeEntryScreen(ChargeDescription_2, "Seller Charge", "$3,156,689.78", "SET");
                FastDriver.FileFees.ProvideTheDataOnFeeEntryScreen(ChargeDescription_2, "Seller Charge", "$3,56,689.78", "SET");
                //CLICK ON THE RESPECTIVE PDD
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", ChargeDescription_2, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.LERounded.FASetText("$12,123,523.56");
                PayeeName_2 = PayeeName_2 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.PaymentDetails.PartOf.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.BottomFrame.Done();
                #endregion
                #region CHARGE DESCRIPTION 3
                Reports.TestStep = "Provide the Data for " + ChargeDescription_3 + " as per the requirement";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
                //CLICK ON THE RESPECTIVE PDD
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", ChargeDescription_3, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                FastDriver.PaymentDetails.BuyerCharge.FASetText("8,363.98");
                FastDriver.PaymentDetails.BuyerAtClosing.FASetText("$678.98");
                FastDriver.PaymentDetails.BuyerBeforeClosing.FASetText("$7,678");
                FastDriver.PaymentDetails.BuyerPaidByOthers.FASetText("$7");
                FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItemBySendingKeys("Lender");
                FastDriver.PaymentDetails.BuyerDisplayL.FASetCheckbox(true);//this is necessary for the following verification section
                FastDriver.PaymentDetails.SellerCharge.FASetText("245.55");
                FastDriver.PaymentDetails.SellerAtClosing.FASetText("$78.90");
                FastDriver.PaymentDetails.SellerBeforeClosing.FASetText("$87.67");
                FastDriver.PaymentDetails.SellerPaidbyOthers.FASetText("$78.98");
                FastDriver.PaymentDetails.SellerPaidbyOthersPayMethod.FASelectItem("Lender");
                FastDriver.PaymentDetails.PartOf.FASetCheckbox(true);
                PayeeName_3 = PayeeName_3 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.PaymentDetails.SectionB.Click();//In EVAL02 this fee appears on SectionC instead of SectionB
                FastDriver.PaymentDetails.LenderAffiliate.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion
                #region CHARGE DESCRIPTION 4
                Reports.TestStep = "Provide the Data for " + ChargeDescription_4 + " as per the requirement";
                FastDriver.FileFees.ProvideTheDataOnFeeEntryScreen(ChargeDescription_4, "Buyer Charge", "$87,878.66", "SET");
                FastDriver.FileFees.ProvideTheDataOnFeeEntryScreen(ChargeDescription_4, "Seller Charge", "$96,598.88", "SET");
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("$184,478.54");
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
                //CLICK ON THE RESPECTIVE PDD
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", ChargeDescription_4, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                PayeeName_4 = PayeeName_4 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion
                #region CHARGE DESCRIPTION 5
                Reports.TestStep = "Provide the Data for " + ChargeDescription_5 + " as per the requirement";
                FastDriver.FileFees.ProvideTheDataOnFeeEntryScreen(ChargeDescription_5, "Loan Estimate Unrounded", "$480,890.58 ", "SET");

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", ChargeDescription_5, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                PayeeName_5 = PayeeName_5 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion
                #region EXPAND LOAN COST
                Reports.TestStep = "Navigate to CD Screen and verify the Added Fees and its Values.";
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region SELECT THE DISPLAY LOAN ESTIMATE COLUMN CHECK BOX
                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD..";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                #endregion
                #region VERIFY COSTS DESCRIPTION FOR PAYEE AND VERIFY AMOUNT SALES TAX
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(Section: ClosingDisclosureSection.B, isChrDisplay: true, ChargeDescription: "Title - " + ChargeDescription_1 + "", IsPayeeName: true, ExpectedPayeeName: PayeeName_1);
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(lineNo: 3, section: ClosingDisclosureSection.B, ChargeDescription: ChargeDescription_1, BuyerAtClosing: 98.67, BuyerBeforeClosing: 1000.00, BuyerPaidbyOther: 67.87, SellerAtClosing: null, SellerBeforeClosing: null, SellerPaidbyOthers: null, LenderExist: true, LoanEstimteUnroundedAmt: 423723223.00, LoanEstimateRoundedAmt: 423723223.00);
                
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(Section: ClosingDisclosureSection.B, isChrDisplay: true, ChargeDescription: "Title - " + ChargeDescription_2 + "", IsPayeeName: true, ExpectedPayeeName: PayeeName_2);
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(lineNo: 4, section: ClosingDisclosureSection.B, ChargeDescription: ChargeDescription_2, BuyerAtClosing: null, BuyerBeforeClosing: null, BuyerPaidbyOther: null, SellerAtClosing: 356689.78, SellerBeforeClosing: null, SellerPaidbyOthers: null, LenderExist: false, LoanEstimteUnroundedAmt: null, LoanEstimateRoundedAmt: 12123524.00);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(Section: ClosingDisclosureSection.B, isChrDisplay: true, ChargeDescription: "Title - " + ChargeDescription_3 + "", IsPayeeName: true , ExpectedPayeeName: PayeeName_3);
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(lineNo: 2, section: ClosingDisclosureSection.B, ChargeDescription: ChargeDescription_3, BuyerAtClosing: 678.98, BuyerBeforeClosing: 7678.00, BuyerPaidbyOther: 7, SellerAtClosing: 78.90, SellerBeforeClosing: 87.67, SellerPaidbyOthers: null, LenderExist: true, LoanEstimteUnroundedAmt: null, LoanEstimateRoundedAmt: null);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(Section: ClosingDisclosureSection.B, isChrDisplay: true, ChargeDescription: "Title - " + ChargeDescription_4 + "", IsPayeeName: true, ExpectedPayeeName: PayeeName_4);
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(lineNo: 1, section: ClosingDisclosureSection.B, ChargeDescription: ChargeDescription_4, BuyerAtClosing: 184478.54, BuyerBeforeClosing: null, BuyerPaidbyOther: null, SellerAtClosing: null, SellerBeforeClosing: null, SellerPaidbyOthers: null, LenderExist: false, LoanEstimteUnroundedAmt: null, LoanEstimateRoundedAmt: null);
                #endregion
                #region LOAN ESTIMATE COLUMN
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.B, "Title - " + ChargeDescription_3 + "", "Edit", true, 987.98M, true);
                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.B, "Title - " + ChargeDescription_3 + "", "Verify", true, 987.98M, true);

                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.B, "Title - " + ChargeDescription_3 + "", "Edit", false, 45.50M, false);
                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.B, "Title - " + ChargeDescription_3 + "", "Verify", false, 45.50M, false);

                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.B, "Title - " + ChargeDescription_4 + "", "Edit", true, 93487.28M, true);
                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.B, "Title - " + ChargeDescription_4 + "", "Verify", true, 93487.28M, true);

                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.B, "Title - " + ChargeDescription_2 + "", "Edit", true, 765.56M, true);
                FastDriver.ClosingDisclosure.LoanEstimateColumn(ClosingDisclosureSection.B, "Title - " + ChargeDescription_2 + "", "Verify", true, 765.56M, true);
                #endregion
                #region EDIT COST DESCRIPTION FOR CHARGEDESCRIPTION_2
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FastDriver.ClosingDisclosure.EditCostDescription(ClosingDisclosureSection.B, "Title - " + ChargeDescription_2 + "", "A General Modified in CD");
                ChargeDescription_2 = "A General Modified in CD";
                FastDriver.BottomFrame.Done();
                #endregion
                #region Click on Good Faith Variance link in CD
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.VarianceTab.FAClick();
                FastDriver.ClosingDisclosureGFV.SwitchToContentFrame();
                FastDriver.ClosingDisclosureGFV.WaitCreation(FastDriver.ClosingDisclosureGFV.TableZeroPerVariance);
                FastDriver.ClosingDisclosureGFV.WaitCreation(FastDriver.ClosingDisclosureGFV.TableTenPerVariance);
                #endregion
                #region Verify Values in Good Faith Variance screen in CD
                Reports.TestStep = "VERIFY THE VALUES IN  GOOD FAITH ANALYSIS 10% CATEGORY.";
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblTenPerVariance", LineNumber: 1, Section: ClosingDisclosureSection.B, 
                    lineno: 1, ChargeDescription: ChargeDescription_2, LoanEstimateRounded: 766, FinalBorrowerPaid: 0, 
                    LoanEstimateUnRounded: 0, PartOf: true);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblTenPerVariance", LineNumber: 2, Section: ClosingDisclosureSection.B,
                    lineno: 2, ChargeDescription: "Title - 1999 Eagle Manufactured Home Jr. Lien", LoanEstimateRounded: 93487, 
                    FinalBorrowerPaid: 184478.54, LoanEstimateUnRounded: 0, PartOf: false);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblTenPerVariance", LineNumber: 3, Section: ClosingDisclosureSection.B,
                    lineno: 4, ChargeDescription: "Title - Cancellation Fee-Escrow", LoanEstimateRounded: 423723223, 
                    FinalBorrowerPaid: 1098.67, LoanEstimateUnRounded: 423723223.00, PartOf: false);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblTenPerVariance", LineNumber: 4, Section: ClosingDisclosureSection.B, 
                    lineno: 0, ChargeDescription: "Title - " + ChargeDescription_5 + "", LoanEstimateRounded: 480891,
                    FinalBorrowerPaid: 0, LoanEstimateUnRounded: 480890.58, PartOf: false);
                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV(TableID: "tblTenPerVariance", AggregateAmountsExceeding: null, AggregateLoanEstimate: 423723223.00,
                    AggregateFinal: 185577.21, TenPercentofAggregateLoanEstimate: 542372322.00, differenceofFinalandLoanEstimate: 0, Costabovetenpercent: 0, Costabovetotalzeroandtenpercent: null);
                #endregion
                #region Verify Good Faith Analysis 0% Category
                Reports.TestStep = @"Verify Good Faith Analysis 0% Category";
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 1, ClosingDisclosureSection.B, 3, "Title - " + ChargeDescription_3 + "", 46, 8356.98, 45.50, true);
                #endregion
                #region Navigate Back to the Fee Entry screen and verify the Changes made on the CD screen for CHARGE DESCRIPTION 3
                Reports.TestStep = "Navigate Back to the Fee Entry screen and verify the Changes made on the CD screen for CHARGE DESCRIPTION 3.";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.ProvideTheDataOnFeeEntryScreen(ChargeDescription_3, "Loan Estimate Unrounded", "45.50", "Verify");
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
                //CLICK ON THE RESPECTIVE PDD for CHARGE DESCRIPTION 3
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", ChargeDescription_3, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                Support.AreEqual("$45.50", FastDriver.PaymentDetails.LEUnrounded.FAGetValue());
                Support.AreEqual("$46.00", FastDriver.PaymentDetails.LERounded.FAGetValue());
                Support.AreEqual("false", FastDriver.PaymentDetails.BrokenImage.Displayed.ToString().ToLower());
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion
                #region Navigate Back to the Fee Entry screen and verify the Changes made on the CD screen for CHARGE DESCRIPTION 4
                Reports.TestStep = "Navigate Back to the Fee Entry screen and verify the Changes made on the CD screen for CHARGE DESCRIPTION 4.";
                FastDriver.FileFees.ProvideTheDataOnFeeEntryScreen(ChargeDescription_4, "Seller Charge", "96,598.88", "VAL");
                //CLICK ON THE RESPECTIVE PDD for CHARGE DESCRIPTION 4
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", ChargeDescription_4, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                Support.AreEqual("$0.00", FastDriver.PaymentDetails.LEUnrounded.FAGetValue());
                Support.AreEqual("$93,487.00", FastDriver.PaymentDetails.LERounded.FAGetValue());
                Support.AreEqual("true", FastDriver.PaymentDetails.BrokenImage.Displayed.ToString().ToLower());
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion
                #region Navigate Back to the Fee Entry screen and verify the Changes made on the CD screen for CHARGE DESCRIPTION 2
                Reports.TestStep = "Navigate Back to the Fee Entry screen and verify the Changes made on the CD screen for CHARGE DESCRIPTION 2.";
                ChargeDescription_2 = "General Excise Tax";
                FastDriver.FileFees.ProvideTheDataOnFeeEntryScreen(ChargeDescription_2, "Seller Charge", "356,689.78", "VAL");
                //CLICK ON THE RESPECTIVE PDD for CHARGE DESCRIPTION 2
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", ChargeDescription_2, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                ChargeDescription_2 = "A General Modified in CD";
                Support.AreEqual(ChargeDescription_2, FastDriver.PaymentDetails.LEDesc.FAGetValue());
                Support.AreEqual("$0.00", FastDriver.PaymentDetails.LEUnrounded.FAGetValue());
                Support.AreEqual("$766.00", FastDriver.PaymentDetails.LERounded.FAGetValue());
                Support.AreEqual("true", FastDriver.PaymentDetails.BrokenImage.Displayed.ToString().ToLower());
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            
        }

        #region Fee_BCH_Scenario_2 variables
        string LenderSalesFee = "OneRate Title-110% ALTA Ext.";
        string OwnerSalesFee = "ALTA U.S. Policy #1037.91 (9-28-91)";
        /* BA's comment on why this fee "ALTA US Policy #1037.91 (9-28-91)" 
         * would be set for Section H instead of Section B: 
         * it is an Owners Policy, it is not required by the Lender, so it is not in section B or C.
         * it must be in section H.
         * B and C are Loan Costs only.
         * Lenders Policy is a Loan Cost, so it is normally in B or C.
         * */

        string LEDLenderSalesFee = "Title - OneRate Title-110% ALTA Ext.";
        string LEDOwnerSalesFee = "Title - Owner's Title Insurance (optional)";
        double BuyerSalestax;
        double BuyerSalestax1;
        double SellerSalestax;
        double SellerSalestax1;
        double OwnerBuyerSalesTotal;
        double OwnerSellerSalesTotal;
        double LenderBuyerSalesTotal;
        double LenderSellerSalesTotal;
        double OwnerPaidbyOther;
        double LenderPaidbyOther;
        #endregion

        [TestMethod]
        public void Fee_BCH_Scenario_2_1()
        {
            try
            {
                #region USERSTORY_520909_TESTCASE_531632_SCENARIO1-VERIFY CHARGES WHEN FLP AMOUNT IS EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS EQUAL TO OWNER POLICY AMOUNT,AMOUNT IS ENTERED USING PDDD AND DISPLAY (L) IS CHECKED.
                Reports.TestDescription = "VERIFY CHARGES WHEN FLP AMOUNT IS EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS EQUAL TO OWNER POLICY AMOUNT,AMOUNT IS ENTERED USING PDD AND DISPLAY (L) IS CHECKED.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };
                #endregion
                #region CreateNewLoan
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region AddNonFACCRecordingFeeTax
                Reports.TestStep = "Add Non FACC Recording Fee Tax";
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", LenderSalesFee);
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", OwnerSalesFee);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.TitleandEscrow.FAClick();
                #endregion
                #region EnterBuyerandSellerAmountUsingPDD
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + LenderSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: LenderSalesFee, ByrAtClosing: 4000, ByrBfrClosing: 4000,
                    ByrPdOthrs: 4000, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 5000, SellerPaidBeforeClosing: 5000,
                    SellerPaidbyOthers: 5000, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: true, display_L_Seller: true);
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + OwnerSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: OwnerSalesFee, ByrAtClosing: 400, ByrBfrClosing: 400,
                    ByrPdOthrs: 400, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 500, SellerPaidBeforeClosing: 500,
                    SellerPaidbyOthers: 500, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: true, display_L_Seller: true);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Set Lender Adjustment Amount
                Reports.TestStep = "Set Lender Adjustment Amount";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("27000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                #endregion
                #region Get Buyer and Seller values from Fees
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                BuyerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                BuyerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                SellerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                SellerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                #endregion
                #region Navigate to Closing Disclosure and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Verify Amount
                Reports.TestStep = "1st Verify Amount for: " + LEDLenderSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 1, section: ClosingDisclosureSection.B, chargeDescription: LEDLenderSalesFee, 
                    buyerAtClosing: 4000, buyerBeforeClosing: 4000, buyerPaidbyOther: 4000, sellerAtClosing: 5000, sellerBeforeClosing: 5000,
                    sellerPaidbyOthers: 5000, lenderExist: true);
                string HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 2, LEDLenderSalesFee);
                LenderBuyerSalesTotal = BuyerSalestax1 / 3;
                LenderSellerSalesTotal = SellerSalestax1 / 3;
                //LenderPaidbyOther = LenderBuyerSalesTotal + LenderSellerSalesTotal;//Changed according to US559013
                LenderPaidbyOther = LenderBuyerSalesTotal;
                if (LenderPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Lender Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "2nd Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 2, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: LenderBuyerSalesTotal, BuyerBeforeClosing: LenderBuyerSalesTotal, BuyerPaidbyOther: LenderPaidbyOther,
                    SellerAtClosing: LenderSellerSalesTotal, SellerBeforeClosing: LenderSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: true);
                Reports.TestStep = "3rd Verify Amount for: " + LEDOwnerSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 3, section: ClosingDisclosureSection.B, chargeDescription: LEDOwnerSalesFee,
                    buyerAtClosing: 400, buyerBeforeClosing: 400, buyerPaidbyOther: 400, sellerAtClosing: 500, sellerBeforeClosing: 500, 
                    sellerPaidbyOthers: 500, lenderExist: true);
                HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 3, LEDOwnerSalesFee);
                OwnerBuyerSalesTotal = BuyerSalestax / 3;
                OwnerSellerSalesTotal = SellerSalestax / 3;
                //OwnerPaidbyOther = OwnerBuyerSalesTotal + OwnerSellerSalesTotal;//Changed according to US559013
                OwnerPaidbyOther = OwnerBuyerSalesTotal;
                if (OwnerPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Owner Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "4th Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 4, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: OwnerBuyerSalesTotal, BuyerBeforeClosing: OwnerBuyerSalesTotal, BuyerPaidbyOther: OwnerPaidbyOther,
                    SellerAtClosing: OwnerSellerSalesTotal, SellerBeforeClosing: OwnerSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: true);
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message); 
            }

            
        }

        [TestMethod]
        public void Fee_BCH_Scenario_2_2()
        {
            try
            {
                #region USERSTORY_520909_TESTCASE_531694_SCENARIO2-VERIFY CHARGES WHEN FLP AMOUNT IS EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS EQUAL TO OWNER POLICY AMOUNT,AMOUNT IS ENTERED USING PDDD AND DISPLAY (L) IS UNCHECKED.
                Reports.TestDescription = "VERIFY CHARGES WHEN FLP AMOUNT IS EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS EQUAL TO OWNER POLICY AMOUNT,AMOUNT IS ENTERED USING PDDD AND DISPLAY (L) IS UNCHECKED.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
            {
                new FileBusinessParty()
                {
                    AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                    RoleTypeObjectCD = "BUSSOURCE",
                    AdditionalRole = new AdditionalRoleList()
                    {
                        eAddtionalRole = AdditionalRoleType.NewLender
                    }
                }
            };
                customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "Santa Ana", 
                            County = "Orange", 
                            Country = "USA" 
                        } 
                    } 
                } 
            };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region CreateNewLoan
                //var newLoan = new NewLoanParameters()
                //{
                //    Type = "Small Loan",
                //    Amount = "300000000",
                //    GABCode = "247"
                //};
                //Reports.TestStep = "Enter charges to New Loan.";
                //Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                //FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                //FastDriver.NewLoan.WaitForScreenToLoad();
                //FastDriver.NewLoan.FillNewLoanForm(newLoan);
                //FastDriver.NewLoan.ClickRecapTab();
                //FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region AddNonFACCRecordingFeeTax
                Reports.TestStep = "Add Non FACC Recording Fee Tax";
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", LenderSalesFee);
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", OwnerSalesFee);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.TitleandEscrow.FAClick();
                #endregion
                #region EnterBuyerandSellerAmountUsingPDD
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + LenderSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: LenderSalesFee, ByrAtClosing: 4000, ByrBfrClosing: 4000,
                    ByrPdOthrs: 4000, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 5000, SellerPaidBeforeClosing: 5000,
                    SellerPaidbyOthers: 5000, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: false, display_L_Seller: false);
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + OwnerSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: OwnerSalesFee, ByrAtClosing: 400, ByrBfrClosing: 400,
                    ByrPdOthrs: 400, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 500, SellerPaidBeforeClosing: 500,
                    SellerPaidbyOthers: 500, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: false, display_L_Seller: false);
                #endregion
                #region Set Lender Adjustment Amount
                Reports.TestStep = "Set Lender Adjustment Amount";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("27000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                #endregion
                #region Get Buyer and Seller values from Fees
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                BuyerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                BuyerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                SellerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                SellerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                #endregion
                #region Navigate to Closing Disclosure and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Verify Amount
                Reports.TestStep = "1st Verify Amount for: " + LEDLenderSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 1, section: ClosingDisclosureSection.B, chargeDescription: LEDLenderSalesFee,
                    buyerAtClosing: 4000, buyerBeforeClosing: 4000, buyerPaidbyOther: 4000, sellerAtClosing: 5000, sellerBeforeClosing: 5000, 
                    sellerPaidbyOthers: 5000, lenderExist: false);
                string HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 2, LEDLenderSalesFee);
                LenderBuyerSalesTotal = BuyerSalestax1 / 3;
                LenderSellerSalesTotal = SellerSalestax1 / 3;
                //LenderPaidbyOther = LenderBuyerSalesTotal + LenderSellerSalesTotal;//Changed according to US559013
                LenderPaidbyOther = LenderBuyerSalesTotal;
                if (LenderPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Lender Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "2nd Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 2, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: LenderBuyerSalesTotal, BuyerBeforeClosing: LenderBuyerSalesTotal, BuyerPaidbyOther: LenderPaidbyOther,
                    SellerAtClosing: LenderSellerSalesTotal, SellerBeforeClosing: LenderSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: false);
                Reports.TestStep = "3rd Verify Amount for: " + LEDOwnerSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(3, ClosingDisclosureSection.B, LEDOwnerSalesFee, 400, 400, 400, 500, 500, 500, false);
                HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 3, LEDOwnerSalesFee);
                OwnerBuyerSalesTotal = BuyerSalestax / 3;
                OwnerSellerSalesTotal = SellerSalestax / 3;
                //OwnerPaidbyOther = OwnerBuyerSalesTotal + OwnerSellerSalesTotal;//Changed according to US559013
                OwnerPaidbyOther = OwnerBuyerSalesTotal;
                if (LenderPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Lender Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "4th Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 4, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: OwnerBuyerSalesTotal, BuyerBeforeClosing: OwnerBuyerSalesTotal, BuyerPaidbyOther: OwnerPaidbyOther,
                    SellerAtClosing: OwnerSellerSalesTotal, SellerBeforeClosing: OwnerSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: false);
                #endregion
                
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message); 
            }
        }

        [TestMethod]
        public void Fee_BCH_Scenario_2_3()
        {
            try
            {
                #region USERSTORY_520909_TESTCASE_531737_SCENARIO3-VERIFY CHARGES WHEN FLP AMOUNT IS NOT EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS NOT EQUAL TO OWNER POLICY AMOUNT, AMOUNT IS ENTERED USING PDDD AND DISPLAY (L) IS CHECKED.
                Reports.TestDescription = "VERIFY CHARGES WHEN FLP AMOUNT IS NOT EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS NOT EQUAL TO OWNER POLICY AMOUNT, AMOUNT IS ENTERED USING PDDD AND DISPLAY (L) IS CHECKED.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
            {
                new FileBusinessParty()
                {
                    AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                    RoleTypeObjectCD = "BUSSOURCE"
                }
            };
                customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "Santa Ana", 
                            County = "Orange", 
                            Country = "USA" 
                        } 
                    } 
                } 
            };
                #endregion
                #region CreateNewLoan
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region AddNonFACCRecordingFeeTax
                Reports.TestStep = "Add Non FACC Recording Fee Tax";
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", LenderSalesFee);
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", OwnerSalesFee);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.TitleandEscrow.FAClick();
                #endregion
                #region EnterBuyerandSellerAmountUsingPDD
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + LenderSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: LenderSalesFee, ByrAtClosing: 4000, ByrBfrClosing: 4000,
                    ByrPdOthrs: 4000, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 5000, SellerPaidBeforeClosing: 5000,
                    SellerPaidbyOthers: 5000, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: true, display_L_Seller: true);
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + OwnerSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: OwnerSalesFee, ByrAtClosing: 400, ByrBfrClosing: 400,
                    ByrPdOthrs: 400, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 500, SellerPaidBeforeClosing: 500,
                    SellerPaidbyOthers: 500, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: true, display_L_Seller: true);
                #endregion
                #region Set Lender Adjustment Amount
                Reports.TestStep = "Set Lender Adjustment Amount";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("28000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                #endregion
                #region Get Buyer and Seller values from Fees
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                BuyerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                BuyerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                SellerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                SellerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                #endregion
                #region Navigate to Closing Disclosure and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Verify Amount
                Reports.TestStep = "1st Verify Amount for: " + LEDLenderSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 1, section: ClosingDisclosureSection.B, chargeDescription: LEDLenderSalesFee, 
                    buyerAtClosing: 28000, buyerBeforeClosing: null, buyerPaidbyOther: null, sellerAtClosing: null, sellerBeforeClosing: null,
                    sellerPaidbyOthers: null, lenderExist: false);
                string HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 2, LEDLenderSalesFee);
                LenderBuyerSalesTotal = BuyerSalestax1 / 3;
                LenderSellerSalesTotal = SellerSalestax1 / 3;
                //LenderPaidbyOther = LenderBuyerSalesTotal + LenderSellerSalesTotal;//Changed according to US559013
                LenderPaidbyOther = LenderBuyerSalesTotal;
                if (LenderPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Lender Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "2nd Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 2, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: LenderBuyerSalesTotal, BuyerBeforeClosing: LenderBuyerSalesTotal, BuyerPaidbyOther: LenderPaidbyOther,
                    SellerAtClosing: LenderSellerSalesTotal, SellerBeforeClosing: LenderSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: true);
                Reports.TestStep = "3rd Verify Amount for: " + LEDOwnerSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.B, 3, LEDOwnerSalesFee, 1700, null, null, null, null, null, false);//check line No
                HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 3, LEDOwnerSalesFee);
                OwnerBuyerSalesTotal = BuyerSalestax / 3;
                OwnerSellerSalesTotal = SellerSalestax / 3;
                //OwnerPaidbyOther = OwnerBuyerSalesTotal + OwnerSellerSalesTotal;//Changed according to US559013
                OwnerPaidbyOther = OwnerBuyerSalesTotal;
                if (OwnerPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Owner Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "4th Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 4, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: OwnerBuyerSalesTotal, BuyerBeforeClosing: OwnerBuyerSalesTotal, BuyerPaidbyOther: OwnerPaidbyOther,
                    SellerAtClosing: OwnerSellerSalesTotal, SellerBeforeClosing: OwnerSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: true);//check line No
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void Fee_BCH_Scenario_2_4()
        {
            try
            {
                #region USERSTORY_520909_TESTCASE_531753_SCENARIO4-VERIFY CHARGES WHEN FLP AMOUNT IS NOT EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS NOT EQUAL TO OWNER POLICY AMOUNT, AMOUNT IS ENTERED USING PDD AND DISPLAY (L) IS UNCHECKED.
                Reports.TestDescription = "VERIFY CHARGES WHEN FLP AMOUNT IS NOT EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS NOT EQUAL TO OWNER POLICY AMOUNT, AMOUNT IS ENTERED USING PDD AND DISPLAY (L) IS UNCHECKED.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };
                #endregion
                #region CreateNewLoan
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region AddNonFACCRecordingFeeTax
                Reports.TestStep = "Add Non FACC Recording Fee Tax";
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", LenderSalesFee);
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", OwnerSalesFee);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.TitleandEscrow.FAClick();
                #endregion
                #region EnterBuyerandSellerAmountUsingPDD
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + LenderSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: LenderSalesFee, ByrAtClosing: 4000, ByrBfrClosing: 4000,
                    ByrPdOthrs: 4000, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 5000, SellerPaidBeforeClosing: 5000,
                    SellerPaidbyOthers: 5000, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: false, display_L_Seller: false);
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + OwnerSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: OwnerSalesFee, ByrAtClosing: 400, ByrBfrClosing: 400,
                    ByrPdOthrs: 400, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 500, SellerPaidBeforeClosing: 500,
                    SellerPaidbyOthers: 500, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: false, display_L_Seller: false);
                #endregion
                #region Set Lender Adjustment Amount
                Reports.TestStep = "Set Lender Adjustment Amount";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("28000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                #endregion
                #region Get Buyer and Seller values from Fees
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                BuyerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                BuyerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                SellerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                SellerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                #endregion
                #region Navigate to Closing Disclosure and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Verify Amount
                Reports.TestStep = "1st Verify Amount for: " + LEDLenderSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, LEDLenderSalesFee, 28000, null, null, null, null, null, false);
                string HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 2, LEDLenderSalesFee);
                LenderBuyerSalesTotal = BuyerSalestax1 / 3;
                LenderSellerSalesTotal = SellerSalestax1 / 3;
                //LenderPaidbyOther = LenderBuyerSalesTotal + LenderSellerSalesTotal;//Changed according to US559013
                LenderPaidbyOther = LenderBuyerSalesTotal;
                if (LenderPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Lender Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "2nd Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 2, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: LenderBuyerSalesTotal, BuyerBeforeClosing: LenderBuyerSalesTotal, BuyerPaidbyOther: LenderPaidbyOther,
                    SellerAtClosing: LenderSellerSalesTotal, SellerBeforeClosing: LenderSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: false);
                Reports.TestStep = "3rd Verify Amount for: " + LEDOwnerSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(ClosingDisclosureSection.B, 3, LEDOwnerSalesFee, 1700, null, null, null, null, null, false);
                HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 3, LEDOwnerSalesFee);
                OwnerBuyerSalesTotal = BuyerSalestax / 3;
                OwnerSellerSalesTotal = SellerSalestax / 3;
                //OwnerPaidbyOther = OwnerBuyerSalesTotal + OwnerSellerSalesTotal;//Changed according to US559013
                OwnerPaidbyOther = OwnerBuyerSalesTotal;
                if (OwnerPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Owner Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "4th Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 4, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: OwnerBuyerSalesTotal, BuyerBeforeClosing: OwnerBuyerSalesTotal, BuyerPaidbyOther: OwnerPaidbyOther,
                    SellerAtClosing: OwnerSellerSalesTotal, SellerBeforeClosing: OwnerSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: false);
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message); 
            }

        }

        [TestMethod]
        public void Fee_BCH_Scenario_2_5()
        {
            try
            {
                #region USERSTORY_520909_TESTCASE_531826_SCENARIO5-VERIFY CHARGES WHEN FLP AMOUNT IS EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS EQUAL TO OWNER POLICY AMOUNT, AMOUNT IS SPLITTED USING B/S SPLIT.
                Reports.TestDescription = "VERIFY CHARGES WHEN FLP AMOUNT IS EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS EQUAL TO OWNER POLICY AMOUNT, AMOUNT IS SPLITTED USING B/S SPLIT.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                new Property() 
                    {
                    PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };
                #endregion
                #region CreateNewLoan
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region AddNonFACCRecordingFeeTax
                Reports.TestStep = "Add Non FACC Recording Fee Tax";
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", LenderSalesFee);
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", OwnerSalesFee);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.TitleandEscrow.FAClick();
                #endregion
                #region EnterBuyerandSellerAmountUsingPDD
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + LenderSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: LenderSalesFee, ByrAtClosing: 4000, ByrBfrClosing: 4000,
                    ByrPdOthrs: 4000, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 5000, SellerPaidBeforeClosing: 5000,
                    SellerPaidbyOthers: 5000, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: true, display_L_Seller: false);
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + OwnerSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: OwnerSalesFee, ByrAtClosing: 400, ByrBfrClosing: 400,
                    ByrPdOthrs: 400, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 500, SellerPaidBeforeClosing: 500,
                    SellerPaidbyOthers: 500, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: true, display_L_Seller: false);
                #endregion
                #region Set Lender Adjustment Amount
                Reports.TestStep = "Set Lender Adjustment Amount";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("27000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion
                #region Change Split Percentage to 50% and verify
                Reports.TestStep = "Set Split Percentage to 50% and Verify";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                FastDriver.BuyerSellerSplitDlg.SplitPercentage.FASetText("50");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();
                Support.AreEqual("Seller 50.00%", FastDriver.FileFees.BSSplitSellerPercentage.Text);
                Support.AreEqual("Buyer 50.00%", FastDriver.FileFees.BSSplitBuyerPercentage.Text);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Get Buyer and Seller values from Fees
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                BuyerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                BuyerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                SellerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                SellerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                #endregion
                #region Navigate to Closing Disclosure and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Verify Amount
                Reports.TestStep = "1st Verify Amount for: " + LEDLenderSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 1, section: ClosingDisclosureSection.B, chargeDescription: LEDLenderSalesFee, 
                    buyerAtClosing: 4000, buyerBeforeClosing: 4000, buyerPaidbyOther: 4000, sellerAtClosing: 5000, sellerBeforeClosing: 5000, 
                    sellerPaidbyOthers: 5000, lenderExist:true);
                string HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 2, LEDLenderSalesFee);
                LenderBuyerSalesTotal = BuyerSalestax1 / 3;
                LenderSellerSalesTotal = SellerSalestax1 / 3;
                //LenderPaidbyOther = LenderBuyerSalesTotal + LenderSellerSalesTotal;//Changed according to US559013
                LenderPaidbyOther = LenderBuyerSalesTotal;
                if (LenderPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Lender Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "2nd Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 2, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: LenderBuyerSalesTotal, BuyerBeforeClosing: LenderBuyerSalesTotal, BuyerPaidbyOther: LenderPaidbyOther,
                    SellerAtClosing: LenderSellerSalesTotal, SellerBeforeClosing: LenderSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: true);
                Reports.TestStep = "3rd Verify Amount for: " + LEDOwnerSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo:3, section: ClosingDisclosureSection.B, chargeDescription: LEDOwnerSalesFee,
                    buyerAtClosing: 400, buyerBeforeClosing: 400, buyerPaidbyOther: 400, sellerAtClosing: 500, sellerBeforeClosing: 500, 
                    sellerPaidbyOthers: 500, lenderExist: true);
                HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 3, LEDOwnerSalesFee);
                OwnerBuyerSalesTotal = BuyerSalestax / 3;
                OwnerSellerSalesTotal = SellerSalestax / 3;
                //OwnerPaidbyOther = OwnerBuyerSalesTotal + OwnerSellerSalesTotal;//Changed according to US559013
                OwnerPaidbyOther = OwnerBuyerSalesTotal;
                if (OwnerPaidbyOther == 0)
                {
                    Support.AreEqual("True", "False", "Owner Sales value is Zero. Hence system does not display sales tax. Please check if setup issue or system issue");
                }
                Reports.TestStep = "4th Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 4, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: OwnerBuyerSalesTotal, BuyerBeforeClosing: OwnerBuyerSalesTotal, BuyerPaidbyOther: OwnerPaidbyOther,
                    SellerAtClosing: OwnerSellerSalesTotal, SellerBeforeClosing: OwnerSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: true);
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void Fee_BCH_Scenario_2_6()
        {
            try
            {
                #region USERSTORY_520909_TESTCASE_531833_SCENARIO6-VERIFY CHARGES WHEN FLP AMOUNT IS EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS EQUAL TO OWNER POLICY AMOUNT, AMOUNT IS SPLITTED USING B/S SPLIT.
                Reports.TestDescription = "VERIFY CHARGES WHEN FLP AMOUNT IS EQUAL TO THE LENDER POLICY AMOUNT AND DOP IS EQUAL TO OWNER POLICY AMOUNT, AMOUNT IS SPLITTED USING B/S SPLIT.";

                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };
                #endregion
                #region CreateNewLoan
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region AddNonFACCRecordingFeeTax
                Reports.TestStep = "Add Non FACC Recording Fee Tax";
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", LenderSalesFee);
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", OwnerSalesFee);
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.TitleandEscrow.FAClick();
                #endregion
                #region EnterBuyerandSellerAmountUsingPDD
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + LenderSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: LenderSalesFee, ByrAtClosing: 4000, ByrBfrClosing: 4000,
                    ByrPdOthrs: 4000, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 5000, SellerPaidBeforeClosing: 5000,
                    SellerPaidbyOthers: 5000, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: true, display_L_Seller: false);
                Reports.TestStep = "Enter Buyer and Seller Amount Using PDD for " + OwnerSalesFee;
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: OwnerSalesFee, ByrAtClosing: 400, ByrBfrClosing: 400,
                    ByrPdOthrs: 400, ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 500, SellerPaidBeforeClosing: 500,
                    SellerPaidbyOthers: 500, SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: true, display_L_Seller: false);
                #endregion
                #region Set Lender Adjustment Amount
                Reports.TestStep = "Set Lender Adjustment Amount";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("28000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                #endregion
                #region Change Split Percentage to 50% and verify
                Reports.TestStep = "Set Split Percentage to 50% and Verify";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                FastDriver.BuyerSellerSplitDlg.SplitPercentage.FASetText("50");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();
                Support.AreEqual("Seller 50.00%", FastDriver.FileFees.BSSplitSellerPercentage.Text);
                Support.AreEqual("Buyer 50.00%", FastDriver.FileFees.BSSplitBuyerPercentage.Text);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Get Buyer and Seller values from Fees
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                BuyerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                BuyerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#5", TableAction.GetAttribute, "value").Message);
                SellerSalestax = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", OwnerSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                SellerSalestax1 = Convert.ToDouble(FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", LenderSalesFee, "#8", TableAction.GetAttribute, "value").Message);
                #endregion
                #region Navigate to Closing Disclosure and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Verify Amount
                Reports.TestStep = "1st Verify Amount for: " + LEDLenderSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 1, section: ClosingDisclosureSection.B, chargeDescription: LEDLenderSalesFee, 
                    buyerAtClosing: 28000, buyerBeforeClosing: null, buyerPaidbyOther: null, sellerAtClosing: null, sellerBeforeClosing: null, 
                    sellerPaidbyOthers: null, lenderExist: false);
                string HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 2, LEDLenderSalesFee);
                LenderBuyerSalesTotal = BuyerSalestax1 / 3;
                LenderSellerSalesTotal = SellerSalestax1 / 3;
                //LenderPaidbyOther = LenderBuyerSalesTotal + LenderSellerSalesTotal;//Changed according to US559013
                LenderPaidbyOther = LenderBuyerSalesTotal;
                Reports.TestStep = "2nd Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 2, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: LenderBuyerSalesTotal, BuyerBeforeClosing: LenderBuyerSalesTotal, BuyerPaidbyOther: LenderPaidbyOther,
                    SellerAtClosing: LenderSellerSalesTotal, SellerBeforeClosing: LenderSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: true);
                Reports.TestStep = "3rd Verify Amount for: " + LEDOwnerSalesFee;
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 3, section: ClosingDisclosureSection.B, chargeDescription: LEDOwnerSalesFee, 
                    buyerAtClosing: 850, buyerBeforeClosing: null, buyerPaidbyOther: null, sellerAtClosing: 850, sellerBeforeClosing: null, 
                    sellerPaidbyOthers: null, lenderExist: false);
                HelpTextdescription = FastDriver.ClosingDisclosure.VerifyDescription(ClosingDisclosureSection.B, 3, LEDOwnerSalesFee);
                OwnerBuyerSalesTotal = BuyerSalestax / 3;
                OwnerSellerSalesTotal = SellerSalestax / 3;
                //OwnerPaidbyOther = OwnerBuyerSalesTotal + OwnerSellerSalesTotal;//Changed according to US559013
                OwnerPaidbyOther = OwnerBuyerSalesTotal;
                Reports.TestStep = "4th Verify Amount for: " + HelpTextdescription;
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(section: ClosingDisclosureSection.B, lineNo: 4, ChargeDescription: HelpTextdescription,
                    BuyerAtClosing: OwnerBuyerSalesTotal, BuyerBeforeClosing: OwnerBuyerSalesTotal, BuyerPaidbyOther: OwnerPaidbyOther,
                    SellerAtClosing: OwnerSellerSalesTotal, SellerBeforeClosing: OwnerSellerSalesTotal, SellerPaidbyOthers: null,
                    LenderExist: true);
                #endregion

                #endregion
        
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void Fee_BCH_Scenario_3()//Review In Progress...
        {
            try
            {
                #region INITIALIZE VARIABLES
                Reports.TestStep = "INITIALIZE VARIABLES";
                var yesterday = DateTime.Now.Date.AddDays(-1).ToString("MM/dd/yyyy");
                string PayeeName_1 = "to ";
                string PayeeName_2 = "to ";
                string PayeeName_3 = "to ";
                string PayeeName_4 = "to ";
                string PayeeName_5 = "to ";
                //List<string> productlist = new List<string>();
                //productlist.Add("*ALTA Standard Owner Policy");
                //productlist.Add("*ALTA Standard Loan Policy");
                #endregion
                #region These Fees Belongs to EVAL 00.
                string FACCFeeDesc = "Endorsement L w Sales Tax";
                List<string> FACCEndose = new List<string>();
                FACCEndose.Add("[ALTA 4] Condominium");
                #endregion
                #region These Fees Belongs to EVAL 01 for QA-Automation CD region.
                string FeeDescription_1 = "ALTA Ext Loan Policy 1056.06"; //Title Lender Policy
                string FeeDescription_2 = "Express (JLP) Policy"; //Title Lender Policy
                string FeeDescription_3 = "CLTA 100.12 CC&R's, Right of Revrs"; //Title Endorsement fee
                //  string FeeDescription_FACC_4 = "[ALTA 7.1-06] Manufactured Housing Unit";
                string FeeDesc_LP1 = "ALTA Extended Loan Policy 1992 (LP-10 Re-issue)";
                string FeeDesc_OP = "CLTA Standard Coverage 1084 1990";//This fee must be subject to calculation, otherwise it will not appear on the dropdown
                Reports.TestDescription = "VERIFY: DISPLAY LENDER POLICY AND ITS ENDORSEMENTS AS AN AGGREGATE ON THE CD SCREEN.";
                #endregion
                #region LOGIN
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region Create A Basic file order.
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
                customizableFileRequest.File.SalesPriceAmount = 500000;
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "MD",  
                                City = "OLDTOWN", 
                                County = "ALLEGANY",
                                Zip = "94122",
                                Country = "USA" 
                            } 
                        } 
                    } 
                };
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region Policy Liability
                Reports.TestStep = "Navigate to Terms/Dates/Status screen.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();

                Reports.TestStep = "Ensure Owner's Policy Liability Amount Exists in TDS Screen. If not enter amount.";
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText(@"500000.00");//Owner's Liability Amount
                // Set Status Date to universal time as it will fail if run in offshore box. System automatically default this field to current date
                FastDriver.TermsDatesStatus.StatusDate.FASetText(DateTime.Today.ToUniversalTime().AddHours(-8).ToDateString());//might need to be set for yesterday's date
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                #endregion
                #region CreateNewLoan (NewLender role)
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "100000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region CreateNewLoan for Second Liability Amount
                var secondLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "100000000",
                    GABCode = "508"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnNew.Click();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(secondLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Loan Policy");
                #endregion
                #region Remove Product: ALTA Expanded (Eagle Loan) Policy
                //Necessary for EVAL02 CD Region as of Sept 14, 2015
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").SwitchToContentFrame();
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction("Product Name", "*ALTA Expanded (Eagle Loan) Policy","#1", TableAction.Off);
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to Fee Entry and set values for FeeDescription_1
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectAndVerifyParticularFeeOnFeeEntryScreen(FeeDescription_1);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.buyercharge.FASetText("$98.67");
                FastDriver.FileFees.Sellercharge.FASetText("$3,56,689.78");
                FastDriver.FileFees.lenderAdjAmnt.FASetText("$356,788.45");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                //CLICK ON THE RESPECTIVE PDD for FeeDescription_1 to get PayeeName_1
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeDescription_1, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                FastDriver.PaymentDetails.SectionB.Click();
                PayeeName_1 = PayeeName_1 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to Fee Entry and set values for FeeDescription_2
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectAndVerifyParticularFeeOnFeeEntryScreen(FeeDescription_2);
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
                //CLICK ON THE RESPECTIVE PDD for FeeDescription_2
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeDescription_2, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                FastDriver.PaymentDetails.BuyerCharge.FASetText("$1,258.19");
                FastDriver.PaymentDetails.BuyerAtClosing.FASetText("$234.34");
                FastDriver.PaymentDetails.BuyerBeforeClosing.FASetText("$989.40");
                FastDriver.PaymentDetails.BuyerPaidByOthers.FASetText("$34.45");
                FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetails.SellerCharge.FASetText("$255.66");
                FastDriver.PaymentDetails.SellerAtClosing.FASetText("$98.67");
                FastDriver.PaymentDetails.SellerBeforeClosing.FASetText("$78.09");
                FastDriver.PaymentDetails.SellerPaidbyOthers.FASetText("$78.90");
                FastDriver.PaymentDetails.SellerPaidbyOthersPayMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetails.SectionC.Click();
                PayeeName_2 = PayeeName_2 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to Fee Entry and set values for FeeDescription_3
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectAndVerifyParticularFeeOnFeeEntryScreen(FeeDescription_3);
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
                //CLICK ON THE RESPECTIVE PDD for FeeDescription_3
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeDescription_3, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                FastDriver.PaymentDetails.BuyerCharge.FASetText("$8,363.98");
                FastDriver.PaymentDetails.BuyerAtClosing.FASetText("$678.98");
                FastDriver.PaymentDetails.BuyerBeforeClosing.FASetText("$7,678");
                FastDriver.PaymentDetails.BuyerPaidByOthers.FASetText("$7");
                FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetails.SellerCharge.FASetText("$166.65");
                FastDriver.PaymentDetails.SellerBeforeClosing.FASetText("$87.67");
                FastDriver.PaymentDetails.SellerPaidbyOthers.FASetText("$78.98");
                FastDriver.PaymentDetails.SellerPaidbyOthersPayMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetails.SectionC.Click();
                PayeeName_3 = PayeeName_3 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion
                #region SELECT TITLE AND ENDORSEMENT FEES
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.PerformCalculateFees();
                FastDriver.FileFees.SwitchToContentFrame();
                Reports.TestStep = "Select Title Policy";
                FastDriver.CalculateFees.SelectTitlePolicy(Date: yesterday, TitlePolicy: "ALTA Standard Loan Policy", RateType: "Basic");
                Reports.TestStep = "Add Endorsement";
                FastDriver.CalculateFees.PerformAddEndorsement(FACCEndose);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.CalculateFees.SwitchToContentFrame();
                Reports.TestStep = "Perform Add Product";
                FastDriver.CalculateFees.PerformAddProduct(TitlePolicy: "ALTA Standard Owner Policy", Ratetype: "Basic");
                FastDriver.WebDriver.HandleDialogMessage(); //2nd Loan Liability Amount has been added so this dialog won't pop-up
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.SwitchToContentFrame();
                Reports.TestStep = "Perform Click Next";
                FastDriver.CalculateFees.Next.Click();
                Reports.TestStep = "Perform Select FAST Desc And Charge To";
                //Problem: FeeDesc_OP does NOT appear on the second dropdown!!!
                FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo(FeeDesc_TLP: FeeDesc_LP1, FeeDesc_TOP: FeeDesc_OP, EndorsementDesc: FACCFeeDesc, LenderChargeTo: "Buyer", OwnerChargeTo: "Seller", EndoChargeTo: "Buyer");
                Reports.TestStep = "Perform Click Done";
                FastDriver.CalculateFees.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.Click();
                Reports.TestStep = "Perform Clicked Done";
                #endregion

                #region SET LENDER ADJUSTMENT AMOUNT
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("$356,788.45");
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                #endregion
                #region Get PayeeName_4
                //CLICK ON THE RESPECTIVE PDD for FeeDesc_LP1 to get PayeeName_4
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeDesc_LP1, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                PayeeName_4 = PayeeName_4 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Get PayeeName_5
                //CLICK ON THE RESPECTIVE PDD for "Title - [ALTA 4] Condominium" to get PayeeName_5
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", "[ALTA 4] Condominium", "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                PayeeName_5 = PayeeName_5 + FastDriver.PaymentDetails.GfeThirdPartyNameDefault.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to the CD Screen and verify the added fees under the respective sections
                Reports.TestStep = "Navigate to the CD Screen and verify the added fees under the respective sections";
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandOtherCosts();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Reports.TestStep = "Section B - Line 1";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, "Title - " + FeeDescription_1, true, PayeeName_1);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, "Title - " + FeeDescription_1, 98.67, null, null, 356689.78, null, null, false, null, null);
                Reports.TestStep = "Section C - Line 2";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, "Title - " + FeeDescription_2, true, PayeeName_2);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.C, "Title - " + FeeDescription_2, 234.34, 989.40, null, 98.67, 78.09, 113.35, false, null, null);
                Reports.TestStep = "Section C - Line 1";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, "Title - " + FeeDescription_3, true, PayeeName_3);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.C, "Title - " + FeeDescription_3, 678.98, 7678.00, null, null, 87.67, 85.98, false, null, null);
                Reports.TestStep = "Section B - Line 2";
                string FeeDesc_LP1_cut = "ALTA Extended Loan Policy 1992";
                //The Description is not fully shown on the table. If it's clicked, then you can see it. 
                //But the text property doesn't get it anyways, it just appears on the HelpText and Title properties
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, "Title - " + FeeDesc_LP1_cut, true, PayeeName_4);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, "Title - " + FeeDesc_LP1, 150.00, null, null, null, null, null, false, null, null);

                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, false, "Title - [ALTA 4] Condominium", false, PayeeName_5);

                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandOtherCosts();
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                try
                {
                    //Where does the "Title - Owner's Title Insurance (optional)" fee come from?
                    FastDriver.ClosingDisclosure.VerifyAmountSalesTax(1, ClosingDisclosureSection.H, "Title - Owner's Title Insurance (optional)", null, null, null, 2020.00, null, null, false, null, null);
                }
                catch (IndexOutOfRangeException e)
                {
                    Reports.TestStep = "Table H is empty: " + e.Message.ToString();
                }
                #endregion
                #region Navigate Back to the Fee Entry screen and Check the Agreegate check box
                Reports.TestStep = "Navigate Back to the Fee Entry screen and Check the Agreegate check box.";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AggregateLPAndEndorsementsOnCD.FASetCheckbox(true);
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                #endregion
                #region Navigate Back to the CD screen and verify \"Aggregate Lender Policy and Endorsements on CD\" value on the screen
                Reports.TestStep = "Navigate Back to the CD screen and verify \"Aggregate Lender Policy and Endorsements on CD\" value on the screen.";
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, "Title - Lender Policy and Endorsements", true, PayeeName_1);
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(3, ClosingDisclosureSection.B, "Title - Lender Policy and Endorsements", 777.65, 7678.00, null, 356689.78, 87.67, 85.98, false, null, null);
                #endregion
                #region Navigate Back to the Fee Entry screen and Un Check the Agreegate check box
                Reports.TestStep = "Navigate Back to the Fee Entry screen and Un Check the Agreegate check box.";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AggregateLPAndEndorsementsOnCD.FASetCheckbox(false);
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                #endregion
                #region Navigate to the CD Screen and verify the added fees under the respective sections
                Reports.TestStep = "Navigate to the CD Screen and verify the added fees under the respective sections";
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                Reports.TestStep = "Section B - Line 1";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, "Title - " + FeeDescription_1, true, PayeeName_1);
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(1, ClosingDisclosureSection.B, "Title - " + FeeDescription_1, 98.67, null, null, 356689.78, null, null, false, null, null);
                Reports.TestStep = "Section C - Line 2";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, "Title - " + FeeDescription_2, true, PayeeName_2);
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(2, ClosingDisclosureSection.C, "Title - " + FeeDescription_2, 234.34, 989.40, null, 98.67, 78.09, 113.35, false, null, null);
                Reports.TestStep = "Section C - Line 1";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, "Title - " + FeeDescription_3, true, PayeeName_3);
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(1, ClosingDisclosureSection.C, "Title - " + FeeDescription_3, 678.98, 7678.00, null, null, 87.67, 85.98, false, null, null);
                Reports.TestStep = "Section B - Line 2";
                //The Description is not fully shown on the table. If it's clicked, then you can see it. 
                //But the text property doesn't get it anyways, it just appears on the HelpText and Title properties
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, "Title - " + FeeDesc_LP1_cut, true, PayeeName_4);
                FastDriver.ClosingDisclosure.VerifyAmountSalesTax(2, ClosingDisclosureSection.B, "Title - " + FeeDesc_LP1, 150.00, null, null, null, null, null, false, null, null);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void Fee_BCH_Scenario_4()
        {
            try
            {
                #region Initialize variables
                string ChargeDescription_1 = "Title - Lender Policy     	              ";
                string ChargeDescription_2 = "Title - Endorsement (s)- L     	              ";
                string ChargeDescription_3 = "Title - Title Insurance Binder - L     	              ";
                string ChargeDescription_4 = "Adhoc Charge - OTC Lender and Endorsement     	              ";
                string PayeeName_1 = "to ";
                string PayeeName_2 = "to ";
                string PayeeName_3 = "to ";
                string PayeeName_4 = "to ";
                #endregion
                Reports.TestDescription = "Verify : Display Lender Policy and Endorsements as an aggregate amount – OTC on CD Screen.";
                #region  Login
                Reports.TestStep = "Login into the IIS Side.";
                _IISLOGIN();
                #endregion
                #region CreateFile
                Reports.TestStep = "Create A Basic file order.";
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };
                #endregion
                #region CreateNewLoan
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Reports.TestStep = "File No: " + File.FileNumber;
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                Reports.TestStep = "Navigate to the New Loan Page and create a new instance by associating it with the GAB Code.";
                //Reports.StatusUpdate("CREATE NEW LOAN INSTANCE AND VERIFY THE SAME.", GUI_Functions.GUI_Functions.NewLoanInstance());

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FillNewLoanForm(newLoan);
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion
                #region Create the OTC Instance
                Reports.TestStep = "Create the OTC Instance.";
                FastDriver.OTCDetail.Open();
                Reports.TestStep = "Set an instance of OTC details.";
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.GABcode.FASetText(@"438");
                FastDriver.OTCDetail.Find.FAClick();
                #region PDD Charge Description 1
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_1, "Buyer Charge", TableAction.SetText, "98.67");
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_1, "Seller Charge", TableAction.SetText, "3566.78");
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_1, "Loan Estimate Unrounded", TableAction.SetText, "9898.50");
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_1, "Description", TableAction.Click);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SectionB.FAClick();
                PayeeName_1 = PayeeName_1 + FastDriver.PaymentDetailsDlg.PayeeName.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                #endregion
                #region PDD Charge Description 2
                Reports.TestStep = "Provide The Data as per the requirement and verification on the CD screen for Charge : " + ChargeDescription_2.Trim();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_2, "Description", TableAction.Click);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SectionC.FAClick();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$1,258.19");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$234.34");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$989.40");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(" $34.45");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$255.66");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("$98.67");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$78.09");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$78.90");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$23.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$23.45");
                PayeeName_2 = PayeeName_2 + FastDriver.PaymentDetailsDlg.PayeeName.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                #endregion
                #region PDD Charge Description 3
                Reports.TestStep = "Provide The Data as per the requirement and verification on the CD screen for Charge : " + ChargeDescription_3.Trim();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_3, "Buyer Charge", TableAction.SetText, "$12,117.00");
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_3, "Seller Charge", TableAction.SetText, "$12,117.00");
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_3, "Description", TableAction.Click);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SectionB.FAClick();
                PayeeName_3 = PayeeName_3 + FastDriver.PaymentDetailsDlg.PayeeName.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion
                #region PDD Charge Description 4
                Reports.TestStep = "Provide The Data as per the requirement and verification on the CD screen for Charge : " + ChargeDescription_4.Trim();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();
                var table = FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable;
                FastDriver.OTCDetail.AddLastLineCharges(Table: table, TableId: "agcItemizeL_dcs", ChargeDesc: ChargeDescription_4, BuyerCharge: null, BuyerCredit: null, SellerCharge: null, SellerCredit: null, LoanEstimate: null, Months: null, MonthlyCharges: null);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_4, "Description", TableAction.Click);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SectionH.FAClick();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("212.06");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$34.40 ");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$98.90");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$78.76");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("247.39");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("$78.98");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$89.76");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$78.65");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("POC");
                PayeeName_4 = PayeeName_4 + FastDriver.PaymentDetailsDlg.PayeeName.GetAttribute("value").ToString();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();
                #endregion
                #endregion
                #region Navigate to The CD screen and verify the OTC charge values
                Reports.TestStep = "Navigate to The CD screen and verify the OTC charge values.";
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                #endregion
                #region Verify Charges
                Reports.TestStep = "Section B - Line 1";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, ChargeDescription_1.Trim(), true, PayeeName_1);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, ChargeDescription_1.Trim(), 98.67, null, null, 3566.78, null, null, false, 9898.50, 9899);
                Reports.TestStep = "Section C - Line 1";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, ChargeDescription_2.Trim(), true, PayeeName_2);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.C, ChargeDescription_2.Trim(), 234.34, 989.40, 34.45, 98.67, 78.09, 78.90, false, 23.45, 23.00);
                Reports.TestStep = "Section B - Line 2";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, ChargeDescription_3.Trim(), true, PayeeName_3);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, ChargeDescription_3.Trim(), 12117.00, null, null, 12117.00, null, null, false, null, null);
                Reports.TestStep = "Section H - Line 1";
                FastDriver.ClosingDisclosure.ExpandOtherCosts();
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, "Adhoc Charge - OTC Lender and Endorsement".Trim(), true, PayeeName_4);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChargeDescription_4.Trim(), 34.40, 98.90, 78.76, 78.98, 89.76, 78.65, false, null, null);
                #endregion
                #region Navigate to OTC Screen and check the \"Display aggregate on CD\" Check box.
                Reports.TestStep = "Navigate to OTC Screen and check the \"Display aggregate on CD\" Check box.";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.DisplayAggregateOnCD.FASetCheckbox(true);
                #endregion
                #region Navigate Back to The CD screen and verify the Agregated OTC charge values
                Reports.TestStep = "Navigate Back to The CD screen and verify the Agregated OTC charge values.";
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD..";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, ChargeDescription_1.Trim(), true, PayeeName_1);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, ChargeDescription_1.Trim(), 12484.41, 1088.30, 113.21, 15861.43, 167.85, 270.76, false, 9921.95, 9922.00);
                #endregion
                #region Change the Section Value = C for First OTC charge and verify the same on the CD Screen
                Reports.TestStep = "Change the Section Value = C for First OTC charge and verify the same on the CD Screen.";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_1, "Description", TableAction.Click);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SectionC.FAClick();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();
                #endregion
                #region Navigate Back to The CD screen and verify the Agregated OTC charge values for Section C
                Reports.TestStep = "Navigate Back to The CD screen and verify the Agregated OTC charge values for Section C.";
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD for Section C.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, ChargeDescription_1.Trim(), true, PayeeName_1);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.C, ChargeDescription_1.Trim(), 12484.41, 1088.30, 113.21, 15861.43, 167.85, 270.76, false, 9921.95, 9922.00);
                #endregion
                #region Change the Section Value = H for First OTC charge and verify the same on the CD Screen
                Reports.TestStep = "Change the Section Value = H for First OTC charge and verify the same on the CD Screen.";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_1, "Description", TableAction.Click);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SectionH.FAClick();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();
                #endregion
                #region Navigate Back to The CD screen and verify the Agregated OTC charge values for Section H
                Reports.TestStep = "Navigate Back to The CD screen and verify the Agregated OTC charge values for Section H.";
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandOtherCosts();
                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD for Section H.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, ChargeDescription_1.Trim(), true, PayeeName_1);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChargeDescription_1.Trim(), 12484.41, 1088.30, 113.21, 15861.43, 167.85, 270.76, false, 9921.95, 9922.00);
                #endregion
                #region Navigate to OTC Screen and check the \"Display aggregate on CD\" Check box
                Reports.TestStep = "Navigate to OTC Screen and check the \"Display aggregate on CD\" Check box.";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.DisplayAggregateOnCD.FASetCheckbox(false);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementTable.PerformTableAction("#1", ChargeDescription_1, "Description", TableAction.Click);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SectionB.FAClick();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();
                #endregion
                #region Navigate Back to The CD screen and verify the Agregated OTC charge values for Section B
                Reports.TestStep = "Navigate Back to The CD screen and verify the Agregated OTC charge values for Section B.";
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                Reports.TestStep = "SELECT DISPLAY LOAN ESTIMATE COLUMN CHECK BOX AND VERIFY THE MODIFIED DETAILS IN CD for Section H.";
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                #endregion
                #region Verify Charges again
                Reports.TestStep = "Section B - Line 1";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, ChargeDescription_1.Trim(), true, PayeeName_1);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, ChargeDescription_1.Trim(), 98.67, null, null, 3566.78, null, null, false, 9898.50, 9899);
                Reports.TestStep = "Section C - Line 1";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.C, true, ChargeDescription_2.Trim(), true, PayeeName_2);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.C, ChargeDescription_2.Trim(), 234.34, 989.40, 34.45, 98.67, 78.09, 78.90, false, 23.45, 23.00);
                Reports.TestStep = "Section B - Line 2";
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.B, true, ChargeDescription_3.Trim(), true, PayeeName_3);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, ChargeDescription_3.Trim(), 12117.00, null, null, 12117.00, null, null, false, null, null);
                Reports.TestStep = "Section H - Line 1";
                FastDriver.ClosingDisclosure.ExpandOtherCosts();
                FastDriver.ClosingDisclosure.VerifyCostsDescription_PayeeName(ClosingDisclosureSection.H, true, "Adhoc Charge - OTC Lender and Endorsement".Trim(), true, PayeeName_4);
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.H, ChargeDescription_4.Trim(), 34.40, 98.90, 78.76, 78.98, 89.76, 78.65, false, null, null);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
       

        #region USERSTORY : 530784 CD SCREEN : GFV - DISPLAY SALES TAX
        [TestMethod]
        [Description("USERSTORY_530784_TESTCASE_538053_SCENARIO1-VERIFY SALES TAX IN 0% VARIANCE SECTION WHEN AMOUNT IS ENTER WITH PDD.")]
        public void FTR4_ITR41_US_530784_TC_538053_SC1()
        {
            try
            {
                Reports.TestDescription = "FTR4_ITR41_US_530784_TC_538053_SC-VERIFY SALES TAX IN 0% VARIANCE SECTION WHEN AMOUNT IS ENTER WITH PDD.";
                _ADMLOGIN();
                
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("13071");
                FastDriver.GeneralLedgerSetup.CreateNewGeneralLedgerSetup(Description: "116-02 Recording Fees - Non-Revenue");

                #region Verify and create the Fees
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Escrow Fee", FeeCode: "53078401", FeeType: "Escrow Fee");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Other Fee", FeeCode: "53078402", FeeType: "Other Fee");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Title - Lenders Policy", FeeCode: "53078403", FeeType: "Title - Lenders Policy");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Title - Miscellaneous", FeeCode: "53078404", FeeType: "Title - Miscellaneous");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Title - Owners Policy", FeeCode: "53078405", FeeType: "Title - Owners Policy");
                #endregion

                #region Create File
                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad()
                    .FillNewLoanForm(newLoan)
                    .ClickRecapTab();
                #endregion

                #region AddNonFACCRecordingFeeTax
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Escrow Fee", "530784_Escrow Fee", "53078401");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Other Fee", "530784_Other Fee","53078402");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", "530784_Title - Lenders Policy","53078403");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Miscellaneous", "530784_Title - Miscellaneous","53078404");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", "530784_Title - Owners Policy", "53078405");
                #endregion

                #region EnterBuyerandSellerAmountsUsingPDD
                // Fix according to code review 590479
                //Lender Affialite needs to be true so it appears on the Zero Percent table on GFV screen
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: "530784_Escrow Fee", ByrAtClosing: 4000, ByrBfrClosing: 4000, ByrPdOthrs: 4000,
                    ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 4000, SellerPaidBeforeClosing: 4000, SellerPaidbyOthers: 4000, 
                    SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: false, display_L_Seller: false, LenderAffialite: true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: "530784_Other Fee", ByrAtClosing: 5000, ByrBfrClosing: 5000, ByrPdOthrs: 5000, 
                    ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 5000, SellerPaidBeforeClosing: 5000, SellerPaidbyOthers: 5000, 
                    SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: false, display_L_Seller: false, LenderAffialite: true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: "530784_Title - Lenders Policy", ByrAtClosing: 1000, ByrBfrClosing: 1000, ByrPdOthrs: 1000,
                    ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 1000, SellerPaidBeforeClosing: 1000, SellerPaidbyOthers: 1000, 
                    SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: false, display_L_Seller: false, LenderAffialite: true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: "530784_Title - Miscellaneous", ByrAtClosing: 2000, ByrBfrClosing: 2000, ByrPdOthrs: 2000, 
                    ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 2000, SellerPaidBeforeClosing: 2000, SellerPaidbyOthers: 2000, 
                    SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: false, display_L_Seller: false, LenderAffialite: true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD(Description: "530784_Title - Owners Policy", ByrAtClosing: 2000, ByrBfrClosing: 2000, ByrPdOthrs: 2000, 
                    ByrPaidByOthrsPymtmthd: "Lender", SellerPaidAtClosing: 3000, SellerPaidBeforeClosing: 3000, SellerPaidbyOthers: 3000, 
                    SellerPaidbyOtherPaymentMthd: "Lender", display_L_Buyer: false, display_L_Seller: false, LenderAffialite: true);
                #endregion

                #region Set Lender Adjustment Amount
                Reports.TestStep = "Set Lender Adjustment Amount";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.LenderAdjustmentAmount.FASetText("6000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");//modified according to US559013
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Obtain Final Borrower Paid Amounts
                double FinalBorrowerPaidSalesTax1, FinalBorrowerPaidSalesTax2, FinalBorrowerPaidSalesTax3, FinalBorrowerPaidSalesTax4, FinalBorrowerPaidSalesTax5 = 0.0;
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FinalBorrowerPaidSalesTax1 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B, 
                    lineNo: 2, ChargeDescription: "530784_Escrow Fee - Sales Tax");
                FinalBorrowerPaidSalesTax2 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 4, ChargeDescription: "530784_Other Fee - Sales Tax");
                FinalBorrowerPaidSalesTax3 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 6, ChargeDescription: "530784_Title - Lenders Policy - Sales Tax");
                FinalBorrowerPaidSalesTax4 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 8, ChargeDescription: "530784_Title - Miscellaneous - Sales Tax");
                FinalBorrowerPaidSalesTax5 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 10, ChargeDescription: "530784_Title - Owners Policy - Sales Tax");
                #endregion

                #region Verify CD
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 1, Section: ClosingDisclosureSection.B, 
                    lineno: 1, ChargeDescription: "530784_Escrow Fee", LoanEstimateRounded: 0, FinalBorrowerPaid: 8000, 
                    LoanEstimateUnRounded: 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 2, Section: ClosingDisclosureSection.B,
                    lineno: 2, ChargeDescription: "530784_Escrow Fee - Sales Tax", LoanEstimateRounded: 0, FinalBorrowerPaid: FinalBorrowerPaidSalesTax1,
                    LoanEstimateUnRounded: 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 3, Section: ClosingDisclosureSection.B,
                    lineno: 3, ChargeDescription: "530784_Other Fee", LoanEstimateRounded: 0, FinalBorrowerPaid: 10000, 
                    LoanEstimateUnRounded: 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 4, Section: ClosingDisclosureSection.B,
                   lineno: 4, ChargeDescription: "530784_Other Fee - Sales Tax", LoanEstimateRounded: 0, FinalBorrowerPaid: FinalBorrowerPaidSalesTax2,
                   LoanEstimateUnRounded: 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 5, Section: ClosingDisclosureSection.B, 
                    lineno: 5, ChargeDescription: "530784_Title - Lenders Policy", LoanEstimateRounded: 0, FinalBorrowerPaid: 2000, 
                    LoanEstimateUnRounded: 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 6, Section: ClosingDisclosureSection.B,
                    lineno: 6, ChargeDescription: "530784_Title - Lenders Policy - Sales Tax", LoanEstimateRounded: 0, FinalBorrowerPaid: FinalBorrowerPaidSalesTax3,
                    LoanEstimateUnRounded: 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 7, Section: ClosingDisclosureSection.B, 
                    lineno: 7, ChargeDescription: "530784_Title - Miscellaneous", LoanEstimateRounded: 0, FinalBorrowerPaid: 4000, 
                    LoanEstimateUnRounded: 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 8, Section: ClosingDisclosureSection.B,
                    lineno: 8, ChargeDescription: "530784_Title - Miscellaneous - Sales Tax", LoanEstimateRounded: 0, FinalBorrowerPaid: FinalBorrowerPaidSalesTax4,
                    LoanEstimateUnRounded: 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 9, Section: ClosingDisclosureSection.B, 
                    lineno: 9, ChargeDescription: "530784_Title - Owners Policy", LoanEstimateRounded: 0, FinalBorrowerPaid: 4000, 
                    LoanEstimateUnRounded: 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory(TableID: "tblZeroPerVariance", LineNumber: 10, Section: ClosingDisclosureSection.B,
                    lineno: 10, ChargeDescription: "530784_Title - Owners Policy - Sales Tax", LoanEstimateRounded: 0, FinalBorrowerPaid: FinalBorrowerPaidSalesTax5,
                    LoanEstimateUnRounded: 0);

                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV(TableID: "tblZeroPerVariance", AggregateAmountsExceeding: 34370, 
                    AggregateLoanEstimate: null, AggregateFinal: null, TenPercentofAggregateLoanEstimate: null, differenceofFinalandLoanEstimate: null, 
                    Costabovetenpercent: null, Costabovetotalzeroandtenpercent: null);
                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV(TableID: "tblCategoryTotal", AggregateAmountsExceeding: null, 
                    AggregateLoanEstimate: null, AggregateFinal: null, TenPercentofAggregateLoanEstimate: null, differenceofFinalandLoanEstimate: null, 
                    Costabovetenpercent: null, Costabovetotalzeroandtenpercent: 34370);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message); 
            } 
        }

        [TestMethod]
        [Description("FTR4_ITR41_US_530784_TC_538058_SC2: VERIFY SALES TAX IN 0% VARIANCE SECTION WHEN AMOUNT IS ENTER WITH PDD AND LENDER AFFILIATE / 0% IS CHECKED AT SOURCE SCREEN.")]
        public void FTR4_ITR41_US_530784_TC_538058_SC2()
        {
            try
            {
                Reports.TestDescription = "FTR4_ITR41_US_530784_TC_538058_SC2: VERIFY SALES TAX IN 0% VARIANCE SECTION WHEN AMOUNT IS ENTER WITH PDD AND LENDER AFFILIATE / 0% IS CHECKED AT SOURCE SCREEN.";
                _ADMLOGIN();

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("13071");
                FastDriver.GeneralLedgerSetup.CreateNewGeneralLedgerSetup(Description: "116-02 Recording Fees - Non-Revenue");

                #region Verify and create the Fees
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Escrow Fee_NLAC", FeeCode: "53078408", FeeType: "Escrow Fee");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Other Fee_NLAC", FeeCode: "53078409", FeeType: "Other Fee");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Title - Lenders Policy_NLAC", FeeCode: "53078410", FeeType: "Title - Lenders Policy");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Title - Miscellaneous_NLAC", FeeCode: "53078411", FeeType: "Title - Miscellaneous");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Title - Owners Policy_NLAC", FeeCode: "53078412", FeeType: "Title - Owners Policy");
                #endregion

                #region Create File
                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad()
                .FillNewLoanForm(newLoan)
                .ClickRecapTab();
                #endregion

                #region AddNonFACCRecordingFeeTax
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Escrow Fee", "Escrow Fee_NLAC", "53078408");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Other Fee", "Other Fee_NLAC", "53078409");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", "Title - Lenders Policy_NLAC", "53078410");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Miscellaneous", "Title - Miscellaneous_NLAC", "53078411");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", "Title - Owners Policy_NLAC", "53078412");
                #endregion

                #region EnterBuyerandSellerAmountsUsingPDD
                // Fix according to code review 590479
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Escrow Fee_NLAC", 4000, 4000, 4000, "Lender", 4000, 4000, 4000, "Lender", false, false);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Other Fee_NLAC", 5000, 5000, 5000, "Lender", 5000, 5000, 5000, "Lender", false, false);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Title - Lenders Policy_NLAC", 1000, 1000, 1000, "Lender", 1000, 1000, 1000, "Lender", false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Title - Miscellaneous_NLAC", 2000, 2000, 2000, "Lender", 2000, 2000, 2000, "Lender", false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Title - Owners Policy_NLAC", 2000, 2000, 2000, "Lender", 3000, 3000, 3000, "Lender", false, true);
                #endregion

                #region Set Lender Adjustment Amount
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.LenderAdjustmentAmount.FASetText("6000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");//modified according to US559013
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Obtain Final Borrower Paid Amounts
                double FinalBorrowerPaidSalesTax1, FinalBorrowerPaidSalesTax2, FinalBorrowerPaidSalesTax3, FinalBorrowerPaidSalesTax4, FinalBorrowerPaidSalesTax5 = 0.0;
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FinalBorrowerPaidSalesTax1 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 2, ChargeDescription: "Escrow Fee_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax2 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 4, ChargeDescription: "Other Fee_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax3 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 6, ChargeDescription: "Title - Lenders Policy_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax4 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 8, ChargeDescription: "Title - Miscellaneous_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax5 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 10, ChargeDescription: "Title - Owners Policy_NLAC - Sales Tax");
                #endregion

                #region Verify CD
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 1, ClosingDisclosureSection.B, 1, "Escrow Fee_NLAC", 0, 8000, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 2, ClosingDisclosureSection.B, 2, "Escrow Fee_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax1, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 3, ClosingDisclosureSection.B, 3, "Other Fee_NLAC", 0, 10000, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 4, ClosingDisclosureSection.B, 4, "Other Fee_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax2, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 5, ClosingDisclosureSection.B, 5, "Title - Lenders Policy_NLAC", 0, 2000, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 6, ClosingDisclosureSection.B, 6, "Title - Lenders Policy_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax3, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 7, ClosingDisclosureSection.B, 7, "Title - Miscellaneous_NLAC", 0, 4000, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 8, ClosingDisclosureSection.B, 8, "Title - Miscellaneous_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax4, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 9, ClosingDisclosureSection.B, 9, "Title - Owners Policy_NLAC", 0, 4000, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblZeroPerVariance", 10, ClosingDisclosureSection.B, 10, "Title - Owners Policy_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax5, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV("tblZeroPerVariance", 34370, null, null, null, null, null, null);
                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV("tblCategoryTotal", null, null, null, null, null, null, 34370);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            } 
        }

        [TestMethod]
        [Description("FTR4_ITR41_US_530784_TC_538067_SC3: VERIFY SALES TAX IN 10% VARIANCE SECTION WHEN AMOUNT IS ENTER WITH PDD.")]
        public void FTR4_ITR41_US_530784_TC_538067_SC3()
        {
            try
            {
                Reports.TestDescription = "FTR4_ITR41_US_530784_TC_538067_SC3: VERIFY SALES TAX IN 10% VARIANCE SECTION WHEN AMOUNT IS ENTER WITH PDD.";
                _ADMLOGIN();

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("13071");
                FastDriver.GeneralLedgerSetup.CreateNewGeneralLedgerSetup(Description: "116-02 Recording Fees - Non-Revenue");

                #region Verify and create the Fees
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Escrow Fee_NLAC", FeeCode: "53078408", FeeType: "Escrow Fee");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Other Fee_NLAC", FeeCode: "53078409", FeeType: "Other Fee");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Title - Lenders Policy_NLAC", FeeCode: "53078410", FeeType: "Title - Lenders Policy");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Title - Miscellaneous_NLAC", FeeCode: "53078411", FeeType: "Title - Miscellaneous");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "Title - Owners Policy_NLAC", FeeCode: "53078412", FeeType: "Title - Owners Policy");
                #endregion

                #region Create File
                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad()
                    .FillNewLoanForm(newLoan)
                    .ClickRecapTab();
                #endregion

                #region AddNonFACCRecordingFeeTax
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Escrow Fee", "Escrow Fee_NLAC", "53078408");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Other Fee", "Other Fee_NLAC", "53078409");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", "Title - Lenders Policy_NLAC", "53078410");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Miscellaneous", "Title - Miscellaneous_NLAC", "53078411");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", "Title - Owners Policy_NLAC", "53078412");
                #endregion

                #region EnterBuyerandSellerAmountsUsingPDD
                // Fix according to code review 590479
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Escrow Fee_NLAC", 4000, 4000, 4000, "Lender", 4000, 4000, 4000, "Lender", false, false, false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Other Fee_NLAC", 5000, 5000, 5000, "Lender", 5000, 5000, 5000, "Lender", false, false, false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Title - Lenders Policy_NLAC", 1000, 1000, 1000, "Lender", 1000, 1000, 1000, "Lender", false, false, false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Title - Miscellaneous_NLAC", 2000, 2000, 2000, "Lender", 2000, 2000, 2000, "Lender", false, false, false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("Title - Owners Policy_NLAC", 2000, 2000, 2000, "Lender", 3000, 3000, 3000, "Lender", false, false, false, true);
                #endregion

                #region Set Lender Adjustment Amount
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.LenderAdjustmentAmount.FASetText("6000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");//modified according to US559013
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Obtain Final Borrower Paid Amounts
                double FinalBorrowerPaidSalesTax1, FinalBorrowerPaidSalesTax2, FinalBorrowerPaidSalesTax3, FinalBorrowerPaidSalesTax4, FinalBorrowerPaidSalesTax5 = 0.0;
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FinalBorrowerPaidSalesTax1 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 2, ChargeDescription: "Escrow Fee_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax2 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 4, ChargeDescription: "Other Fee_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax3 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 6, ChargeDescription: "Title - Lenders Policy_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax4 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 8, ChargeDescription: "Title - Miscellaneous_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax5 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 10, ChargeDescription: "Title - Owners Policy_NLAC - Sales Tax");
                #endregion
                
                #region Verify CD
                double FinalBorrowerPaid1 = 8000;
                double FinalBorrowerPaid2 = 10000;
                double FinalBorrowerPaid3 = 2000;
                double FinalBorrowerPaid4 = 4000;
                double FinalBorrowerPaid5 = 4000;
                double TotalFinalBorrowerPaid = FinalBorrowerPaid1 + FinalBorrowerPaid2 + FinalBorrowerPaid3 + FinalBorrowerPaid4 + FinalBorrowerPaid5 + FinalBorrowerPaidSalesTax1 + FinalBorrowerPaidSalesTax2 + FinalBorrowerPaidSalesTax3 + FinalBorrowerPaidSalesTax4 + FinalBorrowerPaidSalesTax5;
                
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 1, ClosingDisclosureSection.B, 1, "Escrow Fee_NLAC", 0, FinalBorrowerPaid1, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 2, ClosingDisclosureSection.B, 2, "Escrow Fee_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax1, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 3, ClosingDisclosureSection.B, 3, "Other Fee_NLAC", 0, FinalBorrowerPaid2, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 4, ClosingDisclosureSection.B, 4, "Other Fee_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax2, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 5, ClosingDisclosureSection.B, 5, "Title - Lenders Policy_NLAC", 0, FinalBorrowerPaid3, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 6, ClosingDisclosureSection.B, 6, "Title - Lenders Policy_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax3, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 7, ClosingDisclosureSection.B, 7, "Title - Miscellaneous_NLAC", 0, FinalBorrowerPaid4, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 8, ClosingDisclosureSection.B, 8, "Title - Miscellaneous_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax4, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 9, ClosingDisclosureSection.B, 9, "Title - Owners Policy_NLAC", 0, FinalBorrowerPaid5, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 10, ClosingDisclosureSection.B, 10, "Title - Owners Policy_NLAC - Sales Tax", 0, FinalBorrowerPaidSalesTax5, 0);

                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV(TableID: "tblZeroPerVariance", AggregateAmountsExceeding: 0, 
                    AggregateLoanEstimate: null, AggregateFinal: null, TenPercentofAggregateLoanEstimate: null, 
                    differenceofFinalandLoanEstimate: null, Costabovetenpercent: null, Costabovetotalzeroandtenpercent: null);
                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV(TableID: "tblTenPerVariance", AggregateAmountsExceeding: null,
                    AggregateLoanEstimate: 0, AggregateFinal: TotalFinalBorrowerPaid, TenPercentofAggregateLoanEstimate: 0,
                    differenceofFinalandLoanEstimate: TotalFinalBorrowerPaid, Costabovetenpercent: TotalFinalBorrowerPaid, Costabovetotalzeroandtenpercent: null);
                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV(TableID: "tblCategoryTotal", AggregateAmountsExceeding: null, 
                    AggregateLoanEstimate: null, AggregateFinal: null, TenPercentofAggregateLoanEstimate: null,
                    differenceofFinalandLoanEstimate: null, Costabovetenpercent: null, Costabovetotalzeroandtenpercent: TotalFinalBorrowerPaid);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message); 
            }

            
     
        }

        [TestMethod] 
        [Description("FTR4_ITR41_US_530784_TC_538072_SC4: VERIFY SALES TAX IN 10% VARIANCE SECTION WHEN AMOUNT IS ENTER WITH PDD.")]
        public void FTR4_ITR41_US_530784_TC_538072_SC4()
        {
            try
            {
                Reports.TestDescription = "FTR4_ITR41_US_530784_TC_538072_SC4: VERIFY SALES TAX IN 10% VARIANCE SECTION WHEN AMOUNT IS ENTER WITH PDD.";
                _ADMLOGIN();

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("13071");
                FastDriver.GeneralLedgerSetup.CreateNewGeneralLedgerSetup(Description: "116-02 Recording Fees - Non-Revenue");

                #region Verify and create the Fees
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Escrow Fee", FeeCode: "53078401", FeeType: "Escrow Fee");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Other Fee", FeeCode: "53078402", FeeType: "Other Fee");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Title - Lenders Policy", FeeCode: "53078403", FeeType: "Title - Lenders Policy");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Title - Miscellaneous", FeeCode: "53078404", FeeType: "Title - Miscellaneous");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFee(Description: "530784_Title - Owners Policy", FeeCode: "53078405", FeeType: "Title - Owners Policy");
                #endregion

                #region Create File
                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                Reports.TestStep = "Enter charges to New Loan.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad()
                    .FillNewLoanForm(newLoan)
                    .ClickRecapTab();
                #endregion

                #region AddNonFACCRecordingFeeTax
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Escrow Fee", "530784_Escrow Fee", "53078401");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Other Fee", "530784_Other Fee", "53078402");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Lenders Policy", "530784_Title - Lenders Policy", "53078403");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Miscellaneous", "530784_Title - Miscellaneous", "53078404");
                FastDriver.FileFees.AddNonFACCRecordingFeeTax("Title - Owners Policy", "530784_Title - Owners Policy", "53078405");
                #endregion

                #region EnterBuyerandSellerAmountsUsingPDD
                // Fix according to code review 590479
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("530784_Escrow Fee", 4000, 4000, 4000, "Lender", 4000, 4000, 4000, "Lender", false, false, false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("530784_Other Fee", 5000, 5000, 5000, "Lender", 5000, 5000, 5000, "Lender", false, false, false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("530784_Title - Lenders Policy", 1000, 1000, 1000, "Lender", 1000, 1000, 1000, "Lender", false, false, false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("530784_Title - Miscellaneous", 2000, 2000, 2000, "Lender", 2000, 2000, 2000, "Lender", false, false, false, true);
                FastDriver.FileFees.EnterBuyerandSellerAmountUsingPDD("530784_Title - Owners Policy", 2000, 2000, 2000, "Lender", 3000, 3000, 3000, "Lender", false, false, false, true);
                #endregion

                #region Set Lender Adjustment Amount
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.LenderAdjustmentAmount.FASetText("6000");
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");//modified according to US559013
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion

                #region Obtain Final Borrower Paid Amounts
                double FinalBorrowerPaidSalesTax1, FinalBorrowerPaidSalesTax2, FinalBorrowerPaidSalesTax3, FinalBorrowerPaidSalesTax4, FinalBorrowerPaidSalesTax5 = 0.0;
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FinalBorrowerPaidSalesTax1 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 2, ChargeDescription: "Escrow Fee_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax2 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 4, ChargeDescription: "Other Fee_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax3 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 6, ChargeDescription: "Title - Lenders Policy_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax4 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 8, ChargeDescription: "Title - Miscellaneous_NLAC - Sales Tax");
                FinalBorrowerPaidSalesTax5 = FastDriver.ClosingDisclosure.CalculateFinalBorrowerPaidAmountForSalesTax(Section: ClosingDisclosureSection.B,
                    lineNo: 10, ChargeDescription: "Title - Owners Policy_NLAC - Sales Tax");
                #endregion

                #region Verify CD
                double FinalBorrowerPaid1 = 8000;
                double FinalBorrowerPaid2 = 10000;
                double FinalBorrowerPaid3 = 2000;
                double FinalBorrowerPaid4 = 4000;
                double FinalBorrowerPaid5 = 4000;
                double TotalFinalBorrowerPaid = FinalBorrowerPaid1 + FinalBorrowerPaid2 + FinalBorrowerPaid3 + FinalBorrowerPaid4 + FinalBorrowerPaid5 + FinalBorrowerPaidSalesTax1 + FinalBorrowerPaidSalesTax2 + FinalBorrowerPaidSalesTax3 + FinalBorrowerPaidSalesTax4 + FinalBorrowerPaidSalesTax5;

                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 1, ClosingDisclosureSection.B, 1, "530784_Escrow Fee", 0, FinalBorrowerPaid1, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 2, ClosingDisclosureSection.B, 2, "530784_Escrow Fee - Sales Tax", 0, FinalBorrowerPaidSalesTax1, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 3, ClosingDisclosureSection.B, 3, "530784_Other Fee", 0, FinalBorrowerPaid2, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 4, ClosingDisclosureSection.B, 4, "530784_Other Fee - Sales Tax", 0, FinalBorrowerPaidSalesTax2, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 5, ClosingDisclosureSection.B, 5, "530784_Title - Lenders Policy", 0, FinalBorrowerPaid3, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 6, ClosingDisclosureSection.B, 6, "530784_Title - Lenders Policy - Sales Tax", 0, FinalBorrowerPaidSalesTax3, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 7, ClosingDisclosureSection.B, 7, "530784_Title - Miscellaneous", 0, FinalBorrowerPaid4, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 8, ClosingDisclosureSection.B, 8, "530784_Title - Miscellaneous - Sales Tax", 0, FinalBorrowerPaidSalesTax4, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 9, ClosingDisclosureSection.B, 9, "530784_Title - Owners Policy", 0, FinalBorrowerPaid5, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAmountForCategory("tblTenPerVariance", 10, ClosingDisclosureSection.B, 10, "530784_Title - Owners Policy - Sales Tax", 0, FinalBorrowerPaidSalesTax5, 0);
                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV("tblZeroPerVariance", 0, null, null, null, null, null, null);
                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV("tblTenPerVariance", null, 0, TotalFinalBorrowerPaid, 0, TotalFinalBorrowerPaid, TotalFinalBorrowerPaid, null);
                FastDriver.ClosingDisclosureGFV.VerifyAggregateAmountForGFV("tblCategoryTotal", null, null, null, null, null, null, TotalFinalBorrowerPaid);
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            
           
        }
        
        #endregion

        /* The listed tests methods have been removed from the CodedUI script as of Sept 8, 2015:
         * Iteration52_473130_1
         * Iteration52_473130_2
         * Iteration52_473130_3
         * Iteration52_473130_4
         * Iteration52_473130_5
         * */
        #region 473130 CD Screen: Display Adj/Premium Amount as charge for the Primary Owner Policy on CD Form        
        [TestMethod]
        [Description("Verify Adjusted/Premium Amount as charge for the Primary Owner Policy on CD Form.")]
        public void Iteration52_473130_1()
        {
            try
            {
                Reports.TestDescription = "Iteration52_473130_1: Verify Adjusted/Premium Amount as charge for the Primary Owner Policy on CD Form.";
                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";

                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                #endregion

                #region Adding Fees
                Reports.TestStep = "Navigate to File Fees Add Fees";
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "All", FeeDescription: "OneRate Title-110% ALTA Ext.");
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "All", FeeDescription: "ALTA U.S. Policy #1037.91 (9-28-91)");
                #endregion

                #region Setting Buyer and Seller Adjustment Amount
                Reports.TestStep = "Setting Buyer and Seller Adjustment Amount and Click on Done Dutton";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "OneRate Title-110% ALTA Ext.", 4, TableAction.SetText, "500");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "OneRate Title-110% ALTA Ext.", 7, TableAction.SetText, "300");

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "ALTA U.S. Policy #1037.91 (9-28-91)", 4, TableAction.SetText, "400");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "ALTA U.S. Policy #1037.91 (9-28-91)", 7, TableAction.SetText, "200");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "ALTA U.S. Policy #1037.91 (9-28-91)", 7, TableAction.SendKeys, FAKeys.Tab);

                FastDriver.BottomFrame.Done();

                #endregion

                #region Open Payment Details Dialog and Verify Values

                Reports.TestStep = "Navigate to File Fee, Open Payment Details Dialog and Verify Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "ALTA U.S. Policy #1037.91 (9-28-91)", 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SectionB.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PrimaryPolicy.Selected.ToString());
                Support.AreEqual("$400.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$200.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();
                Support.AreEqual("$600.00", FastDriver.FileFees.OwnerAdjAmnt.FAGetValue().Trim());

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "OneRate Title-110% ALTA Ext.", 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SectionB.Selected.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PrimaryPolicy.Selected.ToString());
                Support.AreEqual("$500.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$300.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                #endregion

                #region Navigate to CD and Verify Values For Primary Policy Fee

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Loan Cost and verify Buyer and Seller on Section B";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();

                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableLoanCostSectionB);

                //SectionB BuyerAtClosing
                Support.AreEqual("$400.00", FastDriver.ClosingDisclosure.TableLoanCostSectionB.PerformTableAction(1, 1, TableAction.GetText).Message);
                //SectionB SellerAtClosing
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.TableLoanCostSectionB.PerformTableAction(1, 3, TableAction.GetText).Message);

                #endregion

                #region Navigate to Fee Entry and Change the Primary Policy Fee

                Reports.TestStep = "Navigate to File Fee, Open Payment Details Dialog and Change the selected Primary POlicy";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "OneRate Title-110% ALTA Ext.", 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicy.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();
                Support.AreEqual("$600.00", FastDriver.FileFees.OwnerAdjAmnt.FAGetValue().Trim());

                #endregion

                #region Navigate to CD and Verify Values For Primary Policy Fee

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Loan Cost and verify Buyer and Seller on Section B";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();

                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableLoanCostSectionB);

                //SectionB BuyerAtClosing
                Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.TableLoanCostSectionB.PerformTableAction(1, 1, TableAction.GetText).Message);
                //SectionB SellerAtClosing
                Support.AreEqual("$300.00", FastDriver.ClosingDisclosure.TableLoanCostSectionB.PerformTableAction(1, 3, TableAction.GetText).Message);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }


        }

        [TestMethod]
        [Description("Verify Buyer and Seller split % for the Owner  Policy on CD form.")]
        public void Iteration52_473130_2()
        {
            try
            {
                Reports.TestDescription = "Iteration52_473130_2: Verify Buyer and Seller split % for the Owner  Policy on CD form.";

                _ADMLOGIN();

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("13071");

                #region Verify and Create the GLCodes
                FastDriver.GeneralLedgerSetup.CreateNewGeneralLedgerSetup(Description: "732 Assumption");
                FastDriver.GeneralLedgerSetup.CreateNewGeneralLedgerSetup(Description: "902 Advances");
                #endregion

                #region Verify and create the Fees
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFeeWithFilterName(Description: "Test TOP435", FeeCode: "TOP73", FeeType: "Title - Owners Policy", FeeFilterName: "Filter Template for Customary Fees", LoanEstimateDescription: "Title - Owner's Title Insurance (optional)");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFeeWithFilterName(Description: "Test TOP564", FeeCode: "TOP74", FeeType: "Title - Owners Policy", FeeFilterName: "Filter Template for Customary Fees", LoanEstimateDescription: "Title - Owner's Title Insurance (optional)", Section: ClosingDisclosureSection.C, GLCode: "902 Advances");
                #endregion

                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";

                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                var newLoan = new NewLoanParameters()
                {
                    Type = "Small Loan",
                    Amount = "300000000",
                    GABCode = "247"
                };
                #endregion

                #region Adding Fees
                Reports.TestStep = "Navigate to File Fees Add Fees";
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Owners Policy", FeeDescription: "Test TOP435", FeeCode: "TOP73");
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Owners Policy", FeeDescription: "Test TOP564", FeeCode: "TOP74");
                #endregion

                #region Setting Buyer and Seller Adjustment Amount
                Reports.TestStep = "Setting Buyer and Seller Adjustment Amount and Click on Done Dutton";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test TOP435", 4, TableAction.SetText, "400");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test TOP435", 7, TableAction.SetText, "200");

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test TOP564", 4, TableAction.SetText, "500");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test TOP564", 7, TableAction.SetText, "300");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test TOP564", 7, TableAction.SendKeys, FAKeys.Tab);

                FastDriver.BottomFrame.Done();

                #endregion

                #region Open Payment Details Dialog and Verify Values

                Reports.TestStep = "Navigate to File Fee, Open Payment Details Dialog and Verify Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test TOP435", 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SectionB.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PrimaryPolicy.Selected.ToString());
                Support.AreEqual("$400.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$200.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();
                #endregion

                #region Change Split Percentage to 50% and verify
                Reports.TestStep = "Set Split Percentage to 50% and Verify";

                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                FastDriver.BuyerSellerSplitDlg.SplitPercentage.FASetText("50");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                Support.AreEqual("Seller 50.00%", FastDriver.FileFees.BSSplitSellerPercentage.Text);
                Support.AreEqual("Buyer 50.00%", FastDriver.FileFees.BSSplitBuyerPercentage.Text);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer and Seller Amounts

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer and Seller Amounts";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();

                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                //Verify Buyer
                Support.AreEqual("$400.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(1, 2, TableAction.GetText).Message);
                //Verify Seller
                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.LoanCostsSectionBSellerAtClosingAmount.Text);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Fee Entry and set Buyer Split Percentage to 75% and verify
                Reports.TestStep = "Navigate to Fee Entry and set Buyer Split Percentage to 75% and Verify";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.lenderAdjAmnt.FASetText("100");
                FastDriver.FileFees.BSSplitButton.FAClick();

                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                FastDriver.BuyerSellerSplitDlg.ApplyPercentageTo.FASelectItemBySendingKeys("Buyer");
                FastDriver.BuyerSellerSplitDlg.SplitPercentage.FASetText("75");
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                Support.AreEqual("Seller 25.00%", FastDriver.FileFees.BSSplitSellerPercentage.Text);
                Support.AreEqual("Buyer 75.00%", FastDriver.FileFees.BSSplitBuyerPercentage.Text);

                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer and Seller Amounts

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Loan Cost";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();

                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                //Verify Buyer
                Support.AreEqual("$375.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(1, 2, TableAction.GetText).Message);
                //Verify Seller
                Support.AreEqual("$125.00", FastDriver.ClosingDisclosure.LoanCostsSectionBSellerAtClosingAmount.Text);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Verify Adjusted/Premium Amount as charge for the FACC Primary Owner Policy,Normal Policy and Policy with Subject to Sales tax on CD Form.")]
        public void Iteration52_473130_3()
        {
            try
            {
                Reports.TestDescription = "Iteration52_473130_3: Verify Adjusted/Premium Amount as charge for the FACC Primary Owner Policy,Normal Policy and Policy with Subject to Sales tax on CD Form.";

                _ADMLOGIN();

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("13071");

                #region Verify and Create the GLCodes
                FastDriver.GeneralLedgerSetup.CreateNewGeneralLedgerSetup(Description: "732 Assumption");
                #endregion

                #region Verify and create the Fees
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFeeWithFilterName(Description: "Test NTOP132", FeeCode: "NTOP132", FeeType: "Title - Owners Policy", FeeFilterName: "Filter Template for Customary Fees", LoanEstimateDescription: "Title - Owner's Title Insurance (optional)");
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFeeWithFilterName(Description: "Test FTOP132", FeeCode: "FTOP132", FeeType: "Title - Owners Policy", FeeFilterName: "Filter Template for Customary Fees", LoanEstimateDescription: "Title - Owner's Title Insurance (optional)", Section: ClosingDisclosureSection.C, SubjectToCalculation: true);
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFeeWithFilterName(Description: "Test STOP132", FeeCode: "STOP132", FeeType: "Title - Owners Policy", FeeFilterName: "Filter Template for Customary Fees", LoanEstimateDescription: "Title - Owner's Title Insurance (optional)", Section: ClosingDisclosureSection.H, SubjectToSaleTaxes: true);

                #endregion

                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";

                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Add First Owner's Liabity Amount
                Reports.TestStep = "Navigate to Terms/Dates/Status Screen and add the First Oweners Liability";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("10,00.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                #endregion

                #region Adding Fees
                Reports.TestStep = "Navigate to File Fees Add Fees";
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Owners Policy", FeeDescription: "Test NTOP132", FeeCode: "NTOP132");
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Owners Policy", FeeDescription: "Test STOP132", FeeCode: "STOP132");
                #endregion

                #region Add Calutated Fees and Test FACC Fee Description
                Reports.TestStep = " Add Calutated Fees and Test FACC Fee Description";
                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.TitleRates.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Standard Owner Policy");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.Click();

                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 4, TableAction.GetCell).Element.FASelectItemBySendingKeys(index: 0, lastFirst: true);


                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText("Test FTOP132");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(3, "FTOP132", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.CalculateFees.SwitchToContentFrame();
                FastDriver.CalculateFees.SummaryTable.SendKeys(Keys.Right);
                FastDriver.CalculateFees.SummaryTable.SendKeys(Keys.Right);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 6, TableAction.SelectItem, "Premium Split");

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 7, TableAction.SetText, "2,000.00");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 8, TableAction.SetText, "50");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 8, TableAction.SendKeys, FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region VERIFY FACC TITLE OWNER POLICY DETAILS
                Reports.TestStep = "VERIFY FACC TITLE OWNER POLICY DETAILS";

                FastDriver.FileFees.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitleandescrowTable.Text.Contains("Test FTOP132").ToString());
                Support.AreEqual("1,000.00", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test FTOP132", 4, TableAction.GetAttribute, "value").Message.Trim());
                Support.AreEqual("1,000.00", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test FTOP132", 7, TableAction.GetAttribute, "value").Message.Trim());

                #endregion

                #region Verify and Edit Payment Details Dialog for Policy FTOP132
                Reports.TestStep = "Verify and Edit Payment Details Dialog for Policy Test FTOP132";
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test FTOP132", 3, TableAction.Click);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SectionC.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PrimaryPolicy.Selected.ToString());

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region  Enter Buyer and Seller Charge Amount
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test NTOP132", 4, TableAction.SetText, "500");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test NTOP132", 7, TableAction.SetText, "300");

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test STOP132", 4, TableAction.SetText, "400");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test STOP132", 7, TableAction.SetText, "200");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test STOP132", 7, TableAction.SendKeys, FAKeys.Tab);

                #endregion

                #region Verify and Edit Payment Details Dialog for Policy NTOP132
                Reports.TestStep = "Verify and Edit Payment Details Dialog for Policy Test FTOP132";
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test NTOP132", 3, TableAction.Click);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.PrimaryPolicy.FASetCheckbox(true);
                FastDriver.PaymentDetailsDlg.SectionB.FAClick();

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Verify and Edit Payment Details Dialog for Policy STOP132
                Reports.TestStep = "Verify and Edit Payment Details Dialog for Policy Test FTOP132";
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test STOP132", 3, TableAction.Click);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.SectionC.FAClick();
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PrimaryPolicy.Selected.ToString());

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Add LenderAdjusment Amount
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("100");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer and Seller Amounts

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Loan Cost";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();

                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                //Verify Buyer
                Support.AreEqual("$700.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(1, 2, TableAction.GetText).Message);
                //Verify Seller
                Support.AreEqual("$1,000.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual("$1,000.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidShopForTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                FastDriver.BottomFrame.Done();
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify Owner Policy Name On CD Form When Owner Policy is split by a Split $ amount")]
        public void Iteration52_473130_4()
        {
            try
            {
                Reports.TestDescription = "Iteration52_473130_4: Verify Owner Policy Name On CD Form When Owner Policy is split by a Split $ amount";

                _ADMLOGIN();

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("13071");

                #region Verify and Create the GLCodes
                FastDriver.GeneralLedgerSetup.CreateNewGeneralLedgerSetup(Description: "732 Assumption");
                #endregion

                #region Verify and create the Fees
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFeeWithFilterName(Description: "Test Description TOP3", FeeCode: "T126", FeeType: "Title - Owners Policy", FeeFilterName: "Filter Template for Customary Fees", SubjectToCalculation: true);
                #endregion

                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";

                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Add First Owner's Liabity Amount
                Reports.TestStep = "Navigate to Terms/Dates/Status Screen and add the First Oweners Liability";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("10,00.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                #endregion

                #region Add Calutated Fees and Test FACC Fee Description
                Reports.TestStep = " Add Calutated Fees and Test FACC Fee Description";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.TitleRates.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Standard Owner Policy");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.Click();

                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 4, TableAction.GetCell).Element.FASelectItemBySendingKeys(index: 0, lastFirst: true);


                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText("Test Description TOP3");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(3, "T126", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.CalculateFees.SwitchToContentFrame();
                FastDriver.CalculateFees.SummaryTable.SendKeys(Keys.Right);
                FastDriver.CalculateFees.SummaryTable.SendKeys(Keys.Right);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 6, TableAction.SelectItem, "Premium Split");

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 7, TableAction.SetText, "2,000.00");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 9, TableAction.SetText, "500.00");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 9, TableAction.SendKeys, FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify The Buyer and Seller Amount
                Reports.TestStep = "Verify The Buyer and Seller Amount";

                FastDriver.FileFees.SwitchToContentFrame();
                Support.AreEqual("Seller $0.00", FastDriver.FileFees.BSSplitSellerPercentage.Text.Trim());
                Support.AreEqual("Buyer $0.00", FastDriver.FileFees.BSSplitBuyerPercentage.Text.Trim());

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer and Seller Amounts

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Loan Cost";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();

                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Support.AreEqual("01. Test Description TOP3 to First American Title Company", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 1, TableAction.GetText).Message);
                Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual("$1,500.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Verify Owner Policy On CD Form When Owner Policy is split by a B/S Split %")]
        public void Iteration52_473130_5()
        {
            try
            {
                Reports.TestDescription = "Iteration52_473130_5: Verify Owner Policy On CD Form When Owner Policy is split by a B/S Split %";
                _ADMLOGIN();

                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("13071");

                #region Verify and Create the GLCodes
                FastDriver.GeneralLedgerSetup.CreateNewGeneralLedgerSetup(Description: "732 Assumption");
                #endregion

                #region Verify and create the Fees
                FastDriver.FeeList2.VerifyIfExistsAndCreateNewFeeWithFilterName(Description: "Test Description TOP3", FeeCode: "T126", FeeType: "Title - Owners Policy", FeeFilterName: "Filter Template for Customary Fees", SubjectToCalculation: true);
                #endregion

                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";

                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Add First Owner's Liabity Amount
                Reports.TestStep = "Navigate to Terms/Dates/Status Screen and add the First Oweners Liability";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("10,00.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                #endregion

                #region Add Calutated Fees and Test FACC Fee Description
                Reports.TestStep = " Add Calutated Fees and Test FACC Fee Description";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.TitleRates.FASetCheckbox(true);
                FastDriver.FileFees.CalculateFees.FAClick();

                FastDriver.CalculateFees.WaitForScreenToLoad();
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Standard Owner Policy");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.Next.Click();

                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 4, TableAction.GetCell).Element.FASelectItemBySendingKeys(index: 0, lastFirst: true);


                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText("Test Description TOP3");
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(3, "T126", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.CalculateFees.SwitchToContentFrame();
                FastDriver.CalculateFees.SummaryTable.SendKeys(Keys.Right);
                FastDriver.CalculateFees.SummaryTable.SendKeys(Keys.Right);

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 5, TableAction.SelectItem, "Buyer");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 6, TableAction.SelectItem, "Premium Split");

                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 7, TableAction.SetText, "2,000.00");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 8, TableAction.SetText, "50");
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 8, TableAction.SendKeys, FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify The Buyer and Seller Amount
                Reports.TestStep = "Verify The Buyer and Seller Amount";

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                Support.AreEqual("Seller 50.00%", FastDriver.FileFees.BSSplitSellerPercentage.Text.Trim());
                Support.AreEqual("Buyer 50.00%", FastDriver.FileFees.BSSplitBuyerPercentage.Text.Trim());
                Support.AreEqual("1,000.00", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test Description TOP3", 4, TableAction.GetAttribute, "value").Message);
                Support.AreEqual("1,000.00", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "Test Description TOP3", 7, TableAction.GetAttribute, "value").Message);

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer and Seller Amounts

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Loan Cost";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();

                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                Support.AreEqual("$1,000.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual("$1,000.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        //On the CodedUI script, this tests methods' content hast been replaced with the one from REG_FEE_06 test method
        [TestMethod]
        [Description("VERIFY THE TITLE POLICY CALCULATION SECTION AND RECORDING FEE & TRANSFER TAX SECTION IN FILE FEES SCREEN")]
        public void REG_FEE_05()
        {
            try
            {
                Reports.TestDescription = "REG_FEE_05 : TO VERIFY THE TITLE POLICY CALCULATION SECTION AND RECORDING FEE & TRANSFER TAX SECTION IN FILE FEES SCREEN";

                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";

                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Loan Policy");
                #endregion

                #region Navigate to Terms/Dates/Status and Add values
                Reports.TestStep = "Navigate to Terms/Dates/Status and Add values";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("500,000.00");
                FastDriver.TermsDatesStatus.LiabilityAmount.SendKeys(FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("500,000.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to New Loan and enter values
                Reports.TestStep = "Navigate to New Loan and enter values";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItemBySendingKeys("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsLoanAmount.SendKeys(FAKeys.Tab);
                FastDriver.NewLoan.LenderPolicyLiability.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION
                Reports.TestStep = "Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION";
                FastDriver.FileFees.VerifyFieldsInTCPSection();
                #endregion

                #region ENTER THE LOANESTIMATE UNROUNDED IN TPC SECTION
                Reports.TestStep = "ENTER THE LOANESTIMATE UNROUNDED IN TPC SECTION";
                FastDriver.FileFees.LenderLoanEstimateAmount.FASetText("1200.89");
                FastDriver.FileFees.OwnerLoanEstimateAmount.FASetText("456.33");
                FastDriver.FileFees.OwnerLoanEstimateAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual(FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue(), FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue().Replace("$", "").FormatAsMoney(true));
                Support.AreEqual(FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue(), FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue().Replace("$", "").FormatAsMoney(true));
                #endregion

                #region GO TO RECORDING AND TAX TAB and VERIFY THE LABELS IN RECORDING FEES AND TAX SECTION
                Reports.TestStep = "GO TO RECORDING AND TAX TAB and VERIFY THE LABELS IN RECORDING FEES AND TAX SECTION";
                FastDriver.FileFees.VerifyRecordingTransferTaxSection();
                #endregion

                #region Navigate to CD Expand Loan Cost
                Reports.TestStep = "Navigate to Closing Disclosure and Expand Loan Cost";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                #endregion

                #region Navigate to FileFees, Change Form type to HUD, Verify and navigate to HUD-1 Statement
                Reports.TestStep = "Navigate to FileFees, Change Form type to HUD, Verify and navigate to HUD-1 Statement";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.HUD.FAClick();
                FastDriver.FileFees.WaitForFeeScreen();

                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitlePolicyCalculationsforHUD.Text.Contains("Title Services and Title Insurance").ToString());
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeesTax);
                Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingFeesAndTransferTaxes.Text.Contains("Government Recording and TransferTaxes").ToString());

                FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Home>Order Entry>Escrow Closing>HUD-1 Statement");

                #endregion

                #region Navigate to FileFees, Change Form type to CD and Verify
                Reports.TestStep = "Navigate to FileFees, Change Form type to CD and Verify";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.CD.FAClick();
                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.VerifyFieldsInTCPSection();

                #endregion

                #region GO TO RECORDING AND TAX TAB and VERIFY THE LABELS IN RECORDING FEES AND TAX SECTION
                Reports.TestStep = "GO TO RECORDING AND TAX TAB and VERIFY THE LABELS IN RECORDING FEES AND TAX SECTION";
                FastDriver.FileFees.VerifyRecordingTransferTaxSection();
                #endregion

                #region Go to Title Escrow Tab and Select Fee
                Reports.TestStep = "Go to Title Escrow Tab and Select Fee \"Bundle Rate - see note section for breakdown\" ";
                FastDriver.FileFees.TitleandEscrow.FAClick();
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "All", FeeDescription: "Bundle Rate - see note section for breakdown");
                #endregion

                #region Navigate to CD Expand Loan Cost
                Reports.TestStep = "Navigate to Closing Disclosure and Expand Loan Cost";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                #endregion

                #region Navigate to FileFees, Change Form type to HUD and Verify Message
                Reports.TestStep = "Navigate to FileFees, Change Form type to HUD and Verify Message";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.HUD.FAClick();
                Support.AreEqual(FastDriver.WebDriver.HandleDialogMessage(), "All fees must be deselected and all charges must be removed to change Form Type.");
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.DeselectTitleScrowFee("Bundle Rate - see note section for breakdown");
                #endregion

                #region Navigate to FileFees, Change Form type to HUD, Verify and navigate to HUD-1 Statement
                Reports.TestStep = "Navigate to FileFees, Change Form type to HUD, Verify and navigate to HUD-1 Statement";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.HUD.FAClick();
                FastDriver.FileFees.WaitForFeeScreen();

                Support.AreEqual(true.ToString(), FastDriver.FileFees.TitlePolicyCalculationsforHUD.Text.Contains("Title Services and Title Insurance").ToString());
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeesTax);
                Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingFeesAndTransferTaxes.Text.Contains("Government Recording and TransferTaxes").ToString());

                FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>("Home>Order Entry>Escrow Closing>HUD-1 Statement");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }           
        }

        //On the CodedUI script, this tests methods' content hast been replaced with the one from REG_FEE_07 test method
        [TestMethod]
        [Description(" VERIFY THE FULL LOAN PREMIUM, DISCLOSED OWNER PREMIUM AND TITLE POLICY ADJUSTMENT FOR A NON FACC FEES")]
        public void REG_FEE_06() //Review In Progress...
        {
            try
            {
                Reports.TestDescription = "REG_FEE_06 : TO VERIFY THE FULL LOAN PREMIUM, DISCLOSED OWNER PREMIUM AND TITLE POLICY ADJUSTMENT FOR A NON FACC FEES";

                #region Initialize variables
                string FeeDesc_TLP = "New Home Rate ALTA Ext.Loan 1056.06 (2006)-1";//Description Editable
                string FeeDesc_TLP1 = "OneRate Title-110% ALTA Ext.";
                string FeeDesc_TOP = "New Home Rate (Title Only)";//Additional Description editable
                string FeeDesc_TOP1 = "New Home Rate Eagle Owner";
                string Loanesttop = "Title - Owner's Title Insurance (optional)";
                string Loanesttop1 = "Title - Owner's Title Insurance (optional)123";
                string TopEditChargeDesc = "Updated top LoanEstimate descin CD";
                string TlpEditChargeDesc = "Updated tlp LoanEstimate descin CD";
                string FeeDesc_Lender;
                string FeeDesc_Owner;
                string DisclosedOwnerPremium;
                string BuyerCharge;
                string SellerCharge;
                string B_PAC_PM;
                string B_PBO_PM;
                string S_PAC_PM;
                string S_PBO_PM;
                string BuyerTooltip;
                string SellerTooltip;
                string BuyerSplitpercent;
                string SellerSplitpercent;
                string Desc;
                string LoanEstDesc;
                string DefaultBuyerTooltip;
                string DefaultSellerTooltip;
                string TitlePremiumAmount;
                #endregion

                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";

                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "San Francisco", 
                                County = "San Francisco",
                                Zip = "94122",
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Loan Policy");
                #endregion

                #region Navigate to Terms/Dates/Status and Add values
                Reports.TestStep = "Navigate to Terms/Dates/Status and Add values";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("500,000.00");
                FastDriver.TermsDatesStatus.LiabilityAmount.SendKeys(FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("500,000.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to New Loan and enter values
                Reports.TestStep = "Navigate to New Loan and enter values";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItemBySendingKeys("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsLoanAmount.SendKeys(FAKeys.Tab);
                FastDriver.NewLoan.LenderPolicyLiability.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION
                Reports.TestStep = "Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION";
                FastDriver.FileFees.VerifyFieldsInTCPSection();
                #endregion

                #region Go to Title Escrow  and Select the Fees
                Reports.TestStep = "Go to Title Escrow Tab and Select the Fees";
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Lenders Policy", FeeDescription: FeeDesc_TLP);
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Lenders Policy", FeeDescription: FeeDesc_TLP1);
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Owners Policy", FeeDescription: FeeDesc_TOP);
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Owners Policy", FeeDescription: FeeDesc_TOP1);
                #endregion

                #region Set Buyer Seller Charge amount for fees
                Reports.TestStep = "Set Buyer Seller Charge amount for fees";
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.EnterAmount(FeeDesc: FeeDesc_TLP, TitleEscrowTable: true, Buyer_Amt: "100", Seller_Amt: "100");
                FastDriver.FileFees.EnterAmount(FeeDesc: FeeDesc_TLP1, TitleEscrowTable: true, Buyer_Amt: "2000", Seller_Amt: "3000");
                FastDriver.FileFees.EnterAmount(FeeDesc: FeeDesc_TOP, TitleEscrowTable: true, Buyer_Amt: "150", Seller_Amt: "150");
                FastDriver.FileFees.EnterAmount(FeeDesc: FeeDesc_TOP1, TitleEscrowTable: true, Buyer_Amt: "1500", Seller_Amt: "5000");
                FastDriver.BottomFrame.Done();
                #endregion;

                #region Open Payment Details Dialog and Verify Values for New Home Rate Eagle Owner Fee

                Reports.TestStep = "Navigate to File Fee, \"New Home Rate Eagle Owner\" Open Payment Details Dialog and Verify Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 3, TableAction.Click);//can it be "New Home Rate (Title Only)"?
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, FeeDesc_TOP, 3, TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                Reports.TestStep = "VERIFY LOANESTIMATE DESCRIPTION IS PREPENDED WITH TITLE FOLLOWED BY FEE DESCRIPTION";
                FastDriver.PaymentDetails.VerifyLoanEstimateDescTitleFeeinPDD(FeeType: "OwnerPolicy", FeeDesc: FeeDesc_TOP);
                LoanEstDesc = FeeDesc_TOP;
                //Support.AreEqual("Title - Owner's Title Insurance (optional)", FastDriver.PaymentDetails.LEDesc.FAGetValue());

                Reports.TestStep = "EDIT ADDITIONAL DESCRIPTION IN PDD";
                FastDriver.PaymentDetails.AdditionalDesc.FASetText("AdditionalDescription");
                Desc = "AdditionalDescription";
                FastDriver.PaymentDetails.AdditionalDesc.SendKeys(FAKeys.Tab);
                //FastDriver.PaymentDetailsDlg.PrimaryPolicy.FASetCheckbox(true);
                //Support.AreEqual("Title - Owner's Title Insurance (optional)", FastDriver.PaymentDetailsDlg.LEDescription.FAGetValue());
                FastDriver.PaymentDetails.VerifyLoanEstimateDescTitleFeeinPDD(FeeType: "OwnerPolicy", FeeDesc: FeeDesc_TOP);
                LoanEstDesc = FeeDesc_TOP;
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                //Support.AreEqual("New Home Rate Eagle Owner AdditionalDescription", FastDriver.FileFees.TitleOwnerPolicyName.Text.Trim());
                FastDriver.FileFees.VerifythePolicyNameinTPCsection(FeeType: "Owner", Desc: Desc);
                string TitleOwnerPolicyName = FastDriver.FileFees.TitleOwnerPolicyName.Text.Trim();

                #endregion

                #region Open Payment Details Dialog and Verify Values for New Home Rate ALTA Ext.Loan 1056.06 (2006)-1 fee

                Reports.TestStep = "Navigate to File Fee,Open \"New Home Rate ALTA Ext.Loan 1056.06 (2006)-1\"Payment Details Dialog and Verify Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, FeeDesc_TLP, 3, TableAction.Click);

                FastDriver.PaymentDetails.WaitForScreenToLoad();
                Reports.TestStep = "VERIFY LOANESTIMATE DESCRIPTION IS PREPENDED WITH TITLE FOLLOWED BY FEE DESCRIPTION";
                //Support.AreEqual("Title - New Home Rate ALTA Ext.Loan 1056.06 (2006)-1", FastDriver.PaymentDetailsDlg.LEDescription.FAGetValue());
                FastDriver.PaymentDetails.VerifyLoanEstimateDescTitleFeeinPDD(FeeType: "", FeeDesc: FeeDesc_TLP);
                LoanEstDesc = FeeDesc_TLP;
                Reports.TestStep = "EDIT ADDITIONAL DESCRIPTION IN PDD";
                Support.AreEqual("true", FastDriver.PaymentDetails.Desc.Enabled.ToString().ToLower());
                FastDriver.PaymentDetails.Desc.FASetText("DescriptionEdited");//the fee must be set to editable in ADM
                FastDriver.PaymentDetails.Desc.SendKeys(FAKeys.Tab);
                //Support.AreEqual("Title - New Home Rate ALTA Ext.Loan 1056.06 (2006)-1", FastDriver.PaymentDetails.LEDesc.FAGetValue());
                FastDriver.PaymentDetails.VerifyLoanEstimateDescTitleFeeinPDD(FeeType: "", FeeDesc: FeeDesc_TLP);
                LoanEstDesc = FeeDesc_TLP;
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                Support.AreEqual("DescriptionEdited", FastDriver.FileFees.TitleLenderPolicyName.Text.Trim());

                string TitleLenderPolicyName = FastDriver.FileFees.TitleLenderPolicyName.Text.Trim();
                #endregion

                #region Set Lender Adj Amount
                Reports.TestStep = "Set Lender Adj Amount";
                FastDriver.FileFees.lenderAdjAmnt.FASetText("400.00");
                FastDriver.FileFees.lenderAdjAmnt.SendKeys(FAKeys.Tab);
                Support.AreEqual(FastDriver.FileFees.lenderAdjAmnt.FAGetValue(), "400.00".FormatAsMoney(true));
                FastDriver.FileFees.DisplaySalesTaxOnCD.FASelectItemBySendingKeys("Separate line");//modified according to US559013
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section B
                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section B";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                FastDriver.ClosingDisclosure.ExpandLoanCost();
                FastDriver.ClosingDisclosure.VerifyAmount(section: ClosingDisclosureSection.B, lineNo: 1, ChargeDescription: "Title - " + FeeDesc_TLP, 
                    BuyerAtClosing: 400.00, BuyerBeforeClosing: null, BuyerPaidbyOther: null, SellerAtClosing: null, SellerBeforeClosing: null,
                    SellerPaidbyOthers: null, LenderExist: false, LoanEstimteUnroundedAmt: null, LoanEstimateRoundedAmt: null);
                FastDriver.ClosingDisclosure.VerifyAmount(section: ClosingDisclosureSection.B, lineNo: 2, ChargeDescription: "Title - " + FeeDesc_TLP1, 
                    BuyerAtClosing: 2000.00, BuyerBeforeClosing: null, BuyerPaidbyOther: null, SellerAtClosing: 3000.00, SellerBeforeClosing: null,
                    SellerPaidbyOthers: null, LenderExist: false, LoanEstimteUnroundedAmt: null, LoanEstimateRoundedAmt: null);
                #endregion

                #region Edit and verify Loan Estimate Rounded
                Reports.TestStep = "Edit and verify Loan Estimate Rounded";
                FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.SendKeys(Keys.Right);
                FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.SendKeys(Keys.Right);

                FastDriver.ClosingDisclosure.LoanEstimateColumn(Section: ClosingDisclosureSection.B, Description: "Title - " + FeeDesc_TLP, 
                    Option: "edit", isrounded: true, LEValue: 76543.89M, IsBrokenLink: true);
                //FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 8, TableAction.SetText, "76543.89");
                //FastDriver.BottomFrame.Done();

                //FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                //do
                //{
                //    FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                //}
                //while (!FastDriver.ClosingDisclosure.DisplayLoanEstimate.Selected);

                //FastDriver.ClosingDisclosure.ExpandLoanCost();
                //FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.SendKeys(Keys.Right);
                //FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.SendKeys(Keys.Right);
                //FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.SendKeys(Keys.Down);
                //FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.SendKeys(Keys.Down);
                //Support.AreEqual("$76,544.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 8, TableAction.GetText).Message);
                #endregion

                #region Edit and verify Fee Description for Section B
                Reports.TestStep = "Edit and verify Fee Description for Section B";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                FastDriver.ClosingDisclosure.ExpandLoanCost();

                //FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 1, TableAction.GetCell, "76543.89");//should be 76544 since it's Rounded
                //TlpEditChargeDesc = "Updated tlp LoanEstimate descin CD";
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.B, "Title - " + FeeDesc_TLP, TlpEditChargeDesc);

                FastDriver.BottomFrame.Done();

                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                FastDriver.ClosingDisclosure.ExpandLoanCost();
                Support.AreEqual(true.ToString(), FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.Text.Contains("Updated tlp LoanEstimate descin CD").ToString());

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section H
                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                FastDriver.ClosingDisclosure.ExpandOtherCosts();
                FastDriver.ClosingDisclosure.VerifyAmount(ChargeDescription: "Title - Owner's Title Insurance (optional)", lineNo: 1, 
                    section: ClosingDisclosureSection.H, BuyerAtClosing: 100.00, BuyerBeforeClosing: null, BuyerPaidbyOther: null, SellerAtClosing: null, 
                    SellerBeforeClosing: null, SellerPaidbyOthers: null, LenderExist: false, LoanEstimteUnroundedAmt: null, LoanEstimateRoundedAmt: null);//values not matching!!!
                FastDriver.ClosingDisclosure.VerifyAmount(ChargeDescription: "Title - Owner's Title Insurance (optional)", lineNo: 2,
                    section: ClosingDisclosureSection.H, BuyerAtClosing: 1500.00, BuyerBeforeClosing: null, BuyerPaidbyOther: null, SellerAtClosing: 5000,
                    SellerBeforeClosing: null, SellerPaidbyOthers: null, LenderExist: false, LoanEstimteUnroundedAmt: null, LoanEstimateRoundedAmt: null);//values not matching!!!
                #endregion

                #region Edit and verify Loan Estimate Rounded
                Reports.TestStep = "Edit and verify Loan Estimate Rounded";
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                //Loanesttop = Title - Owner's Title Insurance (optional)
                FastDriver.ClosingDisclosure.LoanEstimateColumn(Section: ClosingDisclosureSection.H, Description: Loanesttop,
                    Option: "edit", isrounded: true, LEValue: 85432.34M, IsBrokenLink: true);
                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Down);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Down);
                //TopEditChargeDesc = "Updated top LoanEstimate descin CD"
                FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, Loanesttop, TopEditChargeDesc);

                FastDriver.BottomFrame.Done();

                //FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                //FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();
                //Playback.Wait(1000);
                //FastDriver.ClosingDisclosure.ExpandOtherCosts();
                //FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                //FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                //FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Down);
                //FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Down);
                //Support.AreEqual("$85,432.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 8, TableAction.GetText).Message);
                
                //#endregion

                //#region Edit and verify Fee Description for Section H
                //Reports.TestStep = "Edit and verify Fee Description for Section H";
                //FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                //FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad(); 
                //FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();
                //Playback.Wait(1000);
                //FastDriver.ClosingDisclosure.ExpandOtherCosts();
                //FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 1, TableAction.GetCell, "76543.89");

                //FastDriver.ClosingDisclosure.editCostDescription(ClosingDisclosureSection.H, "Title - Owner's Title Insurance (optional)", "Updated top LoanEstimate descin CD");

                //FastDriver.BottomFrame.Done();

                //FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                //FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                //FastDriver.ClosingDisclosure.ExpandOtherCosts();
                //Support.AreEqual(true.ToString(), FastDriver.ClosingDisclosure.SectionHTable.Text.Contains("Updated top LoanEstimate descin CD").ToString());
                #endregion

                #region Navigate to Files Fee Open PDD and Verify Values
                Reports.TestStep = "Navigate to File Fee, \"New Home Rate (Title Only)\" Open Payment Details Dialog and Verify Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                //FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 3, TableAction.Click);//Description Not Found
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, FeeDesc_TOP + " AdditionalDescription", 3, TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();

                Support.AreEqual("$0.00", FastDriver.PaymentDetails.LEUnrounded.FAGetValue().Trim());
                Support.AreEqual("$85,432.00", FastDriver.PaymentDetails.LERounded.FAGetValue().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetails.BrokenImage.Displayed.ToString());

                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                #endregion

                #region Navigate to Files Fee Open PDD and Verify Values
                Reports.TestStep = "Navigate to File Fee, \"New Home Rate ALTA Ext.Loan 1056.06 (2006)-1\" Open Payment Details Dialog and Verify Values";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "DescriptionEdited", 3, TableAction.Click);

                FastDriver.PaymentDetails.WaitForScreenToLoad();

                Support.AreEqual("$0.00", FastDriver.PaymentDetails.LEUnrounded.FAGetValue().Trim());
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetails.LERounded.FAGetValue().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetails.BrokenImage.Displayed.ToString());

                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                #endregion

                #region Calculate POD and Set BuyerSeller Split
                Reports.TestStep = "Calculate POD and Set BuyerSeller Split";

                DisclosedOwnerPremium = FastDriver.FileFees.CalculateAndGetPOD(TitleLenderPolicyName, TitleOwnerPolicyName);

                FastDriver.FileFees.BSSplitButton.Click();
                FastDriver.BuyerSellerSplitDlg.VerifyBuyerSellerSplitDialog(FeeDesc: TitleOwnerPolicyName, ApplyPercentageTo: "Seller", SplitPercentage: "100.00", DisclosedOwnerPremium: DisclosedOwnerPremium);


                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.CalculateVerifyAndGetTPA(FeeDesc: TitleLenderPolicyName, SplitPercentage: "100.00");
                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.BSSplitButton.Click();
                FastDriver.BuyerSellerSplitDlg.VerifyBuyerSellerSplitDialog(FeeDesc: TitleOwnerPolicyName, ApplyPercentageTo: "Seller", SplitPercentage: "100.00", DisclosedOwnerPremium: DisclosedOwnerPremium);
                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.BSSplitButton.Click();
                FastDriver.BuyerSellerSplitDlg.EnterSplitPercentage("60.00");
                FastDriver.FileFees.WaitForFeeScreen();


                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section B

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section B";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                FastDriver.ClosingDisclosure.ExpandLoanCost();

                Support.AreEqual("$2,000.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual("$3,000.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                FastDriver.ClosingDisclosure.ExpandOtherCosts();

                Support.AreEqual("$60.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual("$40.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                #endregion

                #region Navigate to Files and Set BuyerSeller Split
                Reports.TestStep = "Navigate to Files and Set BuyerSeller Split";

                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.BSSplitButton.Click();
                FastDriver.BuyerSellerSplitDlg.VerifyBuyerSellerSplitDialog(FeeDesc: TitleOwnerPolicyName, ApplyPercentageTo: "Seller", SplitPercentage: "60.00", DisclosedOwnerPremium: DisclosedOwnerPremium);

                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen();
                #endregion

                #region Calculate and Verify TPA
                Reports.TestStep = "Calculate and Verify TPA";

                FastDriver.FileFees.CalculateVerifyAndGetTPA(FeeDesc: TitleLenderPolicyName, SplitPercentage: "100.00");
                #endregion

                #region Calculate Buyer Seller Charge From PDD
                Reports.TestStep = "Calculate Buyer Seller Charge From PDD";

                string BuyerSellerToolTip = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyName, 3, TableAction.GetCell).Element.FindElement(By.CssSelector("input")).GetAttribute("title");

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyName, 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("200.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("100.00");
                FastDriver.PaymentDetailsDlg.CalculateBuyerSellerCharge(BuyerSellerToolTip: BuyerSellerToolTip);
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Verify Buyer Seller PDD Charge Values on Title Scrow Fee Table
                Reports.TestStep = "Verify Buyer Seller PDD Charge Values on Title Scrow Fee Table";
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyName, 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                SellerCharge = FastDriver.PaymentDetailsDlg.CalculateSellerCharge();
                BuyerCharge = FastDriver.PaymentDetailsDlg.CalculateBuyerCharge();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                Support.AreEqual(BuyerCharge, FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyName, 4, TableAction.GetAttribute, "value").Message);

                Support.AreEqual(SellerCharge, FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyName, 7, TableAction.GetAttribute, "value").Message);

                #endregion

                #region Calculate POD and Set BuyerSeller Split
                Reports.TestStep = "Calculate POD and Set BuyerSeller Split";

                DisclosedOwnerPremium = FastDriver.FileFees.CalculateAndGetPOD(TitleLenderPolicyName, TitleOwnerPolicyName);

                FastDriver.FileFees.BSSplitButton.Click();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                FastDriver.BuyerSellerSplitDlg.ApplyPercentageTo.FASelectItemBySendingKeys("Buyer");
                FastDriver.BuyerSellerSplitDlg.SplitPercentage.FASetText("40.00");
                FastDriver.BuyerSellerSplitDlg.SplitPercentage.SendKeys(FAKeys.Tab);
                FastDriver.BuyerSellerSplitDlg.VerifyBuyerSellerSplitDialog(FeeDesc: TitleOwnerPolicyName, ApplyPercentageTo: "Buyer", SplitPercentage: "40.00", DisclosedOwnerPremium: DisclosedOwnerPremium);
                FastDriver.FileFees.WaitForFeeScreen();

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                FastDriver.ClosingDisclosure.ExpandOtherCosts();

                Support.AreEqual("$120.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(3, 2, TableAction.GetText).Message);
                Support.AreEqual("$80.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(3, 4, TableAction.GetText).Message);

                #endregion

                #region Navigate to FileFees, Enter Full Loan Premium amount, Open and Edit PDD
                Reports.TestStep = "Navigate to FileFees, Enter Full Loan Premium amount, Open and Edit PDD";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("2500.00");
                FastDriver.FileFees.lenderAdjAmnt.SendKeys(FAKeys.Tab);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleOwnerPolicyName, 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("100.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("100.00");
                FastDriver.PaymentDetailsDlg.CalculateBuyerSellerCharge(BuyerSellerToolTip);
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                #endregion

                #region Verify Buyer Seller PDD Charge Values on Title Scrow Fee Table
                Reports.TestStep = "Verify Buyer Seller PDD Charge Values on Title Scrow Fee Table";
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyName, 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                SellerCharge = FastDriver.PaymentDetailsDlg.CalculateSellerCharge();
                BuyerCharge = FastDriver.PaymentDetailsDlg.CalculateBuyerCharge();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                Support.AreEqual(BuyerCharge, FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyName, 4, TableAction.GetAttribute, "value").Message);

                Support.AreEqual(SellerCharge, FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyName, 7, TableAction.GetAttribute, "value").Message);

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section B

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section B";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                FastDriver.ClosingDisclosure.ExpandLoanCost();
                Support.AreEqual("$2,500.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(4, 2, TableAction.GetText).Message);

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();

                FastDriver.ClosingDisclosure.ExpandOtherCosts();

                Support.AreEqual("$-1,700.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }                        
        }

        //On the CodedUI script, this tests methods' content hast been replaced with the one from REG_FEE_08 test method        
        [TestMethod]
        [Description("VERIFY THE FULL LOAN PREMIUM, TITLE POLICY ADJUSTMENT FOR A NON FACC FEES")]
        public void REG_FEE_07()
        {
            try
            {
                Reports.TestDescription = "REG_FEE_07 : TO VERIFY THE FULL LOAN PREMIUM, TITLE POLICY ADJUSTMENT FOR A NON FACC FEES";
                #region Variable Declaration
                string FeeDesc_TLP = "New Home Rate ALTA Ext.Loan 1056.06 (2006)-1";//Description Editable
                string FeeDesc_TLP1 = "OneRate Title-110% ALTA Ext.";
                //  string TlpEditChargeDesc = "Updated tlp LoanEstimate descin CD";
                //string LoanEstDesc;
                #endregion
                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";
                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion
                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Loan Policy");
                #endregion
                #region Navigate to Terms/Dates/Status and Add values
                Reports.TestStep = "Navigate to Terms/Dates/Status and Add values";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("500,000.00");
                FastDriver.TermsDatesStatus.LiabilityAmount.SendKeys(FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("500,000.00");
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to New Loan and enter values
                Reports.TestStep = "Navigate to New Loan and enter values";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItemBySendingKeys("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsLoanAmount.SendKeys(FAKeys.Tab);
                FastDriver.NewLoan.LenderPolicyLiability.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion
                #region Navigate to Fee Entry and Verify Form Type is CD
                FastDriver.FileFees.NavigateToFeeEntry();
                Support.AreEqual("true", FastDriver.FileFees.CD.Selected.ToString().ToLower());
                #endregion
                #region Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION
                Reports.TestStep = "Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION";
                FastDriver.FileFees.VerifyFieldsInTCPSection();
                #endregion
                #region Add Fees
                FastDriver.FileFees.AddTitleAndScrowFee("Title - Lenders Policy", FeeDesc_TLP);
                FastDriver.FileFees.AddTitleAndScrowFee("Title - Lenders Policy", FeeDesc_TLP1);
                #endregion
                #region Enter Buyer Charge and Seller Charge
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.EnterAmount(FeeDesc_TLP, true, "100.00", "200.00");
                FastDriver.FileFees.EnterAmount(FeeDesc_TLP1, true, "2000.00", "3000.00");
                #endregion
                #region Verify Loan Estimate Desc
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, FeeDesc_TLP, 3, TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                FastDriver.PaymentDetails.VerifyLoanEstimateDescTitleFeeinPDD("", FeeDesc_TLP);
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                Reports.TestStep = "Clicked On Done Button on Payment Details Dialog";
                #endregion
                #region Set Lender Adjustment Amount
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("500.00");
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion
                #region Navigate to CD screen and Expand Loan Cost
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Select Display Loan Estimate Column Checkbox
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                #endregion
                #region Verify Amounts
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, "Title - " + FeeDesc_TLP, 500.00, null, null, null, null, null, false, null, null);
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, "Title - " + FeeDesc_TLP1, 2000.00, null, null, 3000.00, null, null, false, null, null);
                #endregion
                #region MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE
                Reports.TestStep = "MODIFY LOAN ESTIMATE UNROUNDED AND VERIFY THE CHANGES FOR THE CHARGE";
                string FeeDesc_TLP_cut = "New Home Rate ALTA Ext.Loan 1056.06";
                FastDriver.ClosingDisclosure.LoanEstimateColumn(Section: ClosingDisclosureSection.B,
                    Description: "Title - " + FeeDesc_TLP_cut, Option: "edit", isrounded: true, LEValue: 76543.89M, IsBrokenLink: true);
                #endregion
                #region Verify LE values on Fee Entry
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeDesc_TLP, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                Support.AreEqual("$0.00", FastDriver.PaymentDetails.LEUnrounded.GetAttribute("value"));
                Support.AreEqual("$76,544.00", FastDriver.PaymentDetails.LERounded.GetAttribute("value"));
                FastDriver.PaymentDetails.VerifyBrokenImage();
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.NavigateToFeeEntry();
                Reports.TestStep = "Click On Done Button on Payment Details Dialog";
                #endregion
                #region Enter Amount for New Home Rate ALTA Ext.Loan 1056.06 (2006)-1
                FastDriver.FileFees.EnterAmount(FeeDesc_TLP, true, "0.00", "200.00");
                #endregion
                #region Navigate to CD screen and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Select Display Loan Estimate Column Checkbox
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                #endregion
                #region Verify Amount for New Home Rate ALTA Ext.Loan 1056.06 (2006)-1
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, "Title - " + FeeDesc_TLP, 500.00, null, null, null, null, null, false, null, null);
                #endregion
                #region Enter Amount for New Home Rate ALTA Ext.Loan 1056.06 (2006)-1
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.EnterAmount(FeeDesc_TLP, true, "300.00", "200.00");
                #endregion
                #region Navigate to CD screen and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Select Display Loan Estimate Column Checkbox
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                #endregion
                #region Verify Amount for New Home Rate ALTA Ext.Loan 1056.06 (2006)-1
                FastDriver.ClosingDisclosure.VerifyAmount(1, ClosingDisclosureSection.B, "Title - " + FeeDesc_TLP, 300.00, null, null, 200.00, null, null, false, null, null);
                #endregion
                #region Enter Paid Amounts on PDD
                Reports.TestStep = "Enter Paid Amounts on PDD";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeDesc_TLP, "Det", TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.SwitchToDialogContentFrame();
                FastDriver.PaymentDetails.BuyerAtClosing.FASetText("100");
                FastDriver.PaymentDetails.BuyerBeforeClosing.FASetText("100");
                FastDriver.PaymentDetails.BuyerPaidByOthers.FASetText("100");
                FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItem("POC");
                FastDriver.PaymentDetails.SellerAtClosing.FASetText("100");
                FastDriver.PaymentDetails.SellerBeforeClosing.FASetText("50");
                FastDriver.PaymentDetails.SellerPaidbyOthers.FASetText("50");
                FastDriver.PaymentDetails.SellerPaidbyOthersPayMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                #endregion
                #region Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION
                Reports.TestStep = "Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION";
                FastDriver.FileFees.VerifyFieldsInTCPSection();
                #endregion
                #region ENTER THE LOANESTIMATE UNROUNDED IN TPC SECTION
                Reports.TestStep = "ENTER THE LOANESTIMATE UNROUNDED IN TPC SECTION";
                FastDriver.FileFees.LenderLoanEstimateAmount.FASetText("299.49");
                FastDriver.FileFees.OwnerLoanEstimateAmount.FASetText("");
                FastDriver.FileFees.OwnerLoanEstimateAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual(FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue(), FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue().Replace("$", "").FormatAsMoney(true));
                Support.AreEqual(FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue(), FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue().Replace("$", "").FormatAsMoney(true));
                #endregion
                #region Navigate to CD screen and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Select Display Loan Estimate Column Checkbox
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                #endregion
                #region Verify Amount for New Home Rate ALTA Ext.Loan 1056.06 (2006)-1
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 1, section: ClosingDisclosureSection.B, ChargeDescription: "Title - " + FeeDesc_TLP, 
                    BuyerAtClosing: 100.00, BuyerBeforeClosing: 100.00, BuyerPaidbyOther: 100.00, SellerAtClosing: 100.00, SellerBeforeClosing: 50.00,
                    SellerPaidbyOthers: 150.00, LenderExist: false, LoanEstimteUnroundedAmt: 299.49, LoanEstimateRoundedAmt: 299.00);
                //Modified BuyerPaidByOther amount according to US559013...
                #endregion
                #region Navigate to Fee Entry and Change the Primary Policy Fee
                Reports.TestStep = "Navigate to File Fee, Open Payment Details Dialog and Change the selected Primary Policy";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, FeeDesc_TLP1, 3, TableAction.Click);
                FastDriver.PaymentDetails.WaitForScreenToLoad();
                FastDriver.PaymentDetails.PrimaryPolicy.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();
                #endregion
                #region Enter Full Loan Premium (FLP)
                Reports.TestStep = "Enter Full Loan Premium (FLP)";
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("400.00");
                FastDriver.FileFees.SwitchToBottomFrame();
                FastDriver.FileFees.Done.Click();
                FastDriver.WebDriver.HandleDialogMessage();
                #endregion
                #region Navigate to CD screen and Expand Loan Costs section
                FastDriver.ClosingDisclosure.NavigateToClosingDisclosure();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                #endregion
                #region Select Display Loan Estimate Column Checkbox
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                #endregion
                #region Verify Amount for OneRate Title-110% ALTA Ext.
                FastDriver.ClosingDisclosure.VerifyAmount(2, ClosingDisclosureSection.B, "Title - " + FeeDesc_TLP1, 400.00, null, null, null, null, null, false, null, null);
                #endregion            
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        //On the CodedUI script, this tests methods' content hast been replaced with the one from REG_FEE_09 test method        
        [TestMethod]
        [Description("VERIFY THE DISCLOSED OWNER PREMIUM, OWNER POLICY ADJUSTMENT FOR A NON FACC FEES")]
        public void REG_FEE_08()
        {
            try
            {
                Reports.TestDescription = "REG_FEE_08 : TO VERIFY THE DISCLOSED OWNER PREMIUM, OWNER POLICY ADJUSTMENT FOR A NON FACC FEES";

                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";

                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "CA",  
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Loan Policy");
                #endregion

                #region Navigate to Terms/Dates/Status and Add values
                Reports.TestStep = "Navigate to Terms/Dates/Status and Add values";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("500,000.00");
                FastDriver.TermsDatesStatus.LiabilityAmount.SendKeys(FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("500,000.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to New Loan and enter values
                Reports.TestStep = "Navigate to New Loan and enter values";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItemBySendingKeys("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsLoanAmount.SendKeys(FAKeys.Tab);
                FastDriver.NewLoan.LenderPolicyLiability.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION
                Reports.TestStep = "Navigate to FileFees and VERIFY THE LABELS IN TITLE POLICY CALCULATION SECTION";
                FastDriver.FileFees.VerifyFieldsInTCPSection();
                #endregion

                #region Go to Title Escrow  and Select the Fees
                Reports.TestStep = "Go to Title Escrow Tab and Select the Fees";
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Owners Policy", FeeDescription: "New Home Rate Eagle Owner");
                FastDriver.FileFees.AddTitleAndScrowFee(FeeType: "Title - Owners Policy", FeeDescription: "New Home Rate (Title Only)");
                #endregion

                #region Set Buyer Seller Charge amount for fees
                Reports.TestStep = "Set Buyer Seller Charge amount for fees";
                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "2000.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "3000.00");

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "100.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "200.00");
                FastDriver.BottomFrame.Done();
                #endregion;

                #region Open Payment Details Dialog and Verify Values for New Home Rate (Title Only)

                Reports.TestStep = "Navigate to File Fee, \"New Home Rate (Title Only)\" Open Payment Details Dialog and Verify Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Reports.TestStep = "VERIFY LOANESTIMATE DESCRIPTION IS PREPENDED WITH TITLE FOLLOWED BY FEE DESCRIPTION";
                Support.AreEqual("Title - Owner's Title Insurance (optional)", FastDriver.PaymentDetailsDlg.LEDescription.FAGetValue());

                string LoanEstimateDescTitleOnly = FastDriver.PaymentDetailsDlg.LEDescription.FAGetValue().Trim();

                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                #endregion

                #region Open Payment Details Dialog and Verify Values for New Home Rate Eagle Owner

                Reports.TestStep = "Navigate to File Fee, \"New Home Rate Eagle Owner\" Open Payment Details Dialog and Verify Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Reports.TestStep = "VERIFY LOANESTIMATE DESCRIPTION IS PREPENDED WITH TITLE FOLLOWED BY FEE DESCRIPTION";
                Support.AreEqual("Title - Owner's Title Insurance (optional)", FastDriver.PaymentDetailsDlg.LEDescription.FAGetValue());

                string LoanEstimateDesc = FastDriver.PaymentDetailsDlg.LEDescription.FAGetValue().Trim();

                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                #endregion

                #region Set Lender Adj Amount
                Reports.TestStep = "Set Lender Adj Amount";
                FastDriver.FileFees.lenderAdjAmnt.FASetText("500.00");
                FastDriver.FileFees.lenderAdjAmnt.SendKeys(FAKeys.Tab);
                Support.AreEqual(FastDriver.FileFees.lenderAdjAmnt.FAGetValue(), "500.00".FormatAsMoney(true));
                FastDriver.BottomFrame.Done();
                #endregion

                #region ENTER THE LOANESTIMATE UNROUNDED IN TPC SECTION
                FastDriver.FileFees.WaitForFeeScreen();

                Reports.TestStep = "ENTER THE LOANESTIMATE UNROUNDED IN TPC SECTION";
                FastDriver.FileFees.LenderLoanEstimateAmount.FASetText("123.49");
                FastDriver.FileFees.OwnerLoanEstimateAmount.FASetText("123.50");
                FastDriver.FileFees.OwnerLoanEstimateAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual(FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue(), FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue().Replace("$", "").FormatAsMoney(true));
                Support.AreEqual(FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue(), FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue().Replace("$", "").FormatAsMoney(true));
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H
                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.Other_Costs.Click();
                Support.AreEqual("$2,000.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(3, 2, TableAction.GetText).Message);
                Support.AreEqual("$3,000.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(3, 4, TableAction.GetText).Message);
                #endregion

                #region Edit and verify Loan Estimate Rounded
                Reports.TestStep = "Edit and verify Loan Estimate Rounded";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();
                FastDriver.ClosingDisclosure.Other_Costs.Click();
                Playback.Wait(3000);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Down);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Down);
                FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 8, TableAction.SetText, "");//focus
                FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 8, TableAction.Click);
                int existingTextLength = 3;
                for (int i = 0; i < existingTextLength; i++)
                {
                    FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 8, TableAction.SendKeys, Keys.Backspace);//delete existing text
                }
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();
                FastDriver.ClosingDisclosure.Other_Costs.Click();
                Playback.Wait(3000);
                FastDriver.ClosingDisclosure.LoanEstimateColumn(Section: ClosingDisclosureSection.H, Description: "Title - Owner's Title Insurance (optional)",
                    Option: "edit", isrounded: true, LEValue: 76543.49M, IsBrokenLink: true);
                FastDriver.BottomFrame.Done();

                FastDriver.ClosingDisclosure.WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();
                FastDriver.ClosingDisclosure.Other_Costs.Click();
                Playback.Wait(3000);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Right);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Down);
                FastDriver.ClosingDisclosure.SectionHTable.SendKeys(Keys.Down);
                Support.AreEqual("$76,543.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 8, TableAction.GetText).Message);
                #endregion

                #region Navigate to Files Fee Open PDD and Verify Values
                Reports.TestStep = "Navigate to File Fee, \"New Home Rate Eagle Owner\" Open Payment Details Dialog and Verify Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 3, TableAction.Click);

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Support.AreEqual("$123.50", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$76,543.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FileFees.WaitForFeeScreen();

                #endregion

                #region Edit Buyer Seller Charge amount
                Reports.TestStep = "Edit Buyer Seller Charge amount";

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "0.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "200.00");
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.Other_Costs.FAClick();

                Support.AreEqual("$200.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                #endregion

                #region Edit Buyer Seller Charge amount
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                Reports.TestStep = "Edit Buyer Seller Charge amount";

                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 4, TableAction.SetText, "300.00");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 7, TableAction.SetText, "0.00");
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.Other_Costs.FAClick();

                Support.AreEqual("$300.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);

                #endregion

                #region Navigate to Files Fee Open PDD and Set Values
                Reports.TestStep = "Navigate to File Fee, \"New Home Rate Eagle Owner\" Open Payment Details Dialog and Set Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate Eagle Owner", 3, TableAction.Click);

                FastDriver.PaymentDetails.WaitForScreenToLoad();

                FastDriver.PaymentDetails.BuyerAtClosing.FASetText("100");
                FastDriver.PaymentDetails.SellerAtClosing.FASetText("100");

                FastDriver.PaymentDetails.BuyerBeforeClosing.FASetText("100");
                FastDriver.PaymentDetails.SellerBeforeClosing.FASetText("50");

                FastDriver.PaymentDetails.BuyerPaidByOthers.FASetText("100");
                FastDriver.PaymentDetails.SellerPaidbyOthers.FASetText("50");

                FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetails.SellerPaidbyOthersPayMethod.FASelectItemBySendingKeys("POC");

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.FileFees.WaitForFeeScreen();
                #endregion

                #region ENTER THE LOANESTIMATE UNROUNDED IN TPC SECTION
                Reports.TestStep = "ENTER THE LOANESTIMATE UNROUNDED IN TPC SECTION";
                FastDriver.FileFees.LenderLoanEstimateAmount.FASetText("299.49");
                FastDriver.FileFees.OwnerLoanEstimateAmount.FASetText("299.49");
                FastDriver.FileFees.OwnerLoanEstimateAmount.SendKeys(FAKeys.Tab);
                Support.AreEqual(FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue(), FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue().Replace("$", "").FormatAsMoney(true));
                Support.AreEqual(FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue(), FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue().Replace("$", "").FormatAsMoney(true));
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.Other_Costs.FAClick();

                //Buyer At Closing
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);

                //Buyer Before Closing
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 3, TableAction.GetText).Message);//ARE BEFORE CLOSING VALUES NOT SHOWING AT CD?

                //Seller At Closing
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                //Seller Before Closing
                Support.AreEqual("$50.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 5, TableAction.GetText).Message);//ARE BEFORE CLOSING VALUES NOT SHOWING AT CD?

                //Seller Paid By Others
                //Support.AreEqual("$150.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 6, TableAction.GetText).Message);
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 6, TableAction.GetText).Message);//modified according to TFS559013

                Support.AreEqual("$299.49", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 7, TableAction.GetText).Message);
                Support.AreEqual("$299.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 8, TableAction.GetText).Message);

                #endregion

                #region Navigate to Files Fee Open PDD and Set Values
                Reports.TestStep = "Navigate to File Fee, \"New Home Rate Eagle Owner\" Open Payment Details Dialog and Set Values";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 3, TableAction.Click);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.PrimaryPolicy.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion

                #region Set Lender Adj Amount
                FastDriver.FileFees.WaitForFeeScreen();
                Reports.TestStep = "Set Lender Adj Amount";
                FastDriver.FileFees.lenderAdjAmnt.FASetText("400.00");
                FastDriver.FileFees.lenderAdjAmnt.SendKeys(FAKeys.Tab);
                Support.AreEqual(FastDriver.FileFees.lenderAdjAmnt.FAGetValue(), "400.00".FormatAsMoney(true));
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.Other_Costs.FAClick();

                Support.AreEqual("-$200.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(3, 4, TableAction.GetText).Message);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        //On the CodedUI script, this tests method does not exist. However, its content has been placed on the REG_FEE_08 method....
        [TestMethod]
        [Description("FACC - TO VERIFY THE DOP AND TPA WHEN THE FACC FEE IS RECALCULATED")]
        public void REG_FEE_09()//Review In Progress...
        {
            try
            {
                Reports.TestDescription = "REG_FEE_CD_09 : FACC - TO VERIFY THE DOP AND TPA WHEN THE FACC FEE IS RECALCULATED";
                #region INITIALIZE VARIABLES
                Reports.TestStep = "INITIALIZE VARIABLES";
                var yesterday = DateTime.Now.Date.AddDays(-1).ToString("MM/dd/yyyy");
                string FeeDesc_TLP = "ALTA Extended Loan Policy 1992 (LP-10 Re-issue)";
                string FeeDesc_TOP = "CLTA Standard Coverage 1084 1990";//This fee must be subject to calculation, otherwise it will not appear on the dropdown
                
                #endregion

                #region Login To IIS and Create File
                Reports.TestStep = "Login to IIS and Create File";

                _IISLOGIN();
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.formType = FormType.CD;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE"; //you can replace this value with a valid one
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        //AddrBookEntryID = 8836264, //not sure if this can actually find GAB codes, we are using Addrss  Book Entry ID
                        AddrBookEntryID = AutoConfig.UserName.ToLower() == @"corp\fastqacd" ? 179803738 : 8836264,
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                customizableFileRequest.File.Properties = new Property[] 
                { 
                    new Property() 
                    {
                        PropertyAddress = new PhysicalAddress[] 
                        {
                            new PhysicalAddress() 
                            { 
                                State = "MD",  
                                City = "OLDTOWN", 
                                County = "ALLEGANY",
                                Zip = "94122",
                                Country = "USA" 
                            } 
                        } 
                    } 
                };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                #endregion

                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Loan Policy");
                #endregion

                #region Navigate to Terms/Dates/Status and Add values
                Reports.TestStep = "Navigate to Terms/Dates/Status and Add values";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>("Home>Order Entry>Terms/Dates/Status");
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("500,000.00");
                FastDriver.TermsDatesStatus.LiabilityAmount.SendKeys(FAKeys.Tab);

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("500,000.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to New Loan and enter values
                Reports.TestStep = "Navigate to New Loan and enter values";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsLoantype.FASelectItemBySendingKeys("Small Loan");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsLoanAmount.SendKeys(FAKeys.Tab);
                FastDriver.NewLoan.LenderPolicyLiability.FASetText("100000");
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add File Products
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Owner Policy");
                FastDriver.FileHomepage.AddFileProduct("*ALTA Standard Loan Policy");
                #endregion

                #region Remove Product: ALTA Expanded (Eagle Loan) Policy
                //Necessary for EVAL02 CD Region as of Sept 14, 2015
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").SwitchToContentFrame();
                FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction("Product Name", "*ALTA Expanded (Eagle Loan) Policy", "#1", TableAction.Off);
                FastDriver.BottomFrame.Done();
                #endregion

                #region SELECT TITLE AND ENDORSEMENT FEES
                FastDriver.FileFees.NavigateToFeeEntry();
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.PerformCalculateFees();
                FastDriver.FileFees.SwitchToContentFrame();
                Reports.TestStep = "Select Title Policy";
                FastDriver.CalculateFees.SelectTitlePolicy(Date: yesterday, TitlePolicy: "ALTA Standard Loan Policy", RateType: "Basic");
                FastDriver.CalculateFees.SwitchToContentFrame();
                Reports.TestStep = "Perform Add Product";
                FastDriver.CalculateFees.PerformAddProduct(TitlePolicy: "ALTA Standard Owner Policy", Ratetype: "Basic");
                FastDriver.WebDriver.HandleDialogMessage(); //2nd Loan Liability Amount has been added so this dialog won't pop-up
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.SwitchToContentFrame();
                Reports.TestStep = "Perform Click Next";
                FastDriver.CalculateFees.Next.Click();
                Reports.TestStep = "Perform Select FAST Desc And Charge To";
                FastDriver.CalculateFees.SelectFASTFeeDescAndChargeTo(FeeDesc_TLP: FeeDesc_TLP, FeeDesc_TOP: FeeDesc_TOP, EndorsementDesc: "", LenderChargeTo: "Buyer", OwnerChargeTo: "Seller", EndoChargeTo: "");
                Reports.TestStep = "Perform Click Done";
                FastDriver.CalculateFees.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnDone.Click();
                #endregion

                //this section has been commented out...
                #region Navigate to FileFees and Add Calutated Fees and Test FACC Fee Description
                //Reports.TestStep = "Navigate to FileFees and Add Calutated Fees";
                //FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                //FastDriver.FileFees.TitleRates.FASetCheckbox(true);
                //FastDriver.FileFees.CalculateFees.FAClick();

                //FastDriver.CalculateFees.WaitForScreenToLoad();
                //FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Standard Owner Policy");
                //FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                //FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Standard Loan Policy");
                //FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                //FastDriver.CalculateFees.Next.Click();

                //FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();

                //FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Loan Policy", 4, TableAction.GetCell).Element.FASelectItemBySendingKeys(index: 0, lastFirst: true);
                //FastDriver.FileFeesDlg.WaitScreenToLoad();
                //FastDriver.FileFeesDlg.SearchFeeDesc.FASetText("ALTA Extended Loan Policy 1992 (LP-10 Re-issue)");
                //FastDriver.FileFeesDlg.FindNow.FAClick();
                //FastDriver.FileFeesDlg.FeesTable.PerformTableAction(2, "ALTA Extended Loan Policy 1992 (LP-10 Re-issue)", 1, TableAction.On);

                //FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //FastDriver.CalculateFees.SwitchToContentFrame();
                //FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Loan Policy", 5, TableAction.SelectItem, "Buyer");

                //FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 4, TableAction.GetCell).Element.FASelectItemBySendingKeys(index: 0, lastFirst: true);
                //FastDriver.FileFeesDlg.WaitScreenToLoad();
                //FastDriver.FileFeesDlg.SearchFeeDesc.FASetText("CLTA Standard Coverage 1084 1990");
                //FastDriver.FileFeesDlg.FindNow.FAClick();
                //FastDriver.FileFeesDlg.FeesTable.PerformTableAction(2, "CLTA Standard Coverage 1084 1990", 1, TableAction.On);
                //FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                //FastDriver.CalculateFees.SwitchToContentFrame();
                //FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner's Policy", 5, TableAction.SelectItem, "Seller");

                //FastDriver.BottomFrame.Done();

                #endregion

                #region Verify Split labels and Title Policy Names in TPC Section
                Reports.TestStep = "Verify Split labels and Title Policy Names in TPC Section";

                FastDriver.FileFees.WaitForFeeScreen();
                Support.AreEqual("Seller 100.00%", FastDriver.FileFees.BSSplitSellerPercentage.Text);
                Support.AreEqual("Buyer 0.00%", FastDriver.FileFees.BSSplitBuyerPercentage.Text);

                string TitleLenderPolicyName = FastDriver.FileFees.TitleLenderPolicyName.Text;
                string TitleOwnerPolicyName = FastDriver.FileFees.TitleOwnerPolicyName.Text;

                Support.AreEqual("ALTA Extended Loan Policy 1992 (LP-10 Re-issue)", TitleLenderPolicyName);
                Support.AreEqual("CLTA Standard Coverage 1084 1990", TitleOwnerPolicyName);

                #endregion

                #region Calculate POD and Set BuyerSeller Split
                Reports.TestStep = "Calculate POD and Set BuyerSeller Split";

                string DisclosedOwnerPremium = FastDriver.FileFees.CalculateAndGetPOD(TitleLenderPolicyName, TitleOwnerPolicyName);

                FastDriver.FileFees.CalculateVerifyAndGetTPA(FeeDesc: TitleLenderPolicyName, SplitPercentage: "100.00");
                FastDriver.FileFees.WaitForFeeScreen();

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();
                FastDriver.ClosingDisclosure.LoanCosts.Click();

                //CONTINUE REVIEWING HERE...

                //FastDriver.ClosingDisclosure.Other_Costs.Click();
                //Support.AreEqual("$292.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                //Support.AreEqual("$2,545.00", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 4, TableAction.GetText).Message);
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 1, section: ClosingDisclosureSection.B, ChargeDescription: "Title - ALTA Extended Loan Policy 1992 (LP-10 Re-issue)", 
                    BuyerAtClosing: 2545.00, BuyerBeforeClosing: null, BuyerPaidbyOther: null, SellerAtClosing: null, SellerBeforeClosing: null, SellerPaidbyOthers: null, 
                    LenderExist: false, LoanEstimteUnroundedAmt: null, LoanEstimateRoundedAmt: null, IsBrokenLink: false);
                //verify description, section and amounts
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section B
                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer, Seller Amounts and Descriptions for Section B";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.SelectDisplayLoanEstimate();
                FastDriver.ClosingDisclosure.Other_Costs.Click();
                //FastDriver.ClosingDisclosure.LoanCosts.Click();
                //if B/S Split IS SET FOR SELLER 100% THIS WON'T HAVE A VALUE ON THE BUYER!!
                //Support.AreEqual("$1,878.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 4, TableAction.GetText).Message);
                //Support.AreEqual("$780.00", FastDriver.ClosingDisclosure.ServicesBorrowerDidNotShopForTable.PerformTableAction(2, 2, TableAction.GetText).Message);//seller
                FastDriver.ClosingDisclosure.VerifyAmount(lineNo: 1, section: ClosingDisclosureSection.H, ChargeDescription: "Title - Owner's Title Insurance (optional)", BuyerAtClosing: null,
                    BuyerBeforeClosing: null, BuyerPaidbyOther: null, SellerAtClosing: 780.00, SellerBeforeClosing: null, SellerPaidbyOthers: null, LenderExist: false,
                    LoanEstimteUnroundedAmt: null, LoanEstimateRoundedAmt: null, IsBrokenLink: false);
                //verify description, section and amounts
                #endregion

                #region Navigate to FileFees and Verify Split Dialog
                Reports.TestStep = "Navigate to FileFees and Verify Split Dialog";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                FastDriver.BuyerSellerSplitDlg.VerifyBuyerSellerSplitDialog(FeeDesc: "CLTA Standard Coverage 1084 1990", ApplyPercentageTo: "Seller", SplitPercentage: "100.00", DisclosedOwnerPremium: DisclosedOwnerPremium);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.VerifyFieldsinBuyerSellerSplitDialogwhenFeeisCalculatedfromFACCandSplitbypercentage();
                FastDriver.FileFees.WaitForFeeScreen();
                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.Other_Costs.FAClick();

                Support.AreEqual("$1051.68", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual("$826.32", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);

                #endregion

                #region Navigate to FileFees and Calculate POD
                Reports.TestStep = "Navigate to FileFees and Calculate POD";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                DisclosedOwnerPremium = FastDriver.FileFees.CalculateAndGetPOD(TitleLenderPolicyName, TitleOwnerPolicyName);

                #endregion

                #region Verify Split Dialog
                Reports.TestStep = "Verify Split Dialog";
                FastDriver.FileFees.WaitForFeeScreen();
                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.VerifyFieldsinBuyerSellerSplitDialogwhenFeeisCalculatedfromFACCandSplitbypercentage();
                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                FastDriver.BuyerSellerSplitDlg.VerifyBuyerSellerSplitDialog(FeeDesc: "CLTA Standard Coverage 1084 1990", ApplyPercentageTo: "Seller", SplitPercentage: "44.00", DisclosedOwnerPremium: DisclosedOwnerPremium);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.Other_Costs.FAClick();

                Support.AreEqual("$1939.28", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual("$11523.72", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                #endregion

                #region Navigate to Calculation Fees Summary and Set Split Percentage
                Reports.TestStep = "Navigate to Calculation Fees Summary and Set Split Percentage";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary").WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, "ALTA Owner Policy", 8, TableAction.SetText, "88.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to FileFees and Calculate POD
                Reports.TestStep = "Navigate to FileFees and Calculate POD and Set BuyerSeller Split";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                DisclosedOwnerPremium = FastDriver.FileFees.CalculateAndGetPOD(TitleLenderPolicyName, TitleOwnerPolicyName);

                #endregion

                #region Verify Split Dialog
                Reports.TestStep = "Verify Split Dialog";
                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.VerifyFieldsinBuyerSellerSplitDialogwhenFeeisCalculatedfromFACCandSplitbypercentage();
                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                FastDriver.BuyerSellerSplitDlg.VerifyBuyerSellerSplitDialog(FeeDesc: "CLTA Standard Coverage 1084 1990", ApplyPercentageTo: "Seller", SplitPercentage: "88.00", DisclosedOwnerPremium: DisclosedOwnerPremium);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.Other_Costs.FAClick();

                Support.AreEqual("$415.56", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual("$3,047.44", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                #endregion

                #region Navigate to FileFees and Calculate POD
                Reports.TestStep = "Navigate to FileFees and Calculate POD and Set BuyerSeller Split";
                FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();

                DisclosedOwnerPremium = FastDriver.FileFees.CalculateAndGetPOD(TitleLenderPolicyName, TitleOwnerPolicyName);

                #endregion

                #region Verify Split Dialog
                Reports.TestStep = "Verify Split Dialog";
                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.VerifyFieldsinBuyerSellerSplitDialogwhenFeeisCalculatedfromFACCandSplitbypercentage();
                FastDriver.FileFees.WaitForFeeScreen();

                FastDriver.FileFees.BSSplitButton.FAClick();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                FastDriver.BuyerSellerSplitDlg.VerifyBuyerSellerSplitDialog(FeeDesc: "CLTA Standard Coverage 1084 1990", ApplyPercentageTo: "Seller", SplitPercentage: "88.00", DisclosedOwnerPremium: DisclosedOwnerPremium);
                FastDriver.BottomFrame.Done();

                #endregion

                #region Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H

                Reports.TestStep = "Navigate to CD Expand Loan Cost to Verify Buyer at closing amount for Section H";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.Other_Costs.FAClick();

                Support.AreEqual("$145.20", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 2, TableAction.GetText).Message);
                Support.AreEqual("$1,064.80", FastDriver.ClosingDisclosure.SectionHTable.PerformTableAction(2, 4, TableAction.GetText).Message);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message); 
            }
            

        }

        #region IIS ADM LOGIN METHODS
        public static void _IISLOGIN(string UserName = null, string Password = null) 
        {

            var website = AutoConfig.FASTHomeURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(website, Credentials, true); 
        }
        public void _ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password};
            FASTLogin.Login(WebSite, Credentials, true);

        }
        #endregion

        #region ADD NON FACC RECORDING FEE TAX
        public static void IIS_FileFees_AddNonFACCRecordingFeeTax(string FeeType, string FeeDescription)
        {
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
            FastDriver.FileFees.RecordingandTax.FAClick();
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeesTax, 10);
            FastDriver.FileFees.AddFeesTax.FAClick();
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem(FeeType);
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.FeeSearchFeeDescription.FASetText(FeeDescription);
            FastDriver.FileFees.FindNow.FAClick();
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", FeeDescription, "#1", TableAction.Click);
            FastDriver.BottomFrame.Done();
            FastDriver.BottomFrame.Done();

        }
        #endregion

        #region OPEN PDD FOR THE SELECTED CHARGE AND ENTER DETAILS IN NEW LOAN PDD
        // Fix according to code review 590479
        public static void EnterBuyerandSellerAmountUsingPDD(string ObjID, string Description, double? ByrAtClosing, double? ByrBfrClosing, double? ByrPdOthrs, string ByrPaidByOthrsPymtmthd, double? SellerPaidAtClosing, double? SellerPaidBeforeClosing, double? SellerPaidbyOthers, string SellerPaidbyOtherPaymentMthd, bool display_L_Buyer, bool display_L_Seller, bool LenderAffialite = false, string RemoveLenderAffialite = "NO")
        {
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry");
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.WebDriver.FindElement(By.Id(ObjID)).Click();
            FastDriver.PaymentDetails.WaitForScreenToLoad();
            FastDriver.PaymentDetails.SwitchToDialogContentFrame();
            string Runtime_Description = FastDriver.PaymentDetails.Desc.GetAttribute("value").ToString();
            if(Runtime_Description.Contains(Description))
            {
                if (ByrAtClosing.HasValue)
                {
                    FastDriver.PaymentDetails.BuyerAtClosing.FAClick();
                    FastDriver.PaymentDetails.BuyerAtClosing.FASetText(ByrAtClosing.ToString());
                    //Playback.Wait(1000);
                }
                if (ByrBfrClosing.HasValue)
                {
                    FastDriver.PaymentDetails.BuyerBeforeClosing.FASetText(ByrBfrClosing.ToString());
                    //Playback.Wait(1000);
                }
                if (ByrPdOthrs.HasValue)
                {
                    FastDriver.PaymentDetails.BuyerPaidByOthers.FASetText(ByrPdOthrs.ToString());
                    //Playback.Wait(1000);
                }
                double? TotalBuyerCharge;
                TotalBuyerCharge = ByrAtClosing + ByrBfrClosing + ByrPdOthrs;
                FastDriver.PaymentDetails.BuyerCharge.FAClick();
                //Playback.Wait(1000);
                FastDriver.PaymentDetails.BuyerCharge.FASetText(TotalBuyerCharge.ToString());
                //Playback.Wait(1000);

                if (ByrPaidByOthrsPymtmthd != string.Empty)
                {
                    FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItem(ByrPaidByOthrsPymtmthd);
                }

                if (SellerPaidAtClosing.HasValue)
                {
                    FastDriver.PaymentDetails.SellerAtClosing.FASetText(SellerPaidAtClosing.ToString());
                }

                if (SellerPaidBeforeClosing.HasValue)
                {
                    FastDriver.PaymentDetails.SellerBeforeClosing.FASetText(SellerPaidBeforeClosing.ToString());
                }
                if (SellerPaidbyOthers.HasValue)
                {
                    FastDriver.PaymentDetails.SellerPaidbyOthers.FASetText(SellerPaidbyOthers.ToString());
                }
                if (SellerPaidbyOtherPaymentMthd != string.Empty)
                {
                    FastDriver.PaymentDetails.SellerPaidbyOthersPayMethod.FASelectItemBySendingKeys(SellerPaidbyOtherPaymentMthd.ToString());
                }

                if (display_L_Buyer == true)
                {
                    //Playback.Wait(1000);
                    if(FastDriver.PaymentDetails.BuyerDisplayL.Selected.Equals("True"))
                    {
                        FastDriver.PaymentDetails.BuyerDisplayL.FASetCheckbox(display_L_Buyer);
                        //Playback.Wait(1000);
                    }
                }

                /* Remove/uncheck the "Display (L) on CD" check box _Start*/
                if (display_L_Buyer == false)
                {
                    //Playback.Wait(1000);
                    if(FastDriver.PaymentDetails.BuyerDisplayL.Selected.Equals("True"))
                    {
                        FastDriver.PaymentDetails.BuyerDisplayL.FASetCheckbox(display_L_Buyer);
                        //Playback.Wait(1000);
                    }
                }
                /* Remove/uncheck the "Display (L) on CD" check box  _End*/

                if (display_L_Seller == true)
                {
                    //Playback.Wait(1000);
                    if(FastDriver.PaymentDetails.SellerDisplayL.Enabled.ToString().Equals("True"))
                    {
                        FastDriver.PaymentDetails.SellerDisplayL.FASetCheckbox(display_L_Seller);
                        //Playback.Wait(1000);
                    }
                }

                if (LenderAffialite == true)
                {
                    //Playback.Wait(1000);
                    if(FastDriver.PaymentDetails.LenderAffiliate.Enabled.ToString().Equals("True"))
                    {
                        FastDriver.PaymentDetails.LenderAffiliate.FASetCheckbox(LenderAffialite);
                        //Playback.Wait(1000);
                    }
            
                }

                if (RemoveLenderAffialite.Equals("YES"))
                {
                    //Playback.Wait(1000);
                    if(FastDriver.PaymentDetails.LenderAffiliate.Enabled.ToString().Equals("True"))
                    {
                        FastDriver.PaymentDetails.LenderAffiliate.FASetCheckbox(LenderAffialite);
                        //Playback.Wait(2000);
                    }
                }
                double? TotalSellerCharge;
                TotalSellerCharge = SellerPaidAtClosing + SellerPaidBeforeClosing + SellerPaidbyOthers;
                FastDriver.PaymentDetails.SellerCharge.FASetText(TotalSellerCharge.ToString());
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
            }
            else
            {
                Reports.StatusUpdate("Wrong PDD has been Opened", false);
            }
                
        }
        #endregion
                
        
        //#region PROVIDE THE DATA ON FEE ENTRY SCREEN
        //public void ProvideTheDataOnFeeEntryScreen(string Charge_Desc, string ColumnName, string SetValue, string Action = "SET")
        //{
        //    FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
        //    FastDriver.FileFees.SwitchToContentFrame();
        //    FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
        //    FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", Charge_Desc, ColumnName, TableAction.SetText, SetValue);
        //    FastDriver.BottomFrame.Done();
        //    FastDriver.FileFees.SwitchToContentFrame();

        //}
        //#endregion

        #region GET PAYEE NAME
        public static void GetPayeeName(string Section, string ChargeDescription){
            
            try
            {
                switch (Section.ToLower())
                {
                    case "sectiona":
                        //TableSubSection = FastDriver.ClosingDisclosure.TableLoanCostSectionA;
                        //PayeeName = FastDriver.FileFees.det;
                        break;
                    case "sectionb":
                        //TableSubSection = FastDriver.ClosingDisclosure.TableLoanCostSectionB;
                        break;
                    case "sectionc":
                        //TableSubSection = FastDriver.ClosingDisclosure.TableLoanCostSectionC;
                        break;
                    case "sectiond":
                        //TableSubSection = FastDriver.ClosingDisclosure.TableLoanCostSectionD;
                        break;
                }
            }
            catch(Exception e)
            {
                Reports.UpdateDebugLog(e.Message + " for " + ChargeDescription, "", "", "", "", "", Reports.Result(false), e.Message);
                Reports.TestResult = false;
            }
        }
        
        #endregion

        #region SET VALUES ON PDD FOR FEE
        //public void SetValuesOnPDDForFee(PDDObject Obj, string FeeDesc, string TabledId)
        //{
        //    FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
        //    FastDriver.FileFees.SwitchToContentFrame();
        //    FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable, 10);
        //    //CLICK ON THE RESPECTIVE PDD
        //    FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeDesc, "Det", TableAction.Click);
        //    FastDriver.PaymentDetails.WaitForScreenToLoad();
        //    FastDriver.PaymentDetails.SwitchToDialogContentFrame();
        //    FastDriver.PaymentDetails.BuyerCharge.FAClick();
        //    //string FeeDesc = string.Empty;"tFF_tF1_gT_gT"
        //    //HtmlTable FeeEntryTable = new HtmlTable(objBrowser);
        //    //FeeEntryTable.SearchProperties.Add(HtmlTable.PropertyNames.Id, TabledId);
        //    //HtmlCell FeeEntryCell = new HtmlCell(FeeEntryTable);
        //    //FeeEntryCell.SearchProperties.Add(HtmlCell.PropertyNames.ColumnIndex, "1");
        //    //FeeEntryCell.SearchProperties.Add(HtmlCell.PropertyNames.InnerText, FeeDesc);
        //    //HtmlInputButton FeeEntryButton = (HtmlInputButton)FeeEntryCell.GetParent().GetChildren()[2].GetChildren()[0].GetChildren()[0];
        //    //Mouse.Click(FeeEntryButton);
        //    //Fee_SetUp_Object.SetParent("IIS.Fee_PaymentDetailsDlg", "PaymentDetailsDlg");
        //    //PayeeName = Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "PayeeName").Get("Text").ToString();

        //    //if (Obj.Additional_Description != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "AdditionalDesc").Set("Text", Obj.Additional_Description);
        //    //}
        //    //if (Obj.LoanEstimate_UnRounded != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "LoanEstiUnrounded").Set("Text", Obj.LoanEstimate_UnRounded);
        //    //}
        //    //if (Obj.LoanEstimate_Rounded != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "LoanEstiRounded").Set("Text", Obj.LoanEstimate_Rounded);
        //    //}
        //    //if (Obj.Buyer_Charge != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "BuyerCharge").Set("Text", Obj.Buyer_Charge);
        //    //}
        //    //if (Obj.Buyer_AtClosing != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "Paid_By_Buyer_Atclosing").Set("Text", Obj.Buyer_AtClosing);
        //    //}
        //    //if (Obj.Buyer_BeforeClosing != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "Paid_By_Buyer_Beforeclosing").Set("Text", Obj.Buyer_BeforeClosing);
        //    //}
        //    //if (Obj.Buyer_PaidByOthers != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "Paid_By_Buyer_By_Others").Set("Text", Obj.Buyer_PaidByOthers);
        //    //}
        //    //if (Obj.Buyer_PaymentMethod != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "Buyer_PaidByOtherDropDown").Set("SelectedItem", Obj.Buyer_PaymentMethod);
        //    //}
        //    //if (Obj.DoubleAsteriskIndicator)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "DoubleEstrikIndicator").Set("Checked", "True");
        //    //}
        //    //else
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "DoubleEstrikIndicator").Set("Checked", "False");
        //    //}
        //    //if (Obj.Seller_Charge != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "SellerCharge").Set("Text", Obj.Seller_Charge);
        //    //}
        //    //if (Obj.Seller_AtClosing != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "Paid_By_Seller_At_Closing").Set("Text", Obj.Seller_AtClosing);
        //    //}
        //    //if (Obj.Seller_BeforeClosing != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "Paid_By_Seller_Before_Closing").Set("Text", Obj.Seller_BeforeClosing);
        //    //}
        //    //if (Obj.Seller_PaidByOthers != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "Paid_By_Seller_Other").Set("Text", Obj.Seller_PaidByOthers);
        //    //}
        //    //if (Obj.Seller_PaymentMethod != string.Empty)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "Seller_PaidByOtherDropDown").Set("SelectedItem", Obj.Seller_PaymentMethod);
        //    //}
        //    //if (Obj.Section_Value != string.Empty)
        //    //{
        //    //    if (Obj.Section_Value == "B")
        //    //    {
        //    //        Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "SectionBDidNotShopFor").Set("Selected", "True");
        //    //        if (Obj.LenderAffliate_Status)
        //    //        {
        //    //            Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "LenderAff").Set("Checked", "True");
        //    //        }
        //    //        else
        //    //        {
        //    //            Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "LenderAff").Set("Checked", "False");
        //    //        }
        //    //    }
        //    //    else if (Obj.Section_Value == "C")
        //    //    {
        //    //        Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "SectionCDidShopFor").Set("Selected", "True");
        //    //    }
        //    //    else if (Obj.Section_Value == "H")
        //    //    {
        //    //        Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "SectionHOtherCosts").Set("Selected", "True");
        //    //    }
        //    //}
        //    //if (Obj.PartOfChcekBox == true)
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "PartOf").Set("Checked", "True");
        //    //}
        //    //else
        //    //{
        //    //    Fee_SetUp_Object.GetControl("IIS.Fee_PaymentDetailsDlg", "PartOf").Set("Checked", "False");
        //    //}
        //    //Keyboard.SendKeys("^D");


        //}

        #endregion
        
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }


    }
}
