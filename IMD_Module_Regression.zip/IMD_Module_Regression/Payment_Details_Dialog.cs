﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.Reflection;
using SeleniumInternalHelpers;
using FASTWCFHelpers.FastFileService;
using System.ComponentModel;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.IE;
using AutoIt;

namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class Payment_Details_Dialog : MasterTestClass
    {
        private int TableChargesColumnCount = 7;
        public Payment_Details_Dialog()
        {
        }

        #region TestCases

        [TestMethod]
        public void Assumption_Loan_Payment_Details_Dialog()
        {
            try
            {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For Assumption Loan";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();
                string detailsGABCode = "HUDASLNDR1";
                Reports.TestStep = "Create AssumptionLoan First Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText(detailsGABCode);
                FastDriver.AssumptionLoanDetails.DetailsFind.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.AssumptionLoanDetails.GABcodeLabel.Text, detailsGABCode);

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer Credit Amount on  AssumptionLoan  Screen";

                SetBuyerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "4.99");

                Reports.TestStep = "Enter Buyer Credit Amount on  AssumptionLoan  Screen";
                SetSellerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "5.99");

                Reports.TestStep = "Enter Buyer Credit Amount on  AssumptionLoan  Screen";
                SetLoanEstimate(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  AssumptionLoan  Screen";
                SetSellerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "6.99");
                SetBuyerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "7.99");
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee");

                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$4.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$4.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  AssumptionLoan  Screen";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer credit charges";
                Support.AreEqual("$4.99", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify seller credit charges";
                Support.AreEqual("$5.99", FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Statement/Forwarding Fee".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("ASSUMPTION LENDER 1 FOR HUD TEST NAME 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("ASSUMPTION LENDER 1 FOR HUD TEST NAME 1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$4.00", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("POC POC-L", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify credits Payment Method for Buyer and Innertext.";

                Support.AreEqual("At Closing", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("At Closing No Check POC", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Text.Trim());
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify credits Payment Method for seller and Innertext.";
                Support.AreEqual("At Closing", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("At Closing No Check POC", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Text.Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Displayed.ToString());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.DisplayLSeller.Displayed.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  AssumptionLoan  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer Credit Amount on  AssumptionLoan  Screen";
                SetBuyerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "4.99");

                Reports.TestStep = "Enter Buyer Credit Amount on  AssumptionLoan  Screen";
                SetSellerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "5.99");

                Reports.TestStep = "Enter Buyer Credit Amount on  AssumptionLoan  Screen";
                SetLoanEstimate(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  AssumptionLoan  Screen";
                SetBuyerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "1");
                SetSellerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "7.99");
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee");
                SetBuyerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee", "6.99");

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.SendKeys(FAKeys.Tab);
                 
                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$4.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$4.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  AssumptionLoan  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  AssumptionLoan  Screen";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Verify Display (L) on CD CheckBox enabled property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Enabled.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString());

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  AssumptionLoan Screen.";
                Support.AreEqual(@"1,000.00", GetBuyerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  AssumptionLoan Screen.";
                Support.AreEqual(@"2,000.00", GetSellerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Loan Estimate Amount on  AssumptionLoan Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on AssumptionLoan Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  AssumptionLoan Screen and verify that the edited values are saved.";

                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox enabled property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Enabled.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString());

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                Support.AreEqual("$1,000.00", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  AssumptionLoan  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  AssumptionLoan Screen.";
                Support.AreEqual(@"1,000.00", GetBuyerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  AssumptionLoan Screen.";
                Support.AreEqual(@"2,000.00", GetSellerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Loan Estimate Amount on  AssumptionLoan Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on AssumptionLoan Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Assumption_Loan_Error_Warning()
        {
            try {
                Reports.TestDescription = "Verify the Error Warning Conditions for  AssumptionLoan screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan");
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText(detailsGABCode);
                FastDriver.AssumptionLoanDetails.DetailsFind.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData
                Reports.TestStep = "Navigate to  AssumptionLoan Screen and Open Payment Details Dialog.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited"),"4,000.00");

                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  AssumptionLoan Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                 FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", SwitchToWindow:true);
               // Support.AreEqual(@, FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited"),"5,000.00");

                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  AssumptionLoan Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Support.AreEqual("5,000.00", FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FAGetValue().Trim());
                Support.AreEqual("6,000.00", FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FAGetValue().Trim());

                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  AssumptionLoan Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method is required for Paid By Others amount.");
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  AssumptionLoan  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                Reports.TestStep = "Click on Charges Tab on  AssumptionLoan Screen.";
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  AssumptionLoan Screen.";
                Support.AreEqual(GetBuyerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim(), "1,000.00");

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  AssumptionLoan Screen.";
                Support.AreEqual(GetSellerCredit(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim(), "2,000.00");

                Reports.TestStep = "Verify Loan Estimate Amount on  AssumptionLoan Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on AssumptionLoan Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  AssumptionLoan Screen.";
                SetBuyerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited","9,000.00");
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  AssumptionLoan Screen.";
                SetSellerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited", "10,000.00");
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  AssumptionLoan Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  AssumptionLoan Screen and verify the error.";

                ClearDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Assumption_Loan_Disbursement()
        {
            try {
                Reports.TestDescription = "Disburse the charges for  AssumptionLoan  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText(detailsGABCode);
                FastDriver.AssumptionLoanDetails.DetailsFind.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "Statement/Forwarding Fee");

                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement(true);

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();

                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);
                Reports.TestStep = "Navigate toAssumption Loan Screen.";

                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();

                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();

                if (FastDriver.AssumptionLoanDetails.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.AssumptionLoanDetails.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.AssumptionLoanDetails.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
            
                Reports.TestStep = "Click Delete on Assumption Loan Charges.";
                FastDriver.BottomFrame.Delete();

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.AssumptionLoanCharges.CheqImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanCharges.CheqImage.Displayed.ToString());

                ClickDescription(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FAGetValue(), "7,000.00");
                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FAGetValue(), "6,000.00");

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.AssumptionLoanCharges.CheqAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.AssumptionLoanCharges.CheqAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.AssumptionLoanCharges.CheqImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.AssumptionLoanCharges.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Outside_Title_Company_Payment_Details_Dialog()
        {
            try
            {

                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For OTC";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();
                Reports.TestStep = "Enter Gab Code and Click on Find.";
                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.OTCDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.OTCDetail.SwitchToContentFrame();
                Support.AreEqual(FastDriver.OTCDetail.GABcodeLabel.Text, detailsGABCode);

                Reports.TestStep = "Enter Buyer Credit Amount on OTC Screen";
                SetLoanEstimate(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on OTC Screen";
                SetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination", "6.99");
                SetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination", "7.99");
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination");

                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on OTC Screen";
                FastDriver.OTCDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination");

                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Title - Title Examination".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("ASSUMPTION LENDER 1 FOR HUD TEST NAME 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("ASSUMPTION LENDER 1 FOR HUD TEST NAME 1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify amount for Buyer Seller will be disable.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.BuyerCredit.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.SellerCredit.Enabled.ToString());

                //Reports.CaptureImage();

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to OTC and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer Credit Amount on OTC Screen";
                FastDriver.OTCDetail.SwitchToContentFrame();
                
                SetLoanEstimate(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on OTC Screen";
                SetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination", "6.99");
                SetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination", "7.99");
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination");

                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on OTC and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();

                FastDriver.OTCDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on OTC Screen";
                FastDriver.OTCDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                //Reports.CaptureImage();

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OTCDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify if Credits exists and disable the amount will be Null on OTC Screen.";
                Support.AreEqual(string.Empty, GetBuyerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("0.00", GetSellerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Loan Estimate Amount on OTC Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on OTC Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify if Credits exists and disable the amount will be Null on OTCScreen.";
                FastDriver.OTCDetail.SwitchToContentFrame();
                Support.AreEqual(string.Empty, GetBuyerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("0.00", GetSellerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.OTCDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";
                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to OTC and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();

                FastDriver.OTCDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on OTC Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on OTC Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify if Credits exists and disable the amount will be Null on OTC Screen.";
                Support.AreEqual(string.Empty, GetBuyerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("0.00", GetSellerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        [TestMethod]
        public void Outside_Title_Company_Error_Warning()
        {
            try
            {
                Reports.TestDescription = "Verify the Error Warning Conditions for OTC screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();
                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company");
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.OTCDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.OTCDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.OTCDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();

                FastDriver.OTCDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on OTC Screen.";
                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.OTCDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.OTCDetail.SwitchToContentFrame();
                SetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited", "4,000.00");

                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on OTC Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.OTCDetail.SwitchToContentFrame();
                SetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited", "5,000.00");


                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on OTC Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();
                ///Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.OTCDetail.SwitchToContentFrame();
                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify if Credits exists and disable the amount will be Null on OTC Screen.";
                Support.AreEqual(string.Empty, GetBuyerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("0.00", GetSellerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim());

                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on OTC Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");
                //Reports.CaptureImage();

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OTCDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to OTC and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OTCDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on OTCS creen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on OTC Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Verify if Credits exists and disable the amount will be Null on OTC Screen.";
                Support.AreEqual(GetBuyerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim(), string.Empty);
                Support.AreEqual(GetSellerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim(), "0.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on OTC Screen.";
                SetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited","10,000.00");
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.OTCDetail.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on OTC Screen.";
                SetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited","10,000.00");
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed OTC Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Verify if Credits exists and disable the amount will be Null on OTC Screen.";
                Support.AreEqual(GetBuyerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim(), string.Empty);
                FastDriver.OTCDetail.OTCTitleServicesSellerCredit.SendKeys(FAKeys.Tab);
                Support.AreEqual(GetSellerCredit(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited").Trim(), "0.00");

                Reports.TestStep = "Delete the charge description on OTC Screen and verify the error.";
                ClearDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.OTCDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();

                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:9,000.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
            
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Outside_Title_Company_Disbursement()
        {
            try {
                Reports.TestDescription = "Disburse the charges for  OTC  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.OTCDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.OTCDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.OTCDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "Title - Title Examination");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OTCDetail.SwitchToContentFrame();

                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);
                FastDriver.LeftNavigation.Navigate<OTCDetail>(@"Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
                FastDriver.OTCDetail.SwitchToContentFrame();

                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.BottomFrame.Delete();

                //A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.OTCDetail.SwitchToContentFrame();

                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.OTCDetail.CheqImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));
            
                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.OTCDetail.CheqImage.Displayed.ToString());

                ClickDescription(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OTCDetail.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.OTCDetail.TitleServicesTable, "ChargeDescriptionEdited"), "6,000.00");

                FastDriver.OTCDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.OTCDetail.NetCheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.OTCDetail.NetCheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.OTCDetail.CheqImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));
            
                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.OTCDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Property_Tax_Check_Loan_Payment_Details_Dialog()
        {
            try {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For PROPERTYTAXCHECK";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                Reports.TestStep = "Create Assumption Loan First Instance";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.GABcode.FASetText(detailsGABCode);
                FastDriver.PropertyTaxCheck.Find.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.PropertyTaxCheck.GABcodeLabel.Text, detailsGABCode);

                Reports.TestStep = "Enter Buyer Credit Amount on  PROPERTYTAXCHECK  Screen";

                SetBuyerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due","4.99");

                Reports.TestStep = "Enter Seller Credit Amount on  PROPERTYTAXCHECK  Screen";
                SetSellerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", "5.99");

                Reports.TestStep = "Enter Loan Estiamte Amount on  PROPERTYTAXCHECK  Screen";
                SetLoanEstimate(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  PROPERTYTAXCHECK  Screen";
                SetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", "6.99");
                SetBuyerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due", "7.99");

                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due");

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$4.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$4.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PROPERTYTAXCHECK  Screen";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer credit charges";
                Support.AreEqual("$4.99", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify seller credit charges";
                Support.AreEqual("$5.99", FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Tax Installment: Interest Due".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1".ToUpper(), FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1".ToUpper(), PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$4.00", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify credits Payment Method for Buyer and Innertext.";
                Support.AreEqual("At Closing", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("At Closing No Check POC", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Text.Trim());
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Enabled.ToString());
                //Reports.CaptureImage();

                Reports.TestStep = "Verify credits Payment Method for seller and Innertext.";
                Support.AreEqual("At Closing", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("At Closing No Check POC", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Text.Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Enabled.ToString());
                //Reports.CaptureImage();

                //Reports.CaptureImage();

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  PROPERTYTAXCHECK  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Enter Seller Credit Amount on  PROPERTYTAXCHECK  Screen";
                SetBuyerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due","4.99");

                Reports.TestStep = "Enter Buyer Credit Amount on  PROPERTYTAXCHECK  Screen";
                SetSellerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due","5.99");

                Reports.TestStep = "Enter Loan Estimate Amount on  PROPERTYTAXCHECK  Screen";
                SetLoanEstimate(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  PROPERTYTAXCHECK  Screen";
                SetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due","6.99");
                SetBuyerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due","7.99");
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due");

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$4.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$4.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestDescription = "Edit the Value on Payment details dialog and verify on  PROPERTYTAXCHECK  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  PROPERTYTAXCHECK  Screen";
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due");

                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                //Reports.CaptureImage();

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");
                //Reports.CaptureImage();

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  PROPERTYTAXCHECK Screen.";

                Support.AreEqual(@"1,000.00", GetBuyerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  PROPERTYTAXCHECK Screen.";
                Support.AreEqual(@"2,000.00", GetSellerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Loan Estimate Amount on  PROPERTYTAXCHECK Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on PROPERTYTAXCHECK Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PROPERTYTAXCHECK Screen and verify that the edited values are saved.";

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                Support.AreEqual("$1,000.00", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Trim());

                //Reports.CaptureImage();

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem().Trim());

                //Reports.CaptureImage();

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  PROPERTYTAXCHECK  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  PROPERTYTAXCHECK Screen.";
                Support.AreEqual(@"1,000.00", GetBuyerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  PROPERTYTAXCHECK Screen.";
                Support.AreEqual(@"2,000.00", GetSellerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Loan Estimate Amount on  PROPERTYTAXCHECK Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on PROPERTYTAXCHECK Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Property_Tax_Check_Loan_Error_Warning()
        {
            try
            {
                Reports.TestDescription = "Verify the Error Warning Conditions for  PROPERTYTAXCHECK screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check");
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.GABcode.FASetText(detailsGABCode);
                FastDriver.PropertyTaxCheck.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                ///"Charge Description is required."
                Reports.TestStep = "Open Payment Details Dialog on  PROPERTYTAXCHECK Screen.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_2.FASetText("4,000.00");

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PROPERTYTAXCHECK Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                ///Total of Seller Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Seller Charge Amount?

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                SetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited", "5,000.00");

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PROPERTYTAXCHECK Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                ///Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PROPERTYTAXCHECK Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                //Payment Method is required for Paid By Others amount.
                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                //Buyer and/or Seller Charge cannot be negative.

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                //Buyer Broker for Paid By Other Buyer
                Reports.TestStep = "Open Payment Details Dialog on  PROPERTYTAXCHECK to verify Broker error warnings.";
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                //Payment Method is required for Paid By Others amount.
                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                //Seller Broker for Paid By Other Buyer
                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                //Buyer Broker for Paid By Other Seller
                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                //Seller Broker for Paid By Other Seller
                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                //Support.AreEqual(@"Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to  PROPERTYTAXCHECK  and Verify the data on source screen";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  PROPERTYTAXCHECK Screen.";
                Support.AreEqual(GetBuyerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim(), "1,000.00");

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  PROPERTYTAXCHECK Screen.";
                Support.AreEqual(GetSellerCredit(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim(), "2,000.00");

                Reports.TestStep = "Verify Loan Estimate Amount on  PROPERTYTAXCHECK Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on PROPERTYTAXCHECK Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  PROPERTYTAXCHECK Screen.";
                SetBuyerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited", "9,000.00");
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                //Charge has Multiple Paid By Methods. Seller
                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  PROPERTYTAXCHECK Screen.";
                SetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited", "10,000.00");

                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  PROPERTYTAXCHECK Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                // To generate code for this test, select "Generate Code for Coded UI Test" from the shortcut menu and select one of the menu items.

                Reports.TestStep = "Delete the charge description on  PROPERTYTAXCHECK Screen and verify the error.";

                ClearDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited"); FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                //Payment Method is required for Paid By Others amount.
                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Property_Tax_Check_Loan_Disbursement()
        {

            try {

                Reports.TestDescription = "Disburse the charges for  PROPERTYTAXCHECK  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.GABcode.FASetText(detailsGABCode);
                FastDriver.PropertyTaxCheck.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "Tax Installment: Interest Due");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement(true);

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.BottomFrame.Delete();

                //A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.PropertyTaxCheck.CheckIssuedImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxCheck.CheckIssuedImage.Displayed.ToString());

                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited"), "6,000.00");

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.PropertyTaxCheck.CheckIssuedImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxCheck.CheckIssuedImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                //Broker IF Content
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");

                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();

                ClickDescription(FastDriver.PropertyTaxCheck.PropertyTaxesTable, "ChargeDescriptionEdited");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                if (FastDriver.PropertyTaxCheck.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.PropertyTaxCheck.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";

                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.PropertyTaxCheck.CheckIssuedImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.PropertyTaxCheck.CheckIssuedImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Payoff_Loan_Payment_Details_Dialog()
        {
            try {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For Payoffloan";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                Reports.TestStep = "Create Assumption Loan First Instance";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";

                FastDriver.PayoffLoanDetails.SwitchToContentFrame();

                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(detailsGABCode);
                FastDriver.PayoffLoanDetails.LenderFind.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.PayoffLoanDetails.GABcodeLabel.Text, detailsGABCode);

                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                        
                Reports.TestStep = "Enter Buyer Credit Amount on  Payoffloan  Screen";
                SetBuyerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee","4.99");

                Reports.TestStep = "Enter Seller Credit Amount on  Payoffloan  Screen";
                SetSellerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee","5.99");

                Reports.TestStep = "Enter Loan Estimate Amount on  Payoffloan  Screen";
                SetLoanEstimate(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  Payoffloan  Screen";
                SetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee","6.99");
                SetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee","7.99");
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee");
            
                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$4.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$4.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  Payoffloan  Screen";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer credit charges";
                Support.AreEqual("$4.99", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify seller credit charges";
                Support.AreEqual("$5.99", FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Statement/Forwarding Fee".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1".ToUpper(), FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1".ToUpper(), PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$4.00", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("POC POC-L", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify credits Payment Method for Buyer and Innertext.";
                Support.AreEqual("At Closing", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("At Closing No Check POC", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Text.Trim());
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify credits Payment Method for seller and Innertext.";
                Support.AreEqual("At Closing", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("At Closing No Check POC", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Text.Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Enabled.ToString());
          
                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Displayed.ToString());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.DisplayLSeller.Displayed.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  Payoffloan  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Payoff Loan");

                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Enter Buyer Credit Amount on  Payoffloan  Screen";
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee");
                SetBuyerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", "4.99");

                Reports.TestStep = "Enter Seller Credit Amount on  Payoffloan  Screen";
                SetSellerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", "5.99");

                Reports.TestStep = "Enter Loan Estimate Amount on  Payoffloan  Screen";
                SetLoanEstimate(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  Payoffloan  Screen";
                SetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", "6.99");
                SetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", "1.00");
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee");
                SetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee", "7.99");

                FastDriver.PayoffLoanCharges.PaymentDetails.SendKeys(FAKeys.Tab);

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$4.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$4.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  Payoffloan  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  Payoffloan  Screen";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");
             
                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                //Reports.CaptureImage();

                Reports.TestStep = "Verify Display (L) on CD CheckBox enabled property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Enabled.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString());

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");
                //Reports.CaptureImage();

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  Payoffloan Screen.";
                Support.AreEqual(@"1,000.00", GetBuyerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  Payoffloan Screen.";
                Support.AreEqual(@"2,000.00", GetSellerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Loan Estimate Amount on  Payoffloan Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on Payoffloan Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  Payoffloan Screen and verify that the edited values are saved.";
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox enabled property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Enabled.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString());
                //Reports.CaptureImage();

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                Support.AreEqual("$1,000.00", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Trim());

                //Reports.CaptureImage();

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem().Trim());

                //Reports.CaptureImage();

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  Payoffloan  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  Payoffloan Screen.";
                Support.AreEqual(@"1,000.00", GetBuyerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  Payoffloan Screen.";
                Support.AreEqual(@"2,000.00", GetSellerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify Loan Estimate Amount on  Payoffloan Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on Payoffloan Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Payoff_Loan_Error_Warning()
        {

            try {
                Reports.TestDescription = "Verify the Error Warning Conditions for  Payoffloan screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan");
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(detailsGABCode);
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();

                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();

                FastDriver.PayoffLoanDetails.SwitchToContentFrame();

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  Payoffloan Screen.";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                SetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited","4,000.00");

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  Payoffloan Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                ///Total of Seller Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Seller Charge Amount?
                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");
            
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                SetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited","5,000.00");

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  Payoffloan Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                ///Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  Payoffloan Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                //Payment Method is required for Paid By Others amount.
                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method is required for Paid By Others amount.");
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  Payoffloan  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();

                Reports.TestStep = "Click on Charges Tab on  Payoffloan Screen.";
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  Payoffloan Screen.";
                Support.AreEqual(GetBuyerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim(), "1,000.00");

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  Payoffloan Screen.";
                Support.AreEqual(GetSellerCredit(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim(), "2,000.00");

                Reports.TestStep = "Verify Loan Estimate Amount on  Payoffloan Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on Payoffloan Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  Payoffloan Screen.";
                SetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited", "9,000.00");
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                //Charge has Multiple Paid By Methods. Seller
                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  Payoffloan Screen.";
                SetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited","10,000.00");

                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  Payoffloan Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                // To generate code for this test, select "Generate Code for Coded UI Test" from the shortcut menu and select one of the menu items.

                Reports.TestStep = "Delete the charge description on  Payoffloan Screen and verify the error.";

                ClearDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                //Payment Method is required for Paid By Others amount.
                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Payoff_Loan_Disbursement()
        {
            try {
                Reports.TestDescription = "Disburse the charges for  Payoffloan  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.LenderGABcode.FASetText(detailsGABCode);
                FastDriver.PayoffLoanDetails.LenderFind.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();

                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "Statement/Forwarding Fee");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement(true);

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");

                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("POC");

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>(@"Home>Order Entry>Payoff Loan").WaitForScreenToLoad();
                FastDriver.PayoffLoanDetails.SwitchToContentFrame();
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.BottomFrame.Delete();

                //A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.PayoffLoanCharges.CheqImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));
           
                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.PayoffLoanCharges.CheqImage.Displayed.ToString());

                ClickDescription(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited");
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, "ChargeDescriptionEdited"), "6,000.00");

                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.PayoffLoanCharges.CheckAmt.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.PayoffLoanCharges.CheckAmt.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.PayoffLoanCharges.CheqImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));
           
                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.PayoffLoanCharges.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Outside_Escrow_Company_Payment_Details_Dialog()
        {

            try
            {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For OEC";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();
                string detailsGABCode = "OUTESCROW";
                Reports.TestStep = "Create OEC First Instance";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.OutsideEscrowCompanyDetail.Find.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.Text, detailsGABCode);

                SetDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "", "OTC - Charge_Descrption"+FAKeys.Tab);
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption");

                Reports.TestStep = "Enter Loan Estimate Amount on OEC Screen";
                SetLoanEstimate(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption","8.99");
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on OEC Screen";
                SetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption","6.99");
                SetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption","7.99");
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption");
            
                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on OEC Screen";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("OTC - Charge_Descrption".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";
                Support.AreEqual("NAME 1 FOR OUTSIDE ESCROW COMPANY", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("NAME 1 FOR OUTSIDE ESCROW COMPANY", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  OEC and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Outside Escrow Company");
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Enter Loan Estimate Amount on OEC Screen";
                SetLoanEstimate(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on OEC Screen";
                SetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption", "6.99");
                SetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption", "7.99");
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption");
            

                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on OEC and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on OEC Screen";
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                //Reports.CaptureImage();

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on OEC Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on OEC Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim());

                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";
                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());
                //Reports.CaptureImage();

                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to OEC and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on OEC Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on OEC Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim());

                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }
        [TestMethod]
        public void Outside_Escrow_Company_Error_Warning()
        {
            try
            {
                Reports.TestDescription = "Verify the Error Warning Conditions for  OEC screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();
                string detailsGABCode = "OUTESCROW";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company");
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.OutsideEscrowCompanyDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                SetDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "", "OTC - Charge_Descrption" + FAKeys.Tab);
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption");


                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  OEC Screen.";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited"); 
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                SetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited", "4,000.00");

                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  OEC Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                SetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited", "5,000.00");

                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  OEC Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim());

                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  OEC Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");
                //Reports.CaptureImage();

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  OEC  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  OEC Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on OEC Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  OEC Screen.";
                SetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited", "9,000.00");
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");
                
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  OEC Screen.";
                SetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited", "10,000.00");

                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  OEC Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  OEC Screen and verify the error.";
                ClearDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");

                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Outside_Escrow_Company_Disbursement()
        {
            try
            {
                Reports.TestDescription = "Disburse the charges for  OEC  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();
                string detailsGABCode = "OUTESCROW";
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.OutsideEscrowCompanyDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                SetDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "", "OTC - Charge_Descrption" + FAKeys.Tab);
                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "OTC - Charge_Descrption");

                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company").WaitForScreenToLoad();
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.BottomFrame.Delete();
                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";

                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.OutsideEscrowCompanyDetail.CheqImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.OutsideEscrowCompanyDetail.CheqImage.Displayed.ToString());

                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                Support.AreEqual(GetBuyerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges, "ChargeDescriptionEdited"), "6,000.00");
                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.OutsideEscrowCompanyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.OutsideEscrowCompanyDetail.CheqImage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.OutsideEscrowCompanyDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());
            }
            catch (Exception e)
            {
                Support.Fail(e.Message);
            }

        }
        [TestMethod]
        public void Home_Owner_Association_Loan_Payment_Details_Dialog()
        {
            try
            {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For HOA";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();
                string detailsGABCode = "HOA1";
                Reports.TestStep = "Create HOA First Instance";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText(detailsGABCode);
                FastDriver.HomeownerAssociation.Find.Click();

                Reports.TestStep = "Click on Done in Assumption Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.HomeownerAssociation.IDCodeText.Text, detailsGABCode);

                Reports.TestStep = "Enter Loan Estimate Amount on  HOA  Screen";
                //This Screen's table has less fields so the LoanEstimate column index changes
                SetTableChargesColumnCount(FastDriver.HomeownerAssociation.AssociationChargesTable);
                SetLoanEstimate(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  HOA  Screen";
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "6.99");
                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee","7.99");
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee");
            
                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  HOA  Screen";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Transfer Fee".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";
                Support.AreEqual("Homeowner Assn name 1".ToUpper(), FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("Homeowner Assn name 1".ToUpper(), PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  HOA  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association");

                Reports.TestStep = "Enter Loan Estimate Amount on  HOA  Screen";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                SetLoanEstimate(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  HOA  Screen";
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "6.99");
                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", "7.99");
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee");

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  HOA  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  HOA  Screen";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                //Reports.CaptureImage();

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  HOA Screen.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on HOA Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";
                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  HOA  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  HOA Screen.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on HOA Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception e)
            {
                Support.Fail(e.Message);
            }
        }
        [TestMethod]
        public void Home_Owner_Association_Loan_Error_Warning()
        {
            try
            {
                Reports.TestDescription = "Verify the Error Warning Conditions for  HOA screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();
                string detailsGABCode = "HOA1";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association");
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText(detailsGABCode);
                FastDriver.HomeownerAssociation.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                //This Screen's table has less fields so the LoanEstimate column index changes
                SetTableChargesColumnCount(FastDriver.HomeownerAssociation.AssociationChargesTable);
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee");

                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  HOA Screen.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.SurveyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited", "4,000.00");

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  HOA Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited", "5,000.00");

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  HOA Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  HOA Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");
                //Reports.CaptureImage();

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  HOA to verify Broker error warnings.";
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");
                //problema aki
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  HOA  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  HOA Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on HOA Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  HOA Screen.";
                SetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited","9,000.00");
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  HOA Screen.";
                SetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited","10,000.00");

                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  HOA Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  HOA Screen and verify the error.";
                ClearDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");

                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Home_Owner_Association_Loan_Disbursement()
        {
            try
            {
                Reports.TestDescription = "Disburse the charges for  HOA  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();
                string detailsGABCode = "HOA1";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.HomeownerAssociation.GABcode.FASetText(detailsGABCode);
                FastDriver.HomeownerAssociation.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                //This Screen's table has less fields so the LoanEstimate column index changes
                SetTableChargesColumnCount(FastDriver.HomeownerAssociation.AssociationChargesTable);
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");

                Reports.TestStep = "Click on Delete on HomeOwnerAssociation.";
                FastDriver.BottomFrame.Delete();
                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.HomeownerAssociation.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.CheckImage.Displayed.ToString());
                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                Support.AreEqual(GetBuyerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited"), "6,000.00");
                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.HomeownerAssociation.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.CheckImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                //IF broker Content
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");

                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();

                FastDriver.HomeownerAssociation.SwitchToContentFrame();

                ClickDescription(FastDriver.HomeownerAssociation.AssociationChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.SwitchToContentFrame();
                if (FastDriver.HomeownerAssociation.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.HomeownerAssociation.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";

                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.HomeownerAssociation.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.HomeownerAssociation.CheckImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }

        }
        [TestMethod]
        public void Home_Warranty_Payment_Details_Dialog()
        {
            try
            {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For HOMEWARRANTY";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();
                string detailsGABCode = "HW1";
                Reports.TestStep = "Create Assumption Loan First Instance";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.HomeWarrantyDetail.Find.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.HomeWarrantyDetail.IDCodeText.Text, detailsGABCode);

                Reports.TestStep = "Enter Loan Estimate Amount on  HOMEWARRANTY  Screen";
                SetTableChargesColumnCount(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable);
                SetLoanEstimate(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  HOMEWARRANTY  Screen";
                SetSellerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty","6.99");
                SetBuyerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty","7.99");
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty");

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  HOMEWARRANTY  Screen";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Home Warranty".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";
                Support.AreEqual("HW NAME 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("HW NAME 1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());
                //Reports.CaptureImage();

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  HOMEWARRANTY  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty");
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Enter Loan Estimate Amount on  HOMEWARRANTY  Screen";
                SetLoanEstimate(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  HOMEWARRANTY  Screen";
                SetSellerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", "6.99");
                SetBuyerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", "7.99");
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty");

                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty");
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  HOMEWARRANTY  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  HOMEWARRANTY  Screen";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);
                //Reports.CaptureImage();

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  HOMEWARRANTY Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim());
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on HOMEWARRANTY Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  HOMEWARRANTY Screen and verify that the edited values are saved.";

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  HOMEWARRANTY  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  HOMEWARRANTY Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on HOMEWARRANTY Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim());

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FAGetValue().Trim());

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Home_Warranty_Error_Warning()
        {
            try
            {
                Reports.TestDescription = "Verify the Error Warning Conditions for  HOMEWARRANTY screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();
                string detailsGABCode = "HW1";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty");
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.HomeWarrantyDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable);
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  HOMEWARRANTY Screen.";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                Support.AreEqual(GetBuyerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited"), "4,000.00");

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  HOMEWARRANTY Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                Support.AreEqual(GetSellerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited"),"5,000.00");

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  HOMEWARRANTY Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  HOMEWARRANTY Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");
                //Reports.CaptureImage();

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  HOMEWARRANTY to verify Broker error warnings.";
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith(@"Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FAClick();
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  HOMEWARRANTY  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty");
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  HOMEWARRANTY Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on HOMEWARRANTY Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  HOMEWARRANTY Screen.";
                SetBuyerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited", "9,000.00");
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");

                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  HOMEWARRANTY Screen.";
                SetSellerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited", "10,000.00");
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  HOMEWARRANTY Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  HOMEWARRANTY Screen and verify the error.";
                ClearDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");

                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Home_Warranty_Disbursement()
        {
            try
            {
                Reports.TestDescription = "Disburse the charges for  HOMEWARRANTY  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();
                string detailsGABCode = "HW1";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                FastDriver.HomeWarrantyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.HomeWarrantyDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable);
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.BottomFrame.Delete();

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.HomeWarrantyDetail.CheqImage.Displayed.ToString());
                

                Reports.TestStep = "Increase the amount and Verify Error message.";
                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Support.AreEqual(FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FAGetValue(), "7,000.00");
                Support.AreEqual(FastDriver.HomeWarrantyDetail.HomeWarrantySellerCharge.FAGetValue(), "6,000.00");

                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.HomeWarrantyDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                //IF broker Content
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();

                ClickDescription(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "ChargeDescriptionEdited");
                FastDriver.HomeWarrantyDetail.PaymentDetailsHomeWarrantyCharges.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer's Broker net commission check is issued.  The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total.  Please verify that the appropriate Trust Accounting entries have been made.  (I.e. should the issued check be cancelled?)  Additionally, these changes may result in the File being out-of-balance.  Do you wish to save the changes?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Seller's Broker net commission check is issued.  The effect of your changes may result in a check amount that is LESS than the charge total and an out-of-balance condition between the issued check and the charge total.  Please verify that the appropriate Trust Accounting entries have been made.  (I.e. should the issued check be cancelled?)  Additionally, these changes may result in the File being out-of-balance.  Do you wish to save the changes?");

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
                FastDriver.HomeWarrantyDetail.SwitchToContentFrame();
                if (FastDriver.HomeWarrantyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.HomeWarrantyDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.HomeWarrantyDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Lease_Payment_Details_Dialog()
        {
            try
            {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For LEASE";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();
                string detailsGABCode = "LEASE";
                Reports.TestStep = "Create Assumption Loan First Instance";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.LeaseDetail.Find.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();
                FastDriver.LeaseDetail.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.LeaseDetail.IDCodeLebel.Text, detailsGABCode);
                
                Reports.TestStep = "Enter Loan Estimate Amount on  LEASE  Screen";
                SetTableChargesColumnCount(FastDriver.LeaseDetail.LeaseChargesTable);
                SetLoanEstimate(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  LEASE  Screen";
                SetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due","6.99");
                SetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due","7.99");
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due");
                
                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                
                Reports.TestStep = "Open Payment Details Dialog on  LEASE  Screen";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Rent/Lease Payment Due".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("LEASE NAME 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("LEASE NAME 1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  LEASE  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Lease");

                Reports.TestStep = "Enter Loan Estimate Amount on  LEASE  Screen";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                SetLoanEstimate(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  LEASE  Screen";
                SetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due","6.99");
                SetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due","7.99");
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due");
                
                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestDescription = "Edit the Value on Payment details dialog and verify on  LEASE  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  LEASE  Screen";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  LEASE Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on LEASE Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  LEASE  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  LEASE Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on LEASE Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00",GetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim());

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.LeaseDetail.ChargeDescription.FAGetValue().Trim());

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Lease_Error_Warning()
        {
            try
            {
                Reports.TestDescription = "Verify the Error Warning Conditions for  LEASE screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();
                string detailsGABCode = "LEASE";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease");
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.LeaseDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.LeaseDetail.LeaseChargesTable);
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  LEASE Screen.";
                FastDriver.LeaseDetail.SwitchToContentFrame();

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.LeaseDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                Support.AreEqual(GetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited"),"4,000.00");

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  LEASE Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.LeaseDetail.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited"), "5,000.00");

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  LEASE Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.LeaseDetail.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  LEASE Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                //Reports.CaptureImage();

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.LeaseDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  LEASE to verify Broker error warnings.";
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeaseDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();
                Reports.TestStep = "Navigate to  LEASE  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  LEASE Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on LEASE Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  LEASE Screen.";
                SetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited","9,000.00");
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.LeaseDetail.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  LEASE Screen.";
                SetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited","10,000.00");
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.LeaseDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  LEASE Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  LEASE Screen and verify the error.";

                ClearDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.LeaseDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Lease_Disbursement()
        {
            try
            {
                Reports.TestDescription = "Disburse the charges for  LEASE  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();
                string detailsGABCode = "LEASE";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.SwitchToContentFrame();
                FastDriver.LeaseDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.LeaseDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.LeaseDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.LeaseDetail.LeaseChargesTable);
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();

                FastDriver.LeaseDetail.SwitchToContentFrame();

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.BottomFrame.Delete();

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.LeaseDetail.SwitchToContentFrame();

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.LeaseDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.LeaseDetail.CheqImage.Displayed.ToString());
                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeaseDetail.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited"), "6,000.00");

                FastDriver.LeaseDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";

                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.LeaseDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.LeaseDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                //IF broker Content
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                ClickDescription(FastDriver.LeaseDetail.LeaseChargesTable, "ChargeDescriptionEdited");
                FastDriver.LeaseDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<LeaseDetail>(@"Home>Order Entry>Escrow Charge Processes>Lease").WaitForScreenToLoad();
                FastDriver.LeaseDetail.SwitchToContentFrame();

                if (FastDriver.LeaseDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.LeaseDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.LeaseDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.LeaseDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Survey_Payment_Details_Dialog()
        {
            try
            {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For SURVEY";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();
                string detailsGABCode = "SURVEY";
                Reports.TestStep = "Create Assumption Loan First Instance";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";

                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.SurveyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.SurveyDetail.Find.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.SurveyDetail.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.SurveyDetail.IDcodeLabel.Text, detailsGABCode);

                Reports.TestStep = "Enter Loan Estimate Amount on  SURVEY  Screen";
                SetTableChargesColumnCount(FastDriver.SurveyDetail.SurveyChargesTable);
                SetLoanEstimate(FastDriver.SurveyDetail.SurveyChargesTable, "Survey","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  SURVEY  Screen";
                SetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "Survey","6.99");
                SetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "Survey","7.99");
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "Survey");
              
                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  SURVEY  Screen";
                FastDriver.SurveyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "Survey");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Survey".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("SURVEY NAME 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("SURVEY NAME 1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  SURVEY  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Survey");
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Enter Loan Estimate Amount on  SURVEY  Screen";
                SetTableChargesColumnCount(FastDriver.SurveyDetail.SurveyChargesTable);
                SetLoanEstimate(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  SURVEY  Screen";
                SetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", "6.99");
                SetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "Survey", "7.99");
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "Survey");

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  SURVEY  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  SURVEY  Screen";
                FastDriver.SurveyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "Survey");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  SURVEY Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on SURVEY Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.SurveyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  SURVEY  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  SURVEY Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on SURVEY Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }

        }
        [TestMethod]
        public void Survey_Error_Warning()
        {

           try
           {
                Reports.TestDescription = "Verify the Error Warning Conditions for  SURVEY screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();
                string detailsGABCode = "SURVEY";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey");
                FastDriver.SurveyDetail.SwitchToContentFrame();
                FastDriver.SurveyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.SurveyDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.SurveyDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.SurveyDetail.SurveyChargesTable);
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "Survey");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  SURVEY Screen.";
                FastDriver.SurveyDetail.SwitchToContentFrame();

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.SurveyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited"), "4,000.00");
                FastDriver.SurveyDetail.BorrowerSelectedServicesBuyerCharge.FASetText("4,000.00");

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  SURVEY Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited"), "5,000.00");

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  SURVEY Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  SURVEY Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  SURVEY to verify Broker error warnings.";
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.SurveyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  SURVEY  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  SURVEY Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on SURVEY Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  SURVEY Screen.";
                SetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited","9,000.00");
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  SURVEY Screen.";
                SetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited","10,000.00");
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  SURVEY Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  SURVEY Screen and verify the error.";
                ClearDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.SurveyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Survey_Disbursement()
        {
            try
            {
                Reports.TestDescription = "Disburse the charges for  SURVEY  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();
                string detailsGABCode = "SURVEY";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.SwitchToContentFrame();
                FastDriver.SurveyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.SurveyDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.SurveyDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.SurveyDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.SurveyDetail.SurveyChargesTable);
                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "Survey");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.SurveyDetail.SwitchToContentFrame();

                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();

                FastDriver.SurveyDetail.SwitchToContentFrame();

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.BottomFrame.Delete();

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.SurveyDetail.SwitchToContentFrame();

                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.SurveyDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.SurveyDetail.CheqImage.Displayed.ToString());

                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SurveyDetail.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited"), "6,000.00");

                FastDriver.SurveyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.SurveyDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.SurveyDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                //IF broker Content
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.SwitchToContentFrame();

                ClickDescription(FastDriver.SurveyDetail.SurveyChargesTable, "ChargeDescriptionEdited");
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<SurveyDetail>(@"Home>Order Entry>Escrow Charge Processes>Survey").WaitForScreenToLoad();
                FastDriver.SurveyDetail.SwitchToContentFrame();
                
                if (FastDriver.SurveyDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.SurveyDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.SurveyDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.SurveyDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Utility_Payment_Details_Dialog()
        {
            try { 
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For UTILITY";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();

                string detailsGABCode = "UTILITY";
                Reports.TestStep = "Create UtilityDetail Instance";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";

                FastDriver.UtilityDetail.SwitchToContentFrame();

                FastDriver.UtilityDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.UtilityDetail.Find.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.UtilityDetail.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.UtilityDetail.GabCodeLabel.Text, detailsGABCode);

                Reports.TestStep = "Enter Loan Estimate Amount on  UTILITY  Screen";
                SetTableChargesColumnCount(FastDriver.UtilityDetail.UtilityChargesTable);
                SetLoanEstimate(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  UTILITY  Screen";
                SetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities","6.99");
                SetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities","7.99");
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities");
            
                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  UTILITY  Screen";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Utilities".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("UTILITY NAME 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("UTILITY NAME 1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  UTILITY  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "Enter Loan Estimate Amount on  UTILITY  Screen";
                SetLoanEstimate(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  UTILITY  Screen";
                SetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities", "6.99");
                SetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities", "7.99");
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities");

                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  UTILITY  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.SwitchToContentFrame();
            
                Reports.TestStep = "Open Payment Details Dialog on  UTILITY  Screen";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  UTILITY Screen.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on UTILITY Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  UTILITY  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  UTILITY Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on UTILITY Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Utility_Error_Warning()
        {
            try {
                Reports.TestDescription = "Verify the Error Warning Conditions for  UTILITY screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "UTILITY";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.UtilityDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.UtilityDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.UtilityDetail.UtilityChargesTable);
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();

                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  UTILITY Screen.";
                FastDriver.UtilityDetail.SwitchToContentFrame();

                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.UtilityDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.UtilityDetail.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited"), "4,000.00");
            
                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  UTILITY Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.UtilityDetail.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited"), "5,000.00");

                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  UTILITY Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.UtilityDetail.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  UTILITY Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  UTILITY to verify Broker error warnings.";
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith(@"Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.UtilityDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  UTILITY  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();

                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  UTILITY Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on UTILITY Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  UTILITY Screen.";
                SetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited", "9,000.00");
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  UTILITY Screen.";
                SetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited", "10,000.00");
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
            
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  UTILITY Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  UTILITY Screen and verify the error.";

                ClearDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.UtilityDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();

                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void Utility_Disbursement()
        {
            try {
                Reports.TestDescription = "Disburse the charges for  UTILITY  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();

                string detailsGABCode = "UTILITY";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.SwitchToContentFrame();
                FastDriver.UtilityDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.UtilityDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.UtilityDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.UtilityDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.UtilityDetail.UtilityChargesTable);
                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "Utilities");

                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();

                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();

                FastDriver.UtilityDetail.SwitchToContentFrame();

                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on Delete on Utility Screen.";
                FastDriver.BottomFrame.Delete();

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.UtilityDetail.SwitchToContentFrame();

                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";

                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.UtilityDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.UtilityDetail.CheqImage.Displayed.ToString());

                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.UtilityDetail.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited"), "6,000.00");

                FastDriver.UtilityDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.UtilityDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.UtilityDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.SwitchToContentFrame();

                ClickDescription(FastDriver.UtilityDetail.UtilityChargesTable, "ChargeDescriptionEdited");
                FastDriver.UtilityDetail.UtilityChargesPaymentDetails.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?",FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.SwitchToContentFrame();
                if (FastDriver.UtilityDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.UtilityDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.UtilityDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.UtilityDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }        

        }
        [TestMethod]
        public void Attorney_Seller_Payment_Details_Dialog()
        {
            try {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For ATTORNEYSELLER";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();

                string detailsGABCode = "HUDATASTL1";
                Reports.TestStep = "Create ATTORNEYSELLER First Instance";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.AttorneyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.AttorneyDetail.Find.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.AttorneyDetail.GABcodeLabel.Text, detailsGABCode);

                Reports.TestStep = "Enter Loan Estimate amount on  ATTORNEYSELLER  Screen";
                SetTableChargesColumnCount(FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                SetLoanEstimate(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  ATTORNEYSELLER  Screen";
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee","6.99");
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee","7.99");
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee");
          
                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  ATTORNEYSELLER  Screen";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Attorney Fee".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("ATTORNEY AS TITLE 1 FOR HUD TEST NAME 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("ATTORNEY AS TITLE 1 FOR HUD TEST NAME 1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  ATTORNEYSELLER  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Attorney - Seller");

                Reports.TestStep = "Enter Loan Estimate amount on  ATTORNEYSELLER  Screen";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                SetLoanEstimate(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  ATTORNEYSELLER  Screen";
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "6.99");
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee", "7.99");
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee");

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  ATTORNEYSELLER  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  ATTORNEYSELLER  Screen";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  ATTORNEYSELLER Screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on ATTORNEYSELLER Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  ATTORNEYSELLER Screen and verify that the edited values are saved.";

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  ATTORNEYSELLER  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  ATTORNEYSELLER Screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on ATTORNEYSELLER Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }  
        }
        [TestMethod]
        public void Attorney_Seller_Error_Warning()
        {
            try {
                Reports.TestDescription = "Verify the Error Warning Conditions for  ATTORNEYSELLER screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller");
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.AttorneyDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                SetTableChargesColumnCount(FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee");
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  ATTORNEYSELLER Screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited"), "4,000.00");

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  ATTORNEYSELLER Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited"), "5,000.00");
                FastDriver.AttorneyDetail.SellerCharge.FASetText("5,000.00");

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  ATTORNEYSELLER Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  ATTORNEYSELLER Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  ATTORNEYSELLER to verify Broker error warnings.";
                FastDriver.AttorneyDetail.ChargeDescription.FAClick();
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith(@"Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  ATTORNEYSELLER  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  ATTORNEYSELLER Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on ATTORNEYSELLER Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  ATTORNEYSELLER Screen.";
                SetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited","9,000.00");
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
            
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  ATTORNEYSELLER Screen.";
                SetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited","10,000.00");
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
            
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  ATTORNEYSELLER Screen.";
                Support.AreEqual(FastDriver.AttorneyDetail.BuyerCharge.FAGetValue().Trim(), "5,000.00");
                Support.AreEqual(FastDriver.AttorneyDetail.SellerCharge.FAGetValue().Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  ATTORNEYSELLER Screen and verify the error.";
                ClearDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.AttorneyDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }  
        }
        [TestMethod]
        public void Attorney_Seller_Disbursement()
        {
            try {
                Reports.TestDescription = "Disburse the charges for  ATTORNEYSELLER  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();

                string detailsGABCode = "HUDATASTL1";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                FastDriver.AttorneyDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.AttorneyDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.AttorneyDetail.SellerAttorneyChargesTable);
                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "Attorney Fee");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();

                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.BottomFrame.Delete();

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";

                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.AttorneyDetail.Issuedcheckimage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.AttorneyDetail.Issuedcheckimage.Displayed.ToString());

                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited"), "6,000.00");

                FastDriver.AttorneyDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.AttorneyDetail.Issuedcheckimage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.AttorneyDetail.Issuedcheckimage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                //IF broker Content
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.SwitchToContentFrame();

                ClickDescription(FastDriver.AttorneyDetail.SellerAttorneyChargesTable, "ChargeDescriptionEdited");
                FastDriver.AttorneyDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<AttorneyDetail>(@"Home>Order Entry>Attorney - Seller").WaitForScreenToLoad();
                FastDriver.AttorneyDetail.SwitchToContentFrame();
                if (FastDriver.AttorneyDetail.NetcheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.AttorneyDetail.NetcheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.AttorneyDetail.Issuedcheckimage.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.AttorneyDetail.Issuedcheckimage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }  
        }
        [TestMethod]
        public void Miscellaneous_Disbursement_Payment_Details_Dialog()
        {
            try {
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For MISCDISB";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();

                string detailsGABCode = "MISCDISB";
                Reports.TestStep = "Create Assumption Loan First Instance";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                FastDriver.MiscDisbursementDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.MiscDisbursementDetail.Find.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.MiscDisbursementDetail.IDCode.Text, detailsGABCode);

                SetDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable,"", "Miscellaneous Disbursement"+FAKeys.Tab);
            
                Reports.TestStep = "Enter Loan Estimate Amount on  MISCDISB  Screen";
                SetLoanEstimate(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  MISCDISB  Screen";
                SetSellerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement","6.99");
                SetBuyerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement","7.99");
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement");
          
                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  MISCDISB  Screen";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Miscellaneous Disbursement".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("MISC NAME1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("MISC NAME1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  MISCDISB  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
            
                Reports.TestStep = "Enter Loan Estimate Amount on  MISCDISB  Screen";
                SetLoanEstimate(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  MISCDISB  Screen";
                SetSellerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement", "6.99");
                SetBuyerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement", "7.99");
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement");
          
                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  MISCDISB  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  MISCDISB  Screen";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  MISCDISB Screen.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on MISCDISB Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  MISCDISB  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  MISCDISB Screen.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on MISCDISB Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge (FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim());
            
                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }  
        }
        [TestMethod]
        public void Miscellaneous_Disbursement_Error_Warning()
        {
            try {
                Reports.TestDescription = "Verify the Error Warning Conditions for  MISCDISB screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "MISCDISB";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.MiscDisbursementDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                SetDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "", "Miscellaneous Disbursement" + FAKeys.Tab);
          
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  MISCDISB Screen.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited"), "4,000.00");

                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  MISCDISB Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited"), "5,000.00");

                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  MISCDISB Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  MISCDISB Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  MISCDISB to verify Broker error warnings.";
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith(@"Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  MISCDISB  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  MISCDISB Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on MISCDISB Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  MISCDISB Screen.";
                SetBuyerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited", "9,000.00");
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");

                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  MISCDISB Screen.";
                SetSellerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited","10,000.00");
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
            
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  MISCDISB Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  MISCDISB Screen and verify the error.";
                ClearDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");           
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Miscellaneous_Disbursement_Disbursement()
        {
            try {
                Reports.TestDescription = "Disburse the charges for  MISCDISB  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();

                string detailsGABCode = "MISCDISB";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                FastDriver.MiscDisbursementDetail.GABcode.FASetText(detailsGABCode);
                FastDriver.MiscDisbursementDetail.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                SetDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "", "Miscellaneous Disbursement" + FAKeys.Tab);
            
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "Miscellaneous Disbursement");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on delete on Misc Disbursement Screen.";
                FastDriver.BottomFrame.Delete();

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";

                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.MiscDisbursementDetail.CheqImage.Displayed.ToString());

                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Support.AreEqual(FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue(), "7,000.00");
                Support.AreEqual(FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue(), "6,000.00");

                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.MiscDisbursementDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();

                ClickDescription(FastDriver.MiscDisbursementDetail.MiscChargesTable, "ChargeDescriptionEdited");
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.SwitchToContentFrame();
                if (FastDriver.MiscDisbursementDetail.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.MiscDisbursementDetail.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.MiscDisbursementDetail.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                //Reports.CaptureImage();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Inspection_Repair_Pest_Payment_Details_Dialog()
        {
            try { 
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For PEST";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();

                string detailsGABCode = "PESTINSPEC";
                Reports.TestStep = "Create Assumption Loan First Instance";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";

                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                FastDriver.InspectionRepairPest.GABcode.FASetText(detailsGABCode);
                FastDriver.InspectionRepairPest.Find.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.InspectionRepairPest.LabelIDCode.Text, detailsGABCode);

                Reports.TestStep = "Enter Loan Estimate Amount on  PEST  Screen";
                SetTableChargesColumnCount(FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                SetLoanEstimate(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  PEST  Screen";
                SetSellerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection", "6.99");
                SetBuyerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection", "7.99");
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection");
            
                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PEST  Screen";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Pest Inspection".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("PEST NAME 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("PEST NAME 1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  PEST  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest");

                Reports.TestStep = "Enter Loan Estimate Amount on  PEST  Screen";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection");
                SetLoanEstimate(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  PEST  Screen";
                SetSellerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection", "6.99");
                SetBuyerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection", "7.99");
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection");

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  PEST  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  PEST  Screen";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  PEST Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on PEST Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PEST Screen and verify that the edited values are saved.";

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  PEST  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  PEST Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on PEST Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Inspection_Repair_Pest_Error_Warning()
        {

            try { 
                Reports.TestDescription = "Verify the Error Warning Conditions for  PEST screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "PESTINSPEC";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest");
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                FastDriver.InspectionRepairPest.GABcode.FASetText(detailsGABCode);
                FastDriver.InspectionRepairPest.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  PEST Screen.";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited"), "4,000.00");

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PEST Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited"), "5,000.00");

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PEST Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  PEST Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  PEST to verify Broker error warnings.";
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith(@"Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  PEST  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  PEST Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on PEST Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  PEST Screen.";
                SetBuyerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited","9,000.00");
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
            
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  PEST Screen.";
                SetSellerCharge(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited","10,000.00");
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");

                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  PEST Screen.";
                Support.AreEqual(FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue().Trim(), "5,000.00");
                Support.AreEqual(FastDriver.InspectionRepairPest.SellerCharge.FAGetValue().Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  PEST Screen and verify the error.";
                ClearDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
           
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Inspection_Repair_Pest_Disbursement()
        {
            try { 
                Reports.TestDescription = "Disburse the charges for  PEST  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();

                string detailsGABCode = "PESTINSPEC";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                FastDriver.InspectionRepairPest.GABcode.FASetText(detailsGABCode);
                FastDriver.InspectionRepairPest.Find.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.InspectionRepairPest.InspectionRepairChargesTable);
                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "Pest Inspection");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on Delete button on Inspection Repair Pest Screen.";
                FastDriver.BottomFrame.Delete();

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.InspectionRepairPest.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.InspectionRepairPest.CheqImage.Displayed.ToString());

                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Support.AreEqual(FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue(), "7,000.00");
                Support.AreEqual(FastDriver.InspectionRepairPest.SellerCharge.FAGetValue(), "6,000.00");

                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.InspectionRepairPest.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.InspectionRepairPest.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.SwitchToContentFrame();

                ClickDescription(FastDriver.InspectionRepairPest.InspectionRepairChargesTable, "ChargeDescriptionEdited");
                FastDriver.InspectionRepairPest.PaymentDetails.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<InspectionRepairPest>(@"Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.SwitchToContentFrame();
                if (FastDriver.InspectionRepairPest.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.InspectionRepairPest.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.InspectionRepairPest.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.InspectionRepairPest.CheqImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Insurance_Other_Payment_Details_Dialog()
        {
            try { 
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For INSURANCE";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                Reports.TestStep = "Create INSURANCE First Instance";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();

                FastDriver.InsuranceOther.SwitchToContentFrame();

                FastDriver.InsuranceOther.OtherGABcode.FASetText(detailsGABCode);
                FastDriver.InsuranceOther.OtherFind.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.InsuranceOther.GabCodeLabel.Text, detailsGABCode);

                Reports.TestStep = "Enter Loan Estimate Amount on  INSURANCE  Screen";
                SetTableChargesColumnCount(FastDriver.InsuranceOther.InsuranceChargesTable);
                SetLoanEstimate(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  INSURANCE  Screen";
                SetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium","6.99");
                SetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium","7.99");
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium");
  
                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  INSURANCE  Screen";
                FastDriver.InsuranceOther.SwitchToContentFrame();
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Insurance Premium".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("ASSUMPTION LENDER 1 FOR HUD TEST NAME 1", FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("ASSUMPTION LENDER 1 FOR HUD TEST NAME 1", PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("Buyer Broker POC Seller Broker", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  INSURANCE  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Enter Loan Estimate Amount on  INSURANCE  Screen";
                SetTableChargesColumnCount(FastDriver.InsuranceOther.InsuranceChargesTable);
                SetLoanEstimate(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  INSURANCE  Screen";
                SetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", "6.99");
                SetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium", "7.99");
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium");

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$14.98", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$14.98", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  INSURANCE  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  INSURANCE  Screen";
                FastDriver.InsuranceOther.SwitchToContentFrame();
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  INSURANCE Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on INSURANCE Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.InsuranceOther.SwitchToContentFrame();
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  INSURANCE  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  INSURANCE Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on INSURANCE Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Insurance_Other_Error_Warning()
        {
            try { 
                Reports.TestDescription = "Verify the Error Warning Conditions for  INSURANCE screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<InsuranceOther>(@"Home>Order Entry>Escrow Charge Processes>Insurance");

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();
                FastDriver.InsuranceOther.OtherGABcode.FASetText(detailsGABCode);
                FastDriver.InsuranceOther.OtherFind.Click();

                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.InsuranceOther.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.InsuranceOther.InsuranceChargesTable);
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Verify Check amount and Open Payment Details Dialog on  INSURANCE Screen.";
                FastDriver.InsuranceOther.SwitchToContentFrame();

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InsuranceOther.SwitchToContentFrame();
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited"), "4,000.00");
            
                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  INSURANCE Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited"), "5,000.00");

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  INSURANCE Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim());

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$0.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Open Payment Details Dialog on  INSURANCE Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Open Payment Details Dialog on  INSURANCE to verify Broker error warnings.";
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Select Paid by other Buyer Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Buyer Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as BUYER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");
            
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method Buyer Broker cannot be selected. Buyer Broker is not available in the file.");

                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "Select Paid by other Seller Payment Method as SELLER BROKER when Broker is not available in file.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith(@"Payment Method Seller Broker cannot be selected. Seller Broker is not available in the file.");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.InsuranceOther.SwitchToContentFrame();
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                //Reports.CaptureImage();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim(), "POC");
                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  INSURANCE  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Verify Loan Estimate Amount on  INSURANCE Screen.";
                Support.AreEqual(FastDriver.InsuranceOther.OtherGFE11.FAGetValue().Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on INSURANCE Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  INSURANCE Screen.";
                SetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited","9,000.00");
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
           
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  INSURANCE Screen.";
                SetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited","10,000.00");
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
            
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  INSURANCE Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  INSURANCE Screen and verify the error.";
                ClearDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.InsuranceOther.SwitchToContentFrame();
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InsuranceOther.SwitchToContentFrame();

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Insurance_Other_Disbursement()
        {
            try { 
                Reports.TestDescription = "Disburse the charges for  INSURANCE  and verify changes on source screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();
                FastDriver.InsuranceOther.OtherGABcode.FASetText(detailsGABCode);
                FastDriver.InsuranceOther.OtherFind.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.InsuranceOther.SwitchToContentFrame();
                SetTableChargesColumnCount(FastDriver.InsuranceOther.InsuranceChargesTable);
                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "Insurance Premium");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsDataForDisbursement();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");

                }
                if (FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled)
                {
                    FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FASelectItemBySendingKeys("Check");
                }

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.InsuranceOther.SwitchToContentFrame();
                #endregion Setting TestData

                string DocumentNumber = FastDriver.ActiveDisbursementSummary.DisburseCheckActiveDisbursementSummary(PayeeName);

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                FastDriver.InsuranceOther.SwitchToContentFrame();

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                Reports.TestStep = "Click on Delete on Insurance  Other screen.";
                FastDriver.BottomFrame.Delete();

                Support.AreEqual(@"A disbursement has been issued for this payee. Please void or cancel the disbursement, and then you may delete the payee.", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "Verify the check amount when check is disbursed.";
                FastDriver.InsuranceOther.SwitchToContentFrame();

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$9,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$9,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.InsuranceOther.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the check issues Image- check Mark";
                Support.AreEqual(true.ToString(), FastDriver.InsuranceOther.IssuedCheckImage.Displayed.ToString());

                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Increase the amount and Verify Error message.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad().BuyerCharge.FASetText("$6,000.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$6,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual(@"A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage(false, true));

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.InsuranceOther.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited"), "7,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited"), "6,000.00");

                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$11,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$11,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.InsuranceOther.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.InsuranceOther.IssuedCheckImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify the PINK coloured amount.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("9,000.00  " + PayeeName).ToString());

                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("BUYERBROKER");
                FastDriver.RealEstateBrokerAgentSummary.SelectAgentBrokerBy("SELLERBROKER");

                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();

                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                ClickDescription(FastDriver.InsuranceOther.InsuranceChargesTable, "ChargeDescriptionEdited");
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();

                Reports.TestStep = "Select Buyer Broker and seller broker as Paid By Other Payment Method.";

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Buyer Broker");

                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("Seller Broker");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.Click();

                Support.AreEqual("A check has been issued for the previously entered charges. The effect of your changes may result in a check amount that is GREATER than the one previously issued, which would affect the accuracy of the File Balance. You may create an additional disbursement for the amount of the difference or you may cancel your changes. Would you like to create an additional disbursement for this Payee?", FastDriver.WebDriver.HandleDialogMessage());


                Reports.TestStep = "Verify the check Amount after decreasing the amount.";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.SwitchToContentFrame();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.SwitchToContentFrame();

                if (FastDriver.InsuranceOther.CheckAmount.Text.Replace(" ", string.Empty).Contains("CheckAmount"))
                    Support.AreEqual(@"CheckAmount:$13,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));
                else
                    Support.AreEqual(@"$13,000.00", FastDriver.InsuranceOther.CheckAmount.Text.Trim().Replace(" ", string.Empty));

                Reports.TestStep = "Verify the Document Number captured from Active Disbursement summary screen";
                Support.AreEqual("1.Issued:#" + DocumentNumber + "$9,000.00", FastDriver.InsuranceOther.CheckAmount.GetAttribute("title").Replace("\n", "").Replace(" ", ""));

                Reports.TestStep = "Verify the Help Text of Check amount.";
                Support.AreEqual(true.ToString(), FastDriver.InsuranceOther.IssuedCheckImage.Displayed.ToString());

                Reports.TestStep = "Navigate to Active Disbursement screen and verify : system will create a pending check.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();

                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();

                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 1, TableAction.Click);
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Contains("4,000.00").ToString());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Mortage_Broker_Payment_Details_Dialog()
        {
            try { 
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For MORTGAGEBROKER";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                Reports.TestStep = "Create Assumption Loan First Instance";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.LoanDetailsGABcode.FASetText(detailsGABCode);
                FastDriver.NewLoan.LoanDetailsFind.Click();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text, detailsGABCode);

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Enter Buyer Credit Amount on  MORTGAGEBROKER  Screen";
                //SetBuyerCredit(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee","4.99");

                Reports.TestStep = "Enter Seller Credit Amount on  MORTGAGEBROKER  Screen";
                //SetSellerCredit(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee","5.99");

                Reports.TestStep = "Enter Loan Estimate Amount on  MORTGAGEBROKER  Screen";
                SetLoanEstimate(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee","8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  MORTGAGEBROKER  Screen";
                SetSellerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee","6.99");
                SetBuyerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee","7.99");
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee");
            
                Reports.TestStep = "Open Payment Details Dialog on  MORTGAGEBROKER  Screen";
                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer credit charges";
                //Support.AreEqual("$4.99", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify seller credit charges";
              //  Support.AreEqual("$5.99", FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Appraisal Fee".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual(string.Empty, PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("RBL", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("RBL", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("POC POC-L POC-MB", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify credits Payment Method for Buyer and Innertext.";

                Support.AreEqual("Lender", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Lender POC", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Text.Trim());
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify credits Payment Method for seller and Innertext.";
                Support.AreEqual("Lender", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Lender POC", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Text.Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Enabled.ToString());
                //Reports.CaptureImage();

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Displayed.ToString());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.DisplayLSeller.Displayed.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  MORTGAGEBROKER  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Enter Buyer Credit Amount on  MORTGAGEBROKER  Screen";
                //SetBuyerCredit(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", "4.99");

                Reports.TestStep = "Enter Seller Credit Amount on  MORTGAGEBROKER  Screen";
                //SetSellerCredit(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", "5.99");

                Reports.TestStep = "Enter Loan Estimate Amount on  MORTGAGEBROKER  Screen";
                SetLoanEstimate(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  MORTGAGEBROKER  Screen";
                SetSellerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", "6.99");
                SetBuyerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", "7.99");
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee");

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  MORTGAGEBROKER  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  MORTGAGEBROKER  Screen";
                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Verify Display (L) on CD CheckBox enabled property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Enabled.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  MORTGAGEBROKER Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on MORTGAGEBROKER Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Open Payment Details Dialog on  MORTGAGEBROKER Screen and verify that the edited values are saved.";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox enabled property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Enabled.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString());
                //Reports.CaptureImage();

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  MORTGAGEBROKER  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  MORTGAGEBROKER Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on MORTGAGEBROKER Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Mortage_Broker_Error_Warning()
        {
            try { 
                Reports.TestDescription = "Verify the Error Warning Conditions for  MORTGAGEBROKER screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText(detailsGABCode);
                FastDriver.NewLoan.LoanDetailsFind.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  MORTGAGEBROKER Screen.";

                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage();


                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.NewLoan.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited"),"4,000.00");
                     
                Reports.TestStep = "Open Payment Details Dialog on  MORTGAGEBROKER Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.NewLoan.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited"), "5,000.00");
           
                Reports.TestStep = "Open Payment Details Dialog on  MORTGAGEBROKER Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.NewLoan.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Open Payment Details Dialog on  MORTGAGEBROKER Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  MORTGAGEBROKER  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Click on Charges Tab on  MORTGAGEBROKER Screen.";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Verify Loan Estimate Amount on  MORTGAGEBROKER Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on MORTGAGEBROKER Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  MORTGAGEBROKER Screen.";
                SetBuyerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited", "9,000.00");
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");

                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  MORTGAGEBROKER Screen.";
                SetSellerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited","10,000.00");
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");
                     
                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  MORTGAGEBROKER Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  MORTGAGEBROKER Screen and verify the error.";
                ClearDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.MortgageBrokerChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Newloan_Interest_Calculation_Payment_Details_Dialog()
        {
            try { 
                Reports.TestDescription = "Verify the Description,Buyer and Seller functionality on PAYMENT DETAILS DIALOG For NEWLOAN";
                _IISLOGIN();

                Reports.TestStep = "Create a basic order with mandatory details";
                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                Reports.TestStep = "Create Assumption Loan First Instance";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText(detailsGABCode);
                FastDriver.NewLoan.LoanDetailsFind.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Click on Done in Assumtion Loan screen.";
                FastDriver.BottomFrame.Done();

                FastDriver.NewLoan.SwitchToContentFrame();
                Reports.TestStep = "Verify GAB Code Label is" + detailsGABCode;
                Support.AreEqual(FastDriver.NewLoan.LoanDetailsGabcodeLabel.Text, detailsGABCode);

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Enter Buyer Credit Amount on  NEWLOAN  Screen";
               // SetBuyerCredit(FastDriver.NewLoan.OriginationChargesTable, "Application Fee","4.99");

                Reports.TestStep = "Enter Seller Credit Amount on  NEWLOAN  Screen";
                //FastDriver.NewLoan.LoanChargesOriginationChargeSellercredit.FASetText("5.99");

                Reports.TestStep = "Enter Loan Estimate Amount on  NEWLOAN  Screen";
                SetLoanEstimate(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  NEWLOAN  Screen";
                SetSellerCharge(FastDriver.NewLoan.OriginationChargesTable, "Application Fee","6.99");
                SetBuyerCharge(FastDriver.NewLoan.OriginationChargesTable, "Application Fee","7.99");
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "Application Fee");
    
                Reports.TestStep = "Open Payment Details Dialog on  NEWLOAN  Screen";
                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "Application Fee");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                Reports.TestStep = "Verify Buyer and Seller charges";
                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer at closing and Seller at closing charges";

                Support.AreEqual("$7.99", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$6.99", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer credit charges";
               // Support.AreEqual("$4.99", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify seller credit charges";
               // Support.AreEqual("$5.99", FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Rounded and Unrounded Amount.";
                Support.AreEqual("$8.99", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());
                Support.AreEqual("$9.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify Charge Description.";
                Support.AreEqual("Application Fee".ToUpper(), FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToUpper().Trim());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.Description.Enabled.ToString());

                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.AdditionalDescription.Text.ToUpper().Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.AdditionalDescription.Enabled.ToString());

                string PayeeName = FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue();

                Reports.TestStep = "Verify Pay to and Payee Name.";

                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1".ToUpper(), FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToUpper().Trim());
                Support.AreEqual("Assumption Lender 1 for HUD Test Name 1".ToUpper(), PayeeName.ToUpper().Trim());

                Reports.TestStep = "Verify Use Default Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("$14.98", FastDriver.PaymentDetailsDlg.TotalCharge.FAGetValue());

                Reports.TestStep = "Verify Pay Of checkbox Properties.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing selected Method.";
                Support.AreEqual("RBL", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("RBL", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer at Closing and Paid By Seller at Closing disable Property.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.Enabled.ToString());

                //Reports.CaptureImage();
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual(string.Empty, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other Innertext for Payment Method.";
                Support.AreEqual("POC POC-L POC-MB", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Text.Trim());

                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify credits Payment Method for Buyer and Innertext.";

                Support.AreEqual("Lender", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Lender POC", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Text.Trim());
                Reports.TestStep = "Verify Paid By Buyer by other and Paid By Seller by other disable Property.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify credits Payment Method for seller and Innertext.";
                Support.AreEqual("Lender", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("Lender POC", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Text.Trim());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.Enabled.ToString());

                Reports.TestStep = "Verify Double Asterisk Checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Enabled.ToString());
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.DisplayLBorrower.Displayed.ToString());
                Support.AreEqual("True", FastDriver.PaymentDetailsDlg.DisplayLSeller.Displayed.ToString());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  NEWLOAN  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Enter Buyer Credit Amount on  NEWLOAN  Screen";
                //SetBuyerCredit(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", "4.99");

                Reports.TestStep = "Enter Seller Credit Amount on  NEWLOAN  Screen";
                //FastDriver.NewLoan.LoanChargesOriginationChargeSellercredit.FASetText("5.99");

                Reports.TestStep = "Enter Loan Estimate Amount on  NEWLOAN  Screen";
                SetLoanEstimate(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", "8.99");

                Reports.TestStep = "Enter  Buyer and Seller Charge Amount on  NEWLOAN  Screen";
                SetSellerCharge(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", "6.99");
                SetBuyerCharge(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", "7.99");
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "Application Fee");

                Reports.TestStep = "Edit the Value on Payment details dialog and verify on  NEWLOAN  and vice versa";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  NEWLOAN  Screen";
                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "Application Fee");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Change the PAYEE NAME from Payment details dialog by Unchecking the USE DEFAULT checkbox.";
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("EditedPayeeName");

                Reports.TestStep = "Check the PART OFF Checkbox.";
                FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(true);

                Reports.TestStep = "Verify rounded Amount functionality.";
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.50");
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,001.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText("$5,000.49");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);
                Support.AreEqual("$5,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FASetText("$10,000.00");
                FastDriver.PaymentDetailsDlg.LoadEstimateRounded.SendKeys(FAKeys.Tab);

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Edit Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("$3,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$2,000.00");

                Reports.TestStep = "Edit Seller charges amount.";
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("$4,000.00");
                Reports.TestStep = "Delete amount from Paid By Seller at closing and enter amount at Paid before Closing";
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$3,000.00");

                //Reports.CaptureImage();
                Reports.TestStep = "Enter Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                Reports.TestStep = "Check the double asterisk checkbox.";
                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                Reports.TestStep = "Verify Display (L) on CD CheckBox enabled property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Enabled.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString());

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
             //   FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                //FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");

                //FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
               // FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("Lender");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  NEWLOAN Screen.";
              //  Support.AreEqual(@"1,000.00", FastDriver.NewLoan.LoanChargesOriginationChargebuyercredit.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  NEWLOAN Screen.";
              //  Support.AreEqual(@"2,000.00", FastDriver.NewLoan.LoanChargesOriginationChargeSellercredit.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Amount on  NEWLOAN Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on NEWLOAN Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Open Payment Details Dialog on  NEWLOAN Screen and verify that the edited values are saved.";

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify the Charge Description on Payment details dialog.";
                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(@"ChargeDescriptionEdited", FastDriver.PaymentDetailsDlg.Description.FAGetValue().Trim());

                Reports.TestStep = "Verify the Change PAYEE NAME on Payment details dialog.";
                Support.AreEqual(false.ToString(), FastDriver.PaymentDetailsDlg.usedefault.Selected.ToString());
                Support.AreEqual("EditedPayeeName", FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue().Trim());

                Reports.TestStep = "Verify that PART OFF CheckBox is checked.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.PartOf.Selected.ToString());

                Reports.TestStep = "Verify rounded and unrounded Amount.";

                Support.AreEqual("$5,000.49", FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue().Trim());

                Support.AreEqual("$10,000.00", FastDriver.PaymentDetailsDlg.LoadEstimateRounded.FAGetValue().Trim());

                Reports.TestStep = "Verify BROKEN IMAGE.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.BrokenImage.Displayed.ToString());

                Reports.TestStep = "Verify Buyer charges amount.";
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Buyer at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Seller charges amount.";
                Support.AreEqual("$4,000.00", FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Trim());
                Reports.TestStep = "Verify Paid By Seller at closing and Paid before Closing";
                Support.AreEqual("$0.00", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Trim());
                Support.AreEqual("$3,000.00", FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Trim());

                Reports.TestStep = "Verify Paid By Other Amount.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText("$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method.";
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());
                Support.AreEqual("POC-L", FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Check the double asterisk checkbox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.Selected.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox enabled property.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Enabled.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Enabled.ToString());

                Reports.TestStep = "Verify Display (L) on CD CheckBox.";
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLBorrower.Selected.ToString());
                Support.AreEqual(true.ToString(), FastDriver.PaymentDetailsDlg.DisplayLSeller.Selected.ToString());
                //Reports.CaptureImage();

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
               // Support.AreEqual("$1,000.00", FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue().Trim());
               // Support.AreEqual("POC", FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Select credits Payment Method for seller and Buyer.";
                //Support.AreEqual("$2,000.00", FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue().Trim());
               // Support.AreEqual("Lender", FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem().Trim());

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to  NEWLOAN  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  NEWLOAN Screen.";
               // Support.AreEqual(@"1,000.00", FastDriver.NewLoan.LoanChargesOriginationChargebuyercredit.FAGetValue().Trim());

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  NEWLOAN Screen.";
               // Support.AreEqual(@"2,000.00", FastDriver.NewLoan.LoanChargesOriginationChargeSellercredit.FAGetValue().Trim());

                Reports.TestStep = "Verify Loan Estimate Amount on  NEWLOAN Screen.";
                Support.AreEqual(@"5,000.49", GetLoanEstimate(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on NEWLOAN Screen.";
                Support.AreEqual(@"4,000.00", GetSellerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual(@"3,000.00", GetBuyerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim());
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            } 
        }
        [TestMethod]
        public void Newloan_Interest_Calculation_Error_Warning()
        {
            try
            {
                Reports.TestDescription = "Verify the Error Warning Conditions for  NEWLOAN screen and Payment Details dialog";
                _IISLOGIN();

                #region Setting TestData

                CreateFile();

                string detailsGABCode = "HUDASLNDR1";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText(detailsGABCode);
                FastDriver.NewLoan.LoanDetailsFind.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Setting the Test Data";
                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "Application Fee");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();
                var PayeeName = FastDriver.PaymentDetailsDlg.EnterPaymentDetailsData();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys("POC-L");

                FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(true);

                //FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("$1,000.00");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");

                // FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("$2,000.00");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("Lender");

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion Setting TestData

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Open Payment Details Dialog on  NEWLOAN Screen.";
                FastDriver.NewLoan.SwitchToContentFrame();

                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                Reports.TestStep = "Change the Charge Description from Payment details dialog.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Charge Description is required.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.Description.FASetText("ChargeDescriptionEdited");

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$3,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount. Do you want to recalculate the Buyer Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.WebDriver.HandleDialogMessage(false, false);

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.NewLoan.SwitchToContentFrame();

                Support.AreEqual(GetBuyerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited"), "4,000.00");

                Reports.TestStep = "Open Payment Details Dialog on  NEWLOAN Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Seller before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("4,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Seller Charge Amount?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.NewLoan.SwitchToContentFrame();

                Support.AreEqual(GetSellerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited"), "5,000.00");

                Reports.TestStep = "Open Payment Details Dialog on  NEWLOAN Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                Reports.TestStep = "Increase the paid by Buyer Before Before Closing and paid by Buyer Seller Before Closing Amount and verify the Error Warning.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("$4,000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                Support.AreEqual(@"Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?", FastDriver.WebDriver.HandleDialogMessage());

                Reports.TestStep = "System will update the Buyer Charge on Main screen.";
                FastDriver.NewLoan.SwitchToContentFrame();

                Support.AreEqual("5,000.00", GetBuyerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim());
                Support.AreEqual("6,000.00", GetSellerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim());

                Reports.TestStep = "Open Payment Details Dialog on  NEWLOAN Screen and verify that the edited values are saved.";
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                Reports.TestStep = "Verify Buyer charges amount.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "$4,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Verify Seller charges amount.";

                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "$6,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue(), "$0.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue(), "$5,000.00");
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue(), "$1,000.00");

                Reports.TestStep = "Select Paid By Buyer by other and Paid By Seller by other selected Method as NULL.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemByIndex(0);
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemByIndex(0);

                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Payment Method is required for Paid By Others amount.");
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Enter Paid by Borrower at Closing and Paid by Seller at Closing amount as negative amount";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-900000.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-900000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Total of Buyer Paid By amounts is not equal to the Buyer Charge Amount and Seller Paid By amounts is not equal to the Seller Charge Amount. Do you want to recalculate the Buyer and Seller Charge Amounts?");
                FastDriver.PaymentDetailsDlg.AcceptDialogAndCompareWith("Buyer and/or Seller Charge cannot be negative.");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Navigate to  NEWLOAN  and Verify the data on source screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Click on Charges Tab on  NEWLOAN Screen.";
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  NEWLOAN Screen.";
                //Support.AreEqual(FastDriver.NewLoan.LoanChargesOriginationChargebuyercredit.FAGetValue().Trim(), "1,000.00");

                Reports.TestStep = "Verify Buyer and Seller Credit Amount on  NEWLOAN Screen.";
                //Support.AreEqual(FastDriver.NewLoan.LoanChargesOriginationChargeSellercredit.FAGetValue().Trim(), "2,000.00");

                Reports.TestStep = "Verify Loan Estimate Amount on  NEWLOAN Screen.";
                Support.AreEqual(GetLoanEstimate(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.49");

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount on NEWLOAN Screen.";
                Support.AreEqual(GetSellerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");
                Support.AreEqual(GetBuyerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");

                Reports.TestStep = "Modify the Splited Buyer charge amount and Verify Error on  NEWLOAN Screen.";
                SetBuyerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited", "9,000.00");
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");

                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Modify the Splited Seller charge amount and Verify Error on  NEWLOAN Screen.";
                SetSellerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited", "10,000.00");
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");

                Support.AreEqual("Charge has Multiple Paid By Methods.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.NewLoan.SwitchToContentFrame();

                Reports.TestStep = "Verify  Buyer and Seller Charge Amount is not changed  NEWLOAN Screen.";
                Support.AreEqual(GetBuyerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim(), "5,000.00");
                Support.AreEqual(GetSellerCharge(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited").Trim(), "6,000.00");

                Reports.TestStep = "Delete the charge description on  NEWLOAN Screen and verify the error.";
                ClearDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");
                Support.AreEqual("Unable to delete charge description.  Charge description still has a charge amount.", FastDriver.WebDriver.HandleDialogMessage());

                FastDriver.NewLoan.SwitchToContentFrame();
                ClickDescription(FastDriver.NewLoan.OriginationChargesTable, "ChargeDescriptionEdited");
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.FAClick();

                Reports.TestStep = "Verify the Payment Method is POC.";
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();

                Reports.TestStep = "Remove the charges from Before closing and putting in At closing.";

                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("$4,000.00");

                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("$5,000.00");

                Reports.TestStep = "Click on Done in Payment Details dialog.";
                FastDriver.PaymentDetailsDlg.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
            }
            catch (Exception ex) {
                Support.Fail(ex.Message);
            }

        }

        #endregion TestCases

        #region AdditionalMethods

        private void _IISLOGIN()
        {
            Reports.TestStep = "Login to Fast Application.";
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
        }

        private void CreateFile()
        {
            var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
            defaultRequest.File.Sellers = null;
            defaultRequest.File.Buyers = null;
            defaultRequest.formType = FormType.CD;
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
        }

        private void SetBuyerCharge(IWebElement TableCharges, string DescriptionRow, string BuyerChargeValue) {
            TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.SetText, BuyerChargeValue);
        }
        private string GetBuyerCharge(IWebElement TableCharges, string DescriptionRow)
        {
            
            return TableCharges.PerformTableAction(1, DescriptionRow, 3, TableAction.GetAttribute, "value").Message;
        }
        private void SetSellerCharge(IWebElement TableCharges, string DescriptionRow, string SellerChargeValue)
        {
            int SearchIndex = TableChargesColumnCount == 7 ? 5 : 4;
            TableCharges.PerformTableAction(1, DescriptionRow, SearchIndex, TableAction.SetText, SellerChargeValue);
        }
        private string GetSellerCharge(IWebElement TableCharges, string DescriptionRow)
        {
            int SearchIndex = TableChargesColumnCount == 7 ? 5 : 4;
            return TableCharges.PerformTableAction(1, DescriptionRow, SearchIndex, TableAction.GetAttribute, "value").Message;
        }
        private void SetBuyerCredit(IWebElement TableCharges, string DescriptionRow, string BuyerCreditValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.SetText, BuyerCreditValue);
        }
        private string GetBuyerCredit(IWebElement TableCharges, string DescriptionRow)
        {
            return TableCharges.PerformTableAction(1, DescriptionRow, 4, TableAction.GetAttribute, "value").Message;
        }
        private void SetSellerCredit(IWebElement TableCharges, string DescriptionRow, string SellerCreditValue)
        {            
            TableCharges.PerformTableAction(1, DescriptionRow, 6, TableAction.SetText, SellerCreditValue);
        }
        private string GetSellerCredit(IWebElement TableCharges, string DescriptionRow)
        {
            
            return TableCharges.PerformTableAction(1, DescriptionRow, 6, TableAction.GetAttribute, "value").Message;
        }
        private void SetLoanEstimate(IWebElement TableCharges, string DescriptionRow, string LoanEstiamteValue)
        {
            int SearchIndex = TableChargesColumnCount == 7 ? 7 : 5;
            TableCharges.PerformTableAction(1, DescriptionRow, SearchIndex, TableAction.SetText, LoanEstiamteValue);
        }
        private string GetLoanEstimate(IWebElement TableCharges, string DescriptionRow)
        {
            int SearchIndex = TableChargesColumnCount == 7 ? 7 : 5;
            return TableCharges.PerformTableAction(1, DescriptionRow, SearchIndex, TableAction.GetAttribute, "value").Message;
        }
        private void SetDescription(IWebElement TableCharges, string DescriptionRow, string DescriptionValue)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 1, TableAction.SendKeys, DescriptionValue);
            //There are some table charges that have only 5 columns and the index for the Loan Estimate will change.
            SetTableChargesColumnCount(TableCharges);
        }
        private void ClickDescription(IWebElement TableCharges, string DescriptionRow) {
            TableCharges.PerformTableAction(1, DescriptionRow, 1, TableAction.Click);
        }
        private void ClearDescription(IWebElement TableCharges, string DescriptionRow)
        {
            TableCharges.PerformTableAction(1, DescriptionRow, 1, TableAction.Click);
            TableCharges.PerformTableAction(1, DescriptionRow, 1, TableAction.SetText, ".");
            TableCharges.PerformTableAction(1, ".", 1, TableAction.SendKeys, Keys.Backspace+FAKeys.Tab);
        }
        private void SetTableChargesColumnCount(IWebElement TableCharges)
        {
            TableChargesColumnCount = TableCharges.FindElements(By.CssSelector("tr:first-of-type td")).Count;
        }
        
        #endregion AdditionalMethods

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }

}