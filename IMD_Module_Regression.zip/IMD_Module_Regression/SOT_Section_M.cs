﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;


namespace IMD_Module_Regression
{
    [CodedUITest]
    public class SOT_Section_M : MasterTestClass
    {
        #region 491406- CD Screen - Section M - Display Seller deposits on line M 03
        [TestMethod]
        public void US_491406_TC_502604_NO_01()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var deposit = new DepositParameters()
                {
                    Amount = 5000,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Seller",
                    Payor = "Charge",
                    CreditToSeller = true
                };
                #endregion

                Reports.TestDescription = "VERIFY AMOUNT FROM DEPOSIT IN ESCROW SCREEN IN LINE M03";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide Deposit in Escrow credit to seller amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Validating Section M Line 03";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM03_Seqno.FAClick();
                Support.data = FastDriver.ClosingDisclosure.SectionM03_Seqno.Text;
                Support.AreEqual("03", Support.data.Clean());
                Support.data = FastDriver.ClosingDisclosure.SectionM03_Label.FAGetAttribute("title");
                Support.AreEqual("Deposits", Support.data.Clean());
                Support.data = FastDriver.ClosingDisclosure.SectionM03_Amt.Text;
                Support.AreEqual("$5,000.00", Support.data.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_491406_TC_502607_NO_03()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var depositFromSeller = new DepositParameters()
                {
                    Amount = 5000.50,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Seller",
                    Payor = "Charge",
                    CreditToSeller = true
                };
                var depositFromBuyer = new DepositParameters()
                {
                    Amount = 6000.50,
                    TypeofFunds = "Cash",
                    Representing = "Earnest Money Deposit",
                    ReceivedFrom = "Buyer",
                    Payor = "Charge",
                    CreditToSeller = true
                };
                #endregion

                Reports.TestDescription = "VERIFY MULTIPLE AMOUNT FROM DEPOSIT IN ESCROW SCREEN IN LINE M03";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide multiple Deposit in Escrow credit to seller amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(depositFromSeller);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: false);
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(depositFromBuyer);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Validating Section M Line 03";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM03_Seqno.FAClick();
                Support.data = FastDriver.ClosingDisclosure.SectionM03_Seqno.Text;
                Support.AreEqual("03", Support.data.Clean());
                Support.data = FastDriver.ClosingDisclosure.SectionM03_Label.FAGetAttribute("title");
                Support.AreEqual("Deposits", Support.data.Clean());
                Support.data = FastDriver.ClosingDisclosure.SectionM03_Amt.Text;
                Support.AreEqual("$11,001.00", Support.data.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_491406_TC_502609_NO_04()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var deposit = new DepositParameters()
                {
                    Amount = 5000,
                    TypeofFunds = "Cash",
                    Representing = "Miscellaneous Deposit",
                    ReceivedFrom = "Seller",
                    Payor = "Charge",
                    CreditToSeller = true
                };
                #endregion

                Reports.TestDescription = "VERIFY THE ADJUSTED AMOUNT FROM DEPOSIT ADJUSTMENT SCREEN WITH ADJUST REASON AS CORRECT AMOUNT IN LINE M03";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide multiple Deposit in Escrow credit to seller amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Adjust the amount from Deposit Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "5,000.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");
                FastDriver.DepositAdjustment.CorrectAmount.FASetText("12345678901.23");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.FAClick();

                Reports.TestStep = "Validating Section M Line 03";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM03_Seqno.FAClick();
                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionM03_Seqno.Text.Clean());
                Support.AreEqual("Deposits", FastDriver.ClosingDisclosure.SectionM03_Label.FAGetAttribute("title").Clean());
                Support.AreEqual("$345,678,901.20", FastDriver.ClosingDisclosure.SectionM03_Amt.Text.Clean());
                //Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionM03_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_491406_TC_502610_NO_05()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var deposit = new DepositParameters()
                {
                    Amount = 5000,
                    TypeofFunds = "Cash",
                    Representing = "Earnest Money Deposit",
                    ReceivedFrom = "Seller",
                    Payor = "Charge",
                    CreditToSeller = true
                };
                #endregion

                Reports.TestDescription = "VERIFY THE ADJUSTED AMOUNT FROM DEPOSIT ADJUSTMENT SCREEN WITH ADJUST REASON AS CANCEL IN LINE M03";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide Deposit in Escrow amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Adjust the amount from Deposit Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").WaitForScreenToLoad();
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "5,000.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.WaitForScreenToLoad();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Cancel");
                FastDriver.DepositAdjustment.Comment.FASetText("Cancel");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Validating Section M Line 03";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM03_Seqno.FAClick();
                Support.data = FastDriver.ClosingDisclosure.SectionM03_Seqno.Text;
                Support.AreEqual("03", Support.data.Clean());
                Support.data = FastDriver.ClosingDisclosure.SectionM03_Amt.Text;
                Support.AreEqual(string.Empty, Support.data.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void US_491406_TC_502614_NO_08()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                var deposit = new DepositParameters()
                {
                    Amount = 1000,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    ReceivedFrom = "Seller",
                    Payor = "Charge",
                    CreditToSeller = true
                };
                #endregion

                Reports.TestDescription = "VERIFY SEQUENCE OF INDIVIDUAL CREDITS FROM LINE M03 TO M08";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide Deposit in Escrow credit to seller amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Creating Charges in Offset Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", "Assign Tenant Lease/Rent", "Seller Credit", TableAction.SetText, "2000");
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", "Assign Tenant Lease/Rent", "Description", TableAction.Click);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Creating REB Credits for seller";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                //TODO: Wait for DetailsGABcodeLabel value                
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("REB Seller");
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway); Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("3000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Creating Credit Amount for Assumption Loan 1st Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("248");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                //TODO: Wait for DetailsGABcodeLabel value
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Seller Credit", TableAction.SetText, "4000");
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Description", TableAction.Click);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("4000");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone(); Playback.Wait(200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanChargesTab.FAClick(); Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", "Principal Reduction Payment", "Seller Credit", TableAction.SetText, "6000");
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", "Principal Reduction Payment", "Description", TableAction.Click);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("6000");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone(); Playback.Wait(200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Creating Charges in 2nd New Loan Charges";
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanChargesTab.FAClick(); Playback.Wait(500);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Document Preparation Fee", "Seller Credit", TableAction.SetText, "5000");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Document Preparation Fee", "Description", TableAction.Click);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("5000");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone(); Playback.Wait(200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", "Tax Installment: Amount", "Seller Credit", TableAction.SetText, "7000");
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", "Tax Installment: Amount", "Description", TableAction.Click);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText("7000");
                FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone(); Playback.Wait(200);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Validating Section M";
                //03
                FastDriver.ClosingDisclosure.SectionM03_Seqno.FAClick();
                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionM03_Seqno.Text.Clean());
                Support.AreEqual("Deposits", FastDriver.ClosingDisclosure.SectionM03_Label.Text.Clean());
                Support.AreEqual("$1,000.00", FastDriver.ClosingDisclosure.SectionM03_Amt.Text.Clean());
                //04
                FastDriver.ClosingDisclosure.SectionM04_Seqno.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionM04_Seqno.Text.Clean());
                Support.AreEqual("Assign Tenant Lease/Rent", FastDriver.ClosingDisclosure.SectionM04_Label.Text.Clean());
                Support.AreEqual("$2,000.00", FastDriver.ClosingDisclosure.SectionM04_Amt.Text.Clean());
                //05
                FastDriver.ClosingDisclosure.SectionM05_Seqno.FAClick();
                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionM05_Seqno.Text.Clean());
                Support.AreEqual("REB Seller from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionM05_Label.Text.Clean());
                Support.AreEqual("$3,000.00", FastDriver.ClosingDisclosure.SectionM05_Amt.Text.Clean());
                //06
                FastDriver.ClosingDisclosure.SectionM06_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionM06_Seqno.Text.Clean());
                Support.AreEqual("Document Fee from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionM06_Label.Text.Clean());
                Support.AreEqual("$4,000.00", FastDriver.ClosingDisclosure.SectionM06_Amt.Text.Clean());
                //07
                FastDriver.ClosingDisclosure.SectionM07_Seqno.FAClick();
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionM07_Seqno.Text.Clean());
                Support.AreEqual("Document Preparation Fee from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionM07_Label.Text.Clean());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionM07_Amt.Text.Clean());
                //08
                FastDriver.ClosingDisclosure.SectionM08_Seqno.FAClick();
                Support.AreEqual("08", FastDriver.ClosingDisclosure.SectionM08_Seqno.Text.Clean());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionM08_Label.Text.Clean());
                Support.AreEqual("$13,000.00", FastDriver.ClosingDisclosure.SectionM08_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Deleting Credit Amount for Assumption Loan 1st Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Seller Credit", TableAction.SetText, "0");
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Validating Section M";
                //03
                FastDriver.ClosingDisclosure.SectionM03_Seqno.FAClick();
                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionM03_Seqno.Text.Clean());
                Support.AreEqual("Deposits", FastDriver.ClosingDisclosure.SectionM03_Label.Text.Clean());
                Support.AreEqual("$1,000.00", FastDriver.ClosingDisclosure.SectionM03_Amt.Text.Clean());
                //04
                FastDriver.ClosingDisclosure.SectionM04_Seqno.FAClick();
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionM04_Seqno.Text.Clean());
                Support.AreEqual("Assign Tenant Lease/Rent", FastDriver.ClosingDisclosure.SectionM04_Label.Text.Clean());
                Support.AreEqual("$2,000.00", FastDriver.ClosingDisclosure.SectionM04_Amt.Text.Clean());
                //05
                FastDriver.ClosingDisclosure.SectionM05_Seqno.FAClick();
                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionM05_Seqno.Text.Clean());
                Support.AreEqual("REB Seller from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionM05_Label.Text.Clean());
                Support.AreEqual("$3,000.00", FastDriver.ClosingDisclosure.SectionM05_Amt.Text.Clean());
                //06
                FastDriver.ClosingDisclosure.SectionM07_Seqno.FAClick();
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionM06_Seqno.Text.Clean());
                Support.AreEqual("Document Preparation Fee from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionM06_Label.Text.Clean());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionM06_Amt.Text.Clean());
                //07
                FastDriver.ClosingDisclosure.SectionM07_Seqno.FAClick();
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionM07_Seqno.Text.Clean());
                Support.AreEqual("Principal Reduction Payment from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionM07_Label.Text.Clean());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionM07_Amt.Text.Clean());
                //08
                FastDriver.ClosingDisclosure.SectionM08_Seqno.FAClick();
                Support.AreEqual("08", FastDriver.ClosingDisclosure.SectionM08_Seqno.Text.Clean());
                Support.AreEqual("Tax Installment: Amount from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionM08_Label.Text.Clean());
                Support.AreEqual("$7,000.00", FastDriver.ClosingDisclosure.SectionM08_Amt.Text.Clean());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

            }
            catch (Exception e)
            {
                Support.Fail(e.Message);
            }
        }

        #endregion

        #region USER STORY -363419 :ClosingDisclosure SCREEN : SECTION M.01: ENTER AMOUNT  IN  SALES PRICE  TEXBOX UNDER SECTION.
        [TestMethod]
        public void US_363419_ITE_16_TestCase_2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = " USER STORY -363419 : SECTION M.01: ENTER AMOUNT  IN  SALES PRICE  TEXBOX UNDER SECTION.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "ENTER THE SALES PRICE AMOUNT IN TEXTBOX AND SAVE.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("250.50" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("Sale Price of Property", FastDriver.ClosingDisclosure.SectionM01_Label.Text);
                Support.AreEqual("$250.50", FastDriver.ClosingDisclosure.SectionM01_Amt.Text);
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionM01_Amt.Text.Contains("$").ToString(), "Verify '$' symbol is present");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "VERIFY THE AMOUNT AFTER SAVE AND SET MAX VALUE(11.2 DIGITS).";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("250.50" + FAKeys.Tab);
                FastDriver.TermsDatesStatus.LiabilityAmount.FASetText("250.50" + FAKeys.Tab);
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("12345678901.33" + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "VERIFY THE MAX VALUE AFTER SAVE .";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("12,345,678,901.33", FastDriver.TermsDatesStatus.SalesPriceAmount.FAGetValue(), "Sales Price Amount");
                Support.AreEqual("12,345,678,901.33", FastDriver.TermsDatesStatus.LiabilityAmount.FAGetValue(), "Liability Amount");

                //Reports.TestDescription = "USER STORY -347861: SECTION K: VERIFY  AMOUNT AND  THE DESCRIPTION SHALL NOT BE EDITABLE ON LINE K.01";                
                Reports.TestStep = "VERIFY ($) SIGN AND DESCRIPTION SHALL NOT BE EDITABLE ON LINE K.01.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("Sale Price of Property", FastDriver.ClosingDisclosure.SectionM01_Label.Text);
                Support.AreEqual("$345,678,901.33", FastDriver.ClosingDisclosure.SectionM01_Amt.Text);
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionM01_Amt.Text.Contains("$").ToString(), "Verify '$' symbol is present");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "SET ZERO VALUES AND VARIFY THE AMOUNT AFTER SAVE .";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("0");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("Sale Price of Property", FastDriver.ClosingDisclosure.SectionM01_Label.Text);
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionM01_Amt.Displayed.ToString());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USER STORY -363420 : ClosingDisclosure SCREEN - SECTION M: DISPLAY "SALE PRICE OF ANY PERSONAL PROPERTY INCLUDED IN SALE" ON LINE M.02.
        [TestMethod]
        public void US_363420_ITE_16_TestCase_4()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = " USER STORY -363420 : SECTION M: DISPLAY SALE PRICE OF ANY PERSONAL PROPERTY INCLUDED IN SALE ON LINE M.02.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "ENTER THE BUYER CHARGE AMOUNT IN OFFSET SCREEN AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", "Sale Price of Any Personal Property Included in Sale", "Seller Credit", TableAction.SetText, "500");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("Sale Price of Any Personal Property Included in Sale", FastDriver.ClosingDisclosure.SectionM02_Label.Text);
                Support.AreEqual("$500.00", FastDriver.ClosingDisclosure.SectionM02_Amt.Text);
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionM02_Amt.Text.Contains("$").ToString(), "Verify '$' symbol is present");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "ENTER THE MAX BUYER CHARGE AMOUNT IN OFFSET SCREEN AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", "Sale Price of Any Personal Property Included in Sale", "Seller Credit", TableAction.SetText, "12345678901.33");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("Sale Price of Any Personal Property Included in Sale", FastDriver.ClosingDisclosure.SectionM02_Label.Text);
                Support.AreEqual("$345,678,901.33", FastDriver.ClosingDisclosure.SectionM02_Amt.Text);
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionM02_Amt.Text.Contains("$").ToString(), "Verify '$' symbol is present");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "ENTER ZERO(0) BUYER CHARGE AMOUNT IN OFFSET SCREEN AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", "Sale Price of Any Personal Property Included in Sale", "Seller Credit", TableAction.SetText, "0");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Support.AreEqual("Sale Price of Any Personal Property Included in Sale", FastDriver.ClosingDisclosure.SectionM02_Label.Text);
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionM02_Label.Displayed.ToString());
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 360030 CD Screen - Section M: City/Town Taxes
        [TestMethod]
        public void FTR5_ITR20SECM_US_360030_TC_370836_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360030_TESTCASE_370836_SCENARIO_1- Verify display of Line 09 when no data entered for City/Town Taxes in Proration Tax screen.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                var createFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                string fileNumber = FastDriver.FACreateFileFromWCF(createFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Verify the line 9 in section M";
                FastDriver.ClosingDisclosure.SectionM.Click();
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.M, 9, "City/Town Taxes", "", "", "");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR20SECM_US_360030_TC_370837_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360030_TESTCASE_370837_SCENARIO_2- Sec M: Verify display of Line 09 when valid required data is entered for City/Town Taxes in Proration Tax screen";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                string charge = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "10/21/2014", "10/21/2015", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.M, 9, "City/Town Taxes", "10/21/14", "10/21/15", charge);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR20SECM_US_360030_TC_370850_SC10()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360030_TESTCASE_370850_SCENARIO_10 - Sec M: Verify display format of charge amount in Line 09.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                string charge = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "10/21/2014", "10/21/2015", "99,999,999,999.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.M, 9, "City/Town Taxes", "10/21/14", "10/21/15", charge.Substring(3));
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR20SECM_US_360030_TC_370851_SC11()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360030_TESTCASE_370851_SCENARIO_11 - Sec M: Verify display of Line 09 When Proration City/Town Taxes added is removed.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "10/21/2014", "10/21/2015", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.CityCell.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.M, 9, "City/Town Taxes", "", "", "");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 360033 CD Screen - Section M: County Taxes
        [TestMethod]
        public void FTR5_ITR20SECM_US_360033_TC_370853_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360033_TESTCASE_370853_SCENARIO_1- Verify display of Line 10 when no data entered for County Taxes in Proration Tax screen.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                var createFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                string fileNumber = FastDriver.FACreateFileFromWCF(createFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Verify the line 10 in section M";
                FastDriver.ClosingDisclosure.SectionM.FAClick();
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.M, 10, "County Taxes", "", "", "");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR20SECM_US_360033_TC_370854_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360033_TESTCASE_370854_SCENARIO_2- Sec M: Verify display of Line 10 when valid required data is entered for County Taxes in Proration Tax screen";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                string charge = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/21/2014", "10/21/2015", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.M, 10, "County Taxes", "10/21/14", "10/21/15", charge);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR20SECM_US_360033_TC_370872_SC10()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360033_TESTCASE_370872_SCENARIO_10 - Sec M: Verify display format of charge amount in Line 09.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                string charge = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/21/2014", "10/21/2015", "99,999,999,999.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.M, 10, "County Taxes", "10/21/14", "10/21/15", charge.Substring(3));
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR20SECM_US_360033_TC_370874_SC11()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360033_TESTCASE_370874_SCENARIO_11 - Sec M: Verify display of Line 10 When Proration County Taxes added is removed.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/21/2014", "10/21/2015", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.CountyCell.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM.SendKeys("");
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.M, 10, "County Taxes", "", "", "");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 360034 CD Screen - Section M: Assessments
        [TestMethod]
        public void FTR5_ITR20SECM_US_360034_TC_371011_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360034_TESTCASE_371011_SCENARIO_1- Verify display of Line 11 when no data entered for Assessments in Proration Tax screen.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                var createFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                string fileNumber = FastDriver.FACreateFileFromWCF(createFileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Verify the line 10 in section M";
                FastDriver.ClosingDisclosure.SectionM.FAClick();
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.M, 11, "Assessments", "", "", "");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR20SECM_US_360034_TC_371013_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360034_TESTCASE_371013_SCENARIO_2- Sec M: Verify display of Line 11 when valid required data is entered for Assessments in Proration Tax screen";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                string charge = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "10/21/2014", "10/21/2015", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.M, 11, "Assessments", "10/21/14", "10/21/15", charge);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR20SECM_US_360034_TC_371024_SC10()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360034_TESTCASE_371024_SCENARIO_10 - Sec M: Verify display format of charge amount in Line 11.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                string charge = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "10/21/2014", "10/21/2015", "99,999,999,999.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.M, 11, "Assessments", "10/21/14", "10/21/15", charge.Substring(3));
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR20SECM_US_360034_TC_371025_SC11()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = @"USERSTORY – 360034_TESTCASE_371025_SCENARIO_11 - Sec M: Verify display of Line 11 When Proration Assessments added is removed.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "10/21/2014", "10/21/2015", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.AssesmentCell.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM.SendKeys("");
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.M, 11, "Assessments", "", "", "");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 381645 CD Screen – Section M: Display Asterisk for groups
        [TestMethod]
        public void FTR5_ITR27_US_381645_TC_394581_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "USERSTORY 381645_TESTCASE_394581_SCENARIO1: Verify asterisk mark when a credit group is shown and is in collapsed state.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Property Tax Check and Add GAB";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("188");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                Reports.TestStep = "Add BuyerCredit in Property Tax Check screen";
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", "Tax Installment: Interest Due", "Seller Credit", TableAction.SetText, "300.09" + FAKeys.Tab);
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", "Tax Installment: Amount", "Seller Credit", TableAction.SetText, "200" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.SendKeys("");
                string credDesc = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetCell).Element.FindElement(OpenQA.Selenium.By.CssSelector("span:nth-child(3)")).Text;
                string creditDescription = credDesc.Clean();

                Reports.TestStep = "Verify Credit group shown";
                Support.AreEqual("* Property Taxes", creditDescription);

                Reports.TestStep = "Verify * mark for a credit Group in collapsed state";
                Support.AreEqual("*", creditDescription[0].ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR27_US_381645_TC_394586_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "USERSTORY 381645_TESTCASE_394586_SCENARIO1: Verify asterisk mark is not shown for an Individual credit.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Property Tax Check and Add GAB";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("188");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                Reports.TestStep = "Add Seller Credit in Property Tax Check screen";
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", "Tax Installment: Interest Due", "Seller Credit", TableAction.SetText, "300.09").Element.FindElement(OpenQA.Selenium.By.TagName("input")).FireEvent("onblur");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();
                string description = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();

                Support.AreEqual("False", description.Contains("*").ToString(), "Verify '*' mark is not shown");
                Support.AreEqual("03 Tax Installment: Interest Due from Mblo Funding, Inc.", description);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 382377 CD Screen – Section M: Display Supplemental Summary line in section M
        [TestMethod]
        public void FTR5_ITR27_US_382377_TC_394590_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "USERSTORY 382377_TESTCASE_394590_SCENARIO1: Verify display of Line 08 when there are six or more credits/credit groups to display in section M.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "NAVIGATE TO TERMSDATESSTATUS SCREEN.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FireEvent("onfocus").FASetText("25000.00" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Setting Seller Credit in Adjustment Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Sale Price of Any Personal Property Included in Sale", sellerCredit: 212.00);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Lease/Rent", sellerCredit: 312.00);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Setting Seller Credit in Adjustment Miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", sellerCredit: 1533);

                Reports.TestStep = "Navigate to REB screen - Add GAB REBBroker Credits, Commission Amount";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("12");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Seller Listing Credit", sellerCredit: 23.09);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Adhoc Seller Broker 1", sellerCredit: 45.08);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Add Seller Credit in Assumption Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Escrow Charge Processes>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("188");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", sellerCredit: 249);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", sellerCredit: 42);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Add Seller Credit in New Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCredit: 640);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCredit: 460);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Add Seller Credit in New Loan 2 charge screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("314");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", sellerCredit: 54.25);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", sellerCredit: 45);

                Reports.TestStep = "Navigate to Property Tax Check and Add GAB";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("234");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                Reports.TestStep = "Add Seller Credit in Property Tax Check screen";
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", sellerCredit: 12.20);

                Reports.TestStep = "Navigate to Proration Tax screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "09/21/2012", "09/21/2013", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/22/2013", "10/22/2014", "600.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "11/23/2014", "11/23/2015", "800", true);

                Reports.TestStep = "Navigate to Proration Rent screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad().EnterProrationDetails(fromDate: "08/28/2014", toDate: "08/28/2015", amount: "12600.00", creditSeller: true);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionM.Click();

                Reports.TestStep = "Getting all amounts from Section M - Due Items sub section";
                List<double> adjAmounts = new List<double>();
                for (int i = 2; i < 10; i++)
                {
                    string value = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();
                    if (value.Length > 0)
                        adjAmounts.Add(double.Parse(value.Substring(1)));
                }

                Reports.TestStep = "Getting all amounts from Section M - Adjustment for Items sub section";
                List<double> dueAmounts = new List<double>();
                for (int i = 2; i < 10; i++)
                {
                    string value = FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 7, TableAction.GetText).Message.Clean();
                    if (value.Length > 0)
                        dueAmounts.Add(double.Parse(value.Substring(1)));
                }

                Reports.TestStep = "Getting total amount from Section M header";
                string sectionMTotal = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();

                double dueTotal = dueAmounts.Sum();
                double adjTotal = adjAmounts.Sum();
                double subSectionsTotal = dueTotal + adjTotal;

                Reports.TestStep = "Verifying amounts in Secion M";
                Reports.StatusUpdate(string.Format("Total displayed amount is: {0}", sectionMTotal), true);
                Reports.StatusUpdate(string.Format("Due Items calculated amount total is:  {0}", dueTotal.ToString().FormatAsMoney(true)), true);
                Reports.StatusUpdate(string.Format("Adjuntment for Items calculated amount total is:  {0}", adjTotal.ToString().FormatAsMoney(true)), true);
                Support.AreEqual(sectionMTotal, subSectionsTotal.ToString().FormatAsMoney(true), "Sec M Total Credits Verified");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 213053 CD Screen - Section M – Due to Seller at Closing-167931.
        [TestMethod]
        public void FTR5_ITR27_US_213053_TC_394594_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "USERSTORY 213053_TESTCASE_394594_SCENARIO1: Verify total amount when credit amount is available from M1 to M16 and credit payment method is either POC or other than POC..";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "NAVIGATE TO TERMSDATESSTATUS SCREEN.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("250.50" + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Setting Seller Credit in Adjustment Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", "Sale Price of Any Personal Property Included in Sale", "Seller Credit", TableAction.SetText, "212.00");

                Reports.TestStep = "Setting Seller Credit in Adjustment Miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", sellerCredit: 1533);

                Reports.TestStep = "Navigate to REB screen - Add GAB REBBroker Credits, Commission Amount";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("12");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Seller Listing Credit", sellerCredit: 23.09);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Adhoc Seller Broker 1", sellerCredit: 45.08);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Add Seller Credit in Assumption Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Escrow Charge Processes>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("188");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", sellerCredit: 249);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", sellerCredit: 42);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Add Seller Credit in New Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCredit: 640);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCredit: 460);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Add Seller Credit in New Loan 2 charge screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("314");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", sellerCredit: 54.25);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", sellerCredit: 45);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Navigate to Property Tax Check and Add GAB";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("234");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                Reports.TestStep = "Add Seller Credit in Property Tax Check screen";
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", sellerCredit: 12.20);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Proration Entry";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "09/21/2012", "09/21/2013", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/22/2013", "10/22/2014", "600.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "11/23/2014", "11/23/2015", "800", true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad().EnterProrationDetails(description: "Rents", fromDate: "08/28/2014", toDate: "08/28/2015", amount: "12600.00", creditSeller: true);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM.Click();

                Reports.TestStep = "Getting all credits from Due Items Table";
                List<double> creditsDue = new List<double>();
                for (int i = 2; i < 9; i++)
                {
                    string cred = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();
                    if (cred.Length > 0)
                        creditsDue.Add(double.Parse(cred.Replace("$", "").Replace(",", "")));
                }
                string DueItemsActualTotal = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(9, 3, TableAction.GetText).Message.Clean();
                if (DueItemsActualTotal.Length > 0)
                    creditsDue.Add(double.Parse(DueItemsActualTotal.Replace("$", "").Replace(",", "")));
                Reports.StatusUpdate("Due Items Actual: " + creditsDue.Sum().ToString().FormatAsMoney(true), true);

                Reports.TestStep = "Getting all credits from Due Adjustment for Items";
                List<double> creditsAdjustment = new List<double>();
                for (int i = 2; i < 9; i++)
                {
                    string cred = FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 7, TableAction.GetText).Message.Clean();
                    if (cred.Length > 0)
                        creditsAdjustment.Add(double.Parse(cred.Replace("$", "").Replace(",", "")));
                }
                string AdjustmentActualTotal = FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(9, 4, TableAction.GetText).Message.Clean();
                if (AdjustmentActualTotal.Length > 0)
                    creditsAdjustment.Add(double.Parse(AdjustmentActualTotal.Replace("$", "").Replace(",", "")));
                Reports.StatusUpdate("Adjustment for Items Actual: " + creditsAdjustment.Sum().ToString().FormatAsMoney(true), true);

                Reports.TestStep = "Verifying total credits";
                string actualSectionMTotal = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();
                string sectionMTotalFromUI = (creditsDue.Sum() + creditsAdjustment.Sum()).ToString().FormatAsMoney(true);
                if (actualSectionMTotal == sectionMTotalFromUI)
                    Support.AreEqual(actualSectionMTotal, sectionMTotalFromUI, "Sec M Total Credits Verified");
                else
                    Support.AreEqual(actualSectionMTotal, sectionMTotalFromUI, "Sec M Total Credits Verified not Equal");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR27_US_213053_TC_394598_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "USERSTORY 213053_TESTCASE_394598_SCENARIO2: Verify total amount  when no data entered from M1 to M16.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM.Click();

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                string sectionMDesc = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, 1, TableAction.GetText).Message;
                Support.AreEqual(sectionMDesc.Clean(), "M. Due to Seller at Closing");
                string sectionMAmt = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, 3, TableAction.GetText).Message;
                Support.AreEqual(sectionMAmt.Clean(), string.Empty, "Verify empty amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR27_US_213053_TC_394601_SC3()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "USERSTORY 213053_TESTCASE_394601_SCENARIO3: Verify total amount  when credits are available from M3 to M8  and payment method for all credits is POC.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //M05
                Reports.TestStep = "Add Seller Credit in Assumption Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Escrow Charge Processes>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("188");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", sellerCredit: 249);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("188");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", sellerCredit: 42);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //M07
                Reports.TestStep = "Add Seller Credit in New Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCredit: 640);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCredit: 460);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Seller Credit in New Loan 2 charge screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("314");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", sellerCredit: 54.25);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Navigate to Property Tax Check and Add GAB";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("234");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                Reports.TestStep = "Add Seller Credit in Property Tax Check screen";
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", sellerCredit: 12.20);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", sellerCredit: 12.20);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionM.Click();

                Reports.TestStep = "Getting all amounts from Section M - Due Items sub section";
                List<double> adjAmounts = new List<double>();
                int rowCount = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.GetRowCount();
                for (int i = 2; i <= rowCount; i++)
                {
                    string value = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();
                    if (value.Length > 0)
                        adjAmounts.Add(double.Parse(value.Substring(1)));
                }

                Reports.TestStep = "Getting total amount from Section M header";
                string sectionMTotal = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();

                double adjTotal = adjAmounts.Sum();

                Reports.TestStep = "Verifying Secion M Total";
                Support.AreEqual((adjTotal == 0) ? "" : adjTotal.ToString().FormatAsMoney(true), sectionMTotal);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 382375 CD Screen - Section M: Supplemental Credits for Section M
        [TestMethod]
        public void FTR5_ITR27_US_382375_TC_395170_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "USERSTORY 382375_TESTCASE_395170_SCENARIO1: Verify the display format of an Individual Credit with or without POC in Supplemental section M.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add Seller Credit in Assumption Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Escrow Charge Processes>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("188");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", sellerCredit: 249);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "At Closing" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("188");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", sellerCredit: 42);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "At Closing" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                //M07
                Reports.TestStep = "Add Seller Credit in New Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCredit: 640);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "Lender" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCredit: 460);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "Lender" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Adhoc New Loan 1", sellerCredit: 45.08);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                //M06
                Reports.TestStep = "Add Seller Credit in New Loan 2 charge screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("314");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", sellerCredit: 54.25);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //M08
                Reports.TestStep = "Navigate to Property Tax Check, add GAB and Seller Credit in Property Tax Check screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("234");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", sellerCredit: 12.20);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM, 5);
                FastDriver.ClosingDisclosure.SectionM.Click();

                bool supplementaryLinesShown = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(9, 1, TableAction.GetText).Message.Clean().Length > 0;
                if (supplementaryLinesShown)
                {
                    string expectedLineNumber = string.Empty;
                    for (int i = 10; i < FastDriver.ClosingDisclosure.SectionM_DueItemsTable.GetRowCount(); ++i)
                    {
                        string actualCreditLineNumber = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(2)")).Text.Clean();

                        string actualCreditFullDescription = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3)")).Text.Clean();

                        string actualCreditSmallDescription = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3) span:nth-child(1)")).Text.Clean();

                        string actualCreditPayeeDescription = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3) span:nth-child(2)")).Text.Clean();

                        string actualIndividualCredit = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();

                        string expectedCreditDesc = string.Empty, expectedPayeeNameLabel = string.Empty, expectedIndividualCredit = string.Empty, expectedFullDescription = string.Empty;

                        if (i == 10)
                        {
                            expectedLineNumber = "08a";
                            expectedFullDescription = "Adhoc New Loan 1  from Lenders Advantage A Division Of First American Title Ins. ".Clean();
                            expectedCreditDesc = "Adhoc New Loan 1  ".Clean();
                            expectedPayeeNameLabel = " from Lenders Advantage A Division Of First American Title Ins. ".Clean();
                            expectedIndividualCredit = "$45.08".Clean();
                        }
                        if (i == 11)
                        {
                            expectedLineNumber = "08b";
                            expectedFullDescription = "Tax Installment: Interest Due  from Prism Mortgage Company $12.20 P.O.C. ".Clean();
                            expectedCreditDesc = "Tax Installment: Interest Due  ".Clean();
                            expectedPayeeNameLabel = " from Prism Mortgage Company $12.20 P.O.C.".Clean();
                            expectedIndividualCredit = "";
                        }

                        if (actualCreditLineNumber.Length > 0)
                        {
                            Reports.TestStep = "Verify Individual credit line number";
                            Support.AreEqual(expectedLineNumber, actualCreditLineNumber, true);

                            if (actualCreditSmallDescription.Length > 0)
                            {
                                Reports.TestStep = "Verify Complete Description";
                                Support.AreEqual(expectedFullDescription, actualCreditFullDescription, true);
                                Reports.TestStep = "Verify Credit Description alone";
                                Support.AreEqual(expectedCreditDesc, actualCreditSmallDescription, true);
                                Reports.TestStep = "Verify Payee Name";
                                Support.AreEqual(expectedPayeeNameLabel, actualCreditPayeeDescription, true);
                                Reports.TestStep = "Verify Credit";
                                Support.AreEqual(expectedIndividualCredit.Clean(true), actualIndividualCredit.Clean(true), false);
                            }
                            else
                                Reports.StatusUpdate("Credit Description is not shown", false);
                        }
                    }
                }
                else
                    Reports.StatusUpdate("Supplemental line is not shown", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR27_US_382375_TC_395173_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "USERSTORY 382375_TESTCASE_395170_SCENARIO1: Verify the display format of an Individual Credit with or without POC in Supplemental section M.";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Setting Seller Credit in Adjustment Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Lease/Rent", sellerCredit: 212.00);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Security Deposit", sellerCredit: 312.00);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Setting Seller Credit in Adjustment Miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", sellerCredit: 1533);

                Reports.TestStep = "Add Seller Credit in Assumption Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Escrow Charge Processes>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("188");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", sellerCredit: 249);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("188");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", sellerCredit: 42);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Seller Credit in New Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCredit: 640);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Add Seller Credit in New Loan 2 charge screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("314");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", sellerCredit: 54.25);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.EnterPaymentDetails(new PaymentDetailsParameters() { SellerCreditPaymentMethod = "POC" });
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, chargeDescription: "Credit Report", sellerCredit: 99999999);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionM.Click();

                bool areSupplementaryLinesShown = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(9, 1, TableAction.GetText).Message.Clean().Length > 0;
                if (areSupplementaryLinesShown)
                {
                    string expectedLineNumber = string.Empty;

                    // *****To Verify Credit Group header *******************     
                    string actualDescriptionFullLine = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(10, 1, TableAction.GetText).Message.Clean();

                    Reports.TestStep = "Verify Group Credit Description line number";
                    string actualLineNumber = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(10, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(2)")).Text.Clean();
                    Support.AreEqual("08a", actualLineNumber);

                    Reports.TestStep = "Verify Group Credit Description";
                    string actualDescriptionOnly = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(10, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3)")).Text.Clean();
                    Support.AreEqual("New Loan 2 Credits", actualDescriptionOnly, true);

                    Reports.TestStep = "Verify Group Credit";
                    string actualCreditInDescription = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(10, 2, TableAction.GetText).Message.Clean();
                    Support.AreEqual("$99,999,999.00", actualCreditInDescription, true);

                    if (actualDescriptionFullLine.Length > 0)
                    {
                        // ***** To Verify Credits Under a Credit Group *******************
                        for (int i = 11; i < FastDriver.ClosingDisclosure.SectionM_DueItemsTable.GetRowCount(); i++)
                        {
                            string actualCreditGroupDescription = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetText).Message.Clean();
                            string actualCreditDescription = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3) span:nth-child(1)")).Text.Clean();
                            string actualPayeeDescription = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3) span:nth-child(2)")).Text.Clean();
                            string actualCrediLineNumber = string.Empty;
                            string actualCreditAmount = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();
                            bool creditIsBlank = actualCreditAmount.Length == 0;

                            string expectedCreditDesc = string.Empty, expectedPayeeNameLabel = string.Empty, expectedCreditAmount = string.Empty;

                            if (i == 11)
                            {
                                expectedCreditDesc = "Appraisal Fee";
                                expectedPayeeNameLabel = " from Smythe & Lee Jerome E. Lee $54.25 P.O.C.";
                                expectedCreditAmount = "";
                            }
                            if (i == 12)
                            {
                                expectedCreditDesc = "Credit Report";
                                expectedPayeeNameLabel = "  from Smythe & Lee Jerome E. Lee";
                                expectedCreditAmount = "$99,999,999.00";
                            }

                            bool individualCreditStartsWith8 = actualCreditGroupDescription.Substring(0, 2).StartsWith("8");
                            Reports.TestStep = "Verify Individual credit Line Number exists";
                            if (!individualCreditStartsWith8)
                            {
                                actualCrediLineNumber = "no line number";
                                Support.AreEqual("no line number", actualCrediLineNumber, true);
                            }
                            else
                            {
                                actualCrediLineNumber = "line number exists";
                                Support.AreEqual("no line number", actualCrediLineNumber, false);
                            }

                            if (actualCreditGroupDescription.Length > 0)
                            {
                                Reports.TestStep = "Verify Credit Description alone";
                                Support.AreEqual(expectedCreditDesc.Trim(), actualCreditDescription.Trim(), true);
                                Reports.TestStep = "Verify Payee Name ";
                                Support.AreEqual(expectedPayeeNameLabel.Trim(), actualPayeeDescription.Trim(), true);

                                if (actualPayeeDescription.Contains("P.O.C"))
                                {
                                    Reports.TestStep = "Verify Individual Credit for POC data ";
                                    Support.AreEqual(expectedCreditAmount, actualCreditAmount, false);
                                }
                                else
                                {
                                    Reports.TestStep = "Verify Individual Credit for other than POC data ";
                                    Support.AreEqual(expectedCreditAmount, actualCreditAmount, true);
                                }
                            }
                        }
                    }
                }
                else
                    Reports.StatusUpdate("Supplemental line is not shown", false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 393787 CD Screen – Section M: Provide ability to edit the Charge Description on lines M 02 to M 16
        [TestMethod]
        public void FTR5_ITR34_US_393787_TC_443525_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                String[] editedDescriptionsInCD = new String[25];
                #endregion

                Reports.TestDescription = "USERSTORY 393787_TESTCASE_443525_SCENARIO1:Section M: Verify the Charge Description in line M02 to M16 are editable when a charge setup is editable at ADM site. ";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //M01
                Reports.TestStep = "NAVIGATE TO TERMSDATESSTATUS SCREEN.";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("250.50"); Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                Reports.StatusUpdate(FastDriver.WebDriver.HandleDialogMessage(), true);
                FastDriver.BottomFrame.Done();

                //M02            
                Reports.TestStep = "Setting Seller Credit in Adjustment Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Sale Price of Any Personal Property Included in Sale", sellerCredit: 34.00);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                //M03
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Lease/Rent", sellerCredit: 1399);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                //M04 
                Reports.TestStep = "Setting Seller Credit in Adjustment Miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").WaitForScreenToLoad();
                FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", sellerCredit: 715);

                //M05 group
                Reports.TestStep = "Add Seller Credit in Assumption Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Escrow Charge Processes>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("234");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", sellerCredit: 1462);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", sellerCredit: 1904);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                //M06 group
                Reports.TestStep = "Setting Seller Charge in Assumptions Loan 2 screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Escrow Charge Processes>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("314");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab().WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", sellerCredit: 53);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", sellerCredit: 1772);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                //M08a, M08b
                Reports.TestStep = "Add Seller Credit in New Loan charge screen.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Principal Reduction Payment", sellerCredit: 1533);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesPrincipalReductiontable, "Construction Holdback", sellerCredit: 1533);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                //M07 group
                Reports.TestStep = "Add Seller Credit in New Loan 2 charge screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("314");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", sellerCredit: 257.75);
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.MortgageGABcode.FASetText("188");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.NewLoan.MortgageBrokerChargesTable, chargeDescription: "Credit Report", sellerCredit: 214.00);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, chargeDescription: "Tax Installment: Interest Due", sellerCredit: 214.00);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("234");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, chargeDescription: "Tax Installment: Amount", sellerCredit: 1914.00);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.TableCharges.Enter(FastDriver.PropertyTaxCheck.PropertyTaxesTable, chargeDescription: "Tax Installment: Partial Payment Amt", sellerCredit: 948.00);
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Proration Entry";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "09/21/2012", "09/21/2013", "200.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/22/2013", "10/22/2014", "600.00", true);
                FastDriver.BottomFrame.Done();
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "11/23/2014", "11/23/2015", "800", true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                FastDriver.ProrationTax.Rent1.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad().EnterProrationDetails(description: "Rents", fromDate: "08/28/2014", toDate: "08/28/2015", amount: "12600.00", creditSeller: true);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionM.Click();

                for (int i = 4; i < FastDriver.ClosingDisclosure.SectionM_DueItemsTable.GetRowCount(); ++i)
                {
                    int curline = i - 1;
                    bool isGroup = false;
                    string formattedLineNo = "0" + curline;

                    string editedDescription = string.Empty;

                    if (FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetText).Message.Length > 0)
                    {
                        string creditLineNo = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(2)")).Text.Clean();
                        if (creditLineNo.Length == 0)
                            Reports.StatusUpdate("No Line number shown after line" + curline, true);

                        if (FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3)")).Text.Clean().Length > 0) //Full description including payee Name 
                        {
                            Reports.TestStep = "Verifying line " + formattedLineNo;
                            IWebElement descriptionSpan = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3) span:nth-child(1)"));
                            string actualDescription = descriptionSpan.Text.Clean();
                            bool isContentEditable = descriptionSpan.GetAttribute("contenteditable") != null;

                            if (actualDescription.Length > 0)
                            {
                                if (actualDescription == "*")
                                {
                                    isContentEditable = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3) span:nth-child(2)")).GetAttribute("contenteditable") != null;
                                    isGroup = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 2, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(1)")).GetAttribute("id").Contains("imgGroupExpand");
                                }
                                if (actualDescription == "See attached page for additional information")
                                {
                                    string actualCreditAmount = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();
                                    Support.AreEqual("$4,609.00", actualCreditAmount, true); // updated bcause some business rules changed
                                    //Support.AreEqual("$5,262.00", actualCreditAmount, true);
                                }

                                if (isContentEditable && !isGroup) //SecMTable1.GetRow(i).GetChildren()[0].GetChildren()[2].GetChildren()[0].GetProperty("InnerText").ToString().Trim() == "*" //|| clas.Contains("descriptionWidth")  == true
                                {
                                    Reports.StatusUpdate(actualDescription + " in " + formattedLineNo + " is Editable in the CD Screen", true);
                                    editedDescription = actualDescription.Substring(0, 4) + "12345678901234567890123456789012345678901";
                                    FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3) span:nth-child(1)")).Click();
                                    Keyboard.SendKeys("^a");
                                    FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3) span:nth-child(1)")).FASetText(Keys.Delete + editedDescription);
                                    Keyboard.SendKeys(FAKeys.TabAway);
                                    Keyboard.SendKeys(FAKeys.TabAway);

                                    Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                    FastDriver.ClosingDisclosure.SectionM.Click();

                                    editedDescriptionsInCD[curline] = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(3) span:nth-child(1)")).Text.Clean();
                                    Support.AreEqual(editedDescription, editedDescriptionsInCD[curline]);

                                    if (i == 4)
                                    {
                                        FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                                        try
                                        {
                                            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", editedDescriptionsInCD[curline], "Description", TableAction.Click);
                                            Reports.StatusUpdate(editedDescription + " is updated and shown in sourcescreen", true);
                                        }
                                        catch (Exception)
                                        {
                                            Reports.StatusUpdate(editedDescription + " is not shown in source screen", false);
                                        }

                                        Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                        FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                        FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                        FastDriver.ClosingDisclosure.SectionM.Click();
                                    }

                                    if (i == 8)
                                    {
                                        Reports.TestStep = "Select first new loan instance from the table and remove it";
                                        FastDriver.LeftNavigation.Navigate<NewLoanSummary>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                                        FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Midwest Financial Group", "Name", TableAction.Click);

                                        Reports.TestStep = "Click on Remove button in New Loan Summary table";
                                        FastDriver.NewLoanSummary.Edit.FAClick();
                                        FastDriver.NewLoan.WaitForScreenToLoad().ClickChargesTab().WaitForLoanChargesTabToLoad();
                                        try
                                        {
                                            FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", editedDescriptionsInCD[curline], "Description", TableAction.Click);
                                            Reports.StatusUpdate(editedDescription + " is updated in sourcescreen", true);
                                        }
                                        catch (Exception)
                                        {
                                            Reports.StatusUpdate(editedDescription + " is not shown in source screen", false);
                                        }

                                        Reports.TestStep = "Verify the description in PDD screen";
                                        FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                                        FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                                        Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.PaymentDetailsDlg.DESCRPTION.FAGetValue().Clean());
                                        FastDriver.DialogBottomFrame.ClickDone();
                                        FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                                        FastDriver.BottomFrame.Done();

                                        Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                        FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                        FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                        FastDriver.ClosingDisclosure.SectionM.Click();
                                    }

                                    if (i == 10)
                                    {
                                        Reports.TestStep = "Select first new loan instance from the table and remove it";
                                        FastDriver.LeftNavigation.Navigate<NewLoanSummary>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                                        FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Name", "Midwest Financial Group", "Name", TableAction.Click);

                                        Reports.TestStep = "Click on Edit button in New Loan Summary table";
                                        FastDriver.NewLoanSummary.Edit.FAClick();
                                        FastDriver.NewLoan.WaitForScreenToLoad().ClickChargesTab().WaitForLoanChargesTabToLoad();
                                        try
                                        {
                                            FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction("Description", editedDescriptionsInCD[curline], "Description", TableAction.Click);
                                            Reports.StatusUpdate(editedDescription + " is updated in sourcescreen", true);
                                        }
                                        catch (Exception)
                                        {
                                            Reports.StatusUpdate(editedDescription + " is not shown in source screen", false);
                                        }

                                        FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
                                        FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                                        Reports.TestStep = "Verify the description in PDD screen";
                                        Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.PaymentDetailsDlg.DESCRPTION.FAGetValue().Clean());
                                        FastDriver.DialogBottomFrame.ClickDone();
                                        FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                                        FastDriver.BottomFrame.Done();

                                        Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                        FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                        FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                        FastDriver.ClosingDisclosure.SectionM.Click();
                                    }

                                    if (i == 14)
                                    {
                                        Support.AreEqual(editedDescription.Trim(), editedDescriptionsInCD[curline].Trim());
                                        FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();

                                        Reports.TestStep = "Select first instance from the table and Edit it";
                                        FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction("Name", "Mblo Funding, Inc.", "Name", TableAction.Click);

                                        Reports.TestStep = "Click on Edit button in Property Tax Summary table";
                                        FastDriver.PropertyTaxSummary.Edit.FAClick();
                                        try
                                        {
                                            FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", editedDescriptionsInCD[curline], "Description", TableAction.Click);
                                            Reports.StatusUpdate(editedDescription + " is updated in sourcescreen", true);
                                        }
                                        catch (Exception)
                                        {
                                            Reports.StatusUpdate(editedDescription + " is not shown in source screen", false);
                                        }

                                        Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                        FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                        FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                        FastDriver.ClosingDisclosure.SectionM.Click();
                                    }

                                    if (i == 16 || i == 17)
                                    {
                                        Reports.TestStep = "Select second instance from the table and Edit it";
                                        FastDriver.LeftNavigation.Navigate<PropertyTaxSummary>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                                        FastDriver.PropertyTaxSummary.SummaryTable.PerformTableAction("Name", "Prism Mortgage Company", "Name", TableAction.Click);

                                        Reports.TestStep = "Click on Edit button in Property Tax Summary table";
                                        FastDriver.PropertyTaxSummary.Edit.FAClick();
                                        try
                                        {
                                            FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", editedDescriptionsInCD[curline], "Description", TableAction.Click);
                                            Reports.StatusUpdate(editedDescription + " is updated in sourcescreen", true);
                                        }
                                        catch (Exception)
                                        {
                                            Reports.StatusUpdate(editedDescription + " is not shown in source screen", false);
                                        }

                                        Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                        FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                        FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                        FastDriver.ClosingDisclosure.SectionM.Click();
                                    }
                                }
                                else if (!isContentEditable || (!isContentEditable && actualDescription == "01" || actualDescription == "See attached page for additional information"))
                                    Reports.StatusUpdate("The Description: " + actualDescription + "in line" + actualDescription + "should not be editable in section M", true);
                                else if (isContentEditable == true && isGroup)
                                    Reports.StatusUpdate("Its a group description", true);
                                else if (isContentEditable != true && actualDescription.Length != 0)
                                    Reports.StatusUpdate("The Description: " + actualDescription + "is not editable in section M", false);
                                else if (actualDescription.Length == 0)
                                    Reports.StatusUpdate("The Description: is not shown", true);
                            }
                        }
                        else
                            Reports.StatusUpdate("No Description shown for line " + creditLineNo, true);
                    }
                }

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.SectionM.Click();

                for (int i = 2; i <= FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.GetRowCount(); ++i)
                {
                    int curline = i - 1;
                    string slno = "0" + curline;

                    if (FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 1, TableAction.GetText).Message.Clean().Length > 0)
                    {
                        string actualLineNumber = FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.CssSelector("span:nth-child(2)")).Text.Clean();
                        if (actualLineNumber.Length == 0)
                            Reports.StatusUpdate("No Line number shown after line" + curline, true);

                        string actualCreditDescription = FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 2, TableAction.GetText).Message.Clean();   //Full description 
                        if (actualCreditDescription.Length > 0)
                        {
                            Reports.TestStep = "Verifying line " + slno;
                            bool isContentEditable = FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 2, TableAction.GetCell).Element.FindElement(By.TagName("span")).GetAttribute("contenteditable") != null;

                            if (isContentEditable)
                            {
                                Reports.StatusUpdate("The Description: " + actualCreditDescription + " is Editable in the CD Screen", true);

                                string editedDescription = actualCreditDescription.Substring(0, 4) + "12345678901234567890123456789012345678901";
                                FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 2, TableAction.GetCell).Element.FindElement(By.TagName("span")).Click();
                                Keyboard.SendKeys("^a");
                                FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 2, TableAction.GetCell).Element.FindElement(By.TagName("span")).SendKeys(Keys.Delete + actualLineNumber + editedDescription);
                                Keyboard.SendKeys(FAKeys.TabAway);
                                Keyboard.SendKeys(FAKeys.TabAway);
                                editedDescriptionsInCD[curline] = FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 2, TableAction.GetCell).Element.FindElement(By.TagName("span")).Text.Clean();

                                if (i == 5)
                                {
                                    //Rents
                                    Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                                    FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                                    FastDriver.ProrationTax.Rent1.FAClick();
                                    FastDriver.ProrationTax.Edit.FAClick();
                                    FastDriver.ProrationDetail.WaitForScreenToLoad();
                                    Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.ProrationDetail.Description.FAGetValue());

                                    Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                    FastDriver.ClosingDisclosure.SectionM.Click();
                                }
                                if (i == 6)
                                {
                                    //wind Insurance
                                    Reports.TestStep = "Creating Proration charges in Escrow charge->WindInsurance";
                                    FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                                    FastDriver.InsuranceSummary.Wind.FAClick();
                                    FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                                    FastDriver.InsuranceWind.WaitForScreenToLoad();
                                    Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.InsuranceWind.WindDescription.FAGetValue());

                                    Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                    FastDriver.ClosingDisclosure.SectionM.Click();
                                }
                                if (i == 7)
                                {
                                    //Flood Insurance
                                    Reports.TestStep = "Creating Proration charges in Escrow charge->flood Insurance";
                                    FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                                    FastDriver.InsuranceSummary.Flood.FAClick();
                                    FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                                    FastDriver.Insuranceflood.WaitForScreenToLoad();
                                    Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.Insuranceflood.FloodDescription.FAGetValue());

                                    Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                    FastDriver.ClosingDisclosure.SectionM.Click();
                                }
                                if (i == 8)
                                {
                                    //Fire Insurance
                                    Reports.TestStep = "Creating Proration charges in Escrow charge->fire Insurance";
                                    FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                                    FastDriver.InsuranceSummary.Fire.FAClick();
                                    FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                                    FastDriver.InsuranceFire.WaitForScreenToLoad();
                                    Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.InsuranceFire.FireDescription.FAGetValue());

                                    Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                    FastDriver.ClosingDisclosure.SectionM.Click();
                                }
                                if (i == 10)
                                {
                                    //Earth quake Insurance
                                    Reports.TestStep = "Creating Proration charges in Escrow charge->EarthQuake Insurance";
                                    FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                                    FastDriver.InsuranceSummary.EarthQuake.FAClick();
                                    FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                                    FastDriver.InsuranceEarth.WaitForScreenToLoad();
                                    Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.InsuranceEarth.EarthCalculateDescription.FAGetValue());

                                    Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                    FastDriver.ClosingDisclosure.SectionM.Click();
                                }
                                if (i == 11)
                                {
                                    //HOA 
                                    Reports.TestStep = "Creating Proration charges in Escrow charge->homeowner association ";
                                    FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                                    Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.HomeownerAssociation.ProrationDescription.FAGetValue());

                                    Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                    FastDriver.ClosingDisclosure.SectionM.Click();
                                }
                                if (i == 12)
                                {
                                    //Rents
                                    Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                                    FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                                    FastDriver.ProrationTax.Rent1.FAClick();
                                    FastDriver.ProrationTax.Edit.FAClick();
                                    FastDriver.ProrationDetail.WaitForScreenToLoad();
                                    Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.ProrationDetail.Description.FAGetValue());

                                    Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                    FastDriver.ClosingDisclosure.SectionM.Click();
                                }
                                if (i == 13)
                                {
                                    // Utility Description
                                    Reports.TestStep = "Creating Proration charges in Escrow charge->Utility ";
                                    FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                                    Support.AreEqual(editedDescriptionsInCD[curline], FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue());

                                    Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                                    FastDriver.ClosingDisclosure.SectionM.Click();
                                }

                            }
                            else if (actualCreditDescription == "See attached page for additional information")
                                Reports.StatusUpdate("See attached page for additional information in line" + actualLineNumber + "should not be editable", true);
                            else if (!isContentEditable && actualCreditDescription.Length > 0)
                                Reports.StatusUpdate("The Description: " + actualCreditDescription + " is not setup as editable at admin", true);
                        }
                        else
                            Reports.StatusUpdate("No Description shown for line" + actualLineNumber, true);
                    }
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 391835 CD Screen - provide AUTO-SAVE instead of Save button to the CD screen.
        [TestMethod]
        public void FTR5_ITR41_US_391835_TC_458073()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "391835_TESTCASE_458073_CD Screen - provide AUTO-SAVE instead of Save button to the CD screen";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Setting Seller Credit in Adjusment Offset screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Lease/Rent", sellerCredit: 20000.2);

                Reports.TestStep = "Check the Charge entered in Adjustment Offset screen is reflected in CD section M";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();
                var lineDescription = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetCell).Element;
                var composedDescription = lineDescription.FindElement(OpenQA.Selenium.By.CssSelector("span:nth-child(3)"));
                var actualDescription = composedDescription.FindElement(OpenQA.Selenium.By.CssSelector("span:nth-child(1)"));
                string updatedDescription = "", actualDescriptionHelptext = "";

                if (lineDescription.Text.Length > 0)
                {
                    string lineNo = lineDescription.FindElement(OpenQA.Selenium.By.CssSelector("span:nth-child(2)")).Text.Clean();
                    if (lineNo.Length > 0) //verifies if there is any text in line numbers span
                    {
                        Support.AreEqual("03", lineNo, true);
                    }

                    actualDescriptionHelptext = actualDescription.GetAttribute("title").Clean();
                    if (actualDescriptionHelptext.Length > 0) //verifies if there is any text in the fee description span
                    {
                        Support.AreEqual("Assign Tenant Lease/Rent", actualDescriptionHelptext, "Credit description shown in help text");

                        bool descriptionEditable = actualDescription.GetAttribute("contenteditable") != null;
                        if (descriptionEditable)
                        {
                            Reports.StatusUpdate(string.Format("{0} in line {1} is editable in CD screen", actualDescription.GetAttribute("title").Clean(), lineNo), true);

                            updatedDescription = actualDescriptionHelptext.Substring(0, 4) + "123456789";
                            actualDescription.FAClick();
                            Keyboard.SendKeys("^A");
                            actualDescription.FASetText(updatedDescription);
                            Keyboard.SendKeys(FAKeys.TabAway);
                            Playback.Wait(1000); //wait for the autosave function to do its thing
                        }
                    }
                }

                Reports.TestStep = "Do not click on Done button, reload the page and verify Description edited in CD M03 is saved ";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();
                string newDesc = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetCell).Element
                    .FindElement(OpenQA.Selenium.By.CssSelector("span:nth-child(3) > span:nth-child(1)")).Text.Clean();
                Support.AreEqual(updatedDescription, newDesc);

                Reports.TestStep = "Verify Description edited in CD is reflected in source screen - Adjustment Offset";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", newDesc, "Description", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 393848 CD Screen - Section M - Ability to edit Charge Group Description
        [TestMethod]
        public void FTR5_ITR41_US_393848_IC_460795_SC3()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = " Edit Property Tax Group Description in Section M";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Entering Property Tax data";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("344");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", "Tax Installment: Interest Due", "Seller Credit", TableAction.SetText, "1" + Support.RandomString("NNN"));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", "Tax Installment: Amount", "Seller Credit", TableAction.SetText, "1" + Support.RandomString("NNN"));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Saving updated Description in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();
                string rowDescription = "Property Taxes new group description";
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetCell).Element.FindElement(OpenQA.Selenium.By.CssSelector("span:nth-child(3) > span:nth-child(2)")).FADoubleClick();
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys(" new group description");
                string cellText = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                if (cellText.Contains(rowDescription))
                    Reports.StatusUpdate("Group Description successfully updated: " + rowDescription, true);
                else
                    Reports.StatusUpdate(string.Format("Group Description not updated. Expected = {0}; Actual: {1}", rowDescription, cellText), false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying Group Description in pop up window After Saving The New Description";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.M03Plus, 5);
                FastDriver.ClosingDisclosure.M03Plus.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CDPopupTable, 5);
                cellText = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                if (cellText.Contains(rowDescription))
                    Reports.StatusUpdate("Group Description successfully updated in pop up window '" + rowDescription + "' found", true);
                else
                    Reports.StatusUpdate("Group Description not got updated in pop up Expected = " + rowDescription, false);
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR41_US_393848_TC_3460791_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = " Edit Property Tax Group Description in Section M";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Entering new loan data";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Appraisal Fee", "Seller Credit", TableAction.SetText, "1" + Support.RandomString("NNN"));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Credit Report", "Seller Credit", TableAction.SetText, "1" + Support.RandomString("NNN"));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Saving updated Description in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();
                string rowDescription = "New Loan 2 Credits new group description";
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetCell).Element.FindElement(OpenQA.Selenium.By.CssSelector("span:nth-child(3) > span:nth-child(2)")).FADoubleClick();
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys(" new group description");
                string cellText = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                if (cellText.Contains(rowDescription))
                    Reports.StatusUpdate("Group Description successfully updated: " + rowDescription, true);
                else
                    Reports.StatusUpdate(string.Format("Group Description not updated. Expected = {0}; Actual: {1}", rowDescription, cellText), false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying Group Description in pop up window After Saving The New Description";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.M03Plus, 5);
                FastDriver.ClosingDisclosure.M03Plus.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CDPopupTable, 5);
                cellText = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                if (cellText.Contains(rowDescription))
                    Reports.StatusUpdate("Group Description successfully updated in pop up window '" + rowDescription + "' found", true);
                else
                    Reports.StatusUpdate("Group Description not got updated in pop up Expected = " + rowDescription, false);
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR41_US_393848_TC_460787_SC1()
        {

            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = " Edit Assumption Loan  Description and Verify In Section M ";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Entering new loan data";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Escrow Charge Processes>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("344");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ClickChargesTab();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Saving updated Description in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();
                string rowDescription = "Assumption Loan 1 Credits new group description";
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetCell).Element.FindElement(OpenQA.Selenium.By.CssSelector("span:nth-child(3) > span:nth-child(2)")).FADoubleClick();
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys(" new group description");
                string cellText = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                if (cellText.Contains(rowDescription))
                    Reports.StatusUpdate("Group Description successfully updated: " + rowDescription, true);
                else
                    Reports.StatusUpdate(string.Format("Group Description not updated. Expected = {0}; Actual: {1}", rowDescription, cellText), false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying Group Description in pop up window After Saving The New Description";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.M03Plus, 5);
                FastDriver.ClosingDisclosure.M03Plus.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CDPopupTable, 5);
                cellText = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                if (cellText.Contains(rowDescription))
                    Reports.StatusUpdate("Group Description successfully updated in pop up window '" + rowDescription + "' found", true);
                else
                    Reports.StatusUpdate("Group Description not updated in pop up Expected = " + rowDescription, false);
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_IT9R41_US_393848_IC_460796_SC4()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                Reports.TestDescription = "Edit REB Group Description in Section M";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Entering REB data";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Escrow Charge Processes>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("344");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Description1", sellerCredit: 737.50);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("3444");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Escrow Charge Processes>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("344");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Description1", sellerCredit: 737.50);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("3444");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Saving updated Description in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();
                string rowDescription = "Real Estate Broker Credits new group description";
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetCell).Element.FindElement(OpenQA.Selenium.By.CssSelector("span:nth-child(3) > span:nth-child(2)")).FADoubleClick();
                Keyboard.SendKeys("{END}");
                Keyboard.SendKeys(" new group description");
                string cellText = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                if (cellText.Contains(rowDescription))
                    Reports.StatusUpdate("Group Description successfully updated: " + rowDescription, true);
                else
                    Reports.StatusUpdate(string.Format("Group Description not updated. Expected = {0}; Actual: {1}", rowDescription, cellText), false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying Group Description in pop up window After Saving The New Description";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.M03Plus, 5);
                FastDriver.ClosingDisclosure.M03Plus.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CDPopupTable, 5);
                cellText = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                if (cellText.Contains(rowDescription))
                    Reports.StatusUpdate("Group Description successfully updated in pop up window '" + rowDescription + "' found", true);
                else
                    Reports.StatusUpdate("Group Description not got updated in pop up Expected = " + rowDescription, false);
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 213055 CD Screen - Seller Calculations
        [TestMethod]
        public void FTR5_ITR34_US_213055_TC_431504_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");
                #endregion

                Reports.TestDescription = "Seller Calculations when m > n";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Creating data ...";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText("344");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.UtilityDetail.ProrationSellerCredit.FASetText("2" + Support.RandomString("NNN"));
                FastDriver.UtilityDetail.ProrationSellerCharge.FASetText("1" + Support.RandomString("NNN"));

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Verifying Section M Total charges in Calculations Section";
                string SectionMTotal = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();
                string SectionMCalculated = FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                SectionMCalculated = SectionMCalculated.Substring(SectionMCalculated.IndexOf('$'));
                if (SectionMTotal == SectionMCalculated)
                    Reports.StatusUpdate(string.Format("Sum of M section value is matching in calculation section. Value: {0}", SectionMTotal), true);
                else
                    Reports.StatusUpdate(string.Format("M section values are not matching. Actual = {0}, Expected = {1}", SectionMTotal, SectionMCalculated), false);

                Reports.TestStep = "Verifying Section N Total charges in Calculations Section";
                string SectionNTotal = FastDriver.ClosingDisclosure.SectionN_DueItemsTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();
                string SectionNCalculated = FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(3, 3, TableAction.GetText).Message.Clean();
                SectionNCalculated = SectionNCalculated.Substring(SectionNCalculated.IndexOf('$'));
                if (SectionNTotal == SectionNCalculated)
                    Reports.StatusUpdate(string.Format("Sum of N section value is matching in calculation section. Value: {0}", SectionNTotal), true);
                else
                    Reports.StatusUpdate(string.Format("N section values are not matching. Actual = {0}, Expected = {1}", SectionNTotal, SectionNCalculated), false);

                Reports.TestStep = "Verifying Cash To Close charges in Calculations Section";
                string CashToClose = FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(4, 3, TableAction.GetText).Message.Clean();
                CashToClose = CashToClose.Substring(CashToClose.IndexOf('$'));
                SectionMCalculated = SectionMCalculated.Replace("$", string.Empty).Replace(",", string.Empty);
                SectionNCalculated = SectionNCalculated.Replace("$", string.Empty).Replace(",", string.Empty);
                decimal totalM = decimal.Parse(SectionMCalculated);
                decimal totalN = decimal.Parse(SectionNCalculated);
                string diff = (totalM - totalN).ToString().FormatAsMoney(true);
                if (CashToClose == diff)
                    Reports.StatusUpdate(string.Format("Cash to Close value is matching in calculation section. Value: {0}", CashToClose), true);
                else
                    Reports.StatusUpdate(string.Format("Cash to Close value is not matching. Actual = {0}, Expected = {1}", CashToClose, diff), false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR34_US_213055_TC_431524_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");
                #endregion

                Reports.TestDescription = "Seller Calculations when m < n";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Creating data ...";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText("344");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.UtilityDetail.ProrationSellerCredit.FASetText("1" + Support.RandomString("NNN"));
                FastDriver.UtilityDetail.ProrationSellerCharge.FASetText("2" + Support.RandomString("NNN"));

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Verifying Section M Total charges in Calculations Section";
                string SectionMTotal = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();
                string SectionMCalculated = FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                SectionMCalculated = SectionMCalculated.Substring(SectionMCalculated.IndexOf('$'));
                if (SectionMTotal == SectionMCalculated)
                    Reports.StatusUpdate(string.Format("Sum of M section value is matching in calculation section. Value: {0}", SectionMTotal), true);
                else
                    Reports.StatusUpdate(string.Format("M section values are not matching. Actual = {0}, Expected = {1}", SectionMTotal, SectionMCalculated), false);

                Reports.TestStep = "Verifying Section N Total charges in Calculations Section";
                FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.Click();
                string SectionNTotal = FastDriver.ClosingDisclosure.SectionN_DueItemsTable.PerformTableAction(1, 3, TableAction.GetText).Message.Clean();
                string SectionNCalculated = FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(3, 3, TableAction.GetText).Message.Clean();
                SectionNCalculated = SectionNCalculated.Substring(SectionNCalculated.IndexOf('$'));
                if (SectionNTotal == SectionNCalculated)
                    Reports.StatusUpdate(string.Format("Sum of N section value is matching in calculation section. Value: {0}", SectionNTotal), true);
                else
                    Reports.StatusUpdate(string.Format("N section values are not matching. Actual = {0}, Expected = {1}", SectionNTotal, SectionNCalculated), false);

                Reports.TestStep = "Verifying Cash To Close charges in Calculations Section";
                string CashToClose = FastDriver.ClosingDisclosure.TransactionSummary_CalculationTable.PerformTableAction(4, 3, TableAction.GetText).Message.Clean();
                CashToClose = CashToClose.Substring(CashToClose.IndexOf('$'));
                SectionMCalculated = SectionMCalculated.Replace("$", string.Empty).Replace(",", string.Empty);
                SectionNCalculated = SectionNCalculated.Replace("$", string.Empty).Replace(",", string.Empty);
                decimal totalM = decimal.Parse(SectionMCalculated);
                decimal totalN = decimal.Parse(SectionNCalculated);
                string diff = (totalN - totalM).ToString().FormatAsMoney(true);
                if (CashToClose == diff)
                    Reports.StatusUpdate(string.Format("Cash to Close value is matching in calculation section. Value: {0}", CashToClose), true);
                else
                    Reports.StatusUpdate(string.Format("Cash to Close value is not matching. Actual = {0}, Expected = {1}", CashToClose, diff), false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 382324 CD Screen -Section M: Ability to display Credits as a Group
        [TestMethod]
        public void FTR5_ITR34_US_382324_TC_395276_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                string feeDescription = "* Assumption Loan 1 Credits";
                #endregion

                Reports.TestDescription = "Verify Collapse functionality of assumption";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Creating Credit Amount for Assumption Loan 1st Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("344");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Statement/Forwarding Fee", "Seller Credit", TableAction.SetText, string.Format("1{0}", Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Document Fee", "Seller Credit", TableAction.SetText, string.Format("1{0}", Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", "Late Charge", "Seller Credit", TableAction.SetText, string.Format("1{0}", Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Before expanding verifying the contents";
                string cellText1 = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                string lineNo1 = cellText1.Split()[0].Trim();
                cellText1 = cellText1.Substring(cellText1.IndexOf('*')).Clean();
                if (lineNo1 == "03")
                    Reports.StatusUpdate("The value Serial no is verifed: 03", true);
                else
                    Reports.StatusUpdate("The value Serial is not matching. Actual = " + lineNo1 + ", Expected = 03", false);

                if (cellText1.Clean() == feeDescription)
                    Reports.StatusUpdate("The value Desc is verifed: " + feeDescription, true);
                else
                    Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText1 + ", Expected = " + feeDescription, false);

                Reports.TestStep = "After colapse verifying the contents";
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                string cellText2 = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                string lineNo2 = cellText2.Split()[0].Trim();
                cellText2 = cellText2.Substring(cellText2.IndexOf('*')).Clean();
                if (lineNo2 == "03")
                    Reports.StatusUpdate("The value Serial no is verifed: 03", true);
                else
                    Reports.StatusUpdate("The value Serial is not matching. Actual = " + lineNo2 + ", Expected = 03", false);

                if (cellText2.Clean() == feeDescription)
                    Reports.StatusUpdate("The value Desc is verifed: " + feeDescription, true);
                else
                    Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText2 + ", Expected = " + feeDescription, false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR34_US_382324_TC_395295_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                string feeDescription = "* Property Taxes";
                #endregion

                Reports.TestDescription = "Verify Collapse functionality of property tax";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Entering property tax data";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("344");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Before expanding verifying the contents";
                string cellText1 = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                string lineNo1 = cellText1.Split()[0].Trim();
                cellText1 = cellText1.Substring(cellText1.IndexOf('*')).Clean();
                if (lineNo1 == "03")
                    Reports.StatusUpdate("The value Serial no is verifed: 03", true);
                else
                    Reports.StatusUpdate("The value Serial is not matching. Actual = " + lineNo1 + ", Expected = 03", false);

                if (cellText1.Clean() == feeDescription)
                    Reports.StatusUpdate("The value Desc is verifed: " + feeDescription, true);
                else
                    Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText1 + ", Expected = " + feeDescription, false);

                Reports.TestStep = "After colapse verifying the contents";
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                string cellText2 = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                string lineNo2 = cellText2.Split()[0].Trim();
                cellText2 = cellText2.Substring(cellText2.IndexOf('*')).Clean();
                if (lineNo2 == "03")
                    Reports.StatusUpdate("The value Serial no is verifed: 03", true);
                else
                    Reports.StatusUpdate("The value Serial is not matching. Actual = " + lineNo2 + ", Expected = 03", false);

                if (cellText2.Clean() == feeDescription)
                    Reports.StatusUpdate("The value Desc is verifed: " + feeDescription, true);
                else
                    Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText2 + ", Expected = " + feeDescription, false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR34_US_382324_TC_395282_SC3()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                fileRequest.File.TransactionTypeObjectCD = "ACCOMODAT";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                string feeDescription = "* New Loan 2 Credits";
                #endregion

                Reports.TestDescription = "Verify Collapse functionality of new loan";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Entering New Loan data";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                Reports.TestStep = "Entering Loan Charges data";
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Lender's Inspection Fee", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Before expanding verifying the contents";
                string cellText1 = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                string lineNo1 = cellText1.Split()[0].Trim();
                cellText1 = cellText1.Substring(cellText1.IndexOf('*')).Clean();
                if (lineNo1 == "03")
                    Reports.StatusUpdate("The value Serial no is verifed: 03", true);
                else
                    Reports.StatusUpdate("The value Serial is not matching. Actual = " + lineNo1 + ", Expected = 03", false);

                if (cellText1.Clean() == feeDescription)
                    Reports.StatusUpdate("The value Desc is verifed: " + feeDescription, true);
                else
                    Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText1 + ", Expected = " + feeDescription, false);

                Reports.TestStep = "After colapse verifying the contents";
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                string cellText2 = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                string lineNo2 = cellText2.Split()[0].Trim();
                cellText2 = cellText2.Substring(cellText2.IndexOf('*')).Clean();
                if (lineNo2 == "03")
                    Reports.StatusUpdate("The value Serial no is verifed: 03", true);
                else
                    Reports.StatusUpdate("The value Serial is not matching. Actual = " + lineNo2 + ", Expected = 03", false);

                if (cellText2.Clean() == feeDescription)
                    Reports.StatusUpdate("The value Desc is verifed: " + feeDescription, true);
                else
                    Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText2 + ", Expected = " + feeDescription, false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR34_US_382324_TC_395308_SC4()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                string feeDescription = "* Real Estate Broker Credits";
                #endregion

                Reports.TestDescription = "Verify Collapse functionality of REB";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Entering REB data";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("344");
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Ad Hoc Entry", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("3444");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("344");
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Ad Hoc Entry", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("3444");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("344");
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Ad Hoc Entry", sellerCredit: double.Parse("1" + Support.RandomString("NNN")));
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("3444");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Before expanding verifying the contents";
                string cellText1 = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                string lineNo1 = cellText1.Split()[0].Trim();
                cellText1 = cellText1.Substring(cellText1.IndexOf('*')).Clean();
                if (lineNo1 == "03")
                    Reports.StatusUpdate("The value Serial no is verifed: 03", true);
                else
                    Reports.StatusUpdate("The value Serial is not matching. Actual = " + lineNo1 + ", Expected = 03", false);

                if (cellText1.Clean() == feeDescription)
                    Reports.StatusUpdate("The value Desc is verifed: " + feeDescription, true);
                else
                    Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText1 + ", Expected = " + feeDescription, false);

                Reports.TestStep = "After colapse verifying the contents";
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                string cellText2 = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(4, 1, TableAction.GetText).Message.Clean();
                string lineNo2 = cellText2.Split()[0].Trim();
                cellText2 = cellText2.Substring(cellText2.IndexOf('*')).Clean();
                if (lineNo2 == "03")
                    Reports.StatusUpdate("The value Serial no is verifed: 03", true);
                else
                    Reports.StatusUpdate("The value Serial is not matching. Actual = " + lineNo2 + ", Expected = 03", false);

                if (cellText2.Clean() == feeDescription)
                    Reports.StatusUpdate("The value Desc is verifed: " + feeDescription, true);
                else
                    Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText2 + ", Expected = " + feeDescription, false);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 382060 CD Screen - Section M: Ability To Display credit that are part of group as individuals
        [TestMethod]
        public void FTR5_ITR34_US_382060_TC_395355_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> feeDescriptions = new List<string>();
                feeDescriptions.Add("Statement/Forwarding Fee");
                feeDescriptions.Add("Document Fee");
                feeDescriptions.Add("Late Charge");
                string feeSource = " from Brite Mortgage";

                Random random = new Random(Environment.TickCount);
                List<double> sellerCredits = new List<double>();
                for (int i = 0; i < 3; i++)
                    sellerCredits.Add((double)random.Next(1000, 2000));
                #endregion

                Reports.TestDescription = "Verify expand functionality of assumption";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Creating Credit Amount for Assumption Loan 1st Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("344");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", feeDescriptions[0], "Seller Credit", TableAction.SetText, sellerCredits[0].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", feeDescriptions[1], "Seller Credit", TableAction.SetText, sellerCredits[1].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", feeDescriptions[2], "Seller Credit", TableAction.SetText, sellerCredits[2].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Expanding group charges to individual";
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                for (int i = 0; i < 3; i++)
                {
                    feeDescriptions[i] = feeDescriptions[i] + feeSource;

                    Reports.TestStep = "Verifying line 0" + (i + 3) + " of section M";
                    FastDriver.ClosingDisclosure.ValidateSectionMDueItemsLine(i, feeDescriptions[i], sellerCredits[i]);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR34_US_382060_TC_395468_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> feeDescriptions = new List<string>();
                feeDescriptions.Add("Tax Installment: Interest Due");
                feeDescriptions.Add("Tax Installment: Amount");
                feeDescriptions.Add("Tax Installment: Penalty Due");
                string feeSource = " from Brite Mortgage";

                Random random = new Random(Environment.TickCount);
                List<double> sellerCredits = new List<double>();
                for (int i = 0; i < 3; i++)
                    sellerCredits.Add((double)random.Next(1000, 2000));
                #endregion

                Reports.TestDescription = "Verify expand functionality of property tax";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Entering property tax data";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("344");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(feeDescriptions[0], sellerCredit: sellerCredits[0]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(feeDescriptions[1], sellerCredit: sellerCredits[1]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(feeDescriptions[2], sellerCredit: sellerCredits[2]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Expanding group charges to individual";
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                for (int i = 0; i < 3; i++)
                {
                    feeDescriptions[i] = feeDescriptions[i] + feeSource;

                    Reports.TestStep = "Verifying line 0" + (i + 3) + " of section M";
                    FastDriver.ClosingDisclosure.ValidateSectionMDueItemsLine(i, feeDescriptions[i], sellerCredits[i]);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR34_US_382060_TC_395463_SC3()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> feeDescriptions = new List<string>();
                feeDescriptions.Add("Appraisal Fee");
                feeDescriptions.Add("Credit Report");
                feeDescriptions.Add("Lender's Inspection Fee");
                string feeSource = " from Brite Mortgage";

                Random random = new Random(Environment.TickCount);
                List<double> sellerCredits = new List<double>();
                for (int i = 0; i < 3; i++)
                    sellerCredits.Add((double)random.Next(1000, 2000));
                #endregion

                Reports.TestDescription = "Verify Collapse functionality of new loan";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Entering New Loan data";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, feeDescriptions[0], sellerCredit: sellerCredits[0]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, feeDescriptions[1], sellerCredit: sellerCredits[1]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, feeDescriptions[2], sellerCredit: sellerCredits[2]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Expanding group charges to individual";
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                for (int i = 0; i < 3; i++)
                {
                    feeDescriptions[i] = feeDescriptions[i] + feeSource;

                    Reports.TestStep = "Verifying line 0" + (i + 3) + " of section M";
                    FastDriver.ClosingDisclosure.ValidateSectionMDueItemsLine(i, feeDescriptions[i], sellerCredits[i]);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR34_US_382060_TC_395470_SC4()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> feeDescriptions = new List<string>();
                feeDescriptions.Add("Ad Hoc Entry");
                feeDescriptions.Add("Ad Hoc Entry");
                feeDescriptions.Add("Ad Hoc Entry");
                string feeSource = " from Brite Mortgage";

                Random random = new Random(Environment.TickCount);
                List<double> sellerCredits = new List<double>();
                for (int i = 0; i < 3; i++)
                    sellerCredits.Add((double)random.Next(1000, 2000));
                #endregion

                Reports.TestDescription = "Verify Collapse functionality of REB";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Entering REB data";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("344");
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits(feeDescriptions[0], sellerCredit: sellerCredits[0]);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("3444");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("344");
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits(feeDescriptions[1], sellerCredit: sellerCredits[1]);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("3444");
                FastDriver.BottomFrame.Done();
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.FindGAB("344");
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits(feeDescriptions[2], sellerCredit: sellerCredits[2]);
                Keyboard.SendKeys(FAKeys.TabAway); Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("3444");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Expanding group charges to individual";
                FastDriver.ClosingDisclosure.M03Expand.FAClick();
                for (int i = 0; i < 3; i++)
                {
                    feeDescriptions[i] = feeDescriptions[i] + feeSource;

                    Reports.TestStep = "Verifying line 0" + (i + 3) + " of section M";
                    FastDriver.ClosingDisclosure.ValidateSectionMDueItemsLine(i, feeDescriptions[i], sellerCredits[i]);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 381643 CD Screen - Section M: CD Screen - Section M: Display seller credit from line m3-m8
        [TestMethod]
        public void FTR5_ITR27_US_381643_TC_395481_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> descriptions = new List<string>();
                descriptions.Add("Assign Tenant Lease/Rent");
                descriptions.Add("Assign Tenant Security Deposit");
                descriptions.Add("Statement/Forwarding Fee");
                descriptions.Add("Appraisal Fee");
                descriptions.Add("Credit Report");
                descriptions.Add("Tax Installment: Interest Due");
                string feeSource = " from Brite Mortgage";

                Random random = new Random(Environment.TickCount);
                List<double> credits = new List<double>();
                for (int i = 0; i < 6; i++)
                    credits.Add((double)random.Next(1000, 2000));
                #endregion

                Reports.TestDescription = "Section M, line M3-M8 individual charge verification";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Creating Charges for Adjustments offset screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.UpdateOffsetCharges(descriptions[0], sellerCredit: credits[0]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges for Adjustments offset screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.UpdateOffsetCharges(descriptions[1], sellerCredit: credits[1]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering Assumption Loan data";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("344");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", descriptions[2], "Seller Credit", TableAction.SetText, credits[2].ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering New Loan data";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, descriptions[3], sellerCredit: credits[3]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, descriptions[4], sellerCredit: credits[4]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering property tax data";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("344");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(descriptions[5], sellerCredit: credits[5]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Verifying individual charges between line 3 to 8 of section m";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                for (int i = 0; i < 6; i++)
                {
                    if (i > 1) //update description from 3rd to 6th
                        descriptions[i] = descriptions[i] + feeSource;

                    Reports.TestStep = "Verifying line 0" + (i + 3) + " of section M";
                    FastDriver.ClosingDisclosure.ValidateSectionMDueItemsLine(i, descriptions[i], credits[i]);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR27_US_381643_TC_395483_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> descriptions = new List<string>();
                descriptions.Add("Statement/Forwarding Fee");
                descriptions.Add("Document Fee");
                descriptions.Add("Late Charge");
                descriptions.Add("Appraisal Fee");
                descriptions.Add("Credit Report");
                descriptions.Add("Lender's Inspection Fee");
                descriptions.Add("Tax Installment: Interest Due");
                descriptions.Add("Tax Installment: Amount");
                descriptions.Add("Assign Tenant Lease/Rent");

                Random random = new Random(Environment.TickCount);
                List<double> credits = new List<double>();
                for (int i = 0; i < 9; i++)
                    credits.Add((double)random.Next(1000, 2000));
                #endregion

                Reports.TestDescription = "Section M, line M3-M8 Group charges";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Creating Charges for Adjustments offset screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").WaitForScreenToLoad();
                FastDriver.AdjustmentOffset.UpdateOffsetCharges(descriptions[8], sellerCredit: credits[8]);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering Assumption Loan data";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("344");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", descriptions[0], "Seller Credit", TableAction.SetText, credits[0].ToString());
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", descriptions[1], "Seller Credit", TableAction.SetText, credits[1].ToString());
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", descriptions[2], "Seller Credit", TableAction.SetText, credits[2].ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering New Loan data";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, descriptions[3], sellerCredit: credits[3]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, descriptions[4], sellerCredit: credits[4]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, descriptions[5], sellerCredit: credits[5]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering property tax data";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("344");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(descriptions[6], sellerCredit: credits[6]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(descriptions[7], sellerCredit: credits[7]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();

                Reports.TestStep = "Verifying individual charges between line 3 to 8 of section m";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                List<string> groupDescriptions = new List<string>();
                groupDescriptions.Add("* Assumption Loan 1 Credits");
                groupDescriptions.Add("* New Loan 2 Credits");
                groupDescriptions.Add("* Property Taxes");

                List<double> expectedAmounts = new List<double>();
                expectedAmounts.Add(credits[0] + credits[1] + credits[2]);
                expectedAmounts.Add(credits[3] + credits[4] + credits[5]);
                expectedAmounts.Add(credits[6] + credits[7]);
                for (int i = 0; i < 3; i++)
                {
                    Reports.TestStep = "Verifying line 0" + (i + 4) + " of section M";
                    int rowIndex = i + 5; //since perform table action starts from 1, the 3rd row is the 4rd rendered because the table header counts as the first row
                    string expectedLineNumber = "0" + (rowIndex - 1); //normalize expected line number
                    string cellText = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(rowIndex, 1, TableAction.GetText).Message.Clean();

                    if (cellText.StartsWith(expectedLineNumber))
                        Reports.StatusUpdate(string.Format("The value Serial no is verifed: {0}", expectedLineNumber), true);
                    else
                        Reports.StatusUpdate("The value Serial is not matching. Cell text = " + cellText + ", Expected line number = " + expectedLineNumber, false);

                    if (cellText.Clean().Contains(groupDescriptions[i]))
                        Reports.StatusUpdate("The value Desc is verifed: " + groupDescriptions[i], true);
                    else
                        Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText + ", Expected = " + groupDescriptions[i], false);

                    string amount = FastDriver.ClosingDisclosure.SectionM_DueItemsTable.PerformTableAction(rowIndex, 3, TableAction.GetText).Message.Clean();
                    amount = amount.Replace(",", "").Replace("$", "");//normalize actual amount
                    string expectedAmount = expectedAmounts[i].ToString() + ".00"; //normalize expected amount
                    if (amount == expectedAmount)
                        Reports.StatusUpdate("The  value seller credit is  verifed. Actual=" + amount + " Expected=" + expectedAmount, true);
                    else
                        Reports.StatusUpdate("The value  seller credit not matching. Actual=" + amount + " Expected=" + expectedAmount, false);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 381646 CD Screen - Section M: CD Screen - Section M: View details of credit that are part of group
        [TestMethod]
        public void FTR5_ITR27_US_381646_TC_395475_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> descriptions = new List<string>();
                descriptions.Add("Statement/Forwarding Fee");
                descriptions.Add("Document Fee");
                descriptions.Add("Late Charge");
                string feeSource = " from Brite Mortgage";

                Random random = new Random(Environment.TickCount);
                List<double> credits = new List<double>();
                for (int i = 0; i < 3; i++)
                    credits.Add((double)random.Next(1000, 2000));
                #endregion

                Reports.TestDescription = "Section M, line M3-M8 individual charge verification";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Entering Assumption Loan data";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("344");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", descriptions[0], "Seller Credit", TableAction.SetText, credits[0].ToString());
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", descriptions[1], "Seller Credit", TableAction.SetText, credits[1].ToString());
                FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction("Description", descriptions[2], "Seller Credit", TableAction.SetText, credits[2].ToString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Validating the charges in CD Screen line M03 popup";
                FastDriver.ClosingDisclosure.M03Plus.FAClick();
                double creditTotal = credits.Sum();

                Reports.TestStep = "Validating the charges in header section of popup";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CDPopupTable, 5);
                string cellText = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean();
                if (cellText == "Seller Credits")
                    Reports.StatusUpdate("The header value seller credit is  verifed. Actual=" + cellText + " Expected=" + "Seller Credits" + " ", true);
                else
                    Reports.StatusUpdate("The value Description not matching. Actual=" + cellText + " Expected=" + "Seller Credits" + " ", false);

                string lineNo = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean();
                if (lineNo == "03")
                    Reports.StatusUpdate("The value line no is verifed. Actual=" + lineNo + " Expected=" + "03" + " ", true);
                else
                    Reports.StatusUpdate("The value not matching. Actual=" + lineNo + " Expected=" + "03" + " ", false);

                string expectedGroupDescription = "Assumption Loan 1 Credits";
                string actualGroupDesciption = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                if (actualGroupDesciption == expectedGroupDescription)
                    Reports.StatusUpdate("The value of group Description is verifed. Actual=" + actualGroupDesciption + " Expected=" + expectedGroupDescription + " ", true);
                else
                    Reports.StatusUpdate("The value group Description not matching. Actual=" + actualGroupDesciption + " Expected=" + expectedGroupDescription + " ", false);

                string actualSum = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                actualSum = actualSum.Replace(",", "").Replace("$", "").Trim();
                string expectedSum = creditTotal.ToString().Trim() + ".00";
                if (actualSum == expectedSum)
                    Reports.StatusUpdate("The value Avg Seller Credit in pop up is verified. Actual=" + actualSum + " Expected=" + expectedSum, true);
                else
                    Reports.StatusUpdate("The value Avg seller credit in pop up is not matching. Actual=" + actualSum + " Expected=" + expectedSum, false);

                Reports.TestStep = "Validating indivudual charges within pop up section";
                for (int i = 3; i <= FastDriver.ClosingDisclosure.CDPopupTable.GetRowCount(); i++)
                {
                    string actualChargeDescription = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();
                    string expectedChargeDescription = descriptions[i - 3] + feeSource;
                    if (actualChargeDescription == expectedChargeDescription)
                        Reports.StatusUpdate("The value desc is verifed. Actual=" + actualChargeDescription + " Expected=" + expectedChargeDescription, true);
                    else
                        Reports.StatusUpdate("The value Description not matching. Actual=" + actualChargeDescription + " Expected=" + expectedChargeDescription, false);

                    string actualChargeAmount = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(i, 6, TableAction.GetText).Message.Clean();
                    actualChargeAmount = actualChargeAmount.Replace(",", "").Replace("$", "");
                    string expectedChargeAmount = credits[i - 3].ToString() + ".00";
                    if (actualChargeAmount == expectedChargeAmount)
                        Reports.StatusUpdate("The value desc is verifed. Actual=" + actualChargeAmount + " Expected=" + expectedChargeAmount, true);
                    else
                        Reports.StatusUpdate("The value Description not matching. Actual=" + actualChargeAmount + " Expected=" + expectedChargeAmount, false);
                }
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR27_US_381646_TC_395475_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> descriptions = new List<string>();
                descriptions.Add("Appraisal Fee");
                descriptions.Add("Credit Report");
                descriptions.Add("Lender's Inspection Fee");
                string feeSource = " from Brite Mortgage";

                Random random = new Random(Environment.TickCount);
                List<double> credits = new List<double>();
                for (int i = 0; i < 3; i++)
                    credits.Add((double)random.Next(1000, 2000));

                double creditTotal = credits.Sum();
                string expectedGroupDescription = "New Loan 2 Credits";
                #endregion

                Reports.TestDescription = "Section M, line M3-M8 individual charge verification";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Entering New Loan data";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.ClickChargesTab().WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, descriptions[0], sellerCredit: credits[0]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, descriptions[1], sellerCredit: credits[1]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, descriptions[2], sellerCredit: credits[2]);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Validating the charges in CD Screen line M03 popup";
                FastDriver.ClosingDisclosure.M03Plus.FAClick();

                Reports.TestStep = "Validating the charges in header section of popup";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CDPopupTable, 5);
                string cellText = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean();
                if (cellText == "Seller Credits")
                    Reports.StatusUpdate("The header value seller credit is  verifed. Actual=" + cellText + " Expected=" + "Seller Credits" + " ", true);
                else
                    Reports.StatusUpdate("The value Description not matching. Actual=" + cellText + " Expected=" + "Seller Credits" + " ", false);

                string lineNo = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean();
                if (lineNo == "03")
                    Reports.StatusUpdate("The value line no is verifed. Actual=" + lineNo + " Expected=" + "03" + " ", true);
                else
                    Reports.StatusUpdate("The value not matching. Actual=" + lineNo + " Expected=" + "03" + " ", false);

                string actualGroupDesciption = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                if (actualGroupDesciption == expectedGroupDescription)
                    Reports.StatusUpdate("The value of group Description is verifed. Actual=" + actualGroupDesciption + " Expected=" + expectedGroupDescription + " ", true);
                else
                    Reports.StatusUpdate("The value group Description not matching. Actual=" + actualGroupDesciption + " Expected=" + expectedGroupDescription + " ", false);

                string actualSum = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                actualSum = actualSum.Replace(",", "").Replace("$", "").Trim();
                string expectedSum = creditTotal.ToString().Trim() + ".00";
                if (actualSum == expectedSum)
                    Reports.StatusUpdate("The value Avg Seller Credit in pop up is verified. Actual=" + actualSum + " Expected=" + expectedSum, true);
                else
                    Reports.StatusUpdate("The value Avg seller credit in pop up is not matching. Actual=" + actualSum + " Expected=" + expectedSum, false);

                Reports.TestStep = "Validating indivudual charges within pop up section";
                for (int i = 3; i <= FastDriver.ClosingDisclosure.CDPopupTable.GetRowCount(); i++)
                {
                    string actualChargeDescription = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();
                    string expectedChargeDescription = descriptions[i - 3] + feeSource;
                    if (actualChargeDescription == expectedChargeDescription)
                        Reports.StatusUpdate("The value desc is verifed. Actual=" + actualChargeDescription + " Expected=" + expectedChargeDescription, true);
                    else
                        Reports.StatusUpdate("The value Description not matching. Actual=" + actualChargeDescription + " Expected=" + expectedChargeDescription, false);

                    string actualChargeAmount = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(i, 6, TableAction.GetText).Message.Clean();
                    actualChargeAmount = actualChargeAmount.Replace(",", "").Replace("$", "");
                    string expectedChargeAmount = credits[i - 3].ToString() + ".00";
                    if (actualChargeAmount == expectedChargeAmount)
                        Reports.StatusUpdate("The value desc is verifed. Actual=" + actualChargeAmount + " Expected=" + expectedChargeAmount, true);
                    else
                        Reports.StatusUpdate("The value Description not matching. Actual=" + actualChargeAmount + " Expected=" + expectedChargeAmount, false);
                }
                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void FTR5_ITR27_US_381646_TC_395479_SC3()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> descriptions = new List<string>();
                descriptions.Add("Tax Installment: Interest Due");
                descriptions.Add("Tax Installment: Amount");
                string feeSource = " from Brite Mortgage";

                Random random = new Random(Environment.TickCount);
                List<double> credits = new List<double>();
                for (int i = 0; i < 2; i++)
                    credits.Add((double)random.Next(1000, 2000));

                string expectedSum = credits.Sum().ToString() + ".00";
                string expectedGroupDescription = "Property Taxes";
                #endregion

                Reports.TestDescription = "Section M, pro tax pop up verification";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Entering property tax data";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("344");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", descriptions[0], "Seller Credit", TableAction.SetText, credits[0].ToString()).Element.FindElement(OpenQA.Selenium.By.TagName("input")).FireEvent("onblur");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.PropertyTaxCheck.PropertyTaxesTable.PerformTableAction("Description", descriptions[1], "Seller Credit", TableAction.SetText, credits[1].ToString()).Element.FindElement(OpenQA.Selenium.By.TagName("input")).FireEvent("onblur");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_DueItemsTable, 5);
                FastDriver.ClosingDisclosure.SectionM_DueItemsTable.Click();

                Reports.TestStep = "Validating the charges in CD Screen line M03 popup";
                FastDriver.ClosingDisclosure.M03Plus.FAClick();

                Reports.TestStep = "Validating the charges in header section of popup";
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CDPopupTable, 5);
                string cellText = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean();
                if (cellText == "Seller Credits")
                    Reports.StatusUpdate("The header value seller credit is  verifed. Actual=" + cellText + " Expected=" + "Seller Credits" + " ", true);
                else
                    Reports.StatusUpdate("The value Description not matching. Actual=" + cellText + " Expected=" + "Seller Credits" + " ", false);

                string lineNo = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean();
                if (lineNo == "03")
                    Reports.StatusUpdate("The value line no is verifed. Actual=" + lineNo + " Expected=" + "03" + " ", true);
                else
                    Reports.StatusUpdate("The value not matching. Actual=" + lineNo + " Expected=" + "03" + " ", false);

                string actualGroupDesciption = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                if (actualGroupDesciption == expectedGroupDescription)
                    Reports.StatusUpdate("The value of group Description is verifed. Actual=" + actualGroupDesciption + " Expected=" + expectedGroupDescription + " ", true);
                else
                    Reports.StatusUpdate("The value group Description not matching. Actual=" + actualGroupDesciption + " Expected=" + expectedGroupDescription + " ", false);

                string actualSum = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean();
                actualSum = actualSum.Replace(",", "").Replace("$", "").Trim();
                if (actualSum == expectedSum)
                    Reports.StatusUpdate("The value Avg Seller Credit in pop up is verified. Actual=" + actualSum + " Expected=" + expectedSum, true);
                else
                    Reports.StatusUpdate("The value Avg seller credit in pop up is not matching. Actual=" + actualSum + " Expected=" + expectedSum, false);

                Reports.TestStep = "Validating property section aggregate charges";
                string aChar = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(3, 2, TableAction.GetText).Message.Clean();
                if (aChar == "a")
                    Reports.StatusUpdate("the value section  no is verifed." + "Actual=" + aChar + " Expected=" + "a" + " ", true);
                else
                    Reports.StatusUpdate("the value not matching." + "Actual=" + aChar + " Expected=" + "a" + " ", false);

                string actualDescription = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(3, 3, TableAction.GetText).Message.Clean();
                if (actualDescription == "Property Taxes 1")
                    Reports.StatusUpdate("the value group instance  is verifed." + "Actual=" + actualDescription + " Expected=" + "Property Taxes 1" + " ", true);
                else
                    Reports.StatusUpdate("the value not matching." + "Actual=" + actualDescription + " Expected=" + "Property Taxes 1" + " ", false);

                string actualAmount = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(3, 5, TableAction.GetText).Message.Clean();
                actualAmount = actualAmount.Replace(",", "").Replace("$", "");
                if (actualAmount == expectedSum)
                    Reports.StatusUpdate("the value amt aggregate is verifed." + "Actual=" + actualAmount + " Expected=" + expectedSum + " ", true);
                else
                    Reports.StatusUpdate("the value not verified." + "Actual=" + actualAmount + " Expected=" + expectedSum + " ", false);

                Reports.TestStep = "Validating indivudual charges within pop up section ";
                for (int i = 0; i <= FastDriver.ClosingDisclosure.CDPopupTable.GetRowCount() - 4; i++)
                {
                    descriptions[i] = descriptions[i] + feeSource;
                    int rowIndex = i + 4;
                    string individualDesc = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(rowIndex, 3, TableAction.GetText).Message.Clean();
                    if (individualDesc == descriptions[i])
                        Reports.StatusUpdate("the value desc is verifed." + "Actual=" + individualDesc + " Expected=" + descriptions[i], true);
                    else
                        Reports.StatusUpdate("the value Description not matching." + "Actual=" + individualDesc + " Expected=" + descriptions[i], false);

                    string individualAmount = FastDriver.ClosingDisclosure.CDPopupTable.PerformTableAction(rowIndex, 6, TableAction.GetText).Message.Clean();
                    individualAmount = individualAmount.Replace(",", "").Replace("$", "");
                    string expectedAmount = credits[i].ToString() + ".00";
                    if (individualAmount == expectedAmount)
                        Reports.StatusUpdate("The value seller credit is  verifed." + "Actual=" + individualAmount + " Expected=" + expectedAmount, true);
                    else
                        Reports.StatusUpdate("The value not matching." + "Actual=" + individualAmount + " Expected=" + expectedAmount, false);
                }

                FastDriver.ClosingDisclosure.K04PopupClose.FAClick();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 360040 CD Screen - Section M: CD Screen - Section M: Adjustments for Items Unpaid by Seller - Supplementary Charges
        [TestMethod]
        public void FTR5_ITR20_US_360040_TC_379738_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> descriptions = new List<string>();
                List<double> amounts = new List<double>();
                List<string> fromDates = new List<string>();
                List<string> toDates = new List<string>();

                List<string> credits = new List<string>();

                Random random = new Random(Environment.TickCount);
                for (int i = 0; i < 9; i++)
                {
                    string index = (i + 1).ToString();
                    descriptions.Add("DescriptionDetails " + index);
                    amounts.Add((double)random.Next(1000, 2000));
                    fromDates.Add("1/" + index + "/14");
                    toDates.Add("1/" + index + "/15");
                }
                #endregion

                Reports.TestDescription = "Section M: Add and edit supplementary charges";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                FastDriver.ProrationTax.New.FAClick();
                credits.Add(FastDriver.ProrationDetail.WaitForScreenToLoad().EnterProrationDetails(descriptions[0], fromDate: fromDates[0], toDate: toDates[0], amount: amounts[0].ToString(), creditSeller: true));
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").WaitForScreenToLoad();
                FastDriver.ProrationTax.New.FAClick();
                credits.Add(FastDriver.ProrationDetail.WaitForScreenToLoad().EnterProrationDetails(descriptions[1], fromDate: fromDates[1], toDate: toDates[1], amount: amounts[1].ToString(), creditSeller: true));
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Proration charges in Escrow charge->Utility ";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText("344");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.UtilityDetail.ProrationDescription.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(descriptions[2]);
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.UtilityDetail.Per.FASelectItem("MONTH");
                FastDriver.UtilityDetail.FromDate.FASetText(fromDates[2]);
                FastDriver.UtilityDetail.ToDate.FASetText(toDates[2]);
                FastDriver.UtilityDetail.ProrationAmount.FASetText(amounts[2].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue());
                FastDriver.BottomFrame.Done();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText("344");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.UtilityDetail.ProrationDescription.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(descriptions[3]);
                FastDriver.UtilityDetail.Per.FASelectItem("MONTH");
                FastDriver.UtilityDetail.FromDate.FASetText(fromDates[3]);
                FastDriver.UtilityDetail.ToDate.FASetText(toDates[3]);
                FastDriver.UtilityDetail.ProrationAmount.FASetText(amounts[3].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Proration charges in Escrow charge->hoeowner association ";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("344");
                FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(true);
                FastDriver.HomeownerAssociation.ProrationDescription.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.HomeownerAssociation.ProrationDescription.SendKeys(descriptions[4]);
                FastDriver.HomeownerAssociation.Per.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.FromDate.FASetText(fromDates[4]);
                FastDriver.HomeownerAssociation.ToDate.FASetText(toDates[4]);
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText(amounts[4].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(FastDriver.HomeownerAssociation.ProrationSellerCredit.FAGetValue());
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("344");
                FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(true);
                FastDriver.HomeownerAssociation.ProrationDescription.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.HomeownerAssociation.ProrationDescription.SendKeys(descriptions[5]);
                FastDriver.HomeownerAssociation.Per.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.FromDate.FASetText(fromDates[5]);
                FastDriver.HomeownerAssociation.ToDate.FASetText(toDates[5]);
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText(amounts[5].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(FastDriver.HomeownerAssociation.ProrationSellerCredit.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFYING SUPPLEMENTARY CHARGES ";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable, 5);
                FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.Click();
                FastDriver.ClosingDisclosure.ValidateSuplementaryChargesSectionM(true, descriptions, fromDates, toDates, credits);

                Reports.TestStep = "EDITING one of the supplementar line charges";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociationSummary.TableRow.FAClick();
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                amounts[5] = amounts[5] - 555.25;
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText(amounts[5].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits[5] = FastDriver.HomeownerAssociation.ProrationSellerCredit.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFYING SUPPLEMENTARY CHARGES ";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable, 5);
                FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.Click();
                FastDriver.ClosingDisclosure.ValidateSuplementaryChargesSectionM(true, descriptions, fromDates, toDates, credits);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 360038 CD Screen - Section M: CD Screen - Section M: Adjustments for Items Unpaid by Seller - Supplementary Line
        [TestMethod]
        public void FTR5_ITR20_US_360038_TC_380168_SC2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> descriptions = new List<string>();
                List<double> amounts = new List<double>();
                List<string> fromDates = new List<string>();
                List<string> toDates = new List<string>();

                List<double> credits = new List<double>();

                Random random = new Random(Environment.TickCount);
                for (int i = 0; i < 9; i++)
                {
                    string index = (i + 1).ToString();
                    descriptions.Add("DescriptionDetails " + index);
                    amounts.Add((double)random.Next(5500, 7000));
                    fromDates.Add("1/" + index + "/14");
                    toDates.Add("1/" + index + "/15");
                }
                #endregion

                Reports.TestDescription = "Section M supple lines, Add/remove";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                for (int i = 0; i < 2; i++)
                {
                    Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                    FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").WaitForScreenToLoad();
                    FastDriver.ProrationTax.New.FAClick();
                    //credits.Add(double.Parse());
                    FastDriver.ProrationDetail.WaitForScreenToLoad().EnterProrationDetails(descriptions[i], fromDate: fromDates[i], toDate: toDates[i], amount: amounts[i].ToString(), creditSeller: true);
                    FastDriver.BottomFrame.Done();
                }
                for (int i = 2; i < 4; i++)
                {
                    Reports.TestStep = "Creating Proration charges in Escrow charge->proration->miscellaneous Screen";
                    FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").WaitForScreenToLoad();
                    FastDriver.ProrationTax.New.FAClick();
                    //credits.Add(double.Parse());
                    FastDriver.ProrationDetail.WaitForScreenToLoad().EnterProrationDetails(descriptions[i], fromDate: fromDates[i], toDate: toDates[i], amount: amounts[i].ToString(), creditSeller: true);
                    FastDriver.BottomFrame.Done();
                }

                Reports.TestStep = "Creating Proration charges in Escrow charge->Utility ";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText("344");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.UtilityDetail.ProrationDescription.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(descriptions[4]);
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.UtilityDetail.Per.FASelectItem("MONTH");
                FastDriver.UtilityDetail.FromDate.FASetText(fromDates[4]);
                FastDriver.UtilityDetail.ToDate.FASetText(toDates[4]);
                FastDriver.UtilityDetail.ProrationAmount.FASetText(amounts[4].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(double.Parse(FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue()));
                FastDriver.BottomFrame.Done();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText("344");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.UtilityDetail.ProrationDescription.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(descriptions[5]);
                FastDriver.UtilityDetail.Per.FASelectItem("MONTH");
                FastDriver.UtilityDetail.FromDate.FASetText(fromDates[5]);
                FastDriver.UtilityDetail.ToDate.FASetText(toDates[5]);
                FastDriver.UtilityDetail.ProrationAmount.FASetText(amounts[5].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(double.Parse(FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue()));
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Proration charges in Escrow charge->hoeowner association ";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("344");
                FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(true);
                FastDriver.HomeownerAssociation.ProrationDescription.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.HomeownerAssociation.ProrationDescription.SendKeys(descriptions[6]);
                FastDriver.HomeownerAssociation.Per.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.FromDate.FASetText(fromDates[6]);
                FastDriver.HomeownerAssociation.ToDate.FASetText(toDates[6]);
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText(amounts[6].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(double.Parse(FastDriver.HomeownerAssociation.ProrationSellerCredit.FAGetValue()));
                FastDriver.BottomFrame.Done();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.BottomFrame.New();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.FindGABCode("344");
                FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(true);
                FastDriver.HomeownerAssociation.ProrationDescription.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.HomeownerAssociation.ProrationDescription.SendKeys(descriptions[7]);
                FastDriver.HomeownerAssociation.Per.FASelectItem("MONTH");
                FastDriver.HomeownerAssociation.FromDate.FASetText(fromDates[7]);
                FastDriver.HomeownerAssociation.ToDate.FASetText(toDates[7]);
                FastDriver.HomeownerAssociation.ProrationAmount.FASetText(amounts[7].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(double.Parse(FastDriver.HomeownerAssociation.ProrationSellerCredit.FAGetValue()));
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFYING SUPPLEMENTARY CHARGES ";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable, 5);
                FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.Click();
                FastDriver.ClosingDisclosure.ValidateSuplementaryLine(credits.Sum().ToString());

                Reports.TestStep = "EDITING one of the supplementar line charges";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociationSummary>("Home>Order Entry>Escrow Charge Processes>Homeowner Association").WaitForScreenToLoad();
                FastDriver.HomeownerAssociationSummary.TableRow.FAClick();
                FastDriver.HomeownerAssociationSummary.Edit.FAClick();
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                amounts[7] = amounts[7] - 5555.25;
                FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText(amounts[7].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(1000);
                string val = FastDriver.HomeownerAssociation.ProrationSellerCredit.FAGetValue().Clean();
                credits[3] = val != "?" && val != "" ? double.Parse(val) : 0;
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "VERIFYING SUPPLEMENTARY CHARGES ";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable, 5);
                FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.Click();
                FastDriver.ClosingDisclosure.ValidateSuplementaryLine(credits.Sum().ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region USERSTORY 360037 CD Screen - Section M: CD Screen - Section M: Adjustments for Items Unpaid by Seller - other proration charges
        [TestMethod]
        public void FTR5_ITR20_US_360037_TC_390694_SC1()
        {
            try
            {
                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].State = "AK";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "";
                fileRequest.File.Properties[0].PropertyAddress[0].Country = "USA";
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214");

                List<string> descriptions = new List<string>();
                List<double> amounts = new List<double>();
                List<string> fromDates = new List<string>();
                List<string> toDates = new List<string>();

                List<string> credits = new List<string>();

                Random random = new Random(Environment.TickCount);
                for (int i = 0; i < 9; i++)
                {
                    string index = (i + 1).ToString();
                    descriptions.Add("DescriptionDetails " + index);
                    amounts.Add((double)random.Next(5500, 7000));
                    fromDates.Add("1/" + index + "/14");
                    toDates.Add("1/" + index + "/15");
                }
                #endregion

                Reports.TestDescription = "Section M: Add/Edit Other proration Charges and verify";

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file";
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Creating Proration charges in Escrow charge->Utility ";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility").WaitForScreenToLoad();
                FastDriver.UtilityDetail.GABcode.FASetText("344");
                FastDriver.UtilityDetail.Find.FAClick();
                FastDriver.UtilityDetail.ProrationDescription.Click();
                Keyboard.SendKeys("{DEL}");
                FastDriver.UtilityDetail.ProrationDescription.SendKeys(descriptions[0]);
                FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true);
                FastDriver.UtilityDetail.Per.FASelectItem("MONTH");
                FastDriver.UtilityDetail.FromDate.FASetText(fromDates[0]);
                FastDriver.UtilityDetail.ToDate.FASetText(toDates[0]);
                FastDriver.UtilityDetail.ProrationAmount.FASetText(amounts[0].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Wind insurance charges";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                FastDriver.InsuranceWind.WindGABcode.FASetText("344");
                FastDriver.InsuranceWind.WindFind.FAClick();
                FastDriver.InsuranceWind.WindDescription.FAClick();
                Keyboard.SendKeys("{DEL}");
                FastDriver.InsuranceWind.WindDescription.SendKeys(descriptions[1]);
                FastDriver.InsuranceWind.WindCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceWind.WindPer.FASelectItem("MONTH");
                FastDriver.InsuranceWind.WindFromDate.FASetText(fromDates[1]);
                FastDriver.InsuranceWind.WindToDate.FASetText(toDates[1]);
                FastDriver.InsuranceWind.WindAmount.FASetText(amounts[1].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(FastDriver.InsuranceWind.WindSellerCredit1.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Flood insurance charges ";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                FastDriver.Insuranceflood.FloodGABcode.FASetText("344");
                FastDriver.Insuranceflood.FloodFind.FAClick();
                FastDriver.Insuranceflood.FloodDescription.FAClick();
                Keyboard.SendKeys("{DEL}");
                FastDriver.Insuranceflood.FloodDescription.SendKeys(descriptions[2]);
                FastDriver.Insuranceflood.FloodCreditSeller.FASetCheckbox(true);
                FastDriver.Insuranceflood.FloodPer.FASelectItem("MONTH");
                FastDriver.Insuranceflood.FloodFromDate.FASetText(fromDates[2]);
                FastDriver.Insuranceflood.FloodToDate.FASetText(toDates[2]);
                FastDriver.Insuranceflood.FloodAmount.FASetText(amounts[2].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(FastDriver.Insuranceflood.FloodSellerCredit1.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Fire insurance charges ";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                FastDriver.InsuranceFire.FireGABcode.FASetText("344");
                FastDriver.InsuranceFire.FireFind.FAClick();
                FastDriver.InsuranceFire.FireDescription.FAClick();
                Keyboard.SendKeys("{DEL}");
                FastDriver.InsuranceFire.FireDescription.SendKeys(descriptions[3]);
                FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceFire.FirePer.FASelectItem("MONTH");
                FastDriver.InsuranceFire.FireFromDate.FASetText(fromDates[3]);
                FastDriver.InsuranceFire.FireToDate.FASetText(toDates[3]);
                FastDriver.InsuranceFire.FireAmount.FASetText(amounts[3].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(FastDriver.InsuranceFire.FireSellerCredit1.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating EarthQuake insurance charges ";
                FastDriver.InsuranceSummary.WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                FastDriver.InsuranceEarth.EarthGABcode.FASetText("344");
                FastDriver.InsuranceEarth.EarthFind.FAClick();
                FastDriver.InsuranceEarth.EarthCalculateDescription.FAClick();
                Keyboard.SendKeys("{DEL}");
                FastDriver.InsuranceEarth.EarthCalculateDescription.SendKeys(descriptions[4]);
                FastDriver.InsuranceEarth.EarthCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceEarth.EarthCalculatePer.FASelectItem("MONTH");
                FastDriver.InsuranceEarth.EarthCalculateFromDate.FASetText(fromDates[4]);
                FastDriver.InsuranceEarth.EarthCalculateToDate.FASetText(toDates[4]);
                FastDriver.InsuranceEarth.EarthCalculateAmount.FASetText(amounts[4].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                credits.Add(FastDriver.InsuranceEarth.EarthSellerCredit1.FAGetValue());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying charges entered in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable, 5);
                FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.Click();
                FastDriver.ClosingDisclosure.ValidateSuplementaryChargesSectionM(false, descriptions, fromDates, toDates, credits);

                Reports.TestStep = "Removing  supplementar line charges";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryRemove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Editing one of the insurance charges ";
                descriptions[4] = "zDesc aaaa"; fromDates[4] = "3/3/12"; toDates[4] = "5/5/24"; amounts[4] = 4444.50;
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                FastDriver.InsuranceEarth.EarthGABcode.FASetText("344");
                FastDriver.InsuranceEarth.EarthFind.FAClick();
                FastDriver.InsuranceEarth.EarthCalculateDescription.FAClick();
                Keyboard.SendKeys("{DEL}");
                FastDriver.InsuranceEarth.EarthCalculateDescription.SendKeys(descriptions[4]);
                FastDriver.InsuranceEarth.EarthCreditSeller.FASetCheckbox(true);
                FastDriver.InsuranceEarth.EarthCalculatePer.FASelectItem("MONTH");
                FastDriver.InsuranceEarth.EarthCalculateFromDate.FASetText(fromDates[4]);
                FastDriver.InsuranceEarth.EarthCalculateToDate.FASetText(toDates[4]);
                FastDriver.InsuranceEarth.EarthCalculateAmount.FASetText(amounts[4].ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(200);
                credits[4] = FastDriver.InsuranceEarth.EarthSellerCredit1.FAGetValue();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verifying charges entered in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable, 5);
                FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.Click();
                FastDriver.ClosingDisclosure.ValidateSuplementaryChargesSectionM(false, descriptions, fromDates, toDates, credits);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
