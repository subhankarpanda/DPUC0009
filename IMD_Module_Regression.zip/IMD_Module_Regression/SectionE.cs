﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium;
using System.Collections.Generic;
using OpenQA.Selenium.Support.PageObjects;
using System.Reflection;
using System.Globalization;
using System.Linq.Expressions;
using SeleniumInternalHelpers;

namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest, DeploymentItem(@"Common/Utilities/AutoItX3.dll")]
    public class SectionE : FASTHelpers
    {
        [TestMethod]
        [Description("ADM_FeeSetup_RecordingFees")]
        public void ADM_FeeSetup_RecordingFees()
        {
            try
            {
                #region FAST Login ADM side
                Reports.TestStep = "Login to ADM";
                FAST_Login_ADM();
                #endregion

                Reports.TestStep = "Manually add Fee: E Recording Fee Mortgage1";
                Reports.TestStep = "Manually add Fee: FACC E Recording Fee - Mortgage2";
                Reports.TestStep = "Manually add Fee: FACC E Recording Fee Mortgage";
                Reports.TestStep = "Manually add Fee: Recording Fee - Mortgage2";
                Reports.TestStep = "Manually add Fee: E Recording Fee Deed1";
                Reports.TestStep = "Manually add Fee: E Recording Fee Deed2";
                Reports.TestStep = "Manually add Fee: FACC E Recording Fee Deed";
                Reports.TestStep = "Manually add Fee: FACC E Recording Fee Deed2";
                Reports.TestStep = "Manually add Fee: E Recording Fee Misc. 2";
                Reports.TestStep = "Manually add Fee: E Recording Fee Misc. description1";
                Reports.TestStep = "Manually add Fee: FACC E Recording Fee Misc. description";
                Reports.TestStep = "Manually add Fee: FACC E Recording Fee Misc. description2";
                Reports.TestStep = "Manually add Fee: E Recording Fee - Release1";
                Reports.TestStep = "Manually add Fee: E Recording Fee - Release2";
                Reports.TestStep = "Manually add Fee: FACC E Recording Fee - Release";
                Reports.TestStep = "Manually add Fee: FACC E Recording Fee - Release2";
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #region Section E: Non – FACC – Recording Fees

        [TestMethod]
        [Description("Fee Entry – Verify charges in Section E – Line 1 with all Recording Fee types.")]
        public void SectionE_Scenario1()
        {
            try
            {
                Reports.TestDescription = "Fee Entry – Verify charges in Section E – Line 1 with all Recording Fee types.";

                //  SectionE_Scenario1_1

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with New Loan Lender (214) and Mortgage Broker (BOA).";
                FAST_WCF_File_IIS(GAB: "BOA", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, LenderID: "214", SPAmt: 0);
                #endregion

                #region FAST add fee to file
                Reports.TestStep = "Navigate to Fee Entry screen. Select Recording Fee and Tax. Click on Add Fees and add above created Fees (Without Filters).";
                FAST_AddFileFees(new PDD[]{
                    new PDD() { ChargeDescription = "E Recording Fee Deed1", BuyerAtClosing = 98763.50, BuyerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "E Recording Fee Deed2", BuyerAtClosing = 2345.56, BuyerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "E Recording Fee Mortgage1", SellerPaidAtClosing = 234232.56, SellerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "E Recording Fee Misc. description1", BuyerAtClosing = 233232312.76, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 233232312.76, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "E Recording Fee Misc. 2", SellerPaidAtClosing = 89564.56, SellerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "E Recording Fee - Release1", BuyerAtClosing = 228.38, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 228.38, SellerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "E Recording Fee - Release2", BuyerAtClosing = 5600.00, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 4500.34, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "Recording Fee - Mortgage2", BuyerAtClosing = 3423.23, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 563224.34, SellerChargePaymentMethod = "Fee" }
                }, isTE: false);
                #endregion

                #region FAST verify CD Section E
                Reports.TestStep = "Navigate to CD screen and verify the values under Other Cost. Line E.01";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$233,342,673.43", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $101,109.06 Mortgage: $800,880.13", "$233,342,673.43", "", "$234,124,062.94", "", "", "", "" } }, displayLE: false);
                //  
                Reports.TestStep = "Click on + icon and verify if system displays all the Recording Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$101,109.06", "", "", "", "" }, { "E Recording Fee Deed1", "$98,763.50", "", "", "", "" }, { "E Recording Fee Deed2 to Bloom County Tax Authority", "$2,345.56", "", "", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$3,423.23", "", "", "", "" }, { "E Recording Fee Mortgage1 to Bloom County Tax Authority", "", "", "$234,232.56", "", "" }, { "Recording Fee - Mortgage2 to Payee Name updated", "$3,423.23", "", "$563,224.34", "", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$5,828.38", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$228.38", "", "$228.38", "", "" }, { "E Recording Fee - Release2", "$5,600.00", "", "$4,500.34", "", "" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$233,232,312.76", "", "", "", "" }, { "E Recording Fee Misc. 2 to Bloom County Tax Authority", "", "", "$89,564.56", "", "" }, { "E Recording Fee Misc. description1", "$233,232,312.76", "", "$233,232,312.76", "", "" } });
                //
                #endregion

                #region Verify CD - Good Faith Variance
                Reports.TestStep = "Select Good Faith Variance Screen and verify the values displayed under Good Faith Analysis 10% Category";
                FAST_VerifyGFaithVariance(cat0Table: null, cat10Table: new string[,] { { "E 01 Recording Fees", "$0", "$0.00", "$0.00", "$233,342,673.43" }, { "Total Aggregate Fees", "$0.00", "$233,342,673.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$0.00", "$233,342,673.43", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$233,342,673.43", "", "", "" } }, lenderCredits: null, increaseTotal: 233342673.43);
                #endregion

                #region Enter Loan Estimate Unrounded Amount
                Reports.TestStep = "Select CD tab. Enter Loan Estimate Unrounded Amount. (E.g. 434323.45)";
                FAST_UpdateRecTaxLEAmounts(new double[,] { { 434323.45, 434323 }, { 0, 0 } });
                #endregion
                
                #region Verify CD Section E - LE Amount
                Reports.TestStep = "Navigate to CD screen and verify CD Section E - LE Amount";
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 434323.45, LERounded: 434323);
                #endregion

                #region Verify CD - Good Faith Variance after setting LEUnrounded
                Reports.TestStep = "Select Good Faith Variance screen and verify if Loan Estimate values are displayed";
                FAST_VerifyGFaithVariance(cat0Table: null, cat10Table: new string[,] { { "E 01 Recording Fees", "$434,323", "$434,323.45", "$434,323.45", "$233,342,673.43" }, { "Total Aggregate Fees", "$434,323.45", "$233,342,673.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$232,908,349.98", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$232,864,917.98", "", "", "" } }, lenderCredits: null, increaseTotal: 0);
                #endregion

                //  SectionE_Scenario1_2

                #region Verify LE Amounts in OTC screen
                Reports.TestStep = "Navigate to OTC Screen and Verify if Loan Estimate Unrounded and Rounded are update in Recording Fees & Transfer Taxes Grid.";
                FAST_VerifyLEAmtOTC(new double[,] { { 434323.45, 434323 }, { 0, 0 } });
                #endregion

                #region Verify Loan Estimate Unrounded Amount in FileFee screen
                Reports.TestStep = "Select CD tab. Enter Loan Estimate Unrounded Amount. (E.g. 434323.45)";
                FAST_VerifyRecTaxLEAmounts(new double[,] { { 434323.45, 434323 }, { 0, 0 } });
                #endregion

                #region Edit LE Rounded amount in FileFee screen
                Reports.TestStep = @"Edit LE Rounded amount in FileFee screen and verify broken image link";
                FAST_UpdateRecTaxLEAmounts(new double[,] { { 434323.45, 5434323 }, { 0, 0 } }, recFeeRound: false);
                #endregion

                #region Edit Recording fees
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release1", 4, TableAction.SetText, "4564.56");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release1", 5, TableAction.SetText, "0");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release2", 4, TableAction.SetText, "67542.45");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee - Release2", 5, TableAction.SetText, "23243.34");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed1", 4, TableAction.SetText, "434.50");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed1", 5, TableAction.SetText, "565.50");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed2", 4, TableAction.SetText, "0");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Deed2", 5, TableAction.SetText, "23435.50");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. 2", 4, TableAction.SetText, "43534");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. 2", 5, TableAction.SetText, "87764");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. description1", 4, TableAction.SetText, "4342.23");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Misc. description1", 5, TableAction.SetText, "2343.78");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Mortgage1", 4, TableAction.SetText, "0");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Mortgage1", 5, TableAction.SetText, "0.56");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Recording Fee - Mortgage2", 4, TableAction.SetText, "0.34");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Recording Fee - Mortgage2", 5, TableAction.SetText, "0");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify if system displays modified values
                Reports.TestStep = "Navigate to CD Screen and verify if system displays modified values and if Pencil icon is displayed for Loan Estimate Rounded amount.";
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 434323.45, LERounded: 5434323, isRounded: false);
                #endregion

                #region FAST verify CD Section E
                Reports.TestStep = "Verify Recording fees in CD screen Section E";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$120,418.08", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $24,435.50 Mortgage: $0.90", "$120,418.08", "", "$137,352.68", "", "", "", "" } }, displayLE: false);
                //  
                Reports.TestStep = "Click on + icon and verify if system displays all the Recording Fees";
                FastDriver.ClosingDisclosure.ItemizedRecordingFeePlusIcon.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.divRecordingFee);
                FAST_VerifyRecordingFeesDeed(new string[,] { { "Recording Fee - Deed", "$434.50", "", "", "", "" }, { "E Recording Fee Deed1", "$434.50", "", "$565.50", "", "" }, { "E Recording Fee Deed2 to Bloom County Tax Authority", "", "", "$23,435.50", "", "" } });
                FAST_VerifyRecordingFeesMortgage(new string[,] { { "Recording Fee - Mortgage", "$0.34", "", "", "", "" }, { "E Recording Fee Mortgage1 to Bloom County Tax Authority", "", "", "$0.56", "", "" }, { "Recording Fee - Mortgage2 to Payee Name updated", "$0.34", "", "", "", "" } });
                FAST_VerifyRecordingFeesRelease(new string[,] { { "Recording Fee - Release", "$72,107.01", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$4,564.56", "", "", "", "" }, { "E Recording Fee - Release2", "$67,542.45", "", "$23,243.34", "", "" } });
                FAST_VerifyRecordingFeesMisc(new string[,] { { "Recording Fee - Miscellaneous", "$47,876.23", "", "", "", "" }, { "E Recording Fee Misc. 2 to Bloom County Tax Authority", "$43,534.00", "", "$87,764.00", "", "" }, { "E Recording Fee Misc. description1", "$4,342.23", "", "$2,343.78", "", "" } });
                FastDriver.ClosingDisclosure.RecordingFeeDone.FAClick();
                #endregion

                #region Verify CD - Good Faith Variance after setting LEUnrounded
                Reports.TestStep = "Select Good Faith Variance screen and verify if Loan Estimate values are displayed";
                FAST_VerifyGFaithVariance(cat0Table: null, cat10Table: new string[,] { { "E 01 Recording Fees", "$5,434,323", "$434,323.45", "$434,323.45", "$120,418.08" }, { "Total Aggregate Fees", "$434,323.45", "$120,418.08", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } }, lenderCredits: null, increaseTotal: 0);
                #endregion

                #region Edit fee payment details in FileFees screen
                Reports.TestStep = "Edit fee payment details in FileFees screen";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FAST_UpdateFileFeesPDD(paymentDetails: new PDD()
                {
                    ChargeDescription = "E Recording Fee - Release2",
                    LEDescription = "Modified LE Description",
                    PayeeName = "Modified Payee Name",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 34423.45,
                    BuyerChargePaymentMethod = "Fee",
                    BuyerBeforeClosing = 2234.55,
                    BuyerPaidbyOther = 7556.67,
                    BuyerPaidbyOtherPaymentMethod = "Mortgage Broker",
                    SellerPaidAtClosing = 7455.67,
                    SellerChargePaymentMethod = "Fee",
                    SellerPaidBeforeClosing = 5676.76,
                    SellerPaidbyOthers = 8756,
                    SellerPaidbyOtherPaymentMthd = "Mortgage Broker"
                }, isTE: false);
                FAST_UpdateFileFeesPDD(paymentDetails: new PDD()
                {
                    ChargeDescription = "E Recording Fee Deed2",
                    LEDescription = "Deed2 Modified LE Description",
                    PayeeName = "Deed2 Modified Payee Name",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 1500.87,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 4565.50,
                    BuyerPaidbyOther = 3345.50,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    SellerPaidAtClosing = 4544.49,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 34534.51,
                    SellerPaidbyOthers = 9243.50,
                    SellerPaidbyOtherPaymentMthd = "POC"
                }, isTE: false);
                FAST_UpdateFileFeesPDD(paymentDetails: new PDD()
                {
                    ChargeDescription = "E Recording Fee Misc. description1",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 0,
                    BuyerChargePaymentMethod = "Fee",
                    BuyerLenderCheckbox = true,
                    SellerPaidAtClosing = 34423.56,
                    SellerChargePaymentMethod = "Fee",
                    SellerPaidBeforeClosing = 45344.56,
                    SellerPaidbyOthers = 342323.45,
                    SellerPaidbyOtherPaymentMthd = "Lender",
                    SellerLenderCheckbox = true,
                }, isTE: false);
                FAST_UpdateFileFeesPDD(paymentDetails: new PDD()
                {
                    ChargeDescription = "Recording Fee - Mortgage2",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 560,
                    BuyerChargePaymentMethod = "Fee",
                    BuyerBeforeClosing = 670,
                    BuyerPaidbyOther = 345.44,
                    BuyerPaidbyOtherPaymentMethod = "Lender",
                    BuyerLenderCheckbox = false,
                    SellerPaidAtClosing = 0,
                    SellerChargePaymentMethod = "Fee",
                }, isTE: false);
                #endregion

                #region Verify if system displays modified values
                Reports.TestStep = "Navigate to CD Screen and verify if system displays modified values and if Pencil icon is displayed for Loan Estimate Rounded amount.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { " E.  Taxes and Other Government Fees", "$92,487.43", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $49,490.87 Mortgage: $1,576.00", "$85,017.38", "$7,470.05", "$134,753.78", "$85,555.83", "$11,247.61", "$434,323.45", "$5,434,323.00" } }, displayLE: true);
                //  
                Reports.TestStep = "Click on + icon and verify if system displays all the Recording Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$6,500.87", "", "", "", "" }, { "Deed2 Modified LE Description to Deed2 Modified Payee Name", "$1,500.87", "$4,565.50", "$4,544.49", "$34,534.51", "$3,345.50" }, { "E Recording Fee Deed1", "$434.50", "", "$565.50", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$1,230.00", "", "", "", "" }, { "E Recording Fee Mortgage1 to Bloom County Tax Authority", "", "", "$0.56", "", "" }, { "Recording Fee - Mortgage2 to Payee Name updated", "$560.00", "$670.00", "", "", "$345.44" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$41,222.56", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$4,564.56", "", "", "", "" }, { "Modified LE Description to Modified Payee Name", "$34,423.45", "$2,234.55", "$7,455.67", "$5,676.76", "$7,556.67" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$43,534.00", "", "", "", "" }, { "E Recording Fee Misc. 2 to Bloom County Tax Authority", "$43,534.00", "", "$87,764.00", "", "" }, { "E Recording Fee Misc. description1", "", "", "$34,423.56", "$45,344.56", "" } });
                #endregion

                #region Verify Total sum of E section should be displayed under I and J
                Reports.TestStep = "Total sum of E section should be displayed under I and J.";
                FAST_VerifyOtherCosts(sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$92,487.43", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$85,017.38", "$7,470.05", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$92,487.43", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$85,017.38", "$7,470.05", "$134,753.78", "$85,555.83", "$11,247.61" } },
                    displayLE: false);
                #endregion

                #region Verify CD - Good Faith Variance after modifying fee payment details
                Reports.TestStep = "Verify CD - Good Faith Variance after modifying fee payment details";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits  (See Lender Credit Analysis)", "$0", "-$7,902.11", "$0.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } }, cat10Table: new string[,] { { "E 01 Recording Fees", "$5,434,323", "$434,323.45", "$434,323.45", "$92,487.43" }, { "Total Aggregate Fees", "$434,323.45", "$92,487.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } }, lenderCredits: null, increaseTotal: 0);
                #endregion

                #region Edit and Verify Loan Estimate Unrounded Amount in CD Section E
                Reports.TestStep = "Select Closing Disclosure tab. Enter Loan Estimate unrounded amount. (E.g. 5,345.56)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 5345.56, 5346 }, { 0, 0 } }, recFeeRound: true);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 5345.56, LERounded: 5346, isRounded: true);
                #endregion

                #region Verify Good Faith Variance table
                Reports.TestStep = @"Select Good Faith Variance tab and verify the values displayed under Good Faith Variance 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits  (See Lender Credit Analysis)", "$0", "-$7,902.11", "$0.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } }, cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$92,487.43" }, { "Total Aggregate Fees", "$5,345.56", "$92,487.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$87,141.87", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$86,606.87", "", "", "" } }, lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "E 01 Recording Fees", "-$7,902.11" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$7,902.11" } }, increaseTotal: 0);
                #endregion

                #region Verify LE amounts in FileFees screen
                FAST_VerifyRecTaxLEAmounts(new double[,] { { 5345.56, 5346 }, { 0, 0 } });
                #endregion

                #region Pay Recording/Tax
                Reports.TestStep = @"Click on Pay Recording/Tax button and add new Payees. (E.g. 415)";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.PayRecordingTax.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad();
                FastDriver.RecordFeeTransferTaxDisb.New.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.GABcode.FASetText("415");
                FastDriver.RecordFeeTransferTaxDisb.Find.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitCreation(FastDriver.RecordFeeTransferTaxDisb.GABLabel, 5);
                FastDriver.RecordFeeTransferTaxDisb.None.Click();
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, "E Recording Fee - Release2", 1, TableAction.On);
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, "E Recording Fee Deed1", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Edit Mortgage Fee charges
                Reports.TestStep = @"Updated amounts for E Recording Fee Mortgage1 => $0.00";
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Mortgage1", 4, TableAction.SetText, "0");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "E Recording Fee Mortgage1", 5, TableAction.SetText, "0");
                Reports.TestStep = @"Uncheck Recording Fee - Mortgage2.";
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Recording Fee - Mortgage2", 1, TableAction.Off);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
                Reports.TestStep = @"Navigate to New Loan - Loan Charges then enter Buyer Credit Amount and LE for Non-Specific Lender Credits.";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "56734", "", "", "34534" } });
                #endregion

                #region Verify CD Section E, I, J
                Reports.TestStep = "Verify CD Other Costs table for Section E, I, J";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$91,257.43", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $49,490.87 Mortgage:", "$84,457.38", "$6,800.05", "$134,753.22", "$85,555.83", "$10,902.17", "$5,345.56", "$5,346.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$91,257.43", "", "", "", "", }, { "Other Costs Subtotals (E + F + G + H)", "$84,457.38", "$6,800.05", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$34,523.43", "", "", "", "", }, { "Closing Costs Subtotals (D + I)", "$84,457.38", "$6,800.05", "$134,753.22", "$85,555.83", "$10,902.17" }, { "Lender Credits", "-$56,734.00", "", "", "", "" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Recording Fees Itemization
                Reports.TestStep = "Verify CD Other Costs table for Section E - Recording Fees Itemization";
                FastDriver.ClosingDisclosure.ItemizedRecordingFeePlusIcon.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.divRecordingFee);
                FAST_VerifyRecordingFeesDeed(new string[,] { { "Recording Fee - Deed", "$6,500.87", "", "", "", "" }, { "Deed2 Modified LE Description  to Deed2 Modified Payee Name", "$1,500.87", "$4,565.50", "$4,544.49", "$34,534.51", "$3,345.50" }, { "E Recording Fee Deed1 to Continental Mortgage", "$434.50", "", "$565.50", "", "" } });
                FAST_VerifyRecordingFeesRelease(new string[,] { { "Recording Fee - Release", "$41,222.56", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$4,564.56", "", "", "", "" }, { "Modified LE Description to Continental Mortgage", "$34,423.45", "$2,234.55", "$7,455.67", "$5,676.76", "$7,556.67" } });
                FAST_VerifyRecordingFeesMisc(new string[,] { { " Recording Fee - Miscellaneous", "$43,534.00", "", "", "", "" }, { "E Recording Fee Misc. 2 to Bloom County Tax Authority", "$43,534.00", "", "$87,764.00", "", "" }, { "E Recording Fee Misc. description1", "", "", "$34,423.56", "$45,344.56", "" } });
                FastDriver.ClosingDisclosure.RecordingFeeDone.FAClick();
                #endregion

                #region Verify Good Faith Variance table
                Reports.TestStep = @"Verify the values displayed under Good Faith Variance 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits  (See Lender Credit Analysis)", "-$34,534", "-$64,290.67", "-$34,534.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } }, cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$91,257.43" }, { "Total Aggregate Fees", "$5,345.56", "$91,257.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$85,911.87", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$85,376.87", "", "", "" } }, lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$56,734.00" }, { "Specific Lender Credits", "" }, { "E 01 Recording Fees", "-$7,556.67" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$64,290.67" } }, increaseTotal: 85376.87);
                #endregion

                #region Modify Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
                Reports.TestStep = @"Navigate to New Loan - Loan Charges then enter Buyer Credit Amount and LE for Non-Specific Lender Credits.";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "56734", "", "", "134534.50" } });
                #endregion

                #region Modify fee Payment Details
                Reports.TestStep = "Modify fee Payment Details";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FAST_UpdateFileFeesPDD(paymentDetails: new PDD()
                {
                    ChargeDescription = "E Recording Fee Deed1",
                    LEDescription = "E Recording Fee Deed LEDesc.",
                    PayeeName = "First American Financial Corporation",
                    PartOfCheckbox = false,
                    BuyerAtClosing = 434.50,
                    BuyerChargePaymentMethod = "Check",
                    SellerPaidAtClosing = 565.50,
                    SellerChargePaymentMethod = "Check",
                }, isTE: false);
                FAST_UpdateFileFeesPDD(paymentDetails: new PDD()
                {
                    ChargeDescription = "E Recording Fee - Release2",
                    LEDescription = "Modified LE Description",
                    PayeeName = "First American",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 34423.45,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 2234.55,
                    BuyerPaidbyOther = 7556.67,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    SellerPaidAtClosing = 7455.67,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 5676.76,
                    SellerPaidbyOthers = 8756.00,
                    SellerPaidbyOtherPaymentMthd = "POC"
                }, isTE: false);
                FAST_UpdateFileFeesPDD(paymentDetails: new PDD()
                {
                    ChargeDescription = "E Recording Fee Misc. description1",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 0,
                    BuyerChargePaymentMethod = "Fee",
                    SellerPaidAtClosing = 34423.56,
                    SellerChargePaymentMethod = "Fee",
                    SellerPaidBeforeClosing = 45344.56,
                    SellerPaidbyOthers = 342323.45,
                    SellerPaidbyOtherPaymentMthd = "Lender",
                    SellerLenderCheckbox = false
                }, isTE: false);
                #endregion

                #region Verify CD Section E, I, J
                Reports.TestStep = "Verify CD Other Costs table for Section E, I, J";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$91,257.43", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $49,490.87 Mortgage:", "$84,457.38", "$6,800.05", "$134,753.22", "$85,555.83", "$10,902.17", "$5,345.56", "$5,346.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$91,257.43", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$84,457.38", "$6,800.05", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$34,523.43", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$84,457.38", "$6,800.05", "$134,753.22", "$85,555.83", "$10,902.17" }, { "Lender Credits", "-$56,734.00", "", "", "", "" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Recording Fees Itemization
                Reports.TestStep = "Verify CD Other Costs table for Section E - Recording Fees Itemization";
                FastDriver.ClosingDisclosure.ItemizedRecordingFeePlusIcon.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.divRecordingFee);
                FAST_VerifyRecordingFeesDeed(new string[,] { { "Recording Fee - Deed", "$6,500.87", "", "", "", "" }, { "Deed2 Modified LE Description  to Deed2 Modified Payee Name", "$1,500.87", "$4,565.50", "$4,544.49", "$34,534.51", "$3,345.50" }, { "E Recording Fee Deed LEDesc. to First American Financial", "$434.50", "", "$565.50", "", "" } });
                FAST_VerifyRecordingFeesRelease(new string[,] { { "Recording Fee - Release", "$41,222.56", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$4,564.56", "", "", "", "" }, { "Modified LE Description to First American", "$34,423.45", "$2,234.55", "$7,455.67", "$5,676.76", "$7,556.67" } });
                FAST_VerifyRecordingFeesMisc(new string[,] { { " Recording Fee - Miscellaneous", "$43,534.00", "", "", "", "" }, { "E Recording Fee Misc. 2 to Bloom County Tax Authority", "$43,534.00", "", "$87,764.00", "", "" }, { "E Recording Fee Misc. description1", "", "", "$34,423.56", "$45,344.56", "" } });
                FastDriver.ClosingDisclosure.RecordingFeeDone.FAClick();
                #endregion

                #region Verify Good Faith Variance table
                Reports.TestStep = @"Verify the values displayed under Good Faith Variance 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits  (See Lender Credit Analysis)", "-$134,535", "-$56,734.00", "-$134,534.50", "$77,800.50" }, { "Increase in Closing Costs above legal limits - 0% Category", "$77,800.50", "", "", "" } }, 
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$91,257.43" }, { "Total Aggregate Fees", "$5,345.56", "$91,257.43", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$85,911.87", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$85,376.87", "", "", "" } }, lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$56,734.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$56,734.00" } }, 
                    increaseTotal: 163177.37);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("OTC – Verify charges in Section E – Line 1 with all Recording Fee types")]
        public void SectionE_Scenario2()
        {
            try
            {
                Reports.TestDescription = "OTC – Verify charges in Section E – Line 1 with all Recording Fee types";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with New Loan Lender (214) and Mortgage Broker (BOA).";
                FAST_WCF_File_IIS("BOA", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, LenderID: "214", SPAmt: 0);
                #endregion

                #region Enter OTC's bussiness party
                Reports.TestStep = "Navigate to OTC Screen.  Enter GAB Code. (E.g. 415)";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.GABcode.FASetText("415");
                FastDriver.OTCDetail.Find.FAClick();
                FastDriver.OTCDetail.WaitCreation(FastDriver.OTCDetail.GABcodeLabel);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Set OTC's Recording Tax Fee LE Unrounded amount $7000.49
                Reports.TestStep = @"Set the Unrounded Amount:7000.49:";
                FAST_UpdateLEAmtOTC(new double[,] { { 7000.49, 7000 }, { 0, 0 } });
                #endregion

                #region Add OTC's Recording fees
                Reports.TestStep = "Click on Add Recording Fees button under Recording Fees & Transfer Taxes. Add Fees which were created in admin.";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.AddRecordingFees.FAClick();
                FastDriver.AddOTCFees.WaitForScreenToLoad();
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Deed1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Deed2", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Mortgage1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Misc. description1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee Misc. 2", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee - Release1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "E Recording Fee - Release2", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "Recording Fee - Mortgage2", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter values for OTC's Recording fees
                Reports.TestStep = @"Enter values for OTC's Recording fees";
                FastDriver.OTCDetail.WaitForScreenToLoad();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed2", 3, TableAction.SetText, "2345.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed2", 4, TableAction.SetText, "2345.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. 2", 3, TableAction.SetText, "89564.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. 2", 4, TableAction.SetText, "89564.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "Recording Fee - Mortgage2", 3, TableAction.SetText, "3423.23");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "Recording Fee - Mortgage2", 4, TableAction.SetText, "563224.34");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 3, TableAction.SetText, "5600");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 4, TableAction.SetText, "4500.34");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD screen and verify the values under Other Cost. Line E.01";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$233,432,237.99", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $103,454.62 Mortgage: $800,880.13", "$233,432,237.99", "", "$234,126,408.50", "", "", "$7,000.49", "$7,000.00" } }, displayLE: true);
                #endregion

                #region Verify CD Section E - Other Costs / Recording Fees Itemization
                Reports.TestStep = "Click on + icon and verify if system displays all values";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", " $101,109.06", "", "", "", "" }, { "E Recording Fee Deed1", "$98,763.50", "", "", "", "" }, { "E Recording Fee Deed2", "$2,345.56", "", "$2,345.56", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$3,423.23", "", "", "", "" }, { "E Recording Fee Mortgage1", "", "", "$234,232.56", "", "" }, { "Recording Fee - Mortgage2 to Payee Name updated", "$3,423.23", "", "$563,224.34", "", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$5,828.38", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$228.38", "", "$228.38", "", "" }, { "E Recording Fee - Release2", "$5,600.00", "", "$4,500.34", "", "" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$233,321,877.32", "", "", "", "" }, { "E Recording Fee Misc. 2 to Continental Mortgage", "$89,564.56", "", "$89,564.56", "", "" }, { "E Recording Fee Misc. description1 to Continental Mortgage", "$233,232,312.76", "", "$233,232,312.76", "", "" } });
                #endregion

                #region Verify Good Faith Variance 10% Analisys table
                Reports.TestStep = "Select Good Faith Variance Screen and verify the values displayed under Good Faith Analysis 10% Category:";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { { "E 01 Recording Fees", "$7,000", "$7,000.49", "$7,000.49", "$233,432,237.99" }, { "Total Aggregate Fees", "$7,000.49", "$233,432,237.99", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$700.00", "$233,425,237.50", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$233,424,537.50", "", "", "" } }, increaseTotal: 233424537.50);
                #endregion

                #region Edit LE Unrounded amount in CD Section E
                Reports.TestStep = "Select CD tab. Enter Loan Estimate Unrounded Amount. (E.g. 434323.45)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 434323.45, 434323 }, { 0, 0 } }, recFeeRound: true);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 434323.45, LERounded: 434323, isRounded: true);
                #endregion

                #region Verify CD Good Faith Variance 10%
                Reports.TestStep = "Select Good Faith Variance screen and verify if Loan Estimate values are displayed";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { { "E 01 Recording Fees", "$434,323", "$434,323.45", "$434,323.45", "$233,432,237.99" }, { "Total Aggregate Fees", "$434,323.45", "$233,432,237.99", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$232,997,914.54", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$232,954,482.54", "", "", "" } }, increaseTotal: 232954482.54);
                #endregion

                #region Verify LE Amounts in FileFees screen
                Reports.TestStep = "Navigate to Fee Entry Screen and Verify if Loan Estimate Unrounded and Rounded are update in Recording Fees & Transfer Taxes Grid.";
                FAST_VerifyRecTaxLEAmounts(new double[,] { { 434323.45, 434323 }, { 0, 0 } });
                #endregion

                #region Verify LE amount in OTC
                Reports.TestStep = "Navigate to Outside Title Company Screen and Verify if Loan Estimate Unrounded and Rounded are update in Recording Fees & Transfer Taxes Grid.";
                FAST_VerifyLEAmtOTC(new double[,] { { 434323.45, 434323 }, { 0, 0 } });
                #endregion

                #region Update LE Amount in OTC
                Reports.TestStep = @"Edit LE Amount values in OTC Screen";
                FAST_UpdateLEAmtOTC(new double[,] { { 434323.45, 5434323 }, { 0, 0 } }, recFeeRound: false);
                #endregion

                #region Enter values for OTC's Recording fees
                Reports.TestStep = @"Enter values for OTC's Recording fees";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed1", 3, TableAction.SetText, "434.50");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed1", 4, TableAction.SetText, "565.50");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed2", 3, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed2", 4, TableAction.SetText, "23435.50");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. 2", 3, TableAction.SetText, "43534");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. 2", 4, TableAction.SetText, "87764");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. description1", 3, TableAction.SetText, "4342.23");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Misc. description1", 4, TableAction.SetText, "2343.78");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Mortgage1", 3, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Mortgage1", 4, TableAction.SetText, "0.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "Recording Fee - Mortgage2", 3, TableAction.SetText, "0.34");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "Recording Fee - Mortgage2", 4, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release1", 3, TableAction.SetText, "4564.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release1", 4, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 3, TableAction.SetText, "67542.45");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 4, TableAction.SetText, "23243.34");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD Screen and verify if system displays modified values and if Pencil icon is displayed for Loan Estimate Rounded amount";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$120,418.08", "", "", "", "", "", "" }, { "01.  Recording Fees Deed: $24,435.50 Mortgage: $0.90", "$120,418.08", "", "$137,352.68", "", "", "$434,323.45", "$5,434,323.00" } }, displayLE: true);
                #endregion

                #region Verify CD Section E - Other Costs [+] Recording Itemization Table
                Reports.TestStep = @"Click on + icon and verify the values displayed in Recording Fees Itemization pop up";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$434.50", "", "", "", "" }, { "E Recording Fee Deed1", "$434.50", "", "$565.50", "", "" }, { "E Recording Fee Deed2", "", "", "$23,435.50", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$0.34", "", "", "", "" }, { "E Recording Fee Mortgage1", "", "", "$0.56", "", "" }, { "Recording Fee - Mortgage2 to Payee Name updated", "$0.34", "", "", "", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$72,107.01", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$4,564.56", "", "", "", "" }, { "E Recording Fee - Release2", "$67,542.45", "", "$23,243.34", "", "" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$47,876.23", "", "", "", "" }, { "E Recording Fee Misc. 2 to Continental Mortgage", "$43,534.00", "", "$87,764.00", "", "" }, { "E Recording Fee Misc. description1 to Continental Mortgage", "$4,342.23", "", "$2,343.78", "", "" } });
                #endregion

                #region Verify CD Good Faith Variance 10% category table
                Reports.TestStep = @"Select Good Faith Variance screen and verify the values displayed in Good Faith Variance screen.";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { { "E 01 Recording Fees", "$5,434,323", "$434,323.45", "$434,323.45", "$120,418.08" }, { "Total Aggregate Fees", "$434,323.45", "$120,418.08", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } });
                #endregion

                #region Edit PDD for OTC's Recording fees
                Reports.TestStep = @"Edit PDD for OTC's Recording fees";
                FastDriver.OTCDetail.Open();
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "E Recording Fee - Release2",
                    LEDescription = "Modified Loan Estimate Description",
                    PayeeName = "Modified Payee Name",
                    PartOfCheckbox = false,
                    BuyerAtClosing = 34423.45,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 2234.55,
                    BuyerPaidbyOther = 7556.67,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    SellerPaidAtClosing = 7455.67,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 5676.76,
                    SellerPaidbyOthers = 8756,
                    SellerPaidbyOtherPaymentMthd = "POC"
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "E Recording Fee Deed2",
                    LEDescription = "Deed2 Modified Loan Estimate Description",
                    PayeeName = "Deed2 Modified Payee Name",
                    PartOfCheckbox = false,
                    BuyerAtClosing = 1500.87,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 4565.50,
                    BuyerPaidbyOther = 34534.51,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    SellerPaidAtClosing = 4544.49,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 3345.50,
                    SellerPaidbyOthers = 9243.50,
                    SellerPaidbyOtherPaymentMthd = "POC"
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "E Recording Fee Misc. description1",
                    PartOfCheckbox = false,
                    BuyerAtClosing = 4342.23,
                    BuyerChargePaymentMethod = "Check",
                    SellerPaidAtClosing = 34423.56,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 45344.56,
                    SellerPaidbyOthers = 342323.45,
                    SellerPaidbyOtherPaymentMthd = "POC"
                });
                FAST_UpdateOTCDetailPDD(new PDD
                {
                    ChargeDescription = "Recording Fee - Mortgage2",
                    PartOfCheckbox = true,
                    BuyerAtClosing = 560.00,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 670.00,
                    BuyerPaidbyOther = 345.44,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E, I, J - Other Costs after modifying recording fees PDD
                Reports.TestStep = "Verify CD Section E, I, J - Other Costs after modifying recording fees PDD";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "$96,829.66", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $49,490.87 Mortgage: $1,576.00", "$89,359.61", "$7,470.05", "$134,753.78", "$54,366.82", "$42,436.62", "$434,323.45", "$5,434,323.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$96,829.66", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$89,359.61", "$7,470.05", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$96,829.66", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$89,359.61", "$7,470.05", "$134,753.78", "$54,366.82", "$42,436.62" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Other Costs / Recording Fees Itemization after modifying PDD
                Reports.TestStep = "Verify CD Section E - Other Costs / Recording Fees Itemization after modifying PDD";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$6,500.87", "", "", "", "" }, { "Deed2 Modified Loan Estimate Description to Deed2 Modified Payee", "$1,500.87", "$4,565.50", "$4,544.49", "$3,345.50", "$34,534.51" }, { "E Recording Fee Deed1", "$434.50", "", "$565.50", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$1,230.00", "", "", "", "" }, { "E Recording Fee Mortgage1", "", "", "$0.56", "", "" }, { "Recording Fee - Mortgage2 to Payee Name updated", "$560.00", "$670.00", "", "", "$345.44" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", " $41,222.56", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$4,564.56", "", "", "", "" }, { "Modified Loan Estimate Description to Modified Payee Name", "$34,423.45", "$2,234.55", "$7,455.67", "$5,676.76", "$7,556.67" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$47,876.23", "", "", "", "" }, { "E Recording Fee Misc. 2 to Continental Mortgage", "$43,534.00", "", "$87,764.00", "", "" }, { "E Recording Fee Misc. description1 to Continental Mortgage", "$4,342.23", "", "$34,423.56", "$45,344.56", "" } });
                #endregion

                #region Verify CD Good Faith Variance after modifying recording fees PDD
                Reports.TestStep = "Verify CD Good Faith Variance after modifying recording fees PDD";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { { "E 01 Recording Fees", "$5,434,323", "$434,323.45", "$434,323.45", "$96,829.66" }, { "Total Aggregate Fees", "$434,323.45", "$96,829.66", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$43,432.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } });
                #endregion

                #region Update LE Unrounded amount in CD Section E
                Reports.TestStep = "Select Closing Disclosure tab. Enter Loan Estimate unrounded amount. (E.g. 5,345.56)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 5345.56, 5346 }, { 0, 0 } }, recFeeRound: true);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 5345.56, LERounded: 5346);
                #endregion

                #region Verify LE Unrounded amount in OTC screen
                Reports.TestStep = "Navigate to OTC screen. Select Recording Fee and Tax tab and verify if Loan Estimate unrounded and rounded amounts are updated.";
                FAST_VerifyLEAmtOTC(new double[,] { { 5345.56, 5346 }, { 0, 0 } });
                #endregion

                #region Verify CD Good Faith Variance after modifying LE Unrounded
                Reports.TestStep = "Verify CD Good Faith Variance after modifying LE Unrounded";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$96,829.66" }, { "Total Aggregate Fees", "$5,345.56", "$96,829.66", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$91,484.10", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$90,949.10", "", "", "" } },
                    increaseTotal: 90949.10);
                #endregion

                #region Update Buyer  and Seller amounts for E Recording Fee Mortgage1
                Reports.TestStep = @"Update Buyer  and Seller amounts for E Recording Fee Mortgage1";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Mortgage1", 3, TableAction.SetText, "0");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Mortgage1", 4, TableAction.SetText, "0");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
                Reports.TestStep = @"Navigate to New Loan - Loan Charges then enter Buyer Credit Amount and LE for Non-Specific Lender Credits.";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "56734", "", "", "34534" } });
                #endregion

                #region Verify CD Section E - Other Costs after setting Lender Credits
                Reports.TestStep = "Verify CD Section E - Other Costs after setting Lender Credits";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "$96,829.66", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $49,490.87 Mortgage: $1,575.44", "$89,359.61", "$7,470.05", "$134,753.22", "$54,366.82", "$42,436.62", "$5,345.56", "$5,346.00" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Other Costs / Recording Fees Itemization after setting Lender Credits
                Reports.TestStep = "Verify CD Section E - Other Costs / Recording Fees Itemization after setting Lender Credits";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$6,500.87", "", "", "", "" }, { "Deed2 Modified Loan Estimate Description to Deed2 Modified Payee", "$1,500.87", "$4,565.50", "$4,544.49", "$3,345.50", "$34,534.51" }, { "E Recording Fee Deed1", "$434.50", "", "$565.50", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$1,230.00", "", "", "", "" }, { "Recording Fee - Mortgage2 to Payee Name updated", "$560.00", "$670.00", "", "", "$345.44" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", " $41,222.56", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$4,564.56", "", "", "", "" }, { "Modified Loan Estimate Description to Modified Payee Name", "$34,423.45", "$2,234.55", "$7,455.67", "$5,676.76", "$7,556.67" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$47,876.23", "", "", "", "" }, { "E Recording Fee Misc. 2 to Continental Mortgage", "$43,534.00", "", "$87,764.00", "", "" }, { "E Recording Fee Misc. description1 to Continental Mortgage", "$4,342.23", "", "$34,423.56", "$45,344.56", "" } });
                #endregion

                #region Verify CD Good Faith Variance after setting Lender Credits
                Reports.TestStep = "Verify CD Good Faith Variance after setting Lender Credits";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "-$34,534", "-$56,734.00", "-$34,534.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$56,734.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$56,734.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$96,829.66" }, { "Total Aggregate Fees", "$5,345.56", "$96,829.66", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$91,484.10", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$90,949.10", "", "", "" } },
                    increaseTotal: 90949.10);
                #endregion

                #region Update Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
                Reports.TestStep = @"Update Buyer credits and LE amount for Lender in New Loan - Loan Charges tab";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "56734", "", "", "134534.50" } });
                #endregion

                #region Verify CD Section E - Other Costs after updating Lender Credits
                Reports.TestStep = "Verify CD Section E - Other Costs after updating Lender Credits";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "$96,829.66", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $49,490.87 Mortgage: $1,575.44", "$89,359.61", "$7,470.05", "$134,753.22", "$54,366.82", "$42,436.62", "$5,345.56", "$5,346.00" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Other Costs / Recording Fees Itemization after updating Lender Credits
                Reports.TestStep = "Verify CD Section E - Other Costs / Recording Fees Itemization after updating Lender Credits";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$6,500.87", "", "", "", "" }, { "Deed2 Modified Loan Estimate Description to Deed2 Modified Payee", "$1,500.87", "$4,565.50", "$4,544.49", "$3,345.50", "$34,534.51" }, { "E Recording Fee Deed1", "$434.50", "", "$565.50", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$1,230.00", "", "", "", "" }, { "Recording Fee - Mortgage2 to Payee Name updated", "$560.00", "$670.00", "", "", "$345.44" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", " $41,222.56", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$4,564.56", "", "", "", "" }, { "Modified Loan Estimate Description to Modified Payee Name", "$34,423.45", "$2,234.55", "$7,455.67", "$5,676.76", "$7,556.67" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$47,876.23", "", "", "", "" }, { "E2 Recording Fee Misc. to Continental Mortgage Corporation", "$43,534.00", "", "$87,764.00", "", "" }, { "E Recording Fee Miscellaneous to Continental Mortgage Corporation", "$4,342.23", "", "$34,423.56", "$45,344.56", "$342,323.45" } });
                #endregion

                #region Verify CD Good Faith Variance after updating Lender Credits
                Reports.TestStep = "Verify CD Good Faith Variance after updating Lender Credits";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "-$134,535", "-$56,734.00", "-$134,534.50", "$77,800.50" }, { "Increase in Closing Costs above legal limits - 0% Category", "$77,800.50", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$56,734.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$56,734.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$5,346", "$5,345.56", "$5,345.56", "$96,829.66" }, { "Total Aggregate Fees", "$5,345.56", "$96,829.66", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$535.00", "$91,484.10", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$90,949.10", "", "", "" } },
                    increaseTotal: 168749.60);
                #endregion

                #region Edit OTC recording fee description
                Reports.TestStep = "Navigate to OTC Screen and verify if charge description is saved on edit.";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee Deed1", 1, TableAction.Click);
                Keyboard.SendKeys("Modify Description");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "E Recording Fee - Release2", 1, TableAction.Click);
                Keyboard.SendKeys("Modify Description2");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs / Recording Fees Itemization after modifying fee description
                Reports.TestStep = "Verify CD Section E - Other Costs / Recording Fees Itemization after modifying fee description";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$6,066.37", "", "", "", "" }, { "Deed2 Modified Loan Estimate Description to Deed2 Modified Payee", "$1,500.87", "$4,565.50", "$4,544.49", "$3,345.50", "$34,534.51" }, { "Modify Description", "", "", "$565.50", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$1,230.00", "", "", "", "" }, { "Recording Fee - Mortgage2 to Payee Name updated", "$560.00", "$670.00", "", "", "$345.44" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", " $41,222.56", "", "", "", "" }, { "E Recording Fee - Release1 to Payee Name Filter", "$4,564.56", "", "", "", "" }, { "Modified Loan Estimate Description to Modified Payee Name", "$34,423.45", "$2,234.55", "$7,455.67", "$5,676.76", "$7,556.67" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$47,876.23", "", "", "", "" }, { "E Recording Fee Misc. 2 to Continental Mortgage", "$43,534.00", "", "$87,764.00", "", "" }, { "E Recording Fee Misc. description1 to Continental Mortgage", "$4,342.23", "", "$34,423.56", "$45,344.56", "" } });
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Section E: FACC – Recording Fees

        [TestMethod]
        [Description("FACC:  Verify charges in Section E – Line 1 with all Recording Fee types.")]
        public void SectionE_Scenario3() 
        {
            try
            {
                Reports.TestDescription = "FACC:  Verify charges in Section E – Line 1 with all Recording Fee types.";

                //  SectionE_Scenario3_1

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with New Loan Lender (214) and Mortgage Broker (BOA).";
                FAST_WCF_File_IIS("BOA", GABRole: AdditionalRoleType.MortgageBroker, SPAmt: (decimal)567834.56, loanAmt: (decimal)232332.45, isTO: true, isEO: true, LenderID: "214");
                #endregion

                #region Enter Calculate Recording Fees
                Reports.TestStep = @"Navigate to Fee Entry screen. Check “Recording Fees” checkbox and click on Calculate Fees button.";
                FAST_AddFileFeesFACC(recFees: new string[,] { { "Amendment", "56", "589079.98" }, { "Assignment", "89", "34523423" }, { "Deed", "890", "567834.56" }, { "Mortgage", "986", "232332.45" }, { "POA", "876", "8768763" }, { "Satisfaction", "878", "78678567" }, { "Subordination", "8698", "8789789" } },
                    summary: new string[,] { { "AMENDMENT - Recording Fee","","174.00","FACC E Recording Fee Misc. description2","Buyer","Premium Split","23423.87","45","","10,540.74","12,883.13","23,423.87" }, 
                    {"ASSIGNMENT - Recording Fee","","273.00","FACC E Recording Fee Misc. description","Seller","Premium Split","3423.46","","2345","1,078.46","2,345.00","3,423.46" }, 
                    {"DEED - Recording Fee","","2,673.00","FACC E Recording Fee Deed","Buyer","","","50","","1,336.50","1,336.50","2,673.00" },
                    {"DEED - Documentary Transfer Tax","","624.80","FACC E Recording Fee Deed2","Seller","","","","200.00","424.80","200.00","624.80"},
                    {"MORTGAGE - Recording Fee","","2,964.00","FACC E Recording Fee Mortgage","Buyer","","","","","2,964.00","0.00","2,964.00"},
                    {"POA - Recording Fee","","2,631.00","FACC E Recording Fee - Mortgage2","Seller","","","","","0.00","2,631.00","2,631.00"},
                    {"SATISFACTION - Recording Fee","","2,640.00","FACC E Recording Fee - Release","Buyer","","","","","2,640.00","0.00","2,640.00"},
                    {"SUBORDINATION - Recording Fee","","26,100.00","FACC E Recording Fee - Release2","Seller","","","","","0.00","26,100.00","26,100.00"}
                });
                #endregion

                #region Enter LE Unrounded amount for Recording Fees. (E.g. 456455.56)
                Reports.TestStep = "Enter Loan Estimate Unrounded amount for Recording Fees. (E.g. 456455.56)";
                FAST_UpdateRecTaxLEAmounts(new double[,] { { 456455.56, 456456 }, { 0, 0 } });
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Verify CD Section E - Other Costs";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$18,984.50", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $3,297.80 Mortgage: $5,595.00", "$18,984.50", "", "$45,495.63", "", "", "$456,455.56", "$456,456.00" } },
                    sectionIValues: new string[,] { { " I.  TOTAL OTHER COSTS (Borrower-Paid)", "$18,984.50", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$18,984.50", "", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$18,984.50", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$18,984.50", "", "$45,495.63", "", "" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Itemization Fees
                Reports.TestStep = "Verify CD Section E - Itemization Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$1,761.30", "", "", "", "" }, { "FACC E Recording Fee Deed", "$1,336.50", "", "$1,336.50", "", "" }, { "FACC E Recording Fee Deed2 to Bloom County Tax Authority", "$424.80", "", "$200.00", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$2,964.00", "", "", "", "" }, { "FACC E Recording Fee - Mortgage2", "", "", "$2,631.00", "", "" }, { "FACC E Recording Fee Mortgage to Added Payee Name in Admin", "$2,964.00", "", "", "", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$2,640.00", "", "", "", "" }, { "FACC E Recording Fee - Release to Payee Name Filter", "$2,640.00", "", "", "", "" }, { "FACC E Recording Fee - Release2", "", "", "$26,100.00", "", "" } },
                    miscFees: new string[,] { { " Recording Fee - Miscellaneous", "$11,619.20", "", "", "", "" }, { "FACC E Recording Fee Misc. description", "$1,078.46", "", "$2,345.00", "", "" }, { "FACC E Recording Fee Misc. description2 to Bloom County Tax", "$10,540.74", "", "$12,883.13", "", "" } });
                #endregion

                #region Verify CD Good Faith Variance 10% category table
                Reports.TestStep = "Verify CD Good Faith Variance 10% category table";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { { "E 01 Recording Fees", "$456,456", "$456,455.56", "$456,455.56", "$18,984.50" }, { "Total Aggregate Fees", "$456,455.56", "$18,984.50", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$45,646.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } });
                #endregion

                //  SectionE_Scenario3_2

                #region Edit LE Amounts in CD Section E => 567675.67
                Reports.TestStep = "Select Closing Disclosure tab and modify the Loan Estimate unrounded and rounded amount. (E.g. 567675.67, Rounded Amount = 342333.56)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 567675.67, 342333.56 }, { 0, 0 } }, recFeeRound: false);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 567675.67, LERounded: 342333.56, isRounded: false);
                #endregion

                #region Verify CD Good Faith Variance 10% category table and Lender Credits
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$342,334", "$567,675.67", "$567,675.67", "$18,984.50" }, { "Total Aggregate Fees", "$567,675.67", "$18,984.50", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$56,768.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } });
                #endregion

                #region Verify LE Amounts in FileFees screen
                Reports.TestStep = @"Navigate Fee Entry | Recording Fee and Tax tab and verify the Loan Estimate rounded and unrounded amount.";
                FAST_VerifyRecTaxLEAmounts(new double[,] { { 567675.67, 342334.00 }, { 0, 0 } }, recFeeRound: false);
                #endregion

                #region Update Recording Fees PDD in FileFees screen
                Reports.TestStep = "Update Recording Fees PDD in FileFees screen";
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee Deed",
                    LEDescription = "Modified - FACC Recording Fee - Deed",
                    PayeeName = "Added Payee name in Source Screen PDD",
                    BuyerAtClosing = 500.00,
                    BuyerChargePaymentMethod = "Fee",
                    BuyerBeforeClosing = 500.00,
                    BuyerPaidbyOther = 336.50,
                    BuyerPaidbyOtherPaymentMethod = "Lender",
                    BuyerLenderCheckbox = false,
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 1000.00,
                    SellerChargePaymentMethod = "Fee",
                    SellerPaidBeforeClosing = 300,
                    SellerPaidbyOthers = 36.50,
                    SellerPaidbyOtherPaymentMthd = "Lender",
                    SellerLenderCheckbox = false,
                }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee - Mortgage2",
                    LEDescription = "Updated FACC2 Recording Fee Mortgage",
                    PayeeName = "Updated Payee Name in PDD",
                    BuyerDoubleAsteriskChecked = false,
                    SellerPaidAtClosing = 1000.00,
                    SellerChargePaymentMethod = "Fee",
                    SellerPaidBeforeClosing = 1600,
                    SellerPaidbyOthers = 31.00,
                    SellerPaidbyOtherPaymentMthd = "Lender",
                    SellerLenderCheckbox = true
                }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee - Release",
                    PayeeName = "Wells Fargo Payee",
                    BuyerAtClosing = 640.00,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 1000.00,
                    BuyerPaidbyOther = 1000.00,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    BuyerDoubleAsteriskChecked = true,
                }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee - Release2",
                    PayeeName = "Bank of American Payee",
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 20000.00,
                    SellerChargePaymentMethod = "Fee",
                    SellerPaidBeforeClosing = 6000.00,
                    SellerPaidbyOthers = 100.00,
                    SellerPaidbyOtherPaymentMthd = "Mortgage Broker"
                }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee Misc. description",
                    BuyerAtClosing = 78.46,
                    BuyerChargePaymentMethod = "Fee",
                    BuyerBeforeClosing = 0,
                    BuyerPaidbyOther = 1000.00,
                    BuyerPaidbyOtherPaymentMethod = "Mortgage Broker",
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 2345.00,
                    SellerChargePaymentMethod = "Fee"
                }, isTE: false);
                #endregion

                #region Navigate to Split Fees/Assign State Screen and select 2 Payee name
                Reports.TestStep = "Navigate to Split Fees/Assign State Screen. Select 2 Payee name. (E.g. Smythe & Lee and Continental Mortgage Corporation)";
                FastDriver.SplitFeeDisbursements.Open();
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.WaitForScreenToLoad();
                FastDriver.PayeeSearchDlg.SearchResults.PerformTableAction(4, "Bank of America", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.SplitFeeDisbursements.SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.SplitFeeDisbursements.SpliFeeImage(1).FAClick();
                Playback.Wait(1500);
                FastDriver.SplitFeeDisbursements.SelectPayee(2).FASelectItemBySendingKeys("Bank of America");
                FastDriver.SplitFeeDisbursements.SplitPercent(2).FASetText("50");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD Screen. Expand Other Cost and verify the values displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "$16,648.00", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $3,297.80 Mortgage: $5,595.00", "$15,148.00", "$1,500.00", "$37,428.13", "$7,900.00", "$2,336.50", "$567,675.67", "$342,334.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$16,648.00", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$15,148.00", "$1,500.00", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$16,648.00", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$15,148.00", "$1,500.00", "$37,428.13", "$7,900.00", "$2,336.50" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Itemization Fees
                Reports.TestStep = "Verify CD Section E - Itemization Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$1,424.80", "", "", "", "" }, { "FACC E Recording Fee Deed2 to Bloom County Tax Authority", "$424.80", "", "$200.00", "", "" }, { "**Modified - FACC Recording Fee - Deed to Added Payee name in", "$500.00", "$500.00", "$1,000.00", "$300.00", "$336.50" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$2,964.00", "", "", "", "" }, { "FACC E Recording Fee Mortgage to Added Payee Name in Admin", "$2,964.00", "", "", "", "" }, { "Updated FACC2 Recording Fee Mortgage to Updated Payee Name in", "", "", "$1,000.00", "$1,600.00", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$1,640.00", "", "", "", "" }, { "**FACC E Recording Fee - Release to Wells Fargo Payee", "$640.00", "$1,000.00", "", "", "$1,000.00" }, { "**FACC E Recording Fee - Release2 to Bank of American Payee", "", "", "$20,000.00", "$6,000.00", "" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$10,619.20", "", "", "", "" }, { "**FACC E Recording Fee Misc. description", "$78.46", "", "$2,345.00", "", "$1,000.00" }, { "FACC E Recording Fee Misc. description2 to Bloom County Tax", "$10,540.74", "", "$12,883.13", "", "" } });
                #endregion

                #region Edit LE amount in CD Section E - Other Costs
                Reports.TestStep = "Edit Loan Estimate Unrounded Value for Recording Fee. (E.g. 10,000.50)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 10000.50, 10001 }, { 0, 0 } }, recFeeRound: true);
                //FAST_UpdateLEAmtCDSectionE(LEUnrounded: 10000.50, LERounded: 10001, isRounded: true);
                #endregion

                #region Verify CD Good Faith Variance 10% category all sections
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$1,336.50", "$0.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "E 01 Recording Fees", "-$1,336.50" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$1,336.50" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$10,001", "$10,000.50", "$10,000.50", "$16,648.00" }, { "Total Aggregate Fees", "$10,000.50", "$16,648.00", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$1,000.00", "$6,647.50", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$5,647.50", "", "", "" } },
                    increaseTotal: 5647.50);
                #endregion

                #region Verify LE Amounts in FileFees screen
                Reports.TestStep = @"Navigate Fee Entry | Recording Fee and Tax tab and verify the Loan Estimate rounded and unrounded amount.";
                FAST_VerifyRecTaxLEAmounts(new double[,] { { 10000.50, 10001 }, { 0, 0 } }, recFeeRound: true);
                #endregion

                #region Modifying Recording Fees PDD in FileFees screen
                Reports.TestStep = "Modifying Recording Fees PDD in FileFees screen";
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee Deed",
                    BuyerAtClosing = 500.00,
                    BuyerChargePaymentMethod = "Fee",
                    BuyerBeforeClosing = 500.00,
                    BuyerPaidbyOther = 336.50,
                    BuyerPaidbyOtherPaymentMethod = "Lender",
                    BuyerLenderCheckbox = false,
                    BuyerDoubleAsteriskChecked = false,
                    SellerPaidAtClosing = 1000.00,
                    SellerChargePaymentMethod = "Fee",
                    SellerPaidBeforeClosing = 300.00,
                    SellerPaidbyOthers = 36.50,
                    SellerPaidbyOtherPaymentMthd = "Lender",
                    SellerLenderCheckbox = false,
                }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee - Release2",
                    BuyerDoubleAsteriskChecked = false,
                    SellerPaidAtClosing = 20000.00,
                    SellerChargePaymentMethod = "Fee",
                    SellerPaidBeforeClosing = 6000.00,
                    SellerPaidbyOthers = 100.00,
                    SellerPaidbyOtherPaymentMthd = "Mortgage Broker"
                }, isTE: false);
                #endregion
                
                #region Navigate to Calculate Fee and add Override amount for Recording Fee Deed. E.g. FACC Recording Fee – Deed (DEED - Recording Fee)
                Reports.TestStep = "Navigate to Calculate Fee and add Override amount for Recording Fee Deed. (E.g. FACC Recording Fee – Deed (DEED - Recording Fee))";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FAST_UpdateCalculateFeeSummary(summary: new string[,] { { "DEED - Recording Fee", "", "2,673.00", "FACC E Recording Fee Deed", "Buyer", "3 or More Simultaneous Policies", "5000", "50", "", "25,000.00", "25,000.00", "50,000.00" } });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD Screen. Expand Other Cost and verify the values displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "$40,311.50", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $50,588.30 Mortgage: $5,595.00", "$38,811.50", "$1,500.00", "$61,091.63", "$7,900.00", "$2,336.50", "$10,000.50", "$10,001.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$40,311.50", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$38,811.50", "$1,500.00", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$40,311.50", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$38,811.50", "$1,500.00", "$61,091.63", "$7,900.00", "$2,336.50" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Itemization Fees
                Reports.TestStep = "Verify CD Section E - Itemization Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$25,088.30", "", "", "", "" }, { "FACC E Recording Fee Deed2 to Bloom County Tax Authority", "$424.80", "", "$200.00", "", "" }, { "Modified - FACC Recording Fee - Deed to Added Payee name in", "$24,163.50", "$500.00", "$24,663.50", "$300.00", "$336.50" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$2,964.00", "", "", "", "" }, { "FACC E Recording Fee Mortgage to Added Payee Name in Admin", "$2,964.00", "", "", "", "" }, { "Updated FACC2 Recording Fee Mortgage to Updated Payee Name in", "", "", "$1,000.00", "$1,600.00", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$1,640.00", "", "", "", "" }, { "**FACC Recording Fee - Release Loan est. to Wells Fargo Payee", "$640.00", "$1,000.00", "", "", "$1,000.00" }, { "FACC E Recording Fee - Release to Bank of American Payee", "", "", "$20,000.00", "$6,000.00", "$100.00" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$10,619.20", "", "", "", "" }, { "**FACC E Recording Fee Misc. description", "$78.46", "", "$2,345.00", "", "$1,000.00" }, { "FACC E Recording Fee Misc. description2 to Bloom County Tax", "$10,540.74", "", "$12,883.13", "", "" } });
                #endregion

                #region Verify CD Good Faith Variance 10% category all sections
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$1,336.50", "$0.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "E 01 Recording Fees", "-$1,336.50" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$1,336.50" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$10,001", "$10,000.50", "$10,000.50", "$40,311.50" }, { "Total Aggregate Fees", "$10,000.50", "$40,311.50", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$1,000.00", "$30,311.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$29,311.00", "", "", "" } },
                    increaseTotal: 29311.00);
                #endregion

                #region Enter Buyer credits and LE amount for Lender in New Loan - Loan Charges tab and Mortgage broker tab
                Reports.TestStep = @"Navigate to New Loan - Enter Buyer credits and LE amount for Lender in Loan Charges tab and Mortgage broker tab";
                FAST_UpdateLenderCredits(chargesTabValues: new string[,] { { "2", "", "", "", "430.56", "", "", "67554.56" } }, mortgageTabValues: new string[,] { { "2", "", "", "", "343.34", "", "", "763.45" } });
                #endregion

                #region Remove override reasons for fees in Calculate Fee Summary screen
                Reports.TestStep = "Navigate to Fee Entry | Calculate Fee Summary screen. Remove override reasons for all fees.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FAST_UpdateCalculateFeeSummary(summary: new string[,] { { "AMENDMENT - Recording Fee","","174.00","FACC E Recording Fee Misc. description2","Buyer","","","45","","78.30","95.70","174.00" }, 
                    {"ASSIGNMENT - Recording Fee","","273.00","FACC E Recording Fee Misc. description","Seller","","","","273","0.00","273.00","273.00" }, 
                    { "DEED - Recording Fee", "", "2,673.00", "FACC E Recording Fee Deed", "Buyer", "", "", "50", "", "1,336.50", "1,336.50", "2,673.00" } });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Terms/Dates/Status and update the Sales Price
                Reports.TestStep = "Navigate to Terms/Dates/Status and update the Sales Price. (E.g. 160000). System displays recalculation pop up. Click on Ok button.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SalesPriceAmount.Click();
                Keyboard.SendKeys("160000");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 10);
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 10);
                Support.AreEqual("Changing the Sales Price, Loan Amount or Liability Amounts will result in automatic recalculation of impacted fees if no override exists. If override exists there will be no auto-recalculation and impacted fees will be removed.", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 10);
                Support.AreEqual("Sale Price has changed.  Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to New Loan screen and modify First New Loan Amount. (E.g. 15000)
                Reports.TestStep = "Navigate to New Loan screen and modify First New Loan Amount. (E.g. 15000).System displays a pop up with below mentioned message. Click on Ok button.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsLoanAmount.Click();
                Keyboard.SendKeys("15000");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 10);
                Support.AreEqual("Changing the Sales Price, Loan Amount or Liability Amounts will result in automatic recalculation of impacted fees if no override exists. If override exists there will be no auto-recalculation and impacted fees will be removed.", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD Screen. Expand Other Cost and verify the values displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "$7,018.80", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $2,849.00 Mortgage: $5,595.00", "$7,018.80", "", "$30,612.20", "", "", "$10,000.50", "$10,001.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$7,018.80", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$7,018.80", "", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$6,244.90", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$7,018.80", "", "$30,612.20", "", "" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Itemization Fees
                Reports.TestStep = "Verify CD Section E - Itemization Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$1,336.50", "", "", "", "" }, { "FACC E Recording Fee Deed2 to Bloom County Tax Authority", "", "", "$176.00", "", "" }, { "Modified - FACC Recording Fee - Deed to Added Payee name in", "$1,336.50", "", "$1,336.50", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$2,964.00", "", "", "", "" }, { "FACC E Recording Fee Mortgage to Added Payee Name in Admin", "$2,964.00", "", "", "", "" }, { "Updated FACC2 Recording Fee Mortgage to Updated Payee Name in", "", "", "$2,631.00", "", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$2,640.00", "", "", "", "" }, { "**FACC Recording Fee - Release Loan est. to Wells Fargo Payee", "$2,640.00", "", "", "", "" }, { "FACC E Recording Fee - Release", "", "", "$26,100.00", "", "" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$78.30", "", "", "", "" }, { "**FACC E Recording Fee Misc. description", "", "", "$273.00", "", "" }, { "FACC E Recording Fee Misc. description2 to Bloom County Tax", "$78.30", "", "$95.70", "", "" } });
                #endregion

                #region Verify CD Good Faith Variance 10% category all sections
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "-$68,318", "-$773.90", "-$68,318.01", "$67,544.11" }, { "Increase in Closing Costs above legal limits - 0% Category", "$67,544.11", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$773.90" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$773.90" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$10,001", "$10,000.50", "$10,000.50", "$7,018.80" }, { "Total Aggregate Fees", "$10,000.50", "$7,018.80", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$1,000.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } },
                    increaseTotal: 67544.11);
                #endregion

                #region Add override reasons for fees in Calculate Fee Summary screen
                Reports.TestStep = "Navigate to Fee Entry | Calculate Fee Summary Screen. Add Override reason for any fees. (E.g. AMENDMENT - Recording Fee)";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FAST_UpdateCalculateFeeSummary(summary: new string[,] { { "AMENDMENT - Recording Fee", "", "174.00", "FACC E Recording Fee Misc. description2", "Buyer", "Premium Split", "15000", "45", "", "67,500.00", "82,500.00", "150,000.00" } });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Property Tax Info.  and modify state and county.
                Reports.TestStep = "Navigate to Property Tax Info.  and modify state and county.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItemBySendingKeys(index: 8);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing State will result in the removal or replacements of the ST License ID", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing the State or County will result in removal of all calculated fees. Do you wish to continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.Click();
                Keyboard.SendKeys("Apache{TAB}");
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing the State or County will result in removal of all calculated fees. Do you wish to continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD Screen. Expand Other Cost and verify the values displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "", "", "", "", "", "", "" }, { "01. Recording Fees Deed: Mortgage:", "", "", "", "", "", "", "" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "", "", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "-$773.90", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "", "", "", "", "" } },
                    displayLE: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("OTC & FACC:  Verify charges in Section E – Line 1 with all Recording Fee types.")]
        public void SectionE_Scenario4()
        {
            try
            {
                Reports.TestDescription = "OTC & FACC:  Verify charges in Section E – Line 1 with all Recording Fee types.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with New Loan Lender (214) and Mortgage Broker (BOA).";
                FAST_WCF_File_IIS("BOA", GABRole: AdditionalRoleType.MortgageBroker, isTO: false, isEO: true, LenderID: "214");
                #endregion

                #region Enter OTC's bussiness party
                Reports.TestStep = "Navigate to OTC Screen.  Enter GAB Code. (E.g. 415)";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.GABcode.FASetText("415");
                FastDriver.OTCDetail.Find.FAClick();
                FastDriver.OTCDetail.WaitCreation(FastDriver.OTCDetail.GABcodeLabel);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter Calculate Recording Fees
                Reports.TestStep = @"Navigate to Fee Entry screen. Check “Recording Fees” checkbox and click on Calculate Fees button.";
                FAST_AddOTCCalculateFees(recFees: new string[,] { { "Amendment", "56", "589079.98" }, { "Assignment", "89", "34523423" }, { "Deed", "890", "567834.56" }, { "Mortgage", "986", "232332.45" }, { "POA", "876", "8768763" }, { "Satisfaction", "878", "78678567" }, { "Subordination", "8698", "8789789" } },
                    summary: new string[,] { { "AMENDMENT - Recording Fee","","174.00","FACC E Recording Fee Misc. description2","Buyer","Premium Split","23423.87","45","","10,540.74","12,883.13","23,423.87" }, 
                    {"ASSIGNMENT - Recording Fee","","273.00","FACC E Recording Fee Misc. description","Seller","Premium Split","3423.46","","2345","1,078.46","2,345.00","3,423.46" }, 
                    {"DEED - Recording Fee","","2,673.00","FACC E Recording Fee Deed","Buyer","","","50","","1,336.50","1,336.50","2,673.00" },
                    {"DEED - Documentary Transfer Tax","","624.80","FACC E Recording Fee Deed2","Seller","","","","200.00","424.80","200.00","624.80"},
                    {"MORTGAGE - Recording Fee","","2,964.00","FACC E Recording Fee Mortgage","Buyer","","","","","2,964.00","0.00","2,964.00"},
                    {"POA - Recording Fee","","2,631.00","FACC E Recording Fee - Mortgage2","Seller","","","","","0.00","2,631.00","2,631.00"},
                    {"SATISFACTION - Recording Fee","","2,640.00","FACC E Recording Fee - Release","Buyer","","","","","2,640.00","0.00","2,640.00"},
                    {"SUBORDINATION - Recording Fee","","26,100.00","FACC E Recording Fee - Release2","Seller","","","","","0.00","26,100.00","26,100.00"}
                });
                #endregion

                #region Set LE Unrounded amount for Recording Fees. (E.g. 456455.56)
                Reports.TestStep = "Enter Loan Estimate Unrounded amount for Recording Fees. (E.g. 456455.56)";
                FAST_UpdateRecTaxLEAmounts(new double[,] { { 456455.56, 456456 }, { 0, 0 } });
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Verify CD Section E - Other Costs";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$17,648.00", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $3,297.80 Mortgage: $5,595.00", "$17,648.00", "", "$45,495.63", "", "", "$456,455.56", "$456,456.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$17,648.00", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$17,648.00", "", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$17,648.00", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$17,648.00", "", "$45,495.63", "", "" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Itemization Fees
                Reports.TestStep = "Verify CD Section E - Itemization Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$424.80", "", "", "", "" }, { "FACC E Recording Fee Deed", "", "", "$1,336.50", "", "" }, { "FACC E Recording Fee Deed2", "$424.80", "", "$200.00", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$2,964.00", "", "", "", "" }, { "FACC E Recording Fee - Mortgage2", "", "", "$2,631.00", "", "" }, { "FACC E Recording Fee Mortgage to Added Payee Name in Admin", "$2,964.00", "", "", "", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$2,640.00", "", "", "", "" }, { "FACC E Recording Fee - Release to Payee Name Filter", "$2,640.00", "", "", "", "" }, { "FACC E Recording Fee - Release2", "", "", "$26,100.00", "", "" } },
                    miscFees: new string[,] { { " Recording Fee - Miscellaneous", "$11,619.20", "", "", "", "" }, { "FACC E Recording Fee Misc. description to Continental Mortgage", "$1,078.46", "", "$2,345.00", "", "" }, { "FACC E Recording Fee Misc. description2 to Continental Mortgage", "$10,540.74", "", "$12,883.13", "", "" } });
                #endregion

                #region Verify CD Good Faith Variance 10% category table
                Reports.TestStep = "Verify CD Good Faith Variance 10% category table";
                FAST_VerifyGFaithVariance(cat10Table: new string[,] { { "E 01 Recording Fees", "$456,456", "$456,455.56", "$456,455.56", "$17,648.00" }, { "Total Aggregate Fees", "$456,455.56", "$17,648.00", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$45,646.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } });
                #endregion

                #region Update LE Amounts in CD Section E => 567675.67
                Reports.TestStep = "Select Closing Disclosure tab and modify the Loan Estimate unrounded and rounded amount. (E.g. 567675.67, Rounded Amount = 342333.56)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 567675.67, 342333.56 }, { 0, 0 } }, recFeeRound: false);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 567675.67, LERounded: 342333.56, isRounded: false);
                #endregion

                #region Verify CD Good Faith Variance 10% category table and Lender Credits
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$342,334", "$567,675.67", "$567,675.67", "$17,648.00" }, { "Total Aggregate Fees", "$567,675.67", "$17,648.00", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$56,768.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } });
                #endregion

                #region Verify LE Amounts in FileFees screen
                Reports.TestStep = @"Navigate Fee Entry | Recording Fee and Tax tab and verify the Loan Estimate rounded and unrounded amount.";
                FAST_VerifyRecTaxLEAmounts(new double[,] { { 567675.67, 342334.00 }, { 0, 0 } }, recFeeRound: false);
                #endregion

                #region Edit PDD for OTC's Recording fees
                Reports.TestStep = @"Edit PDD for OTC's Recording fees";
                FastDriver.OTCDetail.Open();
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee Deed",
                    LEDescription = "Modified - FACC Recording Fee - Deed",
                    PayeeName = "Added Payee name in Source Screen PDD",
                    BuyerAtClosing = 500.00,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 500.00,
                    BuyerPaidbyOther = 336.50,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 1000.00,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 300.00,
                    SellerPaidbyOthers = 36.50,
                    SellerPaidbyOtherPaymentMthd = "POC"
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee - Mortgage2",
                    LEDescription = "Updated FACC2 Recording Fee Mortgage",
                    PayeeName = "Updated Payee Name in PDD",
                    SellerPaidAtClosing = 1000.00,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 1600.00,
                    SellerPaidbyOthers = 31.00,
                    SellerPaidbyOtherPaymentMthd = "POC"
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee - Release",
                    BuyerAtClosing = 640.00,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 1000.00,
                    BuyerPaidbyOther = 1000.00,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    BuyerDoubleAsteriskChecked = true
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee - Release2",
                    SellerPaidAtClosing = 20000.00,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 6000.00,
                    SellerPaidbyOthers = 100.00,
                    SellerPaidbyOtherPaymentMthd = "POC",

                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee Misc. description",
                    BuyerAtClosing = 78.46,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 0,
                    BuyerPaidbyOther = 1000.00,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 2345.00,
                    SellerChargePaymentMethod = "Check"
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD Screen. Expand Other Cost and verify the values displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "$16,648.00", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $3,261.30 Mortgage: $5,564.00", "$15,148.00", "$1,500.00", "$37,428.13", "$7,900.00", "$2,336.50", "$567,675.67", "$342,334.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$16,648.00", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$15,148.00", "$1,500.00", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$16,648.00", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$15,148.00", "$1,500.00", "$37,428.13", "$7,900.00", "$2,336.50" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Itemization Fees
                Reports.TestStep = "Verify CD Section E - Itemization Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$1,424.80", "", "", "", "" }, { "FACC E Recording Fee Deed2", "$424.80", "", "$200.00", "", "" }, { "**Modified - FACC Recording Fee - Deed to Added Payee name in", "$500.00", "$500.00", "$1,000.00", "$300.00", "$336.50" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$2,964.00", "", "", "", "" }, { "FACC E Recording Fee Mortgage to Added Payee Name in Admin", "$2,964.00", "", "", "", "" }, { "Updated FACC2 Recording Fee Mortgage to Updated Payee Name in", "", "", "$1,000.00", "$1,600.00", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$1,640.00", "", "", "", "" }, { "**FACC E Recording Fee - Release to Payee Name Filter", "$640.00", "$1,000.00", "", "", "$1,000.00" }, { "FACC E Recording Fee - Release2", "", "", "$20,000.00", "$6,000.00", "" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$10,619.20", "", "", "", "" }, { "**FACC E Recording Fee Misc. description to Continental Mortgage", "$78.46", "", "$2,345.00", "", "$1,000.00" }, { "FACC E Recording Fee Misc. description2 to Continental Mortgage", "$10,540.74", "", "$12,883.13", "", "" } });
                #endregion

                #region Edit LE amount in CD Section E - Other Costs => 10000.50
                Reports.TestStep = "Edit Loan Estimate Unrounded Value for Recording Fee. (E.g. 10,000.50)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 10000.50, 10001 }, { 0, 0 } }, recFeeRound: true);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 10000.50, LERounded: 10001, isRounded: true);
                #endregion

                #region Verify CD Good Faith Variance 10% category all sections
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$10,001", "$10,000.50", "$10,000.50", "$16,648.00" }, { "Total Aggregate Fees", "$10,000.50", "$16,648.00", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$1,000.00", "$6,647.50", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$5,647.50", "", "", "" } },
                    increaseTotal: 5647.50);
                #endregion

                #region Update PDD for OTC's Recording fees
                Reports.TestStep = @"Update PDD for OTC's Recording fees";
                FastDriver.OTCDetail.Open();
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee Deed",
                    BuyerAtClosing = 500.00,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 500.00,
                    BuyerPaidbyOther = 336.50,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    BuyerDoubleAsteriskChecked = false,
                    SellerPaidAtClosing = 1000.00,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 300.00,
                    SellerPaidbyOthers = 36.50,
                    SellerPaidbyOtherPaymentMthd = "POC"

                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Recording Fee Misc. description",
                    BuyerAtClosing = 78.46,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 0.00,
                    BuyerPaidbyOther = 1000.00,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    BuyerDoubleAsteriskChecked = false,
                    SellerPaidAtClosing = 2345.00,
                    SellerChargePaymentMethod = "Check"
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Calculate Fee and add Override amount for Recording Fee Deed. E.g. FACC Recording Fee – Deed (DEED - Recording Fee)
                Reports.TestStep = "Navigate to Calculate Fee and add Override amount for Recording Fee Deed. (E.g. FACC Recording Fee – Deed (DEED - Recording Fee))";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FAST_UpdateCalculateFeeSummary(summary: new string[,] { { "DEED - Recording Fee", "", "2,673.00", "FACC E Recording Fee Deed", "Buyer", "3 or More Simultaneous Policies", "5000", "50", "", "25,000.00", "25,000.00", "50,000.00" } });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD Screen. Expand Other Cost and verify the values displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "$40,311.50", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $50,588.30 Mortgage: $5,564.00", "$38,811.50", "$1,500.00", "$61,091.63", "$7,900.00", "$2,336.50", "$10,000.50", "$10,001.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$40,311.50", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$38,811.50", "$1,500.00", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$40,311.50", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$38,811.50", "$1,500.00", "$61,091.63", "$7,900.00", "$2,336.50" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Itemization Fees
                Reports.TestStep = "Verify CD Section E - Itemization Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$25,088.30", "", "", "", "" }, { "FACC E Recording Fee Deed2", "$424.80", "", "$200.00", "", "" }, { "Modified - FACC Recording Fee - Deed to Added Payee name in", "$24,163.50", "$500.00", "$24,663.50", "$300.00", "$336.50" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$2,964.00", "", "", "", "" }, { "FACC E Recording Fee Mortgage to Added Payee Name in Admin", "$2,964.00", "", "", "", "" }, { "Updated FACC2 Recording Fee Mortgage to Updated Payee Name in", "", "", "$1,000.00", "$1,600.00", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$1,640.00", "", "", "", "" }, { "**FACC E Recording Fee - Release to Payee Name Filter", "$640.00", "$1,000.00", "", "", "$1,000.00" }, { "FACC E Recording Fee - Release2", "", "", "$20,000.00", "$6,000.00", "" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$10,619.20", "", "", "", "" }, { "FACC E Recording Fee Misc. description to Continental Mortgage", "$78.46", "", "$2,345.00", "", "$1,000.00" }, { "FACC E Recording Fee Misc. description2 to Continental Mortgage", "$10,540.74", "", "$12,883.13", "", "" } });
                #endregion

                #region Verify CD Good Faith Variance 10% category all sections
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$10,001", "$10,000.50", "$10,000.50", "$40,311.50" }, { "Total Aggregate Fees", "$10,000.50", "$40,311.50", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$1,000.00", "$30,311.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$29,311.00", "", "", "" } },
                    increaseTotal: 29311.00);
                #endregion

                #region Enter Buyer credits and LE amount for Lender in New Loan - Loan Charges tab and Mortgage broker tab
                Reports.TestStep = @"Navigate to New Loan - Enter Buyer credits and LE amount for Lender in Loan Charges tab and Mortgage broker tab";
                FAST_UpdateLenderCredits(chargesTabValues: new string[,] { { "2", "", "", "", "430.56", "", "", "67554.56" } }, mortgageTabValues: new string[,] { { "2", "", "", "", "343.34", "", "", "763.45" } });
                #endregion

                #region Remove override reasons for fees in Calculate Fee Summary screen
                Reports.TestStep = "Navigate to Fee Entry | Calculate Fee Summary screen. Remove override reasons for all fees.";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FAST_UpdateCalculateFeeSummary(summary: new string[,] { { "AMENDMENT - Recording Fee","","174.00","FACC E Recording Fee Misc. description2","Buyer","","","45","","78.30","95.70","174.00" }, 
                    {"ASSIGNMENT - Recording Fee","","273.00","FACC E Recording Fee Misc. description","Seller","","","","273","0.00","273.00","273.00" }, 
                    { "DEED - Recording Fee", "", "2,673.00", "FACC E Recording Fee Deed", "Buyer", "", "", "50", "", "1,336.50", "1,336.50", "2,673.00" } });
                FastDriver.BottomFrame.Done();
                #endregion
                
                #region Navigate to Terms/Dates/Status and update the Sales Price
                Reports.TestStep = "Navigate to Terms/Dates/Status and update the Sales Price. (E.g. 160000). System displays recalculation pop up. Click on Ok button.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SalesPriceAmount.Click();
                Keyboard.SendKeys("160000");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 10);
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 10);
                Support.AreEqual("Sale Price has changed.  Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to New Loan screen and modify First New Loan Amount. (E.g. 15000)
                Reports.TestStep = "Navigate to New Loan screen and modify First New Loan Amount. (E.g. 15000).System displays a pop up with below mentioned message. Click on Ok button.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsLoanAmount.Click();
                Keyboard.SendKeys("15000");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD Screen. Expand Other Cost and verify the values displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "$6,522.06", "", "", "", "", "", "" }, { "01. Recording Fees Deed: $3,297.80 Mortgage: $5,564.00", "$5,522.06", "$1,000.00", "$22,905.20", "$7,600.00", "$1,000.00", "$10,000.50", "$10,001.00" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "$6,522.06", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "$5,522.06", "$1,000.00", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "$5,748.16", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "$5,522.06", "$1,000.00", "$22,905.20", "$7,600.00", "$1,000.00" } },
                    displayLE: true);
                #endregion

                #region Verify CD Section E - Itemization Fees
                Reports.TestStep = "Verify CD Section E - Itemization Fees";
                FAST_VerifyRecordingItemizationTable(deedFees: new string[,] { { "Recording Fee - Deed", "$1,761.30", "", "", "", "" }, { "FACC E Recording Fee Deed2", "$424.80", "", "$200.00", "", "" }, { "Modified - FACC Recording Fee - Deed to Added Payee name in", "$1,336.50", "", "$1,336.50", "", "" } },
                    mortgageFees: new string[,] { { "Recording Fee - Mortgage", "$2,964.00", "", "", "", "" }, { "FACC E Recording Fee Mortgage to Added Payee Name in Admin", "$2,964.00", "", "", "", "" }, { "Updated FACC2 Recording Fee Mortgage to Updated Payee Name in", "", "", "$1,000.00", "$1,600.00", "" } },
                    releaseFees: new string[,] { { "Recording Fee - Release", "$1,640.00", "", "", "", "" }, { "**FACC Recording Fee - Release Loan est. to Payee Name Filter", "$640.00", "$1,000.00", "", "", "$1,000.00" }, { "FACC E Recording Fee - Release", "", "", "$20,000.00", "$6,000.00", "$100.00" } },
                    miscFees: new string[,] { { "Recording Fee - Miscellaneous", "$156.76", "", "", "", "" }, { "FACC E Recording Fee Misc. description to Continental Mortgage", "$78.46", "", "$273.00", "", "" }, { "FACC E Recording Fee Misc. description2 to Continental Mortgage", "$78.30", "", "$95.70", "", "" } });
                #endregion

                #region Verify CD Good Faith Variance 10% category all sections
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "J 00 Lender Credits (See Lender Credit Analysis)", "-$68,318", "-$773.90", "-$68,318.01", "$67,544.11" }, { "Increase in Closing Costs above legal limits - 0% Category", "$67,544.11", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$773.90" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$773.90" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$10,001", "$10,000.50", "$10,000.50", "$6,522.06" }, { "Total Aggregate Fees", "$10,000.50", "$6,522.06", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$1,000.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } },
                    increaseTotal: 67544.11);
                #endregion

                #region Add override reasons for fees in Calculate Fee Summary screen
                Reports.TestStep = "Navigate to Fee Entry | Calculate Fee Summary Screen. Add Override reason for any fees. (E.g. AMENDMENT - Recording Fee)";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FAST_UpdateCalculateFeeSummary(summary: new string[,] { { "AMENDMENT - Recording Fee", "", "174.00", "FACC E Recording Fee Misc. description2", "Buyer", "Premium Split", "15000", "45", "", "6,750.00", "8,250.00", "15,000.00" } });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Property Tax Info.  and modify state and county.
                Reports.TestStep = "Navigate to Property Tax Info.  and modify state and county.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItemBySendingKeys(index: 8);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing State will result in the removal or replacements of the ST License ID", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing the State or County will result in removal of all calculated fees. Do you wish to continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.Click();
                Keyboard.SendKeys("Apache{TAB}");
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing the State or County will result in removal of all calculated fees. Do you wish to continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Section E - Other Costs
                Reports.TestStep = "Navigate to CD Screen. Expand Other Cost and verify the values displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E. Taxes and Other Government Fees", "", "", "", "", "", "", "" }, { "01. Recording Fees Deed: Mortgage:", "", "", "", "", "", "", "" } },
                    sectionIValues: new string[,] { { "I.  TOTAL OTHER COSTS (Borrower-Paid)", "", "", "", "", "" }, { "Other Costs Subtotals (E + F + G + H)", "", "", "", "", "" } },
                    sectionJValues: new string[,] { { "J.  TOTAL CLOSING COSTS (Borrower-Paid)", "-$773.90", "", "", "", "" }, { "Closing Costs Subtotals (D + I)", "", "", "", "", "" } },
                    displayLE: true);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Section E: New Loan | Future Recording Fee

        [TestMethod]
        [Description("New Loan: Verify charges in Section E – Line 1 with Future Recording Fees.")]
        public void SectionE_Scenario6()
        {
            try
            {
                Reports.TestDescription = "Verify charges in Section E – Line 1 with Future Recording Fees.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with business party WF as New Lender";
                FAST_WCF_File_IIS("WF", GABRole: AdditionalRoleType.NewLender, isTO: true, isEO: true);
                #endregion

                #region Navigate to CD screen and verify the + sign in other cost section
                Reports.TestStep = "Navigate to CD screen and verify the + sign in other cost section";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OCSectionETable);
                Support.IsTrue(!FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.ItemizedRecordingFeePlusIcon, continueOnFailure: true), "the + sign in other cost section");
                #endregion

                #region Add Buyer Charge for New Lean | Loan Charges | future recording Fee
                Reports.TestStep = @"Add Buyer Charge for any future recording Fee. (E.g. Future Recording Fee 1:  Buyer Charge $999.99)";
                FAST_AddLoanCharges_FutureRecFees(new PDD[] { 
                new PDD() { 
                    BuyerAtClosing = 1000.50,
                    UseDefaultChecked = false,
                    ChargeDescription = "Future Recording Fee 1",
                    PDDDescription = "Modified Future Recording",
                    PayeeName = "Modified Payee Name"
                },
                new PDD(){
                    BuyerAtClosing = 2423423,
                    UseDefaultChecked = false,
                    ChargeDescription = "Future Recording Fee 2",
                    PayeeName = ""
                }
            });
                #endregion

                #region Add Buyer Charge for New Lean | Loan Mortage | future recording Fee
                Reports.TestStep = @"Select Mortgage Broker tab. Add GAB Information (E.g. 415) and expand Future Recording Fees collected by MB/Lender.";
                FAST_AddMortgage_FutureRecFees(new PDD[] { 
                new PDD() { 
                    BuyerAtClosing = 233123452.45,
                    UseDefaultChecked = true,
                    ChargeDescription = "Future Recording Fee 1",
                },
                new PDD(){
                    BuyerAtClosing = 34234,
                    UseDefaultChecked = false,
                    ChargeDescription = "Future Recording Fee 2",
                    PayeeName = "Payee Name Mortgage Broker"
                }
            }, GABCode: "415");
                #endregion

                #region Verify CD Section E - Other Costs - Itemization Table
                Reports.TestStep = @"Navigate to CD screen. Expand Other Cost and verify if system displays + icon.";
                FAST_VerifyRecordingItemizationTable(
                    lenderFees: new string[,] { { "Future Recording Fee - Lender", "$2,424,423.50", "", "", "", "" }, { "Future Recording Fee 2", "$2,423,423.00", "", "", "", "" }, { "Modified Future Recording to Modified Payee Name", "$1,000.50", "", "", "", "" } },
                    mbFees: new string[,] { { "Future Recording Fee - Mortgage Broker", "$233,157,686.45", "", "", "", "" }, { "Future Recording Fee 1 to Continental Mortgage", "$233,123,452.45", "", "", "", "" }, { "Future Recording Fee 2 to Payee Name Mortgage Broker", "$34,234.00", "", "", "", "" } });
                #endregion

                #region Verify Good Faith Variance 10% category table and Lender Credit Analysis
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$0", "$0.00", "$0.00", "$235,582,109.95" }, { "Total Aggregate Fees", "$0.00", "$235,582,109.95", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$0.00", "$235,582,109.95", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$235,582,109.95", "", "", "" } },
                    increaseTotal: 235582109.95);
                #endregion

                #region Navigate to New Loan | Loan Charge Screen and Modify the buyer amount
                Reports.TestStep = @"Navigate to New Loan | Loan Charge Screen and Modify the buyer amount";
                FAST_AddLoanCharges_FutureRecFees(new PDD[] { 
                new PDD(){
                    BuyerAtClosing = 34534.70,
                    UseDefaultChecked = false,
                    ChargeDescription = "Future Recording Fee 2",
                }
            });
                Reports.TestStep = "Select Mortgage Broker tab and modify the buyer amount.";
                FAST_AddMortgage_FutureRecFees(new PDD[] { 
                new PDD() { 
                    BuyerAtClosing = 32423.45,
                    UseDefaultChecked = true,
                    ChargeDescription = "Future Recording Fee 1",
                }
            });
                #endregion

                #region Navigate to Fee Entry | Recording Fee and Tax tab and enter Loan Estimate Amount Unrounded. (E.g. 2423423.45)
                Reports.TestStep = @"Navigate to Fee Entry | Recording Fee and Tax tab and enter Loan Estimate Amount Unrounded. (E.g. 2423423.45)";
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 2423423.45, 2423423 }, { 0, 0 } });
                #endregion

                #region Verify CD Section E - Other Costs - Itemization Table
                Reports.TestStep = @"Navigate to CD screen. Expand Other Cost and verify if system displays + icon.";
                FAST_VerifyRecordingItemizationTable(
                    lenderFees: new string[,] { { "Future Recording Fee - Lender", "$35,535.20", "", "", "", "" }, { "Future Recording Fee 2", "$34,534.70", "", "", "", "" }, { "Modified Future Recording to Modified Payee Name", "$1,000.50", "", "", "", "" } },
                    mbFees: new string[,] { { "Future Recording Fee - Mortgage Broker", "$66,657.45", "", "", "", "" }, { "Future Recording Fee 1 to Continental Mortgage Corporation", "$32,423.45", "", "", "", "" }, { "Future Recording Fee 2 to Payee Name Mortgage Broker", "$34,234.00", "", "", "", "" } });
                #endregion

                #region Verify Good Faith Variance 10% category table and Lender Credit Analysis
                Reports.TestStep = "Select Good Faith Variance tab and verify the values displayed in 10% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    cat10Table: new string[,] { { "E 01 Recording Fees", "$2,423,423", "$2,423,423.45", "$2,423,423.45", "$102,192.65" }, { "Total Aggregate Fees", "$2,423,423.45", "$102,192.65", "", "" }, { "Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate", "$242,342.00", "$0.00", "", "" }, { "Increase in Closing Costs above legal limits - 10% Category", "$0.00", "", "", "" } });
                #endregion

                #region Navigate to New Loan | Loan Charges tab. Click on Pay Charges and add a new payee. (E.g. 989)
                Reports.TestStep = @"Navigate to New Loan | Loan Charges tab. Click on Pay Charges and add a new payee. (E.g. 989)";
                FAST_AddLoanCharges_Payee("989", new string[] { "Modified Future Recording" });
                #endregion

                #region Navigate to New Loan | Mortgage Broker tab. Click on Pay Charges and add a new payee. (E.g. 919)
                Reports.TestStep = @"Navigate to New Loan | Mortgage Broker tab. Click on Pay Charges and add a new payee. (E.g. 919)";
                FAST_AddLoanMortgage_Payee("919", new string[] { "Future Recording Fee 1" });
                #endregion

                #region Verify CD Section E - Other Costs - Itemization Table
                Reports.TestStep = @"Navigate to CD screen. Expand Other Cost and verify if system displays + icon.";
                FAST_VerifyRecordingItemizationTable(
                    lenderFees: new string[,] { { "Future Recording Fee - Lender", "$35,535.20", "", "", "", "" }, { "Future Recording Fee 2", "$34,534.70", "", "", "", "" }, { "Modified Future Recording to Modified Payee Name", "$1,000.50", "", "", "", "" } },
                    mbFees: new string[,] { { "Future Recording Fee - Mortgage Broker", "$66,657.45", "", "", "", "" }, { "Future Recording Fee 1 to Bloom County Tax Authority", "$32,423.45", "", "", "", "" }, { "Future Recording Fee 2 to Payee Name Mortgage Broker", "$34,234.00", "", "", "", "" } });
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Section E: Non – FACC – Transfer Tax

        [TestMethod]
        [Description("Fee Entry – Verify charges in Section E – Line 2 with all Transfer Tax Fee types.")]
        public void SectionE_Scenario7()
        {
            try
            {
                Reports.TestDescription = "Fee Entry – Verify charges in Section E – Line 2 with all Transfer Tax Fee types.";

                //  SectionE_Scenario7_1

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with New Lender(WF), Mortgage Broker(312), Sales Price ($56700), Loan Amount($74545.56), City (Santa Ana), State (CA) and County(Orange).";
                FAST_WCF_File_IIS("312", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, SPAmt: 56700, loanAmt: (decimal)74545.56, LenderID: "WF");
                #endregion

                #region FAST add fee to file
                Reports.TestStep = "Navigate to Fee Entry screen. Select Recording Fee and Tax. Click on Add Fees and add above created Fees (Without Filters).";
                FAST_AddFileFees(new PDD[] { 
                    new PDD() { ChargeDescription = "CD - E Transfer Tax Deed1", BuyerAtClosing = 98763.50, BuyerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "CD - E Transfer Tax Deed2", BuyerAtClosing = 2343.56, BuyerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "CD - E Transfer Tax Deed3", SellerPaidAtClosing = 234232.56, SellerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "CD - Transfer Tax – Miscellaneous", SellerPaidAtClosing = 3433.45, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "CD - E Transfer Tax Misc. 2", BuyerAtClosing = 34234.56, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 23433.43, SellerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "CD - E Transfer Tax Misc. description1", BuyerAtClosing = 233232312.76, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 233232312.76, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "CD - E Transfer Tax – Mortgage", BuyerAtClosing = 5000.50, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 4560.67, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "CD - E Transfer Tax – Mortgage1", BuyerAtClosing = 228.38, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 228.38, SellerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "CD - E Transfer Tax – Mortgage2", SellerPaidAtClosing = 567.67, SellerChargePaymentMethod = "Fee" }
                }, isTE: false);
                #endregion

                #region Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.
                Reports.TestStep = @"Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$233,372,883.26", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                        { "02. CD - E Transfer Tax – Mortgage","$5,000.50","","$4,560.67","","", },
                        { "03. CD - E Transfer Tax – Mortgage1 to Payee Name Filter","$228.38","","$228.38","",""},
                        { "04. CD - E Transfer Tax – Mortgage2","","","$567.67","","" },
                        { "05. CD - E Transfer Tax Deed1", "$98,763.50","","$98,763.50","",""},
                        { "06. CD - E Transfer Tax Deed2 to Wonderful Tax Collector", "$2,343.56","","","",""},
                        { "07. CD - E Transfer Tax Deed3 to Added Payee Name in Admin", "","","$234,232.56","",""},
                        { "08. CD - E Transfer Tax Misc. 2 to Wonderful Tax Collector", "$34,234.56","","$23,433.43","",""},
                        { "09. CD - E Transfer Tax Misc. description1", "$233,232,312.76","","$233,232,312.76","",""}
                });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$0", "$233,372,883.26", "$0.00", "$233,372,883.26" }, { "Increase in Closing Costs above legal limits - 0% Category", "$233,372,883.26", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 233372883.26);
                #endregion

                #region Enter Loan Estimate Unrounded amount. (E.g. 598765.55)
                Reports.TestStep = @"Enter Loan Estimate Unrounded amount. (E.g. 598765.55)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 0, 0 }, { 598765.55, 598766 } }, recFeeRound: true, ttaxFeeRound: true);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 598765.55, LERounded: 598766, isRounded: true);
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$598,766", "$233,372,883.26", "$598,765.55", "$232,774,117.71" }, { "Increase in Closing Costs above legal limits - 0% Category", "$232,774,117.71", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 232774117.71);
                #endregion

                #region Navigate to Fee Entry Screen | Recording and Tax tab and verify if system displays the Loan Estimate Unrounded and Rounded amount.
                Reports.TestStep = @"Navigate to Fee Entry Screen | Recording and Tax tab and verify if system displays the Loan Estimate Unrounded and Rounded amount.";
                FAST_VerifyRecTaxLEAmounts(LEvalues: new double[,] { { 0, 0 }, { 598765.55, 598766 } });
                #endregion

                #region Modify Recoring Fee buyer/seller amount
                Reports.TestStep = @"Modify Recoring Fee buyer/seller amount";
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax Deed1", BuyerAtClosing = 5698.49, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 2312.50, SellerChargePaymentMethod = "Fee" }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax Deed2", BuyerAtClosing = 2343.56, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 3433.45, SellerChargePaymentMethod = "Check" }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - Transfer Tax – Miscellaneous", BuyerAtClosing = 43543.78, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 3433.45, SellerChargePaymentMethod = "Fee" }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax – Mortgage", BuyerAtClosing = 85754.67, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 4560.67, SellerChargePaymentMethod = "Fee" }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax – Mortgage1", BuyerAtClosing = 228.38, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 5344.44, SellerChargePaymentMethod = "Check" }, isTE: false);
                #endregion

                #region Modify Loan Estimate Unrounded amount. (E.g. 463434.45)
                Reports.TestStep = @"Modify Loan Estimate Unrounded amount. (E.g. 463434.45)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 0, 0 }, { 463434.45, 463434 } }, recFeeRound: true, ttaxFeeRound: true);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 463434.45, LERounded: 463434, isRounded: true);
                #endregion

                //  SectionE_Scenario7_2

                #region Expand Other Cost and verify the values displayed in Section E, Line 2+
                Reports.TestStep = @"Expand Other Cost and verify the values displayed in Section E, Line 2+.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$233,404,116.20", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                        { "02. CD - E Transfer Tax – Mortgage","$85,754.67","","$4,560.67","","", },
                        { "03. CD - E Transfer Tax – Mortgage1 to Payee Name Filter","$228.38","","$5,344.44","",""},
                        { "04. CD - E Transfer Tax – Mortgage2","","","$567.67","","" },
                        { "05. CD - E Transfer Tax Deed1", "$5,698.49","","$2,312.50","",""},
                        { "06. CD - E Transfer Tax Deed2 to Wonderful Tax Collector", "$2,343.56","","$3,433.45","",""},
                        { "07. CD - E Transfer Tax Deed3 to Added Payee Name in Admin", "","","$234,232.56","",""},
                        { "08. CD - E Transfer Tax Misc. 2 to Wonderful Tax Collector", "$34,234.56","","$23,433.43","",""},
                        { "09. CD - E Transfer Tax Misc. description1", "$233,232,312.76","","$233,232,312.76","",""}
                });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$463,434", "$233,404,116.20", "$463,434.45", "$232,940,681.75" }, { "Increase in Closing Costs above legal limits - 0% Category", "$232,940,681.75", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 232940681.75);
                #endregion

                #region Enter Loan Estimate Rounded amount. (E.g. 3423.45)
                Reports.TestStep = @"Enter Loan Estimate Rounded amount. (E.g. 3423.45)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 0, 0 }, { 463434.45, 3423.45 } }, recFeeRound: true, ttaxFeeRound: false);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 463434.45, LERounded: 3423.45, isRounded: false);
                #endregion
                
                #region Try to remove the Charge description for any of the charge
                Reports.TestStep = @"Try to Remove the Charge description for any of the charge.";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OCSectionEplusTable);
                FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(3, 1, TableAction.SetText, " ");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Loan Estimate Description cannot be blank.", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                #endregion

                #region Modify Charge description for “CD - E Rec Fee Deed Loan Est. Description”
                Reports.TestStep = @"Modify Charge description for “CD - E Rec Fee Deed Loan Est. Description” to “Deed3 modified charge description with maximum characters in CD Screen";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(1, "CD - E Transfer Tax Deed3", 1, TableAction.SetText, "Deed3 modified charge description within maximum characters in CD Screen");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Fee Entry Screen | Recording and Tax tab and verify if system displays the Loan Estimate Unrounded and Rounded amount.
                Reports.TestStep = @"Navigate to Fee Entry Screen | Recording and Tax tab and verify if system displays the Loan Estimate Unrounded and Rounded amount.";
                FAST_VerifyRecTaxLEAmounts(LEvalues: new double[,] { { 0, 0 }, { 463434.45, 3423.00 } }, ttaxFeeRound: false);
                #endregion

                #region Open PDD for the below mentioned fees and modify the values in PDD
                Reports.TestStep = @"Open PDD for the below mentioned fees and modify the values in PDD.";
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax Deed1", BuyerAtClosing = 500.56, BuyerBeforeClosing = 232.34, BuyerPaidbyOther = 789.45, BuyerPaidbyOtherPaymentMethod = "Lender", BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 895.56, SellerPaidBeforeClosing = 234.51, SellerPaidbyOthers = 678.67, SellerPaidbyOtherPaymentMthd = "Lender", SellerChargePaymentMethod = "Fee", LEDescription = "Source Screen Updated Description", PayeeName = "Source - Wells Fargo Payee Name", BuyerDoubleAsteriskChecked = true }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax Deed2", BuyerAtClosing = 2343.56, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 0, SellerPaidBeforeClosing = 3432.45, SellerChargePaymentMethod = "Check" }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax Deed3", BuyerAtClosing = 3454.75, BuyerBeforeClosing = 7684.23, BuyerPaidbyOther = 8656.56, BuyerPaidbyOtherPaymentMethod = "POC", BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 5675.50, SellerPaidBeforeClosing = 3232.34, SellerPaidbyOthers = 9865.23, SellerPaidbyOtherPaymentMthd = "POC", SellerChargePaymentMethod = "Check", LEDescription = "Updated Description in Source Screen", PayeeName = "Bank of American Payee Name with Max Characters", BuyerDoubleAsteriskChecked = true }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax Misc. description1", BuyerAtClosing = 34545.23, BuyerBeforeClosing = 90678.89, BuyerPaidbyOther = 4356.09, BuyerChargePaymentMethod = "Fee", BuyerPaidbyOtherPaymentMethod = "Mortgage Broker", SellerPaidAtClosing = 3433.45, SellerChargePaymentMethod = "Fee" }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax – Mortgage2", BuyerAtClosing = 228.38, BuyerChargePaymentMethod = "Fee", BuyerDoubleAsteriskChecked = true, SellerPaidAtClosing = 7845.23, SellerPaidBeforeClosing = 76342.34, SellerPaidbyOthers = 4342.45, SellerPaidbyOtherPaymentMthd = "Lender", SellerLenderCheckbox = false, SellerChargePaymentMethod = "Fee" }, isTE: false);
                #endregion

                #region Expand Other Cost and verify the values displayed in Section E, Line 2+
                Reports.TestStep = @"Expand Other Cost and verify the values displayed in Section E, Line 2+.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$303,429.33", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                    { "02. CD - E Transfer Tax – Mortgage","$85,754.67","","$4,560.67","","", },
                    { "03. CD - E Transfer Tax – Mortgage1 to Payee Name Filter","$228.38","","$5,344.44","",""},
                    { "04. ** CD - E Transfer Tax – Mortgage2","$228.38","","$7,845.23","$76,342.34","" },
                    { "05. CD - E Transfer Tax Deed2 to Wonderful Tax Collector", "$2,343.56","","","$3,432.45",""},
                    { "06. CD - E Transfer Tax Misc. 2 to Wonderful Tax Collector", "$34,234.56","","$23,433.43","",""},
                    { "07. CD - E Transfer Tax Misc. description1", "$34,545.23","$90,678.89","$3,433.45", "","$4,356.09"},
                    { "08. CD - Transfer Tax – Miscellaneous to Payee Name updated", "$43,543.78","","$3,433.45","",""},
                    { "09. ** Source Screen Updated Description to Source - Wells Fargo Payee", "$500.56","$232.34","$895.56","$234.51","$789.45"}
                });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$3,423", "$303,429.33", "$463,434.45", "$0.00" }, { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$5,145.54", "$0.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "E 02+ Transfer Taxes", "-$5,145.54" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$5,145.54" } });
                #endregion

                #region Select CD Screen. Enter Loan Estimate Unrounded amount. (E.g. 3423.45)
                Reports.TestStep = @"Select CD Screen. Enter Loan Estimate Unrounded amount. (E.g. 3423.45)";
                FAST_UpdateRecTaxLEAmounts(new double[,] { { 0, 0 }, { 3423.45, 3423.00 } }, ttaxFeeRound: true);
                #endregion

                #region Navigate to Fee Entry Screen. Click on Pay Recording/Tax button and add new Payee. (E.g. 615)
                Reports.TestStep = @"Navigate to Fee Entry Screen. Click on Pay Recording/Tax button and add new Payee. (E.g. 615)";
                FAST_AddFileFeesRec_Payee("BOA", new string[] { "CD - E Transfer Tax – Mortgage1", "CD - E Transfer Tax Misc. description1" });
                #endregion

                #region Open PDD for the below mentioned fees and modify the values in PDD
                Reports.TestStep = @"Open PDD for the below mentioned fees and modify the values in PDD.";
                FastDriver.FileFees.SwitchToContentFrame();
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax Deed3", BuyerAtClosing = 34534.34, BuyerBeforeClosing = 6754.7, BuyerPaidbyOther = 3423.67, BuyerPaidbyOtherPaymentMethod = "POC", BuyerDoubleAsteriskChecked = false }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - E Transfer Tax – Mortgage2", BuyerDoubleAsteriskChecked = false, SellerPaidbyOtherPaymentMthd = "Lender", SellerLenderCheckbox = true }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD() { ChargeDescription = "CD - Transfer Tax – Miscellaneous", SellerPaidAtClosing = 10.50, SellerPaidBeforeClosing = 30.34, SellerPaidbyOthers = 40.23, SellerPaidbyOtherPaymentMthd = "Mortgage Broker", SellerChargePaymentMethod = "Fee" }, isTE: false);
                #endregion

                #region Update Lender Credits in New Loan Screen | Loan Charges & Mortgage Tab
                Reports.TestStep = @"Update Lender Credits in New Loan Screen | Loan Charges & Mortgage Tab.";
                FAST_UpdateLenderCredits(new string[,] { { "2", "", "", "", "5600.67", "", "", "7856.56" } }, new string[,] { { "2", "", "", "", "234.34", "", "", "343.34" } });
                #endregion

                #region Expand Other Cost and verify the values displayed in Section E, Line 2+
                Reports.TestStep = @"Expand Other Cost and verify the values displayed in Section E, Line 2+.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$333,579.39", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                { "02. CD - E Transfer Tax – Mortgage","$85,754.67","","$4,560.67","","", },
                { "03. CD - E Transfer Tax – Mortgage1 to Bank of America","$228.38","","$5,344.44","",""},
                { "04. CD - E Transfer Tax – Mortgage2","$228.38","","$7,845.23","$76,342.34","" },
                { "05. CD - E Transfer Tax Deed2 to Wonderful Tax Collector", "$2,343.56","","","$3,432.45",""},
                { "06. CD - E Transfer Tax Misc. 2 to Wonderful Tax Collector", "$34,234.56","","$23,433.43","",""},
                { "07. CD - E Transfer Tax Misc. description1 to Bank of America", "$34,545.23","$90,678.89","$3,433.45","","$4,356.09"},
                { "08. CD - Transfer Tax – Miscellaneous to Payee Name updated", "$43,543.78","","$10.50","$30.34",""},
                { "09. ** Source Screen Updated Description to Source - Wells Fargo Payee", "$500.56","$232.34","$895.56","$234.51","$789.45"}
            });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$3,423", "$333,579.39", "$3,423.45", "$330,155.94" }, { "J 00 Lender Credits (See Lender Credit Analysis)", "-$8,200", "-$10,980.55", "-$8,199.90", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$330,155.94", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$5,835.01" }, { "Specific Lender Credits", "" }, { "E 02+ Transfer Taxes", "-$5,145.54" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$10,980.55" } },
                    increaseTotal: 330155.94);
                #endregion

                #region Uncheck all the Fees of Type Check for the default Payee.
                Reports.TestStep = @"Uncheck all the Fees of Type Check for the default Payee.";
                FAST_SelectFeesForPayee(none: true);
                #endregion

                #region Expand Other Cost and verify the values displayed in Section E, Line 2+
                Reports.TestStep = @"Expand Other Cost and verify the values displayed in Section E, Line 2+.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$333,579.39", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                { "02. CD - E Transfer Tax – Mortgage","$85,754.67","","$4,560.67","","", },
                { "03. CD - E Transfer Tax – Mortgage1 to Bank of America","$228.38","","$5,344.44","",""},
                { "04. CD - E Transfer Tax – Mortgage2","$228.38","","$7,845.23","$76,342.34","" },
                { "05. CD - E Transfer Tax Deed2", "$2,343.56","","","$3,432.45",""},
                { "06. CD - E Transfer Tax Misc. 2", "$34,234.56","","$23,433.43","",""},
                { "07. CD - E Transfer Tax Misc. description1 to Bank of America", "$34,545.23","$90,678.89","$3,433.45","","$4,356.09"},
                { "08. CD - Transfer Tax – Miscellaneous to Payee Name updated", "$43,543.78","","$10.50","$30.34",""},
                { "09. ** Source Screen Updated Description to Source - Wells Fargo Payee", "$500.56","$232.34","$895.56","$234.51","$789.45"}
            });
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("OTC – Verify charges in Section E – Line 2 with all Transfer Tax Fee types.")]
        public void SectionE_Scenario8()
        {
            try
            {
                Reports.TestDescription = "OTC – Verify charges in Section E – Line 2 with all Transfer Tax Fee types.";

                //  SectionE_Scenario8_1

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS(8191);
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file with New Lender(214), Mortgage Broker(415), Sales Price ($76853), Loan Amount($34234.34), City (Santa Ana), State (CA) and County(Orange).";
                FAST_WCF_File_IIS("415", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, SPAmt: 76853, loanAmt: (decimal)34234.34, LenderID: "214");
                #endregion

                #region Enter OTC's bussiness party
                Reports.TestStep = "Navigate to OTC Screen.  Enter GAB Code. (E.g. 247)";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.GABcode.FASetText("247");
                FastDriver.OTCDetail.Find.FAClick();
                FastDriver.OTCDetail.WaitCreation(FastDriver.OTCDetail.GABcodeLabel);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add OTC's Recording fees
                Reports.TestStep = "Click on Add Recording Fees button under Recording Fees & Transfer Taxes. Add Fees which were created in admin.";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.AddRecordingFees.FAClick();
                FastDriver.AddOTCFees.WaitForScreenToLoad();
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "CD - E Transfer Tax Deed1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "CD - E Transfer Tax Deed2", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "CD - E Transfer Tax Deed3", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "CD - Transfer Tax – Miscellaneous", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "CD - E Transfer Tax Misc. description1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "CD - E Transfer Tax Misc. 2", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage1", 1, TableAction.On);
                FastDriver.AddOTCFees.FeeTable.PerformTableAction(2, "CD - E Transfer Tax – Mortgage2", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Enter values for OTC's Recording fees
                Reports.TestStep = @"Enter values for OTC's Recording fees";
                FastDriver.OTCDetail.WaitForScreenToLoad();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax Deed2", 3, TableAction.SetText, "2343.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - Transfer Tax – Miscellaneous", 4, TableAction.SetText, "3433.45");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax Misc. 2", 3, TableAction.SetText, "34234.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax Misc. 2", 4, TableAction.SetText, "23433.43");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax – Mortgage", 3, TableAction.SetText, "5000.50");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax – Mortgage", 4, TableAction.SetText, "4560.67");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax – Mortgage2", 3, TableAction.SetText, "567.67");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.
                Reports.TestStep = @"Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$233,373,450.93", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                    { "02. CD - E Transfer Tax – Mortgage","$5,000.50","","$4,560.67","","", },
                    { "03. CD - E Transfer Tax – Mortgage1 to Payee Name Filter","$228.38","","$228.38","",""},
                    { "04. CD - E Transfer Tax – Mortgage2","$567.67","","","","" },
                    { "05. CD - E Transfer Tax Deed1", "$98,763.50","","$98,763.50","",""},
                    { "06. CD - E Transfer Tax Deed2", "$2,343.56","","","",""},
                    { "07. CD - E Transfer Tax Deed3 to Added Payee Name in Admin", "","","$234,232.56","",""},
                    { "08. CD - E Transfer Tax Misc. 2", "$34,234.56","","$23,433.43","",""},
                    { "09. CD - E Transfer Tax Misc. description1 to Lenders Advantage", "$233,232,312.76","","$233,232,312.76","",""}
                });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$0", "$233,373,450.93", "$0.00", "$233,373,450.93" }, { "Increase in Closing Costs above legal limits - 0% Category", "$233,373,450.93", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 233373450.93);
                #endregion

                #region Select CD Screen. Enter Loan Estimate Unrounded amount. (E.g. 598765.55)
                Reports.TestStep = @"Select CD Screen. Enter Loan Estimate Unrounded amount. (E.g. 598765.55)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 0, 0 }, { 598765.55, 598766 } });
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 598765.55, LERounded: 598766);
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$598,766", "$233,373,450.93", "$598,765.55", "$232,774,685.38" }, { "Increase in Closing Costs above legal limits - 0% Category", "$232,774,685.38", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 232774685.38);
                #endregion

                #region Verify if system displays the Loan Estimate Unrounded and Rounded amount in OTC screen
                Reports.TestStep = @"Verify if system displays the Loan Estimate Unrounded and Rounded amount in OTC screen";
                FAST_VerifyLEAmtOTC(new double[,] { { 0, 0 }, { 598765.55, 598766 } });
                #endregion

                #region Enter values for OTC's Recording fees
                Reports.TestStep = @"Enter values for OTC's Recording fees";
                //FastDriver.OTCDetail.WaitForScreenToLoad();
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax Deed1", 3, TableAction.SetText, "5698.49");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax Deed1", 4, TableAction.SetText, "2312.50");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax Deed2", 3, TableAction.SetText, "2343.56");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax Deed2", 4, TableAction.SetText, "3433.45");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - Transfer Tax – Miscellaneous", 3, TableAction.SetText, "43543.78");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax – Mortgage", 3, TableAction.SetText, "85754.67");
                FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, "CD - E Transfer Tax – Mortgage1", 3, TableAction.SetText, "5344.44");
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Modify Loan Estimate Unrounded amount. (E.g. 463434.45)
                Reports.TestStep = @"Modify Loan Estimate Unrounded amount. (E.g. 463434.45)";
                FAST_UpdateLEAmtOTC(new double[,] { { 0, 0 }, { 463434.45, 463434.00 } });
                #endregion

                #region Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.
                Reports.TestStep = @"Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$233,409,799.93", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                    { "02. CD - E Transfer Tax – Mortgage","$85,754.67","","$4,560.67","","", },
                    { "03. CD - E Transfer Tax – Mortgage1 to Payee Name Filter","$5,344.44","","$228.38","",""},
                    { "04. CD - E Transfer Tax – Mortgage2","$567.67","","","","" },
                    { "05. CD - E Transfer Tax Deed1", "$5,698.49","","$2,312.50","",""},
                    { "06. CD - E Transfer Tax Deed2", "$2,343.56","","$3,433.45","",""},
                    { "07. CD - E Transfer Tax Deed3 to Added Payee Name in Admin", "","","$234,232.56","",""},
                    { "08. CD - E Transfer Tax Misc. 2", "$34,234.56","","$23,433.43","",""},
                    { "09. CD - E Transfer Tax Misc. description1 to Lenders Advantage", "$233,232,312.76","","$233,232,312.76","",""}
                });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$463,434", "$233,409,799.93", "$463,434.45", "$232,946,365.48" }, { "Increase in Closing Costs above legal limits - 0% Category", "$232,946,365.48", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 232946365.48);
                #endregion

                #region Select Closing Disclosure section. Modify Loan Estimate Rounded Amount. (E.g. 3423.45)
                Reports.TestStep = @"Select Closing Disclosure section. Modify Loan Estimate Rounded Amount. (E.g. 3423.45)";
                //  Automation for updating LE amounts in CD Section E is not reliable.
                FAST_UpdateRecTaxLEAmounts(LEvalues: new double[,] { { 0, 0 }, { 463434.45, 3423.45 } }, ttaxFeeRound: false);
                FAST_VerifyLEAmtCDSectionE(LEUnrounded: 463434.45, LERounded: 3423.45, isRounded: false);
                #endregion
                
                #region Try to remove the Charge description for any of the charge
                Reports.TestStep = @"Try to Remove the Charge description for any of the charge.";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Othercosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OCSectionEplusTable);
                FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(3, 1, TableAction.SetText, " ");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Loan Estimate Description cannot be blank.", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                #endregion

                #region Modify Charge description for “CD - E Rec Fee Deed Loan Est. Description”
                Reports.TestStep = @"Modify Charge description for “CD - E Rec Fee Deed Loan Est. Description” to “Deed3 modified charge description with maximum characters in CD Screen";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(1, "CD - E Transfer Tax Deed3", 1, TableAction.SetText, "Deed3 modified charge description within maximum characters in CD Screen");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                #endregion

                //  SectionE_Scenario8_2

                #region Verify the loan estimate values displayed in Government Recording and Transfer Taxes.
                Reports.TestStep = @"Verify the loan estimate values displayed in Government Recording and Transfer Taxes.";
                FAST_VerifyLEAmtOTC(new double[,] { { 0, 0 }, { 463434.45, 3423.00 } }, ttaxFeeRound: false);
                #endregion

                #region Edit PDD for OTC's Recording fees
                Reports.TestStep = @"Edit PDD for OTC's Recording fees";
                FastDriver.OTCDetail.Open();
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "CD - E Transfer Tax Deed1",
                    LEDescription = "Source Screen Updated Description",
                    PayeeName = "Source - Wells Fargo Payee Name",
                    BuyerAtClosing = 500.56,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 232.34,
                    BuyerPaidbyOther = 789.45,
                    BuyerPaidbyOtherPaymentMethod = "POC",  // Lender not available
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 895.56,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 234.51,
                    SellerPaidbyOthers = 678.67,
                    SellerPaidbyOtherPaymentMthd = "POC"    // Lender not available
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "CD - E Transfer Tax Deed2",
                    SellerPaidAtClosing = 0,
                    SellerPaidBeforeClosing = 3433.45,
                    SellerPaidbyOthers = 0,
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "CD - E Transfer Tax Deed3",
                    LEDescription = "Updated Description in Source Screen",
                    PayeeName = "Bank of American Payee Name with Max Characters",
                    BuyerAtClosing = 3454.75,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 7684.23,
                    BuyerPaidbyOther = 8656.56,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 5675.50,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 3232.34,
                    SellerPaidbyOthers = 9865.23,
                    SellerPaidbyOtherPaymentMthd = "POC"
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "CD - E Transfer Tax Misc. description1",
                    BuyerAtClosing = 34545.23,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 90678.89,
                    BuyerPaidbyOther = 4356.09,
                    BuyerPaidbyOtherPaymentMethod = "POC",  //  Mortgage Broker is not available
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "CD - E Transfer Tax – Mortgage2",
                    SellerPaidAtClosing = 7845.23,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 76342.34,
                    SellerPaidbyOthers = 4342.45,
                    SellerPaidbyOtherPaymentMthd = "POC",   //  Lender is not available
                    SellerLenderCheckbox = false
                });
                #endregion

                #region Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.
                Reports.TestStep = @"Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$308,884.68", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                    { "02. CD - E Transfer Tax – Mortgage","$85,754.67","","$4,560.67","","", },
                    { "03. CD - E Transfer Tax – Mortgage1 to Payee Name Filter","$5,344.44","","$228.38","",""},
                    { "04. CD - E Transfer Tax – Mortgage2","$567.67","","$7,845.23","$76,342.34","" },
                    { "05. CD - E Transfer Tax Deed2", "$2,343.56","","","$3,433.45",""},
                    { "06. CD - E Transfer Tax Misc. 2", "$34,234.56","","$23,433.43","",""},
                    { "07. CD - E Transfer Tax Misc. description1 to Lenders Advantage", "$34,545.23", "$90,678.89","$233,232,312.76","","$4,356.09"},
                    { "08. CD - Transfer Tax – Miscellaneous to Payee Name updated", "$43,543.78","","$3,433.45","",""},
                    { "09. ** Source Screen Updated Description to Source - Wells Fargo Payee", "$500.56","$232.34","$895.56","$234.51","$789.45"}
                });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$3,423", "$308,884.68", "$463,434.45", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } });
                #endregion

                #region Edit PDD for OTC's Recording fees
                Reports.TestStep = @"Edit PDD for OTC's Recording fees";
                FastDriver.OTCDetail.Open();
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "CD - E Transfer Tax Deed3",
                    BuyerAtClosing = 34534.34,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 6754.7,
                    BuyerPaidbyOther = 3423.67,
                    BuyerPaidbyOtherPaymentMethod = "POC",  // Lender not available
                    BuyerDoubleAsteriskChecked = false,
                });
                #endregion

                #region Modify Loan Estimate Unrounded amount. (E.g. 3,434.45)
                Reports.TestStep = @"Modify Loan Estimate Unrounded amount. (E.g. 3,434.45)";
                FAST_UpdateLEAmtOTC(new double[,] { { 0, 0 }, { 3434.45, 3434.00 } });
                #endregion

                #region Enter Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
                Reports.TestStep = @"Navigate to New Loan - Loan Charges then enter Buyer Credit Amount and LE for Non-Specific Lender Credits.";
                FAST_UpdateLenderCredits(chargesTabValues: new string[,] { { "2", "", "", "", "5600.67", "", "", "7856.56" } },
                    mortgageTabValues: new string[,] { { "2", "", "", "", "234.34", "", "", "343.34" } });
                #endregion

                #region Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.
                Reports.TestStep = @"Navigate to CD Screen and verify the Transfer Taxes displayed in CD Screen under Other Cost – Section E.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$339,034.74", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                    { "02. CD - E Transfer Tax – Mortgage","$85,754.67","","$4,560.67","","", },
                    { "03. CD - E Transfer Tax – Mortgage1 to Payee Name Filter","$5,344.44","","$228.38","",""},
                    { "04. CD - E Transfer Tax – Mortgage2","$567.67","","$7,845.23","$76,342.34","" },
                    { "05. CD - E Transfer Tax Deed2", "$2,343.56","","","$3,433.45",""},
                    { "06. CD - E Transfer Tax Misc. 2", "$34,234.56","","$23,433.43","",""},
                    { "07. CD - E Transfer Tax Misc. description1 to Lenders Advantage", "$34,545.23","$90,678.89","$233,232,312.76","","$4,356.09"},
                    { "08. CD - Transfer Tax – Miscellaneous to Payee Name updated", "$43,543.78","","$3,433.45","",""},
                    { "09. ** Source Screen Updated Description to Source - Wells Fargo Payee", "$500.56","$232.34","$895.56","$234.51","$789.45"}
                });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$3,434", "$339,034.74", "$3,434.45", "$335,600.29" }, { "J 00 Lender Credits (See Lender Credit Analysis)", "-$8,200", "-$5,835.01", "-$8,199.90", "$2,364.89" }, { "Increase in Closing Costs above legal limits - 0% Category", "$337,965.18", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$5,835.01" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$5,835.01" } },
                    increaseTotal: 337965.18);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        # region Section E: FACC – Transfer Tax

        [TestMethod]
        [Description("Fee Entry – Verify charges in Section E – Line 2 with all Transfer Tax Fee types.")]
        public void SectionE_Scenario9()
        {
            try
            {
                Reports.TestDescription = "Fee Entry – Verify charges in Section E – Line 2 with all Transfer Tax Fee types.";

                //  SectionE_Scenario9_1

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = @"Create a basic file with New Loan Lender (415) and Mortgage Broker (314) with Sales Price (E.g. 98000.50) and Liability Amount (E.g. 8799976.98).";
                FAST_WCF_File_IIS("314", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, SPAmt: (decimal)98000.50, loanAmt: (decimal)8799976.98, LenderID: "415");
                #endregion

                #region Navigate to Fee Entry screen. Check “Recording Fees” checkbox and click on Calculate Fees button.
                Reports.TestStep = @"Navigate to Fee Entry screen. Check “Recording Fees” checkbox and click on Calculate Fees button.";
                FAST_AddFileFeesFACC(
                    recFees: new string[,] { 
                    { "Amendment", "56", "589079.98" }, 
                    { "Assignment", "89", "234234.34" }, 
                    { "Deed", "890", "567834.56" }, 
                    { "Mortgage", "986", "232332.45" }, 
                    { "POA", "876", "34234.34" }, 
                    { "Satisfaction", "878", "234234.34" }, 
                    { "Subordination", "8698", "8789789.00" }},
                    summary: new string[,] { 
                    { "AMENDMENT - Recording Fee",      "",     "174.00",   "FACC E Transfer Tax Deed",             "Buyer",    "", "", "", "", "174.00", "0.00", "174.00" }, 
                    { "ASSIGNMENT - Recording Fee",      "",    "273.00",   "FACC E Transfer Tax Deed2",            "Seller",   "", "", "", "", "0.00", "273.00", "273.00" },
                    { "DEED - Recording Fee",           "",     "2,673.00", "FACC E Transfer Tax Deed3",            "Buyer",    "", "", "", "", "2,673.00", "0.00", "2,673.00" },
                    { "DEED - Documentary Transfer Tax","",     "624.80",   "FACC E Transfer Tax – Mortgage1",      "Seller",   "", "", "", "", "0.00","624.80",  "624.80"},
                    { "MORTGAGE - Recording Fee",       "",     "2,964.00", "FACC E Transfer Tax – Mortgage2",      "Buyer",    "", "", "", "", "2,964.00","0.00",  "2,964.00"},
                    { "POA - Recording Fee",            "",     "2,631.00", "FACC E Transfer Tax Mortgage3",        "Seller",   "", "", "", "", "0.00","2,631.00",  "2,631.00"},
                    { "SATISFACTION - Recording Fee",   "",     "2,640.00", "FACC E Transfer Tax Misc. description1","Buyer",   "", "", "", "", "2,640.00","0.00",  "2,640.00"},
                    { "SUBORDINATION - Recording Fee",  "",     "26,100.00","FACC E Transfer Tax – Miscellaneous2", "Seller",   "", "", "", "", "0.00","26,100.00",  "26,100.00"}, 
                });
                #endregion

                #region Enter Loan Estimate Unrounded amount for Transfer Taxes. (E.g. 10500.57)
                Reports.TestStep = "Enter Loan Estimate Unrounded amount for Transfer Taxes. (E.g. 10500.57)";
                FAST_UpdateRecTaxLEAmounts(new double[,] { { 0, 0 }, { 10500.57, 10501.00 } });
                #endregion

                #region Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.
                Reports.TestStep = "Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$8,451.00", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                { "02. FACC E Transfer Tax – Miscellaneous2 to Added Payee Name in","","","$26,100.00","","", },
                { "03. FACC E Transfer Tax – Mortgage1 to Wonderful Tax Collector","","","$624.80","",""},
                { "04. FACC E Transfer Tax – Mortgage2 to Added Payee Name in Admin","$2,964.00","","","","" },
                { "05. FACC E Transfer Tax Deed", "$174.00","","","",""},
                { "06. FACC E Transfer Tax Deed2 to Added Payee Name in Admin", "","","$273.00","",""},
                { "07. FACC E Transfer Tax Deed3", "$2,673.00","","","",""},
                { "08. FACC E Transfer Tax Misc. description1", "$2,640.00","","","",""},
                { "09. FACC E Transfer Tax Mortgage3 to Wonderful Tax Collector", "","","$2,631.00","",""}
            });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$10,501", "$8,451.00", "$10,500.57", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } });
                #endregion

                #region Modify the LE amounts in CD screen Section E (E.g. 5690.87, Rounded Amount = 6690.80)
                Reports.TestStep = @"Select Closing Disclosure tab and modify the Loan Estimate unrounded and rounded amount. (E.g. 5690.87, Rounded Amount = 6690.80)";
                //  FAST_UpdateLEAmtCDSectionE is not reliable
                FAST_UpdateRecTaxLEAmounts(new double[,] { { 0, 0 }, { 5690.87, 6690.80 } }, ttaxFeeRound: false); 
                FAST_VerifyLEAmtCDSectionE(5690.87, 6690.80, isRounded: false);
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$6,690", "$8,451.00", "$5,690.87", "$2,760.13" }, { "Increase in Closing Costs above legal limits - 0% Category", "$2,760.13", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 2760.13);
                #endregion

                //  SectionE_Scenario9_2

                #region Verify the Loan Estimate rounded and unrounded amount in OTc screen
                Reports.TestStep = @"Verify the Loan Estimate rounded and unrounded amount in OTC screen";
                FAST_VerifyRecTaxLEAmounts(new double[,] { { 0, 0 }, { 5690.87, 6690.00 } }, ttaxFeeRound: false);
                #endregion

                #region Edit PDD for OTC's Recording fees
                Reports.TestStep = @"Edit PDD for OTC's Recording fees";
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Transfer Tax – Miscellaneous2",
                    LEDescription = "Modified - FACC Transfer Tax - Miscellaneous2 Maximum Values",
                    PayeeName = "Added Payee name in Source Screen PDD",
                    PartOfCheckbox = true,
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 6100,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 10000.00,
                    SellerPaidbyOthers = 10000.00,
                    SellerPaidbyOtherPaymentMthd = "POC"
                }, isTE: false);
                //  There is no charge for "FACC E Transfer Tax – Miscellaneous3"
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Transfer Tax Misc. description1",
                    PayeeName = "Wells Fargo Payee - PDD",
                    BuyerDoubleAsteriskChecked = true,
                    BuyerAtClosing = 640,
                    BuyerChargePaymentMethod = "Fee",
                    BuyerBeforeClosing = 1000,
                    BuyerPaidbyOther = 1000,
                    BuyerPaidbyOtherPaymentMethod = "Mortgage Broker"
                }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Transfer Tax – Mortgage1 ",
                    PayeeName = "Bank of American Payee",
                    SellerPaidAtClosing = 300,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 300,
                    SellerPaidbyOthers = 24.80,
                    SellerPaidbyOtherPaymentMthd = "POC"
                }, isTE: false);
                FAST_UpdateFileFeesPDD(new PDD()
                {
                    ChargeDescription = "FACC E Transfer Tax Deed",
                    PayeeName = "Deed Wells Fargo Payee – PDD",
                    BuyerDoubleAsteriskChecked = true,
                    BuyerAtClosing = 50,
                    BuyerChargePaymentMethod = "Fee",
                    BuyerBeforeClosing = 50,
                    BuyerPaidbyOther = 74,
                    BuyerPaidbyOtherPaymentMethod = "Lender"
                }, isTE: false);
                #endregion

                #region Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.
                Reports.TestStep = "Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$7,377.00", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                { "02. FACC E Transfer Tax – Mortgage1 to Bank of American Payee","","","$300.00","$300.00","", },
                { "03. FACC E Transfer Tax – Mortgage2 to Added Payee Name in Admin","$2,964.00","","","",""},
                { "04. ** FACC E Transfer Tax Deed to Deed Wells Fargo Payee –","$50.00","$50.00","","","$74.00" },
                { "05. FACC E Transfer Tax Deed2 to Added Payee Name in Admin", "","","$273.00","",""},
                { "06. FACC E Transfer Tax Deed3", "$2,673.00","","","",""},
                { "07. ** FACC E Transfer Tax Misc. description1 to Wells Fargo Payee -", "$640.00","$1,000.00","","","$1,000.00"},
                { "08. FACC E Transfer Tax Mortgage3 to Wonderful Tax Collector", "","","$2,631.00","",""},
                { "09. ** Modified - FACC Transfer Tax - Miscellaneous2 Maximum Values", "","","$6,100.00","$10,000.00",""}
            });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$6,690", "$7,377.00", "$5,690.87", "$1,686.13" }, { "J 00 Lender Credits (See Lender Credit Analysis)", "$0", "-$1,074.00", "$0.00", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$1,686.13", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "E 02+ Transfer Taxes", "-$1,074.00" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$1,074.00" } },
                    increaseTotal: 1686.13);
                #endregion

                #region Navigate to New Loan screen and modify First New Loan Amount. (E.g. 56000)
                Reports.TestStep = "Navigate to New Loan screen and modify First New Loan Amount. (E.g. 56000).System displays a pop up with below mentioned message. Click on Ok button.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("56000");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Loan Amount has changed. Do you wish to update the Loan Amount to the Loan Liability?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Terms/Dates/Status and update the Sales Price
                Reports.TestStep = "Navigate to Terms/Dates/Status and update the Sales Price. (E.g. 65000). System displays recalculation pop up. Click on Ok button.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SalesPriceAmount.Click();
                Keyboard.SendKeys("65000");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Sale Price has changed.  Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add override reasons for fees in Calculate Fee Summary screen
                Reports.TestStep = "Navigate to Fee Entry | Calculate Fee Summary Screen. Add Override reason for any fees. (E.g. AMENDMENT - Recording Fee)";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FAST_UpdateCalculateFeeSummary(summary: new string[,] { 
                { "AMENDMENT - Recording Fee",      "",     "174.00",   "FACC E Transfer Tax Deed",             "Buyer",    "Premium Split", "50000", "", "", "500,000.00", "0.00", "500,000.00" }, 
                { "ASSIGNMENT - Recording Fee",      "",    "273.00",   "FACC E Transfer Tax Deed2",            "Seller",   "Premium Split", "50000", "45", "", "275,000.00", "225,000.00", "500,000.00" },
                { "DEED - Recording Fee",           "",     "2,673.00", "FACC E Transfer Tax Deed3",            "Buyer",    "Premium Split", "50000", "", "23000", "23,000.00", "477,000.00", "500,000.00" },
            });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Pay Recording/Tax
                Reports.TestStep = @"Click on Pay Recording/Tax button and add new Payees. (E.g. 415)";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.PayRecordingTax.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad();
                FastDriver.RecordFeeTransferTaxDisb.New.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.GABcode.FASetText("415");
                FastDriver.RecordFeeTransferTaxDisb.Find.FAClick();
                FastDriver.RecordFeeTransferTaxDisb.WaitCreation(FastDriver.RecordFeeTransferTaxDisb.GABLabel, 5);
                FastDriver.RecordFeeTransferTaxDisb.None.Click();
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, "FACC E Transfer Tax – Mortgage2", 1, TableAction.On);
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, "FACC E Transfer Tax – Miscellaneous2", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.
                Reports.TestStep = "Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$802,530.00", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                { "02. FACC E Transfer Tax – Mortgage1 to Bank of American Payee","","","$300.00","$300.00","", },
                { "03. FACC E Transfer Tax – Mortgage2 to Continental Mortgage","$2,964.00","","","",""},
                { "04. ** FACC E Transfer Tax Deed to Deed Wells Fargo Payee –","$499,876.00","$50.00","","","$74.00" },
                { "05. FACC E Transfer Tax Deed2 to Added Payee Name in Admin", "$275,000.00","","$225,000.00","",""},
                { "06. FACC E Transfer Tax Deed3", "$23,000.00","","$477,000.00","",""},
                { "07. ** FACC E Transfer Tax Misc. description1 to Wells Fargo Payee -", "$640.00","$1,000.00","","","$1,000.00"},
                { "08. FACC E Transfer Tax Mortgage3 to Wonderful Tax Collector", "","","$2,631.00","",""},
                { "09. ** Modified - FACC Transfer Tax - Miscellaneous2 Maximum Values", "","","$6,100.00","$10,000.00",""}
            });
                #endregion

                #region Edit Loan Estimate Unrounded Value for Transfer Tax. (E.g. 10,000.50)
                Reports.TestStep = "Edit Loan Estimate Unrounded Value for Transfer Tax. (E.g. 10,000.50)";
                //  FAST_UpdateLEAmtCDSectionE is not reliable
                FAST_UpdateRecTaxLEAmounts(new double[,] { { 0, 0 }, { 10000.50, 10001.00 } }, ttaxFeeRound: true); 
                FAST_UpdateLEAmtCDSectionE(10000.50, 10001.00, isRounded: true);
                #endregion

                #region Enter Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
                Reports.TestStep = @"Navigate to New Loan - Loan Charges then enter Buyer Credit Amount and LE for Non-Specific Lender Credits.";
                FAST_UpdateLenderCredits(chargesTabValues: new string[,] { { "2", "", "", "", "4830.56", "", "", "67554.56" } },
                    mortgageTabValues: new string[,] { { "2", "", "", "", "3493.34", "", "", "7663.45" } });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$10,001", "$802,530.00", "$10,000.50", "$792,529.50" }, { "J 00 Lender Credits (See Lender Credit Analysis)", "-$75,218", "-$9,397.90", "-$75,218.01", "$65,820.11" }, { "Increase in Closing Costs above legal limits - 0% Category", "$858,349.61", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$8,323.90" }, { "Specific Lender Credits", "" }, { "E 02+ Transfer Taxes", "-$1,074.00" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$9,397.90" } },
                    increaseTotal: 858349.61);
                #endregion

                #region Navigate to Property Tax Info.  and modify state and county.
                Reports.TestStep = "Navigate to Property Tax Info.  and modify state and county.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItemBySendingKeys(index: 10);   //  CO
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing State will result in the removal or replacements of the ST License ID", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing the State or County will result in removal of all calculated fees. Do you wish to continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.Click();
                Keyboard.SendKeys("Adams{TAB}");
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing the State or County will result in removal of all calculated fees. Do you wish to continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify if all the fees are removed in Fee Entry and CD Screen.
                Reports.TestStep = "Verify if all the fees are removed in Fee Entry and CD Screen.";
                Support.Eval<Exception>(() =>
                {
                    FastDriver.FileFees.Open();
                    FastDriver.FileFees.RecordingandTax.Click();
                    FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                    FAST_UpdateFileFeesPDD(new PDD()
                    {
                        ChargeDescription = "FACC E Transfer Tax – Miscellaneous2",
                    }, isTE: false);
                }, exceptionExpected: true, reportMessage: "Verify if all the fees are removed in Fee Entry");
                Support.Eval<Exception>(() =>
                {
                    FAST_VerifyOtherCosts(
                        sectionEplus: new string[,]{{ "02. FACC E Transfer Tax – Mortgage2 to Continental","$2,964.00","","","","", }
                });
                }, exceptionExpected: true, reportMessage: "Verify if all the fees are removed inCD Screen");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("OTC – Verify charges in Section E – Line 1 with all Transfer Tax Fee types.")]
        public void SectionE_Scenario10()
        {
            try
            {
                Reports.TestDescription = "OTC – Verify charges in Section E – Line 1 with all Transfer Tax Fee types.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = @"Create a basic file with New Loan Lender (415) and Mortgage Broker (314) with Sales Price (E.g. 98000.50) and Liability Amount (E.g. 8799976.98).";
                FAST_WCF_File_IIS("314", GABRole: AdditionalRoleType.MortgageBroker, isTO: false, isEO: true, SPAmt: (decimal)98000.50, loanAmt: (decimal)8799976.98, LenderID: "415");
                #endregion

                #region Enter OTC's bussiness party
                Reports.TestStep = "Navigate to OTC Screen.  Enter GAB Code. (E.g. 215)";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.GABcode.FASetText("215");
                FastDriver.OTCDetail.Find.FAClick();
                FastDriver.OTCDetail.WaitCreation(FastDriver.OTCDetail.GABcodeLabel);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Fee Entry screen. Check “Recording Fees” checkbox and click on Calculate Fees button.
                Reports.TestStep = @"Navigate to Fee Entry screen. Check “Recording Fees” checkbox and click on Calculate Fees button.";
                FastDriver.OTCDetail.Open();
                FAST_AddOTCCalculateFees(
                    recFees: new string[,] { 
                    { "Amendment", "56", "589079.98" }, 
                    { "Assignment", "89", "234234.34" }, 
                    { "Deed", "890", "567834.56" }, 
                    { "Mortgage", "986", "232332.45" }, 
                    { "POA", "876", "34234.34" }, 
                    { "Satisfaction", "878", "234234.34" }, 
                    { "Subordination", "8698", "8789789.00" }},
                    summary: new string[,] { 
                    { "AMENDMENT - Recording Fee",      "",     "174.00",   "FACC E Transfer Tax Deed",             "Buyer",    "", "", "", "", "174.00", "0.00", "174.00" }, 
                    { "ASSIGNMENT - Recording Fee",      "",    "273.00",   "FACC E Transfer Tax Deed2",            "Seller",   "", "", "", "", "0.00", "273.00", "273.00" },
                    { "DEED - Recording Fee",           "",     "2,673.00", "FACC E Transfer Tax Deed3",            "Buyer",    "", "", "", "", "2,673.00", "0.00", "2,673.00" },
                    { "DEED - Documentary Transfer Tax","",     "624.80",   "FACC E Transfer Tax – Mortgage1",      "Seller",   "", "", "", "", "0.00","624.80",  "624.80"},
                    { "MORTGAGE - Recording Fee",       "",     "2,964.00", "FACC E Transfer Tax – Mortgage2",      "Buyer",    "", "", "", "", "2,964.00","0.00",  "2,964.00"},
                    { "POA - Recording Fee",            "",     "2,631.00", "FACC E Transfer Tax Mortgage3",        "Seller",   "", "", "", "", "0.00","2,631.00",  "2,631.00"},
                    { "SATISFACTION - Recording Fee",   "",     "2,640.00", "FACC E Transfer Tax Misc. description1","Buyer",   "", "", "", "", "2,640.00","0.00",  "2,640.00"},
                    { "SUBORDINATION - Recording Fee",  "",     "26,100.00","FACC E Transfer Tax – Miscellaneous2", "Seller",   "", "", "", "", "0.00","26,100.00",  "26,100.00"}, 
                });
                #endregion

                #region Enter Loan Estimate Unrounded amount for Transfer Taxes. (E.g. 10500.57)
                Reports.TestStep = "Enter Loan Estimate Unrounded amount for Transfer Taxes. (E.g. 10500.57)";
                FAST_UpdateLEAmtOTC(new double[,] { { 0, 0 }, { 10500.57, 10501.00 } });
                #endregion

                #region Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.
                Reports.TestStep = "Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$8,451.00", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                { "02. FACC E Transfer Tax – Miscellaneous2 to Added Payee Name in","","","$26,100.00","","", },
                { "03. FACC E Transfer Tax – Mortgage1","","","$624.80","",""},
                { "04. FACC E Transfer Tax – Mortgage2 to Added Payee Name in Admin","$2,964.00","","","","" },
                { "05. FACC E Transfer Tax Deed", "$174.00","","","",""},
                { "06. FACC E Transfer Tax Deed2 to Added Payee Name in Admin", "","","$273.00","",""},
                { "07. FACC E Transfer Tax Deed3 to Carole Madden", "$2,673.00","","","",""},
                { "08. FACC E Transfer Tax Misc. description1", "$2,640.00","","","",""},
                { "09. FACC E Transfer Tax Mortgage3 to Carole Madden", "","","$2,631.00","",""}
            });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$10,501", "$8,451.00", "$10,500.57", "$0.00" }, { "Increase in Closing Costs above legal limits - 0% Category", "$0.00", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } });
                #endregion

                #region Modify the LE amounts in CD screen Section E (E.g. 5690.87, Rounded Amount = 6690.80)
                Reports.TestStep = @"Select Closing Disclosure tab and modify the Loan Estimate unrounded and rounded amount. (E.g. 5690.87, Rounded Amount = 6690.80)";
                // FAST_UpdateLEAmtCDSectionE is not reliable
                FAST_UpdateLEAmtOTC(new double[,] { { 0, 0 }, { 5690.87, 6690.80, } }, ttaxFeeRound: false);
                FAST_VerifyLEAmtCDSectionE(5690.87, 6690.80, isRounded: false);
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$6,690", "$8,451.00", "$5,690.87", "$2,760.13" }, { "Increase in Closing Costs above legal limits - 0% Category", "$2,760.13", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 2760.13);
                #endregion

                #region Navigate OTC screen and verify the Loan Estimate rounded and unrounded amount. (E.g. 5690.87, Rounded Amount = 6690.80)
                Reports.TestStep = @"Navigate OTC screen and verify the Loan Estimate rounded and unrounded amount.";
                FAST_VerifyLEAmtOTC(new double[,] { { 0, 0 }, { 5690.87, 6691.00 } }, ttaxFeeRound: false);
                #endregion

                #region Edit PDD for OTC's Recording fees
                Reports.TestStep = @"Edit PDD for OTC's Recording fees";
                FastDriver.OTCDetail.Open();
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Transfer Tax – Miscellaneous2",
                    LEDescription = "Modified - FACC Transfer Tax - Miscellaneous2 Maximum Values",
                    PayeeName = "Added Payee name in Source Screen PDD",
                    PartOfCheckbox = true,
                    BuyerDoubleAsteriskChecked = true,
                    SellerPaidAtClosing = 6100,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 10000.00,
                    SellerPaidbyOthers = 10000.00,
                    SellerPaidbyOtherPaymentMthd = "POC"
                });
                //  "FACC E Transfer Tax – Miscellaneous3"
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Transfer Tax Misc. description1",
                    PayeeName = "Wells Fargo Payee - PDD",
                    BuyerDoubleAsteriskChecked = true,
                    BuyerAtClosing = 640,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 1000,
                    BuyerPaidbyOther = 1000,
                    BuyerPaidbyOtherPaymentMethod = "POC"
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Transfer Tax – Mortgage1 ",
                    PayeeName = "Bank of American Payee",
                    SellerPaidAtClosing = 300,
                    SellerChargePaymentMethod = "Check",
                    SellerPaidBeforeClosing = 300,
                    SellerPaidbyOthers = 24.80,
                    SellerPaidbyOtherPaymentMthd = "POC"
                });
                FAST_UpdateOTCDetailPDD(new PDD()
                {
                    ChargeDescription = "FACC E Transfer Tax Deed",
                    PayeeName = "Deed Wells Fargo Payee – PDD",
                    BuyerDoubleAsteriskChecked = true,
                    BuyerAtClosing = 50,
                    BuyerChargePaymentMethod = "Check",
                    BuyerBeforeClosing = 50,
                    BuyerPaidbyOther = 74,
                    BuyerPaidbyOtherPaymentMethod = "POC"
                });
                #endregion

                #region Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.
                Reports.TestStep = "Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$7,377.00", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                { "02. FACC E Transfer Tax – Mortgage1 to Bank of American Payee","","","$300.00","$300.00","", },
                { "03. FACC E Transfer Tax – Mortgage2 to Added Payee Name in Admin","$2,964.00","","","",""},
                { "04. ** FACC E Transfer Tax Deed to Deed Wells Fargo Payee –","$50.00","$50.00","","","$74.00" },
                { "05. FACC E Transfer Tax Deed2 to Added Payee Name in Admin", "","","$273.00","",""},
                { "06. FACC E Transfer Tax Deed3 to Carole Madden", "$2,673.00","","","",""},
                { "07. ** FACC E Transfer Tax Misc. description1 to Wells Fargo Payee -", "$640.00","$1,000.00","","","$1,000.00"},
                { "08. FACC E Transfer Tax Mortgage3 to Carole Madden", "","","$2,631.00","",""},
                { "09. ** Modified - FACC Transfer Tax - Miscellaneous2 Maximum Values", "","","$6,100.00","$10,000.00",""}
            });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$6,690", "$7,377.00", "$5,690.87", "$1,686.13" }, { "Increase in Closing Costs above legal limits - 0% Category", "$1,686.13", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "$0.00" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "$0.00" } },
                    increaseTotal: 1686.13);
                #endregion

                #region Navigate to New Loan screen and modify First New Loan Amount. (E.g. 56000)
                Reports.TestStep = "Navigate to New Loan screen and modify First New Loan Amount. (E.g. 56000).System displays a pop up with below mentioned message. Click on Ok button.";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("56000");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Loan Amount has changed. Do you wish to update the Loan Amount to the Loan Liability?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Terms/Dates/Status and update the Sales Price
                Reports.TestStep = "Navigate to Terms/Dates/Status and update the Sales Price. (E.g. 65000). System displays recalculation pop up. Click on Ok button.";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SalesPriceAmount.FASetText("65000");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Sales Price has changed. Do you wish to update liability amount?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Sale Price has changed.  Do you wish to recalculate Real Estate Broker Commission?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add override reasons for fees in Calculate Fee Summary screen
                Reports.TestStep = "Navigate to Fee Entry | Calculate Fee Summary Screen. Add Override reason for any fees. (E.g. AMENDMENT - Recording Fee)";
                FastDriver.LeftNavigation.Navigate<CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FAST_UpdateCalculateFeeSummary(summary: new string[,] { 
                { "AMENDMENT - Recording Fee",      "",     "174.00",   "FACC E Transfer Tax Deed",             "Buyer",    "Premium Split", "50000", "", "", "500,000.00", "0.00", "500,000.00" }, 
                { "ASSIGNMENT - Recording Fee",      "",    "273.00",   "FACC E Transfer Tax Deed2",            "Seller",   "Premium Split", "50000", "45", "", "275,000.00", "225,000.00", "500,000.00" },
                { "DEED - Recording Fee",           "",     "2,673.00", "FACC E Transfer Tax Deed3",            "Buyer",    "Premium Split", "50000", "", "23000", "230,000.00", "477,000.00", "500,000.00" },
            });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.
                Reports.TestStep = "Navigate to CD. Check Display Loan Estimate checkbox. Expand Other Costs and verify the value displayed in E01.";
                FAST_VerifyOtherCosts(sectionEValues: new string[,] { { "E.  Taxes and Other Government Fees", "$802,530.00", "", "", "", "" }, { "01.  Recording Fees Deed: Mortgage:", "", "", "", "", "" } },
                    sectionEplus: new string[,]{    
                { "02. FACC E Transfer Tax – Mortgage1 to Bank of American Payee","","","$300.00","$300.00","", },
                { "03. FACC E Transfer Tax – Mortgage2 to Added Payee Name in Admin","$2,964.00","","","",""},
                { "04. ** FACC E Transfer Tax Deed to Deed Wells Fargo Payee –","$499,876.00","$50.00","","","$74.00" },
                { "05. FACC E Transfer Tax Deed2 to Added Payee Name in Admin", "$275,000.00","","$225,000.00","",""},
                { "06. FACC E Transfer Tax Deed3 to Carole Madden", "$23,000.00","","$477,000.00","",""},
                { "07. ** FACC E Transfer Tax Misc. description1 to Wells Fargo Payee -", "$640.00","$1,000.00","","","$1,000.00"},
                { "08. FACC E Transfer Tax Mortgage3 to Carole Madden", "$2,631.00","","","",""},
                { "09. ** Modified - FACC Transfer Tax - Miscellaneous2 Maximum Values", "","","$6,100.00","$10,000.00",""}
            });
                #endregion

                #region Edit Loan Estimate Unrounded Value for Transfer Tax. (E.g. 10,000.50)
                Reports.TestStep = "Edit Loan Estimate Unrounded Value for Transfer Tax. (E.g. 10,000.50)";
                // FAST_UpdateLEAmtCDSectionE is not reliable
                FAST_UpdateLEAmtOTC(new double[,] { { 0, 0 }, { 10000.50, 10001.00, } }, ttaxFeeRound: true);
                FAST_VerifyLEAmtCDSectionE(10000.50, 10001.00, isRounded: true);
                #endregion

                #region Enter Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
                Reports.TestStep = @"Navigate to New Loan - Loan Charges then enter Buyer Credit Amount and LE for Non-Specific Lender Credits.";
                FAST_UpdateLenderCredits(chargesTabValues: new string[,] { { "2", "", "", "", "4830.56", "", "", "67554.56" } },
                    mortgageTabValues: new string[,] { { "2", "", "", "", "3493.34", "", "", "7663.45" } });
                #endregion

                #region Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.
                Reports.TestStep = @"Navigate to Good Faith Variance screen and verify the values displayed under 0% and Lender Credit Analysis.";
                FAST_VerifyGFaithVariance(cat0Table: new string[,] { { "E 02+ Transfer Taxes", "$10,001", "$802,530.00", "$10,000.50", "$792,529.50" }, { "J 00 Lender Credits (See Lender Credit Analysis)", "-$75,218", "-$8,323.90", "-$75,218.01", "$66,894.11" }, { "Increase in Closing Costs above legal limits - 0% Category", "$859,423.61", "", "", "" } },
                    lenderCredits: new string[,] { { "Non-Specific Lender Credits", "-$8,323.90" }, { "Specific Lender Credits", "" }, { "Lender Credits Total (J) Excluding Good Faith Violation", "-$8,323.90" } },
                    increaseTotal: 859423.61);
                #endregion

                #region Navigate to Property Tax Info.  and modify state and county.
                Reports.TestStep = "Navigate to Property Tax Info.  and modify state and county.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItemBySendingKeys(index: 10);   //  CO
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing State will result in the removal or replacements of the ST License ID", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, clickAcceptButton: true);
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing the State or County will result in removal of all calculated fees. Do you wish to continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.Click();
                Keyboard.SendKeys("Adams{TAB}");
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Changing the State or County will result in removal of all calculated fees. Do you wish to continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify if all the fees are removed in Fee Entry and CD Screen.
                Reports.TestStep = "Verify if all the fees are removed in Fee Entry and CD Screen.";
                Support.Eval<Exception>(() =>
                {
                    FastDriver.FileFees.Open();
                    FastDriver.FileFees.RecordingandTax.Click();
                    FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                    FAST_UpdateFileFeesPDD(new PDD()
                    {
                        ChargeDescription = "FACC E Transfer Tax – Miscellaneous2",
                    }, isTE: false);
                }, exceptionExpected: true, reportMessage: "Verify if all the fees are removed in Fee Entry");
                Support.Eval<Exception>(() =>
                {
                    FAST_VerifyOtherCosts(
                        sectionEplus: new string[,]{{ "02. FACC E Transfer Tax – Mortgage2 to Continental","$2,964.00","","","","", }
                });
                }, exceptionExpected: true, reportMessage: "Verify if all the fees are removed inCD Screen");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }


}
