﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using SeleniumInternalHelpers;
using AutoIt;
using System.Windows.Forms;
using OpenQA.Selenium;
using System.Linq;

namespace IMD_Module_Regression
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest, DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    public class SOT_Section_L : MasterTestClass
    {
        #region Global Datasetup
        String[] GetCharge = new String[30];
        string ret_Amt;
        String[] MAmt = new String[50];
        string MAmtTab2SupTotal;
        System.Collections.Generic.List<string> buyerCredits = new System.Collections.Generic.List<string>();

        String[] Seller_Credit = new String[20];
        String[] Seller_Charge = new String[20];
        String[] Buyer_Credit = new String[20];
        String[] GetAmt = new String[20];
        double sum = 0.0;
        #endregion

        #region 441061- CD Screen - Section L: Display Depoists on line L 01

        #region US_441061_TC_467291_NO_01

        [TestMethod, Description("VERIFY THE TOTAL DEPOSIT AMOUNT FROM DEPOSIT OUTSIDE ESCROW SCREEN IN LINE L01")]
        public void US_441061_TC_467291_NO_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE TOTAL DEPOSIT AMOUNT FROM DEPOSIT OUTSIDE ESCROW SCREEN IN LINE L01.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic Order";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                FastDriver.QuickFileEntry.CreateStandardFile();

                Reports.TestStep = "Provide Total Deposit amount";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("9000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("9000");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL01_Seqno.FAClick();
                string seqno = FastDriver.ClosingDisclosure.SectionL01_Seqno.Text.ToString();
                seqno = seqno.Trim();
                Support.AreEqual("True", seqno.Equals("01", StringComparison.OrdinalIgnoreCase).ToString());
                string desc = FastDriver.ClosingDisclosure.SectionL01_Label.Text.ToString();
                desc = desc.Trim();
                Support.AreEqual("True", desc.Equals("Deposit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("$9,000.00", FastDriver.ClosingDisclosure.SectionL01_Amt.Text.ToString());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit Excess Deposit amount";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("12345678901.23");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("12345678901.23");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating the edited value of Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL01_Seqno.FAClick();
                string seqno1 = FastDriver.ClosingDisclosure.SectionL01_Seqno.Text.ToString();
                seqno1 = seqno1.Trim();
                Support.AreEqual("True", seqno1.Equals("01", StringComparison.OrdinalIgnoreCase).ToString());
                string desc1 = FastDriver.ClosingDisclosure.SectionL01_Label.Text.ToString();
                desc1 = desc1.Trim();
                Support.AreEqual("True", desc1.Equals("Deposit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionL01_Amt.Text.ToString());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_441061_TC_467291_NO_01

        #region US_441061_TC_467293_NO_02

        [TestMethod, Description("VERIFY AMOUNT FROM DEPOSIT IN ESCROW SCREEN IN LINE L01")]
        public void US_441061_TC_467293_NO_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY AMOUNT FROM DEPOSIT IN ESCROW SCREEN IN LINE L01";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide Deposit in Escrow credit to buyer amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositInEscrow.Amount.FASetText("5000");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Earnest Money Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Charge");
                if (!FastDriver.DepositInEscrow.CredittoBuyer.Selected)
                    FastDriver.DepositInEscrow.CredittoBuyer.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL01_Seqno.FAClick();
                string seqno = FastDriver.ClosingDisclosure.SectionL01_Seqno.Text.ToString();
                seqno = seqno.Trim();
                Support.AreEqual("True", seqno.Equals("01", StringComparison.OrdinalIgnoreCase).ToString());
                string desc = FastDriver.ClosingDisclosure.SectionL01_Label.Text.ToString();
                desc = desc.Trim();
                Support.AreEqual("True", desc.Equals("Deposit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual(FastDriver.ClosingDisclosure.SectionL01_Amt.Text.ToString(), "$5,000.00");

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_441061_TC_467293_NO_02

        #region US_441061_TC_467300_NO_04

        [TestMethod, Description("VERIFY THE AMOUNT FROM DEPOSIT IN ESCROW SCREEN IN LINE L01 WHERE REPRESENTING VALUE IS NOT EARNEST MONEY DEPOSIT")]
        public void US_441061_TC_467300_NO_04()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE AMOUNT FROM DEPOSIT IN ESCROW SCREEN IN LINE L01 WHERE REPRESENTING VALUE IS NOT EARNEST MONEY DEPOSIT";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide Deposit in Escrow credit to buyer amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositInEscrow.Amount.FASetText("10000");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Additional Closing Costs");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Charge");
                if (!FastDriver.DepositInEscrow.CredittoBuyer.Selected)
                    FastDriver.DepositInEscrow.CredittoBuyer.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL01_Seqno.FAClick();
                string seqno = FastDriver.ClosingDisclosure.SectionL01_Seqno.Text.ToString();
                seqno = seqno.Trim();
                Support.AreEqual("True", seqno.Equals("01", StringComparison.OrdinalIgnoreCase).ToString());
                string desc = FastDriver.ClosingDisclosure.SectionL01_Label.Text.ToString();
                desc = desc.Trim();
                Support.AreEqual("True", desc.Equals("Deposit", StringComparison.OrdinalIgnoreCase).ToString());
                //Support.AreEqual(FastDriver.ClosingDisclosure.SectionL01_Amt.GetAttribute("FriendlyName"), "sectionL_amt1");

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        #endregion US_441061_TC_467300_NO_04

        #region US_441061_TC_467307_NO_06

        [TestMethod, Description("VERIFY THE ADJUSTED AMOUNT FROM DEPOSIT ADJUSTMENT SCREEN WITH ADJUST REASON AS CORRECT AMOUNT IN LINE L01")]
        public void US_441061_TC_467307_NO_06()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE ADJUSTED AMOUNT FROM DEPOSIT ADJUSTMENT SCREEN WITH ADJUST REASON AS CORRECT AMOUNT IN LINE L01";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic order";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide Deposit in Escrow amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositInEscrow.Amount.FASetText("5000");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Earnest Money Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Charge");
                if (!FastDriver.DepositInEscrow.CredittoBuyer.Selected)
                    FastDriver.DepositInEscrow.CredittoBuyer.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Adjust the amount from Deposit Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "5,000.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                Playback.Wait(250);
                FastDriver.DepositAdjustment.SwitchToContentFrame();
                FastDriver.DepositAdjustment.WaitCreation(FastDriver.DepositAdjustment.AdjustmentReason, 5);
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Correct Amount");

                while (true)
                {
                    FastDriver.DepositAdjustment.CorrectAmount.Click();
                    Playback.Wait(500);
                    Keyboard.SendKeys("^A");
                    Playback.Wait(500);
                    Keyboard.SendKeys("{DEL}");
                    Playback.Wait(500);
                    Keyboard.SendKeys("12345678901.23");
                    Playback.Wait(500);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    
                    if (FastDriver.DepositAdjustment.CorrectAmount.GetAttribute("value").Clean() == "12,345,678,901.23")
                        break;
                }
                
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL01_Seqno.FAClick();

                string seqno = FastDriver.ClosingDisclosure.SectionL01_Seqno.Text.ToString();
                seqno = seqno.Trim();
                Support.AreEqual("True", seqno.Equals("01", StringComparison.OrdinalIgnoreCase).ToString());

                string desc = FastDriver.ClosingDisclosure.SectionL01_Label.Text.ToString();
                desc = desc.Trim();
                Support.AreEqual("True", desc.Equals("Deposit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual(FastDriver.ClosingDisclosure.SectionL01_Amt.Text.ToString(), "$345,678,901.23");

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_441061_TC_467307_NO_06

        #region US_441061_TC_467314_NO_08

        [TestMethod, Description("VERIFY THE ADJUSTED AMOUNT FROM DEPOSIT ADJUSTMENT SCREEN WITH ADJUST REASON AS INPUT ERROR IN LINE L01")]
        public void US_441061_TC_467314_NO_08()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE ADJUSTED AMOUNT FROM DEPOSIT ADJUSTMENT SCREEN WITH ADJUST REASON AS INPUT ERROR IN LINE L01";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic order";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide Deposit in Escrow amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositInEscrow.Amount.FASetText("5000");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Earnest Money Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Charge");
                if (!FastDriver.DepositInEscrow.CredittoBuyer.Selected)
                    FastDriver.DepositInEscrow.CredittoBuyer.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Adjust the amount from Deposit Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<DepositSummary>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction("Amount", "5,000.00", "Amount", TableAction.Click);
                FastDriver.DepositSummary.Adjust.FAClick();
                FastDriver.DepositAdjustment.SwitchToContentFrame();
                FastDriver.DepositAdjustment.AdjustmentReason.FASelectItem("Input Error");
                FastDriver.DepositAdjustment.Comment.FASetText("Input Error");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL01_Seqno.FAClick();
                string seqno = FastDriver.ClosingDisclosure.SectionL01_Seqno.Text.ToString();
                seqno = seqno.Trim();
                Support.AreEqual("01", seqno);
                string desc = FastDriver.ClosingDisclosure.SectionL01_Label.Text.ToString();
                desc = desc.Trim();
                Support.AreEqual("Deposit", desc);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_441061_TC_467314_NO_08

        #region US_441061_TC_467319_NO_10

        [TestMethod, Description("VERIFY THE TOTAL AMOUNT FROM DEPOSIT OUTSIDE ESCROW AND DEPOSIT IN ESCROW SCREENS IN LINE L01")]
        public void US_441061_TC_467319_NO_10()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE TOTAL AMOUNT FROM DEPOSIT OUTSIDE ESCROW AND DEPOSIT IN ESCROW SCREENS IN LINE L01";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Provide Total Deposit amount";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("10000.50");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("10000.50");
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Provide Deposit in Escrow credit to buyer amount";
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow");
                Playback.Wait(250);
                FastDriver.DepositInEscrow.SwitchToContentFrame();
                FastDriver.DepositInEscrow.WaitCreation(FastDriver.DepositInEscrow.Amount, 5);
                FastDriver.DepositInEscrow.Amount.FASetText("20000.25");
                FastDriver.DepositInEscrow.TypeofFunds.FASelectItem("Cash");
                FastDriver.DepositInEscrow.Representing.FASelectItem("Earnest Money Deposit");
                FastDriver.DepositInEscrow.ReceivedFrom.FASelectItem("Buyer");
                FastDriver.DepositInEscrow.Payor.FASetText("Charge");
                if (!FastDriver.DepositInEscrow.CredittoBuyer.Selected)
                    FastDriver.DepositInEscrow.CredittoBuyer.FAClick();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(true, false);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL01_Seqno.FAClick();
                string seqno = FastDriver.ClosingDisclosure.SectionL01_Seqno.Text.ToString();
                seqno = seqno.Trim();
                Support.AreEqual("True", seqno.Equals("01", StringComparison.OrdinalIgnoreCase).ToString());
                string desc = FastDriver.ClosingDisclosure.SectionL01_Label.Text.ToString();
                desc = desc.Trim();
                Support.AreEqual("True", desc.Equals("Deposit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual(FastDriver.ClosingDisclosure.SectionL01_Amt.Text.ToString(), "$30,000.75");

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_441061_TC_467319_NO_10

        #endregion 441061- CD Screen - Section L: Display Depoists on line L 01

        #region 464521- CD Screen - Section L: Display Adjustments on lines L 08 to L 11

        #region US_464521_TC_468364_NO_01

        [TestMethod, Description("VERIFY OFFSET ADJUSTMENTS AMOUNTS IN SECTION L")]
        public void US_464521_TC_468364_NO_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE TOTAL DEPOSIT AMOUNT FROM DEPOSIT OUTSIDE ESCROW SCREEN IN LINE L01.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Offset Adjustment Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.BuyerCredit1.FASetText("5000");
                FastDriver.AdjustmentOffset.BuyerCredit2.FASetText("12345678901.23");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL01_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL08_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("True", seq1.Equals("08", StringComparison.OrdinalIgnoreCase).ToString());

                string label1 = FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString();
                label1 = label1.Trim();
                Support.AreEqual("True", label1.Equals("Assign Tenant Lease/Rent", StringComparison.OrdinalIgnoreCase).ToString());

                string amt1 = FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString();
                amt1 = amt1.Trim();
                Support.AreEqual("True", amt1.Equals("$5,000.00", StringComparison.OrdinalIgnoreCase).ToString());

                FastDriver.ClosingDisclosure.SectionL09_Seqno.FAClick();

                string seq2 = FastDriver.ClosingDisclosure.SectionL09_Seqno.Text.ToString();
                seq2 = seq2.Trim();
                Support.AreEqual("True", seq2.Equals("09", StringComparison.OrdinalIgnoreCase).ToString());

                string label2 = FastDriver.ClosingDisclosure.SectionL09_Label.Text.ToString();
                label2 = label2.Trim();
                Support.AreEqual("True", label2.Equals("Assign Tenant Security Deposit", StringComparison.OrdinalIgnoreCase).ToString());

                string amt2 = FastDriver.ClosingDisclosure.SectionL09_Amt.Text.ToString();
                amt2 = amt2.Trim();
                Support.AreEqual("True", amt2.Equals("$345,678,901.23", StringComparison.OrdinalIgnoreCase).ToString());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464521_TC_468364_NO_01

        #region US_464521_TC_468366_NO_03

        [TestMethod, Description("VERIFY MISCELLANEOUS ADJUSTMENTS AMOUNTS IN Section L")]
        public void US_464521_TC_468366_NO_03()
        {
            Reports.TestDescription = "VERIFY MISCELLANEOUS ADJUSTMENTS AMOUNTS IN Section L";

            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            #endregion

            #region GUI interaction

            Reports.TestStep = "Login to file side";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            Playback.Wait(5000);

            Reports.TestStep = "Create a basic file";
            string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

            Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";
            FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.AdjustmentMisc.BuyerCredit.FASetText("60000");
            FastDriver.AdjustmentMisc.BuyerCredit2.FASetText("12345678901.23");
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Validating the charges in Section L in CD Screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);

            Reports.TestStep = "Validating Section L Line 01";
            FastDriver.ClosingDisclosure.SectionL08_Seqno.FAClick();

            string seq1 = FastDriver.ClosingDisclosure.SectionL08_Seqno.Text.ToString();
            seq1 = seq1.Trim();
            Support.AreEqual("True", seq1.Equals("08", StringComparison.OrdinalIgnoreCase).ToString());

            string label1 = FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString();
            label1 = label1.Trim();
            Support.AreEqual("True", label1.Equals("Buyer Deposit Directly to Seller", StringComparison.OrdinalIgnoreCase).ToString());

            string amt1 = FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString();
            amt1 = amt1.Trim();
            Support.AreEqual("True", amt1.Equals("$60,000.00", StringComparison.OrdinalIgnoreCase).ToString());

            FastDriver.ClosingDisclosure.SectionL09_Seqno.FAClick();

            string seq2 = FastDriver.ClosingDisclosure.SectionL09_Seqno.Text.ToString();
            seq2 = seq2.Trim();
            Support.AreEqual("True", seq2.Equals("09", StringComparison.OrdinalIgnoreCase).ToString());

            string label2 = FastDriver.ClosingDisclosure.SectionL09_Label.Text.ToString();
            label2 = label2.Trim();
            Support.AreEqual("True", label2.Equals("IBA Interest Paid", StringComparison.OrdinalIgnoreCase).ToString());

            string amt2 = FastDriver.ClosingDisclosure.SectionL09_Amt.Text.ToString();
            amt2 = amt2.Trim();
            Support.AreEqual("True", amt2.Equals("$345,678,901.23", StringComparison.OrdinalIgnoreCase).ToString());

            Reports.TestStep = "Saving the CD Screen";
            FastDriver.BottomFrame.Done();

            #endregion GUI interaction

        }

        #endregion US_464521_TC_468366_NO_03

        #region US_464521_TC_468371_NO_06

        [TestMethod, Description("VERIFY ADHOC OFFSET AND MISCELLANEOUS ADJUSTMENTS AMOUNTS IN Section L")]
        public void US_464521_TC_468371_NO_06()
        {
            Reports.TestDescription = "VERIFY ADHOC OFFSET AND MISCELLANEOUS ADJUSTMENTS AMOUNTS IN Section L";

            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            #endregion

            #region GUI interaction

            Reports.TestStep = "Login to file side";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            Playback.Wait(5000);

            Reports.TestStep = "Create a basic file";
            string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

            Reports.TestStep = "Creating Charges in Offset Adjustment Screen";
            FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.AdjustmentOffset.AddOffsetCharges("ABCE Adhoc", null, 5000, null, null);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.AdjustmentOffset.AddOffsetCharges("ABCD Adhoc", null, 6000, null, null);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";
            FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.AdjustmentMisc.AddMiscCharges("2 Misc Adhoc", null, 7000, null, null);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.AdjustmentMisc.AddMiscCharges("1 Misc Adhoc", null, 8000, null, null);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Validating the charges in Section L in CD Screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);

            Reports.TestStep = "Validating Section L Line 01";
            FastDriver.ClosingDisclosure.SectionL08_Seqno.FAClick();

            string seq1 = FastDriver.ClosingDisclosure.SectionL08_Seqno.Text.ToString();
            seq1 = seq1.Trim();
            Support.AreEqual("08", seq1);

            string label1 = FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString();
            label1 = label1.Trim();
            Support.AreEqual("1 Misc Adhoc", label1);

            string amt1 = FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString();
            amt1 = amt1.Trim();
            Support.AreEqual("$8,000.00", amt1);

            FastDriver.ClosingDisclosure.SectionL09_Seqno.FAClick();

            string seq2 = FastDriver.ClosingDisclosure.SectionL09_Seqno.Text.ToString();
            seq2 = seq2.Trim();
            Support.AreEqual("09", seq2);

            string label2 = FastDriver.ClosingDisclosure.SectionL09_Label.Text.ToString();
            label2 = label2.Trim();
            Support.AreEqual("2 Misc Adhoc", label2);

            string amt2 = FastDriver.ClosingDisclosure.SectionL09_Amt.Text.ToString();
            amt2 = amt2.Trim();
            Support.AreEqual("$7,000.00", amt2);

            FastDriver.ClosingDisclosure.SectionL10_Seqno.FAClick();

            string seq3 = FastDriver.ClosingDisclosure.SectionL10_Seqno.Text.ToString();
            seq3 = seq3.Trim();
            Support.AreEqual("10", seq3);

            string label3 = FastDriver.ClosingDisclosure.SectionL10_Label.Text.ToString();
            label3 = label3.Trim();
            Support.AreEqual("ABCD Adhoc", label3);

            string amt3 = FastDriver.ClosingDisclosure.SectionL10_Amt.Text.ToString();
            amt3 = amt3.Trim();
            Support.AreEqual("$6,000.00", amt3);

            FastDriver.ClosingDisclosure.SectionL11_Seqno.FAClick();

            string seq4 = FastDriver.ClosingDisclosure.SectionL11_Seqno.Text.ToString();
            seq4 = seq4.Trim();
            Support.AreEqual("11", seq4);

            string label4 = FastDriver.ClosingDisclosure.SectionL11_Label.Text.ToString();
            label4 = label4.Trim();
            Support.AreEqual("ABCE Adhoc", label4);

            string amt4 = FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString();
            amt4 = amt4.Trim();
            Support.AreEqual("$5,000.00", amt4);

            Reports.TestStep = "Saving the CD Screen";
            FastDriver.BottomFrame.Done();

            #endregion GUI interaction

        }

        #endregion US_464521_TC_468371_NO_06

        #region US_464521_TC_468372_NO_07

        [TestMethod, Description("VERIFY OFFSET AND MISCELLANEOUS ADJUSTMENTS AMOUNTS IN LINE L08 TO L11")]
        public void US_464521_TC_468372_NO_07()
        {
            Reports.TestDescription = "VERIFY OFFSET AND MISCELLANEOUS ADJUSTMENTS AMOUNTS IN LINE L08 TO L11";

            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            #endregion

            #region GUI interaction

            Reports.TestStep = "Login to file side";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            Playback.Wait(5000);

            Reports.TestStep = "Create a basic file";
            string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

            Reports.TestStep = "Creating Charges in Offset Adjustment Screen";
            FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Lease/Rent", null, null, 5000, null, null);
            FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Security Deposit", null, null, 6000, null, null);
            FastDriver.AdjustmentOffset.AddOffsetCharges("ABCE Adhoc", null, 7000.00, null, null);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Creating Charges in Miscellaneous Adjustment Screen";
            FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.AdjustmentMisc.UpdateMiscCharges("Buyer Deposit Directly to Seller", null, null, 8000, null, null);
            FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", null, null, 9000, null, null);
            FastDriver.AdjustmentMisc.AddMiscCharges("1 Misc Adhoc", null, 10000.00, null, null);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Validating the charges in Section L in CD Screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);

            Reports.TestStep = "Validating Section L Line 01";
            FastDriver.ClosingDisclosure.SectionL08_Seqno.FAClick();

            string seq1 = FastDriver.ClosingDisclosure.SectionL08_Seqno.Text.ToString();
            seq1 = seq1.Trim();
            Support.AreEqual("08", seq1);

            string label1 = FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString();
            label1 = label1.Trim();
            Support.AreEqual("1 Misc Adhoc", label1);

            string amt1 = FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString();
            amt1 = amt1.Trim();
            Support.AreEqual("$10,000.00", amt1);

            FastDriver.ClosingDisclosure.SectionL09_Seqno.FAClick();

            string seq2 = FastDriver.ClosingDisclosure.SectionL09_Seqno.Text.ToString();
            seq2 = seq2.Trim();
            Support.AreEqual("09", seq2);

            string label2 = FastDriver.ClosingDisclosure.SectionL09_Label.Text.ToString();
            label2 = label2.Trim();
            Support.AreEqual("ABCE Adhoc", label2);

            string amt2 = FastDriver.ClosingDisclosure.SectionL09_Amt.Text.ToString();
            amt2 = amt2.Trim();
            Support.AreEqual("$7,000.00", amt2);

            FastDriver.ClosingDisclosure.SectionL10_Seqno.FAClick();

            string seq3 = FastDriver.ClosingDisclosure.SectionL10_Seqno.Text.ToString();
            seq3 = seq3.Trim();
            Support.AreEqual("10", seq3);

            string label3 = FastDriver.ClosingDisclosure.SectionL10_Label.Text.ToString();
            label3 = label3.Trim();
            Support.AreEqual("Assign Tenant Lease/Rent", label3);

            string amt3 = FastDriver.ClosingDisclosure.SectionL10_Amt.Text.ToString();
            amt3 = amt3.Trim();
            Support.AreEqual("$5,000.00", amt3);

            FastDriver.ClosingDisclosure.SectionL11_Seqno.FAClick();

            string seq4 = FastDriver.ClosingDisclosure.SectionL11_Seqno.Text.ToString();
            seq4 = seq4.Trim();
            Support.AreEqual("11", seq4);

            string label4 = FastDriver.ClosingDisclosure.SectionL11_Label.Text.ToString();
            label4 = label4.Trim();
            Support.AreEqual("See attached page for additional information", label4);

            string amt4 = FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString();
            amt4 = amt4.Trim();
            Support.AreEqual("$23,000.00", amt4);

            Reports.TestStep = "Saving the CD Screen";
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Deleting Charges in Offset Adjustment Screen";
            FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.AdjustmentOffset.UpdateOffsetCharges("ABCE Adhoc", null, null, 0, null, null);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Deleting Charges in Miscellaneous Adjustment Screen";
            FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.AdjustmentMisc.UpdateMiscCharges("1 Misc Adhoc", null, null, 0, null, null);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Validating the charges in Section L in CD Screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);

            Reports.TestStep = "Validating Section L Line 01";
            FastDriver.ClosingDisclosure.SectionL08_Seqno.FAClick();

            string seq11 = FastDriver.ClosingDisclosure.SectionL08_Seqno.Text.ToString();
            seq11 = seq11.Trim();
            Support.AreEqual("08", seq11);

            string label11 = FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString();
            label11 = label11.Trim();
            Support.AreEqual("Assign Tenant Lease/Rent", label11);

            string amt11 = FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString();
            amt11 = amt11.Trim();
            Support.AreEqual("$5,000.00", amt11);

            FastDriver.ClosingDisclosure.SectionL09_Seqno.FAClick();

            string seq22 = FastDriver.ClosingDisclosure.SectionL09_Seqno.Text.ToString();
            seq22 = seq22.Trim();
            Support.AreEqual("09", seq22);

            string label22 = FastDriver.ClosingDisclosure.SectionL09_Label.Text.ToString();
            label22 = label22.Trim();
            Support.AreEqual("Assign Tenant Security Deposit", label22);

            string amt22 = FastDriver.ClosingDisclosure.SectionL09_Amt.Text.ToString();
            amt22 = amt22.Trim();
            Support.AreEqual("$6,000.00", amt22);

            FastDriver.ClosingDisclosure.SectionL10_Seqno.FAClick();

            string seq33 = FastDriver.ClosingDisclosure.SectionL10_Seqno.Text.ToString();
            seq33 = seq33.Trim();
            Support.AreEqual("10", seq33);

            string label33 = FastDriver.ClosingDisclosure.SectionL10_Label.Text.ToString();
            label33 = label33.Trim();
            Support.AreEqual("Buyer Deposit Directly to Seller", label33);

            string amt33 = FastDriver.ClosingDisclosure.SectionL10_Amt.Text.ToString();
            amt33 = amt33.Trim();
            Support.AreEqual("$8,000.00", amt33);

            FastDriver.ClosingDisclosure.SectionL11_Seqno.FAClick();

            string seq44 = FastDriver.ClosingDisclosure.SectionL11_Seqno.Text.ToString();
            seq44 = seq44.Trim();
            Support.AreEqual("11", seq44);

            string label44 = FastDriver.ClosingDisclosure.SectionL11_Label.Text.ToString();
            label44 = label44.Trim();
            Support.AreEqual("IBA Interest Paid", label44);

            string amt44 = FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString();
            amt44 = amt44.Trim();
            Support.AreEqual("$9,000.00", amt44);

            Reports.TestStep = "Saving the CD Screen";
            FastDriver.BottomFrame.Done();

            #endregion GUI interaction

        }

        #endregion US_464521_TC_468372_NO_07

        #endregion 464521- CD Screen - Section L: Display Adjustments on lines L 08 to L 11

        #region 464525- CD Screen: Section L: Display Buyer Credits on lines L 06 and L 07 and 393359- CD Screen – Section L: Display Asterisk for charge groups

        #region US_464525_393359_TC_467344_NO_01

        [TestMethod, Description("VERIFY  FIRST, SECOND AND THIRD PROPERTY TAX CHECK INSTANCE CREDITS IN SECTION L04")]
        public void US_464525_393359_TC_467344_NO_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY  FIRST, SECOND AND THIRD PROPERTY TAX CHECK INSTANCE CREDITS IN SECTION L04";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                #region BuyerSellerBroker

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode, 10);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Keyboard.SendKeys("^D");
                Playback.Wait(3000);

                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode, 10);
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Keyboard.SendKeys("^D");
                Playback.Wait(3000);

                #endregion BuyerSellerBroker

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("237");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 5000.50, null, null, null, ""); 
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                Playback.Wait(250);

                FastDriver.PropertiesSummary.SwitchToContentFrame();
                Keyboard.SendKeys("^N");
                Playback.Wait(3000);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", null, 5000.50, null, null, null, ""); 
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                Playback.Wait(250);

                FastDriver.PropertiesSummary.SwitchToContentFrame();
                Keyboard.SendKeys("%N");
                Playback.Wait(3000);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", null, 5000.50, null, null, null, ""); 
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                Playback.Wait(250);

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("06", seq1);

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label1 = label1.Trim();
                Support.AreEqual("*  Property Taxes", label1);

                string amt1 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt1.Trim();
                Support.AreEqual("$15,001.50", amt1);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_393359_TC_467344_NO_01

        #region US_464525_TC_467346_NO_03

        [TestMethod, Description("VERIFY FIRST PROPERTY TAX CHECK INSTANCE CREDIT WITH EDITED CHARGE DESCRIPTION AND EDITED PAYEE NAME IN SECTION L06")]
        public void US_464525_TC_467346_NO_03()
        {
            try
            {
                Reports.TestDescription = "VERIFY FIRST PROPERTY TAX CHECK INSTANCE CREDIT WITH EDITED CHARGE DESCRIPTION AND EDITED PAYEE NAME IN SECTION L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                #region BuyerSellerBroker

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                Keyboard.SendKeys("^D");
                Playback.Wait(3000);

                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                Keyboard.SendKeys("^D");
                Playback.Wait(3000);

                #endregion BuyerSellerBroker

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 5000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.Description, 5);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("5000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                Playback.Wait(250);

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("06", seq1);

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label1 = label1.Trim();
                Debug.Print(label1);
                Support.AreEqual("Description1  from Payee Name1", label1);

                string amt1 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt1.Trim();
                Support.AreEqual("$5,000.00", amt1);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_TC_467346_NO_03

        #region US_464525_TC_467347_NO_04

        [TestMethod, Description("VERIFY  FIRST PROPERTY TAX CHECK INSTANCE CREDIT IN SECTION L06 HAVING POC AMOUNT")]
        public void US_464525_TC_467347_NO_04()
        {
            try
            {
                Reports.TestDescription = "VERIFY  FIRST PROPERTY TAX CHECK INSTANCE CREDIT IN SECTION L06 HAVING POC AMOUNT";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Buyer and seller Broker Instance";
                #region BuyerSellerBroker

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                Keyboard.SendKeys("^D");
                Playback.Wait(3000);

                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                Keyboard.SendKeys("^D");
                Playback.Wait(3000);

                #endregion BuyerSellerBroker

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", null, 7000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.usedefault, 5);
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("7000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                Playback.Wait(250);

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Validating Section L Line 01";
                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("06", seq1);

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label1 = label1.Trim();
                Support.AreEqual("Tax Installment: Penalty Due  $7,000.00 P.O.C.", label1);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_TC_467347_NO_04

        #region US_464525_TC_467350_NO_07

        [TestMethod, Description("VERIFY SECOND ASSUMPTION LOAN CREDIT IN SECTION L06")]
        public void US_464525_TC_467350_NO_07()
        {
            try
            {
                Reports.TestDescription = "VERIFY SECOND ASSUMPTION LOAN CREDIT IN SECTION L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Assumption Loan 1st Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "Creating Credit Amount for Assumption Loan 2nd Instance";
                Keyboard.SendKeys("^N");
                Playback.Wait(2000);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("248");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(250);

                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 40000.90, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("40000.90");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("True", seq1.Equals("06", StringComparison.OrdinalIgnoreCase).ToString());

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label1 = label1.Trim();
                Debug.Print(label1.ToString());
                Support.AreEqual("True", label1.Equals("Assumption Transfer Fee  from Midwest Financial Group", StringComparison.OrdinalIgnoreCase).ToString());

                string amt1 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt1.Trim();
                Support.AreEqual("True", amt1.Equals("$40,000.90", StringComparison.OrdinalIgnoreCase).ToString());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing Assumption Loan 2st Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanSummary>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(1, "2", 2, TableAction.Click);
                FastDriver.AssumptionLoanSummary.Edit.FAClick();
                Playback.Wait(250);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 12345678901.23, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("12345678901.23");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq2 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq2 = seq2.Trim();
                Support.AreEqual("06", seq2);

                string label2 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label2 = label2.Trim();
                Debug.Print(label2.ToString());
                Support.AreEqual("Assumption Transfer Fee  from Midwest Financial Group", label2);

                string amt2 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt2 = amt2.Trim();
                Support.AreEqual("$345,678,901.23", amt2);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_TC_467350_NO_07

        #region US_464525_TC_467353_NO_08

        [TestMethod, Description("VERIFY ASSUMPTION LOAN CREDIT WITH EDITED DESCRIPTION AND PAYEE NAME IN SECTION L06")]
        public void US_464525_TC_467353_NO_08()
        {
            try
            {
                Reports.TestDescription = "VERIFY ASSUMPTION LOAN CREDIT WITH EDITED DESCRIPTION AND PAYEE NAME IN SECTION L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Credit Amount for Assumption Loan 1st Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 50000, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.Description, 5);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("50000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("06", seq1);

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label1 = label1.Trim();
                Debug.Print(label1.ToString());
                Support.AreEqual("Description1  from Payee Name1", label1);

                string amt1 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt1.Trim();
                Support.AreEqual("$50,000.00", amt1);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_TC_467353_NO_08

        #region US_464525_TC_467355_NO_09

        [TestMethod, Description("VERIFY ASSUMPTION LOAN CREDIT WITH CREDIT AMOUNT AS POC IN SECTION L06")]
        public void US_464525_TC_467355_NO_09()
        {
            try
            {
                Reports.TestDescription = "VERIFY ASSUMPTION LOAN CREDIT WITH CREDIT AMOUNT AS POC IN SECTION L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Credit Amount for Assumption Loan 1st Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 10000, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.usedefault, 5);
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("10000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("06", seq1);

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label1 = label1.Trim();
                Debug.Print(label1.ToString());
                Support.AreEqual("Assumption Transfer Fee  $10,000.00 P.O.C.", label1);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_TC_467355_NO_09

        #region US_464525_393359_TC_467356_NO_10

        [TestMethod, Description("VERIFY REB CREDITS FOR SELLER, BUYER AND OTHERS IN SECTION L")]
        public void US_464525_393359_TC_467356_NO_10()
        {
            try
            {
                Reports.TestDescription = "VERIFY REB CREDITS FOR SELLER, BUYER AND OTHERS IN SECTION L";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating REB Credits for seller";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit1", 5000, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit2", 5000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "Creating REB Credits for Buyer";
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit3", 6000, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit4", 6000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                Reports.TestStep = "Creating REB Credits for Others";
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("237");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit5", 7000, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit6", 7000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("06", seq1);

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label1 = label1.Trim();
                Debug.Print(label1.ToString());
                Support.AreEqual("*  Real Estate Broker Credits", label1);

                string amt1 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt1.Trim();
                Support.AreEqual("$36,000.00", amt1);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_393359_TC_467356_NO_10

        #region US_464525_TC_467357_NO_11

        [TestMethod, Description("VERIFY REB CREDITS FOR SELLER IN SECTION L")]
        public void US_464525_TC_467357_NO_11()
        {
            try
            {
                Reports.TestDescription = "VERIFY REB CREDITS FOR SELLER IN SECTION L";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating REB Credits for seller";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit1", 10000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("True", seq1.Equals("06", StringComparison.OrdinalIgnoreCase).ToString());

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label1 = label1.Trim();
                Debug.Print(label1.ToString());
                Support.AreEqual("True", label1.Equals("BuyerCredit1  from Midwest Financial Group", StringComparison.OrdinalIgnoreCase).ToString());

                string amt1 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt1.Trim();
                Support.AreEqual("True", amt1.Equals("$10,000.00", StringComparison.OrdinalIgnoreCase).ToString());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing REB Credits for seller";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit1@123", 12345678901.23, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq11 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq11 = seq11.Trim();
                Support.AreEqual("06", seq11);

                string label11 = FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString();
                label11 = label11.Trim();
                Debug.Print(label11.ToString());
                Support.AreEqual("BuyerCredit1@123  from Midwest Financial Group", label11);

                string amt11 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt11.Trim();
                Support.AreEqual("$345,678,901.23", amt11);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_TC_467357_NO_11

        #region US_464525_TC_467359_NO_13

        [TestMethod, Description("VERIFY REB CREDITS FOR OTHERS IN SECTION L")]
        public void US_464525_TC_467359_NO_13()
        {
            try
            {
                Reports.TestDescription = "VERIFY REB CREDITS FOR OTHERS IN SECTION L";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating REB Credits for Others";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit3", 10000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("True", seq1.Equals("06", StringComparison.OrdinalIgnoreCase).ToString());

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.FAGetAttribute("Title").ToString();
                label1 = label1.Trim();
                Debug.Print(label1.ToString());
                Support.AreEqual("True", label1.Equals("BuyerCredit3 from Midwest Financial Group", StringComparison.OrdinalIgnoreCase).ToString());

                string amt1 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt1.Trim();
                Support.AreEqual("True", amt1.Equals("$10,000.00", StringComparison.OrdinalIgnoreCase).ToString());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing REB Credits for others";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("dgdOtherREBroker_1_labelOtherName")).FAClick();
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit3@123", 12345678901.23, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq11 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq11 = seq11.Trim();
                Support.AreEqual("06", seq11);

                string label11 = FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString();
                label11 = label11.Trim();
                Debug.Print(label11.ToString());
                Support.AreEqual("BuyerCredit3@123 from Midwest Financial Group", label11);

                string amt11 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt11.Trim();
                Support.AreEqual("$345,678,901.23", amt11);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_TC_467359_NO_13

        #region US_464525_TC_470051_NO_14

        [TestMethod, Description("VERIFY SEQUENCE OF CREDITS IN LINE06 AND LINE07")]
        public void US_464525_TC_470051_NO_14()
        {
            try
            {
                Reports.TestDescription = "VERIFY SEQUENCE OF CREDITS IN LINE06 AND LINE07";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 1000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating REB Credits for seller";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(250);
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BuyerCredit1", 2000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Credit Amount for Assumption Loan 1st Instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan");
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.DetailsGABcode, 5);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("248");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                Playback.Wait(250);
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 3000, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("3000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq1 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq1 = seq1.Trim();
                Support.AreEqual("06", seq1);

                string label1 = FastDriver.ClosingDisclosure.SectionL06_Label.FAGetAttribute("Title").ToString();
                label1 = label1.Trim();
                Debug.Print(label1.ToString());
                Support.AreEqual("Tax Installment: Amount from Midwest Financial Group", label1);

                string amt1 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt1 = amt1.Trim();
                Support.AreEqual("$1,000.00", amt1);

                string seq2 = FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.ToString();
                seq2 = seq2.Trim();
                Support.AreEqual("07", seq2);

                string label2 = FastDriver.ClosingDisclosure.SectionL07_Label.FAGetAttribute("Title").ToString();
                label2 = label2.Trim();
                Debug.Print(label2.ToString());
                Support.AreEqual("See attached page for additional information", label2);

                string amt2 = FastDriver.ClosingDisclosure.SectionL07_Amt.Text.ToString();
                amt2 = amt2.Trim();
                Support.AreEqual("$5,000.00", amt2);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deleting Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 0, null, null, null, "");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();

                string seq11 = FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString();
                seq11 = seq11.Trim();
                Support.AreEqual("06", seq11);

                string label11 = FastDriver.ClosingDisclosure.SectionL06_Label.FAGetAttribute("Title").ToString();
                label11 = label11.Trim();
                Debug.Print(label11.ToString());
                Support.AreEqual("BuyerCredit1 from Midwest Financial Group", label11);

                string amt11 = FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString();
                amt11 = amt11.Trim();
                Support.AreEqual("$2,000.00", amt11);

                string seq22 = FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.ToString();
                seq22 = seq22.Trim();
                Support.AreEqual("07", seq22);

                string label22 = FastDriver.ClosingDisclosure.SectionL07_Label.FAGetAttribute("Title").ToString();
                label22 = label22.Trim();
                Debug.Print(label22.ToString());
                Support.AreEqual("Assumption Transfer Fee from Midwest Financial Group", label22);

                string amt22 = FastDriver.ClosingDisclosure.SectionL07_Amt.Text.ToString();
                amt22 = amt22.Trim();
                Support.AreEqual("$3,000.00", amt22);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_464525_TC_470051_NO_14

        #endregion 464525- CD Screen: Section L: Display Buyer Credits on lines L 06 and L 07 and 393359- CD Screen – Section L: Display Asterisk for charge groups

        #region 464514: CD SCREEN - SECTION L - DISPLAY SUPPLEMENTAL SUMMARY LINE ON LINE L 11

        #region FEA_5_US_464514_TC_468406_NO_01

        [TestMethod, Description("Display and verify  Supplemental Summary line on line L11 in CD screen")]
        public void FEA_5_US_464514_TC_468406_NO_01()
        {
            try
            {
                Reports.TestDescription = "Display and verify  Supplemental Summary line on line L11 in CD screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "NAVIGATE TO OFF-SET SCREEN AND ENTER BUYER CREDIT";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Lease/Rent", null, null, 100, null, null);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Security Deposit", null, null, 250.50, null, null);
                FastDriver.AdjustmentOffset.AddOffsetCharges("Offset Adhoc 1", null, 12345678910.12, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO Miscellaneous SCREEN AND ENTER BUYER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentMisc.SwitchToContentFrame();
                FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", null, null, 0.99, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("08", FastDriver.ClosingDisclosure.SectionL08_Seqno.Text.ToString().Trim());
                Support.AreEqual("Assign Tenant Lease/Rent", FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString().Trim());
                Support.AreEqual("$100.00", FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString().Trim());

                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionL09_Seqno.Text.ToString().Trim());
                Support.AreEqual("Assign Tenant Security Deposit", FastDriver.ClosingDisclosure.SectionL09_Label.Text.ToString().Trim());
                Support.AreEqual("$250.50", FastDriver.ClosingDisclosure.SectionL09_Amt.Text.ToString().Trim());

                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionL10_Seqno.Text.ToString().Trim());
                Support.AreEqual("IBA Interest Paid", FastDriver.ClosingDisclosure.SectionL10_Label.Text.ToString().Trim());
                Support.AreEqual("$0.99", FastDriver.ClosingDisclosure.SectionL10_Amt.Text.ToString().Trim());

                Support.AreEqual("11", FastDriver.ClosingDisclosure.SectionL11_Seqno.Text.ToString().Trim());
                Support.AreEqual("Offset Adhoc 1", FastDriver.ClosingDisclosure.SectionL11_Label.Text.ToString().Trim());
                Debug.Print(FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString().Trim());

                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous");
                Playback.Wait(250);
                FastDriver.AdjustmentMisc.AddMiscCharges("Adjustment Adhoc 1", null, 12345678910.12, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("11", FastDriver.ClosingDisclosure.SectionL11_Seqno.Text.ToString().Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL11_Label.Text.ToString().Trim());
                Support.AreEqual("$345,678,911.11", FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString().Trim());

                Support.AreEqual("11a", FastDriver.ClosingDisclosure.SectionL11a_Seqno.Text.ToString().Trim());
                Support.AreEqual("IBA Interest Paid", FastDriver.ClosingDisclosure.SectionL11a_Label.Text.ToString().Trim());
                Support.AreEqual("$0.99", FastDriver.ClosingDisclosure.SectionL11a_Amt.Text.ToString().Trim());

                Support.AreEqual("11b", FastDriver.ClosingDisclosure.SectionLSupL02_Seqno.Text.ToString().Trim());
                Support.AreEqual("Offset Adhoc 1", FastDriver.ClosingDisclosure.SectionLSupL02_Label.Text.ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionLSupL02_Amt.Text.ToString().Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464514_TC_468406_NO_01

        #endregion 464514: CD SCREEN - SECTION L - DISPLAY SUPPLEMENTAL SUMMARY LINE ON LINE L 11

        #region 464510: CD SCREEN - SECTION L: SUPPLEMENTAL ADJUSTMENTS FOR SECTION L

        #region FEA_5_US_464510_TC_476081_NO_01

        [TestMethod, Description("VERIFY THE DESCRIPTION AND LINE NUMBERS FOR ADJUSTMENT OFFSET AND AD-HOC OFFSET BUYER CREDITS IN THE SUPPLEMENTAL PAGE.")]
        public void FEA_5_US_464510_TC_476081_NO_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE DESCRIPTION AND LINE NUMBERS FOR ADJUSTMENT OFFSET AND AD-HOC OFFSET BUYER CREDITS IN THE SUPPLEMENTAL PAGE.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "NAVIGATE TO OFF-SET SCREEN AND ENTER BUYER CREDIT";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Lease/Rent", null, null, 100.50, null, null);
                FastDriver.AdjustmentOffset.AddOffsetCharges("EFGH", null, 0.99, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentOffset.AddOffsetCharges("ABCD", null, 2000, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentOffset.AddOffsetCharges("123Bcharge 2", null, 0.99, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentOffset.AddOffsetCharges("*@##$adhoc Charge 3", null, 0.750, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentOffset.AddOffsetCharges("acbcd", null, 12345678910.12, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("08", FastDriver.ClosingDisclosure.SectionL08_Seqno.Text.ToString().Trim());
                Support.AreEqual("*@##$adhoc Charge 3", FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString().Trim());
                Support.AreEqual("$0.75", FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString().Trim());

                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionL09_Seqno.Text.ToString().Trim());
                Support.AreEqual("123Bcharge 2", FastDriver.ClosingDisclosure.SectionL09_Label.Text.ToString().Trim());
                Support.AreEqual("$0.99", FastDriver.ClosingDisclosure.SectionL09_Amt.Text.ToString().Trim());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL10_Seqno.Text.ToString().Trim().Equals("10", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL10_Label.Text.ToString().Trim().Equals("ABCD", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL10_Amt.Text.ToString().Trim().Equals("$2,000.00", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11_Seqno.Text.ToString().Trim().Equals("11", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11_Label.Text.ToString().Trim().Equals("See attached page for additional information", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString().Trim().Equals("$345,679,011.61", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString().Trim());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11a_Seqno.Text.ToString().Trim().Equals("11a", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11a_Label.Text.ToString().Trim().Equals("acbcd", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11a_Amt.Text.ToString().Trim().Equals("$345,678,910.12", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionL11a_Amt.Text.ToString().Trim());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL02_Seqno.Text.ToString().Trim().Equals("11b", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL02_Label.Text.ToString().Trim().Equals("Assign Tenant Lease/Rent", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionLSupL02_Label.Text.ToString().Trim());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL02_Amt.Text.ToString().Trim().Equals("$100.50", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL03_Seqno.Text.ToString().Trim().Equals("11c", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL03_Label.Text.ToString().Trim().Equals("EFGH", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL03_Amt.Text.ToString().Trim().Equals("$0.99", StringComparison.OrdinalIgnoreCase).ToString());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464510_TC_476081_NO_01

        #region FEA_5_US_464510_TC_476083_NO_02

        [TestMethod]
        public void FEA_5_US_464510_TC_476083_NO_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE DESCRIPTION AND LINE NUMBERS FOR AD-HOC  MISCELLANEOUS ADJUSTMENTS CREDITS  IN THE SUPPLEMENTAL PAGE.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "NAVIGATE TO OFF-SET SCREEN AND ENTER BUYER CREDIT";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentMisc.UpdateMiscCharges("Buyer Deposit Directly to Seller", null, null, 0.99, null, null);
                FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", null, null, 12345678910.12, null, null);
                FastDriver.AdjustmentMisc.AddMiscCharges("ABCD", null, 250.50, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentMisc.AddMiscCharges("abcd", null, 2000, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentMisc.AddMiscCharges("@#$%XYA", null, 100.50, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentMisc.AddMiscCharges("1235$adhoc Charge 5", null, 0.99, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL08_Seqno.Text.ToString().Trim().Equals("08", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString().Trim().Equals("@#$%XYA", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString().Trim().Equals("$100.50", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL09_Seqno.Text.ToString().Trim().Equals("09", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL09_Label.Text.ToString().Trim().Equals("1235$adhoc Charge 5", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL09_Amt.Text.ToString().Trim().Equals("$0.99", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL10_Seqno.Text.ToString().Trim().Equals("10", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL10_Label.Text.ToString().Trim().Equals("abcd", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL10_Amt.Text.ToString().Trim().Equals("$2,000.00", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11_Seqno.Text.ToString().Trim().Equals("11", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11_Label.Text.ToString().Trim().Equals("See attached page for additional information", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString().Trim().Equals("$345,679,161.61", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString().Trim());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11a_Seqno.Text.ToString().Trim().Equals("11a", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11a_Label.Text.ToString().Trim().Equals("ABCD", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11a_Amt.Text.ToString().Trim().Equals("$250.50", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionL11a_Amt.Text.ToString().Trim());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL02_Seqno.Text.ToString().Trim().Equals("11b", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL02_Label.Text.ToString().Trim().Equals("Buyer Deposit Directly to Seller", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionLSupL02_Label.Text.ToString().Trim());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL02_Amt.Text.ToString().Trim().Equals("$0.99", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL03_Seqno.Text.ToString().Trim().Equals("11c", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL03_Label.Text.ToString().Trim().Equals("IBA Interest Paid", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL03_Amt.Text.ToString().Trim().Equals("$345,678,910.12", StringComparison.OrdinalIgnoreCase).ToString());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464510_TC_476083_NO_02

        #region FEA_5_US_464510_TC_484539_NO_03

        [TestMethod, Description("VERIFY THE DESCRIPTION AND LINE NUMBERS FOR AD-HOC OFF-SET AND AD-HOC MISCELLANEOUS ADJUSTMENTS AMOUNTS IN THE SUPPLEMENTAL PAGE.")]
        public void FEA_5_US_464510_TC_484539_NO_03()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE DESCRIPTION AND LINE NUMBERS FOR AD-HOC OFF-SET AND AD-HOC MISCELLANEOUS ADJUSTMENTS AMOUNTS IN THE SUPPLEMENTAL PAGE.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "NAVIGATE TO OFF-SET SCREEN AND ENTER BUYER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Security Deposit", null, null, 250.50, null, null);
                FastDriver.AdjustmentOffset.AddOffsetCharges("QCALM", null, 0.75, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentOffset.AddOffsetCharges("&@#$adhoc", null, 2000, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "NAVIGATE TO Miscellaneous SCREEN AND ENTER BUYER CHARGE";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", null, null, 100.50, null, null);
                FastDriver.AdjustmentMisc.AddMiscCharges("QUALCOM", null, 12345678910.12, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.AdjustmentMisc.AddMiscCharges("1235$adhoc Charge 5", null, 0.99, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL08_Seqno.Text.ToString().Trim().Equals("08", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString().Trim().Equals("&@#$adhoc", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString().Trim().Equals("$2,000.00", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL09_Seqno.Text.ToString().Trim().Equals("09", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL09_Label.Text.ToString().Trim().Equals("1235$adhoc Charge 5", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL09_Amt.Text.ToString().Trim().Equals("$0.99", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL10_Seqno.Text.ToString().Trim().Equals("10", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL10_Label.Text.ToString().Trim().Equals("Assign Tenant Security Deposit", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL10_Amt.Text.ToString().Trim().Equals("$250.50", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11_Seqno.Text.ToString().Trim().Equals("11", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11_Label.Text.ToString().Trim().Equals("See attached page for additional information", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString().Trim().Equals("$345,679,011.37", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionL11_Amt.Text.ToString().Trim());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11a_Seqno.Text.ToString().Trim().Equals("11a", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11a_Label.Text.ToString().Trim().Equals("IBA Interest Paid", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL11a_Amt.Text.ToString().Trim().Equals("$100.50", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionL11a_Amt.Text.ToString().Trim());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL02_Seqno.Text.ToString().Trim().Equals("11b", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL02_Label.Text.ToString().Trim().Equals("QCALM", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionLSupL02_Label.Text.ToString().Trim());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL02_Amt.Text.ToString().Trim().Equals("$0.75", StringComparison.OrdinalIgnoreCase).ToString());

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL03_Seqno.Text.ToString().Trim().Equals("11c", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL03_Label.Text.ToString().Trim().Equals("QUALCOM", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionLSupL03_Amt.Text.ToString().Trim().Equals("$345,678,910.12", StringComparison.OrdinalIgnoreCase).ToString());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464510_TC_484539_NO_03

        #endregion 464510: CD SCREEN - SECTION L: SUPPLEMENTAL ADJUSTMENTS FOR SECTION L

        #region 464149: CD SCREEN - SECTION L - DISPLAY NEW LOAN 2+ INSTANCES ON LINE L04

        #region FEA_5_US_464149_TC_487520_NO_01

        [TestMethod, Description("Enter Loan amount  in multiple instance and Verify the Loan amount  on line L04")]
        public void FEA_5_US_464149_TC_487520_NO_01()
        {
            try
            {
                Reports.TestDescription = "Enter Loan amount  in multiple instance and Verify the Loan amount  on line L04";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter GAB code in 1st Instance.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();

                Reports.TestStep = "Enter Loan Amount in 2nd instance";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                Keyboard.SendKeys("^N");
                Playback.Wait(3000);
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("12345678910.12");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL04_Seqno.Text.ToString().Trim().Equals("04", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL04_Label.GetAttribute("Title").ToString().Trim().Equals("Second Loan", StringComparison.OrdinalIgnoreCase).ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionL04_Label.Text.ToString().Trim());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL04_Amt.Text.ToString().Trim().Equals("$345,678,910.12", StringComparison.OrdinalIgnoreCase).ToString());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Loan Amount in 3nd instance";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoanSummary.New.FAClick();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("314");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("250.50");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionL04_Seqno.Text.Trim());
                Support.AreEqual("Second Loan", FastDriver.ClosingDisclosure.SectionL04_Label.GetAttribute("Title").Trim());
                Support.AreEqual("$345,679,160.62", FastDriver.ClosingDisclosure.SectionL04_Amt.Text.Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464149_TC_487520_NO_01

        #region FEA_5_US_464149_TC_487732_NO_02

        [TestMethod, Description("Enter Loan amount  in multiple instance and Verify the Loan amount  on line L04")]
        public void FEA_5_US_464149_TC_487732_NO_02()
        {
            try
            {
                Reports.TestDescription = "Enter Loan amount  in multiple instance and Verify the Loan amount  on line L04";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter GAB code in 1st Instance.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Loan Amount in 2nd instance";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.BottomFrame.New();
                Playback.Wait(1000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("12345678910.12");
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", 50.00, 100.00, null, null, null);
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("50");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.MortgageGABcode, 10);
                FastDriver.NewLoan.MortgageGABcode.FASetText("314");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge1.FASetText("200");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCredit1.FASetText("300");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge1.FAClick();
                Playback.Wait(250);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("200");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL04_Seqno.Text.ToString().Trim().Equals("04", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL04_Label.Text.ToString().Trim().Equals("*  Second Loan  (Principal Balance $345,678,910.12)", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL04_Amt.Text.ToString().Trim().Equals("$345,678,760.12", StringComparison.OrdinalIgnoreCase).ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL04_Label.Text.ToString().Contains("*").ToString());
                Debug.Print(FastDriver.ClosingDisclosure.SectionL04_Amt.Text.ToString().Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464149_TC_487732_NO_02

        #endregion 464149: CD SCREEN - SECTION L - DISPLAY NEW LOAN 2+ INSTANCES ON LINE L04

        #region 464530: CD SCREEN - SECTION L: SUPPLEMENTAL CREDITS FOR SECTION L 06- L 07

        #region FEA_5_US_464530_TC_485908_NO_01

        [TestMethod]
        public void FEA_5_US_464530_TC_485908_NO_01()
        {
            try
            {
                Reports.TestDescription = "Enter Loan amount  in multiple instance and Verify the Loan amount  on line L04";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 12345678910.12, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("12345678910.12");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.CommissionAmount, 10);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("ABCD", 0.750, null, null);
                Keyboard.SendKeys(FAKeys.TabAway); 
                Keyboard.SendKeys(FAKeys.TabAway); 
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Adhoc Seller Broker 1", 12345678910.12, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("314");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 2000, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(5000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString().Trim());
                Support.AreEqual("Tax Installment: Amount from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString().Trim());

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.ToString().Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL07_Label.Text.ToString().Trim());
                Support.AreEqual("$345,680,910.87", FastDriver.ClosingDisclosure.SectionL07_Amt.Text.ToString().Trim());

                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text.ToString().Trim());
                Support.AreEqual("Real Estate Broker Credits", FastDriver.ClosingDisclosure.SectionL07a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.87", FastDriver.ClosingDisclosure.SectionL07a_SubAmt.Text.ToString().Trim());

                Support.AreEqual("ABCD from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$0.75", FastDriver.ClosingDisclosure.SectionL07SupL02_Amt.Text.ToString().Trim());

                Support.AreEqual("Adhoc Seller Broker 1 from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07SupL03_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL07SupL03_Amt.Text.ToString().Trim());

                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionL07SupL04_Seqno.Text.ToString().Trim());
                Support.AreEqual("Assumption Transfer Fee from Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.SectionL07SupL04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$2,000.00", FastDriver.ClosingDisclosure.SectionL07SupL04_Amt.Text.ToString().Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464530_TC_485908_NO_01

        #region FEA_5_US_464530_TC_485913_NO_02

        [TestMethod, Description("Verify the Description and Line numbers for single charge Assumption Loan 1 and 2+ instance Buyer Credits in the supplemental page.")]
        public void FEA_5_US_464530_TC_485913_NO_02()
        {
            try
            {
                Reports.TestDescription = "Verify the Description and Line numbers for single charge Assumption Loan 1 and 2+ instance Buyer Credits in the supplemental page.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 12345678910.12, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("12345678910.12");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("314");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 12345678910.12, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen 2nd instance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.BottomFrame.New();
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.DetailsGABcode, 10);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("248");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 250.50, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString().Trim());
                Support.AreEqual("Tax Installment: Amount from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString().Trim());

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.ToString().Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL07_Label.Text.ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL07_Amt.Text.ToString().Trim());

                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text.ToString().Trim());
                Support.AreEqual("Assumption Transfer Fee from Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.SectionL07a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL07a_Amt.Text.ToString().Trim());

                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionL07SupL02_Seqno.Text.ToString().Trim());
                Support.AreEqual("Assumption Transfer Fee from Midwest Financial Group $250.50 P.O.C.", FastDriver.ClosingDisclosure.SectionL07SupL02_Label.GetAttribute("Title").ToString().Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464530_TC_485913_NO_02

        #region FEA_5_US_464530_TC_485920_NO_03

        [TestMethod, Description("Verify the Description and Line numbers for REB Credits for Buyer in Section L supplemental page.")]
        public void FEA_5_US_464530_TC_485920_NO_03()
        {
            try
            {
                Reports.TestDescription = "Verify the Description and Line numbers for REB Credits for Buyer in Section L supplemental page.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 150.50, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("150.50");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Adhoc Seller Broker", 12345678910.12, null, null);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Adhoc Seller Broker 1 ", 0.99, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("314");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 250.50, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString().Trim());
                Support.AreEqual("Tax Installment: Amount from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$150.50", FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString().Trim());

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.ToString().Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL07_Label.Text.ToString().Trim());
                Support.AreEqual("$345,679,161.61", FastDriver.ClosingDisclosure.SectionL07_Amt.Text.ToString().Trim());

                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text.ToString().Trim());
                Support.AreEqual("Real Estate Broker Credits", FastDriver.ClosingDisclosure.SectionL07a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,911.11", FastDriver.ClosingDisclosure.SectionL07a_SubAmt.Text.ToString().Trim());

                Support.AreEqual("Adhoc Seller Broker from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL07SupL02_Amt.Text.ToString().Trim());

                Support.AreEqual("Adhoc Seller Broker 1 from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL07SupL03_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$0.99", FastDriver.ClosingDisclosure.SectionL07SupL03_Amt.Text.ToString().Trim());

                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionL07SupL04_Seqno.Text.ToString().Trim());
                Support.AreEqual("Assumption Transfer Fee from Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.SectionL07SupL04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$250.50", FastDriver.ClosingDisclosure.SectionL07SupL04_Amt.Text.ToString().Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464530_TC_485920_NO_03

        #region FEA_5_US_464530_TC_485922_NO_04

        [TestMethod, Description("Verify the Description and Line numbers for REB Credits for seller in Section L supplemental page.")]
        public void FEA_5_US_464530_TC_485922_NO_04()
        {
            try
            {
                Reports.TestDescription = "Verify the Description and Line numbers for REB Credits for seller in Section L supplemental page.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", null, 150.50, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("12345678910.12");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Other REB", 12345678910.12, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Other Broker 1", 12345678910.12, null, null);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("314");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 0.99, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString().Trim());
                Support.AreEqual("Tax Installment: Penalty Due from Lenders Advantage A Division Of First American Title Ins. $345,678,910.12 P.O.C.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.ToString().Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL07_Label.Text.ToString().Trim());
                Support.AreEqual("$691,357,821.23", FastDriver.ClosingDisclosure.SectionL07_Amt.Text.ToString().Trim());

                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text.ToString().Trim());
                Support.AreEqual("Real Estate Broker Credits", FastDriver.ClosingDisclosure.SectionL07a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$691,357,820.24", FastDriver.ClosingDisclosure.SectionL07a_SubAmt.Text.ToString().Trim());

                Support.AreEqual("Other Broker 1 from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL07SupL02_Amt.Text.ToString().Trim());

                Support.AreEqual("Other REB from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07SupL03_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL07SupL03_Amt.Text.ToString().Trim());

                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionL07SupL04_Seqno.Text.ToString().Trim());
                Support.AreEqual("Assumption Transfer Fee from Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.SectionL07SupL04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$0.99", FastDriver.ClosingDisclosure.SectionL07SupL04_Amt.Text.ToString().Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464530_TC_485922_NO_04

        #region FEA_5_US_464530_TC_485924_NO_05

        [TestMethod, Description("Verify the Description and Line numbers for REB Credits for seller in Section L supplemental page.")]
        public void FEA_5_US_464530_TC_485924_NO_05()
        {
            try
            {
                Reports.TestDescription = "Verify the Description and Line numbers for REB Credits for seller in Section L supplemental page.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 150.50, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("150.50");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BCDE Seller Broker 1", 0.99, null, null);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("314");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("ABCD", 250.50, null, null);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("Others REB 1", 12345678910.12, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("314");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 1000, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString().Trim());
                Support.AreEqual("Tax Installment: Amount from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$150.50", FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString().Trim());

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.ToString().Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL07_Label.Text.ToString().Trim());
                Support.AreEqual("$345,679,161.61", FastDriver.ClosingDisclosure.SectionL07_Amt.Text.ToString().Trim());

                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text.ToString().Trim());
                Support.AreEqual("Real Estate Broker Credits", FastDriver.ClosingDisclosure.SectionL07a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,679,161.61", FastDriver.ClosingDisclosure.SectionL07a_SubAmt.Text.ToString().Trim());

                Support.AreEqual("ABCD from Smythe & Lee Jerome E. Lee", FastDriver.ClosingDisclosure.SectionL07SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$250.50", FastDriver.ClosingDisclosure.SectionL07SupL02_Amt.Text.ToString().Trim());

                Support.AreEqual("BCDE Seller Broker 1 from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07SupL03_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$0.99", FastDriver.ClosingDisclosure.SectionL07SupL03_Amt.Text.ToString().Trim());

                Support.AreEqual("Others REB 1 from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07SupL04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.ClosingDisclosure.SectionL07SupL04_Amt.Text.ToString().Trim());

                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionL07SupL05_Seqno.Text.ToString().Trim());
                Support.AreEqual("Assumption Transfer Fee from Smythe & Lee Jerome E. Lee $1,000.00 P.O.C.", FastDriver.ClosingDisclosure.SectionL07SupL05_Label.GetAttribute("Title").ToString().Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_464530_TC_485924_NO_05

        #endregion 464530: CD SCREEN - SECTION L: SUPPLEMENTAL CREDITS FOR SECTION L 06- L 07

        #region 393362: CD SCREEN – SECTION L: VIEW DETAILS OF THE CREDITS THAT ARE PART OF THE CHARGE GROUP

        #region FEA_5_US_393362_TC_488660_NO_01

        [TestMethod, Description("Enter Loan amount and charges in multiple instance and Verify the Loan amount  on line L04")]
        public void FEA_5_US_393362_TC_488660_NO_01()
        {
            try
            {
                Reports.TestDescription = "Enter Loan amount and charges in multiple instance and Verify the Loan amount  on line L04";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter GAB code in 1st Instance.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("247");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Loan Amount in 2nd instance";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.BottomFrame.New();
                Playback.Wait(1000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 20);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan. LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("12345678910.12");
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Lender's Inspection Fee", 250.00, 500.00);
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("100");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("150");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", 200.00, 100.00);
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("50");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("150");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-MB");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.MortgageGABcode, 10);
                FastDriver.NewLoan.MortgageGABcode.FASetText("314");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", 200.00, 300.00);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("100");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("100");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();

                FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "New Loan 2 Adhoc 1", 150.00, 200.00);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("75");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("50");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("25");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Validating the Charges in Section L";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionL04_Seqno.Text.ToString().Trim());
                Support.AreEqual("*  Second Loan  (Principal Balance $345,678,910.12)", FastDriver.ClosingDisclosure.SectionL04_Label.Text.ToString().Trim());
                Support.AreEqual("$345,679,385.12", FastDriver.ClosingDisclosure.SectionL04_Amt.Text.ToString().Trim());

                FastDriver.ClosingDisclosure.L04Plus.FAClick();
                Playback.Wait(500);

                FastDriver.CDL04Popup.WaitCreation(FastDriver.CDL04Popup.L04SeqNo, 10);
                Support.AreEqual("04", FastDriver.CDL04Popup.L04SeqNo.Text.ToString().Trim());
                Support.AreEqual("Second Loan", FastDriver.CDL04Popup.L04Description.Text.ToString().Trim());
                Support.AreEqual("$345,679,385.12", FastDriver.CDL04Popup.L04Amt.Text.ToString().Trim());

                Support.AreEqual("a", FastDriver.CDL04Popup.L04SeqNo1.Text.ToString().Trim());
                Support.AreEqual("New Loan 2 Credits", FastDriver.CDL04Popup.L04ChargeDesc1.Text.ToString().Trim());
                Support.AreEqual("$345,679,385.12", FastDriver.CDL04Popup.L04TotalChargeAmt1.Text.ToString().Trim());

                Support.AreEqual("New Loan to File from Midwest Financial Group", FastDriver.CDL04Popup.L04ChargeDesc2.Text.ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.CDL04Popup.L04ChargeAmt2.Text.ToString().Trim());

                Support.AreEqual("Appraisal Fee from Midwest Financial Group $150.00 P.O.C. MB", FastDriver.CDL04Popup.L04ChargeDesc3.Text.ToString().Trim());
                Support.AreEqual("$50.00", FastDriver.CDL04Popup.L04ChargeAmt3.Text.ToString().Trim());

                Support.AreEqual("Lender's Inspection Fee from Midwest Financial Group $150.00 P.O.C. Lender", FastDriver.CDL04Popup.L04ChargeDesc4.Text.ToString().Trim());
                Support.AreEqual("$400.00", FastDriver.CDL04Popup.L04ChargeAmt4.Text.ToString().Trim());

                Support.AreEqual("Credit Report from Smythe & Lee Jerome E. Lee $400.00 P.O.C. Lender", FastDriver.CDL04Popup.L04ChargeDesc5.Text.ToString().Trim());
                Support.AreEqual("-$100.00", FastDriver.CDL04Popup.L04ChargeAmt5.Text.ToString().Trim());

                Support.AreEqual("New Loan 2 Adhoc 1 from Smythe & Lee Jerome E. Lee $75.00 P.O.C.", FastDriver.CDL04Popup.L04ChargeDesc6.Text.ToString().Trim());
                Support.AreEqual("$125.00", FastDriver.CDL04Popup.L04ChargeAmt6.Text.ToString().Trim());

                FastDriver.CDL04Popup.Done.FAClick();
                Playback.Wait(500);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_393362_TC_488660_NO_01

        #region FEA_5_US_393362_TC_491838_NO_2

        [TestMethod, Description("Enter Loan amount and charges in multiple instance and Verify the Loan amount  on line L04")]
        public void FEA_5_US_393362_TC_491838_NO_2()
        {
            try
            {
                Reports.TestDescription = "Enter Loan amount and charges in multiple instance and Verify the Loan amount  on line L04";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter GAB code in 1st Instance.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter Loan Amount in 2nd instance";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.BottomFrame.New();
                Playback.Wait(1000);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 20);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("314");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2000");
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", 200.00, 0);
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("200");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0.00");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0.00");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", 0, 100.00);
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("100");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.NewLoanChargesTable, "Document Preparation Fee", 500.00, 100.00);
                FastDriver.NewLoan.LoanChargesNewLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.Description, 5);
                FastDriver.PaymentDetailsDlg.Description.FASetText("ABCDEF");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("JDA SOFTWARE");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("200");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("200");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("100");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("100");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageGABcode.FASetText("314");
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", 200.00, 300.00);
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("100");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("100");
                FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItem("POC-L");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify. ";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionL04_Seqno.Text.ToString().Trim());
                Support.AreEqual("*  Second Loan  (Principal Balance $2,000.00)", FastDriver.ClosingDisclosure.SectionL04_Label.Text.ToString().Trim());
                Support.AreEqual("$1,600.00", FastDriver.ClosingDisclosure.SectionL04_Amt.Text.ToString().Trim());

                FastDriver.ClosingDisclosure.L04Plus.FAClick();
                Playback.Wait(500);

                FastDriver.CDL04Popup.WaitCreation(FastDriver.CDL04Popup.L04SeqNo, 10);
                Support.AreEqual("04", FastDriver.CDL04Popup.L04SeqNo.Text.ToString().Trim());
                Support.AreEqual("Second Loan", FastDriver.CDL04Popup.L04Description.Text.ToString().Trim());
                Support.AreEqual("$1,600.00", FastDriver.CDL04Popup.L04Amt.Text.ToString().Trim());

                Support.AreEqual("a", FastDriver.CDL04Popup.L04SeqNo1.Text.ToString().Trim());
                Support.AreEqual("New Loan 2 Credits", FastDriver.CDL04Popup.L04ChargeDesc1.Text.ToString().Trim());
                Support.AreEqual("$1,600.00", FastDriver.CDL04Popup.L04TotalChargeAmt1.Text.ToString().Trim());

                Support.AreEqual("New Loan to File from Smythe & Lee Jerome E. Lee", FastDriver.CDL04Popup.L04ChargeDesc2.Text.ToString().Trim());
                Support.AreEqual("$2,000.00", FastDriver.CDL04Popup.L04ChargeAmt2.Text.ToString().Trim());

                Support.AreEqual("Appraisal Fee from Smythe & Lee Jerome E. Lee", FastDriver.CDL04Popup.L04ChargeDesc3.Text.ToString().Trim());
                Support.AreEqual("-$200.00", FastDriver.CDL04Popup.L04ChargeAmt3.Text.ToString().Trim());

                Support.AreEqual("Credit Report from Smythe & Lee Jerome E. Lee $100.00 P.O.C.", FastDriver.CDL04Popup.L04ChargeDesc4.Text.ToString().Trim());
                Reports.StatusUpdate("AMOUNT FILED IS EMPTY", FastDriver.CDL04Popup.L04ChargeAmt4.Text.ToString().Trim() == "");

                Support.AreEqual("ABCDEF from JDA SOFTWARE $300.00 P.O.C.", FastDriver.CDL04Popup.L04ChargeDesc5.Text.ToString().Trim());
                Support.AreEqual("-$100.00", FastDriver.CDL04Popup.L04ChargeAmt5.Text.ToString().Trim());

                Support.AreEqual("Credit Report from Smythe & Lee Jerome E. Lee $400.00 P.O.C. Lender", FastDriver.CDL04Popup.L04ChargeDesc6.Text.ToString().Trim());
                Support.AreEqual("-$100.00", FastDriver.CDL04Popup.L04ChargeAmt6.Text.ToString().Trim());

                FastDriver.CDL04Popup.Done.FAClick();
                Playback.Wait(500);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_393362_TC_491838_NO_2

        #region FEA_5_US_393362_TC_492097_NO_03

        [TestMethod, Description("Verify the Description and Line numbers for REB Credits for Buyer Broker, Seller Broker and other Brokers amounts in line L06 popup")]
        public void FEA_5_US_393362_TC_492097_NO_03()
        {
            try
            {
                Reports.TestDescription = "Verify the Description and Line numbers for REB Credits for Buyer Broker, Seller Broker and other Brokers amounts in line L06 popup";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("BCD", 0.75, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("bcd", 12345678910.12, null, null);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.CommissionAmount, 10);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("10");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("@#$%XYA", 100.50, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("QCALM", 2000, null, null);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("314");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.CommissionAmount, 10);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("1235$adhoc Charge 5", 0.99, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("HPALM", 250.50, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString().Trim());
                Support.AreEqual("*  Real Estate Broker Credits", FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString().Trim());
                Support.AreEqual("$345,681,262.86", FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString().Trim());

                FastDriver.ClosingDisclosure.L06Plus.FAClick();
                Playback.Wait(500);

                FastDriver.CDL06Popup.WaitCreation(FastDriver.CDL06Popup.L06SeqNo, 10);
                Support.AreEqual("06", FastDriver.CDL06Popup.L06SeqNo.Text.ToString().Trim());
                Support.AreEqual("Real Estate Broker Credits", FastDriver.CDL06Popup.L06Description.Text.ToString().Trim());
                Support.AreEqual("$345,681,262.86", FastDriver.CDL06Popup.L06Amt.Text.ToString().Trim());

                Support.AreEqual("@#$%XYA from Midwest Financial Group", FastDriver.CDL06Popup.L06ChargeDesc1.Text.ToString().Trim());
                Support.AreEqual("$100.50", FastDriver.CDL06Popup.L06ChargeAmt1.Text.ToString().Trim());

                Support.AreEqual("1235$adhoc Charge 5 from Smythe & Lee Jerome E. Lee", FastDriver.CDL06Popup.L06ChargeDesc2.Text.ToString().Trim());
                Support.AreEqual("$0.99", FastDriver.CDL06Popup.L06ChargeAmt2.Text.ToString().Trim());

                Support.AreEqual("bcd from Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDL06Popup.L06ChargeDesc3.Text.ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.CDL06Popup.L06ChargeAmt3.Text.ToString().Trim());

                Support.AreEqual("BCD from Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDL06Popup.L06ChargeDesc4.Text.ToString().Trim());
                Support.AreEqual("$0.75", FastDriver.CDL06Popup.L06ChargeAmt4.Text.ToString().Trim());

                Support.AreEqual("HPALM from Smythe & Lee Jerome E. Lee", FastDriver.CDL06Popup.L06ChargeDesc5.Text.ToString().Trim());
                Support.AreEqual("$250.50", FastDriver.CDL06Popup.L06ChargeAmt5.Text.ToString().Trim());

                Support.AreEqual("QCALM from Midwest Financial Group", FastDriver.CDL06Popup.L06ChargeDesc6.Text.ToString().Trim());
                Support.AreEqual("$2,000.00", FastDriver.CDL06Popup.L06ChargeAmt6.Text.ToString().Trim());

                FastDriver.CDL06Popup.Done.FAClick();
                Playback.Wait(500);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Change the GAB code and verify the same in POPUP";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("314");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.OtherbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString().Trim());
                Support.AreEqual("*  Real Estate Broker Credits", FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString().Trim());
                Support.AreEqual("$345,681,262.86", FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString().Trim());

                FastDriver.ClosingDisclosure.L06Plus.FAClick();
                Playback.Wait(500);

                FastDriver.CDL06Popup.WaitCreation(FastDriver.CDL06Popup.L06SeqNo, 10);
                Support.AreEqual("06", FastDriver.CDL06Popup.L06SeqNo.Text.ToString().Trim());
                Support.AreEqual("Real Estate Broker Credits", FastDriver.CDL06Popup.L06Description.Text.ToString().Trim());
                Support.AreEqual("$345,681,262.86", FastDriver.CDL06Popup.L06Amt.Text.ToString().Trim());

                Support.AreEqual("@#$%XYA from Midwest Financial Group", FastDriver.CDL06Popup.L06ChargeDesc1.Text.ToString().Trim());
                Support.AreEqual("$100.50", FastDriver.CDL06Popup.L06ChargeAmt1.Text.ToString().Trim());

                Support.AreEqual("1235$adhoc Charge 5 from Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDL06Popup.L06ChargeDesc2.Text.ToString().Trim());
                Support.AreEqual("$0.99", FastDriver.CDL06Popup.L06ChargeAmt2.Text.ToString().Trim());

                Support.AreEqual("bcd from Smythe & Lee Jerome E. Lee", FastDriver.CDL06Popup.L06ChargeDesc3.Text.ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.CDL06Popup.L06ChargeAmt3.Text.ToString().Trim());

                Support.AreEqual("BCD from Smythe & Lee Jerome E. Lee", FastDriver.CDL06Popup.L06ChargeDesc4.Text.ToString().Trim());
                Support.AreEqual("$0.75", FastDriver.CDL06Popup.L06ChargeAmt4.Text.ToString().Trim());

                Support.AreEqual("HPALM from Lenders Advantage A Division Of First American Title Ins.", FastDriver.CDL06Popup.L06ChargeDesc5.Text.ToString().Trim());
                Support.AreEqual("$250.50", FastDriver.CDL06Popup.L06ChargeAmt5.Text.ToString().Trim());

                Support.AreEqual("QCALM from Midwest Financial Group", FastDriver.CDL06Popup.L06ChargeDesc6.Text.ToString().Trim());
                Support.AreEqual("$2,000.00", FastDriver.CDL06Popup.L06ChargeAmt6.Text.ToString().Trim());

                FastDriver.CDL06Popup.Done.FAClick();
                Playback.Wait(500);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_393362_TC_492097_NO_03

        #region FEA_5_US_393362_TC_496812_NO_04

        [TestMethod, Description("Verify Property Tax check  First and Second instance charges with At closing and  POC amounts in line L06 popup.")]
        public void FEA_5_US_393362_TC_496812_NO_04()
        {
            try
            {
                Reports.TestDescription = "Verify Property Tax check  First and Second instance charges with At closing and  POC amounts in line L06 popup.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("314");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", null, 250.50, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("250.50");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Edit charge description and payee name in Property Tax Check Screen";
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 0.99, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.Description, 5);
                FastDriver.PaymentDetailsDlg.Description.FASetText("ABCDEF");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("JDA SOFTWARE");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("0.99");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", null, 12345678910.12, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("12345678910.12");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in 2nd instance  Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.BottomFrame.New();
                Playback.Wait(1000);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.WaitCreation(FastDriver.PropertyTaxCheck.GABcode, 10);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 101.01, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("101.01");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", null, 1200, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("1200");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Partial Payment Amt", null, 12345678910.12, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("12345678910.12");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify. ";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.ToString().Trim());
                Support.AreEqual("*  Property Taxes", FastDriver.ClosingDisclosure.SectionL06_Label.Text.ToString().Trim());
                Support.AreEqual("$691,358,171.75", FastDriver.ClosingDisclosure.SectionL06_Amt.Text.ToString().Trim());

                FastDriver.ClosingDisclosure.L06Plus.FAClick();
                Playback.Wait(500);

                Reports.TestStep = "Verify Description and values in popup";

                FastDriver.CDL06Popup.WaitCreation(FastDriver.CDL06Popup.L06SeqNo, 10);

                Support.AreEqual("06", FastDriver.CDL06Popup.L06SeqNo.Text.ToString().Trim());
                Support.AreEqual("Property Taxes", FastDriver.CDL06Popup.L06Description.Text.ToString().Trim());
                Support.AreEqual("$691,358,171.75", FastDriver.CDL06Popup.L06Amt.Text.ToString().Trim());

                Support.AreEqual("a", FastDriver.CDL06Popup.L06SeqNo1.Text.ToString().Trim());
                Support.AreEqual("Property Taxes 1", FastDriver.CDL06Popup.L06ChargeDesc1.Text.ToString().Trim());
                Support.AreEqual("$345,679,160.62", FastDriver.CDL06Popup.L06TotalChargeAmt1.Text.ToString().Trim());

                Support.AreEqual("Tax Installment: Interest Due from Smythe & Lee Jerome E. Lee", FastDriver.CDL06Popup.L06ChargeDesc2.Text.ToString().Trim());
                Support.AreEqual("$250.50", FastDriver.CDL06Popup.L06ChargeAmt2.Text.ToString().Trim());

                Support.AreEqual("ABCDEF from JDA SOFTWARE $0.99 P.O.C.", FastDriver.CDL06Popup.L06ChargeDesc3.Text.ToString().Trim());
                Reports.StatusUpdate("AMOUNT FIELD IS EMPTY", FastDriver.CDL06Popup.L06ChargeAmt3.Text.ToString().Trim() == "");

                Support.AreEqual("Tax Installment: Penalty Due from Smythe & Lee Jerome E. Lee", FastDriver.CDL06Popup.L06ChargeDesc4.Text.ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.CDL06Popup.L06ChargeAmt4.Text.ToString().Trim());

                Support.AreEqual("Property Taxes 2", FastDriver.CDL06Popup.L06ChargeDesc5.Text.ToString().Trim());
                Support.AreEqual("$345,679,011.13", FastDriver.CDL06Popup.L06TotalChargeAmt5.Text.ToString().Trim());

                Support.AreEqual("Tax Installment: Amount from Midwest Financial Group", FastDriver.CDL06Popup.L06ChargeDesc6.Text.ToString().Trim());
                Support.AreEqual("$101.01", FastDriver.CDL06Popup.L06ChargeAmt6.Text.ToString().Trim());

                Support.AreEqual("Tax Installment: Penalty Due from Midwest Financial Group $1,200.00 P.O.C.", FastDriver.CDL06Popup.L06ChargeDesc7.Text.ToString().Trim());
                Reports.StatusUpdate("AMOUNT FIELD IS EMPTY", FastDriver.CDL06Popup.L06ChargeAmt7.Text.ToString().Trim() == "");

                Support.AreEqual("Tax Installment: Partial Payment Amt from Midwest Financial Group", FastDriver.CDL06Popup.L06ChargeDesc8.Text.ToString().Trim());
                Support.AreEqual("$345,678,910.12", FastDriver.CDL06Popup.L06ChargeAmt8.Text.ToString().Trim());

                FastDriver.CDL06Popup.Done.FAClick();
                Playback.Wait(500);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_393362_TC_496812_NO_04

        #endregion 393362: CD SCREEN – SECTION L: VIEW DETAILS OF THE CREDITS THAT ARE PART OF THE CHARGE GROUP

        #region CD Screen - 343579-Section L: Display Buyer Title Premium Adjustment

        #region US_343579_TC_498794_NO_01

        [TestMethod, Description("Verification of Title Premium Adjustment on Closing Disclosure Screen")]
        public void US_343579_TC_498794_NO_01()
        {
            try
            {
                Reports.TestDescription = "Verification of Title Premium Adjustment on Closing Disclosure Screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create a Title Premium Adjustment Charge";
                FastDriver.LeftNavigation.Navigate<OutsideTitleSummary>(@"Home>Order Entry>Outside Title Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideTitleCompanyDetail.WaitCreation(FastDriver.OutsideTitleCompanyDetail.GABCodeEdit, 10);
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("312");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.WaitCreation(FastDriver.OutsideTitleCompanyDetail.NameLabel1, 10);
                string businesspartyname1 = FastDriver.OutsideTitleCompanyDetail.NameLabel1.Text.ToString().Trim();
                string businesspartyname2 = FastDriver.OutsideTitleCompanyDetail.NameLabel2.Text.ToString().Trim();
                FastDriver.OutsideTitleCompanyDetail.UpdateLendersPolicyAndEndorsementsTable("Title Premium Adjustment", null, 6000, null, null, null, "");
                FastDriver.OutsideTitleCompanyDetail.LenderPEDisplayTPA.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify TPA Charges on CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                string description = "Title Premium Adjustment" + " from " + businesspartyname1 + businesspartyname2;
                Support.AreEqual(description.Replace(" ", ""), FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString().Trim().Replace(" ", ""));
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString().Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_343579_TC_498794_NO_01

        #region US_343579_TC_498797_NO_02

        [TestMethod, Description("Verification of Title Premium Adjustment on Closing Disclosure Screen by Selecting / Deselecting 'Display Title Premium Adjustment' checkbox on 'Outside Title Company' screen")]
        public void US_343579_TC_498797_NO_02()
        {
            try
            {
                Reports.TestDescription = "Verification of Title Premium Adjustment on Closing Disclosure Screen by Selecting / Deselecting 'Display Title Premium Adjustment' checkbox on 'Outside Title Company' screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create a Title Premium Adjustment Charge";
                FastDriver.LeftNavigation.Navigate<OutsideTitleSummary>(@"Home>Order Entry>Outside Title Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideTitleCompanyDetail.WaitCreation(FastDriver.OutsideTitleCompanyDetail.GABCodeEdit, 10);
                FastDriver.OutsideTitleCompanyDetail.GABCodeEdit.FASetText("312");
                FastDriver.OutsideTitleCompanyDetail.FindBtn.FAClick();
                FastDriver.OutsideTitleCompanyDetail.WaitCreation(FastDriver.OutsideTitleCompanyDetail.NameLabel1, 10);
                string businesspartyname1 = FastDriver.OutsideTitleCompanyDetail.NameLabel1.Text.ToString().Trim();
                string businesspartyname2 = FastDriver.OutsideTitleCompanyDetail.NameLabel2.Text.ToString().Trim();
                FastDriver.OutsideTitleCompanyDetail.UpdateLendersPolicyAndEndorsementsTable("Title Premium Adjustment", null, 6000, null, null, null, "");
                FastDriver.OutsideTitleCompanyDetail.LenderPEDisplayTPA.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify TPA Charges on CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                string description = "Title Premium Adjustment" + " from " + businesspartyname1 + businesspartyname2;
                Support.AreEqual(description.Replace(" ", ""), FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString().Trim().Replace(" ", ""));
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString().Trim());

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deselect 'Title Premium Adjustment'checkbox from 'Outside Title Company' screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleSummary>(@"Home>Order Entry>Outside Title Company").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.OutsideTitleCompanyDetail.WaitCreation(FastDriver.OutsideTitleCompanyDetail.LenderPEDisplayTPA, 10);
                FastDriver.OutsideTitleCompanyDetail.LenderPEDisplayTPA.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify TPA Charges on CD Screen after deselecting 'Title Premium Adjustment' checkbox";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("", FastDriver.ClosingDisclosure.SectionL08_Label.Text.ToString().Trim());
                Support.AreEqual("", FastDriver.ClosingDisclosure.SectionL08_Amt.Text.ToString().Trim());

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_343579_TC_498797_NO_02

        #region US_343579_TC_498798_NO_03

        [TestMethod, Description("Verification of Title Premium Adjustment on CD screen created from 'Fee Entry' screen")]
        public void US_343579_TC_498798_NO_03()
        {
            try
            {
                Reports.TestDescription = "Verification of Title Premium Adjustment on Closing Disclosure Screen by Selecting / Deselecting 'Display Title Premium Adjustment' checkbox on 'Outside Title Company' screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create a Title Premium Adjustment Charge";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.FeeSearchFeeTypes, 10);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("%Lenders%");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeeTable, 10);
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("%Owners%");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeeTable, 10);
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.buyercharge.FASetText("100.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.buyercharge1.FASetText("100.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.sellercharge1.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.lenderAdjAmnt.FASetText("500.00");
                Keyboard.SendKeys(FAKeys.TabAway);

                string TPA = FastDriver.FileFees.SPA.GetAttribute("value");
                FastDriver.FileFees.ShowOnCD.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify TPA Charges on CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                string feeDescription = "Title Premium Adjustment";
                Support.AreEqual(feeDescription, FastDriver.ClosingDisclosure.SectionL08_Label.Text);
                Support.AreEqual(TPA, FastDriver.ClosingDisclosure.SectionL08_Amt.Text);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_343579_TC_498798_NO_03

        #region US_343579_TC_498799_NO_04

        [TestMethod, Description("Verification of Title Premium Adjustment on CD screen by Selecting / Deselecting 'Show on CD Page 3?' checkbox created from 'Fee Entry' screen")]
        public void US_343579_TC_498799_NO_04()
        {
            try
            {
                Reports.TestDescription = "Verification of Title Premium Adjustment on CD screen by Selecting / Deselecting 'Show on CD Page 3?' checkbox created from 'Fee Entry' screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Create a Title Premium Adjustment Charge";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.FeeSearchFeeTypes, 10);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("%Lenders%");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeeTable, 10);
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("%Owners%");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeeTable, 10);
                FastDriver.FileFees.AddFeeTable.PerformTableAction(4, "$0.00", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.buyercharge.FASetText("100.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.Sellercharge.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.buyercharge1.FASetText("100.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.sellercharge1.FASetText("10.00");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.FileFees.lenderAdjAmnt.FASetText("500.00");
                Keyboard.SendKeys(FAKeys.TabAway);

                string TPA = FastDriver.FileFees.SPA.GetAttribute("value");
                FastDriver.FileFees.ShowOnCD.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify TPA Charges on CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                string feeDescription = "Title Premium Adjustment";
                Support.AreEqual(feeDescription, FastDriver.ClosingDisclosure.SectionL08_Label.Text);
                Support.AreEqual(TPA, FastDriver.ClosingDisclosure.SectionL08_Amt.Text);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to 'Fee Entry' screen and deselect 'Show on CD Page 3?' checkbox";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.FileFees.ShowOnCD.FASetCheckbox(false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify TPA on CD screen after deselecting 'Show on CD Page 3?' checkbox from 'Fee Entry' screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("", FastDriver.ClosingDisclosure.SectionL08_Label.Text);
                Support.AreEqual("", FastDriver.ClosingDisclosure.SectionL08_Amt.Text);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_343579_TC_498799_NO_04

        #endregion CD Screen - 343579-Section L: Display Buyer Title Premium Adjustment

        #region 393374- CD Screen – Section L: Ability to display credits that are part of a Charge group as Individual Credits

        #region US_393374_TC_502617_NO_01

        [TestMethod, Description("VERIFY  FIRST, SECOND AND  THIRD PROPERTY TAX CHECK INSTANCE CREDITS ON EXPANDING CHARGE GROUP IN LINE L06")]
        public void US_393374_TC_502617_NO_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY  FIRST, SECOND AND  THIRD PROPERTY TAX CHECK INSTANCE CREDITS ON EXPANDING CHARGE GROUP IN LINE L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("237");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 5000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("5000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.New();
                Playback.Wait(1000);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.WaitCreation(FastDriver.PropertyTaxCheck.GABcode, 10);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", null, 6000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("6000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();
                FastDriver.PropertyTaxSummary.SwitchToContentFrame();
                FastDriver.PropertyTaxSummary.WaitCreation(FastDriver.PropertyTaxSummary.New, 10);
                FastDriver.PropertyTaxSummary.New.FAClick();
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.WaitCreation(FastDriver.PropertyTaxCheck.GABcode, 10);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", null, 7000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("7000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.L06_Expand.FAClick();
                Playback.Wait(500);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Amount from Associated Great Northern Mortgage Co.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionL06_Amt.Text);

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$13,000.00", FastDriver.ClosingDisclosure.SectionL07_Amt.Text);

                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Penalty Due from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL07a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionL07a_Amt.Text);

                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionL07SupL02_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Interest Due from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$7,000.00", FastDriver.ClosingDisclosure.SectionL07SupL02_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_393374_TC_502617_NO_01

        #region US_393374_TC_502620_NO_03

        [TestMethod, Description("VERIFY SECOND PROPERTY TAX CHECK INSTANCE CREDIT ON EXPANDING CHARGE GROUP IN LINE L06")]
        public void US_393374_TC_502620_NO_03()
        {
            try
            {
                Reports.TestDescription = "VERIFY SECOND PROPERTY TAX CHECK INSTANCE CREDIT ON EXPANDING CHARGE GROUP IN LINE L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("247");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.New();
                Playback.Wait(1000);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.WaitCreation(FastDriver.PropertyTaxCheck.GABcode, 10);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", null, 10000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("10000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Partial Payment Amt", null, 20000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("20000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.L06_Expand.FAClick();
                Playback.Wait(500);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Interest Due from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$10,000.00", FastDriver.ClosingDisclosure.SectionL06_Amt.Text);

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Partial Payment Amt from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$20,000.00", FastDriver.ClosingDisclosure.SectionL07_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_393374_TC_502620_NO_03

        #region US_393374_TC_502622_NO_04

        [TestMethod, Description("VERIFY FIRST PROPERTY TAX CHECK INSTANCE CREDIT WITH EDITED CHARGE DESCRIPTION AND EDITED PAYEE NAME ON EXPANDING CHARGE GROUP IN LINE L06")]
        public void US_393374_TC_502622_NO_04()
        {
            try
            {
                Reports.TestDescription = "VERIFY FIRST PROPERTY TAX CHECK INSTANCE CREDIT WITH EDITED CHARGE DESCRIPTION AND EDITED PAYEE NAME ON EXPANDING CHARGE GROUP IN LINE L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 6000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.Description, 5);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description2");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("6000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", null, 5000, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.Description, 5);
                FastDriver.PaymentDetailsDlg.Description.FASetText("Description1");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("Payee Name1");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("5000");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.L06_Expand.FAClick();
                Playback.Wait(500);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("Description1 from Payee Name1", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionL06_Amt.Text);

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("Description2", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionL07_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_393374_TC_502622_NO_04

        #region US_393374_TC_502623_NO_05

        [TestMethod, Description("VERIFY FIRST PROPERTY TAX CHECK INSTANCE CREDIT HAVING POC AMOUNT ON EXPANDING CHARE GROUP IN LINE L06")]
        public void US_393374_TC_502623_NO_05()
        {
            try
            {
                Reports.TestDescription = "VERIFY FIRST PROPERTY TAX CHECK INSTANCE CREDIT HAVING POC AMOUNT ON EXPANDING CHARE GROUP IN LINE L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Property Tax Check Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("248");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 5000.50, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("5000.50");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertyTaxCheck.SwitchToContentFrame();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", null, 6000.60, null, null, null, "");
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("6000.60");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.L06_Expand.FAClick();
                Playback.Wait(500);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Amount from Midwest Financial Group $5,000.50 P.O.C.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("Tax Installment: Penalty Due from Midwest Financial Group $6,000.60 P.O.C.", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_393374_TC_502623_NO_05

        #region US_393374_TC_502626_NO_06

        [TestMethod, Description("VERIFY REB CREDITS FOR SELLER, BUYER AND OTHERS ON EXPANDING CHARGE GROUP IN LINE L06")]
        public void US_393374_TC_502626_NO_06()
        {
            try
            {
                Reports.TestDescription = "VERIFY REB CREDITS FOR SELLER, BUYER AND OTHERS ON EXPANDING CHARGE GROUP IN LINE L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating REB Credits for seller";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("237");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Seller", 5000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating REB Credits for Buyer";
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.BuyerbrokerNew.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Buyer", 6000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating REB Credits for Others";
                Playback.Wait(5000);
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Other", 7000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.L06_Expand.FAClick();
                Playback.Wait(500);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("REB Buyer from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$6,000.00", FastDriver.ClosingDisclosure.SectionL06_Amt.Text);

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$12,000.00", FastDriver.ClosingDisclosure.SectionL07_Amt.Text);

                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text.Trim());
                Support.AreEqual("REB Other from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$7,000.00", FastDriver.ClosingDisclosure.SectionL07a_Amt.Text);

                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionL07SupL02_Seqno.Text.Trim());
                Support.AreEqual("REB Seller from Associated Great Northern Mortgage Co.", FastDriver.ClosingDisclosure.SectionL07SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$5,000.00", FastDriver.ClosingDisclosure.SectionL07SupL02_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_393374_TC_502626_NO_06

        #region US_393374_TC_502629_NO_07

        [TestMethod, Description("VERIFY REB CREDITS FOR SELLER ON EXPANDING CHARGE GROUP IN LINE L06")]
        public void US_393374_TC_502629_NO_07()
        {
            try
            {
                Reports.TestDescription = "VERIFY REB CREDITS FOR SELLER ON EXPANDING CHARGE GROUP IN LINE L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating REB Credits for seller";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Seller Credit 2", 20000, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Seller Credit 1", 10000, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.L06_Expand.FAClick();
                Playback.Wait(2000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("REB Seller Credit 1 from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$10,000.00", FastDriver.ClosingDisclosure.SectionL06_Amt.Text);

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("REB Seller Credit 2 from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$20,000.00", FastDriver.ClosingDisclosure.SectionL07_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing REB Credits for seller";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.FAClick();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Charge B");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.Click();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("12345678901.23");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription2.FASetText("Charge A");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.Click();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.FASetText("12345678901.23");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();
                Playback.Wait(2000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("Charge A from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionL06_Amt.Text);

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("Charge B from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionL07_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_393374_TC_502629_NO_07

        #region US_393374_TC_502632_NO_09

        [TestMethod, Description("VERIFY REB CREDITS FOR OTHERS ON EXPANDING CHARGE GROUP IN LINE L06")]
        public void US_393374_TC_502632_NO_09()
        {
            try
            {
                Reports.TestDescription = "VERIFY REB CREDITS FOR OTHERS ON EXPANDING CHARGE GROUP IN LINE L06";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating REB Credits for other";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("248");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Other Credit 2", 20000.00, null, null);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Other Credit 1", 10000.00, null, null);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();
                FastDriver.ClosingDisclosure.L06_Expand.FAClick();
                Playback.Wait(2000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("REB Other Credit 1 from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$10,000.00", FastDriver.ClosingDisclosure.SectionL06_Amt.Text);

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("REB Other Credit 2 from Midwest Financial Group", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$20,000.00", FastDriver.ClosingDisclosure.SectionL07_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Editing REB Credits for other";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgentSummary.WaitCreation(FastDriver.RealEstateBrokerAgentSummary.SummaryTable, 10);
                FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("dgdOtherREBroker_1_labelOtherName")).FAClick();
                //FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, "Midwest Financial Group", 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.EditOther.FAClick();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.Displayed)
                    FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("Other B");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.Click();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("12345678901.23");
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription2.FASetText("Other A");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.Click();
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit2.FASetText("12345678901.23");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validating the charges in Section L in CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                FastDriver.ClosingDisclosure.SectionL06_Seqno.FAClick();
                Playback.Wait(2000);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("Other A from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionL06_Amt.Text);

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("Other B from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$345,678,901.23", FastDriver.ClosingDisclosure.SectionL07_Amt.Text);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_393374_TC_502632_NO_09

        #endregion 393374- CD Screen – Section L: Ability to display credits that are part of a Charge group as Individual Credits

        #region USER STORY -363428 : ClosingDisclosure SCREEN - SECTION L: ENTER THE FIRST LOAN AMOUNT ON LINE L02.

        #region US_363428_ITE_16_TestCase_5

        [TestMethod, Description("USER STORY -363428:SECTION L: ENTER THE FIRST LOAN AMOUNT ON LINE L02.")]
        public void US_363428_ITE_16_TestCase_5()
        {
            try
            {
                Reports.TestDescription = "USER STORY -363428:SECTION L: ENTER THE FIRST LOAN AMOUNT ON LINE L02.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsLoanAmount, 10);
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify in the ClosingDisclosure screen.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("Loan Amount", FastDriver.ClosingDisclosure.SectionL02_Label.Text.Trim());
                Support.AreEqual("$1,200.00", FastDriver.ClosingDisclosure.SectionL02_Amt.Text);

                Reports.TestStep = "Verify $ sign.";
                bool verifyDollar = FastDriver.ClosingDisclosure.SectionL02_Amt.Text.Contains("$");

                if (verifyDollar)
                    Reports.StatusUpdate("DOLLAR IS PRESENT", true);
                else
                    Reports.StatusUpdate("VERIFIED THAT DOLLAR SYMBOL IS NOT PRESENT", false);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER MAX AMOUNT AND VERIFY $ SIGN AND DESCRIPTION.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsLoanAmount, 10);
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("12345678901.12");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Verify in the ClosingDisclosure screen.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("Loan Amount", FastDriver.ClosingDisclosure.SectionL02_Label.Text.Trim());
                Support.AreEqual("$345,678,901.12", FastDriver.ClosingDisclosure.SectionL02_Amt.Text);

                Reports.TestStep = "Verify $ sign.";
                verifyDollar = FastDriver.ClosingDisclosure.SectionL02_Amt.Text.Contains("$");

                if (verifyDollar)
                    Reports.StatusUpdate("DOLLAR IS PRESENT", true);
                else
                    Reports.StatusUpdate("VERIFIED THAT DOLLAR SYMBOL IS NOT PRESENT", false);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "DELETE AMOUNT AND VERIFY  DESCRIPTION.";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsLoanAmount, 10);
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("0");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Verify in the ClosingDisclosure screen.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("Loan Amount", FastDriver.ClosingDisclosure.SectionL02_Label.Text.Trim());

                Reports.TestStep = "Verify the Zero amount in Textbox.";
                Reports.StatusUpdate("Empty value is verified on ClosingDisclosure Screen", (FastDriver.ClosingDisclosure.SectionL02_Amt.Text == ""));
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_363428_ITE_16_TestCase_5

        #endregion USER STORY -363428 : ClosingDisclosure SCREEN - SECTION L: ENTER THE FIRST LOAN AMOUNT ON LINE L02.

        #region USER STORY -363421 : ClosingDisclosure SCREEN - SECTION L: VERIFY THE SELLER CREDIT AMOUNT ON LINE L.05.

        #region US_363421_ITE_16_TestCase_6

        [TestMethod, Description("USER STORY -363421 :SECTION L: VERIFY THE SELLER CREDIT AMOUNT ON LINE L.05.")]
        public void US_363421_ITE_16_TestCase_6()
        {
            try
            {
                Reports.TestDescription = "USER STORY -363421 :SECTION L: VERIFY THE SELLER CREDIT AMOUNT ON LINE L.05.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "ENTER THE BUYER CREDIT AMOUNT IN OFFSET SCREEN AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.WaitCreation(FastDriver.AdjustmentOffset.SellerCharge3, 10);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Seller Credit", null, null, 1245, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify after save in ClosingDisclosure screen.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("Seller Credit", FastDriver.ClosingDisclosure.SectionL05_Label.Text.Trim());
                Support.AreEqual("$1,245.00", FastDriver.ClosingDisclosure.SectionL05_Amt.Text);

                Reports.TestStep = "Verify $ sign in amount field.";
                bool verifyDollar = FastDriver.ClosingDisclosure.SectionL05_Amt.Text.Contains("$");

                if (verifyDollar)
                    Reports.StatusUpdate("DOLLAR IS PRESENT", true);
                else
                    Reports.StatusUpdate("VERIFIED THAT DOLLAR SYMBOL IS NOT PRESENT", false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER THE MAX BUYER CREDIT AMOUNT IN OFFSET SCREEN AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.WaitCreation(FastDriver.AdjustmentOffset.SellerCharge3, 10);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Seller Credit", null, null, 12345678901.33, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify after save in ClosingDisclosure screen.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("Seller Credit", FastDriver.ClosingDisclosure.SectionL05_Label.Text.Trim());
                Support.AreEqual("$345,678,901.33", FastDriver.ClosingDisclosure.SectionL05_Amt.Text);

                Reports.TestStep = "Verify $ sign in amount field.";
                verifyDollar = FastDriver.ClosingDisclosure.SectionL05_Amt.Text.Contains("$");

                if (verifyDollar)
                    Reports.StatusUpdate("DOLLAR IS PRESENT", true);
                else
                    Reports.StatusUpdate("VERIFIED THAT DOLLAR SYMBOL IS NOT PRESENT", false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER ZERO(0) BUYER CREDIT AMOUNT IN OFFSET SCREEN AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.WaitCreation(FastDriver.AdjustmentOffset.SellerCharge3, 10);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Seller Credit", null, null, 0, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify after save in ClosingDisclosure screen.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("Seller Credit", FastDriver.ClosingDisclosure.SectionL05_Label.Text.Trim());

                Reports.TestStep = "Verify the Zero amount in Textbox.";
                Reports.StatusUpdate("Empty value is verified on ClosingDisclosure Screen", (FastDriver.ClosingDisclosure.SectionL05_Amt.Text == ""));
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US_363421_ITE_16_TestCase_6

        #endregion USER STORY -363421 : ClosingDisclosure SCREEN - SECTION L: VERIFY THE SELLER CREDIT AMOUNT ON LINE L.05.

        #region 363432:CD SCREEN - SECTION L: DISPLAY EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO ON LINE L03.

        #region FEA_5_US_363432_TC_374741_01

        [TestMethod, Description("VERIFY EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO AMOUNT FROM SINGLE CHARGE DESCRIPTION ON LINE L.03")]
        public void FEA_5_US_363432_TC_374741_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO AMOUNT FROM SINGLE CHARGE DESCRIPTION ON LINE L.03";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.DetailsGABcode, 10);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 2500, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(500);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 10);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("*  Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.Text.Trim());
                Support.AreEqual("$2,500.00", FastDriver.ClosingDisclosure.SectionL03_Amt.Text);

                Reports.TestStep = "Verify $ sign.";
                bool verifyDollar = FastDriver.ClosingDisclosure.SectionL03_Amt.Text.Contains("$");

                if (verifyDollar)
                    Reports.StatusUpdate("DOLLAR IS PRESENT", true);
                else
                    Reports.StatusUpdate("VERIFIED THAT DOLLAR SYMBOL IS NOT PRESENT", false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER MAXIMUM BUYER CREDIT(11.2) AMOUNT IN TEXTBOX AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.ChargesTab, 10);
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 12345678901.12, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 10);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("*  Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.Text.Trim());
                Support.AreEqual("$345,678,901.12", FastDriver.ClosingDisclosure.SectionL03_Amt.Text);

                Reports.TestStep = "Verify $ sign.";
                verifyDollar = FastDriver.ClosingDisclosure.SectionL03_Amt.Text.Contains("$");

                if (verifyDollar)
                    Reports.StatusUpdate("DOLLAR IS PRESENT", true);
                else
                    Reports.StatusUpdate("VERIFIED THAT DOLLAR SYMBOL IS NOT PRESENT", false);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER ZERO AMOUNT IN TEXTBOX AND SAVE.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.ChargesTab, 10);
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 0, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 10);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.Text.Trim());
                Reports.StatusUpdate("Empty value is verified on ClosingDisclosure Screen", (FastDriver.ClosingDisclosure.SectionL03_Amt.Text == ""));
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_363432_TC_374741_01

        #region FEA_5_US_363432_TC_374744_02

        [TestMethod, Description("VERIFY THE EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO AMOUNT FROM MULTIPLE CHARGE DESCRIPTION in LINE L.03")]
        public void FEA_5_US_363432_TC_374744_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO AMOUNT FROM MULTIPLE CHARGE DESCRIPTION in LINE L.03";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.DetailsGABcode, 10);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 2500, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("*  Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.Text.Trim());
                Support.AreEqual("$2,500.00", FastDriver.ClosingDisclosure.SectionL03_Amt.Text);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.ChargesTab, 10);
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", null, null, 12345678901.12, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("*  Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.Text.Trim());
                Support.AreEqual("$345,681,401.12", FastDriver.ClosingDisclosure.SectionL03_Amt.Text);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.ChargesTab, 10);
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Late Charge", null, null, 3500.50, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("*  Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.Text.Trim());
                Support.AreEqual("$345,681,401.12", FastDriver.ClosingDisclosure.SectionL03_Amt.Text);
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_363432_TC_374744_02

        #region FEA_5_US_363432_TC_376468_03

        [TestMethod, Description("VERIFY THE EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO AMOUNT FROM MULTIPLE CHARGES FROM MULTIPLE INSTANCES.")]
        public void FEA_5_US_363432_TC_376468_03()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO AMOUNT FROM MULTIPLE CHARGES FROM MULTIPLE INSTANCES.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in 1st New Loan Charges";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.DetailsGABcode, 10);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 12345678901.12, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", null, null, 3500.12, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("*  Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.Text.Trim());
                Support.AreEqual("$345,678,901.12", FastDriver.ClosingDisclosure.SectionL03_Amt.Text);

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "ENTER THE  AMOUNT IN BUYER CREDIT  TEXTBOX IN  ASSUMPTION LOAN FOR SECOND INSTANCE.";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.BottomFrame.New();
                Playback.Wait(1000);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.DetailsGABcode, 10);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 12345678901.12, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", null, null, 3500.12, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("POC");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("*  Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.Text.Trim());
                Support.AreEqual("$691,357,802.24", FastDriver.ClosingDisclosure.SectionL03_Amt.Text);

                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_363432_TC_376468_03

        #endregion 363432:CD SCREEN - SECTION L: DISPLAY EXISTING LOAN(S) ASSUMED OR TAKEN SUBJECT TO ON LINE L03.

        #region 363805 : CD SCREEN - SECTION L: DISPLAY THE ASSUMPTION LOAN BUYER CREDITS AGGREGATED ON LINE L 03 IN A POPUP DIALOG BOX.

        #region FEA_5_US_363805_TC_385804_01

        [TestMethod, Description("VERIFY ASSUMPTION LOAN BUYER   FIRST AND SECOND INSTANCE CREDITS WITH AT CLOSING AND POC AMOUNTS IN LINE L03 POPUP.")]
        public void FEA_5_US_363805_TC_385804_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY ASSUMPTION LOAN BUYER   FIRST AND SECOND INSTANCE CREDITS WITH AT CLOSING AND POC AMOUNTS IN LINE L03 POPUP.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.DetailsGABcode, 10);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("314");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 250.50, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("250.50");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Edit charge description and payee name in Assumption Loan Screen";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", null, null, 0.99, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.Description, 5);
                FastDriver.PaymentDetailsDlg.Description.FASetText("ABCDEF");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("JDA SOFTWARE");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("0.99");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Creating Charges in 2nd instance  Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.BottomFrame.New();
                Playback.Wait(1000);
                FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
                FastDriver.AssumptionLoanDetails.WaitCreation(FastDriver.AssumptionLoanDetails.DetailsGABcode, 10);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("248");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 12345678901.12, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("12345678901.12");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", null, null, 101.01, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCredit, 5);
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("101.01");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Late Charge", null, null, 250.50, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.Description, 5);
                FastDriver.PaymentDetailsDlg.Description.FASetText("XYZA");
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(false);
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText("FIRST AMERICA");
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText("0.99");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(250);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to ClosingDisclosure screen and verify.";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                FastDriver.ClosingDisclosure.SectionL03_Seqno.FAClick();
                Support.AreEqual("True", FastDriver.ClosingDisclosure.L03Plus.Displayed.ToString());

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("*  Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.Text.Trim());
                Support.AreEqual("$345,679,254.61", FastDriver.ClosingDisclosure.SectionL03_Amt.Text);

                FastDriver.ClosingDisclosure.L03Plus.FAClick();

                Reports.TestStep = "Validating the L03 popup";

                Support.AreEqual("Buyer Credits", FastDriver.CDL03Popup.L03Label.Text);

                Support.AreEqual("03", FastDriver.CDL03Popup.L03SeqNo.Text.Trim());
                Support.AreEqual("Existing Loan(s) Assumed or Taken Subject to", FastDriver.CDL03Popup.L03Description.Text.Trim());
                Support.AreEqual("$345,679,254.61", FastDriver.CDL03Popup.L03Amt.Text);

                Support.AreEqual("a", FastDriver.CDL03Popup.L03SeqNo1.Text.Trim());
                Support.AreEqual("Assumption Loan 1 Credits", FastDriver.CDL03Popup.L03ChargeDesc1.Text.Trim());
                Support.AreEqual("$251.49", FastDriver.CDL03Popup.L03TotalChargeAmt1.Text);

                Support.AreEqual("Statement/Forwarding Fee from Smythe & Lee Jerome E. Lee", FastDriver.CDL03Popup.L03ChargeDesc2.Text.Trim());
                Support.AreEqual("$250.50", FastDriver.CDL03Popup.L03ChargeAmt2.Text);

                Support.AreEqual("ABCDEF from JDA SOFTWARE", FastDriver.CDL03Popup.L03ChargeDesc3.Text.Trim());
                Support.AreEqual("$0.99", FastDriver.CDL03Popup.L03ChargeAmt3.Text);

                Support.AreEqual("b", FastDriver.CDL03Popup.L03SeqNo4.Text.Trim());
                Support.AreEqual("Assumption Loan 2 Credits", FastDriver.CDL03Popup.L03ChargeDesc4.Text.Trim());
                Support.AreEqual("$345,679,003.12", FastDriver.CDL03Popup.L03TotalChargeAmt4.Text);

                Support.AreEqual("Statement/Forwarding Fee from Midwest Financial Group", FastDriver.CDL03Popup.L03ChargeDesc5.Text.Trim());
                Support.AreEqual("$345,678,901.12", FastDriver.CDL03Popup.L03ChargeAmt5.Text);

                Support.AreEqual("Document Fee from Midwest Financial Group", FastDriver.CDL03Popup.L03ChargeDesc6.Text.Trim());
                Support.AreEqual("$101.01", FastDriver.CDL03Popup.L03ChargeAmt6.Text);

                Support.AreEqual("XYZA from FIRST AMERICA", FastDriver.CDL03Popup.L03ChargeDesc7.Text.Trim());
                Support.AreEqual("$0.99", FastDriver.CDL03Popup.L03ChargeAmt7.Text);

                FastDriver.CDL03Popup.Done.FAClick();
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion FEA_5_US_363805_TC_385804_01

        #endregion 363805 : CD SCREEN - SECTION L: DISPLAY THE ASSUMPTION LOAN BUYER CREDITS AGGREGATED ON LINE L 03 IN A POPUP DIALOG BOX.

        #region USERSTORY 370050 CD Screen - Section L: City/Town Taxes

        #region USERSTORY 370050_TESTCASE_374155_SCENARIO1: - CD Screen - Sec  L Verify display of Line 12 when no data entered for City/Town Taxes in Proration Tax screen.

        [TestMethod, Description("USERSTORY – 370050_TESTCASE_374155_SCENARIO_1- Verify display of Line 12 when no data entered for City/Town Taxes in Proration Tax screen.")]
        public void FTR5_ITR20_US_370050_TC_374155_SC1()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370050_TESTCASE_374155_SCENARIO_1- Verify display of Line 12 when no data entered for City/Town Taxes in Proration Tax screen.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "VERIFY DEFAULT LABELS IN A LINE WHEN A REQUIRED CHARGE DOES NOT EXISTS FOR A SECTION";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.L, 12, "City/Town Taxes", "", "", "");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370050_TESTCASE_374156_SCENARIO2: CD Screen - Sec  L Verify display of Line 12 when valid required data is entered for City/Town Taxes in Proration Tax screen.

        [TestMethod, Description("USERSTORY – 370050_TESTCASE_374156_SCENARIO_2- Sec  L Verify display of Line 12 when valid required data is entered for City/Town Taxes in Proration Tax screen")]
        public void FTR5_ITR20_US_370050_TC_374156_SC2()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370050_TESTCASE_374156_SCENARIO_2- Sec  L Verify display of Line 12 when valid required data is entered for City/Town Taxes in Proration Tax screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "ENTER PRORATION DATA";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "10/21/2014", "10/21/2015", "200.00", false);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verify data Charge available";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.L, 12, "City/Town Taxes", "10/21/14", "10/21/15", GetCharge);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370050_TESTCASE_374164_SCENARIO10: CD Screen - Sec  L Verify display format of charge amount in Line 12.

        [TestMethod, Description("USERSTORY – 370050_TESTCASE_374164_SCENARIO_10 - Sec  L Verify display format of charge amount in Line 12.")]
        public void FTR5_ITR20_US_370050_TC_374164_SC10()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370050_TESTCASE_374164_SCENARIO_10 - Sec  L Verify display format of charge amount in Line 12.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "ENTER PRORATION DATA";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "10/21/2014", "10/21/2015", "99999999999", false);
                GetCharge = GetCharge.Substring(3);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verify data Charge available";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.L, 12, "City/Town Taxes", "10/21/14", "10/21/15", GetCharge);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370050_TESTCASE_374165_SCENARIO11: CD Screen - Sec  L Verify display of Line 12 When Proration City/Town Taxes added is removed.

        [TestMethod, Description("USERSTORY – 370050_TESTCASE_374165_SCENARIO_11 - Sec  L Verify display of Line 12 When Proration City/Town Taxes added is removed.")]
        public void FTR5_ITR20_US_370050_TC_374165_SC11()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370050_TESTCASE_374165_SCENARIO_11 - Sec  L Verify display of Line 12 When Proration City/Town Taxes added is removed.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "ENTER PRORATION DATA";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "10/21/2014", "10/21/2015", "200", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").SwitchToContentFrame();
                FastDriver.ProrationTax.CityCell.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verify data Charge available";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.L, 12, "City/Town Taxes", "", "", "");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion USERSTORY 370050 CD Screen - Section L: City/Town Taxes

        #region USERSTORY 370055 CD Screen - Section L: County Taxes

        #region USERSTORY 370055 _TESTCASE_374167_SCENARIO1: - CD Screen - Sec L: Verify display of Line 13 when no data entered for County Taxes in Proration Tax screen.

        [TestMethod, Description("USERSTORY – 370055 _TESTCASE_374167_SCENARIO_1- Verify display of Line 13 when no data entered for County Taxes in Proration Tax screen.")]
        public void FTR5_ITR20_US_370055_TC_374167_SC1()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370055 _TESTCASE_374167_SCENARIO_1- Verify display of Line 13 when no data entered for County Taxes in Proration Tax screen.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "VERIFY DEFAULT LABELS IN A LINE WHEN A REQUIRED CHARGE DOES NOT EXISTS FOR A SECTION";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.L, 13, "County Taxes", "", "", "");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370055 _TESTCASE_374168_SCENARIO2: CD Screen - Sec L: Verify display of Line 13 when valid required data is entered for County Taxes in Proration Tax screen.

        [TestMethod, Description("USERSTORY – 370055 _TESTCASE_374168_SCENARIO_2- Sec L: Verify display of Line 13 when valid required data is entered for County Taxes in Proration Tax screen")]
        public void FTR5_ITR20_US_370055_TC_374168_SC2()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370055 _TESTCASE_374168_SCENARIO_2- Sec L: Verify display of Line 13 when valid required data is entered for County Taxes in Proration Tax screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter proration data";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/21/2014", "10/21/2015", "200", false);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "VERIFY DEFAULT LABELS IN A LINE WHEN A REQUIRED CHARGE DOES NOT EXISTS FOR A SECTION";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.L, 13, "County Taxes", "10/21/14", "10/21/15", GetCharge);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370055 _TESTCASE_374176_SCENARIO10: CD Screen - Sec L: Verify display format of charge amount in Line 09.

        [TestMethod, Description("USERSTORY – 370055 _TESTCASE_374176_SCENARIO_10 - Sec L: Verify display format of charge amount in Line 09.")]
        public void FTR5_ITR20_US_370055_TC_374176_SC10()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370055 _TESTCASE_374176_SCENARIO_10 - Sec L: Verify display format of charge amount in Line 09.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter proration data";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Tax", "10/21/2014", "10/21/2015", "99,999,999,999.00", false);
                Debug.Print(GetCharge);
                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "VERIFY DEFAULT LABELS IN A LINE WHEN A REQUIRED CHARGE DOES NOT EXISTS FOR A SECTION";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.L, 13, "County Taxes", "10/21/14", "10/21/15", GetCharge);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370055_TESTCASE_374177_SCENARIO11: CD Screen - Sec L: Verify display of Line 13 When Proration County Taxes added is removed.

        [TestMethod, Description("USERSTORY – 370055 _TESTCASE_374177_SCENARIO_11 - Sec L: Verify display of Line 13 When Proration County Taxes added is removed.")]
        public void FTR5_ITR20_US_370055_TC_374177_SC11()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370055 _TESTCASE_374177_SCENARIO_11 - Sec L: Verify display of Line 13 When Proration County Taxes added is removed.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter proration data";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/21/2014", "10/21/2015", "200", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ProrationTax.CountyCell.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "VERIFY DEFAULT LABELS IN A LINE WHEN A REQUIRED CHARGE DOES NOT EXISTS FOR A SECTION";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.L, 13, "County Taxes", "", "", "");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion USERSTORY 370055 CD Screen - Section L: County Taxes

        #region USERSTORY 370058 CD Screen - Section L: Assessments

        #region USERSTORY 370058_TESTCASE_374134_SCENARIO1: - CD Screen - Sec L: Verify display of Line 14 when no data entered for Assessments in Proration Tax screen.

        [TestMethod, Description("USERSTORY – 370058_TESTCASE_374134_SCENARIO_1- Verify display of Line 14 when no data entered for Assessments in Proration Tax screen.")]
        public void FTR5_ITR20_US_370058_TC_374134_SC1()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370058_TESTCASE_374134_SCENARIO_1- Verify display of Line 14 when no data entered for Assessments in Proration Tax screen.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "VERIFY DEFAULT LABELS IN A LINE WHEN A REQUIRED CHARGE DOES NOT EXISTS FOR A SECTION";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.L, 14, "Assessments", "", "", "");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370058_TESTCASE_374136_SCENARIO2: CD Screen - Sec L: Verify display of Line 14 when valid required data is entered for Assessments in Proration Tax screen.

        [TestMethod, Description("USERSTORY – 370058_TESTCASE_374136_SCENARIO_2- Sec L: Verify display of Line 14 when valid required data is entered for Assessments in Proration Tax screen")]
        public void FTR5_ITR20_US_370058_TC_374136_SC2()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370058_TESTCASE_374136_SCENARIO_2- Sec L: Verify display of Line 14 when valid required data is entered for Assessments in Proration Tax screen";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Setting Proration Tax data";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "10/21/2014", "10/21/2015", "200.00", false);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "VERIFY DEFAULT LABELS IN A LINE WHEN A REQUIRED CHARGE DOES NOT EXISTS FOR A SECTION";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.L, 14, "Assessments", "10/21/14", "10/21/15", GetCharge);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370058_TESTCASE_374150_SCENARIO10: CD Screen - Sec L: Verify display format of charge amount in Line 09.

        [TestMethod, Description("USERSTORY – 370058_TESTCASE_374150_SCENARIO_10 - Sec L: Verify display format of charge amount in Line 09.")]
        public void FTR5_ITR20_US_370058_TC_374150_SC10()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370058_TESTCASE_374150_SCENARIO_10 - Sec L: Verify display format of charge amount in Line 09.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string GetCharge = string.Empty;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Setting Proration Tax data";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "10/21/2014", "10/21/2015", "99,999,999,999.00", false);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "VERIFY DEFAULT LABELS IN A LINE WHEN A REQUIRED CHARGE DOES NOT EXISTS FOR A SECTION";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection.L, 14, "Assessments", "10/21/14", "10/21/15", GetCharge);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 370058_TESTCASE_374151_SCENARIO11: CD Screen - Sec L: Verify display of Line 14 When Proration Assessments added is removed.

        [TestMethod, Description("USERSTORY – 370058_TESTCASE_374151_SCENARIO_11 - Sec L: Verify display of Line 14 When Proration Assessments added is removed.")]
        public void FTR5_ITR20_US_370058_TC_374151_SC11()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370058_TESTCASE_374151_SCENARIO_11 - Sec L: Verify display of Line 14 When Proration Assessments added is removed.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Setting Proration Tax data";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "10/21/2014", "10/21/2015", "200", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ProrationTax.AssesmentCell.FAClick();
                FastDriver.ProrationTax.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "VERIFY DEFAULT LABELS IN A LINE WHEN A REQUIRED CHARGE DOES NOT EXISTS FOR A SECTION";
                FastDriver.ClosingDisclosure.VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection.L, 14, "Assessments", "", "", "");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion USERSTORY 370058 CD Screen - Section L: Assessments

        #region USERSTORY 393783 CD Screen – Section L: Provide ability to edit the Charge Description on lines L06 to L17

        #region USERSTORY 393783_TESTCASE_443534_SCENARIO1 - Section L: Verify the Credit description in lines L06 and L07  are editable when Edit description is enabled at ADM.

        [TestMethod, Description("TO VERIFY L06 L07 INDIVIDUAL CREDITS ARE EDITABLE")]
        public void FTR5_ITR48_US_393783_TC_443534_SC1()
        {
            try
            {
                Reports.TestDescription = "USERSTORY – 370058_TESTCASE_374151_SCENARIO_11 - Sec L: Verify display of Line 14 When Proration Assessments added is removed.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };

                string EditDescinCDL6 = string.Empty;
                string EditDescinCDL7 = string.Empty;
                bool flag = false;
                string SSDescL6 = "Tax Installment: Amount";
                string SSDescL7 = "REB Credit";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Property Tax Check and Add GAB";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("188");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                Reports.TestStep = "Add BuyerCredit in Property Tax Check screen";
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable(SSDescL6, null, 300.09, null, null, null, "");

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verify L06 line number and credit description";
                var SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl_transSummary_OtherCreditsL"));
                if (SecLTable2.GetColumnCount() > 0)
                {
                    Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text);
                    Support.AreEqual("Tax Installment: Amount from Mblo Funding, Inc.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());

                    Reports.TestStep = "Verify credit description shown in L06 is editable";
                    var inputElement = FastDriver.ClosingDisclosure.SectionL06_Label;
                    Support.AreEqual("True", inputElement.Enabled.ToString().Trim());

                    Reports.TestStep = "Edit Charge description with max length";
                    EditDescinCDL6 = inputElement.Text.Substring(0, 4) + "12345678901234567890123456789012345678901";
                    var clearInput = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
                    clearInput.Clear();
                    clearInput.FASetText(EditDescinCDL6);
                    Debug.Print(EditDescinCDL6);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verify Description edited in CD L06 is saved";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL06_Label.Text.Trim().Contains(EditDescinCDL6).ToString());

                Reports.TestStep = "Verify Description edited in CD is reflected in source screen - Property Tax Check";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                flag = FindTheFeeChargePulled(FastDriver.PropertyTaxCheck.PropertyTaxesTable, EditDescinCDL6, null, null, null, null, null, "");

                if (flag)
                    Support.AreEqual("Tax 12345678901234567890123456789012345678901", EditDescinCDL6.Trim(), "Description edited in CD is reflected in Source screen");
                else
                    Support.AreEqual("Tax 12345678901234567890123456789012345678901", EditDescinCDL6.Trim(), "Description edited in CD is not reflected in Source screen");

                Reports.TestStep = "Navigate to REB screen - Add GAB REBBroker Credits, Commission Amount";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits(SSDescL7, 0.750, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verify L07 line number and credit description";
                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl_transSummary_OtherCreditsL"));
                if (SecLTable2.GetColumnCount() > 0)
                {
                    Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text);
                    Support.AreEqual("REB Credit from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());

                    Reports.TestStep = "Verify credit description shown in L06 is editable";
                    var inputElement = FastDriver.ClosingDisclosure.SectionL07_Label;
                    Support.AreEqual("True", inputElement.Enabled.ToString().Trim());

                    Reports.TestStep = "Edit Charge description with max length";
                    EditDescinCDL7 = inputElement.Text.Substring(0, 4) + "12345678901234567890123456789012345678901";
                    var clearInput = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("REB") && i.Displayed);
                    clearInput.Clear();
                    clearInput.FASetText(EditDescinCDL7);
                    Debug.Print(EditDescinCDL7);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verify Description edited in CD L07 is saved";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.SectionL07_Label.Text.Trim().Contains(EditDescinCDL7).ToString());

                Reports.TestStep = "Verify Description edited in CD is reflected in source screen - REB";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                Playback.Wait(500);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                flag = FindTheFeeChargePulled(FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable, EditDescinCDL7, null, null, null, null, null, "");

                if (flag)
                    Support.AreEqual("REB 12345678901234567890123456789012345678901", EditDescinCDL7.Trim(), "Description edited in CD is reflected in Source screen");
                else
                    Support.AreEqual("REB 12345678901234567890123456789012345678901", EditDescinCDL7.Trim(), "Description edited in CD is not reflected in Source screen");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 393783_TESTCASE_443537_SCENARIO4 - Section L: Edit the descriptions in section L (Individual Credits)  with maximum length and verify the same is shown in source screen and in PDD.

        [TestMethod, Description("393787_TESTCASE_443528_SCENARIO4 - Section L: Edit the descriptions for L06 to L17 (Individual Credits)  with maximum length and verify the same is shown in source and PDD.")]
        public void FTR5_ITR48_US_393783_TC_443537_SC4()
        {
            try
            {
                Reports.TestDescription = "393787_TESTCASE_443528_SCENARIO4 - Section L: Edit the descriptions for L06 to L17 (Individual Credits)  with maximum length and verify the same is shown in source and PDD.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                string EditDescinCDL6 = "";
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Entering Assumption Loan data";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("182");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 2.00, null, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Verify L06 line number and credit description";
                var SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl_transSummary_OtherCreditsL"));
                if (SecLTable2.GetColumnCount() > 0)
                {
                    Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text);
                    Support.AreEqual("Assumption Transfer Fee  from Block & Landsman", FastDriver.ClosingDisclosure.SectionL06_Label.Text.Trim());

                    Reports.TestStep = "Verify credit description shown in L06 is editable";
                    var inputElement = FastDriver.ClosingDisclosure.SectionL06_Label;
                    Support.AreEqual("True", inputElement.Enabled.ToString().Trim());

                    Reports.TestStep = "Edit Charge description with max length";
                    EditDescinCDL6 = inputElement.Text.Substring(0, 4) + "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345";
                    var clearInput = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
                    clearInput.Clear();
                    clearInput.FASetText(EditDescinCDL6);
                }

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Description edited in CD M03 is saved";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);
                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl_transSummary_OtherCreditsL"));
                var editableElement = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
                Support.AreEqual("True", editableElement.GetAttribute("title").Trim().Contains(EditDescinCDL6.Substring(0, 59)).ToString());

                Reports.TestStep = "Verify Description edited in CD is reflected in source screen - Assumption Loan";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable(EditDescinCDL6.Substring(0, 59), null, null, 2.00, null, null, null);

                Reports.TestStep = "Verify Description edited in CD is reflected in PDD screen - Assumption Loan";
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                Playback.Wait(2000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.Description, 5);
                FastDriver.PaymentDetailsDlg.Description.Click();
                Keyboard.SendKeys("^C");
                string descriptionValue = System.Windows.Forms.Clipboard.GetText(TextDataFormat.UnicodeText);
                Debug.Print(descriptionValue);
                Support.AreEqual(EditDescinCDL6.Substring(0, 59), descriptionValue);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(2000);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 393783_TESTCASE_443542_SCENARIO9 - CD Section L: Verify the system behavior when Charge Description is edited with a blank value.

        [TestMethod, Description("USERSTORY 393787_TESTCASE_443533_SCENARIO9 - Section L: Verify the system behavior when Charge Description is edited with a blank value.")]
        public void FTR5_ITR48_US_393783_TC_443542_SC9()
        {
            try
            {
                Reports.TestDescription = "USERSTORY 393787_TESTCASE_443533_SCENARIO9 - Section L: Verify the system behavior when Charge Description is edited with a blank value.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Entering Assumption Loan data";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("182");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 2.00, null, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Edit charge descripton in CD section L with blank value ";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                var SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl_transSummary_OtherCreditsL"));
                if (SecLTable2.GetColumnCount() > 0)
                {
                    Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text);
                    var editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
                    Support.AreEqual("Assumption Transfer Fee", editableControl.Text.Trim());
                    Debug.Print(editableControl.Text.Trim());

                    Reports.TestStep = "When edited description is blank, Verify message shown with Ok button";
                    editableControl.Clear();
                    editableControl.Clear();
                    Keyboard.SendKeys(FAKeys.TabAway);
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    FastDriver.ClosingDisclosure.SwitchToContentFrame();
                    Support.AreEqual("Assumption Transfer Fee", editableControl.Text.Trim());
                }

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 393783_TESTCASE_518417_SCENARIO9 - Section L: Verify the credit description in L07, L07a ...L07n are editable in supplemental section

        [TestMethod, Description("TO VERIFY L07a, L07b IN CD are EDITABLE")]
        public void FTR5_ITR48_US_393783_TC_518417_SC9()
        {
            try
            {
                Reports.TestDescription = "TO VERIFY L07a, L07b IN CD are EDITABLE";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                bool flag = false;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Property Tax Check and Add GAB";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.PropertyTaxCheck.WaitCreation(FastDriver.PropertyTaxCheck.GABcode, 5);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("188");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                Reports.TestStep = "Add BuyerCredit in Property Tax Check screen";
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 300.09, null, null, null, "");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to REB screen - Add GAB REBBroker Credits, Commission Amount";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgentSummary.WaitCreation(FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit, 5);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                Playback.Wait(1000);
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.CommissionAmount, 5);
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Credit", 0.750, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Entering Assumption Loan data";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("182");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 2.00, null, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Verify L07a line number and credit description";
                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text);
                Support.AreEqual("REB Credit from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL07a_Label.GetAttribute("Title").ToString().Trim());
                var SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl_transSummary_OtherCreditsL"));
                var editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("REB Credit") && i.Displayed);
                Reports.StatusUpdate("REB Credit" + " in " + FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text + " is Editable in CD", true);
                string editedDescSection07a = editableControl.Text.Substring(0, 4) + "12345678901234567890123456789012345678901";

                Reports.TestStep = "Edit Charge description";
                editableControl.Clear();
                editableControl.Clear();
                editableControl.FASetText(editedDescSection07a);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Description edited in CD L07a is saved";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl_transSummary_OtherCreditsL"));
                var editableControl2 = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("REB") && i.Displayed);
                Support.AreEqual(editedDescSection07a, editableControl2.GetAttribute("Title").ToString().Trim());

                Reports.TestStep = "Verify Description edited in CD is reflected in source screen - REB";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.RealEstateBrokerAgentSummary.WaitCreation(FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit, 5);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                var element = FastDriver.RealEstateBrokerAgent.RealEstateBrokerCreditsTable.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("value").Contains("REB") && input.Displayed);
                flag = element.Displayed;
                if (flag)
                    Support.AreEqual(editedDescSection07a, element.GetAttribute("value").ToString().Trim(), "Description edited in CD L07a  is reflected in Source screen");
                else
                    Support.AreEqual(editedDescSection07a, element.GetAttribute("value").ToString().Trim(), "Description edited in CD L07a is not reflected in Source screen");

                Reports.TestStep = "Verify L07b line number and credit description";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionL07SupL02_Seqno.Text);
                Support.AreEqual("Assumption Transfer Fee from Block & Landsman", FastDriver.ClosingDisclosure.SectionL07SupL02_Label.GetAttribute("Title").ToString().Trim());
                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl_transSummary_OtherCreditsL"));
                editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Assumption") && i.Displayed);
                Reports.StatusUpdate("Assumption Transfer Fee from Block & Landsman" + " in " + FastDriver.ClosingDisclosure.SectionL07SupL02_Seqno.Text + " is Editable in CD", true);
                string editedDescSection07b = editableControl.Text.Substring(0, 4) + "12345678901234567890123456789012345678901";

                Reports.TestStep = "Edit Charge description";
                editableControl.Clear();
                editableControl.Clear();
                editableControl.FASetText(editedDescSection07b);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify Description edited in CD L07b is saved";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl_transSummary_OtherCreditsL"));
                editableControl2 = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Assu") && i.Displayed);
                Support.AreEqual(editedDescSection07b, editableControl2.GetAttribute("Title").ToString().Trim());

                Reports.TestStep = "Verify Description edited in CD is reflected in source screen - Assumption - Loan Charges tab";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                element = FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("value").Contains("Assu") && input.Displayed);
                flag = element.Displayed;
                if (flag)
                    Support.AreEqual(editedDescSection07b, element.GetAttribute("value").ToString().Trim(), "Description edited in CD L07b  is reflected in Source screen");
                else
                    Support.AreEqual(editedDescSection07b, element.GetAttribute("value").ToString().Trim(), "Description edited in CD L07b is not reflected in Source screen");

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region USERSTORY 393783_TESTCASE_518418_SCENARIO10 - Section L: Adjustments section: Verfiy Charge descriptions L08, L09, L10 and L11 are editable.

        [TestMethod, Description("TO VERIFY L08, L09, L10, L11 IN CD are EDITABLE")]
        public void FTR5_ITR48_US_393783_TC_518418_SC10()
        {
            try
            {
                Reports.TestDescription = "TO VERIFY L08, L09, L10, L11 IN CD are EDITABLE";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                bool flag = false;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Setting Buyer Credit  in Adjustment Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.AdjustmentOffset.WaitCreation(FastDriver.AdjustmentOffset.SellerCharge3, 10);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Lease/Rent", null, null, 20.2, null, null);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Security Deposit", null, null, 30.5, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Setting Buyer Credit in Adjustment Miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.AdjustmentMisc.UpdateMiscCharges("Buyer Deposit Directly to Seller", null, null, 40.53, null, null);
                FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", null, null, 50.64, null, null);
                var iba = FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.FindElements(By.TagName("input")).FirstOrDefault(i => i.GetAttribute("value").Contains("IBA") && i.Displayed);
                if (iba.Enabled)
                    flag = true;
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Verify lines in Adjustments table of section L are editable.";
                //SectionL08
                Support.AreEqual("08", FastDriver.ClosingDisclosure.SectionL08_Seqno.Text);
                Support.AreEqual("Assign Tenant Lease/Rent", FastDriver.ClosingDisclosure.SectionL08_Label.GetAttribute("Title").ToString().Trim());
                var SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl-transSummary-Adjustments_L"));
                var editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Lease") && i.Displayed);
                Reports.StatusUpdate("Assign Tenant Lease/Rent" + " in " + FastDriver.ClosingDisclosure.SectionL08_Seqno.Text + " is Editable in CD", true);
                string editedDescSection08 = editableControl.Text.Substring(0, 4) + "12345678901234567890123456789012345678901";
                editableControl.Clear();
                editableControl.Clear();
                editableControl.FASetText(editedDescSection08);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl-transSummary-Adjustments_L"));
                editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Assi") && i.Displayed);
                Support.AreEqual(editedDescSection08, editableControl.GetAttribute("Title").ToString().Trim());

                //SectionL09
                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionL09_Seqno.Text);
                Support.AreEqual("Assign Tenant Security Deposit", FastDriver.ClosingDisclosure.SectionL09_Label.GetAttribute("Title").ToString().Trim());
                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl-transSummary-Adjustments_L"));
                editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Security") && i.Displayed);
                Reports.StatusUpdate("Assign Tenant Security Deposit" + " in " + FastDriver.ClosingDisclosure.SectionL09_Seqno.Text + " is Editable in CD", true);
                var editedDescSection09 = "1" + editableControl.Text.Substring(0, 4) + "12345678901234567890123456789012345678901";
                editableControl.Clear();
                editableControl.Clear();
                editableControl.FASetText(editedDescSection09);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl-transSummary-Adjustments_L"));
                editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("1Assi") && i.Displayed);
                Support.AreEqual(editedDescSection09, editableControl.GetAttribute("Title").ToString().Trim());

                //SectionL10
                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionL10_Seqno.Text);
                Support.AreEqual("Buyer Deposit Directly to Seller", FastDriver.ClosingDisclosure.SectionL10_Label.GetAttribute("Title").ToString().Trim());
                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl-transSummary-Adjustments_L"));
                editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Buyer") && i.Displayed);
                Reports.StatusUpdate("Buyer Deposit Directly to Seller" + " in " + FastDriver.ClosingDisclosure.SectionL10_Seqno.Text + " is Editable in CD", true);
                var editedDescSection10 = editableControl.Text.Substring(0, 4) + "12345678901234567890123456789012345678901";
                editableControl.Clear();
                editableControl.Clear();
                editableControl.FASetText(editedDescSection10);
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl-transSummary-Adjustments_L"));
                editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Buye") && i.Displayed);
                Support.AreEqual(editedDescSection10, editableControl.GetAttribute("Title").ToString().Trim());

                //SectionL11
                if (flag)
                {
                    Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionL11_Seqno.Text);
                    Support.AreEqual("Buyer Deposit Directly to Seller", FastDriver.ClosingDisclosure.SectionL11_Label.GetAttribute("Title").ToString().Trim());
                    SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl-transSummary-Adjustments_L"));
                    editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Buyer") && i.Displayed);
                    Reports.StatusUpdate("Buyer Deposit Directly to Seller" + " in " + FastDriver.ClosingDisclosure.SectionL11_Seqno.Text + " is Editable in CD", true);
                    var editedDescSection11 = editableControl.Text.Substring(0, 4) + "12345678901234567890123456789012345678901";
                    editableControl.Clear();
                    editableControl.Clear();
                    editableControl.FASetText(editedDescSection11);
                    FastDriver.BottomFrame.Done();

                    FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                    Playback.Wait(2000);
                    FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                    Playback.Wait(3000);

                    SecLTable2 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl-transSummary-Adjustments_L"));
                    editableControl = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Buye") && i.Displayed);
                    Support.AreEqual(editedDescSection11, editableControl.GetAttribute("Title").ToString().Trim());
                }

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #endregion

        #region USERSTORY 393783_TESTCASE_518419_SCENARIO11 - Section L: Verify the credit descriptions on lines L12 to L17 are editable.

        [TestMethod, Description("Section L: Verify the credit descriptions on lines L12 to L17 are editable.")]
        public void FTR5_ITR48_US_393783_TC_518419_SC11()
        {
            try
            {
                Reports.TestDescription = "Section L: Verify the credit descriptions on lines L12 to L17 are editable.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                //bool flag = false;
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                FixedLinesData_Adj_dataentry("L");
                Playback.Wait(1000);

                Reports.TestStep = "Setting Buyer Credit  in Adjustment Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments").SwitchToContentFrame();
                Playback.Wait(2000);

                DynamicLines_Adj_dataentry("L");

                Reports.TestStep = "Expand Summaries Of Trans";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(3000);

                Reports.TestStep = "Verify content editable on CD screen";
                var SecLTable4 = FastDriver.WebDriver.FindElement(OpenQA.Selenium.By.Id("tbl-transSummary-AdjforItems_L"));
                string editedDescSectionL;
                System.Collections.Generic.List<string> descEditedInCD = new System.Collections.Generic.List<string>();
                var editableControl = SecLTable4.FindElements(By.CssSelector("span[contenteditable]"));
                int j = 0;

                foreach (var item in editableControl)
                {
                    editedDescSectionL = editableControl[j].Text.Substring(0, 4) + "12345678901234567890123456789012345678901";
                    descEditedInCD.Add(editedDescSectionL);
                    editableControl[j].Clear();
                    editableControl[j].Clear();
                    editableControl[j].FASetText(editedDescSectionL);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    j++;
                }

                foreach (var item in descEditedInCD)
                {
                    Debug.Print(item);
                }

                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);

                //wind
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(1000);
                FastDriver.InsuranceWind.SwitchToContentFrame();
                Support.AreEqual(descEditedInCD.ElementAt(0), FastDriver.InsuranceWind.WindDescription.GetAttribute("value").ToString().Trim());

                //flood
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(1000);
                FastDriver.Insuranceflood.SwitchToContentFrame();
                Support.AreEqual(descEditedInCD.ElementAt(1), FastDriver.Insuranceflood.FloodDescription.GetAttribute("value").ToString().Trim());

                //fire
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(1000);
                FastDriver.InsuranceFire.SwitchToContentFrame();
                Support.AreEqual(descEditedInCD.ElementAt(2), FastDriver.InsuranceFire.FireDescription.GetAttribute("value").ToString().Trim());

                //earth
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                Playback.Wait(1000);
                FastDriver.InsuranceEarth.SwitchToContentFrame();
                Support.AreEqual(descEditedInCD.ElementAt(3), FastDriver.InsuranceEarth.EarthCalculateDescription.GetAttribute("value").ToString().Trim());

                //HOA
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Playback.Wait(2000);
                Support.AreEqual(descEditedInCD.ElementAt(4), FastDriver.HomeownerAssociation.ProrationDescription.GetAttribute("value").ToString().Trim());

                //rent
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ProrationTax.ProrationTaxTable2.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                Playback.Wait(1000);
                FastDriver.ProrationDetail.SwitchToContentFrame();
                Support.AreEqual(descEditedInCD.ElementAt(5), FastDriver.ProrationDetail.Description.GetAttribute("value").ToString().Trim());

                //utility
                FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
                Playback.Wait(2000);
                Support.AreEqual(descEditedInCD.ElementAt(6), FastDriver.UtilityDetail.ProrationDescription.GetAttribute("value").ToString().Trim());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion USERSTORY 393783 CD Screen – Section L: Provide ability to edit the Charge Description on lines L06 to L17

        #region USERSTORY 213051_TESTCASE_431781_SCENARIO1 - Section L : To verify total amount when Buyer Charge amount is available from L1 to L17 and Charge payment method is either POC or other than POC.

        [TestMethod, Description("USERSTORY 213051_TESTCASE_431781_SCENARIO1:To verify total amount when Buyer Charge amount is available from L1 to L17 and Charge payment method is either POC or other than POC.")]
        public void FTR5_ITR34_US_213051_TC_431781_SC1()//PerformTableAction method not working as expected under Adjustment Misc screen
        {
            try
            {
                Reports.TestDescription = "USERSTORY 213051_TESTCASE_431781_SCENARIO1:To verify total amount when Buyer Charge amount is available from L1 to L17 and Charge payment method is either POC or other than POC.";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);
                
                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                //L01
                Reports.TestStep = "To enter Excess Deposit amount in Deposit Outside Escrow screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("2000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("2000");
                FastDriver.BottomFrame.Save();

                //L02
                Reports.TestStep = "Enter Loan Amount value in New Loan 1 screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("1200");
                FastDriver.BottomFrame.Done();

                //L03
                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("247");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 2500, null, null, null);
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod, 5);
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("At Closing");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //L04
                Reports.TestStep = "Enter Loan Amount in 2nd instance";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("248");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.UpdateImpoundCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", 50, null, null, null, null, null, null, string.Empty);
                FastDriver.NewLoan.UpdateImpoundCharge(FastDriver.NewLoan.NewLoanChargesTable, "Appraisal Fee", null, 100, null, null, null, null, null, string.Empty);
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
                FastDriver.PaymentDetailsDlg.SwitchToDialogContentFrame();
                FastDriver.PaymentDetailsDlg.WaitCreation(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing, 5);
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("50");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("0");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText("0");
                FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.BottomFrame.Done();

                //L05
                Reports.TestStep = "Setting Buyer Credit in Adjustment Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.WaitCreation(FastDriver.AdjustmentOffset.SellerCharge3, 10);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Seller Credit", null, null, 12345, null, null);

                //L06
                Reports.TestStep = "Navigate to Property Tax Check and Add GAB";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("188");
                FastDriver.PropertyTaxCheck.Find.FAClick();

                Reports.TestStep = "Add BuyerCredit in Property Tax Check screen";
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 300.09, null, null, null, "");
                Keyboard.SendKeys(FAKeys.TabAway);

                //L07 a
                Reports.TestStep = "Navigate to REB screen - Add GAB REBBroker Credits, Commission Amount";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("247");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("1000");
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Credit", 0.750, null, null);

                //L07 b
                Reports.TestStep = "Entering Assumption Loan data";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("182");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 2.00, null, null, null);

                //L08,L09,L10,L11a, L11 b
                Reports.TestStep = "Setting Buyer Credit  in Adjustment Offset Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Lease/Rent", null, null, 20.2, null, null);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Assign Tenant Security Deposit", null, null, 30.5, null, null);
                FastDriver.AdjustmentOffset.AddOffsetCharges("ABCE Adhoc", null, 901.23, null, null);
                //Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Setting Buyer Credit in Adjustment Miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentMisc>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentMisc.UpdateMiscCharges("Buyer Deposit Directly to Seller", null, null, 40.53, null, null);
                FastDriver.AdjustmentMisc.UpdateMiscCharges("IBA Interest Paid", null, null, 50.64, null, null);
                FastDriver.BottomFrame.Done();

                //L12 to L14
                FixedLinesData_Adj_dataentry("L");

                // L15 to L17
                DynamicLines_Adj_dataentry("L");
                
                Reports.TestStep = "Navigate to Closing Disclosure and Expand Summaries Of Transactions section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(2000);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);
                
                Support.AreEqual("01", FastDriver.ClosingDisclosure.SectionL01_Seqno.Text);
                Support.AreEqual("Deposit", FastDriver.ClosingDisclosure.SectionL01_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$2,000.00", FastDriver.ClosingDisclosure.SectionL01_Amt.Text);

                Support.AreEqual("02", FastDriver.ClosingDisclosure.SectionL02_Seqno.Text);
                Support.AreEqual("Loan Amount", FastDriver.ClosingDisclosure.SectionL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$1,200.00", FastDriver.ClosingDisclosure.SectionL02_Amt.Text);

                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text);
                Support.AreEqual("Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$2,500.00", FastDriver.ClosingDisclosure.SectionL03_Amt.Text);

                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionL04_Seqno.Text);
                Support.AreEqual("Second Loan", FastDriver.ClosingDisclosure.SectionL04_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$50.00", FastDriver.ClosingDisclosure.SectionL04_Amt.Text);

                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionL05_Seqno.Text);
                Support.AreEqual("Seller Credit", FastDriver.ClosingDisclosure.SectionL05_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$12,345.00", FastDriver.ClosingDisclosure.SectionL05_Amt.Text);

                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text);
                Support.AreEqual("Tax Installment: Amount from Mblo Funding, Inc.", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$300.09", FastDriver.ClosingDisclosure.SectionL06_Amt.Text);

                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text);
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$2.75", FastDriver.ClosingDisclosure.SectionL07_Amt.Text);

                Support.AreEqual("07a", FastDriver.ClosingDisclosure.SectionL07a_Seqno.Text);
                Support.AreEqual("REB Credit from Lenders Advantage A Division Of First American Title Ins.", FastDriver.ClosingDisclosure.SectionL07a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$0.75", FastDriver.ClosingDisclosure.SectionL07a_Amt.Text);

                Support.AreEqual("07b", FastDriver.ClosingDisclosure.SectionL07SupL02_Seqno.Text);
                Support.AreEqual("Assumption Transfer Fee from Block & Landsman", FastDriver.ClosingDisclosure.SectionL07SupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$2.00", FastDriver.ClosingDisclosure.SectionL07SupL02_Amt.Text);

                Support.AreEqual("08", FastDriver.ClosingDisclosure.SectionL08_Seqno.Text);
                Support.AreEqual("ABCE Adhoc", FastDriver.ClosingDisclosure.SectionL08_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$901.23", FastDriver.ClosingDisclosure.SectionL08_Amt.Text);

                Support.AreEqual("09", FastDriver.ClosingDisclosure.SectionL09_Seqno.Text);
                Support.AreEqual("Assign Tenant Lease/Rent", FastDriver.ClosingDisclosure.SectionL09_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$20.20", FastDriver.ClosingDisclosure.SectionL09_Amt.Text);

                Support.AreEqual("10", FastDriver.ClosingDisclosure.SectionL10_Seqno.Text);
                Support.AreEqual("Assign Tenant Security Deposit", FastDriver.ClosingDisclosure.SectionL10_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$30.50", FastDriver.ClosingDisclosure.SectionL10_Amt.Text);

                Support.AreEqual("11", FastDriver.ClosingDisclosure.SectionL11_Seqno.Text);
                Support.AreEqual("See attached page for additional information", FastDriver.ClosingDisclosure.SectionL11_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$91.17", FastDriver.ClosingDisclosure.SectionL11_Amt.Text);

                Support.AreEqual("11a", FastDriver.ClosingDisclosure.SectionL11a_Seqno.Text);
                Support.AreEqual("Buyer Deposit Directly to Seller", FastDriver.ClosingDisclosure.SectionL11a_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$40.53", FastDriver.ClosingDisclosure.SectionL11a_Amt.Text);

                Support.AreEqual("11b", FastDriver.ClosingDisclosure.SectionLSupL02_Seqno.Text);
                Support.AreEqual("IBA Interest Paid", FastDriver.ClosingDisclosure.SectionLSupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$50.64", FastDriver.ClosingDisclosure.SectionLSupL02_Amt.Text);

                Support.AreEqual("11b", FastDriver.ClosingDisclosure.SectionLSupL02_Seqno.Text);
                Support.AreEqual("IBA Interest Paid", FastDriver.ClosingDisclosure.SectionLSupL02_Label.GetAttribute("Title").ToString().Trim());
                Support.AreEqual("$50.64", FastDriver.ClosingDisclosure.SectionLSupL02_Amt.Text);
                
                System.Collections.Generic.List<string> charges = FastDriver.ClosingDisclosure.getTotalCreditChargeAmountFromAdjForItemsTable();
                System.Collections.Generic.List<string> descriptions = FastDriver.ClosingDisclosure.getChargeDescriptionsFromAdjForItemsTable();

                Support.AreEqual("12", FastDriver.ClosingDisclosure.SectionL12_SeqNo.Text.Trim());
                Support.AreEqual("City/Town Taxes", descriptions.ElementAt(0));
                Support.AreEqual("$200.00", charges.ElementAt(0));

                Support.AreEqual("13", FastDriver.ClosingDisclosure.SectionL13_SeqNo.Text.Trim());
                Support.AreEqual("County Taxes", descriptions.ElementAt(1));
                Support.AreEqual("$600.00", charges.ElementAt(1));

                Support.AreEqual("14", FastDriver.ClosingDisclosure.SectionL14_SeqNo.Text.Trim());
                Support.AreEqual("Assessments", descriptions.ElementAt(2));
                Support.AreEqual("$800.00", charges.ElementAt(2));

                Support.AreEqual("15", FastDriver.ClosingDisclosure.SectionL15_SeqNo.Text.Trim());
                Support.AreEqual("1Wind Insurance desc", descriptions.ElementAt(3));
                Support.AreEqual("$4,800.00", charges.ElementAt(3));

                Support.AreEqual("16", FastDriver.ClosingDisclosure.SectionL16_SeqNo.Text.Trim());
                Support.AreEqual("2Flood Insurance des", descriptions.ElementAt(4));
                Support.AreEqual("$7,200.00", charges.ElementAt(4));

                Support.AreEqual("17a", FastDriver.ClosingDisclosure.SectionL17a_SeqNo.Text.Trim());
                Support.AreEqual("3Fire Insurance desc", descriptions.ElementAt(5));
                Support.AreEqual("$9,600.00", charges.ElementAt(6));

                Support.AreEqual("17b", FastDriver.ClosingDisclosure.SectionL17b_SeqNo.Text.Trim());
                Support.AreEqual("4EarthQuake descript", descriptions.ElementAt(6));
                Support.AreEqual("$19,200.00", charges.ElementAt(7));

                Support.AreEqual("17c", FastDriver.ClosingDisclosure.SectionL17c_SeqNo.Text.Trim());
                Support.AreEqual("HOA description", descriptions.ElementAt(7));
                Support.AreEqual("$38,400.00", charges.ElementAt(8));

                Support.AreEqual("17d", FastDriver.ClosingDisclosure.SectionL17d_SeqNo.Text.Trim());
                Support.AreEqual("Rents", descriptions.ElementAt(8));
                Support.AreEqual("$151,200.00", charges.ElementAt(9));

                Support.AreEqual("17e", FastDriver.ClosingDisclosure.SectionL17e_SeqNo.Text.Trim());
                Support.AreEqual("Utility description", descriptions.ElementAt(9));
                Support.AreEqual("$76,800.00", charges.ElementAt(10));

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion USERSTORY 213051_TESTCASE_431781_SCENARIO1 - Section L : To verify total amount when Buyer Charge amount is available from L1 to L17 and Charge payment method is either POC or other than POC.

        #region USERSTORY 464159 CD Screen - on tab change save CD

        #region USERSTORY 464159_TESTCASE_489705 CD Screen Verify the save functionality on Tab out.

        [TestMethod, Description("USERSTORY 393783_TESTCASE_489705_SCENARIO1 - CD Screen: Verify the save functionality on Tab out. ")]
        public void FTR5_ITR48_US_464159_TC_489705()
        {
            try
            {
                Reports.TestDescription = "USERSTORY 393783_TESTCASE_489705_SCENARIO1 - CD Screen: Verify the save functionality on Tab out. ";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Entering Assumption Loan data";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("182");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(3000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Assumption Transfer Fee", null, null, 2.00, null, null, null);

                Reports.TestStep = "Expand Summaries of Transaction";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verify L06 line number and credit description";
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text);
                Support.AreEqual("Assumption Transfer Fee from Block & Landsman", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());

                Reports.TestStep = "Verify credit description shown in L06 is editable";
                var inputElement = FastDriver.ClosingDisclosure.SectionL06_Label;
                Support.AreEqual("True", inputElement.Enabled.ToString().Trim());

                Reports.TestStep = "Edit Charge description with max length";
                var SecLTable2 = FastDriver.WebDriver.FindElement(By.Id("tbl_transSummary_OtherCreditsL"));
                string EditDescinCDL6 = inputElement.Text.Substring(0, 4) + "!@012345";
                var clearInput = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
                clearInput.Clear();
                clearInput.Clear();
                clearInput.FASetText(EditDescinCDL6);

                Reports.TestStep = "Navigate to Delivery Options tab";
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Validate All include Default Status";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.IncApp.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.IncApp.Selected.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.IncAddenum.Enabled.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.IncAddenum.Selected.ToString());

                Reports.TestStep = "Navigate to Closing Disclosure tab";
                FastDriver.ClosingDisclosure.tabClosingDisclosure.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Verify Description edited in CD L06 is saved";
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);
                SecLTable2 = FastDriver.WebDriver.FindElement(By.Id("tbl_transSummary_OtherCreditsL"));
                var DescEditinCD = SecLTable2.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
                Support.AreEqual(EditDescinCDL6, DescEditinCD.Text.Trim());

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #endregion

        #endregion USERSTORY 464159 CD Screen - on tab change save CD

        #region USERSTORY 370078 CD Screen - Section L: CD Screen - Section L: Adjustments for Items Unpaid by Seller - Supplemental Charges

        #region USERSTORY 370078_TESTCASE_379549_SCENARIO2: Section L: add and edit Supplemental Charges

        [TestMethod, Description("Section L ADD EDIT supplementary CHARGES")]
        public void FTR5_ITR20_US_370078_TC_379549_SC2()
        {
            try
            {
                Reports.TestDescription = "Section L ADD EDIT supplementary CHARGES";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                String[] Desc = new String[20];
                String[] Fdate = new String[20];
                String[] Tdate = new String[20];
                String[] Amt = new String[20];
                String[] Get_Amt = new String[20];
                //int ind = 4;
                Random rnd = new Random();
                Random random = new Random();
                int randomNumber; random.Next(0, 1000);
                for (int ii = 0; ii < 9; ii++)
                {
                    Desc[ii] = ii + "DescriptionDetails " + ii;
                    Fdate[ii] = 1 + "/" + (ii + 1) + "/" + "14";
                    Tdate[ii] = 1 + "/" + (ii + 1) + "/" + "15";
                    randomNumber = random.Next(0, 860);
                    Amt[ii] = "1000" + randomNumber;
                }
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Proration charges in Escrow charge->Utility ";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
                Playback.Wait(250);
                Utility_Data("344", "Th!s is an Utility Desc1", "1/1/14", "1/1/15", "25000");
                Utility_Data("344", "Th!s is an Utility Desc2", "1/1/14", "1/1/15", "25000");

                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").SwitchToContentFrame();
                Playback.Wait(250);
                other_Proration_data("Th!s is a Rent Desc1", "2/2/14", "2/2/15", "25000");
                other_Proration_data("Th!s is a Rent Desc2", "2/2/14", "2/2/15", "25000");

                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").SwitchToContentFrame();
                Playback.Wait(250);
                other_Proration_data("Th!s is a Misc Desc1", "3/3/14", "3/3/15", "25000");
                other_Proration_data("Th!s is a Misc Desc2", "3/3/14", "3/3/15", "25000");

                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Assumption Loan";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                Assumption_Loan_data("344", "4/4/14", "4/4/15", "25000");
                Assumption_Loan_data("344", "4/4/14", "4/4/15", "25000");

                Reports.TestStep = "Creating Proration charges in Escrow charge->hoeowner associatino ";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Playback.Wait(250);
                homeowner_Data("344", "Th!s is a HOA Desc1", "5/5/2014", "5/5/2015", "25000");
                homeowner_Data("344", "Th!s is a HOA Desc2", "5/5/2014", "5/5/2015", "25000");
                
                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Insurrance";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
                Playback.Wait(250);
                insurance_Data("344", "Th!s is a Insurance Desc1", "6/6/2014", "6/6/2015", "25000");
                insurance_Data("188", "Th!s is a Insurance Desc2", "6/6/2014", "6/6/2015", "25000");

                Reports.TestStep = "vigate to Escrow Closing||Closing Disclosure. click on summaries of transaction link";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Go to line no 15-17(17A -17 z) of section L and verify whether description, from date, to date and amount shown in section L is matching with date, description and Buyer Credit value of other proration charges entered in Insurance/utility/homeowner association and rent and miscellaneoius page ";
                System.Collections.Generic.List<string> charges = FastDriver.ClosingDisclosure.getTotalCreditChargeAmountFromAdjForItemsTable();
                System.Collections.Generic.List<string> descriptions = FastDriver.ClosingDisclosure.getChargeDescriptionsFromAdjForItemsTable();

                Support.AreEqual("Assumption Loan Inte", descriptions.ElementAt(3));
                Support.AreEqual("$9,125,000.00", charges.ElementAt(0));

                Support.AreEqual("Interest Proration", descriptions.ElementAt(4));
                Support.AreEqual("$9,125,000.00", charges.ElementAt(1));

                Support.AreEqual("Th!s is a HOA Desc1", descriptions.ElementAt(5));
                Support.AreEqual("$300,000.00", charges.ElementAt(3));

                Support.AreEqual("Th!s is a HOA Desc2", descriptions.ElementAt(6));
                Support.AreEqual("$300,000.00", charges.ElementAt(4));

                Support.AreEqual("Th!s is a Insurance", descriptions.ElementAt(7));
                Support.AreEqual("$300,000.00", charges.ElementAt(5));

                Support.AreEqual("Th!s is a Insurance", descriptions.ElementAt(8));
                Support.AreEqual("$300,000.00", charges.ElementAt(6));

                Support.AreEqual("Th!s is a Misc Desc1", descriptions.ElementAt(9));
                Support.AreEqual("$300,000.00", charges.ElementAt(7));

                Support.AreEqual("Th!s is a Misc Desc2", descriptions.ElementAt(10));
                Support.AreEqual("$300,000.00", charges.ElementAt(8));

                Support.AreEqual("Th!s is a Rent Desc1", descriptions.ElementAt(11));
                Support.AreEqual("$300,000.00", charges.ElementAt(9));

                Support.AreEqual("Th!s is a Rent Desc2", descriptions.ElementAt(12));
                Support.AreEqual("$300,000.00", charges.ElementAt(10));

                Support.AreEqual("Th!s is an Utility D", descriptions.ElementAt(13));
                Support.AreEqual("$300,000.00", charges.ElementAt(11));

                Support.AreEqual("Th!s is an Utility D", descriptions.ElementAt(14));
                Support.AreEqual("$300,000.00", charges.ElementAt(12));

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion USERSTORY 370078 CD Screen - Section L: CD Screen - Section L: Adjustments for Items Unpaid by Seller - Supplemental Charges

        #region USERSTORY 370073 CD Screen - Section L: CD Screen - Section L: Adjustments for Items Unpaid by Seller - Supplemental Line

        #region USERSTORY 370073_TESTCASE_379680_SCENARIO1: Section L: add and edit charges and verifv Supplemental line charges

        [TestMethod, Description("Section L supplementary lines, Add/EDIT")]
        public void FTR5_ITR20_US_370073_TC_379680_SC1()
        {
            try
            {
                Reports.TestDescription = "Section L supplementary lines, Add/EDIT";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").SwitchToContentFrame();
                Playback.Wait(250);
                other_Proration_data("Th!s is a Rent Desc1", "2/2/14", "2/2/15", "25000");

                Reports.TestStep = "Creating Proration charges in Escrow charge->proration->miscellaneous Screen";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous").SwitchToContentFrame();
                Playback.Wait(250);
                other_Proration_data("Th!s is a Misc Desc1", "3/3/14", "3/3/15", "25000");

                Reports.TestStep = "Creating Proration charges in Escrow charge->Utility ";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
                Playback.Wait(250);
                Utility_Data("344", "Th!s is an Utility Desc1", "1/1/14", "1/1/15", "25000");
                Utility_Data("344", "Th!s is an Utility Desc2", "1/1/14", "1/1/15", "25000");

                Reports.TestStep = "Creating Proration charges in Escrow charge->hoeowner associatino ";
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
                Playback.Wait(250);
                homeowner_Data("344", "Th!s is a HOA Desc1", "5/5/2014", "5/5/2015", "25000");
                homeowner_Data("344", "Th!s is a HOA Desc2", "5/5/2014", "5/5/2015", "25000");

                Reports.TestStep = "VERIFYING SUPPLEMENTARY IINE CHARGES ";
                Supp_Line_Verification("Section L", sum);

                Reports.TestStep = "EDITING one of the supplementar line charges";
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").SwitchToContentFrame();
                Playback.Wait(250); 
                FastDriver.ProrationTax.SwitchToContentFrame();
                FastDriver.ProrationTax.ProrationTaxTable2.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.SwitchToContentFrame();
                FastDriver.ProrationDetail.Description.Click();
                Playback.Wait(1000);
                FastDriver.ProrationDetail.Description.FireEvent("onfocus");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DEL}");
                Playback.Wait(1000);
                Keyboard.SendKeys("zRent Desc Edited");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ProrationDetail.BuyerCredit.FASetText("5555.25");
                FastDriver.BottomFrame.Done();
                buyerCredits[0] = "5555.25";

                Reports.TestStep = "VERIFYING SUPPLEMENTARY IINE CHARGES AFTER EDITING ONE OF THE CHARGES ";
                Supp_Line_Verification("Section L", sum);

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #endregion USERSTORY 370073 CD Screen - Section L: CD Screen - Section L: Adjustments for Items Unpaid by Seller - Supplemental Line

        #region USERSTORY 370064 CD Screen - Section L: CD Screen - Section L: Adjustments for Items Unpaid by Seller - Other Prorations

        #region USERSTORY 370064_TESTCASE_379520_SCENARIO1: Section L: add and edit other proration charges

        [TestMethod, Description("Section L , Add/Edit Other proration Charges and verify")]
        public void FTR5_ITR20_US_370064_TC_379520_SC1()
        {
            Reports.TestDescription = "Section L , Add/Edit Other proration Charges and verify";

            #region data setup
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };
            #endregion

            #region GUI interaction

            Reports.TestStep = "Login to file side";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            Playback.Wait(5000);

            Reports.TestStep = "Create a basic file";
            string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
            FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
            FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
            Playback.Wait(250);

            Reports.TestStep = "Creating Wind insurance charges ";
            Wind_Insurance("Wind Desc", "1/1/14", "1/1/15", "25000", "No", "L");

            Reports.TestStep = "Creating Flood insurance charges ";
            Flood_Insurance("Flood Desc", "2/2/14", "2/2/15", "25000", "No", "L");

            Reports.TestStep = "Creating Fire insurance charges ";
            Fire_Insurance("Fire Desc", "3/3/14", "3/3/15", "25000", "No", "L");

            Reports.TestStep = "Creating EarthQuake insurance charges ";
            EarthQuake_Insurance("Earthquake Desc", "4/4/14", "4/4/15", "25000", "No", "L");

            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(1500);
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(250);

            var row = FastDriver.ClosingDisclosure.SectionL_AdjustmentforItemsSubTable.FindElements(By.TagName("tr"));

            //15
            var element = row[4].FindElements(By.TagName("td"));
            Support.AreEqual("15", element[0].Text.Trim());
            Support.AreEqual("Earthquake Desc", element[1].Text.Trim());
            Support.AreEqual("4/4/14", element[2].Text.Trim());
            Support.AreEqual("4/4/15", element[4].Text.Trim());
            Support.AreEqual("$300,000.00", element[6].Text.Trim());

            //16
            element = row[5].FindElements(By.TagName("td"));
            Support.AreEqual("16", element[0].Text.Trim());
            Support.AreEqual("Fire Desc", element[1].Text.Trim());
            Support.AreEqual("3/3/14", element[2].Text.Trim());
            Support.AreEqual("3/3/15", element[4].Text.Trim());
            Support.AreEqual("$300,000.00", element[6].Text.Trim());

            //17
            element = row[6].FindElements(By.TagName("td"));
            Support.AreEqual("17", element[0].Text.Trim());
            Support.AreEqual("See attached page for additional information", element[1].Text.Trim());
            Support.AreEqual("$600,000.00", element[3].Text.Trim());

            //17a
            element = row[7].FindElements(By.TagName("td"));
            Support.AreEqual("17a", element[0].Text.Trim());
            Support.AreEqual("Flood Desc", element[1].Text.Trim());
            Support.AreEqual("2/2/14", element[2].Text.Trim());
            Support.AreEqual("2/2/15", element[4].Text.Trim());
            Support.AreEqual("$300,000.00", element[6].Text.Trim());

            //17b
            element = row[8].FindElements(By.TagName("td"));
            Support.AreEqual("17b", element[0].Text.Trim());
            Support.AreEqual("Wind Desc", element[1].Text.Trim());
            Support.AreEqual("1/1/14", element[2].Text.Trim());
            Support.AreEqual("1/1/15", element[4].Text.Trim());
            Support.AreEqual("$300,000.00", element[6].Text.Trim());

            Reports.TestStep = "Now navigate to escrow charge process-> insurance link and select any of the insurance type like fire/flood/wind/earthquake and click on remove button and subsequently click on ok button seen on pop up window";
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
            Playback.Wait(1000);
            FastDriver.InsuranceSummary.Wind.FAClick();
            FastDriver.InsuranceSummary.SummaryRemove.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(true, true);
            Playback.Wait(250);
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Navigate to Escrow Closing||Closing Disclosure . click on summaries of transaction link ";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(250);
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(1000);

            Reports.TestStep = "Go to line no 15-17 of section L and verify";
            row = FastDriver.ClosingDisclosure.SectionL_AdjustmentforItemsSubTable.FindElements(By.TagName("tr"));

            //15
            element = row[4].FindElements(By.TagName("td"));
            Support.AreEqual("15", element[0].Text.Trim());
            Support.AreEqual("Earthquak", element[1].Text.Trim());
            Support.AreEqual("4/4/14", element[2].Text.Trim());
            Support.AreEqual("4/4/15", element[4].Text.Trim());
            Support.AreEqual("$300,000.00", element[6].Text.Trim());

            //16
            element = row[5].FindElements(By.TagName("td"));
            Support.AreEqual("16", element[0].Text.Trim());
            Support.AreEqual("Fire Desc", element[1].Text.Trim());
            Support.AreEqual("3/3/14", element[2].Text.Trim());
            Support.AreEqual("3/3/15", element[4].Text.Trim());
            Support.AreEqual("$300,000.00", element[6].Text.Trim());

            //17
            element = row[6].FindElements(By.TagName("td"));
            Support.AreEqual("17", element[0].Text.Trim());
            Support.AreEqual("Flood Desc", element[1].Text.Trim());
            Support.AreEqual("2/2/14", element[2].Text.Trim());
            Support.AreEqual("2/2/15", element[4].Text.Trim());
            Support.AreEqual("$300,000.00", element[6].Text.Trim());

            #endregion GUI interaction

        }

        #endregion

        #endregion USERSTORY 370064 CD Screen - Section L: CD Screen - Section L: Adjustments for Items Unpaid by Seller - Other Prorations

        #region US-393840-CD Screen Section L : Ability to Edit Charge Group Description

        [TestMethod, Description("VERIFY  THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR THE Line L01")]
        public void FTR5_ITR48_US_393840_TC_492784_01()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR THE Line L01";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.DepositOutsideEscrow.ExcessDeposit.FASetText("5000");
                FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText("5000");
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Navigating to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(1500);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verifying Charges in L01";
                Support.AreEqual("01", FastDriver.ClosingDisclosure.SectionL01_Seqno.Text.Trim());
                Support.AreEqual("Deposit", FastDriver.ClosingDisclosure.SectionL01_Label.Text.Trim());
                try 
	            {
                    FastDriver.ClosingDisclosure.SectionL01_Label.Click();
                    FastDriver.ClosingDisclosure.SectionL01_Label.Click();
                    FastDriver.ClosingDisclosure.SectionL01_Label.FASetText("Description Edited");
	            }
	            catch (Exception e)
	            {
                    Reports.StatusUpdate("Closing Costs Description is not able to Edit. Error: " + e.Message, true);
	            }

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Description("VERIFY  THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR THE LineL05")]
        public void FTR5_ITR48_US_393840_TC_492993_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR THE LineL05";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AdjustmentOffset>(@"Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AdjustmentOffset.WaitCreation(FastDriver.AdjustmentOffset.SellerCharge3, 10);
                FastDriver.AdjustmentOffset.UpdateOffsetCharges("Seller Credit", null, null, 5000, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigating to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verifying Charges in L05";
                Support.AreEqual("05", FastDriver.ClosingDisclosure.SectionL05_Seqno.Text.Trim());
                Support.AreEqual("Seller Credit", FastDriver.ClosingDisclosure.SectionL05_Label.Text.Trim());
                FastDriver.ClosingDisclosure.SectionL05_Label.FireEvent("onfocus");
                Keyboard.SendKeys("Buyer Credits");
                Support.AreNotEqual("Buyer Credits", FastDriver.ClosingDisclosure.SectionL05_Label.Text.Trim());
                                
                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Description("VERIFY  THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR Line L02")]
        public void FTR5_ITR48_US_393840_TC_492932_03()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR Line L02";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Adding Loan amount in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("5000");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigating to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verifying Charges in L05";
                Support.AreEqual("02", FastDriver.ClosingDisclosure.SectionL02_Seqno.Text.Trim());
                Support.AreEqual("Loan Amount", FastDriver.ClosingDisclosure.SectionL02_Label.Text.Trim());
                FastDriver.ClosingDisclosure.SectionL02_Label.FireEvent("onfocus");
                Keyboard.SendKeys("Buyer Credits");
                Support.AreNotEqual("Buyer Credits", FastDriver.ClosingDisclosure.SectionL02_Label.Text.Trim());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Description("VERIFY  THE CHARGE GROUP DESCRIPTION IS EDITABLE : FOR THE SOURCE SCREEN NEW LOAN2")]
        public void FTR5_ITR48_US_393840_TC_492981_04()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS EDITABLE : FOR THE SOURCE SCREEN NEW LOAN2";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in New Loan Screen";
                FastDriver.LeftNavigation.Navigate<NewLoan>(@"Home>Order Entry>New Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.LoanDetailsGABcode, 10);
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanDetailsGABcode.FASetText("344");
                FastDriver.NewLoan.LoanDetailsFind.FAClick();
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FASetText("5000");
                FastDriver.NewLoan.LoanChargesInterestCalculationbuyercredit.FASetText("1000");
                FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", "Lender's Inspection Fee", "Buyer Credit", TableAction.SetText, "5000");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigating to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verifying Charges in L04";
                var cdTable = FastDriver.WebDriver.FindElement(By.Id("tbl_transSummary_DueItemsL"));
                Support.AreEqual("04", FastDriver.ClosingDisclosure.SectionL04_Seqno.Text.Trim());
                Support.AreEqual("*  Second Loan  (Principal Balance $5,000.00)", FastDriver.ClosingDisclosure.SectionL04_Label.Text.Trim());
                var element = cdTable.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
                element.Clear();
                element.Clear();
                element.FASetText("NewLoan New Description");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Verifying Group Description in pop up ";
                FastDriver.ClosingDisclosure.L04Plus.FAClick();
                Support.AreEqual("NewLoan New Description", FastDriver.CDL04Popup.L04Description.Text);
                FastDriver.CDL04Popup.Done.FAClick();

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Description("VERIFY  THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR THE LINE L03")]
        public void FTR5_ITR48_US_393840_TC_492990_05()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS NOT EDITABLE : FOR THE LINE L03";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Creating Charges in Assumption Loan Screen";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>(@"Home>Order Entry>Assumption Loan").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("344");
                FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.ChargesTab.FAClick();
                Playback.Wait(250);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Statement/Forwarding Fee", null, null, 5000, null, null, null);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Document Fee", null, null, 600, null, null, null);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Late Charge", null, null, 1500, null, null, null);
                FastDriver.AssumptionLoanCharges.UpdateAssumptionLoanChargesTable("Balance of Impounds/Reserves Acct.", null, null, 1500, null, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigating to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verifying Charges in L03";
                var cdTable = FastDriver.WebDriver.FindElement(By.Id("tbl_transSummary_DueItemsL"));
                Support.AreEqual("03", FastDriver.ClosingDisclosure.SectionL03_Seqno.Text.Trim());
                Support.AreEqual("Existing Loan(s) Assumed or Taken Subject to", FastDriver.ClosingDisclosure.SectionL03_Label.GetAttribute("Title").ToString().Trim());
                FastDriver.ClosingDisclosure.SectionL03_Label.FireEvent("onfocus");
                Keyboard.SendKeys("NewLoan New Description");
                Keyboard.SendKeys(FAKeys.TabAway);
                Support.AreNotEqual("NewLoan New Description", FastDriver.ClosingDisclosure.SectionL03_Label.GetAttribute("Title").ToString().Trim());

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Description("VERIFY  THE CHARGE GROUP DESCRIPTION IS EDITABLE : FOR THE SOURCE SCREEN REB")]
        public void FTR5_ITR48_US_393840_TC_493033_06()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS EDITABLE : FOR THE SOURCE SCREEN REB";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigating to REB Screen and creating REB Credits";
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("344");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("50");
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Credits", 5000, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Adding Buyer credits for another REB";
                FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgentSummary.NewOther.FAClick();
                Playback.Wait(250);
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("344");
                FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText("40");
                FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits, 10);
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
                FastDriver.RealEstateBrokerAgent.AddRealEstateBrokerCredits("REB Credits2", 6000, null, null);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Adding Buyer Credits for another source screen Property Taxes";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("344");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", null, 6000, null, null, null, "");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 600, null, null, null, "");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", null, 1500, null, null, null, "");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Partial Payment Amt", null, 1500, null, null, null, "");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigating to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Editing Charge Group description in Line L06";
                var cdTable = FastDriver.WebDriver.FindElement(By.Id("tbl_transSummary_L"));
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                var element = cdTable.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
                element.Clear();
                element.Clear();
                element.FASetText("New Description");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Verifying Charges in L07";
                Support.AreEqual("07", FastDriver.ClosingDisclosure.SectionL07_Seqno.Text.Trim());
                Support.AreEqual("Real Estate Broker Credits", FastDriver.ClosingDisclosure.SectionL07_Label.GetAttribute("Title").ToString().Trim());
                element = cdTable.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Real Estate") && i.Displayed);
                element.Clear();
                element.Clear();
                element.FASetText("New Description");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Verifying the description";
                FastDriver.ClosingDisclosure.L06Plus.FAClick();

                Reports.TestStep = "Verifying Group Description in pop up window ";
                Support.AreEqual("New Description", FastDriver.CDL06Popup.L06Description.Text.Trim());
                FastDriver.CDL06Popup.Done.FAClick();

                Reports.TestStep = "Verifying the credits in L07 Popup";
                FastDriver.ClosingDisclosure.L07Plus.FAClick();

                Reports.TestStep = "Verifying Group Description in pop up window ";
                Support.AreEqual("New Description", FastDriver.ClosingDisclosure.L07PopupDesc.Text.Trim());
                FastDriver.ClosingDisclosure.PopUpDone.FAClick();
                Playback.Wait(1000);

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod, Description("VERIFY  THE CHARGE GROUP DESCRIPTION IS EDITABLE : FOR THE SOURCE SCEEEN PROPERTY TAXES")]
        public void FTR5_ITR48_US_393840_TC_491639_07()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE CHARGE GROUP DESCRIPTION IS EDITABLE : FOR THE SOURCE SCEEEN PROPERTY TAXES";

                #region data setup
                var credentials = new Credentials()
                {
                    UserName = AutoConfig.UserName,
                    Password = AutoConfig.UserPassword
                };
                #endregion

                #region GUI interaction

                Reports.TestStep = "Login to file side";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                Playback.Wait(5000);

                Reports.TestStep = "Create a basic file";
                string fileNumber = FastDriver.FACreateFileFromWCF(RequestFactory.GetCreateFileDefaultRequest());
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Adding Buyer charges in Proprty Tax Check Source Screen";
                FastDriver.LeftNavigation.Navigate<PropertyTaxCheck>(@"Home>Order Entry>Escrow Charge Processes>Property Tax Check").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.PropertyTaxCheck.GABcode.FASetText("344");
                FastDriver.PropertyTaxCheck.Find.FAClick();
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Interest Due", null, 6000, null, null, null, "");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Amount", null, 600, null, null, null, "");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Penalty Due", null, 1500, null, null, null, "");
                FastDriver.PropertyTaxCheck.UpdatePropertyTaxesTable("Tax Installment: Partial Payment Amt", null, 1500, null, null, null, "");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigating to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
                Playback.Wait(250);
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                Playback.Wait(250);

                Reports.TestStep = "Verifying Charges in L06";
                var cdTable = FastDriver.WebDriver.FindElement(By.Id("tbl_transSummary_L"));
                Support.AreEqual("06", FastDriver.ClosingDisclosure.SectionL06_Seqno.Text.Trim());
                Support.AreEqual("Property Taxes", FastDriver.ClosingDisclosure.SectionL06_Label.GetAttribute("Title").ToString().Trim());
                var element = cdTable.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed);
                element.Clear();
                element.Clear();
                element.FASetText("Property Taxes New Description");
                Keyboard.SendKeys(FAKeys.TabAway);

                Reports.TestStep = "Verifying the Description";
                FastDriver.ClosingDisclosure.L06Plus.FAClick();

                Reports.TestStep = "Verifying Group Description in pop up window After Saving The New Description";
                Support.AreEqual("Property Taxes New Description", FastDriver.CDL06Popup.L06Description.Text.Trim());
                FastDriver.CDL06Popup.Done.FAClick();

                Reports.TestStep = "Saving the CD Screen";
                FastDriver.BottomFrame.Done();

                #endregion GUI interaction

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion US-393840-CD Screen Section L : Ability to Edit Charge Group Description

        #region Help_Functions

        #region Click the charge and enter charges Pulled.
        public static bool FindTheFeeChargePulled(IWebElement table, string chargeDescription, double? buyerCharge, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, string editdescription = "")
        {
            bool iResult = false;
            FastDriver.PropertyTaxCheck.SwitchToContentFrame();
            FastDriver.PropertyTaxCheck.WaitCreation(table, 10);

            IWebElement inputElement;
            if (editdescription != string.Empty)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editdescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                iResult = true;
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                table.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            return iResult;

        }

        #endregion

        #region FUNCTION TO POPULATE DATA IN CD SECTION FIXED LINES M9 TO M11

        public void FixedLinesData_Adj_dataentry(string secName)
        {
            if (secName == "N" || secName == "L")
            {
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[1] = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "09/21/2012", "09/21/2013", "200.00", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[2] = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/22/2013", "10/22/2014", "600.00", false);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[3] = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "11/23/2014", "11/23/2015", "800.00", false);
            }
            else if (secName == "K" || secName == "M")
            {
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[4] = FastDriver.ProrationTax.ProrationTaxEntry(1, "City/Town Taxes", "09/21/2012", "09/21/2013", "200.00", true);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[5] = FastDriver.ProrationTax.ProrationTaxEntry(2, "County Taxes", "10/22/2013", "10/22/2014", "600.00", true);
                FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Tax").WaitForScreenToLoad();
                GetCharge[6] = FastDriver.ProrationTax.ProrationTaxEntry(3, "Assessments", "11/23/2014", "11/23/2015", "800", true);
            }

        }

        #endregion

        #region FUCNTION TO POPULATE DATA IN CD SECTION DYNAMIC LINES OF K L M AND N
        public void DynamicLines_Adj_dataentry(string secName)
        {

            if (secName == "N" || secName == "L")
            {
                GetCharge[7] = Wind_Insurance("1Wind Insurance description", "02/22/2014", "02/22/2015", "400.00", "No", secName);
                Playback.Wait(2000);
                GetCharge[8] = Flood_Insurance("2Flood Insurance description", "03/23/2014", "03/23/2015", "600.00", "No", secName);
                Playback.Wait(2000);
                GetCharge[9] = Fire_Insurance("3Fire Insurance description", "04/24/2014", "04/24/2015", "800.00", "No", secName);
                Playback.Wait(2000);
                GetCharge[10] = EarthQuake_Insurance("4EarthQuake description", "05/25/2014", "05/25/2015", "1600.00", "No", secName);
                Playback.Wait(2000);
                GetCharge[11] = homeowner_Data("HOA description", "06/26/2014", "06/26/2015", "3200.00", "No", secName);
                Playback.Wait(2000);
                GetCharge[12] = Utility_Data("Utility description", "07/27/2014", "07/27/2015", "6400.00", "No", secName);
                Playback.Wait(2000);
                GetCharge[5] = other_Proration_Rdata("Rents", "08/28/2014", "08/28/2015", "12600.00", "No", secName);
                Playback.Wait(2000);

                MAmt[16] = "$" + string.Format("{0:#,##0.00}", GetCharge[6]);
                MAmt[17] = "$" + string.Format("{0:#,##0.00}", GetCharge[7]);
                MAmt[18] = "$" + string.Format("{0:#,##0.00}", GetCharge[8]);
                MAmt[19] = "$" + string.Format("{0:#,##0.00}", GetCharge[9]);
                MAmt[20] = "$" + string.Format("{0:#,##0.00}", GetCharge[10]);
                MAmt[21] = "$" + string.Format("{0:#,##0.00}", GetCharge[11]);
                MAmt[22] = "$" + string.Format("{0:#,##0.00}", GetCharge[5]);
                MAmt[23] = "$" + string.Format("{0:#,##0.00}", GetCharge[12]);

                MAmtTab2SupTotal = "$" + "$" + string.Format("{0:#,##0.00}", GetCharge[10] + GetCharge[11] + GetCharge[12] + GetCharge[5]);
            }

            else if (secName == "M" || secName == "K")
            {

                GetCharge[7] = Wind_Insurance("1Wind Insurance description", "02/22/2014", "02/22/2015", "400.00", "Yes", secName);
                Playback.Wait(2000);
                GetCharge[8] = Flood_Insurance("2Flood Insurance description", "03/23/2014", "03/23/2015", "600.00", "Yes", secName);
                Playback.Wait(2000);
                GetCharge[9] = Fire_Insurance("3Fire Insurance description", "04/24/2014", "04/24/2015", "800.00", "Yes", secName);
                Playback.Wait(2000);
                GetCharge[10] = EarthQuake_Insurance("4EarthQuake description", "05/25/2014", "05/25/2015", "1600.00", "Yes", secName);
                Playback.Wait(2000);
                GetCharge[11] = homeowner_Data("HOA description", "06/26/2014", "06/26/2015", "3200.00", "Yes", secName);
                Playback.Wait(2000);
                GetCharge[12] = Utility_Data("Utility description", "07/27/2014", "07/27/2015", "6400.00", "Yes", secName);
                Playback.Wait(2000);
                GetCharge[5] = other_Proration_Rdata("Rents", "08/28/2014", "08/28/2015", "12600.00", "Yes", secName);
                Playback.Wait(2000);

                MAmt[16] = "$" + string.Format("{0:#,##0.00}", GetCharge[6]);
                MAmt[17] = "$" + string.Format("{0:#,##0.00}", GetCharge[7]);
                MAmt[18] = "$" + string.Format("{0:#,##0.00}", GetCharge[8]);
                MAmt[19] = "$" + string.Format("{0:#,##0.00}", GetCharge[9]);
                MAmt[20] = "$" + string.Format("{0:#,##0.00}", GetCharge[10]);
                MAmt[21] = "$" + string.Format("{0:#,##0.00}", GetCharge[11]);
                MAmt[22] = "$" + string.Format("{0:#,##0.00}", GetCharge[5]);
                MAmt[23] = "$" + string.Format("{0:#,##0.00}", GetCharge[12]);

                MAmtTab2SupTotal = "$" + "$" + string.Format("{0:#,##0.00}", GetCharge[10] + GetCharge[11] + GetCharge[12] + GetCharge[5]);
            }
        }

        public String Wind_Insurance(string Desc, string Fdate, string Tdate, string Amt, String CreditSellerChk, string GetsecAmt)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->WindInsurance";
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.InsuranceSummary.Wind.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceWind.SwitchToContentFrame();
            FastDriver.InsuranceWind.WindGABcode.FASetText("344");
            FastDriver.InsuranceWind.WindFind.FAClick();

            if (CreditSellerChk == "Yes" && (GetsecAmt == "K" || GetsecAmt == "M"))
            {
                string getcreditsellerchk = FastDriver.InsuranceWind.WindCreditSeller.Selected.ToString();// ProRationTax.GetControl("IIS.Insurance", "WindCreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.InsuranceWind.WindAmount.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "WindAmount").Get("Text").ToString();

                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.InsuranceWind.WindCreditSeller.FASetCheckbox(true);//ProRationTax.GetControl("IIS.Insurance", "WindCreditSeller").Set("checked", "True");
                    FastDriver.InsuranceWind.WindPer.FASelectItem("MONTH");// ProRationTax.GetControl("IIS.Insurance", "WindPer").Set("selecteditem", "MONTH");
                    FastDriver.InsuranceWind.WindAmount.FASetText(Amt);// ProRationTax.GetControl("IIS.Insurance", "WindAmount").Set("text", Amt);
                    FastDriver.InsuranceWind.WindFromDate.FASetText(Fdate);// ProRationTax.GetControl("IIS.Insurance", "WindFromDate").Set("text", Fdate);
                    FastDriver.InsuranceWind.WindToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.Insurance", "WindToDate").Set("text", Tdate);
                    FastDriver.InsuranceWind.WindDescription.Click();
                    Playback.Wait(500);
                    FastDriver.InsuranceWind.WindDescription.FireEvent("onfocus");
                    Playback.Wait(500);
                    Keyboard.SendKeys("");
                    Playback.Wait(500);
                    Keyboard.SendKeys(Desc);
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);

                }
                if (GetsecAmt == "K")
                {
                    ret_Amt = FastDriver.InsuranceWind.WindBuyercharge1.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "WindBuyercharge1").Get("Text").ToString();
                }
                else if (GetsecAmt == "M")
                {
                    ret_Amt = FastDriver.InsuranceWind.WindSellerCredit1.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "WindSellerCredit1").Get("Text").ToString();
                }
            }

            else if (CreditSellerChk == "No" && (GetsecAmt == "L" || GetsecAmt == "N"))
            {
                string getcreditsellerchk = FastDriver.InsuranceWind.WindCreditSeller.Selected.ToString();// ProRationTax.GetControl("IIS.Insurance", "WindCreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.InsuranceWind.WindAmount.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "WindAmount").Get("Text").ToString();

                if (getcreditsellerchk == "True")
                {
                    FastDriver.InsuranceWind.WindCreditSeller.FASetCheckbox(false);// ProRationTax.GetControl("IIS.Insurance", "WindCreditSeller").Set("checked", "false");
                    FastDriver.WebDriver.HandleDialogMessage(true, true);// GUI_Functions.GUI_Functions.IEMessage("OK");
                }
                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.InsuranceWind.WindPer.FASelectItem("MONTH");// ProRationTax.GetControl("IIS.Insurance", "WindPer").Set("selecteditem", "MONTH");
                    FastDriver.InsuranceWind.WindAmount.FASetText(Amt);// ProRationTax.GetControl("IIS.Insurance", "WindAmount").Set("text", Amt);
                    FastDriver.InsuranceWind.WindFromDate.FASetText(Fdate); //ProRationTax.GetControl("IIS.Insurance", "WindFromDate").Set("text", Fdate);
                    FastDriver.InsuranceWind.WindToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.Insurance", "WindToDate").Set("text", Tdate);
                    while (true)
                    {
                        FastDriver.InsuranceWind.WindDescription.Click();
                        Playback.Wait(500);
                        Keyboard.SendKeys(Desc);
                        Playback.Wait(500);
                        Keyboard.SendKeys(FAKeys.TabAway);
                        Playback.Wait(500);
                        if (FastDriver.InsuranceWind.WindDescription.GetAttribute("value").Clean() == Desc)
                            break;
                    }
                    
                }
                if (GetsecAmt == "L")
                {
                    ret_Amt = FastDriver.InsuranceWind.Windbuyercredit1.GetAttribute("value").ToString(); ;// ProRationTax.GetControl("IIS.Insurance", "Windbuyercredit1").Get("Text").ToString();
                }
                else if (GetsecAmt == "N")
                {
                    ret_Amt = FastDriver.InsuranceWind.WindSellerCharge1.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "WindSellerCharge1").Get("Text").ToString();
                }
            }

            return (ret_Amt);
        }

        public String EarthQuake_Insurance(string Desc, string Fdate, string Tdate, string Amt, String CreditSellerChk, string GetsecAmt)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->EarthQuake Insurance";
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.InsuranceSummary.EarthQuake.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceEarth.SwitchToContentFrame();
            FastDriver.InsuranceEarth.EarthGABcode.FASetText("344");
            FastDriver.InsuranceEarth.EarthFind.FAClick();

            if (CreditSellerChk == "Yes" && (GetsecAmt == "K" || GetsecAmt == "M"))
            {
                string getcreditsellerchk = FastDriver.InsuranceEarth.EarthCreditSeller.Selected.ToString();// ProRationTax.GetControl("IIS.Insurance", "EarthCreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.InsuranceEarth.EarthCalculateAmount.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "EarthCalculateAmount").Get("Text").ToString();

                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.InsuranceEarth.EarthCreditSeller.FASetCheckbox(true);// ProRationTax.GetControl("IIS.Insurance", "EarthCreditSeller").Set("checked", "True");
                    FastDriver.InsuranceEarth.EarthCalculatePer.FASelectItem("MONTH");// ProRationTax.GetControl("IIS.Insurance", "EarthCalculatePer").Set("selecteditem", "MONTH");
                    FastDriver.InsuranceEarth.EarthCalculateAmount.FASetText(Amt);// ProRationTax.GetControl("IIS.Insurance", "EarthCalculateAmount").Set("text", Amt);
                    FastDriver.InsuranceEarth.EarthCalculateFromDate.FASetText(Fdate);// ProRationTax.GetControl("IIS.Insurance", "EarthCalculateFromDate").Set("text", Fdate);
                    FastDriver.InsuranceEarth.EarthCalculateToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.Insurance", "EarthCalculateToDate").Set("text", Tdate);
                    FastDriver.InsuranceEarth.EarthCalculateDescription.Click();
                    Playback.Wait(500);
                    FastDriver.InsuranceEarth.EarthCalculateDescription.FireEvent("onfocus");
                    Playback.Wait(500);
                    Keyboard.SendKeys("");
                    Playback.Wait(500);
                    Keyboard.SendKeys(Desc);
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);

                }
                if (GetsecAmt == "K")
                {
                    ret_Amt = FastDriver.InsuranceEarth.EarthBuyerCharge1.GetAttribute("value").ToString(); //.GetControl("IIS.Insurance", "EarthBuyerCharge1").Get("Text").ToString();
                }
                else if (GetsecAmt == "M")
                {
                    ret_Amt = FastDriver.InsuranceEarth.EarthSellerCredit1.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "EarthSellerCredit1").Get("Text").ToString();
                }
            }

            else if (CreditSellerChk == "No" && (GetsecAmt == "L" || GetsecAmt == "N"))
            {
                string getcreditsellerchk = FastDriver.InsuranceEarth.EarthCreditSeller.Selected.ToString(); //ProRationTax.GetControl("IIS.Insurance", "EarthCreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.InsuranceEarth.EarthCalculateAmount.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "EarthCalculateAmount").Get("Text").ToString();

                if (getcreditsellerchk == "True")
                {
                    FastDriver.InsuranceEarth.EarthCreditSeller.FASetCheckbox(false);// ProRationTax.GetControl("IIS.Insurance", "EarthCreditSeller").Set("checked", "false");
                    FastDriver.WebDriver.HandleDialogMessage(true, true);// GUI_Functions.GUI_Functions.IEMessage("OK");
                }
                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.InsuranceEarth.EarthCalculatePer.FASelectItem("MONTH"); //ProRationTax.GetControl("IIS.Insurance", "EarthCalculatePer").Set("selecteditem", "MONTH");
                    FastDriver.InsuranceEarth.EarthCalculateAmount.FASetText(Amt);// ProRationTax.GetControl("IIS.Insurance", "EarthCalculateAmount").Set("text", Amt);
                    FastDriver.InsuranceEarth.EarthCalculateFromDate.FASetText(Fdate);// ProRationTax.GetControl("IIS.Insurance", "EarthCalculateFromDate").Set("text", Fdate);
                    FastDriver.InsuranceEarth.EarthCalculateToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.Insurance", "EarthCalculateToDate").Set("text", Tdate);
                    while (true)
                    {
                        FastDriver.InsuranceEarth.EarthCalculateDescription.Click();
                        Playback.Wait(500);
                        Keyboard.SendKeys(Desc);
                        Playback.Wait(500);
                        Keyboard.SendKeys(FAKeys.TabAway);
                        Playback.Wait(500);
                        if (FastDriver.InsuranceEarth.EarthCalculateDescription.GetAttribute("value").Clean() == Desc)
                            break;
                    }
                    
                }
                if (GetsecAmt == "L")
                {
                    ret_Amt = FastDriver.InsuranceEarth.EarthBuyerCredit1.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "EarthBuyerCredit1").Get("Text").ToString();
                }
                else if (GetsecAmt == "N")
                {
                    ret_Amt = FastDriver.InsuranceEarth.EarthSellerCharge1.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "EarthSellerCharge1").Get("Text").ToString();
                }
            }
            return (ret_Amt);
        }

        public String Flood_Insurance(string Desc, string Fdate, string Tdate, string Amt, String CreditSellerChk, string GetsecAmt)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->flood Insurance";
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.InsuranceSummary.Flood.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.Insuranceflood.SwitchToContentFrame();
            FastDriver.Insuranceflood.FloodGABcode.FASetText("344");
            FastDriver.Insuranceflood.FloodFind.FAClick();

            if (CreditSellerChk == "Yes" && (GetsecAmt == "K" || GetsecAmt == "M"))
            {
                string getcreditsellerchk = FastDriver.Insuranceflood.FloodCreditSeller.Selected.ToString();// ProRationTax.GetControl("IIS.Insurance", "FloodCreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.Insuranceflood.FloodAmount.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "FloodAmount").Get("Text").ToString();

                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.Insuranceflood.FloodCreditSeller.FASetCheckbox(true);// ProRationTax.GetControl("IIS.Insurance", "FloodCreditSeller").Set("checked", "True");
                    FastDriver.Insuranceflood.FloodPer.FASelectItem("MONTH");// ProRationTax.GetControl("IIS.Insurance", "FloodPer").Set("selecteditem", "MONTH");
                    FastDriver.Insuranceflood.FloodAmount.FASetText(Amt);//  ProRationTax.GetControl("IIS.Insurance", "FloodAmount").Set("text", Amt);
                    FastDriver.Insuranceflood.FloodFromDate.FASetText(Fdate);// ProRationTax.GetControl("IIS.Insurance", "FloodFromDate").Set("text", Fdate);
                    FastDriver.Insuranceflood.FloodToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.Insurance", "FloodToDate").Set("text", Tdate);
                    FastDriver.Insuranceflood.FloodDescription.Click();
                    Playback.Wait(500);
                    FastDriver.Insuranceflood.FloodDescription.FireEvent("onfocus");
                    Playback.Wait(500);
                    Keyboard.SendKeys("");
                    Playback.Wait(500);
                    Keyboard.SendKeys(Desc);
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);


                }
                if (GetsecAmt == "K")
                {
                    ret_Amt = FastDriver.Insuranceflood.FloodBuyercharge1.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "FloodBuyercharge1").Get("Text").ToString();
                }
                else if (GetsecAmt == "M")
                {
                    ret_Amt = FastDriver.Insuranceflood.FloodSellerCredit1.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "FloodSellerCredit1").Get("Text").ToString();
                }
            }

            else if (CreditSellerChk == "No" && (GetsecAmt == "L" || GetsecAmt == "N"))
            {
                string getcreditsellerchk = FastDriver.Insuranceflood.FloodCreditSeller.Selected.ToString();// ProRationTax.GetControl("IIS.Insurance", "FloodCreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.Insuranceflood.FloodAmount.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "FloodAmount").Get("Text").ToString();

                if (getcreditsellerchk == "True")
                {
                    FastDriver.Insuranceflood.FloodCreditSeller.FASetCheckbox(false);// ProRationTax.GetControl("IIS.Insurance", "FloodCreditSeller").Set("checked", "false");
                    FastDriver.WebDriver.HandleDialogMessage(true, true);// GUI_Functions.GUI_Functions.IEMessage("OK");
                }
                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.Insuranceflood.FloodPer.FASelectItem("MONTH");// ProRationTax.GetControl("IIS.Insurance", "FloodPer").Set("selecteditem", "MONTH");
                    FastDriver.Insuranceflood.FloodAmount.FASetText(Amt);// ProRationTax.GetControl("IIS.Insurance", "FloodAmount").Set("text", Amt);
                    FastDriver.Insuranceflood.FloodFromDate.FASetText(Fdate);// ProRationTax.GetControl("IIS.Insurance", "FloodFromDate").Set("text", Fdate);
                    FastDriver.Insuranceflood.FloodToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.Insurance", "FloodToDate").Set("text", Tdate);
                    while (true)
                    {
                        FastDriver.Insuranceflood.FloodDescription.Click();
                        Playback.Wait(500);
                        Keyboard.SendKeys(Desc);
                        Playback.Wait(500);
                        Keyboard.SendKeys(FAKeys.TabAway);
                        Playback.Wait(500);
                        if (FastDriver.Insuranceflood.FloodDescription.GetAttribute("value").Clean() == Desc)
                            break;
                    }

                }
                if (GetsecAmt == "L")
                {
                    ret_Amt = FastDriver.Insuranceflood.FloodBuyercredit1.GetAttribute("value").ToString(); //ProRationTax.GetControl("IIS.Insurance", "FloodBuyercredit1").Get("Text").ToString();
                }
                else if (GetsecAmt == "N")
                {
                    ret_Amt = FastDriver.Insuranceflood.FloodSellerCharge1.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "FloodSellerCharge1").Get("Text").ToString();
                }
            }
            return (ret_Amt);
        }

        public String Fire_Insurance(string Desc, string Fdate, string Tdate, string Amt, String CreditSellerChk, string GetsecAmt)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->fire Insurance";
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.InsuranceSummary.Fire.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            Playback.Wait(500);
            FastDriver.InsuranceFire.SwitchToContentFrame();
            FastDriver.InsuranceFire.FireGABcode.FASetText("344");
            FastDriver.InsuranceFire.FireFind.FAClick();

            if (CreditSellerChk == "Yes" && (GetsecAmt == "K" || GetsecAmt == "M"))
            {
                string getcreditsellerchk = FastDriver.InsuranceFire.FireCreditSeller.Selected.ToString();// ProRationTax.GetControl("IIS.Insurance", "FireCreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.InsuranceFire.FireAmount.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "FireAmount").Get("Text").ToString();

                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(true);// ProRationTax.GetControl("IIS.Insurance", "FireCreditSeller").Set("checked", "True");
                    FastDriver.InsuranceFire.FirePer.FASelectItem("MONTH"); //ProRationTax.GetControl("IIS.Insurance", "FirePer").Set("selecteditem", "MONTH");
                    FastDriver.InsuranceFire.FireAmount.FASetText(Amt);// ProRationTax.GetControl("IIS.Insurance", "FireAmount").Set("text", Amt);
                    FastDriver.InsuranceFire.FireFromDate.FASetText(Fdate); //ProRationTax.GetControl("IIS.Insurance", "FireFromDate").Set("text", Fdate);
                    FastDriver.InsuranceFire.FireToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.Insurance", "FireToDate").Set("text", Tdate);
                    FastDriver.InsuranceFire.FireDescription.Click();
                    Playback.Wait(500);
                    FastDriver.InsuranceFire.FireDescription.FireEvent("onfocus");
                    Playback.Wait(500);
                    Keyboard.SendKeys("");
                    Playback.Wait(500);
                    Keyboard.SendKeys(Desc);
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);
                }
                if (GetsecAmt == "K")
                {
                    ret_Amt = FastDriver.InsuranceFire.FireBuyerCharge1.GetAttribute("value").ToString();// ProRationTax.GetControl("IIS.Insurance", "FireBuyerCharge1").Get("Text").ToString();
                }
                else if (GetsecAmt == "M")
                {
                    ret_Amt = FastDriver.InsuranceFire.FireSellerCredit1.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "FireSellerCredit1").Get("Text").ToString();
                }
            }

            else if (CreditSellerChk == "No" && (GetsecAmt == "L" || GetsecAmt == "N"))
            {
                string getcreditsellerchk = FastDriver.InsuranceFire.FireCreditSeller.Selected.ToString();// ProRationTax.GetControl("IIS.Insurance", "FireCreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.InsuranceFire.FireAmount.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "FireAmount").Get("Text").ToString();

                if (getcreditsellerchk == "True")
                {
                    FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(false); // ProRationTax.GetControl("IIS.Insurance", "FireCreditSeller").Set("checked", "false");
                    FastDriver.WebDriver.HandleDialogMessage(true, true); // GUI_Functions.GUI_Functions.IEMessage("OK");
                }
                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.InsuranceFire.FirePer.FASelectItem("MONTH");// ProRationTax.GetControl("IIS.Insurance", "FirePer").Set("selecteditem", "MONTH");
                    FastDriver.InsuranceFire.FireAmount.FASetText(Amt);// ProRationTax.GetControl("IIS.Insurance", "FireAmount").Set("text", Amt);
                    FastDriver.InsuranceFire.FireFromDate.FASetText(Fdate); //ProRationTax.GetControl("IIS.Insurance", "FireFromDate").Set("text", Fdate);
                    FastDriver.InsuranceFire.FireToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.Insurance", "FireToDate").Set("text", Tdate);
                    FastDriver.InsuranceFire.FireDescription.Click();
                    Playback.Wait(500);
                    //FastDriver.InsuranceFire.FireDescription.FireEvent("onfocus");
                    //Playback.Wait(500);
                    //Keyboard.SendKeys("");
                    //Keyboard.SendKeys("^A");
                    ////Playback.Wait(500);
                    //Playback.Wait(500);
                    Keyboard.SendKeys(Desc);
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);
                }
                if (GetsecAmt == "L")
                {
                    ret_Amt = FastDriver.InsuranceFire.FireBuyerCredit1.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "FireBuyerCredit1").Get("Text").ToString();
                }
                else if (GetsecAmt == "N")
                {
                    ret_Amt = FastDriver.InsuranceFire.FireSellerCharge1.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.Insurance", "FireSellerCharge1").Get("Text").ToString();
                }
            }
            return (ret_Amt);
        }

        public String homeowner_Data(string Desc, string Fdate, string Tdate, string Amt, String CreditSellerChk, string GetsecAmt)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->homeowner association ";
            FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Escrow Charge Processes>Homeowner Association").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.HomeownerAssociation.GABcode.FASetText("344");
            FastDriver.HomeownerAssociation.Find.FAClick();

            if (CreditSellerChk == "Yes" && (GetsecAmt == "K" || GetsecAmt == "M"))
            {
                string getcreditsellerchk = FastDriver.HomeownerAssociation.CreditSeller.Selected.ToString();// ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffCreditSellerler").Get("Checked").ToString();
                string getAmt = FastDriver.HomeownerAssociation.ProrationAmount.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffProration1Amount").Get("Text").ToString();

                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(true); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffCreditSellerler").Set("checked", "True");
                    FastDriver.HomeownerAssociation.Per.FASelectItem("MONTH"); //ProRationTax.GetControl("IIS.HomeownerAssociation", "CalculationPer").Set("selecteditem", "MONTH");
                    FastDriver.HomeownerAssociation.ProrationAmount.FASetText(Amt); //ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffProration1Amount").Set("text", Amt);
                    FastDriver.HomeownerAssociation.FromDate.FASetText(Fdate); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffProrationFromDate").Set("text", Fdate);
                    FastDriver.HomeownerAssociation.ToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.HomeownerAssociation", "CalculateProrationToDate").Set("text", Tdate);
                    FastDriver.HomeownerAssociation.ProrationDescription.Click();
                    Playback.Wait(500);
                    FastDriver.HomeownerAssociation.ProrationDescription.FireEvent("onfocus");
                    Playback.Wait(500);
                    Keyboard.SendKeys("");
                    Playback.Wait(500);
                    Keyboard.SendKeys(Desc);
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);

                }

                if (GetsecAmt == "K")
                {

                    ret_Amt = FastDriver.HomeownerAssociation.ProrationBuyerCharge.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffBuyerCharge").Get("Text").ToString();

                }

                if (GetsecAmt == "M")
                {
                    ret_Amt = FastDriver.HomeownerAssociation.ProrationSellerCredit.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffSellerCredit").Get("Text").ToString();

                }

            }
            else if (CreditSellerChk == "No" && (GetsecAmt == "L" || GetsecAmt == "N"))
            {
                string getcreditsellerchk = FastDriver.HomeownerAssociation.CreditSeller.Selected.ToString(); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffCreditSellerler").Get("Checked").ToString();
                string getAmt = FastDriver.HomeownerAssociation.ProrationAmount.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffProration1Amount").Get("Text").ToString();
                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.HomeownerAssociation.Per.FASelectItem("MONTH"); //ProRationTax.GetControl("IIS.HomeownerAssociation", "CalculationPer").Set("selecteditem", "MONTH");
                    FastDriver.HomeownerAssociation.ProrationAmount.FASetText(Amt); //ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffProration1Amount").Set("text", Amt);
                    FastDriver.HomeownerAssociation.FromDate.FASetText(Fdate); //ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffProrationFromDate").Set("text", Fdate);
                    FastDriver.HomeownerAssociation.ToDate.FASetText(Tdate); //ProRationTax.GetControl("IIS.HomeownerAssociation", "CalculateProrationToDate").Set("text", Tdate);
                    FastDriver.HomeownerAssociation.ProrationDescription.Click();
                    Playback.Wait(500);
                    //FastDriver.HomeownerAssociation.ProrationDescription.FireEvent("onfocus");
                    //Playback.Wait(500);
                    //Keyboard.SendKeys("");
                    Keyboard.SendKeys("^A");
                    //Playback.Wait(500);
                    Playback.Wait(500);
                    Keyboard.SendKeys(Desc);
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);

                }
                if (getcreditsellerchk == "True")
                {
                    FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(false); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffCreditSellerler").Set("checked", "false");
                    FastDriver.WebDriver.HandleDialogMessage(true, true); // GUI_Functions.GUI_Functions.IEMessage("OK");
                }
                if (GetsecAmt == "L")
                {

                    ret_Amt = FastDriver.HomeownerAssociation.ProrationBuyerCredit.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffBuyerCredit").Get("Text").ToString();

                }
                if (GetsecAmt == "N")
                {

                    ret_Amt = FastDriver.HomeownerAssociation.ProrationSellerCharge.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.HomeownerAssociation", "LienPayoffSellerCharge").Get("Text").ToString();

                }
            }

            return (ret_Amt);
        }

        public String Utility_Data(string Desc, string Fdate, string Tdate, string Amt, String CreditSellerChk, string GetsecAmt)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->Utility ";
            FastDriver.LeftNavigation.Navigate<UtilityDetail>(@"Home>Order Entry>Escrow Charge Processes>Utility").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.UtilityDetail.GABcode.FASetText("344");
            FastDriver.UtilityDetail.Find.FAClick();

            if (CreditSellerChk == "Yes" && (GetsecAmt == "K" || GetsecAmt == "M"))
            {
                string getcreditsellerchk = FastDriver.UtilityDetail.CreditSeller.Selected.ToString(); // ProRationTax.GetControl("IIS.UtilityDetail", "CreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.UtilityDetail.ProrationAmount.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.UtilityDetail", "ProrationAmount").Get("Text").ToString();

                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(true); // ProRationTax.GetControl("IIS.UtilityDetail", "CreditSeller").Set("checked", "True");
                    FastDriver.UtilityDetail.Per.FASelectItem("MONTH"); //ProRationTax.GetControl("IIS.UtilityDetail", "Per").Set("selecteditem", "MONTH");
                    FastDriver.UtilityDetail.ProrationAmount.FASetText(Amt);// ProRationTax.GetControl("IIS.UtilityDetail", "ProrationAmount").Set("text", Amt);
                    FastDriver.UtilityDetail.FromDate.FASetText(Fdate);// ProRationTax.GetControl("IIS.UtilityDetail", "FromDate").Set("text", Fdate);
                    FastDriver.UtilityDetail.ToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.UtilityDetail", "ToDate").Set("text", Tdate);
                    FastDriver.UtilityDetail.ProrationDescription.Click();
                    Playback.Wait(500);
                    FastDriver.UtilityDetail.ProrationDescription.FireEvent("onfocus");
                    Playback.Wait(500);
                    Keyboard.SendKeys("");
                    Playback.Wait(500);
                    Keyboard.SendKeys(Desc);
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);

                }
                if (GetsecAmt == "K")
                {
                    ret_Amt = FastDriver.UtilityDetail.ProrationBuyerCharge.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.UtilityDetail", "ProrationBuyerCharge").Get("Text").ToString();
                }
                else if (GetsecAmt == "M")
                {
                    ret_Amt = FastDriver.UtilityDetail.ProrationSellerCredit.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.UtilityDetail", "ProrationSellerCredit").Get("Text").ToString();
                }

            }
            else if (CreditSellerChk == "No" && (GetsecAmt == "L" || GetsecAmt == "N"))
            {
                string getcreditsellerchk = FastDriver.UtilityDetail.CreditSeller.Selected.ToString(); // ProRationTax.GetControl("IIS.UtilityDetail", "CreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.UtilityDetail.ProrationAmount.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.UtilityDetail", "ProrationAmount").Get("Text").ToString();

                if (getcreditsellerchk == "True")
                {
                    FastDriver.UtilityDetail.CreditSeller.FASetCheckbox(false); //ProRationTax.GetControl("IIS.UtilityDetail", "CreditSeller").Set("checked", "false");
                    FastDriver.WebDriver.HandleDialogMessage(true, true); // GUI_Functions.GUI_Functions.IEMessage("OK");
                }
                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.UtilityDetail.Per.FASelectItem("MONTH"); //ProRationTax.GetControl("IIS.UtilityDetail", "Per").Set("selecteditem", "MONTH");
                    FastDriver.UtilityDetail.ProrationAmount.FASetText(Amt); //ProRationTax.GetControl("IIS.UtilityDetail", "ProrationAmount").Set("text", Amt);
                    FastDriver.UtilityDetail.FromDate.FASetText(Fdate); // ProRationTax.GetControl("IIS.UtilityDetail", "FromDate").Set("text", Fdate);
                    FastDriver.UtilityDetail.ToDate.FASetText(Tdate);// ProRationTax.GetControl("IIS.UtilityDetail", "ToDate").Set("text", Tdate);
                    while (true)
                    {
                        FastDriver.UtilityDetail.ProrationDescription.Click();
                        Playback.Wait(500);
                        Keyboard.SendKeys(Desc);
                        Playback.Wait(500);
                        Keyboard.SendKeys(FAKeys.TabAway);
                        Playback.Wait(500);
                        if (FastDriver.UtilityDetail.ProrationDescription.GetAttribute("value").Clean() == Desc)
                            break;
                    }

                }

                if (GetsecAmt == "L")
                {
                    ret_Amt = FastDriver.UtilityDetail.ProrationBuyerCredit.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.UtilityDetail", "ProrationBuyerCredit").Get("Text").ToString();

                }
                else if (GetsecAmt == "N")
                {
                    ret_Amt = FastDriver.UtilityDetail.ProrationSellerCharge.GetAttribute("value").ToString(); // ProRationTax.GetControl("IIS.UtilityDetail", "ProrationSellerCharge").Get("Text").ToString();
                }
            }

            return (ret_Amt);
        }

        public String other_Proration_Rdata(string Desc, string Fdate, string Tdate, string Amt, String CreditSellerChk, string GetsecAmt)
        {

            Reports.TestStep = "Creating Proration charges in Escrow charge->proration->Rent Screen";
            FastDriver.LeftNavigation.Navigate<ProrationTax>(@"Home>Order Entry>Escrow Charge Processes>Proration>Rent").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.ProrationTax.New.FAClick();

            FastDriver.ProrationDetail.SwitchToContentFrame();

            if (CreditSellerChk == "Yes" && (GetsecAmt == "K" || GetsecAmt == "M"))
            {
                string getcreditsellerchk = FastDriver.ProrationDetail.CreditSeller.Selected.ToString(); // ProrationDetail.GetControl("IIS.ProrationDetail", "CreditSeller").Get("Checked").ToString();
                string getAmt = FastDriver.ProrationDetail.Amount.GetAttribute("value").ToString(); // ProrationDetail.GetControl("IIS.ProrationDetail", "Amount").Get("Text").ToString();
                string getBuyerCredit = FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString(); // ProrationDetail.GetControl("IIS.ProrationDetail", "BuyerCredit").Get("Text").ToString();

                if (getcreditsellerchk == "False" && getAmt == "")
                {
                    FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true); // ProrationDetail.GetControl("IIS.ProrationDetail", "CreditSeller").Set("checked", "True");
                    FastDriver.ProrationDetail.Per.FASelectItem("MONTH");// ProrationDetail.GetControl("IIS.ProrationDetail", "Per").Set("selecteditem", "MONTH");
                    FastDriver.ProrationDetail.Amount.FASetText(Amt); // ProrationDetail.GetControl("IIS.ProrationDetail", "Amount").Set("text", Amt);
                    FastDriver.ProrationDetail.FromDate.FASetText(Fdate); // ProrationDetail.GetControl("IIS.ProrationDetail", "FromDate").Set("text", Fdate);
                    FastDriver.ProrationDetail.ToDate.FASetText(Tdate);  //ProrationDetail.GetControl("IIS.ProrationDetail", "ToDate").Set("text", Tdate);
                    FastDriver.ProrationDetail.Description.Click();
                    Playback.Wait(500);
                    FastDriver.ProrationDetail.Description.FireEvent("onfocus");
                    Playback.Wait(500);
                    Keyboard.SendKeys("");
                    Playback.Wait(500);
                    Keyboard.SendKeys(Desc);
                    Playback.Wait(5000);
                    Keyboard.SendKeys(FAKeys.TabAway);
                    Playback.Wait(2000);


                }
                else if (getcreditsellerchk == "False" && getAmt != "" && getBuyerCredit != null)
                {
                    FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(true);// ProrationDetail.GetControl("IIS.ProrationDetail", "CreditSeller").Set("checked", "true");
                    FastDriver.WebDriver.HandleDialogMessage(true, true); // GUI_Functions.GUI_Functions.IEMessage("OK");
                }
                if (GetsecAmt == "K")
                {
                    ret_Amt = FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString(); // ProrationDetail.GetControl("IIS.ProrationDetail", "BuyerCharge").Get("Text").ToString();
                }
                if (GetsecAmt == "M")
                {
                    ret_Amt = FastDriver.ProrationDetail.SellerCredit.GetAttribute("value").ToString(); // ProrationDetail.GetControl("IIS.ProrationDetail", "SellerCredit").Get("Text").ToString();
                }
            }
            else if (CreditSellerChk == "No" && (GetsecAmt == "L" || GetsecAmt == "N"))
            {
                string getcreditsellerchk = FastDriver.ProrationDetail.CreditSeller.Selected.ToString(); // ProrationDetail.GetControl("IIS.ProrationDetail", "CreditSeller").Get("Checked").ToString();
                string getBuyerCharge = FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString(); // ProrationDetail.GetControl("IIS.ProrationDetail", "BuyerCharge").Get("Text").ToString();

                if (getcreditsellerchk == "True")
                {
                    FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(false);// ProrationDetail.GetControl("IIS.ProrationDetail", "CreditSeller").Set("checked", "false");
                    FastDriver.WebDriver.HandleDialogMessage(true, true); // GUI_Functions.GUI_Functions.IEMessage("OK");
                }
                if (getcreditsellerchk == "False")
                {
                    FastDriver.ProrationDetail.Per.FASelectItem("MONTH"); // ProrationDetail.GetControl("IIS.ProrationDetail", "Per").Set("selecteditem", "MONTH");
                    FastDriver.ProrationDetail.Amount.FASetText(Amt); //ProrationDetail.GetControl("IIS.ProrationDetail", "Amount").Set("text", Amt);
                    FastDriver.ProrationDetail.FromDate.FASetText(Fdate); //ProrationDetail.GetControl("IIS.ProrationDetail", "FromDate").Set("text", Fdate);
                    FastDriver.ProrationDetail.ToDate.FASetText(Tdate);  //ProrationDetail.GetControl("IIS.ProrationDetail", "ToDate").Set("text", Tdate);
                    while (true)
                    {
                        FastDriver.ProrationDetail.Description.Click();
                        Playback.Wait(500);
                        Keyboard.SendKeys(Desc);
                        Playback.Wait(500);
                        Keyboard.SendKeys(FAKeys.TabAway);
                        Playback.Wait(500);
                        if (FastDriver.ProrationDetail.Description.GetAttribute("value").Clean() == Desc)
                            break;
                    }
                    
                }
                if (GetsecAmt == "L")
                {
                    ret_Amt = FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString(); // ProrationDetail.GetControl("IIS.ProrationDetail", "BuyerCredit").Get("Text").ToString();
                }
                if (GetsecAmt == "N")
                {
                    ret_Amt = FastDriver.ProrationDetail.SellerCharge.GetAttribute("value").ToString(); // ProrationDetail.GetControl("IIS.ProrationDetail", "SellerCharge").Get("Text").ToString();
                }

            }
            return (ret_Amt);
        }

        #endregion

        #region function to enter data for other proration's rent , miscellaneous

        public void other_Proration_data(string Desc, string Fdate, string Tdate, string Amt)
        {
            FastDriver.ProrationTax.SwitchToContentFrame();
            FastDriver.ProrationTax.New.FAClick();
            FastDriver.ProrationDetail.SwitchToContentFrame();
            FastDriver.ProrationDetail.Per.FASelectItem("MONTH");
            FastDriver.ProrationDetail.Amount.FASetText(Amt);
            FastDriver.ProrationDetail.FromDate.FASetText(Fdate);
            FastDriver.ProrationDetail.ToDate.FASetText(Tdate);
            FastDriver.ProrationDetail.Description.FASetText(Desc);
            Keyboard.SendKeys(FAKeys.TabAway);
            buyerCredits.Add(FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString().Trim());
            sum += Convert.ToDouble(Convert.ToDouble(FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString().Trim()));
            FastDriver.BottomFrame.Done();
            
        }

        #endregion

        #region function to enter utility proration charges

        public void Utility_Data(string gabCode, string Desc, string Fdate, string Tdate, string Amt)
        {
            FastDriver.BottomFrame.New();
            FastDriver.UtilityDetail.SwitchToContentFrame();
            FastDriver.UtilityDetail.GABcode.FASetText(gabCode);
            FastDriver.UtilityDetail.Find.FAClick();
            FastDriver.UtilityDetail.Per.FASelectItem("MONTH");
            FastDriver.UtilityDetail.ProrationAmount.FASetText(Amt);
            FastDriver.UtilityDetail.FromDate.FASetText(Fdate);
            FastDriver.UtilityDetail.ToDate.FASetText(Tdate);
            Keyboard.SendKeys(FAKeys.TabAway);
            while (true)
            {
                FastDriver.UtilityDetail.ProrationDescription.Click();
                Playback.Wait(500);
                Keyboard.SendKeys(Desc);
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                if (FastDriver.UtilityDetail.ProrationDescription.GetAttribute("value").Clean() == Desc)
                    break;
            }
                        
            buyerCredits.Add(FastDriver.UtilityDetail.ProrationBuyerCredit.GetAttribute("value").ToString().Trim());
            sum += Convert.ToDouble(Convert.ToDouble(FastDriver.UtilityDetail.ProrationBuyerCredit.GetAttribute("value").ToString().Trim()));
            FastDriver.BottomFrame.Done();
            FastDriver.UtilityDetail.SwitchToContentFrame();
                
        }
        
        #endregion

        #region function to enter assumtion loan charges

        public void Assumption_Loan_data(string gabCode, string Fdate, string Tdate, string Amt)
        {
            FastDriver.BottomFrame.New();
            FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
            FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText(gabCode);
            FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
            FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
            Playback.Wait(3000);
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
            FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText(Amt);
            FastDriver.AssumptionLoanCharges.InterestProrationInterestType.FASelectItem("Adjustable Interest Rate");
            FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FASetText(Fdate);
            FastDriver.AssumptionLoanCharges.InterestProrationToDate.FASetText(Tdate);
            Keyboard.SendKeys(FAKeys.TabAway);
            buyerCredits.Add(FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.GetAttribute("value").ToString().Trim());
            FastDriver.BottomFrame.Done();
            sum += Convert.ToDouble(Amt);

        }

        #endregion

        #region function to enter homeowner association data

        public void homeowner_Data(string gabCode, string Desc, string Fdate, string Tdate, string Amt)
        {
            FastDriver.BottomFrame.New();
            FastDriver.HomeownerAssociation.SwitchToContentFrame();
            FastDriver.HomeownerAssociation.GABcode.FASetText(gabCode);
            FastDriver.HomeownerAssociation.Find.FAClick();
            FastDriver.HomeownerAssociation.Per.FASelectItem("MONTH");
            FastDriver.HomeownerAssociation.ProrationAmount.FASetText(Amt);
            FastDriver.HomeownerAssociation.FromDate.FASetText(Fdate);
            FastDriver.HomeownerAssociation.ToDate.FASetText(Tdate);
            while (true)
            {
                FastDriver.HomeownerAssociation.ProrationDescription.Click();
                Playback.Wait(500);
                Keyboard.SendKeys(Desc);
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                if (FastDriver.HomeownerAssociation.ProrationDescription.GetAttribute("value").Clean() == Desc)
                    break;
            }
            //FastDriver.HomeownerAssociation.ProrationDescription.FASetText(Desc);
            buyerCredits.Add(FastDriver.HomeownerAssociation.ProrationBuyerCredit.GetAttribute("value").ToString().Trim());
            sum += Convert.ToDouble(Convert.ToDouble(FastDriver.HomeownerAssociation.ProrationBuyerCredit.GetAttribute("value").ToString().Trim()));
            FastDriver.BottomFrame.Done();
        }

        #endregion

        #region function to enter insurance data

        public void insurance_Data(string gabCode, string Desc, string Fdate, string Tdate, string Amt)
        {
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>(@"Home>Order Entry>Escrow Charge Processes>Insurance").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.InsuranceSummary.SummaryNew.FAClick();
            Playback.Wait(2000);
            FastDriver.InsuranceOther.SwitchToContentFrame();
            FastDriver.InsuranceOther.OtherGABcode.FASetText(gabCode);
            FastDriver.InsuranceOther.OtherFind.FAClick();
            FastDriver.InsuranceOther.OtherAmount.FASetText(Amt);
            FastDriver.InsuranceOther.OtherPer.FASelectItem("MONTH");
            FastDriver.InsuranceOther.OtherFromDate.FASetText(Fdate);
            FastDriver.InsuranceOther.OtherToDate.FASetText(Tdate);
            while (true)
            {
                FastDriver.InsuranceOther.OtherDescription.Click();
                Playback.Wait(500);
                Keyboard.SendKeys(Desc);
                Playback.Wait(500);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(500);

                if (FastDriver.InsuranceOther.OtherDescription.GetAttribute("value").Clean() == Desc)
                    break;
            }
            buyerCredits.Add(FastDriver.InsuranceOther.OtherBuyerCredit1.GetAttribute("value").ToString().Trim());
            sum += Convert.ToDouble(Amt);

        }

        #endregion

        #region function to verify supplementary line charges

        public void Supp_Line_Verification(String SectionName, double Amt)
        {

            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure").SwitchToContentFrame();
            Playback.Wait(2000);
            FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
            Playback.Wait(3000);
            double total = 0.0;
            double adjAmt = 0.0;

            if (buyerCredits.Count > 3)
            {
                //int temp = (int)System.Math.Round((double)(buyerCredits.Count / 2), 0);
                //int temp = buyerCredits.Count - 2;
                System.Collections.Generic.List<double> charges = new System.Collections.Generic.List<double>();
                foreach (var charge in buyerCredits)
	            {
                    charges.Add(Double.Parse(charge));
	            }
                foreach (var charge in charges)
                {
                    total += charge;
                }
                adjAmt = total - (2 * 300000);
            }


            Reports.TestStep = "verifying Supplementary line serial no";
            if (SectionName == "Section M")
            {
                if (FastDriver.ClosingDisclosure.SectionM16_Seqno.Text.Trim() == "16")
                    Reports.StatusUpdate("the value Supplementary line no  is verifed." + "Actual=" + FastDriver.ClosingDisclosure.SectionM16_Seqno.Text + " Expected=" + "16" + " ", true);
                else
                    Reports.StatusUpdate("the value Supplementary line no not matching ." + "Actual=" + FastDriver.ClosingDisclosure.SectionM16_Seqno.Text + " Expected=" + "16" + " ", false);
                Reports.TestStep = "verifying  Supplementary line description";
                var s2 = FastDriver.ClosingDisclosure.SectionM_AdjustmentforItemsSubTable.PerformTableAction(9, 2, TableAction.GetCell).Element.FindElement(By.TagName("span"));
                if (s2.Text.Trim() == "See attached page for additional information")
                    Reports.StatusUpdate("The value Description is verifed." + "Actual=" + s2.Text.Trim() + " Expected=" + "See attached page for additional information ", true);
                else
                    Reports.StatusUpdate("The value Description not matching." + "Actual=" + s2.Text.Trim() + " Expected=" + "See attached page for additional information ", false);
                Reports.TestStep = "verifying Supplementary line sum charges";
                System.Collections.Generic.List<string> charges = FastDriver.ClosingDisclosure.getTotalCreditChargeAmountFromAdjForItemsTable();

                String tmp = (charges.ElementAt(2).Replace(",", "")).Replace("$", "").Trim();

                double amt1 = double.Parse(tmp);
                if (amt1 == adjAmt)
                    Reports.StatusUpdate("the value amt is verifed." + "Actual=" + amt1 + " Expected=" + adjAmt + " ", true);
                else
                    Reports.StatusUpdate("the value amt not matching ." + "Actual=" + amt1 + " Expected=" + adjAmt + " ", false);

            }
            if (SectionName == "Section L")
            {
                if (FastDriver.ClosingDisclosure.SectionL17_SeqNo.Text.Trim() == "17")
                    Reports.StatusUpdate("the value Supplementary line no  is verifed." + "Actual=" + FastDriver.ClosingDisclosure.SectionL17_SeqNo.Text + " Expected=" + "17" + " ", true);
                else
                    Reports.StatusUpdate("the value Supplementary line no not matching ." + "Actual=" + FastDriver.ClosingDisclosure.SectionL17_SeqNo.Text + " Expected=" + "17" + " ", false);
                Reports.TestStep = "verifying  Supplementary line description";
                var s2 = FastDriver.ClosingDisclosure.SectionL_AdjustmentforItemsSubTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FindElement(By.TagName("span"));
                if (s2.Text.Trim() == "See attached page for additional information")
                    Reports.StatusUpdate("The value Description is verifed." + "Actual=" + s2.Text.Trim() + " Expected=" + "See attached page for additional information ", true);
                else
                    Reports.StatusUpdate("The value Description not matching." + "Actual=" + s2.Text.Trim() + " Expected=" + "See attached page for additional information ", false);
                Reports.TestStep = "verifying Supplementary line sum charges";
                System.Collections.Generic.List<string> charges = FastDriver.ClosingDisclosure.getTotalCreditChargeAmountFromAdjForItemsTable();

                String tmp = (charges.ElementAt(2).Replace(",", "")).Replace("$", "").Trim();
                
                double amt1 = double.Parse(tmp);
                if (amt1 == adjAmt)
                    Reports.StatusUpdate("the value amt is verifed." + "Actual=" + amt1 + " Expected=" + adjAmt + " ", true);
                else
                    Reports.StatusUpdate("the value amt not matching ." + "Actual=" + amt1 + " Expected=" + adjAmt + " ", false);

            }
            if (SectionName == "Section N")
            {
                if (FastDriver.ClosingDisclosure.SectionN19_Seqno.Text.Trim() == "19")
                    Reports.StatusUpdate("the value Supplementary line no  is verifed." + "Actual=" + FastDriver.ClosingDisclosure.SectionN19_Seqno.Text + " Expected=" + "19" + " ", true);
                else
                    Reports.StatusUpdate("the value Supplementary line no not matching ." + "Actual=" + FastDriver.ClosingDisclosure.SectionN19_Seqno.Text + " Expected=" + "19" + " ", false);
                Reports.TestStep = "verifying  Supplementary line description";
                var s2 = FastDriver.ClosingDisclosure.SectionN_AdjustmentforItemsSubTable.PerformTableAction(7, 2, TableAction.GetCell).Element.FindElement(By.TagName("span"));
                if (s2.Text.Trim() == "See attached page for additional information")
                    Reports.StatusUpdate("The value Description is verifed." + "Actual=" + s2.Text.Trim() + " Expected=" + "See attached page for additional information ", true);
                else
                    Reports.StatusUpdate("The value Description not matching." + "Actual=" + s2.Text.Trim() + " Expected=" + "See attached page for additional information ", false);
                Reports.TestStep = "verifying Supplementary line sum charges";
                System.Collections.Generic.List<string> charges = FastDriver.ClosingDisclosure.getTotalCreditChargeAmountFromAdjForItemsTable();

                String tmp = (charges.ElementAt(2).Replace(",", "")).Replace("$", "").Trim();

                double amt1 = double.Parse(tmp);
                if (amt1 == adjAmt)
                    Reports.StatusUpdate("the value amt is verifed." + "Actual=" + amt1 + " Expected=" + adjAmt + " ", true);
                else
                    Reports.StatusUpdate("the value amt not matching ." + "Actual=" + amt1 + " Expected=" + adjAmt + " ", false);

            }
        }

        #endregion function to verify supplementary line charges

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
