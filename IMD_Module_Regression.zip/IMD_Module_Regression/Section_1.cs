﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using System.IO;
using System.Runtime.Serialization;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium;
using AutoIt;
using System.Collections.ObjectModel;



namespace IMD_Module_Regression
{
    [CodedUITest]
    public class Section_1 : MasterTestClass
    {
        #region Variable declaration
        string[] sellerdetail = new string[10];
        string[] buyerdetail = new string[10];
        string[] oecdetail = new string[3];
        string[] otcdetail = new string[3];
        string[] owningoffice = new string[11];
        string[] splitpayee1 = new string[5];
        string[] splitpayee2 = new string[5];

        string[] firstaddress = new string[7];
        string[] firstaddress_al1 = new string[7];
        string[] firstaddress_al2 = new string[7];
        string[] secondaddress = new string[7];
        string[] secondaddress_al1 = new string[7];



        #endregion

        #region 261873- CD Screen - Section 1 - Multiple Sellers Under Transaction Information

        [TestMethod]
        public void US_261873_TC_345672_NO_01()
        {
            try
            {

                Reports.TestDescription = "Verify that the Seller information is getting displayed in the CD screen Seller Popup";
                Reports.TestStep = "Login to file side";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Creating Order
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                //Creating First Seller
                Reports.TestStep = "Creating First Seller";
                Seller("SellerName", "SellerLastName", 1);
                //Navigate to CD Screen
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                //Navigate to CD Seller Popup
                Reports.TestStep = "Navigate to CD Seller Popup";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.SellerPlus.FAClick();
                //Validating Seller Details
                Reports.TestStep = "Validating Seller Details";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                var name = FastDriver.ClosingDisclosure.SellerName.Text;
                Support.AreEqual("True", name.Contains(sellerdetail[0]).ToString());
                Support.AreEqual("True", name.Contains(sellerdetail[1]).ToString());

                string CTable = FastDriver.CDSellerInfo.Seller1CATable.Text;
                Support.AreEqual("True", CTable.Contains(sellerdetail[2]).ToString());
                Support.AreEqual("True", CTable.Contains(sellerdetail[3]).ToString());
                Support.AreEqual("True", CTable.Contains(sellerdetail[4]).ToString());
                Support.AreEqual("True", CTable.Contains(sellerdetail[5]).ToString());
                Support.AreEqual("True", CTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable.Contains("CA").ToString());
                Support.AreEqual("True", CTable.Contains("88888").ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Selected.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Selected.ToString());
                //Done
                FastDriver.CDSellerInfo.Done.FAClick();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }



        }

        [TestMethod]
        public void US_261873_TC_345673_NO_02()
        {
            try
            {
                Reports.TestDescription = "Change the Seller Address option in popup and verify in CD Screen";
                Reports.TestStep = "Login to file side";

                //Login
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Create new order
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);

                //Creating First Seller
                Reports.TestStep = "Creating First Seller";
                Seller("SellerName", "SellerLastName", 1);

                //Navigate to CD Screen
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");

                //Navigate to CD Seller Popup
                Reports.TestStep = "Navigate to CD Seller Popup";

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.SellerPlus.FAClick();


                //Validating Seller Details
                Reports.TestStep = "Validating Seller Details";
                var name = FastDriver.ClosingDisclosure.SellerName.Text;
                Support.AreEqual("True", name.Contains(sellerdetail[0]).ToString());
                Support.AreEqual("True", name.Contains(sellerdetail[1]).ToString());
                string CTable = FastDriver.CDSellerInfo.Seller1CATable.Text;
                Support.AreEqual("True", CTable.Contains(sellerdetail[2]).ToString());
                Support.AreEqual("True", CTable.Contains(sellerdetail[3]).ToString());
                Support.AreEqual("True", CTable.Contains(sellerdetail[4]).ToString());
                Support.AreEqual("True", CTable.Contains(sellerdetail[5]).ToString());
                Support.AreEqual("True", CTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable.Contains("CA").ToString());
                Support.AreEqual("True", CTable.Contains("88888").ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Selected.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Selected.ToString());

                Reports.TestStep = "Changing the Seller Address to display in CD Screen";
                FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.FAClick();
                string FTable = FastDriver.CDSellerInfo.Seller1FATable.Text;
                Support.AreEqual("True", FTable.Contains(sellerdetail[6]).ToString());
                Support.AreEqual("True", FTable.Contains(sellerdetail[7]).ToString());
                Support.AreEqual("True", FTable.Contains(sellerdetail[8]).ToString());
                Support.AreEqual("True", FTable.Contains(sellerdetail[9]).ToString());
                Support.AreEqual("True", FTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", FTable.Contains("CA").ToString());
                Support.AreEqual("True", FTable.Contains("92727").ToString());

                //Done
                FastDriver.CDSellerInfo.Done.FAClick();
                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void US_261873_TC_345676_NO_04()
        {
            try
            {

                Reports.TestDescription = "When no Forwarding Address is entered for seller verify blank is displayed in CD Screen popup";
                Reports.TestStep = "Login to file side";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Creating Order
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Seller_SpAddress("IndividualFirstName", "IndividualLastName", "current");
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");

                Reports.TestStep = "Navigate to CD Seller Popup";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.SellerPlus.FAClick();

                Reports.TestStep = "Validating Seller Details";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                string name = FastDriver.ClosingDisclosure.TableSeller1Name.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                name = name.Replace("*", "");
                Support.AreEqual("True", name.Contains(sellerdetail[0]).ToString());
                Support.AreEqual("True", name.Contains(sellerdetail[1]).ToString());
                string CTable = FastDriver.CDSellerInfo.Seller1CATable.Text;
                Support.AreEqual("True", CTable.Contains(sellerdetail[2]).ToString());
                Support.AreEqual("True", CTable.Contains(sellerdetail[3]).ToString());
                Support.AreEqual("True", CTable.Contains(sellerdetail[4]).ToString());
                Support.AreEqual("True", CTable.Contains(sellerdetail[5]).ToString());
                Support.AreEqual("True", CTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable.Contains("CA").ToString());
                Support.AreEqual("True", CTable.Contains("88888").ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Selected.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Selected.ToString());

                Reports.TestStep = "Validating forwarding address does not exists";
                FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.FAClick();

                Support.AreEqual("", FastDriver.CDSellerInfo.Seller1FATable.Text);

                FastDriver.CDSellerInfo.Done.FAClick();

                Reports.TestStep = "validating the Seller Forwarding Address in CD Screen";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                string cdname = FastDriver.ClosingDisclosure.SellerName.Text;
                cdname = cdname.Replace("*", "");
                Support.AreEqual("True", cdname.Contains(sellerdetail[0]).ToString());
                Support.AreEqual("False", cdname.Contains(sellerdetail[1]).ToString());


                //Closing dialog and saving
                FastDriver.CDSellerInfo.Done.FAClick();
                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_261873_TC_345677_NO_05()
        {

            try
            {



                Reports.TestDescription = "Verify system dispalys only State in CD screen ,when there is no current address in file and user selects Current Address option in pop up";
                Reports.TestStep = "Login to file side";

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Creating Order
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                Seller_SpAddress("IndividualFirstName", "IndividualLastName", "forwarding");

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");

                Reports.TestStep = "Navigate to CD Seller Popup";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.SellerPlus.FAClick();

                Reports.TestStep = "Validating Seller Details";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                string name = FastDriver.ClosingDisclosure.TableSeller1Name.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                name = name.Replace("*", "");
                Support.AreEqual("True", name.Contains(sellerdetail[0]).ToString());
                Support.AreEqual("True", name.Contains(sellerdetail[1]).ToString());

                string CTable = FastDriver.CDSellerInfo.Seller1CATable.Text;
                Support.AreEqual("True", CTable.Contains("CA").ToString());

                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Selected.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Selected.ToString());

                Reports.TestStep = "Changing the Seller Address to display in CD Screen";
                FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.FAClick();
                string FTable = FastDriver.CDSellerInfo.Seller1FATable.Text;
                Support.AreEqual("True", FTable.Contains(sellerdetail[2]).ToString());
                Support.AreEqual("True", FTable.Contains(sellerdetail[3]).ToString());
                Support.AreEqual("True", FTable.Contains(sellerdetail[4]).ToString());
                Support.AreEqual("True", FTable.Contains(sellerdetail[5]).ToString());
                Support.AreEqual("True", FTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", FTable.Contains("CA").ToString());
                Support.AreEqual("True", FTable.Contains("92727").ToString());

                FastDriver.CDSellerInfo.Done.FAClick();

                Reports.TestStep = "validating the Seller Forwarding Address in CD Screen";

                //FastDriver.ClosingDisclosure.SwitchToContentFrame();
                string cdname = FastDriver.ClosingDisclosure.SellerName.Text;
                cdname = cdname.Replace("*", "");
                Support.AreEqual("True", cdname.Contains(sellerdetail[0]).ToString());
                Support.AreEqual("False", cdname.Contains(sellerdetail[1]).ToString());

                string cdfstreet = FastDriver.ClosingDisclosure.lblSellerAddr.Text;
                Support.AreEqual("True", cdfstreet.Contains(sellerdetail[2]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(sellerdetail[3]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(sellerdetail[4]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(sellerdetail[5]).ToString());

                string cdfcsz = FastDriver.ClosingDisclosure.lblSellerCSZ.Text;
                Support.AreEqual("True", cdfcsz.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdfcsz.Contains("CA").ToString());
                Support.AreEqual("True", cdfcsz.Contains("92727").ToString());

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_261873_TC_345685_NO_07()
        {
            try
            {


                Reports.TestDescription = "Verify multiple Seller information is getting displayed in the CD screen Seller Popup";
                Reports.TestStep = "Login to file side";

                //Login
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Create new order
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);

                //Creating First Seller
                Reports.TestStep = "Creating First Seller";
                Seller("SellerName", "SellerLastName", 1);

                string[] sellerdetail1 = new string[10];
                Array.Copy(sellerdetail, sellerdetail1, 10);
                Reports.TestStep = "Creating Second Seller";

                Seller("SFName2", "SLName2", 2);
                string[] sellerdetail2 = new string[10];
                Array.Copy(sellerdetail, sellerdetail2, 10);
                Reports.TestStep = "Creating Third Seller";

                Seller("SFName3", "SLName3", 3);
                string[] sellerdetail3 = new string[10];
                Array.Copy(sellerdetail, sellerdetail3, 10);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");

                Reports.TestStep = "Navigate to CD Seller Popup";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.SellerPlus.FAClick();


                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Reports.TestStep = "Validating Seller Details";
                string name1 = FastDriver.ClosingDisclosure.TableSeller1Name.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name1.Contains(sellerdetail1[0]).ToString());
                Support.AreEqual("True", name1.Contains(sellerdetail1[1]).ToString());

                string CTable1 = FastDriver.CDSellerInfo.Seller1CATable.Text;
                Support.AreEqual("True", CTable1.Contains(sellerdetail1[2]).ToString());
                Support.AreEqual("True", CTable1.Contains(sellerdetail1[3]).ToString());
                Support.AreEqual("True", CTable1.Contains(sellerdetail1[4]).ToString());
                Support.AreEqual("True", CTable1.Contains(sellerdetail1[5]).ToString());
                Support.AreEqual("True", CTable1.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable1.Contains("CA").ToString());
                Support.AreEqual("True", CTable1.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Selected.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Selected.ToString());

                string name2 = FastDriver.ClosingDisclosure.TableSeller1Name.PerformTableAction(1, "2", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name2.Contains(sellerdetail2[0]).ToString());
                Support.AreEqual("True", name2.Contains(sellerdetail2[1]).ToString());

                string CTable2 = FastDriver.CDSellerInfo.Seller2CATable.Text;
                Support.AreEqual("True", CTable2.Contains(sellerdetail2[2]).ToString());
                Support.AreEqual("True", CTable2.Contains(sellerdetail2[3]).ToString());
                Support.AreEqual("True", CTable2.Contains(sellerdetail2[4]).ToString());
                Support.AreEqual("True", CTable2.Contains(sellerdetail2[5]).ToString());
                Support.AreEqual("True", CTable2.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable2.Contains("CA").ToString());
                Support.AreEqual("True", CTable2.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Selected.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Selected.ToString());

                string name3 = FastDriver.ClosingDisclosure.TableSeller1Name.PerformTableAction(1, "3", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name3.Contains(sellerdetail3[0]).ToString());
                Support.AreEqual("True", name3.Contains(sellerdetail3[1]).ToString());

                string CTable3 = FastDriver.CDSellerInfo.Seller3CATable.Text;
                Support.AreEqual("True", CTable3.Contains(sellerdetail3[2]).ToString());
                Support.AreEqual("True", CTable3.Contains(sellerdetail3[3]).ToString());
                Support.AreEqual("True", CTable3.Contains(sellerdetail3[4]).ToString());
                Support.AreEqual("True", CTable3.Contains(sellerdetail3[5]).ToString());
                Support.AreEqual("True", CTable3.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable3.Contains("CA").ToString());
                Support.AreEqual("True", CTable3.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1CurrentAddrRadioButton.Selected.ToString());
                Support.AreEqual("True", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSellerInfo.Seller1ForwardingAddrRadioButton.Selected.ToString());

                Reports.TestStep = "Closing CD Screen";
                FastDriver.CDSellerInfo.Done.FAClick();


                string cdname = FastDriver.ClosingDisclosure.SellerName.Text;
                cdname = cdname.Replace("*", "");
                Support.AreEqual("True", cdname.Contains(sellerdetail1[0]).ToString());
                Support.AreEqual("True", cdname.Contains(sellerdetail1[1]).ToString());

                string cdfstreet = FastDriver.ClosingDisclosure.lblSellerAddr.Text;
                Support.AreEqual("True", cdfstreet.Contains(sellerdetail1[2]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(sellerdetail1[3]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(sellerdetail1[4]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(sellerdetail1[5]).ToString());

                string cdfcsz = FastDriver.ClosingDisclosure.lblSellerCSZ.Text;
                Support.AreEqual("True", cdfcsz.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdfcsz.Contains("CA").ToString());
                Support.AreEqual("True", cdfcsz.Contains("88888").ToString());

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Deleting first seller record";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Sellers");
                FastDriver.BuyerSellerSummary.WaitForBuyerSellerSummaryTableLoad();
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("#1", "1", "#1", TableAction.Click);

                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validating the CD Screen will display the Second Seller";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                string cdname1 = FastDriver.ClosingDisclosure.SellerName.Text;
                cdname1 = cdname1.Replace("*", "");
                Support.AreEqual("True", cdname1.Contains(sellerdetail2[0]).ToString());
                Support.AreEqual("True", cdname1.Contains(sellerdetail2[1]).ToString());

                string cdfstreet1 = FastDriver.ClosingDisclosure.lblSellerAddr.Text;
                Support.AreEqual("True", cdfstreet1.Contains(sellerdetail2[2]).ToString());
                Support.AreEqual("True", cdfstreet1.Contains(sellerdetail2[3]).ToString());
                Support.AreEqual("True", cdfstreet1.Contains(sellerdetail2[4]).ToString());
                Support.AreEqual("True", cdfstreet1.Contains(sellerdetail2[5]).ToString());

                string cdfcsz1 = FastDriver.ClosingDisclosure.lblSellerCSZ.Text;
                Support.AreEqual("True", cdfcsz1.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdfcsz1.Contains("CA").ToString());
                Support.AreEqual("True", cdfcsz1.Contains("88888").ToString());

                Reports.TestStep = "Validating the Seller Popup will not display the First Seller";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.SellerPlus.FAClick();

                string name4 = FastDriver.ClosingDisclosure.TableSeller1Name.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("False", name4.Contains(sellerdetail1[0]).ToString());
                Support.AreEqual("False", name4.Contains(sellerdetail1[1]).ToString());

                string CTable4 = FastDriver.CDSellerInfo.Seller1CATable.Text;
                Support.AreEqual("False", CTable4.Contains(sellerdetail1[2]).ToString());
                Support.AreEqual("False", CTable4.Contains(sellerdetail1[3]).ToString());
                Support.AreEqual("False", CTable4.Contains(sellerdetail1[4]).ToString());
                Support.AreEqual("False", CTable4.Contains(sellerdetail1[5]).ToString());

                var rowCnt = FastDriver.WebDriver.FindElements(By.CssSelector("table#tblSellerDetails > tbody > tr")).Count;
                Support.AreEqual("2", rowCnt.ToString());

                Reports.TestStep = "Closing the Seller Popup Screen";
                FastDriver.CDSellerInfo.Done.FAClick();

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void US_261873_TC_355376_NO_09()
        {
            try
            {
                Reports.TestDescription = "Verify multiple Seller information is getting displayed in the CD screen Seller Popup";
                Reports.TestStep = "Login to file side";

                //Login
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Create new order
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Sellers");

                FastDriver.BuyerSellerSummary.WaitForBuyerSellerSummaryTableLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("#1", "1", "#1", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();

                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText("Name1");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText("Name2");


                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                if (FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem() != "USA")
                {
                    FastDriver.BuyerSellerSetup.CurrentCountry.FASelectItem("USA");
                }
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(Support.RandomString("NAN"));
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(Support.RandomString("NAN"));
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(Support.RandomString("NAN"));
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(Support.RandomString("NAN"));
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("88888");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Support.AreEqual("False", FastDriver.ClosingDisclosure.doesElementExist(FastDriver.ClosingDisclosure.SellerPlus).ToString());

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }



        #endregion

        #region 260869- CD Screen - CD Screen - Section 1 -Select Settlement Agent under Closing Information

        [TestMethod]
        public void US_260869_TC_346427_NO_02()
        {

            try
            {
                Reports.TestDescription = "Verify that the Settlement Agent Details with Service Type as Escrow in the CD Screen popup";
                GetOwningOfficeInfo();
                Reports.TestStep = "Login to file side";
                //Login
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Escrow";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[1] };

                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();

                Reports.TestStep = "Validating Settlement Agent Details";
                string Table_Data = FastDriver.CDSettlementAgentInfo.SettlementAgentTable.Text;

                Support.AreEqual("True", Table_Data.Contains(owningoffice[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[1] ?? "").ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[2]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[3]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[4]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[5]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[6]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[7]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[8]).ToString());
                Support.AreEqual("True", Table_Data.Contains("Owning Office").ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Selected.ToString());


                FastDriver.CDSettlementAgentInfo.Done.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }


        }

        [TestMethod]
        public void US_260869_TC_346428_NO_03()
        {
            try
            {
                Reports.TestDescription = "Verify that the OEC as Settlement Agent in the CD Screen popup";
                Reports.TestStep = "Login to file side";

                //Login
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Escrow";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[1] };

                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);

                Reports.TestStep = "Creating First OEC Instance";
                CreateOEC("247", 1);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();

                Reports.TestStep = "Validating Settlement Agent Details";
                string Table_Data = FastDriver.CDSettlementAgentInfo.SettlementAgentTable.Text;

                Table_Data = Table_Data.Replace("\r", " ");
                Table_Data = Table_Data.Replace("\n", " ");
                Table_Data = Table_Data.Replace(" ", "");

                oecdetail[0] = oecdetail[0].Replace(" ", "");
                oecdetail[1] = oecdetail[1].Replace(" ", "");
                Support.AreEqual("True", Table_Data.Contains(oecdetail[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(oecdetail[1]).ToString());
                oecdetail[2] = oecdetail[2].Replace(",", "").Replace("USA", "").Replace("\r", "").Replace("\n", "").Replace(" ", "");
                oecdetail[2] = oecdetail[2].TrimEnd();
                Support.AreEqual("True", Table_Data.Contains(oecdetail[2]).ToString());
                Support.AreEqual("True", Table_Data.Contains("OutsideEscrowCompany").ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Selected.ToString());

                FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.FAClick();


                FastDriver.CDSettlementAgentInfo.Done.FAClick();

                string cdname = FastDriver.ClosingDisclosure.SettlementAgentValue.Text;
                cdname = cdname.Replace(" ", "");

                Support.AreEqual("True", cdname.Contains(oecdetail[0]).ToString());


                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_260869_TC_346432_NO_07()
        {
            try
            {
                Reports.TestDescription = "Verify that the Split Payee as Settlement Agent in the CD Screen popup";
                Reports.TestStep = "Login to admin side";

                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                //CreateFee("MyFeeDescription1", "False", "Escrow Fee", "False", "", "K", "K");
                FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary");
                FastDriver.FeeSetup.SwitchToContentFrame();
                FastDriver.FeeSetup.CreateFee("MyFeeDescription1", "Escrow Fee", false, false, "", "K", "K");

                //Login
                var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Escrow";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[1] };

                var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);

                Reports.TestStep = "Navigate to file fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry");

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("MyFeeDescription");
                FastDriver.FileFees.FindNow.FAClick();

                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Obtaining Split Payee Information";
                FastDriver.FileFees.SwitchToContentFrame();

                SplitPayee(1);

                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                Reports.TestStep = "Navigate to CD Settlement Agent Popup";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();
                Reports.TestStep = "Validating Settlement Agent Details";

                string Table_Data = FastDriver.ClosingDisclosure.SettlementAgentTable.Text;
                Table_Data = Table_Data.Replace("\r", "");
                Table_Data = Table_Data.Replace("\n", "");

                Support.AreEqual("True", Table_Data.Contains(splitpayee1[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(splitpayee1[1]).ToString());
                Support.AreEqual("True", Table_Data.Contains(splitpayee1[2]).ToString());
                Support.AreEqual("True", Table_Data.Contains(splitpayee1[3]).ToString());
                Support.AreEqual("True", Table_Data.Contains(splitpayee1[4]).ToString());
                Support.AreEqual("True", Table_Data.Contains("Split Payee").ToString());




                FastDriver.ClosingDisclosure.Done.FAClick();


            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_260869_TC_350416_NO_10()
        {
            Reports.TestDescription = "Verify that the OEC as Settlement Agent can be changed in the CD Screen popup - Adhoc";
            Reports.TestStep = "Login to file side";


            //Login
            var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);

            //Create new order
            Reports.TestStep = "Create file with Service Type as Escrow";
            var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
            defaultRequest.formType = FormType.CD;
            defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[1] };

            var File2 = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File2.FileNumber);

            Reports.TestStep = "Creating first OEC instance";
            CreateOEC("247", 1);
            Reports.TestStep = "Navigate to CD Screen";
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
            FastDriver.ClosingDisclosure.SwitchToContentFrame();
            Reports.TestStep = "Navigate to CD Settlement Agent Popup";
            FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();
            Reports.TestStep = "Validating Settlement Agent Details";

            string Table_Data = FastDriver.CDSettlementAgentInfo.SettlementAgentTable.Text;
            Table_Data = Table_Data.Replace("\r", "");
            Table_Data = Table_Data.Replace("\n", " ");
            Table_Data = Table_Data.Replace(" ", "");

            oecdetail[0] = oecdetail[0].Replace(" ", "");
            oecdetail[1] = oecdetail[1].Replace(" ", "");
            Support.AreEqual("True", Table_Data.Contains(oecdetail[0]).ToString());
            Support.AreEqual("True", Table_Data.Contains(oecdetail[1]).ToString());
            oecdetail[2] = oecdetail[2].Replace(",", "").Replace("USA", "").Replace("\r", "").Replace("\n", "").Replace(" ", "");
            oecdetail[2] = oecdetail[2].TrimEnd();
            Support.AreEqual("True", Table_Data.Contains(oecdetail[2]).ToString());
            Support.AreEqual("True", Table_Data.Contains("OutsideEscrowCompany").ToString());

            Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Displayed.ToString());
            Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Selected.ToString());

            Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Displayed.ToString());
            Support.AreEqual("False", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Selected.ToString());

            FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.FAClick();
            FastDriver.CDSettlementAgentInfo.Done.FAClick();
            FastDriver.ClosingDisclosure.SwitchToContentFrame();

            string cdname = FastDriver.ClosingDisclosure.SettlementAgentValue.Text;
            cdname = cdname.Replace(" ", "");
            Support.AreEqual("True", cdname.Contains(oecdetail[0]).ToString());

            Reports.TestStep = "Saving CD Screen";
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Editing the OEC Instance";
            CreateOEC("HUDFLINSR1", 1);

            Reports.TestStep = "Navigate to CD Screen";
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
            FastDriver.ClosingDisclosure.SwitchToContentFrame();

            Reports.TestStep = "Validating the new settlement agent in CD Screen";
            string cdname1 = FastDriver.ClosingDisclosure.SettlementAgentValue.Text;
            cdname1 = cdname1.Replace("*", "");
            Support.AreEqual("True", oecdetail[0].Contains(cdname1).ToString());

            Reports.TestStep = "Navigate to CD Seller Popup";
            FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();


            Reports.TestStep = "Validating Settlement Agent Details";
            string Table_Data1 = FastDriver.CDSettlementAgentInfo.SettlementAgentTable.Text;
            Table_Data1 = Table_Data1.Replace("\r", "");
            Table_Data1 = Table_Data1.Replace("\n", " ");
            Table_Data1 = Table_Data1.Replace(" ", "");

            oecdetail[0] = oecdetail[0].Replace(" ", "");
            oecdetail[1] = oecdetail[1].Replace(" ", "");
            Support.AreEqual("True", Table_Data1.Contains(oecdetail[0]).ToString());
            Support.AreEqual("True", Table_Data1.Contains(oecdetail[1]).ToString());
            oecdetail[2] = oecdetail[2].Replace(",", "").Replace("USA", "").Replace("\r", "").Replace("\n", "").Replace(" ", "");
            oecdetail[2] = oecdetail[2].TrimEnd();
            Support.AreEqual("True", Table_Data1.Contains(oecdetail[2]).ToString());
            Support.AreEqual("True", Table_Data1.Contains("OutsideEscrowCompany").ToString());

            Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Displayed.ToString());
            Support.AreEqual("False", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Selected.ToString());

            Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Displayed.ToString());
            Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Selected.ToString());

            FastDriver.CDSettlementAgentInfo.Done.FAClick();
            FastDriver.ClosingDisclosure.SwitchToContentFrame();

            Reports.TestStep = "Validating the new settlement agent in CD Screen";
            string cdname2 = FastDriver.ClosingDisclosure.SettlementAgentValue.Text;
            cdname2 = cdname2.Replace("*", "");
            cdname2 = cdname2.Replace(" ", "");
            Support.AreEqual("True", oecdetail[0].Contains(cdname2).ToString());

            Reports.TestStep = "Saving CD Screen";
            FastDriver.BottomFrame.Done();

        }
        #endregion

        #region Loan Terms
        #region User Story- 213064(Iteration 9)- TC 1: Verify the display of Loan Terms on CD screen.
        [TestMethod]
        public void US_213064_IT_09_TC_1()
        {
            Reports.TestDescription = "Verify the display of Loan Terms on CD screen.";
            Reports.TestStep = "Login to File Side and Create basic order";

            //Login
            var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);

            //Create new order
            Reports.TestStep = "Create file with Service Type as Title";
            var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
            defaultRequest.formType = FormType.CD;
            defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            Reports.TestStep = "Navigate to CD";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
            FastDriver.ClosingDisclosure.SwitchToContentFrame();

            Reports.TestStep = "Click on Loan Terms section";
            FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

            Reports.TestStep = "Verify system displays Loan details";

            //verify loan terms lable
            bool res1 = FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmount.Displayed;
            bool res2 = FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRate.Displayed;
            bool res3 = FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipal.Displayed;
            bool res4 = FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenalty.Displayed;
            bool res5 = FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPayment.Displayed;

            if (res1 && res2 && res3 & res4 && res5)
                Reports.StatusUpdate("System displays expected values", true);
            else
                Reports.StatusUpdate("System displays expected values", false);
        }
        #endregion
        #region User Story- 213064(Iteration 9)- TC 3:  Verify system displays subheading applicable to Loan Amount, Interest Rate, Monthly Principal & Interest on Loan terms table.
        [TestMethod]
        public void US_213064_IT_09_TC_3()
        {
            try
            {

                Reports.TestDescription = "Verify system displays subheading applicable to Loan Amount, Interest Rate, Monthly Principal & Interest on Loan terms table";
                //File side Login Goes here
                Reports.TestStep = "Login to File Side and Create basic order";
                //Login
                var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.StatusUpdate("Create a Basic Order using Mendatory details and verify.", File.FileNumber != "" ? true : false);

                Reports.TestStep = "Navigate to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Click on Loan Terms section";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Verify the heading is present and applicable to Loan Amount, Interest Rate, Monthly Principal & Interest on Loan terms table";
                bool IsPresent = FastDriver.ClosingDisclosure.Section2_LoanTerms_subheading1.Displayed;
                ReadOnlyCollection<IWebElement> TableRows = FastDriver.ClosingDisclosure.LoanTermsHeadingTable.FindElements(By.CssSelector("tr"));

                String RowNum = "";
                String ColumnNo = "";

                for (int rowCount = 0; rowCount < TableRows.Count; rowCount++)
                {
                    ReadOnlyCollection<IWebElement> RowCells = TableRows[rowCount].FindElements(By.CssSelector("td"));

                    for (int cellCount = 0; cellCount < RowCells.Count; cellCount++)
                    {
                        if (RowCells[cellCount].Text.Contains("Can this amount increase after closing?"))
                        {
                            RowNum = rowCount.ToString();
                            ColumnNo = cellCount.ToString();
                        }
                    }


                }


                String ExpectedRowNo = "0";
                String ExpectedColumnNo = "1";

                if (IsPresent && ((RowNum == ExpectedRowNo) && (ColumnNo == ExpectedColumnNo)))
                    Reports.StatusUpdate("Subheading displayed as expected", true);
                else
                    Reports.StatusUpdate("Subheading is not displayed as expected", false);

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }
        #endregion
        #region User Story- 213064(Iteration 9)- TC 4:  Verify system displays subheading applicable to Prepayment Penalty and Balloon Payment on Loan terms table.
        [TestMethod]

        public void US_213064_IT_09_TC_4()
        {

            try
            {


                Reports.TestDescription = "Verify system displays subheading applicable to Loan Amount, Interest Rate, Monthly Principal & Interest on Loan terms table";
                //File side Login Goes here
                Reports.TestStep = "Login to File Side and Create basic order";
                //Login
                var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.StatusUpdate("Create a Basic Order using Mendatory details and verify.", File.FileNumber != "" ? true : false);

                Reports.TestStep = "Navigate to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Click on Loan Terms section";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Verify the heading is present and applicable to Prepayment Penalty and Balloon Payment on Loan terms table";

                bool IsPresent = FastDriver.ClosingDisclosure.Section2_LoanTerms_subheading2Cell.Displayed;
                ReadOnlyCollection<IWebElement> TableRows = FastDriver.ClosingDisclosure.LoanTermsSecHeadingTable.FindElements(By.CssSelector("tr"));

                String RowNum = "";
                String ColumnNo = "";

                for (int rowCount = 0; rowCount < TableRows.Count; rowCount++)
                {
                    ReadOnlyCollection<IWebElement> RowCells = TableRows[rowCount].FindElements(By.CssSelector("td"));

                    for (int cellCount = 0; cellCount < RowCells.Count; cellCount++)
                    {
                        if (RowCells[cellCount].Text.Contains("Can this amount increase after closing?"))
                        {
                            RowNum = rowCount.ToString();
                            ColumnNo = cellCount.ToString();
                        }
                    }


                }

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }
        #endregion

        #endregion

        #region Loan Terms adjustments
        #region User Story- 280539(Iteration 9)- TC 4: Check whether FAST user can select 'NO' as an answer for each of the Loan Term elements when Loan Terms information present on file
        [TestMethod]
        public void US_280539_IT_09_TC_4()
        {
            try
            {

                Reports.TestDescription = "Check wheter FAST user can select 'NO' as an answer for each of the Loan TErm elements when Load Term information is present on file";
                //File side login goes here
                Reports.TestStep = "Login to FIle Side and Create basic order";

                //Login
                var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.StatusUpdate("Create a Basic Order using Mendatory details and verify.", File.FileNumber != "" ? true : false);

                Reports.TestStep = "Navigate to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Click on Loan Terms section";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown.FASelectItem("NO");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItem("NO");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItem("NO");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown.FASelectItem("NO");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown.FASelectItem("NO");

                Reports.TestStep = "Click on save";
                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Verify the NO answer is saved";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Support.AreEqual("NO", FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown.FAGetSelectedItem().ToString());
                Support.AreEqual("NO", FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FAGetSelectedItem().ToString());
                Support.AreEqual("NO", FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FAGetSelectedItem().ToString());
                Support.AreEqual("NO", FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown.FAGetSelectedItem().ToString());
                Support.AreEqual("NO", FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown.FAGetSelectedItem().ToString());

                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }

        }
        #endregion
        #endregion
        
        #region Cash to Close
        #region User Story- 340045(Iteration 9)- TC 4: User Story- 340045: Verify FAST user can edit the statement next Cash to Close amount
        [TestMethod]
        public void US_340045_IT_09_TC_4()
        {
            try
            {


                #region Object maps

                String inputtext = "";
                BrowserWindow ie = new BrowserWindow();
                ie.SearchProperties["ClassName"] = "IEFrame";
                ie.SearchProperties["ControlType"] = "Window";
                HtmlEditableSpan Other = new HtmlEditableSpan(ie);
                Other.SearchProperties["Id"] = "spnCashToClose";

                #endregion

                Reports.TestDescription = "Verify FAST user can edit the statement next Cash to Close amount";
                Reports.TestStep = "Create a file using quick file entry";

                //Login
                var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };
                //defaultRequest.File.BusinessSegmentObjectCD = "WF";
                //defaultRequest.File.TransactionTypeObjectCD = "Bulk Sale";

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Click on costs at Closing section";
                FastDriver.ClosingDisclosure.CostsatClosing.FAClick();
                FastDriver.ClosingDisclosure.CashtoCloseStatement.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Reports.TestStep = "Edit the statement with letters and spaces";
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.Click();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.FASetText("The statement is edited");

                //Reports.TestStep = "Clik on Save then Done";
                //FastDriver.ClosingDisclosure.SwitchToBottomFrame();
                //FastDriver.BottomFrame.Done();


                Reports.TestStep = "Verify the statement is saved";
                Support.AreEqual(FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.Text, "The statement is edited");


                Reports.TestStep = "Edit the statement with alphanumerics, special symbols and spaces";
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.Click();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.FASetText("^#%$$*fdkafkjad24323");

                Reports.TestStep = "Click on Save then Done";
                FastDriver.ClosingDisclosure.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();


                Reports.TestStep = "Verify the statement is saved";
                //FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Support.AreEqual(FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.Text, "^#%$$*fdkafkjad24323");

                Reports.TestStep = "Remove the statement and save";
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.FASetText("");

                Reports.TestStep = "Click on Save then Done";
                FastDriver.ClosingDisclosure.SwitchToBottomFrame();
                FastDriver.BottomFrame.btnSave.FAClick();

                Reports.TestStep = "Verify that previous statement is saved";
                //FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.Click();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.FASetText("^#%$$*fdkafkjad24323");
                Reports.TestStep = "Verify the maximum length";

                for (int i = 0; i < 27; i++)
                {
                    inputtext = "FAST*FAST$" + inputtext;
                }

                try
                {
                    //edit the statement
                    FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.Click();
                    FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.FASetText(inputtext);
                }
                catch (Exception e)
                {

                    Reports.StatusUpdate("System not allowed to enter more than 250 characters", true);
                }

                int LengthOfActualString = FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.Text.Length;
                if (LengthOfActualString <= 260)
                {
                    Reports.StatusUpdate("The Maximum length(" + LengthOfActualString + ") is set to 250", true);
                }
                else
                {
                    Reports.StatusUpdate("The Maximum length(" + LengthOfActualString + ") is NOT set to 250", false);
                    FastDriver.ClosingDisclosure.SwitchToBottomFrame();
                    FastDriver.BottomFrame.btnSave.FAClick();

                }

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }
        #endregion
        #endregion

        #region Closing Costs
        #region User Story- 213066(Iteration 9)- TC 4: Verify FAST user can edit the statement next Cash to Close amount
        [TestMethod]
        public void US_213066_IT_14_TC_4()
        {

            try
            {

                Reports.TestDescription = "Verify FAST user can edit the statement next closing cost amount";
                Reports.TestStep = "Create a file using quick file entry";

                //Login
                var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.StatusUpdate("Create a Basic Order using Mendatory details and verify.", File.FileNumber != "" ? true : false);

                Reports.TestStep = "Navigate to CD";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Click on Costs at Closing section";
                FastDriver.ClosingDisclosure.CostsatClosing.FAClick();

                Reports.TestStep = "Verify Loan costs, Other costs and Lender credits amounts are present in the statement";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsAmount1.Displayed.ToString());
                String LoanCosts = FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsAmount1.Text;
                Support.AreEqual("True", FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsAmount2.Displayed.ToString());
                String OtherCosts = FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsAmount2.Text;
                Support.AreEqual("True", FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsAmount3.Displayed.ToString());
                String LenderCredits = FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsAmount3.Text;

                Reports.TestStep = "Edit the statement with letters and spaces";

                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement1.Click();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement1.FASetText("Text edited1");

                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement2.Click();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement2.FASetText("Text edited2");

                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement3.Click();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement3.FASetText("Text edited3");

                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement4.Click();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement4.FASetText("Text edited4");

                Reports.TestStep = "Click on DONE";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the statement is saved";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.CostsatClosing.FAClick();
                String ExpectedText1 = "Text edited1 " + LoanCosts + " Text edited2 " + OtherCosts + " Text edited3 " + LenderCredits + " Text edited4";
                Support.AreEqual(ExpectedText1, FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatementCell.Text);


                Reports.TestStep = "Edit the statement with alphanumerics, special symbols and spaces";

                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement1.FASetText("  Text edited123!@*");
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement2.FASetText("  Text edited123!@*");
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement3.FASetText("  Text edited123!@*");
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement4.FASetText("  Text edited123!@*");

                Reports.TestStep = "Click on DONE";
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.CostsatClosing.FAClick();
                String ExpectedText2 = "Text edited123!@* " + LoanCosts.Trim() + "    Text edited123!@* " + OtherCosts.Trim() + "    Text edited123!@* " + LenderCredits.Trim() + "    Text edited123!@*";
                String ActualText = FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatementCell.Text;

                Support.AreEqual(ExpectedText2, ActualText.Trim());

                Reports.TestStep = "Click on DONE";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        #endregion
        #endregion

        #region 261856- CD Screen - Section 1 -Multiple Borrowers under Transaction Information

        [TestMethod]
        public void US_261856_TC_345642_NO_01()
        {
            try
            {

                Reports.TestDescription = "Verify that the Borrower information is getting displayed in the CD screen Borrower Popup";
                Reports.TestStep = "Login to file side";

                //Login
                //var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                //FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First Borrower";
                Buyer("SFName", "SLName", true, 1);

                Reports.TestStep = "Navigate to CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to CD Borrower popup";
                Support.AreEqual("Click + for Borrower Information", FastDriver.ClosingDisclosure.BorrowerPlus.GetAttribute("alt"));
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();
                Reports.TestStep = "Validating Borrower Details";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                //string name = FastDriver.CDBorrowerInfo.Borrower1Name.Text;
                string name = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name.Contains(buyerdetail[0].ToString()).ToString());
                Support.AreEqual("True", name.Contains(buyerdetail[1].ToString()).ToString());

                string CTable = FastDriver.CDBorrowerInfo.Borrower1CATable.Text;
                Support.AreEqual("True", CTable.Contains(buyerdetail[2].ToString()).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[3].ToString()).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[4].ToString()).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[5].ToString()).ToString());

                Support.AreEqual("True", CTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable.Contains("CA").ToString());
                Support.AreEqual("True", CTable.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("true", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.FAGetValue().ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                Reports.TestStep = "Closing CDBorrower Screen";
                FastDriver.CDBorrowerInfo.Done.FAClick();


                Reports.TestStep = "Click on DONE";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void US_261856_TC_345645_NO_02()
        {
            try
            {

                Reports.TestDescription = "Verify that the Borrower information is getting displayed in the CD screen Borrower Popup";
                Reports.TestStep = "Login to file side";

                //Login
                //var credentials2 = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                //FASTLogin.Login(AutoConfig.FASTHomeURL, credentials2, true);
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First Borrower";
                Buyer("SFName", "SLName", true, 1);

                Reports.TestStep = "Navigate to CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to CD Borrower popup";
                Support.AreEqual("Click + for Borrower Information", FastDriver.ClosingDisclosure.BorrowerPlus.GetAttribute("alt"));
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();
                Reports.TestStep = "Validating Borrower Details";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                //string name = FastDriver.CDBorrowerInfo.Borrower1Name.Text;
                string name = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name.Contains(buyerdetail[0].ToString()).ToString());
                Support.AreEqual("True", name.Contains(buyerdetail[1].ToString()).ToString());

                string CTable = FastDriver.CDBorrowerInfo.Borrower1CATable.Text;
                Support.AreEqual("True", CTable.Contains(buyerdetail[2].ToString()).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[3].ToString()).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[4].ToString()).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[5].ToString()).ToString());
                Support.AreEqual("True", CTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable.Contains("CA").ToString());
                Support.AreEqual("True", CTable.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("true", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.FAGetValue().ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                Reports.TestStep = "Changing the Borrower Address to display in CD Screen";
                FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.FAClick();

                string FTable = FastDriver.CDBorrowerInfo.Borrower1FATable.Text;
                Support.AreEqual("True", FTable.Contains(buyerdetail[6]).ToString());
                Support.AreEqual("True", FTable.Contains(buyerdetail[7]).ToString());
                Support.AreEqual("True", FTable.Contains(buyerdetail[8]).ToString());
                Support.AreEqual("True", FTable.Contains(buyerdetail[9]).ToString());
                Support.AreEqual("True", FTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", FTable.Contains("CA").ToString());
                Support.AreEqual("True", FTable.Contains("92727").ToString());
                
                Reports.TestStep = "Closing CDBorrower Screen";
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "validating the Borrower Forwarding Address in CD Screen";
                string cdname = FastDriver.ClosingDisclosure.BorrowerName.Text;
                cdname = cdname.Replace("*", "");
                Support.AreEqual("True", cdname.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", cdname.Contains(buyerdetail[1]).ToString());
                
                string cdfstreet = FastDriver.ClosingDisclosure.lblBorrowerAddr.Text;

                Support.AreEqual("True", cdfstreet.Contains(buyerdetail[6]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(buyerdetail[7]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(buyerdetail[8]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(buyerdetail[9]).ToString());

                string cdfcsz = FastDriver.ClosingDisclosure.lblBorrowerCSZ.Text;
                Support.AreEqual("True", cdfcsz.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdfcsz.Contains("CA").ToString());
                Support.AreEqual("True", cdfcsz.Contains("92727").ToString());

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                Reports.TestStep = "Navigate to CD Borrower Popup";
                string cdname1 = FastDriver.ClosingDisclosure.BorrowerName.Text;
                cdname1 = cdname1.Replace("*", "");
                Support.AreEqual("True", cdname1.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", cdname1.Contains(buyerdetail[1]).ToString());

                string cdfstreet1 = FastDriver.ClosingDisclosure.lblBorrowerAddr.Text;

                Support.AreEqual("True", cdfstreet1.Contains(buyerdetail[6]).ToString());
                Support.AreEqual("True", cdfstreet1.Contains(buyerdetail[7]).ToString());
                Support.AreEqual("True", cdfstreet1.Contains(buyerdetail[8]).ToString());
                Support.AreEqual("True", cdfstreet1.Contains(buyerdetail[9]).ToString());

                string cdfcsz1 = FastDriver.ClosingDisclosure.lblBorrowerCSZ.Text;
                Support.AreEqual("True", cdfcsz1.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdfcsz1.Contains("CA").ToString());
                Support.AreEqual("True", cdfcsz1.Contains("92727").ToString());

                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();
                Reports.TestStep = "Validating the radio buttons";
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("true", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.FAGetValue().ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                string FTable1 = FastDriver.CDBorrowerInfo.Borrower1FATable.Text;
                Support.AreEqual("True", FTable1.Contains(buyerdetail[6]).ToString());
                Support.AreEqual("True", FTable1.Contains(buyerdetail[7]).ToString());
                Support.AreEqual("True", FTable1.Contains(buyerdetail[8]).ToString());
                Support.AreEqual("True", FTable1.Contains(buyerdetail[9]).ToString());
                Support.AreEqual("True", FTable1.Contains("Santa Ana").ToString());
                Support.AreEqual("True", FTable1.Contains("CA").ToString());
                Support.AreEqual("True", FTable1.Contains("92727").ToString());

                Reports.TestStep = "Changing the Borrower Address to display in CD Screen";
                FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.FAClick();
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "validating the Borrower Current Address in CD Screen";
                string cdname2 = FastDriver.ClosingDisclosure.BorrowerName.Text; //.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                cdname2 = cdname2.Replace("*", "");
                Support.AreEqual("True", cdname2.Contains(buyerdetail[0].ToString()).ToString());
                Support.AreEqual("True", cdname2.Contains(buyerdetail[1].ToString()).ToString());

                string cdcstreet2 = FastDriver.ClosingDisclosure.lblBorrowerAddr.Text;
                Support.AreEqual("True", cdcstreet2.Contains(buyerdetail[2].ToString()).ToString());
                Support.AreEqual("True", cdcstreet2.Contains(buyerdetail[3].ToString()).ToString());
                Support.AreEqual("True", cdcstreet2.Contains(buyerdetail[4].ToString()).ToString());
                Support.AreEqual("True", cdcstreet2.Contains(buyerdetail[5].ToString()).ToString());
                string cdccsz2 = FastDriver.ClosingDisclosure.lblBorrowerCSZ.Text;
                Support.AreEqual("True", cdccsz2.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdccsz2.Contains("CA").ToString());
                Support.AreEqual("True", cdccsz2.Contains("88888").ToString());

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_261856_TC_345648_NO_04()
        {
            try
            {
                Reports.TestDescription = "When no forwarding address is entered for borrower verify blank is displayed in CD Screen popup";
                Reports.TestStep = "Login to file side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First Borrower";
                Buyer_SpAddress("SFName", "SLName", true, "current");

                Reports.TestStep = "Navigate to CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to CD Borrower Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "Validating Borrower Details";
                
                string name = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", name.Contains(buyerdetail[1]).ToString());

                string CTable = FastDriver.CDBorrowerInfo.Borrower1CATable.Text;

                Support.AreEqual("True", CTable.Contains(buyerdetail[2]).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[3]).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[4]).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[5]).ToString());
                Support.AreEqual("True", CTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable.Contains("CA").ToString());
                Support.AreEqual("True", CTable.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Selected.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                Reports.TestStep = "Validating forwarding address contains only state";
                FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.FAClick();

                Reports.TestStep = "Closing CD Borrower Popup";
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1FATable.Displayed.ToString());
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "validating the Borrower Forwarding Address in CD Screen";
                string cdname = FastDriver.ClosingDisclosure.BorrowerName.Text;
                cdname = cdname.Replace("*", "");
                Support.AreEqual("True", cdname.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", cdname.Contains(buyerdetail[1]).ToString());

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify the blank forwarding is getting saved";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                string cdname1 = FastDriver.ClosingDisclosure.BorrowerName.Text;
                cdname1 = cdname.Replace("*", "");

                Support.AreEqual("True", cdname1.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", cdname1.Contains(buyerdetail[1]).ToString());

                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                Reports.TestStep = "Closing the CDBorrowerInfo Screen";
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_261856_TC_345650_NO_05()
        {
            try
            {
                Reports.TestDescription = "When no Current Address is entered for Borrower verify blank is displayed in CD Screen Popup";
                Reports.TestStep = "Login to file side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First Borrower";
                Buyer_SpAddress("SFName", "SLName", true, "forwarding");

                Reports.TestStep = "Navigate to CD screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to CD Borrower Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "Validating Borrower Details";
                string name = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", name.Contains(buyerdetail[1]).ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("true", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.FAGetValue().ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                Reports.TestStep = "Changing the Borrower Address to display in CD Screen";
                FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.FAClick();

                string FTable = FastDriver.CDBorrowerInfo.Borrower1FATable.Text;
                Support.AreEqual("True", FTable.Contains(buyerdetail[2]).ToString());
                Support.AreEqual("True", FTable.Contains(buyerdetail[3]).ToString());
                Support.AreEqual("True", FTable.Contains(buyerdetail[4]).ToString());
                Support.AreEqual("True", FTable.Contains(buyerdetail[5]).ToString());
                Support.AreEqual("True", FTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", FTable.Contains("CA").ToString());
                Support.AreEqual("True", FTable.Contains("92727").ToString());


                Reports.TestStep = "Closing the CDBorrowerInfo Screen";
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "Validating the borrower forwarding address in CD screen";
                string cdname = FastDriver.ClosingDisclosure.BorrowerName.Text;
                cdname = cdname.Replace("*", "");

                Support.AreEqual("True", cdname.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", cdname.Contains(buyerdetail[1]).ToString());
                string cdfstreet = FastDriver.ClosingDisclosure.lblBorrowerAddr.Text;
                Support.AreEqual("True", cdfstreet.Contains(buyerdetail[2]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(buyerdetail[3]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(buyerdetail[4]).ToString());
                Support.AreEqual("True", cdfstreet.Contains(buyerdetail[5]).ToString());
                string cdfcsz = FastDriver.ClosingDisclosure.lblBorrowerCSZ.Text;
                Support.AreEqual("True", cdfcsz.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdfcsz.Contains("CA").ToString());
                Support.AreEqual("True", cdfcsz.Contains("92727").ToString());

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_261856_TC_345652_NO_07()
        {
            try
            {
                Reports.TestDescription = "Verify multiple Borrower information is getting displayed in the CD screen Borrower Popup";
                Reports.TestStep = "Login to file side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                //Create new order
                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First Borrower";
                Buyer("SFName1", "SLName1", true, 1);
                string[] buyerdetail1 = new string[10];
                Array.Copy(buyerdetail, buyerdetail1, 10);
                Reports.TestStep = "Creating second Borrower";
                Buyer("SFName2", "SLName2", true, 2);
                string[] buyerdetail2 = new string[10];
                Array.Copy(buyerdetail, buyerdetail2, 10);
                Reports.TestStep = "Creating third Borrower";
                Buyer("SFName3", "SLName3", true, 3);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to CD Borrower Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "Validatin Borrower Details";
                string name1 = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name1.Contains(buyerdetail1[0]).ToString());
                Support.AreEqual("True", name1.Contains(buyerdetail1[1]).ToString());
                string cdcstreet = FastDriver.ClosingDisclosure.lblBorrowerAddr.Text;
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail1[2]).ToString());
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail1[3]).ToString());
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail1[4]).ToString());
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail1[5]).ToString());
                string cdccsz = FastDriver.ClosingDisclosure.lblBorrowerCSZ.Text;
                Support.AreEqual("True", cdccsz.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdccsz.Contains("CA").ToString());
                Support.AreEqual("True", cdccsz.Contains("88888").ToString());

                Reports.TestStep = "Closing the CDBorrowerInfo Screen";
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "Deleting first Buyer record";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();


                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnClear.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Validating the CD Screen will display the Second Buyer";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                string cdname1 = FastDriver.ClosingDisclosure.BorrowerName.Text;
                cdname1 = cdname1.Replace("*", "");
                Support.AreEqual("True", cdname1.Contains(buyerdetail2[0]).ToString());
                Support.AreEqual("True", cdname1.Contains(buyerdetail2[1]).ToString());
                string cdcstreet1 = FastDriver.ClosingDisclosure.lblBorrowerAddr.Text;
                Support.AreEqual("True", cdcstreet1.Contains(buyerdetail2[2]).ToString());
                Support.AreEqual("True", cdcstreet1.Contains(buyerdetail2[3]).ToString());
                Support.AreEqual("True", cdcstreet1.Contains(buyerdetail2[4]).ToString());
                Support.AreEqual("True", cdcstreet1.Contains(buyerdetail2[5]).ToString());
                string cdccsz1 = FastDriver.ClosingDisclosure.lblBorrowerCSZ.Text;
                Support.AreEqual("True", cdccsz1.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdccsz1.Contains("CA").ToString());
                Support.AreEqual("True", cdccsz1.Contains("88888").ToString());

                Reports.TestStep = "Validatin the Borrower pop willnot display the first buyer";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                string name4 = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;  //FastDriver.CDBorrowerInfo.Borrower1Name.Text;
                Support.AreEqual("False", name4.Contains(buyerdetail1[0]).ToString());
                Support.AreEqual("False", name4.Contains(buyerdetail1[1]).ToString());
                string CTable4 = FastDriver.CDBorrowerInfo.Borrower1CATable.Text;
                Support.AreEqual("False", CTable4.Contains(buyerdetail1[2]).ToString());
                Support.AreEqual("False", CTable4.Contains(buyerdetail1[3]).ToString());
                Support.AreEqual("False", CTable4.Contains(buyerdetail1[4]).ToString());
                Support.AreEqual("False", CTable4.Contains(buyerdetail1[5]).ToString());

                ReadOnlyCollection<IWebElement> TableRows = FastDriver.CDBorrowerInfo.BorrowerTable.FindElements(By.CssSelector("tr"));

                int RowNum = 0;

                for (int rowCount = 0; rowCount < TableRows.Count; rowCount++)
                {
                    ReadOnlyCollection<IWebElement> RowCells = TableRows[rowCount].FindElements(By.CssSelector("td"));

                    for (int cellCount = 0; cellCount < RowCells.Count; cellCount++)
                    {
                        if (RowCells[cellCount].Text.Contains("FName"))
                        {
                            RowNum++;
                        }
                    }
                    
                }

                Support.AreEqual("2", RowNum.ToString());
                
                Reports.TestStep = "Closing the CDBorrowerInfo Screen";
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "Closing CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_261856_TC_345653_NO_08()
        {
            try
            {
                Reports.TestDescription = "Verify the change of multiple Borrower Address in CD screen";
                Reports.TestStep = "Login to file side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First Borrower";
                Buyer("SFName1", "SLName1", true, 1);
                string[] buyerdetail1 = new string[10];
                Array.Copy(buyerdetail, buyerdetail1, 10);
                Reports.TestStep = "Creating second Borrower";
                Buyer("SFName2", "SLName2", true, 2);
                string[] buyerdetail2 = new string[10];
                Array.Copy(buyerdetail, buyerdetail2, 10);
                Reports.TestStep = "Creating third Borrower";
                Buyer("SFName3", "SLName3", true, 3);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to CD Borrower Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "Validating Borrower Details";
                string name1 = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name1.Contains(buyerdetail1[0]).ToString());
                Support.AreEqual("True", name1.Contains(buyerdetail1[1]).ToString());
                
                string CTable1 = FastDriver.CDBorrowerInfo.Borrower1CATable.Text;
                Support.AreEqual("True", CTable1.Contains(buyerdetail1[2]).ToString());
                Support.AreEqual("True", CTable1.Contains(buyerdetail1[3]).ToString());
                Support.AreEqual("True", CTable1.Contains(buyerdetail1[4]).ToString());
                Support.AreEqual("True", CTable1.Contains(buyerdetail1[5]).ToString());

                Support.AreEqual("True", CTable1.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable1.Contains("CA").ToString());
                Support.AreEqual("True", CTable1.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                string name2 = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "2", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name2.Contains(buyerdetail2[0]).ToString());
                Support.AreEqual("True", name2.Contains(buyerdetail2[1]).ToString());

                string CTable2 = FastDriver.CDBorrowerInfo.Borrower2CATable.Text;
                Support.AreEqual("True", CTable2.Contains(buyerdetail2[2]).ToString());
                Support.AreEqual("True", CTable2.Contains(buyerdetail2[3]).ToString());
                Support.AreEqual("True", CTable2.Contains(buyerdetail2[4]).ToString());
                Support.AreEqual("True", CTable2.Contains(buyerdetail2[5]).ToString());
                
                Support.AreEqual("True", CTable2.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable2.Contains("CA").ToString());
                Support.AreEqual("True", CTable2.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                string name3 = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "3", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name3.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", name3.Contains(buyerdetail[1]).ToString());

                string CTable3 = FastDriver.CDBorrowerInfo.Borrower3CATable.Text;
                Support.AreEqual("True", CTable3.Contains(buyerdetail[2]).ToString());
                Support.AreEqual("True", CTable3.Contains(buyerdetail[3]).ToString());
                Support.AreEqual("True", CTable3.Contains(buyerdetail[4]).ToString());
                Support.AreEqual("True", CTable3.Contains(buyerdetail[5]).ToString());
                
                Support.AreEqual("True", CTable3.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable3.Contains("CA").ToString());
                Support.AreEqual("True", CTable3.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());


                Reports.TestStep = "Select Forwarding Address radio button for all borrower";
                FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.FAClick();

                string FTable1 = FastDriver.CDBorrowerInfo.Borrower1FATable.Text;
                Support.AreEqual("True", FTable1.Contains(buyerdetail1[6]).ToString());
                Support.AreEqual("True", FTable1.Contains(buyerdetail1[7]).ToString());
                Support.AreEqual("True", FTable1.Contains(buyerdetail1[8]).ToString());
                Support.AreEqual("True", FTable1.Contains(buyerdetail1[9]).ToString());
                Support.AreEqual("True", FTable1.Contains("Santa Ana").ToString());
                Support.AreEqual("True", FTable1.Contains("CA").ToString());
                Support.AreEqual("True", FTable1.Contains("92727").ToString());

                FastDriver.CDBorrowerInfo.Borrower2ForwardingAddrRadioButton.FAClick();
                string FTable2 = FastDriver.CDBorrowerInfo.Borrower2FATable.Text;
                Support.AreEqual("True", FTable2.Contains(buyerdetail2[6]).ToString());
                Support.AreEqual("True", FTable2.Contains(buyerdetail2[7]).ToString());
                Support.AreEqual("True", FTable2.Contains(buyerdetail2[8]).ToString());
                Support.AreEqual("True", FTable2.Contains(buyerdetail2[9]).ToString());
                Support.AreEqual("True", FTable2.Contains("Santa Ana").ToString());
                Support.AreEqual("True", FTable2.Contains("CA").ToString());
                Support.AreEqual("True", FTable2.Contains("92727").ToString());

                FastDriver.CDBorrowerInfo.Borrower3ForwardingAddrRadioButton.FAClick();
                string FTable3 = FastDriver.CDBorrowerInfo.Borrower3FATable.Text;
                Support.AreEqual("True", FTable3.Contains(buyerdetail[6]).ToString());
                Support.AreEqual("True", FTable3.Contains(buyerdetail[7]).ToString());
                Support.AreEqual("True", FTable3.Contains(buyerdetail[8]).ToString());
                Support.AreEqual("True", FTable3.Contains(buyerdetail[9]).ToString());
                Support.AreEqual("True", FTable3.Contains("Santa Ana").ToString());
                Support.AreEqual("True", FTable3.Contains("CA").ToString());
                Support.AreEqual("True", FTable3.Contains("92727").ToString());

                Reports.TestStep = "Closing the CDBorrowerInfo Screen";
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "validating the First Borrower Forwarding Address in CD Screen";
                string cdname = FastDriver.ClosingDisclosure.BorrowerName.Text;
                cdname = cdname.Replace("*", "");
                Support.AreEqual("True", cdname.Contains(buyerdetail1[0]).ToString());
                Support.AreEqual("True", cdname.Contains(buyerdetail1[1]).ToString());
                string cdcstreet = FastDriver.ClosingDisclosure.lblBorrowerAddr.Text;
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail1[6]).ToString());
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail1[7]).ToString());
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail1[8]).ToString());
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail1[9]).ToString());
                string cdccsz = FastDriver.ClosingDisclosure.lblBorrowerCSZ.Text;
                Support.AreEqual("True", cdccsz.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdccsz.Contains("CA").ToString());
                Support.AreEqual("True", cdccsz.Contains("92727").ToString());

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_261856_TC_345654_NO_09()
        {
            try
            {
                Reports.TestDescription = "Verify that the Borrower information is getting displayed in the CD screen after checking LA from Popup";
                Reports.TestStep = "Login to file side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First Borrower";
                Buyer("SFName1", "SLName1", false, 1);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to CD Borrower Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "Validating Borrower Details";
                string name = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", name.Contains(buyerdetail[1]).ToString());

                string CTable = FastDriver.CDBorrowerInfo.Borrower1CATable.Text;
                Support.AreEqual("True", CTable.Contains(buyerdetail[2]).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[3]).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[4]).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[5]).ToString());

                Support.AreEqual("True", CTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable.Contains("CA").ToString());
                Support.AreEqual("True", CTable.Contains("88888").ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.FAClick();

                Reports.TestStep = "Closing the CDBorrowerInfo Screen";
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "Validating the borrower information in CD Screen";

                string cdname = FastDriver.ClosingDisclosure.BorrowerName.Text;
                cdname = cdname.Replace("*", "");
                Support.AreEqual("True", cdname.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", cdname.Contains(buyerdetail[1]).ToString());
                string cdcstreet = FastDriver.ClosingDisclosure.lblBorrowerAddr.Text;
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail[2]).ToString());
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail[3]).ToString());
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail[4]).ToString());
                Support.AreEqual("True", cdcstreet.Contains(buyerdetail[5]).ToString());
                string cdccsz = FastDriver.ClosingDisclosure.lblBorrowerCSZ.Text;
                Support.AreEqual("True", cdccsz.Contains("Santa Ana").ToString());
                Support.AreEqual("True", cdccsz.Contains("CA").ToString());
                Support.AreEqual("True", cdccsz.Contains("88888").ToString());

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_261856_TC_345655_NO_10()
        {
            try
            {
                Reports.TestDescription = "Verify that the Borrower information is not getting displayed in the CD screen after unchecking LA from Popup";
                Reports.TestStep = "Login to file side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First Borrower";
                Buyer("SFName1", "SLName1", false, 1);

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to CD Borrower Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "Validating Borrower Details";
                string name = FastDriver.CDBorrowerInfo.BorrowerTable.PerformTableAction(1, "1", 2, TableAction.GetText).Message;
                Support.AreEqual("True", name.Contains(buyerdetail[0]).ToString());
                Support.AreEqual("True", name.Contains(buyerdetail[1]).ToString());

                string CTable = FastDriver.CDBorrowerInfo.Borrower1CATable.Text;
                Support.AreEqual("True", CTable.Contains(buyerdetail[2]).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[3]).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[4]).ToString());
                Support.AreEqual("True", CTable.Contains(buyerdetail[5]).ToString());

                Support.AreEqual("True", CTable.Contains("Santa Ana").ToString());
                Support.AreEqual("True", CTable.Contains("CA").ToString());
                Support.AreEqual("True", CTable.Contains("88888").ToString());

                FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.FAClick();

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1CurrentAddrRadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDBorrowerInfo.Borrower1ForwardingAddrRadioButton.Selected.ToString());

                FastDriver.CDBorrowerInfo.Borrower1LoanApplicant.FASetCheckbox(false);

                Reports.TestStep = "Closing the CDBorrowerInfo Screen";
                FastDriver.CDBorrowerInfo.Done.FAClick();

                Reports.TestStep = "Validating the borrower information in CD Screen as blank";
                //TODO

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_261856_TC_353192_NO_13()
        {
            try
            {
                Reports.TestDescription = "Verify borrower name will be suffixed by + icon is always displayed in CD screen";
                Reports.TestStep = "Login to file side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Create file with Service Type as Title";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First Borrower";
                Buyer_SpAddress("Fname", "Lname", false, "blank");

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                
                Reports.TestStep = "Validating the Borrower + icon";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.BorrowerPlus.Displayed.ToString());


                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion


        #region 332513- CD Screen - Section 1 - Display format for Main Property address and Additional Location on Property label pop up

        [TestMethod]
        public void US_332513_TC_367924_NO_01()
        {
            try
            {

            Reports.TestDescription = "VERIFY THE FIRST PROPERTY INSTANCE IN THE PROPERTY POPUP";
            Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
            FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

            Reports.TestStep = "Create file with Service Type as Title";
            var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
            defaultRequest.formType = FormType.CD;
            defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            Reports.TestStep = "Navigate to QFE Screen";
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>(@"Home>Order Entry>Quick File Entry");
            FastDriver.QuickFileEntry.Continue.FAClick();
            FastDriver.QuickFileEntry.SwitchToContentFrame();
            
            Reports.TestStep = "Validate the address in property tax info screen";
            FastDriver.LeftNavigation.Navigate<CDPropertyInfo>(@"Home>Order Entry>Properties/Tax Info");
            Support.AreEqual("True", FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "1", 1, TableAction.GetText).Message.Contains("1").ToString());

            FastDriver.CDPropertyInfo.Edit.FAClick();

            FastDriver.CDPropertyInfo.Street1.FASetText(Support.RandomString("ANANANAN"));
            FastDriver.CDPropertyInfo.Street2.FASetText(Support.RandomString("ANANANAN"));
            FastDriver.CDPropertyInfo.Street3.FASetText(Support.RandomString("ANANANAN"));
            FastDriver.CDPropertyInfo.Street4.FASetText(Support.RandomString("ANANANAN"));

            FastDriver.CDPropertyInfo.City.FAClick();

            firstaddress[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
            firstaddress[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
            firstaddress[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
            firstaddress[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
            firstaddress[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
            firstaddress[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem();
            firstaddress[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();

            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();

            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
            FastDriver.ClosingDisclosure.SwitchToContentFrame();

            Reports.TestStep = "Navigate to the Property Popup";
            FastDriver.ClosingDisclosure.PropertyPlus.FAClick();

            Reports.TestStep = "Validating First Property Details";
            string prlabel = FastDriver.CDPropertyInfo.PopupLabel.Text;
            prlabel = prlabel.Trim();
            Support.AreEqual("True", prlabel.Equals("Property").ToString());
            string prno = FastDriver.CDPropertyInfo.FirstPropertyNo.Text;
            Support.AreEqual("True", prno.Contains("1").ToString());
            string add1 = FastDriver.CDPropertyInfo.FirstProperty.Text;

            Support.AreEqual("True", add1.Contains(firstaddress[0]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[1]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[2]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[3]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[4]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[5]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[6]).ToString());

            FastDriver.CDPropertyInfo.Done.FAClick();

            Reports.TestStep = "Saving CD Screen";
            FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }

        }

        [TestMethod]
        public void US_332513_TC_367928_NO_02()
        {
            try
            {
                Reports.TestDescription = "VERIFY THE FIRST PROPERTY INSTANCE WITH MULTIPLE ADDITIONAL LOCATION ADDRESS IN THE PROPERTY POPUP";

                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Validate the address in property tax info screen";
                FastDriver.LeftNavigation.Navigate<CDPropertyInfo>(@"Home>Order Entry>Properties/Tax Info");
                Support.AreEqual("True", FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "1", 1, TableAction.GetText).Message.Contains("1").ToString());

                FastDriver.CDPropertyInfo.Edit.FAClick();

                
                FastDriver.CDPropertyInfo.Street1.FASetText(Support.RandomString("ANAN"));
                firstaddress_al1[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
                firstaddress[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street2.FASetText(Support.RandomString("ANAN"));
                firstaddress_al1[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
                firstaddress[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street3.FASetText(Support.RandomString("ANAN"));
                firstaddress_al1[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
                firstaddress[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street4.FASetText(Support.RandomString("ANAN"));
                firstaddress_al1[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
                firstaddress[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.City.FASetText(Support.RandomString("AAAAAAAAA"));
                firstaddress_al1[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
                firstaddress[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.State.FASelectItem("CA");
                firstaddress_al1[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem().ToString();
                firstaddress[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem().ToString();
                FastDriver.CDPropertyInfo.Zip.FASetText(Support.RandomString("NNNNN"));
                firstaddress_al1[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();
                firstaddress[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();

                Reports.TestStep = "Close Property screen";
                Keyboard.SendKeys("^S");
                FastDriver.BottomFrame.Done();

                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Adding second additional locations";
                FastDriver.CDPropertyInfo.SwitchToContentFrame();
                FastDriver.CDPropertyInfo.Edit.FAClick();

                FastDriver.CDPropertyInfo.GeneralNew.FAClick();
                FastDriver.CDPropertyInfo.Street1.FASetText(Support.RandomString("ANAN"));
                firstaddress_al2[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street2.FASetText(Support.RandomString("ANAN"));
                firstaddress_al2[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street3.FASetText(Support.RandomString("ANAN"));
                firstaddress_al2[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street4.FASetText(Support.RandomString("ANAN"));
                firstaddress_al2[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.City.FASetText(Support.RandomString("AAAAAAAAA"));
                firstaddress_al2[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.State.FASelectItem("CA");
                firstaddress_al2[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem().ToString();
                FastDriver.CDPropertyInfo.Zip.FASetText(Support.RandomString("NNNNN"));
                firstaddress_al2[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();

                Reports.TestStep = "Close Property screen";
                Keyboard.SendKeys("^S");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to the Property Popup";
                FastDriver.ClosingDisclosure.PropertyPlus.FAClick();

                Reports.TestStep = "Validating First Property Details";
                string prlabel = FastDriver.CDPropertyInfo.PopupLabel.Text;
                prlabel = prlabel.Trim();
                Support.AreEqual("True", prlabel.Equals("Property").ToString());
                string prno = FastDriver.CDPropertyInfo.FirstPropertyNo.Text;
                Support.AreEqual("True", prno.Contains("1").ToString());
                string add1 = FastDriver.CDPropertyInfo.FirstProperty.Text;

                Support.AreEqual("True", add1.Contains(firstaddress[0]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[1]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[2]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[3]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[4]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[5]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[6]).ToString());

                Reports.TestStep = "Validating First Property First Additional Location Details";
                string add1al1 = FastDriver.CDPropertyInfo.FirstPropertyAL1.Text;

                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[0]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[1]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[2]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[3]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[4]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[5]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[6]).ToString());

                Reports.TestStep = "Validating First Property Second Additional Location Details";
                string add1al2 = FastDriver.CDPropertyInfo.FirstPropertyAL2.Text;

                Support.AreEqual("True", add1al2.Contains(firstaddress_al2[0]).ToString());
                Support.AreEqual("True", add1al2.Contains(firstaddress_al2[1]).ToString());
                Support.AreEqual("True", add1al2.Contains(firstaddress_al2[2]).ToString());
                Support.AreEqual("True", add1al2.Contains(firstaddress_al2[3]).ToString());
                Support.AreEqual("True", add1al2.Contains(firstaddress_al2[4]).ToString());
                Support.AreEqual("True", add1al2.Contains(firstaddress_al2[5]).ToString());
                Support.AreEqual("True", add1al2.Contains(firstaddress_al2[6]).ToString());

                FastDriver.CDPropertyInfo.Done.FAClick();
                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_332513_TC_367930_NO_03()
        {
            try
            {


            Reports.TestDescription = "VERIFY MULTIPLE PROPERTY INSTANCE IN THE PROPERTY POPUP";
            Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
            FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

            Reports.TestStep = "Creating a basic file";
            var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
            defaultRequest.formType = FormType.CD;
            defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

            var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            Reports.TestStep = "Validate the address in property tax info screen";
            FastDriver.LeftNavigation.Navigate<CDPropertyInfo>(@"Home>Order Entry>Properties/Tax Info");
            Support.AreEqual("True", FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "1", 1, TableAction.GetText).Message.Contains("1").ToString());

            FastDriver.CDPropertyInfo.Edit.FAClick();
            
            FastDriver.CDPropertyInfo.Street1.FASetText(Support.RandomString("ANAN"));
            firstaddress[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.Street2.FASetText(Support.RandomString("ANAN"));
            firstaddress[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.Street3.FASetText(Support.RandomString("ANAN"));
            firstaddress[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.Street4.FASetText(Support.RandomString("ANAN"));
            firstaddress[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.City.FASetText(Support.RandomString("AAAAAAAAA"));
            firstaddress[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.State.FASelectItem("CA");
            firstaddress[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem().ToString();
            FastDriver.CDPropertyInfo.Zip.FASetText(Support.RandomString("NNNNN"));
            firstaddress[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();


            Reports.TestStep = "Close Property screen";
            Keyboard.SendKeys("^S");
            FastDriver.BottomFrame.Done();

            FastDriver.WebDriver.HandleDialogMessage();

            Reports.TestStep = "Adding second additional locations";
            FastDriver.CDPropertyInfo.SwitchToContentFrame();
            FastDriver.CDPropertyInfo.New.FAClick();

            FastDriver.CDPropertyInfo.GeneralNew.FAClick();
            FastDriver.CDPropertyInfo.Street1.FASetText(Support.RandomString("ANAN"));
            secondaddress[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.Street2.FASetText(Support.RandomString("ANAN"));
            secondaddress[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.Street3.FASetText(Support.RandomString("ANAN"));
            secondaddress[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.Street4.FASetText(Support.RandomString("ANAN"));
            secondaddress[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.City.FASetText(Support.RandomString("AAAAAAAAA"));
            secondaddress[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
            FastDriver.CDPropertyInfo.State.FASelectItem("CA");
            secondaddress[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem().ToString();
            FastDriver.CDPropertyInfo.Zip.FASetText(Support.RandomString("NNNNN"));
            secondaddress[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();

            Reports.TestStep = "Close Property screen";
            Keyboard.SendKeys("^S");
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Navigate to CD Screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
            FastDriver.ClosingDisclosure.SwitchToContentFrame();

            Reports.TestStep = "Navigate to the Property Popup";
            FastDriver.ClosingDisclosure.PropertyPlus.FAClick();

            Reports.TestStep = "Validating First Property Details";
            string prlabel = FastDriver.CDPropertyInfo.PopupLabel.Text;
            prlabel = prlabel.Trim();
            string prono1 = FastDriver.CDPropertyInfo.FirstPropertyNo.Text;
            Support.AreEqual("True", prono1.Contains("1").ToString());
            string add1 = FastDriver.CDPropertyInfo.FirstProperty.Text;

            Support.AreEqual("True", add1.Contains(firstaddress[0]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[1]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[2]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[3]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[4]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[5]).ToString());
            Support.AreEqual("True", add1.Contains(firstaddress[6]).ToString());

            Reports.TestStep = "Validating Second Property Details";
            string prono2 = FastDriver.CDPropertyInfo.SecondPropertyNo.Text;
            Support.AreEqual("True", prono2.Contains("2").ToString());
            string add2 = FastDriver.CDPropertyInfo.SecondProperty.Text;

            Support.AreEqual("True", add2.Contains(secondaddress[0]).ToString());
            Support.AreEqual("True", add2.Contains(secondaddress[1]).ToString());
            Support.AreEqual("True", add2.Contains(secondaddress[2]).ToString());
            Support.AreEqual("True", add2.Contains(secondaddress[3]).ToString());
            Support.AreEqual("True", add2.Contains(secondaddress[4]).ToString());
            Support.AreEqual("True", add2.Contains(secondaddress[5]).ToString());
            Support.AreEqual("True", add2.Contains(secondaddress[6]).ToString());

            FastDriver.ClosingDisclosure.PropertyDone.FAClick();     
            Reports.TestStep = "Saving CD Screen";
            FastDriver.BottomFrame.Done();
            
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_332513_TC_367931_NO_04()
        {
            try
            {
                Reports.TestDescription = "VERIFY  THE MULTIPLE PROPERTY INSTANCE WITH ADDITIONAL LOCATION ADDRESS IN THE PROPERTY POPUP";

                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Validate the address in property tax info screen";
                FastDriver.LeftNavigation.Navigate<CDPropertyInfo>(@"Home>Order Entry>Properties/Tax Info");
                Support.AreEqual("True", FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "1", 1, TableAction.GetText).Message.Contains("1").ToString());
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CDPropertyInfo.SwitchToContentFrame();

                FastDriver.CDPropertyInfo.Edit.FAClick();

                FastDriver.CDPropertyInfo.Street1.FASetText(Support.RandomString("ANAN"));
                firstaddress[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street2.FASetText(Support.RandomString("ANAN"));
                firstaddress[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street3.FASetText(Support.RandomString("ANAN"));
                firstaddress[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street4.FASetText(Support.RandomString("ANAN"));
                firstaddress[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.City.FASetText(Support.RandomString("AAAAAAAAA"));
                firstaddress[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.State.FASelectItem("CA");
                firstaddress[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem().ToString();
                FastDriver.CDPropertyInfo.Zip.FASetText(Support.RandomString("NNNNN"));
                firstaddress[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();


                Reports.TestStep = "Close Property screen";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CDPropertyInfo.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                FastDriver.PropertiesSummary.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "1", 1, TableAction.GetText).Message.Contains("1").ToString());
                
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CDPropertyInfo.SwitchToContentFrame();
                Playback.Wait(5000);
                FastDriver.CDPropertyInfo.Edit.FAClick();
                Playback.Wait(5000);
                FastDriver.CDPropertyInfo.GeneralNew.FAClick();

                FastDriver.CDPropertyInfo.Street1.FASetText(Support.RandomString("ANAN"));
                firstaddress_al1[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street2.FASetText(Support.RandomString("ANAN"));
                firstaddress_al1[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street3.FASetText(Support.RandomString("ANAN"));
                firstaddress_al1[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street4.FASetText(Support.RandomString("ANAN"));
                firstaddress_al1[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.City.FASetText(Support.RandomString("AAAAAAAAA"));
                firstaddress_al1[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.State.FASelectItem("CA");
                firstaddress_al1[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem().ToString();
                FastDriver.CDPropertyInfo.Zip.FASetText(Support.RandomString("NNNNN"));
                firstaddress_al1[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();

                Reports.TestStep = "Close Property screen";
                FastDriver.BottomFrame.Save(); 
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CDPropertyInfo.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Adding second address and additional locations";
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CDPropertyInfo.SwitchToContentFrame();
                FastDriver.CDPropertyInfo.New.FAClick();
                FastDriver.CDPropertyInfo.GeneralNew.FAClick();

                FastDriver.CDPropertyInfo.Street1.FASetText(Support.RandomString("ANAN"));
                secondaddress[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street2.FASetText(Support.RandomString("ANAN"));
                secondaddress[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street3.FASetText(Support.RandomString("ANAN"));
                secondaddress[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street4.FASetText(Support.RandomString("ANAN"));
                secondaddress[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.City.FASetText(Support.RandomString("AAAAAAAAA"));
                secondaddress[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.State.FASelectItem("CA");
                secondaddress[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem().ToString();
                FastDriver.CDPropertyInfo.Zip.FASetText(Support.RandomString("NNNNN"));
                secondaddress[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();

                Reports.TestStep = "Close Property screen";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.PropertiesSummary.SwitchToContentFrame();
                Support.AreEqual("True", FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "2", 1, TableAction.GetText).Message.Contains("2").ToString());
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(1, "2", 1, TableAction.Click);

                FastDriver.CDPropertyInfo.Edit.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CDPropertyInfo.SwitchToContentFrame();
                FastDriver.CDPropertyInfo.GeneralNew.FAClick();

                FastDriver.CDPropertyInfo.Street1.FASetText(Support.RandomString("ANAN"));
                secondaddress_al1[0] = FastDriver.CDPropertyInfo.Street1.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street2.FASetText(Support.RandomString("ANAN"));
                secondaddress_al1[1] = FastDriver.CDPropertyInfo.Street2.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street3.FASetText(Support.RandomString("ANAN"));
                secondaddress_al1[2] = FastDriver.CDPropertyInfo.Street3.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.Street4.FASetText(Support.RandomString("ANAN"));
                secondaddress_al1[3] = FastDriver.CDPropertyInfo.Street4.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.City.FASetText(Support.RandomString("AAAAAAAAA"));
                secondaddress_al1[4] = FastDriver.CDPropertyInfo.City.FAGetAttribute("value").ToString();
                FastDriver.CDPropertyInfo.State.FASelectItem("CA");
                secondaddress_al1[5] = FastDriver.CDPropertyInfo.State.FAGetSelectedItem().ToString();
                FastDriver.CDPropertyInfo.Zip.FASetText(Support.RandomString("NNNNN"));
                secondaddress_al1[6] = FastDriver.CDPropertyInfo.Zip.FAGetAttribute("value").ToString();

                Reports.TestStep = "Close Property screen";
                Keyboard.SendKeys("^S");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to the property popup";
                FastDriver.ClosingDisclosure.PropertyPlus.FAClick();

                Reports.TestStep = "Validating First Property Details";
                string prlabel = FastDriver.CDPropertyInfo.PopupLabel.Text;
                prlabel = prlabel.Trim();

                Support.AreEqual("True", prlabel.Equals("Property").ToString());

                string prno = FastDriver.CDPropertyInfo.FirstPropertyNo.Text;
                Support.AreEqual("True", prno.Contains("1").ToString());
                string add1 = FastDriver.CDPropertyInfo.FirstProperty.Text;
                Support.AreEqual("True", add1.Contains(firstaddress[0]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[1]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[2]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[3]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[4]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[5]).ToString());
                Support.AreEqual("True", add1.Contains(firstaddress[6]).ToString());

                Reports.TestStep = "Validating First Property and Additional Location Details";

                string add1al1 = FastDriver.CDPropertyInfo.FirstPropertyAL2.Text;
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[0]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[1]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[2]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[3]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[4]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[5]).ToString());
                Support.AreEqual("True", add1al1.Contains(firstaddress_al1[6]).ToString());

                Reports.TestStep = "Validating Second Property and Additional Location Details";
                string prno2 = FastDriver.CDPropertyInfo.SecondPropertyNo.Text;
                Support.AreEqual("True", prno2.Contains("2").ToString());
                string add2 = FastDriver.CDPropertyInfo.SecondProperty.Text;
                Support.AreEqual("True", add2.Contains(secondaddress[0]).ToString());
                Support.AreEqual("True", add2.Contains(secondaddress[1]).ToString());
                Support.AreEqual("True", add2.Contains(secondaddress[2]).ToString());
                Support.AreEqual("True", add2.Contains(secondaddress[3]).ToString());
                Support.AreEqual("True", add2.Contains(secondaddress[4]).ToString());
                Support.AreEqual("True", add2.Contains(secondaddress[5]).ToString());
                Support.AreEqual("True", add2.Contains(secondaddress[6]).ToString());

                string add2al1 = FastDriver.CDPropertyInfo.SecondPropertyAL1.Text;
                Support.AreEqual("True", add2al1.Contains(secondaddress_al1[0]).ToString());
                Support.AreEqual("True", add2al1.Contains(secondaddress_al1[1]).ToString());
                Support.AreEqual("True", add2al1.Contains(secondaddress_al1[2]).ToString());
                Support.AreEqual("True", add2al1.Contains(secondaddress_al1[3]).ToString());
                Support.AreEqual("True", add2al1.Contains(secondaddress_al1[4]).ToString());
                Support.AreEqual("True", add2al1.Contains(secondaddress_al1[5]).ToString());
                Support.AreEqual("True", add2al1.Contains(secondaddress_al1[6]).ToString());

                FastDriver.ClosingDisclosure.PropertyDone.FAClick();
                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region 357473: CD Screen - Settlement Agent - Outside Title Company


        [TestMethod]
        public void US_357473_TC_346430_NO_01()
        {
            try
            {
                Reports.TestDescription = "Verify that the OTC as Settlement Agent in the CD Screen popup";
                Reports.TestStep = "Login to file side";

                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Creating First OTC Instance";
                CreateOTC("247", 1);
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Reports.TestStep = "Navigate to CD Settlement Agent Popup";
                FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();
                Reports.TestStep = "Validating Settlement Agent Details";
                string Table_Data = FastDriver.CDSettlementAgentInfo.SettlementAgentTable.Text;
                Table_Data = Table_Data.Replace("\r", "");
                Table_Data = Table_Data.Replace("\n", " ");
                Table_Data = Table_Data.Replace(" ", "");

                otcdetail[0] = otcdetail[0].Replace(" ", "");
                otcdetail[1] = otcdetail[1].Replace(" ", "");

                Support.AreEqual("True", Table_Data.Contains(otcdetail[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(otcdetail[1]).ToString());
                otcdetail[2] = otcdetail[2].Replace(",", "").Replace("USA", "").Replace("\r", "").Replace("\n", "").Replace(" ", "");
                otcdetail[2] = otcdetail[2].TrimEnd();
                Support.AreEqual("True", Table_Data.Contains(otcdetail[2]).ToString());
                Support.AreEqual("True", Table_Data.Contains("OutsideTitleCompany").ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Selected.ToString());
                                
                FastDriver.CDSettlementAgentInfo.Done.FAClick();
                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex )
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_357473_TC_346435_NO_03()
        {
            try
            {
                Reports.TestDescription = "Verify all File Party Role as Settlement Agent in the CD Screen popup";
                
                Reports.TestStep = "Login to admin side";                

                GetOwningOfficeInfo();
                                
                FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary");
                FastDriver.FeeSetup.SwitchToContentFrame();
                CreateFee("MyFeeDescription1", "Escrow Fee", false, false, "", "K", "K");
                Reports.TestStep = "Login to file side";

                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                
                Reports.TestStep = "Creating 1st OEC";
                CreateOEC("247", 1);
                Reports.TestStep = "Creating 1st OTC";
                CreateOTC("248", 1);

                Reports.TestStep = "Navigate to file fees screen and add fees";
                FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry");
                FastDriver.FileFees.SwitchToContentFrame();

                Playback.Wait(5000);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Escrow Fee");

                FastDriver.FileFees.FeeSearchFeeDescription.FASetText("MyFeeDescription1");
                FastDriver.FileFees.FindNow.FAClick();

                if (FastDriver.FileFees.FeeSearchFeeSelect.Displayed)
                {
                    FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                }
                
                FastDriver.BottomFrame.Done();
                
                Reports.TestStep = "Obtaining Split Payee Information";
                SplitPayee(1);
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Navigate to CD Settlement Agent Popup";
                FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();

                Reports.TestStep = "Validating settlement agent details";
                string Table_Data = FastDriver.ClosingDisclosure.SettlementAgentTable.Text;

                Table_Data = Table_Data.Replace("\r", "");
                Table_Data = Table_Data.Replace("\n", " ");
                Table_Data = Table_Data.Replace(" ", "");

                owningoffice[0] = owningoffice[0].Replace(" ", "");
                owningoffice[1] = owningoffice[1].Replace(" ", "");
                owningoffice[2] = owningoffice[2].Replace(" ", "");
                owningoffice[3] = owningoffice[3].Replace(" ", "");
                owningoffice[4] = owningoffice[4].Replace(" ", "");
                owningoffice[5] = owningoffice[5].Replace(" ", "");
                owningoffice[6] = owningoffice[6].Replace(" ", "");
                owningoffice[7] = owningoffice[7].Replace(" ", "");
                owningoffice[8] = owningoffice[8].Replace(" ", "");

                Support.AreEqual("True", Table_Data.Contains(owningoffice[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[1]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[2]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[3]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[4]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[5]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[6]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[7]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[8]).ToString());
                Support.AreEqual("True", Table_Data.Contains("OwningOffice").ToString());

                oecdetail[0] = oecdetail[0].Replace(" ", "");
                oecdetail[1] = oecdetail[1].Replace(" ", "");

                Support.AreEqual("True", Table_Data.Contains(oecdetail[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(oecdetail[1]).ToString());

                oecdetail[2] = oecdetail[2].Replace(",", "").Replace("USA", "").Replace("\r", "").Replace("\n", "").Replace(" ", "");
                oecdetail[2] = oecdetail[2].TrimEnd();

                Support.AreEqual("True", Table_Data.Contains(oecdetail[1]).ToString());
                Support.AreEqual("True", Table_Data.Contains("OutsideEscrowCompany").ToString());

                otcdetail[0] = otcdetail[0].Replace(" ", "");
                otcdetail[1] = otcdetail[1].Replace(" ", "");

                Support.AreEqual("True", Table_Data.Contains(otcdetail[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(otcdetail[1]).ToString());

                otcdetail[2] = otcdetail[2].Replace(",", "").Replace("USA", "").Replace("\r", "").Replace("\n", "").Replace(" ", "");
                otcdetail[2] = otcdetail[2].TrimEnd();

                Support.AreEqual("True", Table_Data.Contains(otcdetail[2]).ToString());
                Support.AreEqual("True", Table_Data.Contains("OutsideEscrowCompany").ToString());
                
                splitpayee1[0] = splitpayee1[0].Replace(" ", "");
                splitpayee1[1] = splitpayee1[1].Replace(" ", "");
                splitpayee1[2] = splitpayee1[2].Replace(" ", "");
                splitpayee1[3] = splitpayee1[3].Replace(" ", "");
                splitpayee1[4] = splitpayee1[4].Replace(" ", "");

                Support.AreEqual("True", Table_Data.Contains(splitpayee1[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(splitpayee1[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(splitpayee1[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(splitpayee1[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains("SplitPayee").ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent3RadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSettlementAgentInfo.SettlementAgent3RadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent4RadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSettlementAgentInfo.SettlementAgent4RadioButton.Selected.ToString());

                FastDriver.CDSettlementAgentInfo.Done.FAClick();

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        [TestMethod]
        public void US_357473_TC_350418_NO_04()
        {
            try
            {
                Reports.TestDescription = "Verify Settlement Agent in the CD Screen popup after deleting OTC Instance- Adhoc";
                GetOwningOfficeInfo();
                Reports.TestStep = "Login to file side";

                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);
                
                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.StatusUpdate("Creating a basic file", File.FileNumber != "" ? true : false);
                Reports.TestStep = "Creating First OTC Instance";
                CreateOTC("HUDFLINSR1", 1);
                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                
                Reports.TestStep = "Navigate to CD Settlement Agent Popup";
                FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();

                Reports.TestStep = "Validating Settlement Agent Details";
                string Table_Data = FastDriver.ClosingDisclosure.SettlementAgentTable.Text;

                Table_Data = Table_Data.Replace("\r", "");
                Table_Data = Table_Data.Replace("\n", " ");
                Table_Data = Table_Data.Replace(" ", "");

                otcdetail[0] = otcdetail[0].Replace(" ", "");
                otcdetail[1] = otcdetail[1].Replace(" ", "");
                Support.AreEqual("True", Table_Data.Contains(otcdetail[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(otcdetail[1]).ToString());
                otcdetail[2] = otcdetail[2].Replace(",", "").Replace("USA", "").Replace("\r", "").Replace("\n", "").Replace(" ", "");
                otcdetail[2] = otcdetail[2].TrimEnd();
                Support.AreEqual("True", Table_Data.Contains(otcdetail[2]).ToString());
                Support.AreEqual("True", Table_Data.Contains("OutsideTitleCompany").ToString());

                
                owningoffice[0] = owningoffice[0].Replace(" ", "");
                owningoffice[1] = owningoffice[1].Replace(" ", "");
                owningoffice[2] = owningoffice[2].Replace(" ", "");
                owningoffice[3] = owningoffice[3].Replace(" ", "");
                owningoffice[4] = owningoffice[4].Replace(" ", "");
                owningoffice[5] = owningoffice[5].Replace(" ", "");
                owningoffice[6] = owningoffice[6].Replace(" ", "");
                owningoffice[7] = owningoffice[7].Replace(" ", "");
                owningoffice[8] = owningoffice[8].Replace(" ", "");

                Support.AreEqual("True", Table_Data.Contains(owningoffice[0]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[1]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[2]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[3]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[4]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[5]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[6]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[7]).ToString());
                Support.AreEqual("True", Table_Data.Contains(owningoffice[8]).ToString());
                Support.AreEqual("True", Table_Data.Contains("OwningOffice").ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Selected.ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Displayed.ToString());
                Support.AreEqual("False", FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.Selected.ToString());

                FastDriver.CDSettlementAgentInfo.SettlementAgent2RadioButton.FAClick();

                Reports.TestStep = "Saving CD Screen";
                FastDriver.CDSettlementAgentInfo.Done.FAClick();

                Reports.TestStep = "Validating the new Settlement Agent in CD Screen";
                string agent_name = FastDriver.ClosingDisclosure.SettlementAgentValue.Text;
                agent_name = agent_name.Replace("*", "");
                agent_name = agent_name.Replace(" ", "");

                Support.AreEqual("True", otcdetail[0].Contains(agent_name).ToString());



                Reports.TestStep = "Navigate to OTC Screen";
                FastDriver.LeftNavigation.Navigate<OutsideTitleSummary>(@"Home>Order Entry>Outside Title Company");
                FastDriver.OutsideTitleSummary.SwitchToContentFrame();

                Reports.TestStep = "Delete First OTC Instance";
                FastDriver.BottomFrame.New();

                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.GABcode.FASetText("237");
                FastDriver.OTCDetail.Find.FAClick();

                FastDriver.BottomFrame.Done();

                FastDriver.OutsideTitleSummary.SwitchToContentFrame();
                Playback.Wait(5000);
                FastDriver.OutsideTitleSummary.SummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);

                FastDriver.OutsideTitleSummary.Remove.FAClick();

                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Navigate to CD Screen";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Validating the Owning office as settlement agent in CD Screen";
                FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();

                Reports.TestStep = "Validating Settlement Agent Details";
                string cdname = FastDriver.ClosingDisclosure.SettlementAgentTable.Text;
                cdname = cdname.Replace(" ", "");
                cdname = cdname.Replace("*", "");

                Support.AreEqual("True", cdname.Contains(owningoffice[0].Substring(0, 24)).ToString());
                Support.AreEqual("False", cdname.Contains(otcdetail[0]).ToString());
                Support.AreEqual("False", cdname.Contains(otcdetail[1]).ToString());

                Reports.TestStep = "Validate that Settlement Agent Popup is not displaying OTC Details";
                FastDriver.ClosingDisclosure.SettlementAgentPlus.FAClick();

                string Table_Data1 = FastDriver.CDSettlementAgentInfo.SettlementAgentTable.Text;
                Table_Data1 = Table_Data1.Replace("\r", "");
                Table_Data1 = Table_Data1.Replace("\n", "");
                Table_Data1 = Table_Data1.Replace(" ", "");

                Support.AreEqual("True", Table_Data1.Contains(owningoffice[0]).ToString());
                Support.AreEqual("True", Table_Data1.Contains(owningoffice[1]).ToString());
                Support.AreEqual("True", Table_Data1.Contains(owningoffice[2]).ToString());
                Support.AreEqual("True", Table_Data1.Contains(owningoffice[3]).ToString());
                Support.AreEqual("True", Table_Data1.Contains(owningoffice[4]).ToString());
                Support.AreEqual("True", Table_Data1.Contains(owningoffice[5]).ToString());
                Support.AreEqual("True", Table_Data1.Contains(owningoffice[6]).ToString());
                Support.AreEqual("True", Table_Data1.Contains(owningoffice[7]).ToString());
                Support.AreEqual("True", Table_Data1.Contains(owningoffice[8]).ToString());
                Support.AreEqual("True", Table_Data1.Contains("OwningOffice").ToString());

                Support.AreEqual("False", Table_Data1.Contains(otcdetail[0]).ToString());
                Support.AreEqual("False", Table_Data1.Contains(otcdetail[1]).ToString());
                Support.AreEqual("False", Table_Data1.Contains(otcdetail[2]).ToString());

                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Displayed.ToString());
                Support.AreEqual("True", FastDriver.CDSettlementAgentInfo.SettlementAgent1RadioButton.Selected.ToString());

                FastDriver.CDSettlementAgentInfo.Done.FAClick();

                Reports.TestStep = "Saving CD Screen";
                FastDriver.BottomFrame.Done();


            }
            catch (Exception ex)
            {                
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region USER STORY 368905: CD Screen- Section 2 - Validation on Loan Terms when clauses are not entered
        
        #region User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Loan Amount when its corresponding dropdown value is selected as YES
        [TestMethod]
        public void FTR5_ITR33_US_368905_TC_385179()
        {
            try
            {
                Reports.TestDescription = "User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Loan Amount when its corresponding dropdown value is selected as YES";
                
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.StatusUpdate("Creating a basic file", File.FileNumber != "" ? true : false);

                //Reports.StatusUpdate("CD SHARED STEPS", )
                Reports.TestStep = "Expand Loan Term section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Selecting Yes option for Loan Amount";
                FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown.FASelectItem("YES");

                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Adding Clause for Interest Rate element";                
                Add_InterestRate_PredefinedClause();

                Reports.TestStep = "Adding Clause for Principal Interests element";
                Add_Pricipal_Interest_PredefinedClause();

                Reports.TestStep = "Adding Clause for Prepayment Penalty element ";
                Add_PrePayment_Penalty_PredefinedClause();

                Reports.TestStep = "Adding Clause for Ballon payment element ";
                Add_Ballon_Payment_PredefinedClause();
                              
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify error message and click on Ok";
                //String message = "Each YES response requires at least one reponse clause in the Loan Terms section. Please select a response clause. Otherwise the system will change YES to NO. Continue?";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Verify Dropdown value should be changed to NO for Loan Amount Element";
                string selectedOption = FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown.FAGetSelectedItem().ToString();
                Support.AreEqual("NO", selectedOption);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        


        }

        #endregion
        
        #region User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Interest Rate when its corresponding dropdown value is selected as YES
        [TestMethod]
        public void FTR5_ITR33_US_368905_TC_385202()
        {
            try
            {
                Reports.TestDescription = "User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Interest Rate when its corresponding dropdown value is selected as YES";

                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Adding Clause for Loan Amount element ";
                Add_LoanAmount_PredefinedClause();

                Reports.TestStep = "Selecting Yes option for Interest Rate";
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItem("YES");

                Reports.TestStep = "Adding Clause for Pricipal Interets element";
                Add_Pricipal_Interest_PredefinedClause();

                Reports.TestStep = "Adding Clause for Prepayment Penalty element ";
                Add_PrePayment_Penalty_PredefinedClause();

                Reports.TestStep = "Adding Clause for Ballon payment element ";
                Add_Ballon_Payment_PredefinedClause();

                Reports.TestStep = "Click on Done";

                Reports.TestStep = "Verify error message and click on Ok";
                //String message = "Each YES response requires at least one reponse clause in the Loan Terms section. Please select a response clause. Otherwise the system will change YES to NO. Continue?";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Verify Dropdown value should be changed to NO for Interest Rate Element";
                string selectedOption = FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FAGetSelectedItem();
                Support.AreEqual("", selectedOption);

                FastDriver.WebDriver.HandleDialogMessage(true, true);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion

        #region User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Monthly Principal and Interest when its corresponding dropdown value is selected as YES
        [TestMethod]
        public void FTR5_ITR33_US_368905_TC_385204()
        {
            try
            {
                Reports.TestDescription = "User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Monthly Principal and Interest when its corresponding dropdown value is selected as YES";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Adding Clause for Loan Amount element ";
                Add_LoanAmount_PredefinedClause();

                Reports.TestStep = "Adding Clause for Interest Rate element ";
                Add_InterestRate_PredefinedClause();

                Reports.TestStep = "Selecting Yes option for Pricipal Interest Rate element ";
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItem("YES");

                Reports.TestStep = "Adding Clause for Prepayment Penalty element ";
                Add_PrePayment_Penalty_PredefinedClause();

                Reports.TestStep = "Adding Clause for Ballon payment element ";
                Add_Ballon_Payment_PredefinedClause();

                Reports.TestStep = "Click on Done";

                Reports.TestStep = "Verify error message and click on Ok";
                //String message = "Each YES response requires at least one reponse clause in the Loan Terms section. Please select a response clause. Otherwise the system will change YES to NO. Continue?";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Verify Dropdown value should be changed to NO for Pricipal Interest Element";
                string selectedOption = FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FAGetSelectedItem();
                Support.AreEqual("", selectedOption);

                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion

        #region User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Prepayment Penalty when its corresponding dropdown value is selected as YES
        [TestMethod]
        public void FTR5_ITR33_US_368905_TC_385205()
        {
            try
            {
                Reports.TestDescription = "User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Prepayment Penalty when its corresponding dropdown value is selected as YES";

                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Adding Clause for Loan Amount element ";
                Add_LoanAmount_PredefinedClause();

                Reports.TestStep = "Adding Clause for Interest Rate element ";
                Add_InterestRate_PredefinedClause();

                Reports.TestStep = "Selecting Yes option for Prepayment penalty element ";
                FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown.FASelectItem("YES");

                Reports.TestStep = "Adding Clause for Ballon payment element ";
                Add_Ballon_Payment_PredefinedClause();

                Reports.TestStep = "Click on Done";

                Reports.TestStep = "Verify error message and click on Ok";
                //String message = "Each YES response requires at least one reponse clause in the Loan Terms section. Please select a response clause. Otherwise the system will change YES to NO. Continue?";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Verify Dropdown value should be changed to NO for Prepayment Penalty Element";
                string selectedOption = FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown.FAGetSelectedItem();
                Support.AreEqual("", selectedOption);

                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion
        
        #region User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Balloon Payment when its corresponding dropdown value is selected as YES
        [TestMethod]
        public void FTR5_ITR33_US_368905_TC_385207()
        {
            try
            {
                Reports.TestDescription = "User Story : 368905 : CD Screen- Section 2 - Verify error message when clause is entered for all Loan Terms elements except Balloon Payment when its corresponding dropdown value is selected as YES";

                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Adding Clause for Loan Amount element ";
                Add_LoanAmount_PredefinedClause();

                Reports.TestStep = "Adding Clause for Interest Rate element ";
                Add_InterestRate_PredefinedClause();

                Reports.TestStep = "Adding Clause for Pricipal Interets element ";
                Add_Pricipal_Interest_PredefinedClause();

                Reports.TestStep = "Adding Clause for Prepayment Penalty element ";
                Add_PrePayment_Penalty_PredefinedClause();

                Reports.TestStep = "Selecting Yes option for Baloon Payment element ";
                FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown.FASelectItem("YES");

                Reports.TestStep = "Click on Done";

                Reports.TestStep = "Verify error message and click on Ok";
                //String message = "Each YES response requires at least one reponse clause in the Loan Terms section. Please select a response clause. Otherwise the system will change YES to NO. Continue?";
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Verify Dropdown value should be changed to NO for Baloon Payment Element";
                string selectedOption = FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown.FAGetSelectedItem();
                Support.AreEqual("", selectedOption);

                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion

        #region User Story : 368905 : CD Screen- Section 2 - Verify error message when clauses are not entered for Loan Terms elements when any dropdown is selected as YES
        [TestMethod]
        public void FTR5_ITR33_US_368905_TC_385180()
        {
            try
            {
                Reports.TestDescription = "User Story : 368905 : CD Screen- Section 2 - Verify error message when clauses are not entered for Loan Terms elements when any dropdown is selected as YES";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                
                Verify_SelectedOption("Loan amount", FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown);
                Verify_SelectedOption("Interest rate", FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown);
                Verify_SelectedOption("Pricipal and Interest", FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown);
                Verify_SelectedOption("Prepayment penalty", FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown);
                Verify_SelectedOption("Baloon Payment", FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            
        }
        #endregion


        #endregion


        #region USER STORY 379009: CD SCREEN - LOAN APPLICANT FLAG ON BORROWER LABEL FOR HUSBAND/WIFE BUYER TYPE

        #region USER STORY -379009 : VERIFY BORROWER UNDER TRANSACTION  INFORMATION WHEN LOAN APPLICANT IS UNCHECKED FOR BOTH SPOUSES
        [TestMethod]
        public void FTR5_ITR38_US_379009_TC_384413()
        {
            try
            {
                Reports.TestDescription = "USER STORY- 379009 : VERIFY BORROWER UNDER TRANSACTION  INFORMATION WHEN LOAN APPLICANT IS UNCHECKED FOR BOTH SPOUSES";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Setup Buyer Instance For Husband/Wife";

                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);

                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("H");
                Playback.Wait(3000);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Peter");
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText("Parker");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Maria");
                FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.FASetCheckbox(false);
                
                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Verify (+) icon";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.BorrowerPlus.Displayed.ToString());

                Reports.TestStep = "Verify Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "Verify spouse1 snd spouse2 name";
                Support.AreEqual("Peter Parker and Maria Parker", FastDriver.ClosingDisclosure.BorrowerDetailsTable.PerformTableAction(2, "Peter Parker and Maria Parker", 2, TableAction.GetText).Message);

                Reports.TestStep = "Verify spouse1 and spouse2 checkbox";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.Spouse1.Selected.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.Spouse2.Selected.ToString());

                Reports.TestStep = "Check spouse1 checkbox";
                FastDriver.ClosingDisclosure.Spouse1.FASetCheckbox(true);

                Reports.TestStep = "Closing Borrower screen";
                FastDriver.ClosingDisclosure.BorrowerDoneButton.FAClick();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "VERIFY SPOUSE1 AND SPOUSE2 NAME AS BORROWER AFTER CLICKING DONE";
                Support.AreEqual("*Peter Parker and Maria", FastDriver.ClosingDisclosure.BorrowerName.Text);

                Reports.TestStep = "CLICK ON SAVE";
                FastDriver.BottomFrame.Done();
                
                FastDriver.ClosingDisclosure.SwitchToContentFrame();                
                Playback.Wait(3000);
                    
                Reports.TestStep = "VERIFY SPOUSE1 NAME AS BORROWER AFTER SAVING";
                Support.AreEqual("*Peter Parker and Maria", FastDriver.ClosingDisclosure.BorrowerName.Text);


                Reports.TestStep = "NAVIGATE TO BYER INSTANCE VERIFY LOAN APPLICANT CHECKBOX STATE";

                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 1, TableAction.DoubleClick);

                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Playback.Wait(3000);
                Reports.TestStep = "VERIFY SPOUSE1 and SPOUSE2 LOAN APPLICANT CHECKBOX ON THE BYER SCREEN";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.Selected.ToString());
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Spouse2LoanApplicant.Selected.ToString());
                

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion

        #region USER STORY -379009 : VERIFY BORROWER UNDER TRANSACTION  INFORMATION WHEN LOAN APPLICANT IS CHECKED FOR SECOND SPOUSE BUT NOT FOR FIRST
        [TestMethod]
        public void FTR5_ITR38_US_379009_TC_384419()
        {
            try
            {
                Reports.TestDescription = "USER STORY-379009 : VERIFY BORROWER UNDER TRANSACTION  INFORMATION WHEN LOAN APPLICANT IS CHECKED FOR SECOND SPOUSE BUT NOT FOR FIRST";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);                

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Setup Byer Instance For Husband/Wife";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();

                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);

                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("H");
                Playback.Wait(3000);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Peter");
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText("Parker");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Maria");
                FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.FASetCheckbox(false);

                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Verify (+) icon";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.BorrowerPlus.Displayed.ToString());

                Reports.TestStep = "Verify Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "Verify spouse1 snd spouse2 name";
                Support.AreEqual("Peter Parker and Maria Parker", FastDriver.ClosingDisclosure.BorrowerDetailsTable.PerformTableAction(2, "Peter Parker and Maria Parker", 2, TableAction.GetText).Message);

                Reports.TestStep = "Verify spouse1 and spouse2 checkbox";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.Spouse1.Selected.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.Spouse2.Selected.ToString());

                FastDriver.ClosingDisclosure.BorrowerDoneButton.FAClick();
               

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            
        }
        #endregion

        #region USER STORY -379009 : VERIFY SYSTEM DOES NOT ALLOW TO NAVIGATE ANYWHERE WHEN BORROWER DETAILS POP UP IS OPEN

        [TestMethod]
        public void FTR5_ITR38_US_379009_TC_384436()
        {
            try
            {
                Reports.TestDescription = "USER STORY -379009 : VERIFY SYSTEM DOES NOT ALLOW TO NAVIGATE ANYWHERE WHEN BORROWER DETAILS POP UP IS OPEN";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Setup Byer Instance For Husband/Wife";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();

                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);

                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("H");
                Playback.Wait(3000);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Peter");
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText("Parker");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Maria");

                Reports.TestStep = "Click on done";
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Verify (+) icon";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.BorrowerPlus.Displayed.ToString());

                Reports.TestStep = "Verify Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "Verify spouse1 snd spouse2 name";
                Support.AreEqual("Peter Parker and Maria Parker", FastDriver.ClosingDisclosure.BorrowerDetailsTable.PerformTableAction(2, "Peter Parker and Maria Parker", 2, TableAction.GetText).Message);

                Reports.TestStep = "Verify spouse1 and spouse2 checkbox";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.Spouse1.Selected.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.Spouse2.Selected.ToString());

                FastDriver.ClosingDisclosure.Spouse1.FASetCheckbox(false);
                FastDriver.ClosingDisclosure.Spouse2.FASetCheckbox(false);
                
                FastDriver.LeftNavigation.ClickHome();
                
                Reports.TestStep = "VERIFY IE MESSAGE POPUP";
                String message = "Please close the dialog window before save.";
                Support.AreEqual(message, FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow:false).ToString());

                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton:false);

                Reports.TestStep = "Done";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.BorrowerDoneButton.FAClick();


                Reports.TestStep = "VERIFY NO SPOUSE NAME AS BORROWER AFTER CLICKING DONE";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.BorrowerName.Displayed.ToString());

                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();

                Playback.Wait(3000);
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Reports.TestStep = "VERIFY NO SPOUSE NAME AS BORROWER AFTER SAVING";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.BorrowerName.Displayed.ToString());

                Reports.TestStep = "NAVIGATE TO BYER INSTANCE VERIFY LOAN APPLICANT CHECKBOX STATE";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();

                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.Selected.ToString());
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.Spouse2LoanApplicant.Selected.ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion

        #region USER STORY -379009 : VERIFY BORROWER UNDER TRANSACTION  INFORMATION FOR MORE THAN 1 INSTANCE OF BUYER
        [TestMethod]
        public void FTR5_ITR38_US_379009_TC_384425()
        {
            try
            {
                Reports.TestDescription = "USER STORY-379009 : VERIFY BORROWER UNDER TRANSACTION  INFORMATION FOR MORE THAN 1 INSTANCE OF BUYER";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Setup Byer Instance For Husband/Wife";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();

                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);

                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("H");
                Playback.Wait(3000);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("Peter");
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText("Parker");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Maria");
                FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.FASetCheckbox(false);
                FastDriver.BuyerSellerSetup.Spouse2LoanApplicant.FASetCheckbox(false);


                Reports.TestStep = "Click on done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Setup 2nd Byer Instance For Husband/Wife";
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.btnNew.FAClick();

                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItemBySendingKeys("H");
                Playback.Wait(3000);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                FastDriver.BuyerSellerSetup.Husband1FirstName.FASetText("James");
                FastDriver.BuyerSellerSetup.Husband2LastName.FASetText("Martin");
                FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FASetText("Julia");                
                FastDriver.BuyerSellerSetup.Spouse2LoanApplicant.FASetCheckbox(false);
                
                Reports.TestStep = "Click on done";
                FastDriver.BottomFrame.Done();

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Verify (+) icon";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.BorrowerPlus.Displayed.ToString());

                Reports.TestStep = "VERIFY BORROWER NAME";
                Support.AreEqual("James Martin", FastDriver.ClosingDisclosure.BorrowerName.Text);

                Reports.TestStep = "Verify Popup";
                FastDriver.ClosingDisclosure.BorrowerPlus.FAClick();

                Reports.TestStep = "VERIFY SPOUSE1 and SPOUSE2 NAME FOR BOTH BYER INSTANCE";
                Support.AreEqual("Peter Parker and Maria Parker", FastDriver.ClosingDisclosure.BorrowerDetailsTable.PerformTableAction(2, "Peter Parker and Maria Parker", 2, TableAction.GetText).Message);
                Support.AreEqual("James Martin and Julia Martin", FastDriver.ClosingDisclosure.BorrowerDetailsTable.PerformTableAction(2, "James Martin and Julia Martin", 2, TableAction.GetText).Message);

                Support.AreEqual("False", FastDriver.ClosingDisclosure.Spouse1.Selected.ToString());
                Support.AreEqual("False", FastDriver.ClosingDisclosure.Spouse2.Selected.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.Byer2Spouse1.Selected.ToString());
                Support.AreEqual("False", FastDriver.ClosingDisclosure.Byer2Spouse2.Selected.ToString());

                Reports.TestStep = "CHECK SPOUSE1 CHECKBOX";
                FastDriver.ClosingDisclosure.Spouse1.FASetCheckbox(true);

                Reports.TestStep = "Done";
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.BorrowerDoneButton.FAClick();

                Reports.TestStep = "VERIFY SPOUSE1 AND SPOUSE2 NAME AS BORROWER AFTER CLICKING DONE";
                Support.AreEqual("*Peter Parker", FastDriver.ClosingDisclosure.BorrowerName.Text);

                Reports.TestStep = "CLICK ON SAVE";
                FastDriver.BottomFrame.Done();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Playback.Wait(3000);

                Reports.TestStep = "VERIFY SPOUSE1 NAME AS BORROWER AFTER SAVING";
                Support.AreEqual("*Peter Parker", FastDriver.ClosingDisclosure.BorrowerName.Text);


                Reports.TestStep = "NAVIGATE TO BYER INSTANCE VERIFY LOAN APPLICANT CHECKBOX STATE";

                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "1", 1, TableAction.DoubleClick);

                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                Playback.Wait(3000);
                Reports.TestStep = "VERIFY SPOUSE1 and SPOUSE2 LOAN APPLICANT CHECKBOX ON THE BYER SCREEN";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.Selected.ToString());
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.Spouse2LoanApplicant.Selected.ToString());

                Reports.TestStep = "NAVIGATE TO BYER INSTANCE 2 VERIFY LOAN APPLICANT CHECKBOX STATE";
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(1, "2", 1, TableAction.DoubleClick);
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                
                Playback.Wait(3000);
                Reports.TestStep = "VERIFY SPOUSE1 and SPOUSE2 LOAN APPLICANT CHECKBOX ON THE BYER SCREEN";
                Support.AreEqual("True", FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.Selected.ToString());
                Support.AreEqual("False", FastDriver.BuyerSellerSetup.Spouse2LoanApplicant.Selected.ToString());

                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            
        }
        #endregion

        #endregion

        #region USER STORY 372154: FAST - ENTER LOAN TERMS DATA FOR CD XML GENERATION

        #region USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD LOAN AMOUNT ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .

        [TestMethod]
        public void FTR5_ITR33_US_372154_TC_403850()
        {
            try
            {
                Reports.TestDescription = "USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD LOAN AMOUNT ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "EXPAND LOAN TERM SECTION";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "Adding Clause for loan amount element";
                Add_LoanAmount_PredefinedClause();

                Reports.TestStep = "CLICK ON DONE";
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_Clause1.Displayed.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_Clause2.Displayed.ToString());


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion

        #region USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD INTEREST RATE ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .

        [TestMethod]
        public void FTR5_ITR33_US_372154_TC_403870()
        {
            try
            {
                Reports.TestDescription = "USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD INTEREST RATE ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "EXPAND LOAN TERM SECTION";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "ADDING CLAUSE FOR INTEREST RATE ELEMENT";
                Add_InterestRate_PredefinedClause();

                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                
                Reports.TestStep = "Expand loan term section";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_IR_Clause1.Displayed.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_IR_Clause2.Displayed.ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            
        }

        #endregion

        #region USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD PRINCIPAL & INTEREST ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .

        [TestMethod]
        public void FTR5_ITR33_US_372154_TC_403881()
        {
            try
            {


                Reports.TestDescription = "USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD PRINCIPAL & INTEREST ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "EXPAND LOAN TERM SECTION";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();
                Reports.TestStep = "ADDING CLAUSE FOR PRICIPAL & INTEREST RATE ELEMENT";
                Add_Pricipal_Interest_PredefinedClause();

                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_PI_Clause1.Displayed.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_PI_Clause1.Displayed.ToString());

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #region USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD PREPAYMENT PENALTY ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .

        [TestMethod]
        public void FTR5_ITR33_US_372154_TC_403896()
        {
            try
            {
                Reports.TestDescription = "USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD PREPAYMENT PENALTY ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "EXPAND LOAN TERM SECTION";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "ADDING CLAUSE FOR PREPAYMENT PENALTY ELEMENT";
                Add_PrePayment_Penalty_PredefinedClause();

                Reports.TestStep = "CLICK ON DONE";
                FastDriver.BottomFrame.Done();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                FastDriver.ClosingDisclosure.LoanTerm_PP_plusIcon.FAClick();
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_PP_Clause1.Displayed.ToString());
                
                FastDriver.WebDriver.HandleDialogMessage(true,true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);

                
            }
            catch (Exception ex )
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion

        #region USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD BALLOON PAYMENT ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .

        [TestMethod]
        public void FTR5_ITR33_US_372154_TC_403902()
        {
            try
            {
                Reports.TestDescription = "USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD BALLOON PAYMENT ELEMENT WITH PREDEFINED RESPOND CLAUSE TO LOAN TERMS SECTION .";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "EXPAND LOAN TERM SECTION";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "ADDING CLAUSE FOR BALOON PAYMENT ELEMENT";
                Add_Ballon_Payment_PredefinedClause();

                Reports.TestStep = "CLICK ON DONE";
                FastDriver.BottomFrame.Done();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                FastDriver.ClosingDisclosure.LoanTerm_BP_plusIcon.FAClick();
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_BP_Clause1.Displayed.ToString());

                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion

        #region USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD OPTIONAL CLAUSE TO LOAN TERMS SECTION .

        [TestMethod]
        public void FTR5_ITR33_US_372154_TC_403853()
        {
            try
            {
                Reports.TestDescription = "USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD OPTIONAL CLAUSE TO LOAN TERMS SECTION .";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();


                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FAClick();

                Reports.TestStep = "EXPAND LOAN TERM SECTION";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "ADDING OPTIONAL CLAUSE FOR LOAN AMOUNT ELEMENT";
                Add_Optionalclause(FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown, FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_plusIcon);

                Reports.TestStep = "ADDING OPTIONAL CLAUSE FOR INTEREST RATE ELEMENT";
                Add_Optionalclause(FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown, FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon);

                Reports.TestStep = "ADDING OPTIONAL CLAUSE FOR PRICIPAL INTEREST ELEMENT";
                Add_Optionalclause(FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown, FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon);

                Reports.TestStep = "ADDING OPTIONAL CLAUSE FOR PREPAYMENT PENALTY ELEMENT";
                Add_Optionalclause(FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown, FastDriver.ClosingDisclosure.LoanTerm_PP_plusIcon);

                Reports.TestStep = "ADDING OPTIONAL CLAUSE FOR BALOON PAYMENT ELEMENT";
                Add_Optionalclause(FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown, FastDriver.ClosingDisclosure.LoanTerm_BP_plusIcon);

                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Playback.Wait(5000);

                Reports.TestStep = "Expand Loan Term section";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "VERIFY TWO OPTIONAL CLAUSE ADDED ON THE SCREEN";
                FastDriver.ClosingDisclosure.LoanTerm_BP_plusIcon.FAClick();
                ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));

                Support.AreEqual("True", (CheckBoxes.Count >= 3).ToString());
                            
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            
        }
        #endregion

        #region USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD REMOVE CLAUSE FROM LOAN TERMS SECTION .

        [TestMethod]
        public void FTR5_ITR33_US_372154_TC_403858()
        {
            try
            {
                Reports.TestDescription = "USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD REMOVE CLAUSE FROM LOAN TERMS SECTION .";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();


                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FAClick();

                Reports.TestStep = "EXPAND LOAN TERM SECTION";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                #region LOAN AMOUNT
                Reports.TestStep = "Adding clause for loan amount element";
                Add_LoanAmount_PredefinedClause();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_Clause1.Displayed.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_Clause2.Displayed.ToString());

                Reports.TestStep = "REMOVE CLAUSE FROM THE SCREEN";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_plusIcon);

                Reports.TestStep = "VERIFY CLAUSE REMOVED FROM THE SCREEN";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_Clause1.Displayed.ToString());
                Support.AreEqual("False", FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_Clause2.Displayed.ToString());
                #endregion

                #region INTEREST RATE
                Reports.TestStep = "ADDING CLAUSE FOR INTEREST RATE ELEMENT";
                Add_InterestRate_PredefinedClause();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_IR_Clause1.Displayed.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_IR_Clause2.Displayed.ToString());

                Reports.TestStep = "REMOVE CLAUSE FROM THE SCREEN";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon);

                Reports.TestStep = "VERIFY CLAUSE REMOVED FROM THE SCREEN";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.LoanTerm_IR_Clause1.Displayed.ToString());
                Support.AreEqual("False", FastDriver.ClosingDisclosure.LoanTerm_IR_Clause2.Displayed.ToString());
                #endregion

                #region PRINCIPAL INTEREST
                Reports.TestStep = "ADDING CLAUSE FOR PRINCIPAL INTEREST";
                Add_Pricipal_Interest_PredefinedClause();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_PI_Clause1.Displayed.ToString());
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_PI_Clause2.Displayed.ToString());

                Reports.TestStep = "REMOVE CLAUSE FROM THE SCREEN";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon);

                Reports.TestStep = "VERIFY CLAUSE REMOVED FROM THE SCREEN";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.LoanTerm_PI_Clause1.Displayed.ToString());
                Support.AreEqual("False", FastDriver.ClosingDisclosure.LoanTerm_PI_Clause2.Displayed.ToString());
                #endregion

                #region PREPAYMENT PENALTY
                Reports.TestStep = "ADDING CLAUSE FOR PREPAYMENT PENALTY";
                Add_PrePayment_Penalty_PredefinedClause();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                FastDriver.ClosingDisclosure.LoanTerm_PP_plusIcon.FAClick();
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_PP_Clause1.Displayed.ToString());
                
                Reports.TestStep = "REMOVE CLAUSE FROM THE SCREEN";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_PP_plusIcon);

                Reports.TestStep = "VERIFY CLAUSE REMOVED FROM THE SCREEN";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.LoanTerm_PP_Clause1.Displayed.ToString());
                
                #endregion

                #region BALOON PAYMENT
                Reports.TestStep = "ADDING CLAUSE FOR BALOON PAYMENT";
                Add_Ballon_Payment_PredefinedClause();

                Reports.TestStep = "VERIFY CLAUSE ADDED ON THE SCREEN";
                FastDriver.ClosingDisclosure.LoanTerm_BP_plusIcon.FAClick();
                Support.AreEqual("True", FastDriver.ClosingDisclosure.LoanTerm_BP_Clause1.Displayed.ToString());

                Reports.TestStep = "REMOVE CLAUSE FROM THE SCREEN";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_BP_plusIcon);

                Reports.TestStep = "VERIFY CLAUSE REMOVED FROM THE SCREEN";
                Support.AreEqual("False", FastDriver.ClosingDisclosure.LoanTerm_BP_Clause1.Displayed.ToString());

                #endregion

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            

        }
        #endregion

        #region USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD LOAN AMOUNT ELEMENT WITH MAX 10 OPTIONAL CLAUSE TO LOAN TERMS SECTION .

        [TestMethod]
        public void FTR5_ITR33_US_372154_TC_OPTIONALCLAUSE_MAX()
        {
            try
            {
                Reports.TestDescription = "USER STORY 372154 : CD SCREEN LOAN TERMS - VERIFY  FAST USER CAN ADD LOAN AMOUNT ELEMENT WITH MAX 10 OPTIONAL CLAUSE TO LOAN TERMS SECTION .";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();

                FastDriver.ClosingDisclosure.DisplayLoanEstimate.FAClick();

                Reports.TestStep = "EXPAND LOAN TERM SECTION";
                FastDriver.ClosingDisclosure.Section2_LoanTerms.FAClick();

                Reports.TestStep = "ADDING MAX OPTIONAL CLAUSE FOR LOAN AMOUNT ELEMENT AND VERIFY ERROR MESSAGE";
                Add_Max_OptionalClause(FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown, FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_plusIcon);

                Reports.StatusUpdate("Custom Clauses are present on the screen", VerifyMaxCustomClause());
                Reports.TestStep = "REMOVE CLAUSE";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_plusIcon);

                Reports.TestStep = "ADDING MAX OPTIONAL CLAUSE FOR INTEREST RATE ELEMENT AND VERIFY ERROR MESSAGE";
                Add_Max_OptionalClause(FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown, FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon);
                Reports.StatusUpdate("Custom Clauses are present on the screen", VerifyMaxCustomClause());
                Reports.TestStep = "REMOVE CLAUSE";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon);

                Reports.TestStep = "ADDING MAX OPTIONAL CLAUSE FOR PRICIPAL INTEREST ELEMENT AND VERIFY ERROR MESSAGE";
                Add_Max_OptionalClause(FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown, FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon);
                Reports.StatusUpdate("Custom Clauses are present on the screen", VerifyMaxCustomClause());
                Reports.TestStep = "REMOVE CLAUSE";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon);

                Reports.TestStep = "ADDING MAX OPTIONAL CLAUSE FOR PREPAYMENT PENALTY ELEMENT AND VERIFY ERROR MESSAGE";
                Add_Max_OptionalClause(FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown, FastDriver.ClosingDisclosure.LoanTerm_PP_plusIcon);
                Reports.StatusUpdate("Custom Clauses are present on the screen", VerifyMaxCustomClause());
                Reports.TestStep = "REMOVE CLAUSE";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_PP_plusIcon);

                Reports.TestStep = "ADDING MAX OPTIONAL CLAUSE FOR BALOON PAYMENT ELEMENT AND VERIFY ERROR MESSAGE";
                Add_Max_OptionalClause(FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown, FastDriver.ClosingDisclosure.LoanTerm_BP_plusIcon);
                Reports.StatusUpdate("Custom Clauses are present on the screen", VerifyMaxCustomClause());
                Reports.TestStep = "REMOVE CLAUSE";
                Remove_Clause(FastDriver.ClosingDisclosure.LoanTerm_BP_plusIcon);

                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }            

        }
        #endregion

        #endregion

        #region USERSTORY 444976 DEFAULT LOAN PURPOSE BASED ON TRANSACTION TYPE ON CD FILE
        [TestMethod]
        #region USERSTORY-444976_TESTCASE_457470_SCENARIO1-VERIFY LOAN PURPOSE WHEN TRANSACTION TYPE MAPPED TO CONSTRUCTION TYPE ARE SELECTED AND MODIFIED.
        public void FTR5_ITR42_US_444976_TC_457470_SC1()
        {
            try
            {
                Reports.TestDescription = "VERIFY LOAN PURPOSE WHEN TRANSACTION TYPE MAPPED TO CONSTRUCTION TYPE ARE SELECTED AND MODIFIED.";
                Reports.TestStep = "Login to File side";
                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);

                Reports.TestStep = "Creating a basic file";
                var defaultRequest = RequestFactory.GetCreateFileDefaultRequest();
                defaultRequest.formType = FormType.CD;
                defaultRequest.File.Services = new Service[] { defaultRequest.File.Services[0], defaultRequest.File.Services[1] };
                defaultRequest.File.TransactionTypeObjectCD = "CD"; //"Construction Disbursement";

                var BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("214"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        } 
                    };
                
                defaultRequest.File.BusinessParties = BusinessParties;

                var File = FileService.GetOrderDetails((int)FileService.CreateFile(defaultRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                Reports.TestStep = "Navigate to CD Screen and Verify the Purpse type";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                string PurposeTypeatCDScreen = FastDriver.ClosingDisclosure.LoanPurpose.Text;
                Support.AreEqual(PurposeTypeatCDScreen, "Construction");

                Reports.TestStep = "Click on Purpose + Icon and and Verify the Loan Purpose dropdown value/option on Loan Purpose pop up window";
                FastDriver.ClosingDisclosure.PurposePlus.FAClick();
                Support.AreEqual(FastDriver.ClosingDisclosure.LoanPurposeTypeCDID.FAGetSelectedItem().ToString().Trim(), "Construction Only");
                //Reports.TestStep = "Change the Loan Purpose dropdown value/option and verify the same on CD screen and Loan Purpose dropdown value/option on Loan Purpose pop up window";
                //FastDriver.ClosingDisclosure.LoanPurposeTypeCDID.FASelectItem("Construction to Permanent");
                //Support.AreEqual("Changing the Purpose type may require changes to Transaction Type on file. If the Transaction Type and Purpose are of two different types, a new file will need to be opened.", FastDriver.WebDriver.HandleDialogMessage().ToString());
                //FastDriver.ClosingDisclosure.PurposeDone.FAClick();
                //PurposeTypeatCDScreen = FastDriver.ClosingDisclosure.LoanPurpose.Text;
                //Support.AreEqual(PurposeTypeatCDScreen, "Construction");
                //FastDriver.ClosingDisclosure.PurposePlus.FAClick();
                //Support.AreEqual(FastDriver.ClosingDisclosure.LoanPurposeTypeCDID.FAGetSelectedItem().ToString(), "Construction to Permanent");
                //FastDriver.ClosingDisclosure.PurposeDone.FAClick();

                //Reports.TestStep = "Change the Purpose Type and Verify the Pop up Message";
                //FastDriver.ClosingDisclosure.PurposePlus.FAClick();
                //FastDriver.ClosingDisclosure.LoanPurposeTypeCDID.FASelectItemBySendingKeys("H");


            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        #endregion

        #endregion



        #region
        private bool VerifyMaxCustomClause()
        {
           
            Reports.TestStep = "VERIFY 10 OPTIONAL CLAUSE ADDED ON THE SCREEN";           
            //UITestControlCollection coll = CD.GetControl("IIS.ClosingDisclosure", "Customclause").FindControlsMatch();
            ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));
            if (CheckBoxes.Count > 10)
            {
                    return true;
                    //Support.AreEqual("True", CheckBox.Selected.ToString());               
            }
            else
            {
                //Support.Fail("No checkbox found in the Loan Term Dialog");
                return false;
            }
        }
        private void Add_Max_OptionalClause(IWebElement drpdownObj, IWebElement plusIconObj)
        {
            drpdownObj.FASelectItem("YES");
            plusIconObj.FAClick();
            //FastDriver.ClosingDisclosure.OptionalClausePlusIcon.FAClick();
            

            for (int k = 0; k < 11; k++)
            {
                FastDriver.ClosingDisclosure.OptionalClausePlusIcon.FAClick();
            }

            String message = "Cannot add more than 10 custom clauses.";
            Support.AreEqual(message, FastDriver.WebDriver.HandleDialogMessage().ToString());
            FastDriver.WebDriver.HandleDialogMessage(true,true);
            FastDriver.ClosingDisclosure.SwitchToContentFrame();
            ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));

            if (CheckBoxes.Count > 0)
            {
                foreach (IWebElement CheckBox in CheckBoxes)
                {
                    CheckBox.FASetCheckbox(true);
                }
            }
            else
            {
                Support.Fail("No checkbox found in the Loan Term Dialog");
            }

            FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();
            Keyboard.SendKeys("{UP 2}");
        }
        private void Remove_Clause(IWebElement plusIconObj)
        {
            try
            {
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                plusIconObj.FAClick();
                

                BrowserWindow br = new BrowserWindow();
                br.SearchProperties["ClassName"] = "IEFrame";
                br.SearchProperties["ControlType"] = "Window";


                ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));

                if (CheckBoxes.Count > 0)
                {
                    foreach (IWebElement CheckBox in CheckBoxes)
                    {
                        CheckBox.FASetCheckbox(false);
                    }
                }
                else
                {
                    Support.Fail("No checkbox found in the Loan Term Dialog");
                }

                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        private void Add_Optionalclause(IWebElement drpdownObj, IWebElement plusIconObj)
        {
            drpdownObj.FASelectItem("YES");
            plusIconObj.FAClick();
            FastDriver.ClosingDisclosure.OptionalClausePlusIcon.FAClick();
            FastDriver.ClosingDisclosure.OptionalClausePlusIcon.FAClick();

            ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));

            if (CheckBoxes.Count > 0)
            {
                foreach (IWebElement CheckBox in CheckBoxes)
                {
                    CheckBox.FASetCheckbox(true);
                }
            }
            else
            {
                Support.Fail("No checkbox found in the Loan Term Dialog");
            }

            FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();
            Keyboard.SendKeys("{UP 2}");
        }
        private void Verify_SelectedOption(string element, IWebElement dropdownObj)
        {
            try
            {
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Reports.TestStep = "Selecting Yes option for " + element + " element ";
                dropdownObj.FASelectItem("YES");

                Reports.TestStep = "Click on Done";
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify error message and click on Ok";
                FastDriver.WebDriver.HandleDialogMessage(true, false, 5);

                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                Reports.TestStep = "Verify Dropdown value should be changed to NO for Baloon Payment Element";
                string selectedOption = dropdownObj.FAGetSelectedItem();
                Support.AreEqual("YES", selectedOption);

                dropdownObj.FASelectItem("NO");
                FastDriver.WebDriver.HandleDialogMessage(true, true, 5);

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        private void Add_LoanAmount_PredefinedClause()
        {
            try
            {
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown.FASelectItem("YES");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_plusIcon.FAClick();
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_CanGo_DrpDwn.FASelectItem("Can go");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_Amount.FASetText("4000");
                
                BrowserWindow br = new BrowserWindow();
                br.SearchProperties["ClassName"] = "IEFrame";
                br.SearchProperties["ControlType"] = "Window";


                ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));

                if (CheckBoxes.Count > 0)
                {
                    foreach (IWebElement CheckBox in CheckBoxes)
                    {
                        CheckBox.FASetCheckbox(true);
                    }
                }
                else
                {
                    Support.Fail("No checkbox found in the Loan Term Dialog");
                }

                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        private void Add_Ballon_Payment_PredefinedClause()
        {
            try
            {
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown.FASelectItem("YES");
                FastDriver.ClosingDisclosure.LoanTerm_BP_plusIcon.FAClick();
                FastDriver.ClosingDisclosure.LoanTerm_BP_MaxAmmount.FASetText("4000");


                BrowserWindow br = new BrowserWindow();
                br.SearchProperties["ClassName"] = "IEFrame";
                br.SearchProperties["ControlType"] = "Window";


                ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));

                if (CheckBoxes.Count > 0)
                {
                    foreach (IWebElement CheckBox in CheckBoxes)
                    {
                        CheckBox.FASetCheckbox(true);
                    }
                }
                else
                {
                    Support.Fail("No checkbox found in the Loan Term Dialog");
                }

                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        private void Add_PrePayment_Penalty_PredefinedClause()
        {
            try
            {
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown.FASelectItem("YES");
                FastDriver.ClosingDisclosure.LoanTerm_PP_plusIcon.FAClick();
                FastDriver.ClosingDisclosure.LoanTerm_PP_Expiration_Year.FASetText("12");
                FastDriver.ClosingDisclosure.LoanTerm_PP_MaxAmmount.FASetText("4000");
                
                BrowserWindow br = new BrowserWindow();
                br.SearchProperties["ClassName"] = "IEFrame";
                br.SearchProperties["ControlType"] = "Window";


                ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));

                if (CheckBoxes.Count > 0)
                {
                    foreach (IWebElement CheckBox in CheckBoxes)
                    {
                        CheckBox.FASetCheckbox(true);
                    }
                }
                else
                {
                    Support.Fail("No checkbox found in the Loan Term Dialog");
                }

                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        private void Add_Pricipal_Interest_PredefinedClause()
        {
            try
            {
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItem("YES");
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.FAClick();
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText("12");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText("02");
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText("08");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText("10");

                BrowserWindow br = new BrowserWindow();
                br.SearchProperties["ClassName"] = "IEFrame";
                br.SearchProperties["ControlType"] = "Window";


                ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));

                if (CheckBoxes.Count > 0)
                {
                    foreach (IWebElement CheckBox in CheckBoxes)
                    {
                        CheckBox.FASetCheckbox(true);
                    }
                }
                else
                {
                    Support.Fail("No checkbox found in the Loan Term Dialog");
                }

                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        private void Add_InterestRate_PredefinedClause()
        {
            try
            {
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItem("YES");
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.FAClick();
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText("12");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText("02");
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText("08");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText("10");

                BrowserWindow br = new BrowserWindow();
                br.SearchProperties["ClassName"] = "IEFrame";
                br.SearchProperties["ControlType"] = "Window";

                ReadOnlyCollection<IWebElement> CheckBoxes = FastDriver.ClosingDisclosure.LoanTerm_PlusPanel.FindElements(By.CssSelector("li > input"));

                if (CheckBoxes.Count > 0)
                {
                    foreach (IWebElement CheckBox in CheckBoxes)
                    {
                        CheckBox.FASetCheckbox(true);
                    }
                }
                else
                {
                    Support.Fail("No checkbox found in the Loan Term Dialog");
                }

                //FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(true);
                //FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox2.FASetCheckbox(true);
                //FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox3.FASetCheckbox(true);

                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.FAClick();
            
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }             
        }
        public void CreateOTC(string gab, int instance)
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<OutsideTitleSummary>(@"Home>Order Entry>Outside Title Company");
                if (instance == 2)
                {
                    Keyboard.SendKeys("^N");
                    Playback.Wait(7000);
                }
                if (instance > 2)
                {
                    FastDriver.OutsideTitleSummary.New.FAClick();
                }
                FastDriver.OTCDetail.GABcode.FASetText(gab);
                FastDriver.OTCDetail.Find.FAClick();
                otcdetail[0] = FastDriver.OTCDetail.BusinessPartyNameField.Text;
                otcdetail[1] = FastDriver.OTCDetail.BusinessPartyNameField2.Text;
                otcdetail[2] = FastDriver.OTCDetail.BusinessPartyAddress.Text;

                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }
        public void Buyer_SpAddress(string fname, string lname, bool la, string addr_type)
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();
                
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("#1", "1", "#1", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();

                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(fname);
                buyerdetail[0] = fname;
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(lname);
                buyerdetail[1] = lname;

                if (la)
                {
                    FastDriver.BuyerSellerSetup.LoanApplicant.FASetCheckbox(true);
                }
                else
                {
                    FastDriver.BuyerSellerSetup.LoanApplicant.FASetCheckbox(false);
                }
                                

                if(addr_type=="current")
                {
                    FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                    if (FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem() != "USA")
                    {
                        FastDriver.BuyerSellerSetup.CurrentCountry.FASelectItem("USA");
                    }

                    FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(Support.RandomString("NAN"));
                    buyerdetail[2] = FastDriver.BuyerSellerSetup.CurrentStreet1.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(Support.RandomString("NAN"));
                    buyerdetail[3] = FastDriver.BuyerSellerSetup.CurrentStreet2.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(Support.RandomString("NAN"));
                    buyerdetail[4] = FastDriver.BuyerSellerSetup.CurrentStreet3.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(Support.RandomString("NAN"));
                    buyerdetail[5] = FastDriver.BuyerSellerSetup.CurrentStreet4.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                    FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                    FastDriver.BuyerSellerSetup.CurrentZip.FASetText("88888");
                    FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");

                    FastDriver.BuyerSellerSetup.ForwardingSetToOther.FAClick();
                    FastDriver.BuyerSellerSetup.ForwardingState.FASelectItemByIndex(0);

                }
                if(addr_type=="forwarding")
                {
                    FastDriver.BuyerSellerSetup.ForwardingSetToOther.FAClick();
                    if (FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetSelectedItem() != "USA")
                    {
                        FastDriver.BuyerSellerSetup.ForwardingCountry.FASelectItem("USA");
                    }

                    FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(Support.RandomString("NAN"));
                    buyerdetail[6] = FastDriver.BuyerSellerSetup.ForwardingStreet1.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(Support.RandomString("NAN"));
                    buyerdetail[7] = FastDriver.BuyerSellerSetup.ForwardingStreet2.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(Support.RandomString("NAN"));
                    buyerdetail[8] = FastDriver.BuyerSellerSetup.ForwardingStreet3.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(Support.RandomString("NAN"));
                    buyerdetail[9] = FastDriver.BuyerSellerSetup.ForwardingStreet4.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Santa Ana");
                    FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                    FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("92727");
                    FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Orange");

                }

                if(addr_type=="blank")
                {
                    FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                    FastDriver.BuyerSellerSetup.CurrentState.FASelectItemByIndex(0);

                    FastDriver.BuyerSellerSetup.ForwardingSetToOther.FAClick();
                    FastDriver.BuyerSellerSetup.ForwardingState.FASelectItemByIndex(0);

                }

                FastDriver.BottomFrame.Done();
                
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }
        public void Buyer(string fname, string lname, bool la, int instance)
        {
            try
            {

                FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSetup.SwitchToContentFrame();

                if (instance > 1)
                {
                    FastDriver.BuyerSellerSummary.btnNew.FAClick();
                }
                else
                {
                    FastDriver.BuyerSellerSummary.WaitForBuyerSellerSummaryTableLoad();
                    FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("#1", "1", "#1", TableAction.Click);
                    FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                }

                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(fname);
                buyerdetail[0] = fname;
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(lname);
                buyerdetail[1] = lname;

                if (la)
                {
                    FastDriver.BuyerSellerSetup.LoanApplicant.FASetCheckbox(true);
                }
                else
                {
                    FastDriver.BuyerSellerSetup.LoanApplicant.FASetCheckbox(false);
                }

                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                if (FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem() != "USA")
                {
                    FastDriver.BuyerSellerSetup.CurrentCountry.FASelectItem("USA");
                }
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(Support.RandomString("NAN"));
                buyerdetail[2] = FastDriver.BuyerSellerSetup.CurrentStreet1.GetAttribute("value");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(Support.RandomString("NAN"));
                buyerdetail[3] = FastDriver.BuyerSellerSetup.CurrentStreet2.GetAttribute("value");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(Support.RandomString("NAN"));
                buyerdetail[4] = FastDriver.BuyerSellerSetup.CurrentStreet3.GetAttribute("value");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(Support.RandomString("NAN"));
                buyerdetail[5] = FastDriver.BuyerSellerSetup.CurrentStreet4.GetAttribute("value");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("88888");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");

                FastDriver.BuyerSellerSetup.ForwardingSetToOther.FAClick();
                if (FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetSelectedItem() != "USA")
                {
                    FastDriver.BuyerSellerSetup.ForwardingCountry.FASelectItem("USA");
                }
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(Support.RandomString("NAN"));
                buyerdetail[6] = FastDriver.BuyerSellerSetup.ForwardingStreet1.GetAttribute("value");
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(Support.RandomString("NAN"));
                buyerdetail[7] = FastDriver.BuyerSellerSetup.ForwardingStreet2.GetAttribute("value");
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(Support.RandomString("NAN"));
                buyerdetail[8] = FastDriver.BuyerSellerSetup.ForwardingStreet3.GetAttribute("value");
                FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(Support.RandomString("NAN"));
                buyerdetail[9] = FastDriver.BuyerSellerSetup.ForwardingStreet4.GetAttribute("value");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("92727");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Orange");


                FastDriver.BottomFrame.Done();

            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }


        }
        public void SplitPayee(int splitamount)
        {
            Reports.TestStep = "Navigate to Fee Entry Screen";
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry");
            FastDriver.FileFees.SwitchToContentFrame();
            Reports.TestStep = "Entering Charges for Fee";

            FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);

            FastDriver.FileFees.buyercharge.FASetText("3000.00");
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Navigate to Split Fee Disbursements Screen";
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.FileFees.SwitchToContentFrame();

            Reports.TestStep = "Splitting Fees";
            if (splitamount == 1)
            {
                FastDriver.SplitFeeDisbursements.SwitchToContentFrame();
                FastDriver.SplitFeeDisbursements.New.FAClick();

                FastDriver.WebDriver.WaitForWindowAndSwitch("Payee Search");
                FastDriver.PayeeSearchDlg.SwitchToDialogContentFrame();


                FastDriver.PayeeSearchDlg.OfficeAdressBook.FAClick();
                FastDriver.PayeeSearchDlg.FABFirstCheckBox.FAClick();

                FastDriver.PayeeSearchDlg.SwitchToDialogBottomFrame();

                //Closing the PayeeSearchDlg screen
                FastDriver.BottomFrame.btnDone.FAClick();

                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.SplitFeeDisbursements.SwitchToContentFrame();

                //Capturing the splitpayee1 values
                splitpayee1[0] = FastDriver.SplitFeeDisbursements.Payee1Name.Text;
                splitpayee1[1] = FastDriver.SplitFeeDisbursements.Payee1Address.Text;
                splitpayee1[2] = FastDriver.SplitFeeDisbursements.Payee1City.Text;
                splitpayee1[3] = FastDriver.SplitFeeDisbursements.Payee1State.Text;
                splitpayee1[4] = FastDriver.SplitFeeDisbursements.Payee1Zip.Text;

                FastDriver.SplitFeeDisbursements.Scissor1.FAClick();
                FastDriver.SplitFeeDisbursements.Scissor1.FireEvent("onclick");
                Playback.Wait(5000);
                FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(3, 1, TableAction.Click);
                Playback.Wait(1000);
                //FastDriver.SplitFeeDisbursements.Payee.PerformTableAction(1, "Bank of America", 1, TableAction.Click);

                //Setting the Payee DDL value & the SplitPercentage               
                FastDriver.SplitFeeDisbursements.Payee.FASelectItemBySendingKeys("BuyerName BuyerLastName");
                FastDriver.SplitFeeDisbursements.Payee.FireEvent("onmousedown");
                Playback.Wait(5000);
                FastDriver.SplitFeeDisbursements.SplitPercentage.FASetText("10.0000" + FAKeys.Tab);
                FastDriver.SplitFeeDisbursements.Payee.FireEvent("onblur");
                Playback.Wait(5000);
                FastDriver.SplitFeeDisbursements.SplitAmount.FAClick();

            }

            if (splitamount == 2)
            {
                FastDriver.SplitFeeDisbursements.New.FAClick();
                FastDriver.PayeeSearchDlg.SwitchToDialogContentFrame();

                FastDriver.PayeeSearchDlg.Office.FAClick();
                FastDriver.PayeeSearchDlg.FABFirstCheckBox.FAClick();
                FastDriver.PayeeSearchDlg.FABfourthCheckBox.FAClick();

                FastDriver.PayeeSearchDlg.SwitchToDialogBottomFrame();

                //Closing the PayeeSearchDlg screen
                FastDriver.BottomFrame.btnDone.FAClick();

                //Capturing the splitpayee1 values
                splitpayee1[0] = FastDriver.SplitFeeDisbursements.Payee1Name.Text;
                splitpayee1[1] = FastDriver.SplitFeeDisbursements.Payee1Address.Text;
                splitpayee1[2] = FastDriver.SplitFeeDisbursements.Payee1City.Text;
                splitpayee1[3] = FastDriver.SplitFeeDisbursements.Payee1State.Text;
                splitpayee1[4] = FastDriver.SplitFeeDisbursements.Payee1Zip.Text;

                splitpayee2[0] = FastDriver.SplitFeeDisbursements.Payee2Name.Text;
                splitpayee2[1] = FastDriver.SplitFeeDisbursements.Payee2Address.Text;
                splitpayee2[2] = FastDriver.SplitFeeDisbursements.Payee2City.Text;
                splitpayee2[3] = FastDriver.SplitFeeDisbursements.Payee2State.Text;
                splitpayee2[4] = FastDriver.SplitFeeDisbursements.Payee2Zip.Text;

                //Setting the Payee DDL value & the SplitPercentage
                FastDriver.SplitFeeDisbursements.Scissor1.FAClick();

                FastDriver.SplitFeeDisbursements.Payee.FASelectItemByIndex(1);
                FastDriver.SplitFeeDisbursements.SplitPercentage.FASetText("10.0000");
                Support.SendKeys(FAKeys.Tab);
                FastDriver.SplitFeeDisbursements.Scissor1.FAClick();

                FastDriver.SplitFeeDisbursements.Payee.FASelectItemByIndex(2);
                FastDriver.SplitFeeDisbursements.SplitPercentage.FASetText("20.0000");

                Support.SendKeys(FAKeys.Tab);

            }


            Reports.TestStep = "Saving the Split Payee";
            FastDriver.SplitFeeDisbursements.SwitchToBottomFrame();
            FastDriver.BottomFrame.btnDone.FAClick();

        }
        public void Seller_SpAddress(string fname, string lname, string addr_type)
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Sellers");


                FastDriver.BuyerSellerSummary.WaitForBuyerSellerSummaryTableLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("#1", "1", "#1", TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();


                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(fname);
                sellerdetail[0] = FastDriver.BuyerSellerSetup.IndividualFirstName.GetAttribute("value");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(lname);
                sellerdetail[1] = FastDriver.BuyerSellerSetup.IndividualLastName.GetAttribute("value");

                if (addr_type == "current")
                {
                    FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                    if (FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem() != "USA")
                    {
                        FastDriver.BuyerSellerSetup.CurrentCountry.FASelectItem("USA");
                    }
                    FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(Support.RandomString("NAN"));
                    sellerdetail[2] = FastDriver.BuyerSellerSetup.CurrentStreet1.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(Support.RandomString("NAN"));
                    sellerdetail[3] = FastDriver.BuyerSellerSetup.CurrentStreet2.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(Support.RandomString("NAN"));
                    sellerdetail[4] = FastDriver.BuyerSellerSetup.CurrentStreet3.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(Support.RandomString("NAN"));
                    sellerdetail[5] = FastDriver.BuyerSellerSetup.CurrentStreet4.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                    FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                    FastDriver.BuyerSellerSetup.CurrentZip.FASetText("88888");
                    FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");

                }

                if (addr_type == "forwarding")
                {
                    FastDriver.BuyerSellerSetup.ForwardingSetToOther.FAClick();
                    if (FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetSelectedItem() != "USA")
                    {
                        FastDriver.BuyerSellerSetup.ForwardingCountry.FASelectItem("USA");
                    }
                    FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(Support.RandomString("NAN"));
                    sellerdetail[2] = FastDriver.BuyerSellerSetup.ForwardingStreet1.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(Support.RandomString("NAN"));
                    sellerdetail[3] = FastDriver.BuyerSellerSetup.ForwardingStreet2.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(Support.RandomString("NAN"));
                    sellerdetail[4] = FastDriver.BuyerSellerSetup.ForwardingStreet3.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(Support.RandomString("NAN"));
                    sellerdetail[5] = FastDriver.BuyerSellerSetup.ForwardingStreet4.GetAttribute("value");
                    FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Santa Ana");
                    FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                    FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("92727");
                    FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Orange");
                }

                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        public void Seller(string fname, string lname, int instance)
        {

            try
            {
                FastDriver.LeftNavigation.Navigate<HomeownerAssociation>(@"Home>Order Entry>Sellers");

                if (instance > 1)
                {
                    //FastDriver.BuyerSellerSummary.WaitForBuyerSellerSummaryTableLoad();
                    FastDriver.BuyerSellerSummary.SwitchToContentFrame();
                    FastDriver.BuyerSellerSummary.btnNew.FAClick();
                }
                else
                {
                    FastDriver.BuyerSellerSummary.WaitForBuyerSellerSummaryTableLoad();
                    FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction("#1", "1", "#1", TableAction.Click);
                    FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                }



                FastDriver.BuyerSellerSetup.IndividualFirstName.FASetText(fname);
                sellerdetail[0] = FastDriver.BuyerSellerSetup.IndividualFirstName.GetAttribute("value");
                FastDriver.BuyerSellerSetup.IndividualLastName.FASetText(lname);
                sellerdetail[1] = FastDriver.BuyerSellerSetup.IndividualLastName.GetAttribute("value");


                FastDriver.BuyerSellerSetup.CurrentSetToOther.FAClick();
                if (FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem() != "USA")
                {
                    FastDriver.BuyerSellerSetup.CurrentCountry.FASelectItem("USA");
                }
                FastDriver.BuyerSellerSetup.CurrentStreet1.FASetText(Support.RandomString("NAN"));
                sellerdetail[2] = FastDriver.BuyerSellerSetup.CurrentStreet1.GetAttribute("value");
                FastDriver.BuyerSellerSetup.CurrentStreet2.FASetText(Support.RandomString("NAN"));
                sellerdetail[3] = FastDriver.BuyerSellerSetup.CurrentStreet2.GetAttribute("value");
                FastDriver.BuyerSellerSetup.CurrentStreet3.FASetText(Support.RandomString("NAN"));
                sellerdetail[4] = FastDriver.BuyerSellerSetup.CurrentStreet3.GetAttribute("value");
                FastDriver.BuyerSellerSetup.CurrentStreet4.FASetText(Support.RandomString("NAN"));
                sellerdetail[5] = FastDriver.BuyerSellerSetup.CurrentStreet4.GetAttribute("value");
                FastDriver.BuyerSellerSetup.CurrentCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.CurrentState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.CurrentZip.FASetText("88888");
                FastDriver.BuyerSellerSetup.CurrentCounty.FASetText("Orange");


                FastDriver.BuyerSellerSetup.ForwardingSetToOther.FAClick();
                if (FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetSelectedItem() != "USA")
                {
                    FastDriver.BuyerSellerSetup.ForwardingCountry.FASelectItem("USA");
                }
                FastDriver.BuyerSellerSetup.ForwardingStreet1.FASetText(Support.RandomString("NAN"));
                sellerdetail[6] = FastDriver.BuyerSellerSetup.ForwardingStreet1.GetAttribute("value");
                FastDriver.BuyerSellerSetup.ForwardingStreet2.FASetText(Support.RandomString("NAN"));
                sellerdetail[7] = FastDriver.BuyerSellerSetup.ForwardingStreet2.GetAttribute("value");
                FastDriver.BuyerSellerSetup.ForwardingStreet3.FASetText(Support.RandomString("NAN"));
                sellerdetail[8] = FastDriver.BuyerSellerSetup.ForwardingStreet3.GetAttribute("value");
                FastDriver.BuyerSellerSetup.ForwardingStreet4.FASetText(Support.RandomString("NAN"));
                sellerdetail[9] = FastDriver.BuyerSellerSetup.ForwardingStreet4.GetAttribute("value");
                FastDriver.BuyerSellerSetup.ForwardingCity.FASetText("Santa Ana");
                FastDriver.BuyerSellerSetup.ForwardingState.FASelectItem("CA");
                FastDriver.BuyerSellerSetup.ForwardingZip.FASetText("92727");
                FastDriver.BuyerSellerSetup.ForwardingCounty.FASetText("Orange");

                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }
        public void GetOwningOfficeInfo()
        {
            try
            {
                Reports.TestStep = "Obtain Owning Office Information";
                Reports.TestStep = "Login to adm side";

                Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
                FASTLogin.Login(AutoConfig.FASTAdmURL, Credentials, true);
                
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878");

                

                Reports.TestStep = "Obtaining the Office Information";
                FastDriver.OfficeSetupOffice.SwitchToContentFrame();

                FastDriver.OfficeSetupOffice.TableAddress.PerformTableAction(1, "Mailing", 1, TableAction.Click);
                string addr = FastDriver.OfficeSetupOffice.TableAddress.Text;
                Support.AreEqual("True", addr.Contains("Mailing").ToString());

                owningoffice[0] = FastDriver.OfficeSetupOffice.OfficeCompanyName1.GetAttribute("Value");
                owningoffice[1] = (FastDriver.OfficeSetupOffice.OfficeCompanyName2.GetAttribute("Value") == null) ? "" : FastDriver.OfficeSetupOffice.OfficeCompanyName2.GetAttribute("Value");
                owningoffice[2] = FastDriver.OfficeSetupOffice.StreetLine1.GetAttribute("Value");
                owningoffice[3] = (FastDriver.OfficeSetupOffice.StreetLine2.GetAttribute("Value") == null) ? "" : FastDriver.OfficeSetupOffice.StreetLine2.GetAttribute("Value");
                owningoffice[4] = (FastDriver.OfficeSetupOffice.StreetLine3.GetAttribute("Value") == null) ? "" : FastDriver.OfficeSetupOffice.StreetLine3.GetAttribute("Value");
                owningoffice[5] = (FastDriver.OfficeSetupOffice.StreetLine4.GetAttribute("Value") == null) ? "" : FastDriver.OfficeSetupOffice.StreetLine4.GetAttribute("Value");
                owningoffice[6] = FastDriver.OfficeSetupOffice.City.GetAttribute("Value");
                owningoffice[7] = FastDriver.OfficeSetupOffice.State.FAGetSelectedItem();
                owningoffice[8] = FastDriver.OfficeSetupOffice.Zip.GetAttribute("Value");
                owningoffice[9] = FastDriver.OfficeSetupOffice.County.GetAttribute("Value");
                owningoffice[10] = FastDriver.OfficeSetupOffice.Country.FAGetSelectedItem();


                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }

        }
        public void CreateOEC(string gab, int instance)
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>(@"Home>Order Entry>Outside Escrow Company");
                if (instance == 2)
                {
                    //TODO Send the key combination ALT+N
                }
                if (instance > 2)
                {
                    //TODO click the New button
                }

                FastDriver.OutsideEscrowCompanyDetail.SwitchToContentFrame();
                FastDriver.OutsideEscrowCompanyDetail.GABcode.FASetText(gab);
                FastDriver.OutsideEscrowCompanyDetail.Find.FAClick();


                oecdetail[0] = FastDriver.OutsideEscrowCompanyDetail.Name.Text;
                oecdetail[1] = FastDriver.OutsideEscrowCompanyDetail.BusinessPartyNameField.Text;
                oecdetail[2] = FastDriver.OutsideEscrowCompanyDetail.Address.Text;




            }
            catch (Exception ex)
            {

                Support.Fail(ex.Message);
            }
        }
        public void CreateFee(string FeeDesc, string FeeType, bool FeedescEdit, bool ThirdPartyPayee, string ThirdPartyPayeeName, string BuyerSection, string SellerSection)
        {
            Reports.TestStep = "Create Fee in Admin";
            Reports.TestStep = "Navigate to Fee Setup screen";

            FastDriver.LeftNavigation.Navigate<FeeSetup>(@"Home>System Maintenance>Fee Setup>Fee Summary");
            //FastDriver.FeeSetup.CreateFee(FeeDesc, FeedescEdit, FeeType, ThirdPartyPayee, ThirdPartyPayeeName, BuyerSection, SellerSection);

            FastDriver.FeeList2.New.FAClick();
            FastDriver.FeeSetup.SwitchToContentFrame();
            FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType, 10);
            FastDriver.FeeSetup.HudType.FASelectItem("CD");
            FastDriver.FeeSetup.Description.FASetText(FeeDesc);
            FastDriver.FeeSetup.FeeCode.FASetText(Support.RandomString("ANANA"));
            FastDriver.FeeSetup.FeeType.FASelectItem(FeeType);
            
            Playback.Wait(2000);
            FastDriver.FeeSetup.DescriptionEditable.FASetCheckbox(FeedescEdit);
            FastDriver.FeeSetup.GLCode.FASelectItemByIndex(1); //"744 Abandon");
            FastDriver.FeeSetup.FeeDistribution.FASelectItem("Title");
            FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItem("Escrow Owning Office");

            if (ThirdPartyPayee)
            {
                FastDriver.FeeSetup.ThirdPartyPayee.FASetCheckbox(ThirdPartyPayee);
                FastDriver.FeeSetup.ThirdPartyPNameDefault.FASetText(ThirdPartyPayeeName);
            }
            else
            {
                FastDriver.FeeSetup.ThirdPartyPayee.FASetCheckbox(ThirdPartyPayee);
            }

            FastDriver.FeeSetup.BuyerSection.FASelectItem(BuyerSection);
            FastDriver.FeeSetup.SellerSection.FASelectItem(SellerSection);
            
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.FeeSetup.SwitchToContentFrame();
            FastDriver.BottomFrame.Done();
            //Keyboard.SendKeys("^D");

        }
        private void  _CreateFile()
        {

            var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
            customizableFileRequest.formType = FormType.CD;
            customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
            customizableFileRequest.File.TransactionTypeObjectCD = "SALE";
            customizableFileRequest.File.SalesPriceAmount = 5000;
            customizableFileRequest.File.LiabilityAmount = 5000;

            customizableFileRequest.File.Properties = new Property[] 
            { 
                new Property() 
                {
                    PropertyAddress = new PhysicalAddress[] 
                    {
                        new PhysicalAddress() 
                        { 
                            State = "CA",  
                            City = "ALBANY", 
                            County = "ALAMEDA", 
                            Country = "USA",
                            AddrLine1 = "J305",
                            AddrLine2 = "JJEJAMQ",
                            AddrLine3 = "JJEJAMQ"
                        } 
                    },
                    Name = "J305",
                    ProperyTypeCdID = 15,
                    Lot = "Lot1",
                    Block = "Block1",
                    Unit = "Unit1",
                    EstateTypeCdID = 1914
                } 
            };

            customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.SellersAttorney
                            }
                        } 
                };
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

          
        }
        #endregion

        #region LOGINS
        //public void _IISLOGIN(string UserName = null, string Password = null)
        //{

        //    //var website = AutoConfig.FASTHomeURL;
        //    //UserName = UserName ?? AutoConfig.UserName;
        //    //Password = Password ?? AutoConfig.UserPassword;
        //    Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
        //    FASTLogin.Login(AutoConfig.FASTHomeURL, Credentials, true);
        //}

        //public void _ADMLOGIN(string UserName = null, string Password = null)
        //{

        //    //var website = AutoConfig.FASTAdmURL;
        //    //UserName = UserName ?? AutoConfig.UserName;
        //    //Password = Password ?? AutoConfig.UserPassword;
        //    //Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
        //    //FASTLogin.Login(website, Credentials, true);
        //    Credentials Credentials = new Credentials() { UserName = AutoConfig.UserName.ToString(), Password = AutoConfig.UserPassword.ToString() };
        //    FASTLogin.Login(AutoConfig.FASTAdmURL, Credentials, true);
        //}
        #endregion


        #region Additional test attributes
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); } 



        #endregion
    }
}
